package br.com.edgard.aura;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Intent;
import android.content.Context;
import android.media.AudioAttributes;
import android.media.AudioManager;
import android.media.MediaPlayer;
import android.net.Uri;
import android.os.Build;
import android.os.Handler;
import android.os.HandlerThread;
import android.os.IBinder;
import android.util.Log;
import br.com.edgard.aura.core.MixMath;
import org.json.JSONArray;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.atomic.AtomicBoolean;

/** Low-latency two-deck Android playback using source URIs, without decoding
 * entire songs to temporary PCM. The safe 2-player crossfade is NOT certified
 * beatmatching, stems or tone-preserving time stretching.
 */
public final class QuickMixService extends Service {
    public static final String START="br.com.edgard.aura.quick.START";
    public static final String STOP="br.com.edgard.aura.quick.STOP";
    public static final String PAUSE="br.com.edgard.aura.quick.PAUSE";
    public static final String RESUME="br.com.edgard.aura.quick.RESUME";
    public static final String NEXT="br.com.edgard.aura.quick.NEXT";
    private static final String TAG="AURA-QuickMix";
    private static final String CHANNEL="aura-quick-audio";
    private static final AtomicBoolean ACTIVE=new AtomicBoolean(false);
    private final List<Uri> songs=new ArrayList<>();
    private final List<String> titles=new ArrayList<>();
    private HandlerThread thread;
    private Handler worker;
    private MediaPlayer on,next;
    private boolean onReady=false,nextReady=false,playing=false,paused=false,mixing=false;
    private int index=0,style=0,requestedBeats=0;
    private long fadeMs=4200,fadeStarted=0,pauseStarted=0;
    private int fadeLength=4000;
    private int generation=0;
    private AudioManager audioManager;
    private AudioManager.OnAudioFocusChangeListener focusChange;
    private final Runnable ticker=new Runnable(){@Override public void run(){tick();}};
    public static boolean isPlaying(){return ACTIVE.get();}
    @Override public IBinder onBind(Intent intent){return null;}
    @Override public void onCreate(){
        super.onCreate();
        thread=new HandlerThread("AURA11-quick-audio");thread.start();
        worker=new Handler(thread.getLooper());
        audioManager=(AudioManager)getSystemService(Context.AUDIO_SERVICE);
        focusChange=change->{if(change<=0 && worker!=null)worker.post(()->pauseEngine(false));};
        if(Build.VERSION.SDK_INT>=26){
            NotificationManager n=(NotificationManager)getSystemService(NOTIFICATION_SERVICE);
            n.createNotificationChannel(new NotificationChannel(CHANNEL,"AURA DJ — reprodução",NotificationManager.IMPORTANCE_LOW));
        }
    }
    private void status(String s){
        getSharedPreferences("aura",MODE_PRIVATE).edit().putString("status",s).apply();
        Log.i(TAG,s);
    }
    private void state(String s){
        getSharedPreferences("aura",MODE_PRIVATE).edit()
                .putString("dj_mode",s).putInt("dj_index",index)
                .putString("dj_next",index+1<titles.size()?titles.get(index+1):"")
                .apply();
    }
    @Override public int onStartCommand(Intent intent,int flags,int startId){
        if(intent==null)return START_NOT_STICKY;
        final String action=intent.getAction();
        if(START.equals(action)){
            Intent open=new Intent(this,MainActivity.class);
            int pendingFlags=PendingIntent.FLAG_UPDATE_CURRENT|(Build.VERSION.SDK_INT>=23?PendingIntent.FLAG_IMMUTABLE:0);
            Notification note=new Notification.Builder(this,CHANNEL)
                 .setContentTitle("EDGARD AURA DJ").setContentText("Preparando reprodução nativa")
                 .setSmallIcon(android.R.drawable.ic_media_play)
                 .setContentIntent(PendingIntent.getActivity(this,3,open,pendingFlags)).setOngoing(true).build();
            startForeground(11,note);
            int selectedStyle=intent.getIntExtra("style",0),beats=intent.getIntExtra("beats",0);
            worker.post(()->startEngine(selectedStyle,beats));
        }else if(STOP.equals(action))worker.post(this::stopEngine);
        else if(PAUSE.equals(action))worker.post(()->pauseEngine(true));
        else if(RESUME.equals(action))worker.post(this::resumeEngine);
        else if(NEXT.equals(action))worker.post(this::skipEngine);
        return START_NOT_STICKY;
    }
    private void startEngine(int s,int beats){
        releaseDecks();songs.clear();titles.clear();
        style=Math.max(0,Math.min(7,s));requestedBeats=beats;fadeMs=fadeDuration();
        try{
            JSONArray arr=new JSONArray(getSharedPreferences("aura",MODE_PRIVATE).getString("fastUris","[]"));
            JSONArray labels=new JSONArray(getSharedPreferences("aura",MODE_PRIVATE).getString("fastNames","[]"));
            for(int i=0;i<arr.length();i++){
                songs.add(Uri.parse(arr.getString(i)));
                titles.add(i<labels.length()?labels.getString(i):"Música "+(i+1));
            }
            if(songs.isEmpty())throw new IllegalStateException("Nenhuma música selecionada");
            if(audioManager!=null){
                int focus=audioManager.requestAudioFocus(focusChange,AudioManager.STREAM_MUSIC,AudioManager.AUDIOFOCUS_GAIN);
                if(focus!=AudioManager.AUDIOFOCUS_REQUEST_GRANTED)Log.w(TAG,"Audio focus not granted: "+focus);
            }
            playing=true;paused=false;mixing=false;index=0;ACTIVE.set(true);
            status("Abrindo primeira música (sem conversão PCM): "+titles.get(0));
            state("loading");
            int epoch=++generation;
            on=createPlayer(0,false,epoch);
            worker.removeCallbacks(ticker);worker.postDelayed(ticker,100);
        }catch(Exception ex){failure("Erro ao iniciar reprodução imediata",ex);stopEngine();}
    }
    private MediaPlayer createPlayer(int position,boolean preload,int epoch)throws Exception{
        MediaPlayer player=new MediaPlayer();
        AudioAttributes attr=new AudioAttributes.Builder().setUsage(AudioAttributes.USAGE_MEDIA)
                       .setContentType(AudioAttributes.CONTENT_TYPE_MUSIC).build();
        player.setAudioAttributes(attr);
        player.setDataSource(this,songs.get(position));
        player.setVolume(preload?0f:1f,preload?0f:1f);
        player.setOnPreparedListener(p->{
            if(!playing||generation!=epoch){release(p);return;}
            if(preload){
                if(p!=next){release(p);return;}
                nextReady=true;
                if(on==null){
                    // Previous source ended before preload completed. Resume immediately.
                    on=next;next=null;onReady=true;nextReady=false;index++;
                    try{on.setVolume(1f,1f);if(!paused)on.start();}
                    catch(Exception ex){failure("Falha no próximo áudio",ex);stopEngine();return;}
                    state(paused?"paused":"playing");status("TOCANDO: "+titles.get(index));
                    preloadFollowing();
                }else status("Próxima pronta: "+titles.get(index+1));
            }else{
                if(p!=on){release(p);return;}
                onReady=true;
                if(!paused){try{p.start();}catch(Exception ex){failure("Falha ao reproduzir",ex);moveNextNow();return;}}
                state(paused?"paused":"playing");
                status("TOCANDO: "+titles.get(index));
                preloadFollowing();
            }
        });
        player.setOnCompletionListener(p->{
            if(p!=on)return;
            if(mixing)endFade(); else moveNextNow();
        });
        player.setOnErrorListener((p,what,extra)->{
            status("Erro MediaPlayer "+what+"/"+extra+" na faixa "+(position+1)+": "+titles.get(position));
            Log.e(TAG,"MediaPlayer "+what+"/"+extra+" track="+position);
            if(p==on)moveNextNow();
            else if(p==next){nextReady=false;release(next);next=null;if(on==null)moveNextNow();}
            return true;
        });
        player.prepareAsync();
        return player;
    }
    private void preloadFollowing(){
        if(!playing||!onReady||next!=null||index+1>=songs.size())return;
        try{
            int epoch=generation;
            next=createPlayer(index+1,true,epoch);
        }catch(Exception e){status("Falha ao preparar próxima: "+e.getMessage());Log.e(TAG,"Preload",e);}
    }
    private void tick(){
        if(!playing)return;
        try{
            if(onReady && on!=null && !paused){
                int position=on.getCurrentPosition(),duration=on.getDuration();
                getSharedPreferences("aura",MODE_PRIVATE).edit()
                    .putFloat("dj_time",position/1000f).apply();
                if(mixing){
                    double t=Math.max(0,Math.min(1,(android.os.SystemClock.uptimeMillis()-fadeStarted)/(double)fadeLength));
                    if(on!=null)on.setVolume((float)MixMath.gain(style,false,t),(float)MixMath.gain(style,false,t));
                    if(next!=null)next.setVolume((float)MixMath.gain(style,true,t),(float)MixMath.gain(style,true,t));
                    if(t>=1)endFade();
                }else if(next!=null && nextReady && duration>0 && duration-position<=fadeMs){
                    startFade((int)fadeMs);
                }else if(duration>0&&duration-position<=1200&&next==null)preloadFollowing();
            }
        }catch(Exception e){Log.w(TAG,"Playback tick",e);}
        if(playing)worker.postDelayed(ticker,45);
    }
    private int fadeDuration(){
        if(requestedBeats>0){
            // Without measured BPM, manual beat units are only an approximate duration.
            return Math.max(1200,Math.min(14000,(int)Math.round(requestedBeats*60000.0/128.0)));
        }
        return 4200;
    }
    private void startFade(int length){
        if(mixing||!onReady||next==null||!nextReady)return;
        try{
            fadeLength=Math.max(600,length);fadeStarted=android.os.SystemClock.uptimeMillis();
            if(paused)return;
            next.setVolume(0f,0f);next.start();mixing=true;
            state("mixing");
            status("CROSSFADE REAL: "+titles.get(index)+" → "+titles.get(index+1));
        }catch(Exception ex){failure("Falha ao iniciar crossfade",ex);moveNextNow();}
    }
    private void endFade(){
        MediaPlayer old=on;on=next;next=null;
        nextReady=false;mixing=false;onReady=on!=null;
        if(old!=null&&old!=on)release(old);
        if(on==null){moveNextNow();return;}
        on.setVolume(1f,1f);index++;
        state("playing");status("TOCANDO: "+titles.get(index));
        preloadFollowing();
    }
    private void moveNextNow(){
        if(!playing)return;
        if(nextReady&&next!=null){
            if(on!=null)release(on);
            on=next;next=null;onReady=true;nextReady=false;mixing=false;
            index++;on.setVolume(1f,1f);
            try{if(!paused)on.start();}catch(Exception e){failure("Falha ao iniciar próxima",e);stopEngine();return;}
            state(paused?"paused":"playing");status("TOCANDO: "+titles.get(index));preloadFollowing();
            return;
        }
        release(on);on=null;onReady=false;mixing=false;
        if(next!=null){
            // Pending async preparation. Its listener remains active and will be
            // handled by tick once it is ready (no silence mistaken for success).
            status("Aguardando preparar próxima faixa…");
            return;
        }
        if(index+1<songs.size()){
            index++;try{on=createPlayer(index,false,generation);}
            catch(Exception ex){failure("Erro ao abrir próxima",ex);stopEngine();}
        }else{status("Set concluído");stopEngine();}
    }
    private void skipEngine(){
        if(!playing)return;
        if(nextReady&&next!=null && onReady&&!paused){startFade(1500);}
        else moveNextNow();
    }
    private void pauseEngine(boolean user){
        if(!playing)return;
        paused=true;pauseStarted=android.os.SystemClock.uptimeMillis();
        try{if(on!=null&&on.isPlaying())on.pause();}catch(Exception ignored){}
        try{if(next!=null&&next.isPlaying())next.pause();}catch(Exception ignored){}
        state("paused");if(user)status("Pausado");
    }
    private void resumeEngine(){
        if(!playing)return;
        paused=false;
        if(mixing&&pauseStarted>0)fadeStarted+=android.os.SystemClock.uptimeMillis()-pauseStarted;pauseStarted=0;
        try{if(onReady&&on!=null&&!on.isPlaying())on.start();
            if(mixing&&nextReady&&next!=null&&!next.isPlaying())next.start();}
        catch(Exception ex){failure("Falha ao retomar",ex);}
        state(mixing?"mixing":"playing");status("Reprodução retomada");
    }
    private void release(MediaPlayer p){if(p!=null){try{p.reset();}catch(Exception ignored){}try{p.release();}catch(Exception ignored){}}}
    private void releaseDecks(){if(worker!=null)worker.removeCallbacks(ticker);release(on);release(next);on=next=null;onReady=nextReady=false;mixing=false;}
    private void stopEngine(){
        ++generation;playing=false;paused=false;ACTIVE.set(false);
        releaseDecks();
        if(audioManager!=null)audioManager.abandonAudioFocus(focusChange);
        state("idle");stopForeground(STOP_FOREGROUND_REMOVE);stopSelf();
    }
    private void failure(String prefix,Exception e){
        String error=prefix+": "+e.getClass().getSimpleName()+" — "+e.getMessage();
        getSharedPreferences("aura",MODE_PRIVATE).edit().putString("lastCrash",Log.getStackTraceString(e)).apply();
        status(error);Log.e(TAG,prefix,e);
    }
    @Override public void onDestroy(){
        if(worker!=null){worker.removeCallbacksAndMessages(null);releaseDecks();}
        ACTIVE.set(false);
        if(thread!=null){thread.quitSafely();thread=null;}
        super.onDestroy();
    }
}
