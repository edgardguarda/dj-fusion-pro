package br.com.edgard.aura;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Intent;
import android.graphics.Color;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.provider.OpenableColumns;
import android.util.Log;
import android.view.View;
import android.view.WindowManager;
import android.webkit.ConsoleMessage;
import android.webkit.JavascriptInterface;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebResourceResponse;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Toast;

import br.com.edgard.aura.core.BeatAnalyzer;
import br.com.edgard.aura.core.TrackData;
import br.com.edgard.aura.core.TrackPlanner;
import java.io.File;
import java.io.FileInputStream;
import java.io.InputStream;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import org.json.JSONObject;
import org.json.JSONArray;
import java.util.concurrent.atomic.AtomicInteger;

/** The COMPLETE original AURA UI is an offline Android asset.
 * Audio in Native mode is rendered by MediaCodec + AudioTrack, not WebAudio.
 * Classic mode remains accessible for advanced legacy controls/visualizers.
 */
public final class MainActivity extends Activity {
    private static final String TAG="AURA9";
    private static final int PICK_AUDIO=701, SAVE_MASTER=702;
    private static final String APP_URL="https://aura.android.local/index.html";
    private final Handler main=new Handler(Looper.getMainLooper());
    private WebView web;
    private android.webkit.ValueCallback<Uri[]> webFileResult;
    private boolean nativeFileSelect=false;
    private final ArrayList<Uri> musicUris=new ArrayList<>();
    private volatile boolean preparing=false;
    private volatile boolean loaded=false;
    private volatile int decodedCount=0;
    private volatile String decodeFailures="";
    private volatile int selectedCount=0;
    private volatile int playIndex=0;
    private volatile Thread preparationThread;
    private final AtomicInteger prepVersion=new AtomicInteger(0);
    private final ArrayList<String> selectedNames=new ArrayList<>();
    private final ArrayList<TrackData> ready=new ArrayList<>();
    private int preparedStyle=0, preparedBeats=16;

    @Override public void onCreate(Bundle state){
        super.onCreate(state);
        Thread.setDefaultUncaughtExceptionHandler((thread,error)->{
            try{getSharedPreferences("aura",MODE_PRIVATE).edit().putString("lastCrash",Log.getStackTraceString(error)).commit();}catch(Throwable ignored){}
            android.os.Process.killProcess(android.os.Process.myPid());
        });
        getWindow().setStatusBarColor(Color.rgb(4,17,12));
        getWindow().setNavigationBarColor(Color.rgb(4,17,12));
        getWindow().setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_ADJUST_RESIZE);
        web=new WebView(this);web.setBackgroundColor(Color.rgb(4,17,12));
        WebSettings settings=web.getSettings();
        settings.setJavaScriptEnabled(true);
        settings.setDomStorageEnabled(true);
        settings.setDatabaseEnabled(true);
        settings.setAllowFileAccess(false);
        settings.setAllowContentAccess(true);
        settings.setMediaPlaybackRequiresUserGesture(false);
        settings.setDefaultTextEncodingName("UTF-8");
        web.addJavascriptInterface(new Bridge(),"AURA_ANDROID");
        web.setWebViewClient(new WebViewClient(){
            @Override public boolean shouldOverrideUrlLoading(WebView view,WebResourceRequest req){
                Uri url=req.getUrl();
                if("aura.android.local".equals(url.getHost())&&"https".equals(url.getScheme()))return false;
                if("https".equals(url.getScheme())){
                    try{startActivity(new Intent(Intent.ACTION_VIEW,url));}catch(Exception e){Log.w(TAG,"External link",e);}
                }
                return true;
            }
            @Override public WebResourceResponse shouldInterceptRequest(WebView view,WebResourceRequest req){
                Uri u=req.getUrl();
                // No remote JS receives the native bridge. AURA is offline by design.
                if(!"aura.android.local".equals(u.getHost()))
                    return new WebResourceResponse("text/plain","UTF-8",403,"Offline",new java.util.HashMap<>(),new java.io.ByteArrayInputStream(new byte[0]));
                String path=u.getPath();
                if(!"/index.html".equals(path) && !"/classic.html".equals(path) && !"/native-ui.js".equals(path))return new WebResourceResponse("text/plain","UTF-8",403,"Forbidden",new java.util.HashMap<>(),new java.io.ByteArrayInputStream(new byte[0]));
                try{
                    InputStream content=getAssets().open("/native-ui.js".equals(path)?"native-ui.js":("/classic.html".equals(path)?"aura.html":"aura-fast.html"));
                    return new WebResourceResponse("/native-ui.js".equals(path)?"application/javascript":"text/html","UTF-8",content);
                }catch(Exception e){Log.e(TAG,"Asset load failed",e);return new WebResourceResponse("text/plain","UTF-8",new java.io.ByteArrayInputStream(e.toString().getBytes(StandardCharsets.UTF_8)));}
            }
            @Override public void onPageFinished(WebView view,String url){
                loaded=true;
                // Keep the original HTML unchanged: the native controls are a separate, auditable layer.
                if(url!=null && url.endsWith("/classic.html")){
                    view.evaluateJavascript("(function(){var b=document.createElement('button');b.textContent='← Voltar ao Android';b.style='position:fixed;top:8px;right:8px;z-index:99999;background:#0a7647;color:#fff;border:1px solid #5f9;border-radius:10px;padding:10px';b.onclick=function(){location.href='/index.html'};document.body.appendChild(b)})();",null);
                }else{
                    view.evaluateJavascript("(function(){var s=document.createElement('script');s.src='/native-ui.js';document.body.appendChild(s);})();",null);
                }
            }
        });
        web.setWebChromeClient(new WebChromeClient(){
            @Override public boolean onShowFileChooser(WebView v,android.webkit.ValueCallback<Uri[]> result,FileChooserParams params){
                if(webFileResult!=null)webFileResult.onReceiveValue(null);
                webFileResult=result;
                // Web file chooser belongs exclusively to explicit CLASSIC mode.
                // The Android Native picker is invoked by AURA_ANDROID.pick().
                nativeFileSelect=false;
                boolean audio=false;
                for(String a:params.getAcceptTypes())if(a!=null&&(a.contains("audio")||a.contains(".mp3")||a.contains(".wav")))audio=true;
                openPicker(audio,params.getMode()==FileChooserParams.MODE_OPEN_MULTIPLE);
                return true;
            }
            @Override public boolean onConsoleMessage(ConsoleMessage m){
                if(m.messageLevel()==ConsoleMessage.MessageLevel.ERROR)Log.e(TAG,"Web UI: "+m.message()+" @"+m.lineNumber());
                return true;
            }
        });
        setContentView(web);
        // Seed the legacy preferences before its bundled JS initializes.
        // The original ONNX Web pipeline must not compete with native MediaCodec.
        web.loadUrl(APP_URL);
    }
    private void openPicker(boolean music,boolean multiple){
        Intent i=new Intent(Intent.ACTION_OPEN_DOCUMENT);
        i.addCategory(Intent.CATEGORY_OPENABLE);i.setType(music?"audio/*":"*/*");
        i.putExtra(Intent.EXTRA_ALLOW_MULTIPLE,multiple);
        i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION|Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION);
        try{startActivityForResult(i,PICK_AUDIO);}catch(Exception e){
            if(webFileResult!=null){webFileResult.onReceiveValue(null);webFileResult=null;}
            alert("Seletor de músicas",e.toString());
        }
    }
    @Override protected void onActivityResult(int request,int result,Intent data){
        super.onActivityResult(request,result,data);
        if(request==SAVE_MASTER){
            if(result==RESULT_OK&&data!=null&&data.getData()!=null){
                Uri out=data.getData();
                new Thread(()->{
                    String path=getSharedPreferences("aura",MODE_PRIVATE).getString("lastMaster","");
                    try(java.io.InputStream in=new java.io.FileInputStream(new File(path));
                        java.io.OutputStream dest=getContentResolver().openOutputStream(out)){
                        if(dest==null)throw new java.io.IOException("Não foi possível salvar o master");
                        byte[] block=new byte[65536];int n;
                        while((n=in.read(block))>=0)dest.write(block,0,n);
                        status("Master WAV salvo no destino escolhido.");
                    }catch(Exception e){status("Não foi possível exportar o master: "+e);}
                },"AURA-master-export").start();
            }
            return;
        }
        if(request!=PICK_AUDIO)return;
        ArrayList<Uri> list=new ArrayList<>();
        if(result==RESULT_OK && data!=null){
            ClipData clip=data.getClipData();
            if(clip!=null){for(int i=0;i<clip.getItemCount();i++)list.add(clip.getItemAt(i).getUri());}
            else if(data.getData()!=null)list.add(data.getData());
        }
        if(nativeFileSelect && !list.isEmpty()){
            cancelPreparation();
            if(AudioService.isPlaying()||QuickMixService.isPlaying()){stopNative();}
            musicUris.clear();musicUris.addAll(list);
            selectedNames.clear();for(Uri u:list)selectedNames.add(trackName(u));
            selectedCount=list.size();decodedCount=0;playIndex=0;decodeFailures="";
            for(Uri u:list)try{getContentResolver().takePersistableUriPermission(u,Intent.FLAG_GRANT_READ_URI_PERMISSION);}catch(Exception ignored){}
            preparedStyle=0;preparedBeats=16;ready.clear();
            status("Importadas "+list.size()+" faixas. Toque em AutoDJ para preparar e reproduzir.");
        }
        // Native picker results MUST NOT also enter HTML's FileList. Doing so
        // launches 2 independent decoders and the broken ONNX worker.
        if(webFileResult!=null){webFileResult.onReceiveValue(nativeFileSelect||list.isEmpty()?null:list.toArray(new Uri[0]));webFileResult=null;}
        nativeFileSelect=false;
    }
    private void cancelPreparation(){
        prepVersion.incrementAndGet();
        Thread t=preparationThread;if(t!=null)t.interrupt();
        preparing=false;
    }
    private void pickNative(){
        if(preparing){status("Análise PCM experimental em andamento: "+decodedCount+"/"+selectedCount+". Use Parar para cancelar.");return;}
        nativeFileSelect=true;
        if(webFileResult!=null){webFileResult.onReceiveValue(null);webFileResult=null;}
        openPicker(true,true);
    }
    private void clearNative(){
        cancelPreparation();stopNative();
        musicUris.clear();selectedNames.clear();selectedCount=0;decodedCount=0;
        synchronized(ready){ready.clear();}
        status("Biblioteca limpa. Adicione músicas.");
    }
    private String trackName(Uri uri){
        try(android.database.Cursor c=getContentResolver().query(uri,new String[]{OpenableColumns.DISPLAY_NAME},null,null,null)){
            if(c!=null&&c.moveToFirst())return c.getString(0);
        }catch(Exception ignored){}
        return uri.getLastPathSegment()==null?"Música":uri.getLastPathSegment();
    }
    private void status(String s){getSharedPreferences("aura",MODE_PRIVATE).edit().putString("status",s).apply();}
    private String status(){return getSharedPreferences("aura",MODE_PRIVATE).getString("status","AURA Android nativo pronto");}
    private void alert(String title,String msg){main.post(()->new AlertDialog.Builder(this).setTitle(title).setMessage(msg).setPositiveButton("OK",null).show());}
    private void startNative(String style,String beats){
        // AURA 11: default to asynchronous source-URI playback; do not hold
        // the Play button hostage to full PCM decoding of eight songs.
        if(musicUris.isEmpty()){
            status("Selecione músicas em + Músicas antes de iniciar o DJ.");return;
        }
        cancelPreparation();
        if(AudioService.isPlaying())stopStudio();
        preparedStyle=styleIndex(style);
        try{preparedBeats=Integer.parseInt(beats);}catch(Exception ex){preparedBeats=0;}
        org.json.JSONArray uris=new org.json.JSONArray(),names=new org.json.JSONArray();
        for(int i=0;i<musicUris.size();i++){uris.put(musicUris.get(i).toString());names.put(selectedNames.get(i));}
        getSharedPreferences("aura",MODE_PRIVATE).edit()
            .putString("fastUris",uris.toString()).putString("fastNames",names.toString()).apply();
        Intent fast=new Intent(this,QuickMixService.class).setAction(QuickMixService.START);
        fast.putExtra("style",preparedStyle).putExtra("beats",preparedBeats);
        try{
            if(Build.VERSION.SDK_INT>=26)startForegroundService(fast);else startService(fast);
            status("Iniciando som diretamente dos arquivos; sem esperar análises.");
        }catch(Exception ex){status("Falha ao iniciar motor imediato: "+ex);Log.e(TAG,"Fast start",ex);}
    }
    // Advanced legacy DSP path retained for experiments, not the startup default.
    private void startStudio(String style,String beats){
        if(preparing)return;
        if(musicUris.isEmpty()){
            status("Importe músicas usando + Músicas antes de iniciar o motor Android.");return;
        }
        preparedStyle=styleIndex(style);
        try{preparedBeats=Integer.parseInt(beats);}catch(Exception ex){preparedBeats=16;}
        if(!ready.isEmpty() && ready.size()==musicUris.size()){
            begin();return;
        }
        preparing=true;decodedCount=0;
        int version=prepVersion.incrementAndGet();
        status("Preparando 1/"+musicUris.size()+" no Android. Aguarde a primeira faixa.");
        ArrayList<Uri> selected=new ArrayList<>(musicUris);
        preparationThread=new Thread(()->prepare(selected,version),"AURA10-native-preparation");
        preparationThread.start();
    }
    private int styleIndex(String s){
        switch(s){
            case "smooth":return 1;case "linear":return 2;case "s-curve":return 3;
            case "focus":return 4;case "dj":return 5;case "early":return 6;case "late":return 7;
            default:return 0;
        }
    }
    private void prepare(List<Uri> list,int version){
        ArrayList<TrackData> tmp=new ArrayList<>();
        StringBuilder failures=new StringBuilder();boolean started=false;
        try{
            File dir=new File(getFilesDir(),"tracks-native");dir.mkdirs();
            for(int i=0;i<list.size();i++){
                if(version!=prepVersion.get()||Thread.currentThread().isInterrupted())return;
                Uri u=list.get(i);String name=trackName(u);int seq=i+1;
                status("Decodificando "+seq+"/"+list.size()+": "+name);
                try{
                    // Each file is decoded on disk only once by MediaCodec.
                    File file=new File(dir,String.format(Locale.ROOT,"mix-%04d.pcm",i));
                    AudioDecoder.Result decoded=AudioDecoder.decode(this,u,file,frames->{
                        if(version!=prepVersion.get())Thread.currentThread().interrupt();
                        if(version==prepVersion.get())status("Decodificando "+seq+"/"+list.size()+" · "+String.format(Locale.ROOT,"%.1f",frames/1_000_000.0)+" M amostras: "+name);
                    });
                    if(version!=prepVersion.get()||Thread.currentThread().isInterrupted())return;
                    status("Medindo batidas "+seq+"/"+list.size()+": "+name);
                    BeatAnalyzer.Result head=BeatAnalyzer.analyze(file,decoded.sampleRate);
                    double tailStart=Math.max(0,decoded.frames/(double)decoded.sampleRate-44);
                    BeatAnalyzer.Result tail=BeatAnalyzer.analyzeRange(file,decoded.sampleRate,tailStart,42);
                    TrackData prepared=new TrackData(name,file,decoded.sampleRate,decoded.frames,
                          head.bpm,head.confidence,head.phase,head.rms,
                          tail.bpm,tail.confidence,tail.phase,tailStart,
                          BeatAnalyzer.firstAudible(file,decoded.sampleRate));
                    tmp.add(prepared);
                    decodedCount=tmp.size();
                    synchronized(ready){ready.clear();ready.addAll(tmp);}
                    // Update an atomic playlist after each track: playback starts after two.
                    SessionStore.save(this,tmp,preparedStyle,preparedBeats);
                    status("DSP pronto "+decodedCount+"/"+list.size()+": "+name);
                    if(!started && tmp.size()>=Math.min(2,list.size())){
                        started=true;
                        main.post(()->{if(version==prepVersion.get())begin();});
                    }
                }catch(Throwable e){
                    if(Thread.currentThread().isInterrupted())return;
                    failures.append(name).append(": ").append(e.getMessage()).append("; ");
                    decodeFailures=failures.toString();
                    Log.w(TAG,"Decode/analysis failed",e);
                    status("Arquivo recusado ("+seq+"/"+list.size()+"): "+name+" · "+e.getClass().getSimpleName());
                }
            }
            if(version!=prepVersion.get())return;
            if(!started && !tmp.isEmpty()){
                started=true;
                main.post(()->{if(version==prepVersion.get())begin();});
            }
            if(tmp.isEmpty())status("Nenhuma música decodificada: "+failures);
            else if(failures.length()>0)status("Prontas "+tmp.size()+"/"+list.size()+" · falhas: "+failures);
            else if(!AudioService.isPlaying())status("Prontas "+tmp.size()+" músicas. Toque em AutoDJ.");
        }catch(Throwable t){status("Falha de preparação: "+t);Log.e(TAG,"Native preparation",t);}
        finally{if(version==prepVersion.get()){preparing=false;preparationThread=null;}}
    }
    private void begin(){
        try{
            List<TrackData> list;
            synchronized(ready){list=new ArrayList<>(ready);}
            if(list.isEmpty())return;
            SessionStore.save(this,list,preparedStyle,preparedBeats);
            Intent s=new Intent(this,AudioService.class);s.setAction(AudioService.START);
            if(Build.VERSION.SDK_INT>=26)startForegroundService(s);else startService(s);
            status("Iniciando mixagem AURA nativa…");
        }catch(Exception e){status("Falha ao iniciar: "+e);Log.e(TAG,"Start failed",e);}
    }
    private void stopStudio(){Intent s=new Intent(this,AudioService.class).setAction(AudioService.STOP);startService(s);}
    private void stopNative(){
        cancelPreparation();
        if(QuickMixService.isPlaying())startService(new Intent(this,QuickMixService.class).setAction(QuickMixService.STOP));
        if(AudioService.isPlaying())stopStudio();status("AURA Android: reprodução parada.");
    }
    private void pauseNative(){
        if(QuickMixService.isPlaying())startService(new Intent(this,QuickMixService.class).setAction(QuickMixService.PAUSE));
        if(AudioService.isPlaying())startService(new Intent(this,AudioService.class).setAction(AudioService.PAUSE));
    }
    private void resumeNative(){
        if(QuickMixService.isPlaying())startService(new Intent(this,QuickMixService.class).setAction(QuickMixService.RESUME));
        if(AudioService.isPlaying())startService(new Intent(this,AudioService.class).setAction(AudioService.RESUME));
    }
    private void nextNative(){
        if(QuickMixService.isPlaying())startService(new Intent(this,QuickMixService.class).setAction(QuickMixService.NEXT));
        if(AudioService.isPlaying())startService(new Intent(this,AudioService.class).setAction(AudioService.NEXT));
    }
    private void toggleRecord(boolean requested){
        if(QuickMixService.isPlaying()){
            status("Gravação WAV não disponível no modo rápido. Use Estúdio PCM experimental para gravar.");return;
        }
        getSharedPreferences("aura",MODE_PRIVATE).edit().putBoolean("recordRequested",requested).apply();
        Intent s=new Intent(this,AudioService.class);
        s.setAction(requested?AudioService.RECORD:AudioService.RECORD_OFF);
        startService(s);
        status(requested?"Gravação WAV solicitada":"Gravação WAV interrompida");
    }
    private void testAudio(){
        if(AudioService.isPlaying()){status("Pausar a reprodução antes de testar a saída.");return;}
        Intent s=new Intent(this,AudioService.class);s.setAction(AudioService.SELFTEST);
        try{startService(s);}catch(Exception e){status("Falha ao solicitar teste de som: "+e);}
    }
    private void exportMaster(){
        String path=getSharedPreferences("aura",MODE_PRIVATE).getString("lastMaster","");
        if(path.isEmpty()||!new File(path).exists()){alert("Master WAV","Nenhum master foi gravado ainda.");return;}
        Intent i=new Intent(Intent.ACTION_CREATE_DOCUMENT);
        i.addCategory(Intent.CATEGORY_OPENABLE);i.setType("audio/wav");
        i.putExtra(Intent.EXTRA_TITLE,"Edgard-AURA-Master.wav");
        startActivityForResult(i,SAVE_MASTER);
    }
    private void diagnostics(){
        String info="AURA 10 · Android "+Build.VERSION.RELEASE+" (SDK "+Build.VERSION.SDK_INT+")\n"+
         "Faixas selecionadas: "+selectedCount+"\nPCM decodificadas: "+decodedCount+"\nMotor rápido: "+QuickMixService.isPlaying()+"\nMotor PCM: "+AudioService.isPlaying()+"\n"+
         "Status: "+status()+"\nErros nos arquivos: "+(decodeFailures.isEmpty()?"nenhum":decodeFailures)+"\nÚltima exceção: "+getSharedPreferences("aura",MODE_PRIVATE).getString("lastCrash","nenhuma");
        main.post(()->new AlertDialog.Builder(this).setTitle("AURA Diagnóstico Android").setMessage(info)
         .setPositiveButton("Copiar",(d,w)->{
             ClipboardManager c=(ClipboardManager)getSystemService(CLIPBOARD_SERVICE);
             if(c!=null)c.setPrimaryClip(ClipData.newPlainText("AURA Android diagnóstico",info));
         }).setNegativeButton("Fechar",null).show());
    }
    private String snapshot(){
        JSONObject root=new JSONObject();
        try{
            root.put("status",status());root.put("busy",preparing);
            root.put("selected",selectedCount);root.put("decoded",decodedCount);
            root.put("playing",QuickMixService.isPlaying()||AudioService.isPlaying());root.put("quick",QuickMixService.isPlaying());
            JSONArray names=new JSONArray();for(String name:new ArrayList<>(selectedNames))names.put(name);
            root.put("names",names);
            JSONArray done=new JSONArray();synchronized(ready){for(TrackData t:ready){
                JSONObject o=new JSONObject();o.put("name",t.title).put("bpm",Math.round(t.bpm*10)/10.0)
                    .put("confidence",t.confidence).put("seconds",t.duration());done.put(o);
            }}root.put("tracks",done);
            android.content.SharedPreferences p=getSharedPreferences("aura",MODE_PRIVATE);
            root.put("index",p.getInt("dj_index",0));root.put("time",p.getFloat("dj_time",0));
            root.put("next",p.getString("dj_next",""));root.put("mode",p.getString("dj_mode","idle"));
            root.put("lastCrash",p.getString("lastCrash",""));
        }catch(Exception e){Log.w(TAG,"Snapshot",e);}
        return root.toString();
    }
    public final class Bridge {
        @JavascriptInterface public String snapshot(){return MainActivity.this.snapshot();}
        @JavascriptInterface public void pick(){main.post(()->pickNative());}
        @JavascriptInterface public void clear(){main.post(()->clearNative());}
        @JavascriptInterface public void start(String style,String beats){main.post(()->startNative(style,beats));}
        @JavascriptInterface public void studio(String style,String beats){main.post(()->startStudio(style,beats));}
        @JavascriptInterface public void stop(){main.post(()->stopNative());}
        @JavascriptInterface public void pause(){main.post(()->pauseNative());}
        @JavascriptInterface public void resume(){main.post(()->resumeNative());}
        @JavascriptInterface public void next(){main.post(()->nextNative());}
        @JavascriptInterface public void diagnostic(){diagnostics();}
        @JavascriptInterface public void record(boolean enabled){main.post(()->toggleRecord(enabled));}
        @JavascriptInterface public void testAudio(){main.post(()->MainActivity.this.testAudio());}
        @JavascriptInterface public void saveMaster(){main.post(()->exportMaster());}
        @JavascriptInterface public String status(){return MainActivity.this.status();}
        @JavascriptInterface public int count(){return musicUris.size();}
        @JavascriptInterface public boolean busy(){return preparing;}
    }
    @Override public void onBackPressed(){if(web!=null&&web.canGoBack()){web.goBack();}else super.onBackPressed();}
    @Override protected void onDestroy(){cancelPreparation();if(web!=null){web.removeJavascriptInterface("AURA_ANDROID");web.destroy();web=null;}super.onDestroy();}
}
