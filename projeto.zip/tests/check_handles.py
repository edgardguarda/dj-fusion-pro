#!/usr/bin/env python3
"""Proíbe tratar identificadores nativos (ponteiros) como positivos.

No ARM com Android 11+, ponteiros têm uma etiqueta no byte mais alto (Top-Byte Ignore / Memory Tagging): convertidos
para Long podem ser NEGATIVOS. Só 0 e -1 são códigos especiais. Este teste falha se o Kotlin comparar um
identificador de faixa/construtor com > 0 ou <= 0.
"""
import pathlib
import re
import sys

root = pathlib.Path(__file__).resolve().parent.parent / "app/src/main/java"
bad = []
pat = re.compile(r"\b(h|handle|builder|trackHandle|pending)\s*(>|<=|<|>=)\s*0L?\b")
for f in root.rglob("*.kt"):
    for n, line in enumerate(f.read_text(encoding="utf-8").splitlines(), 1):
        if pat.search(line):
            bad.append(f"{f.relative_to(root)}:{n}: {line.strip()}")
if bad:
    print("Identificador nativo comparado como número positivo (quebra no ARM):")
    print("\n".join(bad))
    sys.exit(1)
print("identificadores nativos: nenhuma comparação com > 0 / <= 0")
