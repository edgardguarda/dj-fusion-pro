import app.djfusion.audio.NativeEngine;
import java.nio.*;
public class JniSmoke {
  static int fails = 0;
  static void check(boolean ok, String what) { System.out.println((ok ? "  ok     " : "  FALHOU ") + what); if (!ok) fails++; }
  static long buildTrack(int rate, int seconds, double hz, boolean asFloat) {
    long h = NativeEngine.nativeBeginTrack(rate, 48000L * 900);
    int total = rate * seconds, chunk = 4410;
    ByteBuffer bb = ByteBuffer.allocateDirect(chunk * 2 * (asFloat ? 4 : 2)).order(ByteOrder.nativeOrder());
    for (int pos = 0; pos < total; pos += chunk) {
      int n = Math.min(chunk, total - pos); bb.clear();
      for (int i = 0; i < n; i++) {
        double v = 0.6 * Math.sin(2 * Math.PI * hz * (pos + i) / rate);
        for (int c = 0; c < 2; c++) { if (asFloat) bb.putFloat((float) v); else bb.putShort((short) (v * 32767)); }
      }
      NativeEngine.nativeAppend(h, bb, 0, n * 2 * (asFloat ? 4 : 2), 2, asFloat);
    }
    return NativeEngine.nativeFinishTrack(h);
  }
  public static void main(String[] a) throws Exception {
    check(NativeEngine.nativeStart(), "nativeStart abre o fluxo");
    int[] info = new int[8]; NativeEngine.nativeStreamInfo(info);
    check(info[0] == 48000, "taxa do fluxo = " + info[0]);

    long t = buildTrack(44100, 2, 440, false);
    check(t > 0, "faixa PCM16 44,1 kHz construída");
    long frames = NativeEngine.nativeTrackFrames(t);
    check(Math.abs(frames - 96000) <= 2, "quadros após reamostrar = " + frames + " (esperado 96000)");
    byte[] peaks = NativeEngine.nativeTrackPeaks(t);
    check(peaks.length >= 3 * 299, "picos da waveform: " + peaks.length + " bytes");
    check(NativeEngine.nativeLoad(0, t), "carregar no deck A");
    long t2 = buildTrack(48000, 1, 330, true);
    check(t2 > 0 && NativeEngine.nativeLoad(1, t2), "faixa float 48 kHz no deck B");

    NativeEngine.nativeSetCrossfader(0f); NativeEngine.nativeSetMaster(1f); NativeEngine.nativeSetVolume(0, 1f);
    Thread.sleep(300);
    long[] st = new long[4]; NativeEngine.nativeDeckState(0, st);
    check((st[0] & 1) == 1 && (st[0] & 2) == 0 && st[3] == frames, "estado: carregada, parada, tamanho certo");
    NativeEngine.nativePlay(0); Thread.sleep(500);
    NativeEngine.nativeDeckState(0, st);
    check((st[0] & 2) == 2, "tocando");
    check(st[1] > 10000 && st[1] < 30000, "posição avança (~0,5 s): " + st[1]);
    float peak = NativeEngine.nativeMasterPeak();
    check(peak > 0.4f && peak <= 1f, "nível master com a música = " + peak);
    check(NativeEngine.nativeDeckPeak(0) > 0.4f, "nível do deck A");
    NativeEngine.nativeSetCrossfader(1f); Thread.sleep(1100);
    check(NativeEngine.nativeMasterPeak() < 0.05f, "crossfader todo para B (parado): master fica quase mudo (medidor cai em ~0,8 s)");
    NativeEngine.nativePause(0); NativeEngine.nativeSeek(0, 50000); Thread.sleep(150);
    NativeEngine.nativeDeckState(0, st);
    check(!((st[0] & 2) == 2) && st[1] == 50000, "pausa + busca para 50000 = " + st[1]);
    NativeEngine.nativeCue(0); Thread.sleep(100); NativeEngine.nativeDeckState(0, st);
    check(st[2] == 50000, "cue gravado nessa posição");

    // EQ, filtro, velocidade, loop e análise de BPM pela ponte
    NativeEngine.nativeSetRate(0, 1.05f); NativeEngine.nativeSetEq(0, 0, 0.2f); NativeEngine.nativeSetEq(0, 2, 0.9f);
    NativeEngine.nativeSetFilter(0, 0.3f); NativeEngine.nativeSetFx(0, 1, 0.5f, 0.5f); NativeEngine.nativeSetLoop(0, 1000, 5000); NativeEngine.nativeClearLoop(0);
    NativeEngine.nativeSetEq(9, 0, 1f); NativeEngine.nativeSetEq(0, 7, 1f);  // inválidos: ignorados
    NativeEngine.nativePlay(0); Thread.sleep(200); NativeEngine.nativePause(0);
    // key-lock, scratch, fone e saída 4 canais pela ponte
    NativeEngine.nativeSetKeyLock(0, true); NativeEngine.nativeSetRate(0, 1.1f);
    NativeEngine.nativePlay(0); Thread.sleep(200);
    check(NativeEngine.nativeMasterPeak() >= 0f, "key-lock ligado sem erro");
    NativeEngine.nativeSetKeyLock(0, false); NativeEngine.nativePause(0); Thread.sleep(100);
    NativeEngine.nativeSeek(0, 20000); Thread.sleep(100);
    NativeEngine.nativeScratch(0, true, 1.0f); Thread.sleep(300);
    NativeEngine.nativeDeckState(0, st);
    check(st[1] > 20000 + 4000, "scratch move a posição com o deck parado: " + st[1]);
    NativeEngine.nativeScratch(0, false, 0f); Thread.sleep(100);
    NativeEngine.nativeSetHeadphoneCue(0, true); NativeEngine.nativeSetHeadphoneLevel(0.8f); NativeEngine.nativeSetHeadphoneMix(0.3f);
    NativeEngine.nativeConfigureOutput(2, 7, 0, 0); Thread.sleep(200);
    NativeEngine.nativeStreamInfo(info);
    check(info[4] == 4 && info[5] == 2, "saída 4 canais aberta: canais=" + info[4] + " modo=" + info[5]);
    NativeEngine.nativePlay(0); Thread.sleep(200); NativeEngine.nativePause(0);
    NativeEngine.nativeConfigureOutput(1, 0, 0, 0); Thread.sleep(200);
    NativeEngine.nativeStreamInfo(info);
    check(info[4] == 2 && info[5] == 1, "modo dividido em 2 canais: canais=" + info[4] + " modo=" + info[5]);
    NativeEngine.nativeConfigureOutput(0, 5, 0, 0); Thread.sleep(200);
    NativeEngine.nativeStreamInfo(info);
    check(info[5] == 0 && info[6] == 5, "modo normal no aparelho escolhido: aparelho=" + info[6]);
    // segunda saída tocando junto (som geral espelhado)
    NativeEngine.nativeConfigureOutput(2, 7, 9, 0); NativeEngine.nativePlay(0); Thread.sleep(400);
    NativeEngine.nativeStreamInfo(info);
    check(info[7] == 1 && info[6] == 7, "segunda saída ligada: " + info[7]);
    NativeEngine.nativeConfigureOutput(0, 7, 7, 1); Thread.sleep(200);
    NativeEngine.nativeStreamInfo(info);
    check(info[7] == 0, "segunda saída no mesmo aparelho é ignorada");
    NativeEngine.nativePause(0);
    NativeEngine.nativeConfigureOutput(0, 0, 0, 0); Thread.sleep(200);
    NativeEngine.nativeStreamInfo(info);
    check(info[5] == 0 && info[7] == 0, "volta ao modo normal");
    NativeEngine.nativeSetHeadphoneCue(0, false);
    double[] bpm = new double[3];
    NativeEngine.nativeAnalyze(t, bpm);
    check(bpm[0] == 0, "faixa sem pulso (tom puro curto) não ganha andamento falso: " + bpm[0]);
    NativeEngine.nativeAnalyze(0, bpm);
    check(bpm[0] == 0 && bpm[1] == 0, "analisar faixa inexistente devolve zeros");

    long big = NativeEngine.nativeBeginTrack(44100, 1000);
    ByteBuffer bb = ByteBuffer.allocateDirect(44100 * 2 * 2).order(ByteOrder.nativeOrder());
    for (int i = 0; i < 44100 * 2; i++) bb.putShort((short) 1000);
    NativeEngine.nativeAppend(big, bb, 0, 44100 * 2 * 2, 2, false);
    check(NativeEngine.nativeBuilderTooLong(big), "limite de tamanho detectado");
    check(NativeEngine.nativeFinishTrack(big) == -1, "faixa longa demais devolve -1");
    check(NativeEngine.nativeBeginTrack(100, 1000) == 0, "taxa inválida recusada");
    long abort = NativeEngine.nativeBeginTrack(44100, 100000); NativeEngine.nativeAbortTrack(abort);

    // tom, amostras e partida sincronizada pela ponte
    int[] kout = new int[4]; NativeEngine.nativeAnalyzeKey(t, kout);
    check(kout[0] == 0 || kout[0] == 1, "análise de tom devolve resposta válida/inválida sem erro");
    NativeEngine.nativeAnalyzeKey(0, kout);
    check(kout[0] == 0, "tom de faixa inexistente = inválido");
    long[] sinfo = new long[12];
    int ns = NativeEngine.nativeBuildSamples(0, 0.0, 0L, 0, sinfo);
    check(ns >= 0 && ns <= 4, "amostras do deck A: " + ns);
    if (ns > 0) {
      NativeEngine.nativeSetSamplerVolume(0.8f);
      NativeEngine.nativeTriggerSample(0, false); Thread.sleep(100);
      int mask = NativeEngine.nativeSamplerMask();
      check(mask >= 0, "máscara de pads lida: " + mask);
      NativeEngine.nativeStopSample(0);
    }
    NativeEngine.nativeTriggerSample(7, true); NativeEngine.nativeStopSample(99); // vazio/inválido: ignorado
    check(NativeEngine.nativeLoadBuiltinSamples() == 8, "8 sons prontos nos pads");
    NativeEngine.nativeTriggerSample(0, false); Thread.sleep(100);
    check((NativeEngine.nativeSamplerMask() & 1) == 1, "buzina tocando no pad 1");
    NativeEngine.nativeClearSamples(); Thread.sleep(150);
    check(NativeEngine.nativeSamplerMask() == 0, "limpar amostras zera a máscara");
    NativeEngine.nativePlaySynced(1, 0, 0.0, 22050.0, 0.0, 22050.0, 0.0); Thread.sleep(150);
    NativeEngine.nativeDeckState(1, st);
    check((st[0] & 2) == 2, "partida sincronizada coloca o deck B para tocar");
    NativeEngine.nativePause(1);

    // gravação do set e energia
    String wav = System.getProperty("java.io.tmpdir") + "/djf_rec_test.wav";
    check(NativeEngine.nativeRecordStart(wav), "gravação começa");
    check(!NativeEngine.nativeRecordStart(wav), "segunda gravação ao mesmo tempo é recusada");
    NativeEngine.nativePlay(0); Thread.sleep(400);
    long recFrames = NativeEngine.nativeRecordStop();
    NativeEngine.nativePause(0);
    long fileLen = new java.io.File(wav).length();
    check(recFrames > 4800 && fileLen == 44 + recFrames * 4, "WAV gravado: " + recFrames + " quadros, " + fileLen + " bytes");
    check(NativeEngine.nativeRecordStop() == -1, "parar sem gravar devolve -1");
    float en = NativeEngine.nativeAnalyzeEnergy(t);
    check(en <= 1f, "energia pela ponte: " + en);
    NativeEngine.nativeSetSampleSpeed(0, 1.5f); NativeEngine.nativeTriggerSampleAt(0, false, 4800);
    // decodificador próprio pela ponte (MP3 de verdade do teste)
    try (java.io.RandomAccessFile raf = new java.io.RandomAccessFile(System.getProperty("djf.mp3"), "r")) {
      java.io.FileDescriptor jfd = raf.getFD();
      java.lang.reflect.Field ff = java.io.FileDescriptor.class.getDeclaredField("fd"); ff.setAccessible(true);
      int fdNum = ff.getInt(jfd);
      long h = NativeEngine.nativeDecodeFd(fdNum, 1, raf.length(), 0);
      check(h > 0, "MP3 decodificado pelo decodificador próprio: " + NativeEngine.nativeDecodeError(0));
      check(NativeEngine.nativeTrackFrames(h) > 48000L * 39, "MP3 com 40 s: " + NativeEngine.nativeTrackFrames(h));
      check(NativeEngine.nativeDecodeProgress(0) == 1f, "progresso chegou a 100%");
      NativeEngine.nativeFreeTrack(h);
    }
    check(NativeEngine.nativeDecodeFd(-1, 1, 0, 1) == 0, "descritor inválido recusado");
    check(NativeEngine.nativeDecodeFd(0, 9, 0, 1) == 0, "tipo inválido recusado");
    // stems e tom pela ponte
    check(NativeEngine.nativeStemProgress(0) == 0f, "progresso dos stems começa em 0");
    boolean sep = NativeEngine.nativeSeparateStems(t, 0);
    check(sep && NativeEngine.nativeStemProgress(0) == 1f, "stems separados pela ponte");
    check(NativeEngine.nativeSeparateStems(t, 0), "segunda separação reaproveita");
    check(!NativeEngine.nativeSeparateStems(t, 5) && !NativeEngine.nativeSeparateStems(0L, 0), "deck/faixa inválidos recusados");
    NativeEngine.nativeCancelStems(1); NativeEngine.nativeCancelStems(9);
    NativeEngine.nativeSetStemGain(0, 0, 0f); NativeEngine.nativeSetStemGain(0, 9, 0f);
    NativeEngine.nativeSetKeyShift(0, 2f); NativeEngine.nativePlay(0); Thread.sleep(200);
    NativeEngine.nativeDeckState(0, st);
    check((st[0] & 2) == 2, "deck toca com stem desligado e tom mudado");
    float loud = NativeEngine.nativeAnalyzeLoudness(t);
    check(loud <= 0f && loud > -80f, "volume médio pela ponte: " + loud + " dBFS");
    check(NativeEngine.nativeAnalyzeLoudness(0L) == 0f, "faixa inexistente: 0");
    NativeEngine.nativeSetTrim(0, 0.5f); NativeEngine.nativeSetTrim(7, 2f); NativeEngine.nativeSetTrim(0, 1f);
    NativeEngine.nativePause(0); NativeEngine.nativeSetKeyShift(0, 0f); NativeEngine.nativeSetStemGain(0, 0, 1f);

    NativeEngine.nativeFreeTrack(t); NativeEngine.nativeFreeTrack(t2);
    NativeEngine.nativeUnload(0); Thread.sleep(100); NativeEngine.nativeCollectGarbage();
    NativeEngine.nativeDeckState(0, st);
    check((st[0] & 1) == 0, "descarregar deck A");
    NativeEngine.nativeStop();
    System.out.println(fails == 0 ? "JNI OK" : ("JNI FALHOU: " + fails));
    System.exit(fails == 0 ? 0 : 1);
  }
}
