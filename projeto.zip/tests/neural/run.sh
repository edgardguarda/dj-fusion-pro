#!/bin/bash
# Testa a parte de sinal da IA dos stems (STFT, máscaras, reamostragem, blocos) com uma rede de mentira.
set -e
cd "$(dirname "$0")"
mkdir -p /tmp/djf-neural
javac -d /tmp/djf-neural ../../app/src/main/java/app/djfusion/audio/SpleeterCore.java SpleeterCoreTest.java
java -cp /tmp/djf-neural SpleeterCoreTest
