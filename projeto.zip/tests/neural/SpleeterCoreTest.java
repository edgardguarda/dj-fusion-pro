import app.djfusion.audio.SpleeterCore;
public class SpleeterCoreTest {
  public static void main(String[] a) throws Exception {
    for (int rate : new int[]{44100, 48000}) run(rate);
  }
  static void run(int rate) throws Exception {
    final int secs = 30; final int frames = rate * secs;
    final short[] pcm = new short[frames * 2];
    double[] fr = rate == 44100 ? new double[]{500, 4000, 8000} : new double[]{500, 4000, 7000};
    for (int i = 0; i < frames; i++) {
      double t = (double) i / rate;
      double l = 0.2*Math.sin(2*Math.PI*fr[0]*t) + 0.15*Math.sin(2*Math.PI*fr[1]*t) + 0.1*Math.sin(2*Math.PI*fr[2]*t);
      double r = 0.2*Math.sin(2*Math.PI*fr[0]*t) + 0.15*Math.sin(2*Math.PI*fr[1]*t+1) + 0.1*Math.sin(2*Math.PI*fr[2]*t+2);
      pcm[2*i] = (short) Math.round(l*32767); pcm[2*i+1] = (short) Math.round(r*32767);
    }
    SpleeterCore.Source src = (start, count, out) -> {
      for (int i = 0; i < count; i++) { long p = start + i; for (int c = 0; c < 2; c++) out[2*i+c] = (p >= 0 && p < frames) ? pcm[(int)(2*p+c)] : 0; }
    };
    // rede de mentira: stem k fica com as faixas de frequência (bins) do seu terço; resto quase nada
    SpleeterCore.Net net = (in, out) -> {
      for (int i = 0; i < in.length; i++) {
        int b = i % 1024; int band = b < 341 ? 0 : (b < 682 ? 1 : 2);
        for (int k = 0; k < 4; k++) out[k][i] = (k == band) ? in[i] : 1e-4f * in[i] + 1e-9f;
      }
    };
    final short[] st = new short[frames * 6];
    final int[] writes = {0};
    SpleeterCore.Sink sink = (start, count, o) -> { writes[0] += count; System.arraycopy(o, 0, st, (int) start * 6, count * 6); };
    long t0 = System.currentTimeMillis();
    boolean ok = SpleeterCore.separate(src, frames, rate, net, sink, null);
    System.out.println("rate " + rate + " ok=" + ok + " frames escritos=" + writes[0] + "/" + frames + " em " + (System.currentTimeMillis()-t0) + " ms");
    // soma dos 3 stems ~ original em CADA canal (stems estéreo; menos erro da reamostragem)
    double e = 0, ref = 0; double[] en = new double[3];
    for (int i = rate; i < frames - rate; i++) {
      for (int c = 0; c < 2; c++) {
        double x = pcm[2*i+c]; double sum = st[6*i+c] + st[6*i+2+c] + st[6*i+4+c];
        e += (x - sum) * (x - sum); ref += x * x;
        for (int k = 0; k < 3; k++) en[k] += (double) st[6*i+2*k+c] * st[6*i+2*k+c];
      }
    }
    double rel = Math.sqrt(e/ref);
    System.out.printf("erro relativo da soma (E e D separados): %.5f  (energia voz %.3g bateria %.3g baixo %.3g)%n", rel, en[0], en[1], en[2]);
    if (rel > 0.05) throw new RuntimeException("soma dos stems estéreo difere do original: " + rel);
    // tom de cada stem: correlação com seno de frequência alvo
    for (int k = 0; k < 3; k++) {
      double best = 0; int bf = -1;
      for (int f = 0; f < 3; f++) {
        double sc = 0, ss = 0, cs = 0, cc = 0; 
        for (int i = rate; i < frames - rate; i++) { double t = (double) i / rate; double v = st[6*i+2*k+1]; double s = Math.sin(2*Math.PI*fr[f]*t), c = Math.cos(2*Math.PI*fr[f]*t); sc += v*s; cs += v*c; }
        double p = Math.hypot(sc, cs); if (p > best) { best = p; bf = f; }
      }
      System.out.println("stem " + k + " domina a frequência " + fr[bf]);
    }
  }
}
