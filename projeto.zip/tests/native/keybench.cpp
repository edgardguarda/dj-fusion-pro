// Teste difícil de tonalidade: acordes, melodia, bumbo, chimbal em ruído e afinação fora de 440 Hz (0, +25, -30, +45 centésimos). Demora ~4 min.
// g++ -std=c++17 -O2 keybench.cpp -o kb && ./kb   (antes da afinação+picos: 91% exato; depois: 100%)
#include <cstdio>
#include <memory>
#include <random>
#include <cmath>
#include "../../app/src/main/cpp/core/key.h"
using namespace djf;
static const int kSr=48000; static const double kPi=3.14159265358979323846;
static double noteHz(double midi,double cents){return 440.0*std::pow(2.0,(midi-69+cents/100.0)/12.0);}
// música "difícil": acordes, baixo, bumbo, chimbal em ruído, melodia com notas de passagem, detuning
static std::shared_ptr<Track> hard(int tonic,bool minor,int secs,unsigned seed,double cents,double drumAmp){
  auto t=std::make_shared<Track>(); t->sampleRate=kSr; t->frames=(int64_t)kSr*secs; t->pcm.resize(t->frames*2);
  std::mt19937 rng(seed); const int third=minor?3:4; const int roots[4]={0,5,7,0};
  const int scale[7]={0,2,minor?3:4,5,7,minor?8:9,minor?10:11};
  const int64_t chordLen=kSr*2; const double beat=kSr*0.5;
  double melNote=60+tonic; int64_t nextMel=0; 
  for(int64_t i=0;i<t->frames;++i){
    int ch=(int)((i/chordLen)%4); int root=48+tonic+roots[ch];
    double v=0; int notes[3]={root+12,root+12+third,root+12+7};
    for(int n:notes) for(int h=1;h<=4;++h) v+=std::sin(2*kPi*noteHz(n,cents)*h*i/kSr)/(h*1.5);
    v+=0.7*std::sin(2*kPi*noteHz(root,cents)*i/kSr);
    if(i>=nextMel){ int d=rng()%7; melNote=60+tonic+scale[d]+((rng()%5==0)?1:0); nextMel=i+(int64_t)(kSr*0.25*(1+rng()%3)); }
    for(int h=1;h<=3;++h) v+=0.5*std::sin(2*kPi*noteHz(melNote+12,cents)*h*i/kSr)/h;
    double tb=std::fmod((double)i,beat); 
    v+=drumAmp*2.0*std::sin(2*kPi*55*tb/kSr)*std::exp(-tb/(kSr*0.08));
    double th=std::fmod((double)i+beat/2,beat); v+=drumAmp*1.5*((rng()%2001)/1000.0-1.0)*std::exp(-th/(kSr*0.03));
    v+=0.2*((rng()%2001)/1000.0-1.0);
    int16_t s=(int16_t)std::max(-32767.0,std::min(32767.0,v*0.1*32767.0)); t->pcm[2*i]=t->pcm[2*i+1]=s;
  }
  return t;
}
int main(){
  const double cs[]={0,25,-30,45}; int ok=0,tot=0,relOk=0;
  for(double c:cs){ int r=0,n=0,rel=0;
    for(int minor=0;minor<2;++minor)for(int tonic=0;tonic<12;++tonic){
      auto t=hard(tonic,minor==1,50,200+tonic,c,0.8); KeyResult k=analyzeKey(*t); ++n;
      bool exact=k.valid&&k.tonic==tonic&&k.minor==(minor==1);
      // relativa conta como "mesmo número de Camelot"
      int en=0; (void)en;
      bool same=false; if(k.valid){ int a=((k.minor?(k.tonic+3)%12:k.tonic)), b=(minor?(tonic+3)%12:tonic); same=(a==b);} 
      if(exact)++r; if(same)++rel; }
    std::printf("detune %+4.0f cents: exato %d/%d, mesmo número Camelot %d/%d\n",c,r,n,rel,n); ok+=r; tot+=n; relOk+=rel;}
  std::printf("TOTAL exato %d/%d (%.0f%%) Camelot %d/%d\n",ok,tot,100.0*ok/tot,relOk,tot);
}
