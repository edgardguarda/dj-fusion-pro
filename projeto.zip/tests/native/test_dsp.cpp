// Testes do equalizador, filtro, velocidade, loop e detecção de BPM. Compilar com ASan e UBSan.
#include <cmath>
#include <cstdio>
#include <cstdlib>
#include <memory>
#include <random>
#include <vector>

#include "../../app/src/main/cpp/core/bpm.h"
#include "../../app/src/main/cpp/core/engine.h"
#include "../../app/src/main/cpp/core/track.h"

using namespace djf;

static int g_fail = 0, g_checks = 0;
#define CHECK(c) do { ++g_checks; if (!(c)) { ++g_fail; std::printf("  FALHOU %s:%d  %s\n", __FILE__, __LINE__, #c); } } while (0)
#define CHECK_NEAR(a, b, tol) do { ++g_checks; double _a=(a), _b=(b); if (!(std::fabs(_a-_b) <= (tol))) { ++g_fail; std::printf("  FALHOU %s:%d  %s=%g esperado %g (tol %g)\n", __FILE__, __LINE__, #a, _a, _b, (double)(tol)); } } while (0)

static const double kPi = 3.14159265358979323846;
static const int kSr = 48000;

static std::shared_ptr<Track> makeSine(int64_t frames, double hz, float amp) {
  auto t = std::make_shared<Track>();
  t->sampleRate = kSr; t->frames = frames;
  t->pcm.resize(static_cast<size_t>(frames) * 2);
  for (int64_t i = 0; i < frames; ++i) {
    int16_t s = static_cast<int16_t>(amp * 32767.0 * std::sin(2 * kPi * hz * i / kSr));
    t->pcm[2 * i] = s; t->pcm[2 * i + 1] = s;
  }
  return t;
}

static std::vector<float> renderN(Engine& e, int frames, int chunk = 480) {
  std::vector<float> out(static_cast<size_t>(frames) * 2);
  for (int done = 0; done < frames; done += chunk) {
    int n = std::min(chunk, frames - done);
    e.render(&out[static_cast<size_t>(done) * 2], n);
  }
  return out;
}

static double rmsLeft(const std::vector<float>& o, size_t fromFrame) {
  double s = 0; size_t n = 0;
  for (size_t i = fromFrame; i < o.size() / 2; ++i) { s += o[2 * i] * o[2 * i]; ++n; }
  return std::sqrt(s / n);
}

// Toca um tom a 0 dB de referência e devolve o RMS depois de assentar.
struct Rig {
  Engine e{kSr, 480};
  Rig(double hz, int64_t secs = 3) {
    e.loadTrack(0, makeSine(kSr * secs, hz, 0.5f));
    e.setCrossfader(0.f); e.setMaster(1.f);
    renderN(e, 4800);
  }
};
static double dbOf(double ratio) { return 20.0 * std::log10(ratio); }

static double measure(double hz, void (*setup)(Engine&)) {
  Rig r(hz);
  setup(r.e);
  r.e.play(0);
  auto o = renderN(r.e, 48000 * 2);
  return rmsLeft(o, 24000) / (0.5 / std::sqrt(2.0));  // 1 = sem mudança
}

static void testEq() {
  std::printf("equalizador\n");
  for (double hz : {60.0, 1000.0, 9000.0}) {
    const double r = measure(hz, [](Engine&) {});
    CHECK_NEAR(r, 1.0, 0.002);  // neutro não mexe no som
  }
  // neutro é transparente de verdade: mesma saída que a entrada
  {
    Rig r(1000);
    r.e.play(0);
    auto o = renderN(r.e, 9600);
    auto ref = makeSine(kSr * 3, 1000, 0.5f);
    double maxErr = 0;
    for (int i = 200; i < 9600; ++i) maxErr = std::max<double>(maxErr, std::fabs(o[2 * i] - ref->pcm[2 * (i + 4800)] / 32768.0f * 1.0f));
    CHECK(maxErr < 1e-3);
  }
  // cada banda cortada derruba o seu tom e deixa os outros
  CHECK(dbOf(measure(60, [](Engine& e) { e.setEq(0, 0, 0.f); })) < -30);
  CHECK(dbOf(measure(1000, [](Engine& e) { e.setEq(0, 0, 0.f); })) > -3.0);
  CHECK(dbOf(measure(9000, [](Engine& e) { e.setEq(0, 0, 0.f); })) > -0.5);
  CHECK(dbOf(measure(1000, [](Engine& e) { e.setEq(0, 1, 0.f); })) < -20);
  std::printf("  info: 60Hz com médios cortados %.1f dB; 1kHz com agudos cortados %.1f dB\n", dbOf(measure(60, [](Engine& e) { e.setEq(0, 1, 0.f); })), dbOf(measure(1000, [](Engine& e) { e.setEq(0, 2, 0.f); })));
  CHECK(dbOf(measure(60, [](Engine& e) { e.setEq(0, 1, 0.f); })) > -2.0);
  CHECK(dbOf(measure(9000, [](Engine& e) { e.setEq(0, 2, 0.f); })) < -20);
  CHECK(dbOf(measure(1000, [](Engine& e) { e.setEq(0, 2, 0.f); })) > -2.0);
  // máximo é +6 dB na banda
  CHECK_NEAR(dbOf(measure(60, [](Engine& e) { e.setEq(0, 0, 1.f); })), 6.0, 1.0);
  CHECK_NEAR(dbOf(measure(9000, [](Engine& e) { e.setEq(0, 2, 1.f); })), 6.0, 1.0);
  // índices e deck inválidos são ignorados
  Engine e(kSr, 480);
  e.setEq(5, 0, 1.f); e.setEq(0, 9, 1.f); e.setEq(-1, 0, 1.f);
  renderN(e, 960);
}

static void testFilter() {
  std::printf("filtro de DJ\n");
  CHECK_NEAR(measure(1000, [](Engine& e) { e.setFilter(0, 0.5f); }), 1.0, 0.002);
  CHECK_NEAR(measure(1000, [](Engine& e) { e.setFilter(0, 0.51f); }), 1.0, 0.002);  // zona morta central
  CHECK(dbOf(measure(5000, [](Engine& e) { e.setFilter(0, 0.0f); })) < -30);          // passa-baixas fechado
  CHECK(dbOf(measure(60, [](Engine& e) { e.setFilter(0, 0.3f); })) > -3);            // graves passam
  CHECK(dbOf(measure(100, [](Engine& e) { e.setFilter(0, 1.0f); })) < -20);           // passa-altas fechado
  CHECK(dbOf(measure(9000, [](Engine& e) { e.setFilter(0, 0.7f); })) > -3);          // agudos passam
  // sem estouro nem valores inválidos varrendo o botão
  Rig r(220);
  r.e.play(0);
  bool ok = true;
  for (int i = 0; i < 400; ++i) {
    r.e.setFilter(0, static_cast<float>(i % 101) / 100.f);
    r.e.setEq(0, i % 3, static_cast<float>((i * 7) % 101) / 100.f);
    auto o = renderN(r.e, 480);
    for (float v : o) if (!std::isfinite(v) || std::fabs(v) > 1.0f) ok = false;
  }
  CHECK(ok);
}

static int zeroCrossings(const std::vector<float>& o, size_t from) {
  int z = 0;
  for (size_t i = from + 1; i < o.size() / 2; ++i) if (o[2 * (i - 1)] < 0.f && o[2 * i] >= 0.f) ++z;
  return z;
}

static void testRate() {
  std::printf("velocidade (pitch)\n");
  for (float rate : {0.92f, 1.0f, 1.05f, 1.08f}) {
    Rig r(1000, 10);
    r.e.setRate(0, rate);
    r.e.play(0);
    renderN(r.e, 24000);  // assenta a suavização
    const int64_t p0 = r.e.deckInfo(0).positionFrames;
    auto o = renderN(r.e, 48000);
    const int64_t p1 = r.e.deckInfo(0).positionFrames;
    CHECK_NEAR(static_cast<double>(p1 - p0), 48000.0 * rate, 4.0);
    const double hz = zeroCrossings(o, 0);  // em 1 s
    CHECK_NEAR(hz, 1000.0 * rate, 3.0);
    CHECK_NEAR(rmsLeft(o, 0), 0.5 / std::sqrt(2.0), 0.01);  // interpolação não muda o volume
  }
  // limites
  Rig r(1000, 10);
  r.e.setRate(0, 100.f); r.e.play(0); renderN(r.e, 48000);
  CHECK(r.e.deckInfo(0).positionFrames < 48000 * 2 + 5000);  // limitado a 2x
  r.e.setRate(0, -3.f); renderN(r.e, 24000);
  const int64_t a = r.e.deckInfo(0).positionFrames; renderN(r.e, 48000);
  CHECK_NEAR(static_cast<double>(r.e.deckInfo(0).positionFrames - a), 24000.0, 30.0);  // 0,5x
  // fim da faixa com velocidade
  Engine e(kSr, 480);
  e.loadTrack(0, makeSine(48000, 440, 0.3f)); e.setRate(0, 1.5f); e.play(0);
  renderN(e, 48000);
  CHECK(!e.deckInfo(0).playing);
}

static void testLoop() {
  std::printf("loop\n");
  // faixa em que o valor da amostra diz o quadro: rampa 0..1 a cada 10000 quadros
  auto t = std::make_shared<Track>();
  t->sampleRate = kSr; t->frames = kSr * 5; t->pcm.resize(static_cast<size_t>(t->frames) * 2);
  for (int64_t i = 0; i < t->frames; ++i) { int16_t v = static_cast<int16_t>((i % 20000) * 1.5); t->pcm[2*i] = v; t->pcm[2*i+1] = v; }
  Engine e(kSr, 480);
  e.loadTrack(0, t); e.setCrossfader(0.f); e.setMaster(1.f);
  e.setLoop(0, 100000, 100500);  // curto demais? 500 quadros: válido (>=256)
  e.setLoop(1, 10, 20);          // inválido: ignorado
  e.seekFrames(0, 99000);
  e.play(0);
  renderN(e, 4800);
  bool inside = true;
  for (int i = 0; i < 200; ++i) {
    renderN(e, 480);
    const int64_t p = e.deckInfo(0).positionFrames;
    if (p > 100500 || p < 99000) inside = false;
  }
  CHECK(inside);
  const int64_t p = e.deckInfo(0).positionFrames;
  CHECK(p >= 100000 && p < 100500);   // preso no loop depois de passar por ele
  e.clearLoop(0);
  renderN(e, 4800);
  CHECK(e.deckInfo(0).positionFrames > 100500);  // soltou
  // carregar outra faixa desliga o loop
  e.setLoop(0, 100600, 101600);
  renderN(e, 480);
  e.loadTrack(0, t); e.seekFrames(0, 100000); e.play(0);
  renderN(e, 48000);
  CHECK(e.deckInfo(0).positionFrames > 130000);
}

// Faixa sintética: bumbo em cada tempo, chimbal nos contratempos, ruído de fundo.
static std::shared_ptr<Track> makeBeat(double bpm, double seconds, double offsetSec, unsigned seed) {
  auto t = std::make_shared<Track>();
  t->sampleRate = kSr; t->frames = static_cast<int64_t>(seconds * kSr);
  t->pcm.assign(static_cast<size_t>(t->frames) * 2, 0);
  std::mt19937 rng(seed);
  std::normal_distribution<double> nd(0.0, 1.0);
  const double beat = 60.0 / bpm;
  std::vector<double> mix(static_cast<size_t>(t->frames), 0.0);
  for (double tb = offsetSec; tb < seconds; tb += beat) {
    const int64_t a = static_cast<int64_t>(tb * kSr);
    for (int i = 0; i < 6000 && a + i < t->frames; ++i) {
      const double env = std::exp(-i / 1800.0);
      const double f = 50.0 + 90.0 * std::exp(-i / 500.0);
      mix[a + i] += 0.6 * env * std::sin(2 * kPi * f * i / kSr);
    }
    const int64_t h = static_cast<int64_t>((tb + beat / 2) * kSr);
    for (int i = 0; i < 1200 && h + i < t->frames; ++i) mix[h + i] += 0.12 * std::exp(-i / 300.0) * nd(rng);
  }
  for (int64_t i = 0; i < t->frames; ++i) {
    const double v = std::max(-1.0, std::min(1.0, mix[i] + 0.01 * nd(rng)));
    t->pcm[2 * i] = t->pcm[2 * i + 1] = static_cast<int16_t>(v * 30000);
  }
  return t;
}

static void testBpm() {
  std::printf("detecção de BPM\n");
  struct Case { double bpm, offset; };
  const Case cases[] = {{100, 0.0}, {120, 0.31}, {123.5, 0.1}, {128, 0.0}, {140, 0.22}, {150, 0.05}, {174, 0.13}};
  unsigned seed = 1;
  for (const Case& c : cases) {
    auto t = makeBeat(c.bpm, 60, c.offset, seed++);
    const BpmResult r = analyzeBpm(*t);
    std::printf("  esperado %.1f  detectado %.2f  confiança %.2f  1ª batida %.3f s (esperado %.3f)\n", c.bpm, r.bpm,
                r.confidence, r.firstBeatFrame / 48000.0, c.offset);
    // 174 pode sair como 87: a metade do andamento é um acerto em oitava (a tela tem botões ×2 e ÷2)
    const bool octave = c.bpm >= 170;
    CHECK(std::fabs(r.bpm - c.bpm) < 0.35 || (octave && std::fabs(r.bpm - c.bpm / 2) < 0.2));
    const double beat = 60.0 / r.bpm;
    double d = std::fmod(r.firstBeatFrame / 48000.0 - c.offset, beat);
    if (d < 0) d += beat;
    if (d > beat / 2) d -= beat;
    CHECK(std::fabs(d) < 0.025);
    CHECK(r.confidence > 0.05f);
  }
  // silêncio, faixa curta e ruído: sem andamento falso com confiança alta
  auto silence = std::make_shared<Track>();
  silence->sampleRate = kSr; silence->frames = kSr * 30; silence->pcm.assign(static_cast<size_t>(silence->frames) * 2, 0);
  CHECK(analyzeBpm(*silence).bpm == 0);
  auto shortT = makeBeat(120, 5, 0, 9);
  CHECK(analyzeBpm(*shortT).bpm == 0);
  auto noise = std::make_shared<Track>();
  noise->sampleRate = kSr; noise->frames = kSr * 40; noise->pcm.resize(static_cast<size_t>(noise->frames) * 2);
  std::mt19937 rng(5);
  for (auto& s : noise->pcm) s = static_cast<int16_t>(static_cast<int>(rng() % 20000) - 10000);
  const BpmResult rn = analyzeBpm(*noise);
  std::printf("  ruído: bpm %.1f confiança %.2f\n", rn.bpm, rn.confidence);
  CHECK(rn.confidence < 0.5f);
}

int main() {
  testEq();
  testFilter();
  testRate();
  testLoop();
  testBpm();
  std::printf("\n%d verificações, %d falhas\n", g_checks, g_fail);
  return g_fail ? 1 : 0;
}
