// Testes do equalizador, filtro, velocidade, loop e detecção de BPM. Compilar com ASan e UBSan.
#include <cmath>
#include <cstdio>
#include <cstdlib>
#include <memory>
#include <random>
#include <vector>

#include "../../app/src/main/cpp/core/bpm.h"
#include "../../app/src/main/cpp/core/builtin_samples.h"
#include "../../app/src/main/cpp/core/energy.h"
#include "../../app/src/main/cpp/core/stems.h"
#include "../../app/src/main/cpp/core/engine.h"
#include "../../app/src/main/cpp/core/fx.h"
#include "../../app/src/main/cpp/core/key.h"
#include "../../app/src/main/cpp/core/samples.h"
#include "../../app/src/main/cpp/core/track.h"

using namespace djf;

static int g_fail = 0, g_checks = 0;
#define CHECK(c) do { ++g_checks; if (!(c)) { ++g_fail; std::printf("  FALHOU %s:%d  %s\n", __FILE__, __LINE__, #c); } } while (0)
#define CHECK_NEAR(a, b, tol) do { ++g_checks; double _a=(a), _b=(b); if (!(std::fabs(_a-_b) <= (tol))) { ++g_fail; std::printf("  FALHOU %s:%d  %s=%g esperado %g (tol %g)\n", __FILE__, __LINE__, #a, _a, _b, (double)(tol)); } } while (0)

static const double kPi = 3.14159265358979323846;
static const int kSr = 48000;

static std::shared_ptr<Track> makeSine(int64_t frames, double hz, float amp) {
  auto t = std::make_shared<Track>();
  t->sampleRate = kSr; t->frames = frames;
  t->pcm.resize(static_cast<size_t>(frames) * 2);
  for (int64_t i = 0; i < frames; ++i) {
    int16_t s = static_cast<int16_t>(amp * 32767.0 * std::sin(2 * kPi * hz * i / kSr));
    t->pcm[2 * i] = s; t->pcm[2 * i + 1] = s;
  }
  return t;
}

static std::vector<float> renderN(Engine& e, int frames, int chunk = 480) {
  std::vector<float> out(static_cast<size_t>(frames) * 2);
  for (int done = 0; done < frames; done += chunk) {
    int n = std::min(chunk, frames - done);
    e.render(&out[static_cast<size_t>(done) * 2], n);
  }
  return out;
}

static double rmsLeft(const std::vector<float>& o, size_t fromFrame) {
  double s = 0; size_t n = 0;
  for (size_t i = fromFrame; i < o.size() / 2; ++i) { s += o[2 * i] * o[2 * i]; ++n; }
  return std::sqrt(s / n);
}

// Toca um tom a 0 dB de referência e devolve o RMS depois de assentar.
struct Rig {
  Engine e{kSr, 480};
  Rig(double hz, int64_t secs = 3) {
    e.loadTrack(0, makeSine(kSr * secs, hz, 0.5f));
    e.setCrossfader(0.f); e.setMaster(1.f);
    renderN(e, 4800);
  }
};
static double dbOf(double ratio) { return 20.0 * std::log10(ratio); }

static double measure(double hz, void (*setup)(Engine&)) {
  Rig r(hz);
  setup(r.e);
  r.e.play(0);
  auto o = renderN(r.e, 48000 * 2);
  return rmsLeft(o, 24000) / (0.5 / std::sqrt(2.0));  // 1 = sem mudança
}

static void testEq() {
  std::printf("equalizador\n");
  for (double hz : {60.0, 1000.0, 9000.0}) {
    const double r = measure(hz, [](Engine&) {});
    CHECK_NEAR(r, 1.0, 0.002);  // neutro não mexe no som
  }
  // neutro é transparente de verdade: mesma saída que a entrada
  {
    Rig r(1000);
    r.e.play(0);
    auto o = renderN(r.e, 9600);
    auto ref = makeSine(kSr * 3, 1000, 0.5f);
    double maxErr = 0;
    for (int i = 200; i < 9600; ++i) maxErr = std::max<double>(maxErr, std::fabs(o[2 * i] - ref->pcm[2 * (i + 4800)] / 32768.0f * 1.0f));
    CHECK(maxErr < 1e-3);
  }
  // cada banda cortada derruba o seu tom e deixa os outros
  CHECK(dbOf(measure(60, [](Engine& e) { e.setEq(0, 0, 0.f); })) < -30);
  CHECK(dbOf(measure(1000, [](Engine& e) { e.setEq(0, 0, 0.f); })) > -3.0);
  CHECK(dbOf(measure(9000, [](Engine& e) { e.setEq(0, 0, 0.f); })) > -0.5);
  CHECK(dbOf(measure(1000, [](Engine& e) { e.setEq(0, 1, 0.f); })) < -20);
  std::printf("  info: 60Hz com médios cortados %.1f dB; 1kHz com agudos cortados %.1f dB\n", dbOf(measure(60, [](Engine& e) { e.setEq(0, 1, 0.f); })), dbOf(measure(1000, [](Engine& e) { e.setEq(0, 2, 0.f); })));
  CHECK(dbOf(measure(60, [](Engine& e) { e.setEq(0, 1, 0.f); })) > -2.0);
  CHECK(dbOf(measure(9000, [](Engine& e) { e.setEq(0, 2, 0.f); })) < -20);
  CHECK(dbOf(measure(1000, [](Engine& e) { e.setEq(0, 2, 0.f); })) > -2.0);
  // máximo é +6 dB na banda
  CHECK_NEAR(dbOf(measure(60, [](Engine& e) { e.setEq(0, 0, 1.f); })), 6.0, 1.0);
  CHECK_NEAR(dbOf(measure(9000, [](Engine& e) { e.setEq(0, 2, 1.f); })), 6.0, 1.0);
  // índices e deck inválidos são ignorados
  Engine e(kSr, 480);
  e.setEq(5, 0, 1.f); e.setEq(0, 9, 1.f); e.setEq(-1, 0, 1.f);
  renderN(e, 960);
}

static void testFilter() {
  std::printf("filtro de DJ\n");
  CHECK_NEAR(measure(1000, [](Engine& e) { e.setFilter(0, 0.5f); }), 1.0, 0.002);
  CHECK_NEAR(measure(1000, [](Engine& e) { e.setFilter(0, 0.51f); }), 1.0, 0.002);  // zona morta central
  CHECK(dbOf(measure(5000, [](Engine& e) { e.setFilter(0, 0.0f); })) < -30);          // passa-baixas fechado
  CHECK(dbOf(measure(60, [](Engine& e) { e.setFilter(0, 0.3f); })) > -3);            // graves passam
  CHECK(dbOf(measure(100, [](Engine& e) { e.setFilter(0, 1.0f); })) < -20);           // passa-altas fechado
  CHECK(dbOf(measure(9000, [](Engine& e) { e.setFilter(0, 0.7f); })) > -3);          // agudos passam
  // sem estouro nem valores inválidos varrendo o botão
  Rig r(220);
  r.e.play(0);
  bool ok = true;
  for (int i = 0; i < 400; ++i) {
    r.e.setFilter(0, static_cast<float>(i % 101) / 100.f);
    r.e.setEq(0, i % 3, static_cast<float>((i * 7) % 101) / 100.f);
    auto o = renderN(r.e, 480);
    for (float v : o) if (!std::isfinite(v) || std::fabs(v) > 1.0f) ok = false;
  }
  CHECK(ok);
}

static int zeroCrossings(const std::vector<float>& o, size_t from) {
  int z = 0;
  for (size_t i = from + 1; i < o.size() / 2; ++i) if (o[2 * (i - 1)] < 0.f && o[2 * i] >= 0.f) ++z;
  return z;
}

static void testRate() {
  std::printf("velocidade (pitch)\n");
  for (float rate : {0.92f, 1.0f, 1.05f, 1.08f}) {
    Rig r(1000, 10);
    r.e.setRate(0, rate);
    r.e.play(0);
    renderN(r.e, 24000);  // assenta a suavização
    const int64_t p0 = r.e.deckInfo(0).positionFrames;
    auto o = renderN(r.e, 48000);
    const int64_t p1 = r.e.deckInfo(0).positionFrames;
    CHECK_NEAR(static_cast<double>(p1 - p0), 48000.0 * rate, 4.0);
    const double hz = zeroCrossings(o, 0);  // em 1 s
    CHECK_NEAR(hz, 1000.0 * rate, 3.0);
    CHECK_NEAR(rmsLeft(o, 0), 0.5 / std::sqrt(2.0), 0.01);  // interpolação não muda o volume
  }
  // limites
  Rig r(1000, 10);
  r.e.setRate(0, 100.f); r.e.play(0); renderN(r.e, 48000);
  CHECK(r.e.deckInfo(0).positionFrames < 48000 * 2 + 5000);  // limitado a 2x
  r.e.setRate(0, -3.f); renderN(r.e, 24000);
  const int64_t a = r.e.deckInfo(0).positionFrames; renderN(r.e, 48000);
  CHECK_NEAR(static_cast<double>(r.e.deckInfo(0).positionFrames - a), 0.0, 30.0);  // limitado a 0 (WIDE -100%)
  r.e.setRate(0, 0.5f); renderN(r.e, 24000);
  const int64_t a2 = r.e.deckInfo(0).positionFrames; renderN(r.e, 48000);
  CHECK_NEAR(static_cast<double>(r.e.deckInfo(0).positionFrames - a2), 24000.0, 30.0);  // 0,5x
  // fim da faixa com velocidade
  Engine e(kSr, 480);
  e.loadTrack(0, makeSine(48000, 440, 0.3f)); e.setRate(0, 1.5f); e.play(0);
  renderN(e, 48000);
  CHECK(!e.deckInfo(0).playing);
}

static void testLoop() {
  std::printf("loop\n");
  // faixa em que o valor da amostra diz o quadro: rampa 0..1 a cada 10000 quadros
  auto t = std::make_shared<Track>();
  t->sampleRate = kSr; t->frames = kSr * 5; t->pcm.resize(static_cast<size_t>(t->frames) * 2);
  for (int64_t i = 0; i < t->frames; ++i) { int16_t v = static_cast<int16_t>((i % 20000) * 1.5); t->pcm[2*i] = v; t->pcm[2*i+1] = v; }
  Engine e(kSr, 480);
  e.loadTrack(0, t); e.setCrossfader(0.f); e.setMaster(1.f);
  e.setLoop(0, 100000, 100500);  // curto demais? 500 quadros: válido (>=256)
  e.setLoop(1, 10, 20);          // inválido: ignorado
  e.seekFrames(0, 99000);
  e.play(0);
  renderN(e, 4800);
  bool inside = true;
  for (int i = 0; i < 200; ++i) {
    renderN(e, 480);
    const int64_t p = e.deckInfo(0).positionFrames;
    if (p > 100500 || p < 99000) inside = false;
  }
  CHECK(inside);
  const int64_t p = e.deckInfo(0).positionFrames;
  CHECK(p >= 100000 && p < 100500);   // preso no loop depois de passar por ele
  e.clearLoop(0);
  renderN(e, 4800);
  CHECK(e.deckInfo(0).positionFrames > 100500);  // soltou
  // carregar outra faixa desliga o loop
  e.setLoop(0, 100600, 101600);
  renderN(e, 480);
  e.loadTrack(0, t); e.seekFrames(0, 100000); e.play(0);
  renderN(e, 48000);
  CHECK(e.deckInfo(0).positionFrames > 130000);
}

// Faixa sintética: bumbo em cada tempo, chimbal nos contratempos, ruído de fundo.
static std::shared_ptr<Track> makeBeat(double bpm, double seconds, double offsetSec, unsigned seed) {
  auto t = std::make_shared<Track>();
  t->sampleRate = kSr; t->frames = static_cast<int64_t>(seconds * kSr);
  t->pcm.assign(static_cast<size_t>(t->frames) * 2, 0);
  std::mt19937 rng(seed);
  std::normal_distribution<double> nd(0.0, 1.0);
  const double beat = 60.0 / bpm;
  std::vector<double> mix(static_cast<size_t>(t->frames), 0.0);
  for (double tb = offsetSec; tb < seconds; tb += beat) {
    const int64_t a = static_cast<int64_t>(tb * kSr);
    for (int i = 0; i < 6000 && a + i < t->frames; ++i) {
      const double env = std::exp(-i / 1800.0);
      const double f = 50.0 + 90.0 * std::exp(-i / 500.0);
      mix[a + i] += 0.6 * env * std::sin(2 * kPi * f * i / kSr);
    }
    const int64_t h = static_cast<int64_t>((tb + beat / 2) * kSr);
    for (int i = 0; i < 1200 && h + i < t->frames; ++i) mix[h + i] += 0.12 * std::exp(-i / 300.0) * nd(rng);
  }
  for (int64_t i = 0; i < t->frames; ++i) {
    const double v = std::max(-1.0, std::min(1.0, mix[i] + 0.01 * nd(rng)));
    t->pcm[2 * i] = t->pcm[2 * i + 1] = static_cast<int16_t>(v * 30000);
  }
  return t;
}

static void testBpm() {
  std::printf("detecção de BPM\n");
  struct Case { double bpm, offset; };
  const Case cases[] = {{100, 0.0}, {120, 0.31}, {123.5, 0.1}, {128, 0.0}, {140, 0.22}, {150, 0.05}, {174, 0.13}};
  unsigned seed = 1;
  for (const Case& c : cases) {
    auto t = makeBeat(c.bpm, 60, c.offset, seed++);
    const BpmResult r = analyzeBpm(*t);
    std::printf("  esperado %.1f  detectado %.2f  confiança %.2f  1ª batida %.3f s (esperado %.3f)\n", c.bpm, r.bpm,
                r.confidence, r.firstBeatFrame / 48000.0, c.offset);
    // 174 pode sair como 87: a metade do andamento é um acerto em oitava (a tela tem botões ×2 e ÷2)
    const bool octave = c.bpm >= 170;
    CHECK(std::fabs(r.bpm - c.bpm) < 0.35 || (octave && std::fabs(r.bpm - c.bpm / 2) < 0.2));
    const double beat = 60.0 / r.bpm;
    double d = std::fmod(r.firstBeatFrame / 48000.0 - c.offset, beat);
    if (d < 0) d += beat;
    if (d > beat / 2) d -= beat;
    CHECK(std::fabs(d) < 0.025);
    CHECK(r.confidence > 0.05f);
  }
  // silêncio, faixa curta e ruído: sem andamento falso com confiança alta
  auto silence = std::make_shared<Track>();
  silence->sampleRate = kSr; silence->frames = kSr * 30; silence->pcm.assign(static_cast<size_t>(silence->frames) * 2, 0);
  CHECK(analyzeBpm(*silence).bpm == 0);
  auto shortT = makeBeat(120, 5, 0, 9);
  CHECK(analyzeBpm(*shortT).bpm == 0);
  auto noise = std::make_shared<Track>();
  noise->sampleRate = kSr; noise->frames = kSr * 40; noise->pcm.resize(static_cast<size_t>(noise->frames) * 2);
  std::mt19937 rng(5);
  for (auto& s : noise->pcm) s = static_cast<int16_t>(static_cast<int>(rng() % 20000) - 10000);
  const BpmResult rn = analyzeBpm(*noise);
  std::printf("  ruído: bpm %.1f confiança %.2f\n", rn.bpm, rn.confidence);
  CHECK(rn.confidence < 0.5f);
}


static void testLimiter() {
  std::printf("limitador\n");
  Engine e(kSr, 4096);
  e.loadTrack(0, makeSine(kSr * 2, 440, 0.95f));
  e.loadTrack(1, makeSine(kSr * 2, 440, 0.95f));
  e.setMaster(1.f);
  e.setCrossfader(0.5f);
  e.play(0); e.play(1);
  std::vector<float> buf(2 * 512);
  float mx = 0.f; int flat = 0;
  for (int i = 0; i < 150; ++i) {
    e.render(buf.data(), 512);
    if (i < 20) continue;
    for (float v : buf) { mx = std::max(mx, std::fabs(v)); if (std::fabs(v) >= 0.99999f) ++flat; }
  }
  CHECK(mx <= 1.0f);
  CHECK(mx > 0.9f);      // não amassa o som
  CHECK(flat < 3);       // e não corta seco em 1.0
  // NaN vindo da interface não pode contaminar o áudio
  e.setVolume(0, std::nanf(""));
  e.setEq(0, 1, std::nanf(""));
  e.setFilter(0, std::nanf(""));
  e.setFx(0, 3, std::nanf(""), std::nan(""));
  bool finite = true;
  for (int i = 0; i < 40; ++i) {
    e.render(buf.data(), 512);
    for (float v : buf) if (!std::isfinite(v)) finite = false;
  }
  CHECK(finite);
}

static void testFx() {
  std::printf("efeitos\n");
  const float sm = 1.0f - std::exp(-1.0f / (0.010f * kSr));
  auto settle = [&](DeckFx& fx, int n) { for (int i = 0; i < n; ++i) { float l = 0, r = 0; fx.process(l, r, sm); } };
  // desligado e mistura zero: som seco exato
  {
    DeckFx fx(kSr);
    float l = 0.3f, r = -0.2f;
    fx.process(l, r, sm);
    CHECK(l == 0.3f && r == -0.2f);
    fx.set(DeckFx::Echo, 0.f, 0.5);
    settle(fx, 2000);
    l = 0.3f; r = -0.2f;
    fx.process(l, r, sm);
    CHECK(l == 0.3f && r == -0.2f);
  }
  // eco: batida de 0,5 s -> atraso de 0,375 s = 18000 quadros; na quantidade máxima o eco sai a 1,2 e cada
  // repetição seguinte com 70% da anterior
  {
    DeckFx fx(kSr);
    fx.set(DeckFx::Echo, 1.f, 0.5);
    settle(fx, kSr);  // deixa a mistura chegar a 1
    std::vector<float> out(60000);
    for (int i = 0; i < 60000; ++i) { float l = i == 0 ? 1.f : 0.f, r = l; fx.process(l, r, sm); out[i] = l; }
    CHECK_NEAR(out[0], 1.0, 0.01);
    CHECK_NEAR(out[9000], 0.0, 0.001);
    CHECK_NEAR(out[18000], 1.2, 0.02);
    CHECK_NEAR(out[36000], 0.84, 0.02);
    CHECK_NEAR(out[54000], 0.588, 0.02);
  }
  // flanger e reverb: estáveis com ruído por vários segundos, sem NaN nem estouro
  for (int type : {DeckFx::Flanger, DeckFx::Reverb}) {
    DeckFx fx(kSr);
    fx.set(type, 1.f, 0.5);
    std::mt19937 rng(11);
    float mx = 0.f; bool finite = true;
    for (int i = 0; i < kSr * 6; ++i) {
      float l = (static_cast<int>(rng() % 2001) - 1000) / 1000.f * 0.5f, r = l;
      fx.process(l, r, sm);
      mx = std::max(mx, std::max(std::fabs(l), std::fabs(r)));
      if (!std::isfinite(l) || !std::isfinite(r)) finite = false;
    }
    CHECK(finite);
    CHECK(mx < 3.0f);
  }
  // reverb: uma batida deixa cauda que decai
  {
    DeckFx fx(kSr);
    fx.set(DeckFx::Reverb, 1.f, 0.5);
    settle(fx, kSr);
    double early = 0, late = 0;
    for (int i = 0; i < kSr * 4; ++i) {
      float l = i == 0 ? 1.f : 0.f, r = l;
      fx.process(l, r, sm);
      if (i > 2000 && i < 14000) early += l * l;
      if (i > kSr * 3) late += l * l;
    }
    CHECK(early > 1e-6);
    CHECK(late < early * 0.2);
  }
  // pelo motor: comando chega ao áudio e o som continua finito
  {
    Engine e(kSr, 4096);
    e.loadTrack(0, makeSine(kSr * 4, 440, 0.5f));
    e.setFx(0, 1, 0.8f, 0.5);
    e.play(0);
    std::vector<float> buf(2 * 512);
    bool finite = true;
    for (int i = 0; i < 200; ++i) {
      e.render(buf.data(), 512);
      for (float v : buf) if (!std::isfinite(v)) finite = false;
    }
    CHECK(finite);
  }
}

// Frequência estimada por cruzamentos de zero ascendentes.
static double zeroCrossHz(const std::vector<float>& o, size_t from, size_t to) {
  int crossings = 0; size_t first = 0, last = 0;
  for (size_t i = from + 1; i < to; ++i) {
    if (o[2 * (i - 1)] < 0.f && o[2 * i] >= 0.f) { if (!crossings) first = i; last = i; ++crossings; }
  }
  if (crossings < 2) return 0;
  return (crossings - 1) * static_cast<double>(kSr) / static_cast<double>(last - first);
}

static void testKeyLock() {
  std::printf("key-lock (mudar o andamento sem mudar o tom)\n");
  for (float rate : {0.8f, 1.0f, 1.25f, 1.5f}) {
    Engine e(kSr, 480);
    e.loadTrack(0, makeSine(kSr * 20, 440, 0.5f));
    e.setCrossfader(0.f); e.setMaster(1.f); e.setKeyLock(0, true); e.setRate(0, rate);
    renderN(e, 4800);
    e.play(0);
    auto o = renderN(e, kSr * 3);
    const double hz = zeroCrossHz(o, 24000, o.size() / 2 - 100);
    CHECK_NEAR(hz, 440.0, 6.0);                         // o tom não muda
    CHECK_NEAR(rmsLeft(o, 24000), 0.5 / std::sqrt(2.0), 0.05);   // sem buracos nem excesso de nível
    // a posição avança no ritmo do andamento (3 s a 'rate')
    CHECK_NEAR(static_cast<double>(e.deckInfo(0).positionFrames), 3.0 * kSr * rate + 0.0, 0.05 * kSr * 3 * rate + 800);
    for (float v : o) CHECK(std::isfinite(v) && std::fabs(v) <= 1.0f);
  }
  {  // sem key-lock o tom acompanha a velocidade (controle)
    Engine e(kSr, 480);
    e.loadTrack(0, makeSine(kSr * 20, 440, 0.5f));
    e.setCrossfader(0.f); e.setMaster(1.f); e.setRate(0, 1.25f);
    renderN(e, 4800); e.play(0);
    auto o = renderN(e, kSr * 3);
    CHECK_NEAR(zeroCrossHz(o, 24000, o.size() / 2 - 100), 550.0, 8.0);
  }
  {  // música "real": dois tons + ruído; liga e desliga o key-lock durante a reprodução sem NaN nem estouro
    auto t = std::make_shared<Track>();
    t->sampleRate = kSr; t->frames = kSr * 20; t->pcm.resize(static_cast<size_t>(t->frames) * 2);
    std::mt19937 rng(5);
    for (int64_t i = 0; i < t->frames; ++i) {
      double v = 0.25 * std::sin(2 * kPi * 220 * i / kSr) + 0.2 * std::sin(2 * kPi * 1700 * i / kSr) +
                 0.1 * ((rng() % 2001) / 1000.0 - 1.0);
      int16_t s = static_cast<int16_t>(v * 32767.0);
      t->pcm[2 * i] = s; t->pcm[2 * i + 1] = s;
    }
    Engine e(kSr, 480);
    e.loadTrack(0, t); e.setCrossfader(0.f); e.setMaster(1.f); e.setRate(0, 1.12f);
    renderN(e, 4800); e.play(0);
    for (int k = 0; k < 6; ++k) {
      e.setKeyLock(0, k % 2 == 0);
      if (k == 3) e.seekFrames(0, 100000);
      if (k == 4) e.setLoop(0, 200000, 204000);
      auto o = renderN(e, kSr / 2);
      for (float v : o) CHECK(std::isfinite(v) && std::fabs(v) <= 1.0f);
      CHECK(rmsLeft(o, 0) > 0.05);
    }
  }
}

static void testScratch() {
  std::printf("scratch\n");
  {  // tocar no prato com o deck parado: a posição segue a velocidade do dedo
    Engine e(kSr, 480);
    e.loadTrack(0, makeSine(kSr * 20, 440, 0.5f));
    e.setCrossfader(0.f); e.setMaster(1.f);
    e.seekFrames(0, kSr * 5); renderN(e, 4800);
    e.scratch(0, true, 1.0f);
    auto o = renderN(e, kSr / 2);
    const double adv = static_cast<double>(e.deckInfo(0).positionFrames - kSr * 5);
    CHECK(adv > 0.35 * kSr && adv < 0.52 * kSr);       // ~0,5 s a velocidade 1 (menos a partida suave)
    CHECK(rmsLeft(o, 12000) > 0.3);                    // dá para ouvir mesmo com o deck parado
    e.scratch(0, true, -1.0f);                          // para trás
    auto p0 = e.deckInfo(0).positionFrames;
    renderN(e, kSr / 4);
    CHECK(e.deckInfo(0).positionFrames < p0);
    e.scratch(0, true, 0.f);                            // mão parada: silêncio, sem nível DC
    renderN(e, kSr / 4);
    auto q = renderN(e, 4800);
    double mx = 0; for (float v : q) mx = std::max(mx, (double)std::fabs(v));
    CHECK(mx < 0.01);
    e.scratch(0, false, 0.f);                           // solta com o deck parado: continua parado
    renderN(e, 9600);
    CHECK(!e.deckInfo(0).playing);
    const auto pa = e.deckInfo(0).positionFrames;
    renderN(e, 9600);
    CHECK(e.deckInfo(0).positionFrames == pa);
  }
  {  // deck tocando: segura (para), depois solta e volta a andar
    Engine e(kSr, 480);
    e.loadTrack(0, makeSine(kSr * 20, 440, 0.5f));
    e.setCrossfader(0.f); e.setMaster(1.f); e.play(0); renderN(e, 9600);
    e.scratch(0, true, 0.f); renderN(e, kSr / 4);
    const auto held = e.deckInfo(0).positionFrames;
    renderN(e, 4800);
    CHECK(std::llabs(e.deckInfo(0).positionFrames - held) < 80);  // preso na mão
    e.scratch(0, false, 0.f);
    auto o = renderN(e, kSr / 2);
    CHECK(e.deckInfo(0).positionFrames > held + kSr / 4);
    CHECK(e.deckInfo(0).playing);
    for (float v : o) CHECK(std::isfinite(v) && std::fabs(v) <= 1.0f);
  }
  {  // limites: nunca passa do início nem do fim, velocidade absurda é limitada
    Engine e(kSr, 480);
    e.loadTrack(0, makeSine(kSr * 2, 440, 0.5f));
    e.setCrossfader(0.f); e.setMaster(1.f); e.seekFrames(0, 1000); renderN(e, 4800);
    e.scratch(0, true, -50.f); renderN(e, kSr);
    CHECK(e.deckInfo(0).positionFrames >= 0);
    e.scratch(0, true, 50.f); auto o = renderN(e, kSr * 2);
    CHECK(e.deckInfo(0).positionFrames < kSr * 2);
    for (float v : o) CHECK(std::isfinite(v) && std::fabs(v) <= 1.0f);
    e.scratch(0, true, std::nanf("")); renderN(e, 480);
  }
}

static void testHeadphoneCue() {
  std::printf("fone (pré-escuta)\n");
  Engine e(kSr, 480);
  e.loadTrack(0, makeSine(kSr * 10, 440, 0.5f));
  e.loadTrack(1, makeSine(kSr * 10, 1000, 0.5f));
  e.setMaster(1.f); e.setHeadphoneLevel(1.f); e.setHeadphoneMix(0.f);
  e.setCrossfader(1.f);              // só o deck B no som geral
  e.setVolume(0, 0.f);               // deck A com o fader fechado
  e.play(0); e.play(1); e.setHeadphoneCue(0, true);
  std::vector<float> m(480 * 2), h(480 * 2);
  for (int k = 0; k < 30; ++k) e.render(m.data(), 480, h.data());
  double rm = 0, rh = 0;
  for (int k = 0; k < 40; ++k) {
    e.render(m.data(), 480, h.data());
    for (int i = 0; i < 480; ++i) { rm += m[2 * i] * m[2 * i]; rh += h[2 * i] * h[2 * i]; }
  }
  rm = std::sqrt(rm / (40 * 480)); rh = std::sqrt(rh / (40 * 480));
  CHECK_NEAR(rm, 0.5 / std::sqrt(2.0), 0.05);   // som geral: só o deck B
  CHECK_NEAR(rh, 0.5 / std::sqrt(2.0), 0.05);   // fone: só o deck A, mesmo com o fader fechado
  // o fone não muda o som geral: mesma saída com e sem o barramento
  {
    Engine a(kSr, 480), b(kSr, 480);
    for (Engine* x : {&a, &b}) { x->loadTrack(0, makeSine(kSr * 5, 440, 0.5f)); x->setCrossfader(0.f); x->setMaster(1.f); x->setHeadphoneCue(0, true); x->play(0); }
    std::vector<float> o1(480 * 2), o2(480 * 2), hh(480 * 2);
    double maxd = 0;
    for (int k = 0; k < 50; ++k) {
      a.render(o1.data(), 480); b.render(o2.data(), 480, hh.data());
      for (int i = 0; i < 960; ++i) maxd = std::max(maxd, (double)std::fabs(o1[i] - o2[i]));
    }
    CHECK(maxd == 0.0);
  }
  // mix = 1: fone igual ao som geral; nível 0: fone mudo
  e.setHeadphoneMix(1.f);
  for (int k = 0; k < 40; ++k) e.render(m.data(), 480, h.data());
  double d = 0; for (int i = 0; i < 960; ++i) d = std::max(d, (double)std::fabs(m[i] - h[i]));
  CHECK(d < 1e-3);
  e.setHeadphoneLevel(0.f);
  for (int k = 0; k < 40; ++k) e.render(m.data(), 480, h.data());
  double mx = 0; for (int i = 0; i < 960; ++i) mx = std::max(mx, (double)std::fabs(h[i]));
  CHECK(mx < 1e-3);
  // desligar o cue silencia o fone (mix 0)
  e.setHeadphoneLevel(1.f); e.setHeadphoneMix(0.f); e.setHeadphoneCue(0, false);
  for (int k = 0; k < 60; ++k) e.render(m.data(), 480, h.data());
  mx = 0; for (int i = 0; i < 960; ++i) mx = std::max(mx, (double)std::fabs(h[i]));
  CHECK(mx < 1e-3);
}

// ---- tonalidade ----
static double noteHz(int midi) { return 440.0 * std::pow(2.0, (midi - 69) / 12.0); }
// Progressão I-IV-V-I (ou i-iv-V-i no menor) com baixo, acordes de tríades com harmônicos, e um pouco de ruído.
static std::shared_ptr<Track> makeHarmony(int tonic, bool minor, int64_t seconds, unsigned seed) {
  auto t = std::make_shared<Track>();
  t->sampleRate = kSr; t->frames = kSr * seconds; t->pcm.resize(static_cast<size_t>(t->frames) * 2);
  const int third = minor ? 3 : 4;
  const int roots[4] = {0, 5, 7, 0};
  std::mt19937 rng(seed);
  const int64_t chordLen = kSr * 2;
  for (int64_t i = 0; i < t->frames; ++i) {
    const int ch = static_cast<int>((i / chordLen) % 4);
    const int root = 48 + tonic + roots[ch];
    const int notes[3] = {root + 12, root + 12 + ((ch == 2 && minor) ? 4 : third), root + 12 + 7};
    double v = 0;
    for (int n : notes) for (int h = 1; h <= 3; ++h) v += std::sin(2 * kPi * noteHz(n) * h * i / kSr) / (h * 1.5);
    v += 0.9 * std::sin(2 * kPi * noteHz(root) * i / kSr);
    v += 0.15 * ((rng() % 2001) / 1000.0 - 1.0);
    const int16_t smp = static_cast<int16_t>(v * 0.12 * 32767.0);
    t->pcm[2 * i] = smp; t->pcm[2 * i + 1] = smp;
  }
  return t;
}

static void testKey() {
  std::printf("tonalidade\n");
  int right = 0, total = 0;
  for (int minor = 0; minor < 2; ++minor) {
    for (int tonic = 0; tonic < 12; ++tonic) {
      auto t = makeHarmony(tonic, minor == 1, 40, 100u + tonic);
      const KeyResult r = analyzeKey(*t);
      ++total;
      CHECK(r.valid);
      if (r.valid && r.tonic == tonic && r.minor == (minor == 1)) ++right;
      else std::printf("  errou: esperado %d%s, veio %d%s (conf %.2f)\n", tonic, minor ? "m" : "", r.tonic, r.minor ? "m" : "", r.confidence);
      if (r.valid) { CHECK(r.confidence >= 0.35f); if (tonic == 0 && minor == 0) std::printf("  maior Dó: conf %.2f r %.2f\n", r.confidence, r.rBest); }
    }
  }
  std::printf("  acertos: %d de %d\n", right, total);
  CHECK(right >= 22);
  { // silêncio e ruído puro: sem tonalidade confiável; faixa curta: inválida
    auto sil = std::make_shared<Track>(); sil->sampleRate = kSr; sil->frames = kSr * 30; sil->pcm.assign(static_cast<size_t>(sil->frames) * 2, 0);
    CHECK(!analyzeKey(*sil).valid || analyzeKey(*sil).confidence < 0.35f);
    auto shortT = makeSine(kSr * 3, 440, 0.5f);
    CHECK(!analyzeKey(*shortT).valid);
    auto noise = std::make_shared<Track>(); noise->sampleRate = kSr; noise->frames = kSr * 30; noise->pcm.resize(static_cast<size_t>(noise->frames) * 2);
    std::mt19937 rng(9);
    for (auto& v : noise->pcm) v = static_cast<int16_t>((static_cast<int>(rng() % 20001) - 10000));
    const KeyResult nr = analyzeKey(*noise);
    CHECK(!nr.valid || nr.confidence < 0.35f);
    std::printf("  ruído: conf %.2f r %.2f\n", nr.valid ? nr.confidence : -1.f, nr.rBest);
  }
}

// ---- amostras ----
static std::shared_ptr<Track> makeBeatTrack(double bpm, int64_t secs) {
  auto t = std::make_shared<Track>();
  t->sampleRate = kSr; t->frames = kSr * secs; t->pcm.assign(static_cast<size_t>(t->frames) * 2, 0);
  const double beat = 60.0 / bpm * kSr;
  std::mt19937 rng(3);
  auto add = [&](int64_t i, double v) { if (i >= 0 && i < t->frames) { int s = t->pcm[2 * i] + static_cast<int>(v * 32767); s = std::max(-32767, std::min(32767, s)); t->pcm[2 * i] = t->pcm[2 * i + 1] = static_cast<int16_t>(s); } };
  const int64_t bars = static_cast<int64_t>(secs * bpm / 240.0);
  for (int64_t b = 0; b < bars * 4; ++b) {
    const int64_t at = static_cast<int64_t>(b * beat);
    const double amp = (b / 16 == 3) ? 0.8 : 0.4;   // um trecho forte (compassos 12-15)
    for (int i = 0; i < 9600; ++i) add(at + i, amp * std::sin(2 * kPi * 55 * i / kSr) * std::exp(-i / 2000.0));   // bumbo
    if (b % 4 == 2) for (int i = 0; i < 3000; ++i) add(at + i, 0.35 * ((rng() % 2001) / 1000.0 - 1.0) * std::exp(-i / 700.0));  // caixa
  }
  return t;
}

static void testSamples() {
  std::printf("sampler automático e pads\n");
  auto trk = makeBeatTrack(120, 64);
  auto specs = pickSamples(*trk, 120.0, 0);
  CHECK(specs.size() >= 3);
  bool haveKick = false, haveLoop = false;
  for (auto& s : specs) {
    if (s.kind == 0) haveKick = true;
    if (s.loop) {
      haveLoop = true;
      CHECK(std::llabs(s.length - static_cast<int64_t>(2.0 * kSr * (s.kind == 3 ? 2 : 1))) <= 1);   // compassos inteiros a 120 BPM
      const double beat = 0.5 * kSr;
      const double phase = std::fmod(static_cast<double>(s.start), beat);
      CHECK(std::min(phase, beat - phase) < 2.0);          // começa na grade de batidas
    }
    CHECK(s.start >= 0 && s.start + s.length <= trk->frames);
  }
  CHECK(haveKick && haveLoop);
  // o loop de 1 compasso cai no trecho forte (compassos 12 a 15 = 24 s a 32 s)
  for (auto& s : specs) if (s.kind == 2) CHECK(s.start >= 24 * kSr - 2 && s.start < 32 * kSr);
  // sem andamento: não inventa loop
  for (auto& s : pickSamples(*trk, 0.0, 0)) CHECK(!s.loop);
  CHECK(pickSamples(*makeSine(kSr * 2, 440, 0.5f), 120.0, 0).empty());   // faixa curta: nada
  auto smp = makeSample(*trk, specs[0]);
  CHECK(smp->frames == specs[0].length);
  CHECK(smp->pcm[0] == 0 && smp->pcm[2 * (smp->frames - 1)] == 0);   // pontas em silêncio: sem estalo

  // pads no motor
  Engine e(kSr, 480);
  e.setMaster(1.f); e.setSamplerVolume(1.f);
  auto sample = makeSine(kSr / 2, 1000, 0.5f);   // 0,5 s
  CHECK(e.loadSample(0, sample));
  CHECK(!e.loadSample(9, sample));
  renderN(e, 4800);
  auto o = renderN(e, 4800);
  CHECK(rmsLeft(o, 0) < 1e-6);                           // parado: silêncio
  e.triggerSample(0, false);
  o = renderN(e, 4800);
  CHECK_NEAR(rmsLeft(o, 1000), 0.5 / std::sqrt(2.0), 0.03);
  CHECK((e.samplerPlayingMask() & 1u) != 0);
  o = renderN(e, 48000);                                  // passou de 0,5 s: acabou sozinho
  CHECK(rmsLeft(o, 40000) < 1e-6);
  CHECK((e.samplerPlayingMask() & 1u) == 0);
  e.triggerSample(0, true);                               // loop: continua tocando além do tamanho
  o = renderN(e, 48000 * 2);
  CHECK_NEAR(rmsLeft(o, 60000), 0.5 / std::sqrt(2.0), 0.03);
  CHECK((e.samplerPlayingMask() & 1u) != 0);
  e.stopSample(0);
  renderN(e, 4800);
  o = renderN(e, 4800);
  CHECK(rmsLeft(o, 0) < 1e-6);
  // volume do sampler e soma com um deck
  e.loadTrack(0, makeSine(kSr * 5, 330, 0.3f)); e.setCrossfader(0.f); e.play(0);
  e.setSamplerVolume(0.f); e.triggerSample(0, true);
  renderN(e, 9600); o = renderN(e, 9600);
  CHECK_NEAR(rmsLeft(o, 0), 0.3 / std::sqrt(2.0), 0.03);   // volume 0: só o deck
  e.setSamplerVolume(1.f); renderN(e, 9600); o = renderN(e, 48000);
  for (float v : o) CHECK(std::isfinite(v) && std::fabs(v) <= 1.0f);
  CHECK(rmsLeft(o, 0) > 0.3);
  e.clearSample(0);
  renderN(e, 9600); o = renderN(e, 4800);
  CHECK_NEAR(rmsLeft(o, 0), 0.3 / std::sqrt(2.0), 0.03);   // pad limpo: sumiu
  e.collectGarbage();
}

// ---- partida com batida alinhada ----
static std::shared_ptr<Track> makeClicks(double bpm, int64_t secs, double offsetFrames, bool negative) {
  auto t = std::make_shared<Track>();
  t->sampleRate = kSr; t->frames = kSr * secs; t->pcm.assign(static_cast<size_t>(t->frames) * 2, 0);
  const double beat = 60.0 / bpm * kSr;
  for (int64_t b = 0;; ++b) {
    const int64_t at = static_cast<int64_t>(offsetFrames + b * beat);
    if (at + 4 >= t->frames) break;
    for (int i = 0; i < 4; ++i) t->pcm[2 * (at + i)] = t->pcm[2 * (at + i) + 1] = static_cast<int16_t>((negative ? -1 : 1) * 16000);
  }
  return t;
}

static void testPlaySynced() {
  std::printf("partida com batida alinhada\n");
  Engine e(kSr, 480);
  const double bpmA = 120, bpmB = 100, offA = 3000, offB = 7777;
  e.loadTrack(0, makeClicks(bpmA, 60, offA, false));
  e.loadTrack(1, makeClicks(bpmB, 60, offB, true));
  e.setCrossfader(0.5f); e.setMaster(1.f);
  const double beatA = 60.0 / bpmA * kSr, beatB = 60.0 / bpmB * kSr;
  e.setRate(1, static_cast<float>(bpmA / bpmB));         // B acelera para 120
  renderN(e, 4800);
  e.seekFrames(0, 10000); renderN(e, 4800);
  e.play(0);
  renderN(e, 7001);                                       // ponto qualquer, fora da batida
  e.playSynced(1, 0, offA, beatA, offB, beatB, 4.0);
  auto o = renderN(e, kSr * 6);
  // cliques de A (positivos) e de B (negativos): cada B precisa cair junto de um A
  std::vector<int64_t> posA, negB;
  for (size_t i = 0; i < o.size() / 2; ++i) {
    if (o[2 * i] > 0.1f && (posA.empty() || (int64_t)i - posA.back() > 1000)) posA.push_back((int64_t)i);
    if (o[2 * i] < -0.1f && (negB.empty() || (int64_t)i - negB.back() > 1000)) negB.push_back((int64_t)i);
  }
  CHECK(posA.size() >= 8 && negB.size() >= 8);
  int aligned = 0, counted = 0;
  for (size_t k = 2; k < negB.size(); ++k) {          // ignora os primeiros (rampa de entrada)
    int64_t best = 1 << 30;
    for (int64_t a : posA) best = std::min<int64_t>(best, std::llabs(a - negB[k]));
    ++counted;
    if (best <= 24) ++aligned;                           // 0,5 ms
  }
  std::printf("  cliques de B alinhados com A: %d de %d (dentro de 0,5 ms)\n", aligned, counted);
  CHECK(counted >= 6 && aligned == counted);
  CHECK(e.deckInfo(1).playing);
  // referência parada: começa direto na batida pedida
  Engine f(kSr, 480);
  f.loadTrack(0, makeClicks(120, 20, 0, false)); f.loadTrack(1, makeClicks(100, 20, 500, true));
  renderN(f, 4800);
  f.playSynced(1, 0, 0, 24000, 500, 28800, 2.0);
  renderN(f, 9600);
  CHECK(std::llabs(f.deckInfo(1).positionFrames - (500 + 2 * 28800)) < 9600 + 64);
  f.playSynced(1, 1, 0, 1, 0, 1, 0);        // entradas inválidas: ignoradas sem travar
  f.playSynced(5, 0, 0, 24000, 0, 28800, 0);
}


// ---- pads no tempo, energia e gravação ----
static void testNew() {
  std::printf("pads no tempo, energia e gravação\n");
  Engine e(kSr, 480);
  e.setMaster(1.f); e.setSamplerVolume(1.f);
  auto s = makeSine(kSr, 1000, 0.5f);
  CHECK(e.loadSample(0, s));
  renderN(e, 960);
  e.triggerSample(0, false, 24000);                     // começa 0,5 s depois (na batida)
  auto o = renderN(e, 19200);
  CHECK(rmsLeft(o, 0) < 1e-6);                          // ainda esperando
  o = renderN(e, 9600);
  CHECK(rmsLeft(o, 7000) > 0.3);                        // começou
  // velocidade 2x: termina na metade do tempo
  e.setSampleSpeed(0, 2.f);
  e.triggerSample(0, false);
  renderN(e, 480);
  o = renderN(e, kSr * 3 / 10);                         // 0,3 s
  CHECK((e.samplerPlayingMask() & 1u) != 0);
  o = renderN(e, kSr * 3 / 10);                         // 0,6 s no total: com 2x já acabou (0,5 s)
  CHECK((e.samplerPlayingMask() & 1u) == 0);
  e.setSampleSpeed(0, 0.f);                             // inválido vira 1x, sem travar
  e.setSampleSpeed(9, 1.f);
  // energia: tom fraco e liso < batida forte com ataques
  const float quiet = analyzeEnergy(*makeSine(kSr * 60, 220, 0.03f));
  const float loud = analyzeEnergy(*makeBeatTrack(128, 64));
  std::printf("  energia: tom fraco %.2f, batida %.2f\n", quiet, loud);
  CHECK(quiet >= 0.f && loud > quiet + 0.25f);
  CHECK(analyzeEnergy(*makeSine(kSr, 220, 0.5f)) < 0.f);   // curta demais
  // gravação: o que sai é o que fica gravado, sem perder quadros
  Engine r(kSr, 480);
  r.loadTrack(0, makeSine(kSr * 4, 440, 0.4f)); r.setCrossfader(0.f); r.setMaster(1.f); r.play(0);
  renderN(r, 4800);
  std::vector<float> got;
  float buf[4096];
  r.setRecording(true);
  std::vector<float> heard;
  for (int k = 0; k < 100; ++k) {
    auto blk = renderN(r, 480);
    heard.insert(heard.end(), blk.begin(), blk.end());
    size_t n;
    while ((n = r.readRecorded(buf, 4096)) > 0) got.insert(got.end(), buf, buf + n);
  }
  r.setRecording(false);
  renderN(r, 960);
  size_t n;
  while ((n = r.readRecorded(buf, 4096)) > 0) got.insert(got.end(), buf, buf + n);
  CHECK(got.size() == heard.size());
  bool same = got.size() == heard.size();
  for (size_t i = 0; same && i < got.size(); ++i) same = got[i] == heard[i];
  CHECK(same);
  CHECK(r.recordDropped() == 0);
}


// ---- stems e mudança de tom ----
static double corr(const std::vector<float>& a, const std::vector<float>& b, size_t from, size_t to) {
  double ab = 0, aa = 1e-12, bb = 1e-12;
  for (size_t i = from; i < to; ++i) { ab += a[i] * b[i]; aa += a[i] * a[i]; bb += b[i] * b[i]; }
  return ab / std::sqrt(aa * bb);
}

static void testStems() {
  std::printf("stems (voz, bateria, baixo) e mudança de tom\n");
  const int n = kSr * 12;
  std::vector<float> voc(n), drm(n), bas(n), padL(n), padR(n);
  uint32_t seed = 7;
  double vph = 0;
  const double beat = 60.0 / 120.0;
  for (int i = 0; i < n; ++i) {
    const double t = static_cast<double>(i) / kSr, tb = std::fmod(t, beat), tb2 = std::fmod(t + beat / 2, beat);
    seed = seed * 1664525u + 1013904223u;
    const float noise = static_cast<float>((seed >> 9) & 0xFFFF) / 32768.f - 1.f;
    drm[i] = static_cast<float>(0.5 * std::sin(2 * M_PI * 60 * tb) * std::exp(-tb / 0.05) + 0.25 * noise * std::exp(-tb2 / 0.01));
    bas[i] = static_cast<float>(0.3 * std::sin(2 * M_PI * 55 * t));
    // "voz": harmônicos de 330 Hz com vibrato, no centro
    vph += 2 * M_PI * 330.0 * (1.0 + 0.01 * std::sin(2 * M_PI * 5.5 * t)) / kSr;   // fase acumulada (vibrato real)
    double v = 0;
    for (int h = 1; h <= 6; ++h) v += std::sin(vph * h) / h;
    voc[i] = static_cast<float>(0.15 * v);
    // teclado só nas laterais (estéreo aberto)
    padL[i] = static_cast<float>(0.12 * std::sin(2 * M_PI * 523.25 * t));
    padR[i] = static_cast<float>(0.12 * std::sin(2 * M_PI * 659.25 * t));
  }
  auto t = std::make_shared<Track>();
  t->frames = n; t->sampleRate = kSr; t->pcm.resize(static_cast<size_t>(n) * 2);
  for (int i = 0; i < n; ++i) {
    const float c = voc[i] + drm[i] + bas[i];
    t->pcm[2 * i] = static_cast<int16_t>(std::lrint(std::max(-1.f, std::min(1.f, c + padL[i])) * 32767));
    t->pcm[2 * i + 1] = static_cast<int16_t>(std::lrint(std::max(-1.f, std::min(1.f, c + padR[i])) * 32767));
  }
  float lastP = -1;
  CHECK(separateStems(*t, [&](float p) { lastP = p; }));
  CHECK(t->stemsReady.load());
  CHECK(lastP == 1.f);
  std::vector<float> eV(n), eD(n), eB(n);
  for (int i = 0; i < n; ++i) {
    eV[i] = t->stemPcm[3 * i] / 32768.f; eD[i] = t->stemPcm[3 * i + 1] / 32768.f; eB[i] = t->stemPcm[3 * i + 2] / 32768.f;
  }
  const size_t a = kSr, b = static_cast<size_t>(n) - kSr;
  const double cv = corr(eV, voc, a, b), cd = corr(eD, drm, a, b), cb = corr(eB, bas, a, b);
  std::printf("  correlação com o original: voz %.2f, bateria %.2f, baixo %.2f\n", cv, cd, cb);
  CHECK(cv > 0.6);
  CHECK(cd > 0.6);
  CHECK(cb > 0.85);
  // a voz estimada não deve conter o teclado das laterais nem o baixo
  CHECK(std::fabs(corr(eV, bas, a, b)) < 0.2);

  // motor: todos os ganhos em 1 = som original bit a bit; voz em 0 tira a voz
  Engine e1(kSr, 480), e2(kSr, 480);
  e1.loadTrack(0, t); e2.loadTrack(0, t);
  for (Engine* e : {&e1, &e2}) { e->setCrossfader(0.f); e->setMaster(1.f); e->play(0); }
  e2.setStemGain(0, 0, 1.f);
  auto o1 = renderN(e1, kSr * 2), o2 = renderN(e2, kSr * 2);
  bool same = o1.size() == o2.size();
  for (size_t i = 0; same && i < o1.size(); ++i) same = o1[i] == o2[i];
  CHECK(same);
  e2.setStemGain(0, 0, 0.f);
  renderN(e1, kSr / 2); renderN(e2, kSr / 2);          // espera a rampa do ganho
  auto withVoice = renderN(e1, kSr * 2), noVoice = renderN(e2, kSr * 2);
  // a diferença entre os dois é a voz que saiu: tem de parecer com a voz original
  std::vector<float> diff(kSr * 2), vref(kSr * 2);
  const size_t off = static_cast<size_t>(kSr * 2 + kSr / 2);
  for (int i = 0; i < kSr * 2; ++i) { diff[i] = withVoice[2 * i] - noVoice[2 * i]; vref[i] = voc[off + i]; }
  const double cr = corr(diff, vref, 0, diff.size());
  std::printf("  voz retirada pelo motor x voz original: %.2f\n", cr);
  CHECK(cr > 0.6);
  e2.setStemGain(0, 9, 0.f);                // índice inválido: ignorado
  e2.setStemGain(5, 0, 0.f);

  // mudança de tom: +12 semitons dobra a frequência e mantém o andamento
  Engine k(kSr, 480);
  k.loadTrack(0, makeSine(kSr * 6, 220, 0.5f)); k.setCrossfader(0.f); k.setMaster(1.f);
  k.setKeyShift(0, 12.f);
  k.play(0);
  renderN(k, kSr / 2);
  auto ks = renderN(k, kSr);
  auto tone = [](const std::vector<float>& s, double f) {   // Goertzel no canal esquerdo
    const double w = 2 * M_PI * f / kSr, c = 2 * std::cos(w);
    double s1 = 0, s2 = 0;
    for (size_t i = 0; i < s.size(); i += 2) { const double s0 = s[i] + c * s1 - s2; s2 = s1; s1 = s0; }
    return std::sqrt(s1 * s1 + s2 * s2 - c * s1 * s2) / (s.size() / 2) * 100;
  };
  const double f440 = tone(ks, 440), f220 = tone(ks, 220);
  std::printf("  +12 semitons: 440 Hz %.1f, 220 Hz %.1f\n", f440, f220);
  CHECK(f440 > f220 * 4);
  const double posSec = static_cast<double>(k.deckInfo(0).positionFrames) / kSr;
  CHECK(std::fabs(posSec - 1.5) < 0.05);
  k.setKeyShift(0, -99.f);                   // limitado a -12
  k.setKeyShift(0, NAN);

  // auto-gain: volume medido e ganho de entrada
  auto loud = makeSine(kSr * 6, 440, 0.5f), soft = makeSine(kSr * 6, 440, 0.125f);
  const float dl = analyzeLoudness(*loud), ds = analyzeLoudness(*soft);
  std::printf("  volume medio: %.1f e %.1f dBFS\n", dl, ds);
  CHECK(std::fabs((dl - ds) - 12.04f) < 0.3f);
  CHECK(std::fabs(dl - (-9.03f)) < 0.5f);       // seno de 0,5: RMS 0,354 = -9 dBFS
  Engine g(kSr, 480);
  g.loadTrack(0, loud); g.setCrossfader(0.f); g.setMaster(1.f); g.play(0);
  renderN(g, kSr / 4);
  auto r1 = renderN(g, kSr / 4);
  g.setTrim(0, 0.5f);
  renderN(g, kSr / 4);
  auto r2 = renderN(g, kSr / 4);
  double p1 = 0, p2 = 0;
  for (size_t i = 0; i < r1.size(); ++i) { p1 = std::max(p1, (double)std::fabs(r1[i])); p2 = std::max(p2, (double)std::fabs(r2[i])); }
  std::printf("  trim 0,5: pico %.3f -> %.3f\n", p1, p2);
  CHECK(std::fabs(p2 / p1 - 0.5) < 0.03);
  g.setTrim(0, NAN); g.setTrim(3, 1.f);
}

// Cada efeito muda o som de forma clara (diferença relativa ao som seco) e continua finito.
static void testFxAudible() {
  const char* names[] = {"", "ECO", "FLANGER", "REVERB", "TRANS", "BITCRUSH", "PHASER"};
  for (int type = 1; type < DeckFx::kTypes; ++type) {
    Engine dry(kSr, 480), wet(kSr, 480);
    auto tr = makeSine(kSr * 4, 330, 0.4f);
    // som com ataques (para eco e reverb aparecerem): pulsos de 50 ms a cada meio segundo
    if (type <= 3)   // eco, flanger e reverb: só ataques; trans, bitcrush e phaser: som contínuo
      for (int64_t i = 0; i < tr->frames; ++i) if ((i % (kSr / 2)) > kSr / 20) { tr->pcm[2 * i] = 0; tr->pcm[2 * i + 1] = 0; }
    for (Engine* e : {&dry, &wet}) { e->loadTrack(0, tr); e->setCrossfader(0.f); e->setMaster(1.f); e->play(0); }
    wet.setFx(0, type, 1.f, 0.5);
    auto a = renderN(dry, kSr * 2), b = renderN(wet, kSr * 2);
    double diff = 0, ref = 0; bool fin = true;
    for (size_t i = kSr / 2; i < a.size(); ++i) { diff += (a[i] - b[i]) * (a[i] - b[i]); ref += a[i] * a[i]; fin = fin && std::isfinite(b[i]); }
    const double rel = std::sqrt(diff / ref);
    std::printf("  efeito %s: mudança %.2f\n", names[type], rel);
    CHECK(fin);
    CHECK(rel > 0.3);
  }
}

static void testBuiltin() {
  Engine e(kSr, 480);
  e.setMaster(1.f);
  for (int k = 0; k < kBuiltinSamples; ++k) {
    auto s = makeBuiltinSample(k);
    CHECK(s && s->frames > kSr / 4);
    double peak = 0, sum = 0;
    for (int16_t v : s->pcm) { peak = std::max(peak, std::fabs(v / 32768.0)); sum += (v / 32768.0) * (v / 32768.0); }
    const double rms = std::sqrt(sum / s->pcm.size());
    std::printf("  som pronto %d (%s): %.2f s, pico %.2f, rms %.3f\n", k, builtinSampleName(k), s->durationSec(), peak, rms);
    CHECK(peak > 0.2 && peak <= 0.92);
    CHECK(rms > 0.02);
    CHECK(e.loadSample(k, s));
  }
  CHECK(makeBuiltinSample(9) == nullptr);
  e.triggerSample(3, false);
  auto out = renderN(e, kSr / 4);
  double p = 0;
  for (float v : out) p = std::max(p, (double)std::fabs(v));
  std::printf("  pad 4 (808) tocando: pico %.2f\n", p);
  CHECK(p > 0.1);
}

int main() {
  testFxAudible();
  testBuiltin();
  testStems();
  testNew();
  testKey();
  testSamples();
  testPlaySynced();
  testKeyLock();
  testScratch();
  testHeadphoneCue();
  testLimiter();
  testFx();
  testEq();
  testFilter();
  testRate();
  testLoop();
  testBpm();
  std::printf("\n%d verificações, %d falhas\n", g_checks, g_fail);
  return g_fail ? 1 : 0;
}
