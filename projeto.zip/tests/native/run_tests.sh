#!/usr/bin/env bash
# Compila e roda os testes do motor de áudio no Linux. Precisa de g++ e nada mais.
set -euo pipefail
cd "$(dirname "$0")"
OUT="${TMPDIR:-/tmp}/djf-tests"
mkdir -p "$OUT"
CORE=../../app/src/main/cpp/core/engine.cpp
WARN="-std=c++17 -Wall -Wextra -Werror"

echo "== 1/5 lógica do motor (ASan + UBSan) =="
g++ $WARN -O1 -g -fsanitize=address,undefined -fno-sanitize-recover=undefined \
    test_engine.cpp $CORE -o "$OUT/test_engine" -pthread
"$OUT/test_engine"

echo; echo "== 2/5 callback sem alocação (sem sanitizers) =="
g++ $WARN -O2 -DCOUNT_ALLOCS test_realtime.cpp $CORE -o "$OUT/test_noalloc" -pthread
"$OUT/test_noalloc"

echo; echo "== 3/5 corrida de threads (TSan) =="
g++ $WARN -O1 -g -fsanitize=thread -DTHREAD_TEST test_realtime.cpp $CORE -o "$OUT/test_threads" -pthread
"$OUT/test_threads"
echo; echo "== 4/5 testes extras: conversor de taxa, faixa e motor em escala (ASan + UBSan + TSan) =="
g++ $WARN -O1 -g -fsanitize=address,undefined -fno-sanitize-recover=undefined \
    test_core_extra.cpp $CORE -o "$OUT/test_extra_asan" -pthread
"$OUT/test_extra_asan"
g++ $WARN -O1 -g -fsanitize=thread test_core_extra.cpp $CORE -o "$OUT/test_extra_tsan" -pthread
"$OUT/test_extra_tsan"
echo; echo "== 5/5 EQ, filtro, velocidade, loop e BPM (ASan + UBSan) =="
g++ $WARN -O1 -g -fsanitize=address,undefined -fno-sanitize-recover=undefined \
    test_dsp.cpp $CORE -o "$OUT/test_dsp"

echo; echo "== extra: decodificador próprio (MP3, FLAC, WAV 8/24/32 bits) =="
DEC="$OUT/dec"; mkdir -p "$DEC"
A=../../app/src/androidTest/assets/e2e_124.mp3
ARGS="$A 1"
if command -v ffmpeg >/dev/null; then
  ffmpeg -loglevel error -y -i $A -c:a flac "$DEC/t.flac"
  ffmpeg -loglevel error -y -i $A -c:a pcm_s24le "$DEC/t24.wav"
  ffmpeg -loglevel error -y -i $A -ac 1 -ar 22050 -c:a pcm_u8 "$DEC/t8.wav"
  ffmpeg -loglevel error -y -i $A -c:a pcm_f32le "$DEC/tf.wav"
  ffmpeg -loglevel error -y -i $A -ac 1 -ar 32000 -b:a 96k "$DEC/mono.mp3"
  ARGS="$ARGS $DEC/t.flac 2 $DEC/t24.wav 3 $DEC/t8.wav 3 $DEC/tf.wav 3 $DEC/mono.mp3 1"
fi
g++ -std=c++17 -O1 -g -fsanitize=address,undefined -fno-sanitize-recover=undefined -I../../app/src/main/cpp \
    test_decode.cpp ../../app/src/main/cpp/core/file_decoder.cpp -o "$OUT/test_decode"
"$OUT/test_decode" $ARGS -pthread
"$OUT/test_dsp"
echo; echo "TUDO OK"
