#include "core/file_decoder.h"
#include <fcntl.h>
#include <unistd.h>
#include <cstdio>
#include <cmath>
using namespace djf;
int main(int argc, char** argv){
  int fails=0;
  for (int i=1;i+1<argc;i+=2){
    int fd=open(argv[i],O_RDONLY); int kind=atoi(argv[i+1]);
    off_t sz=lseek(fd,0,SEEK_END); lseek(fd,0,SEEK_SET);
    std::atomic<float> pr{0};
    auto r=decodeFile(fd,(FileKind)kind,sz,48000,48000LL*900,&pr,nullptr);
    close(fd);
    if(!r.track){printf("FALHOU %s: %s\n",argv[i],r.error.c_str());fails++;continue;}
    double peak=0; for(auto v:r.track->pcm) peak=std::max(peak,std::fabs(v/32768.0));
    printf("%s: %.2f s, %d Hz, %d canais, pico %.2f, progresso %.2f\n",argv[i],r.track->durationSec(),r.srcRate,r.channels,peak,pr.load());
    if (peak<0.05) fails++;
  }
  return fails;
}
