# ROTEIRO — tudo o que combinamos fazer (atualizado na 3.7.25)

Estados: **FEITO E TESTADO** (passo automático no emulador) · **FEITO, AGUARDA VOCÊ** (precisa do seu celular) · **EM CONSTRUÇÃO** · **PENDENTE** · **PRECISA DE UMA RESPOSTA SUA** · **FORA DO ALCANCE** (explicado).

## A. Lista dos 9 itens pedidos em 20/11
| # | Item | Estado |
|---|------|--------|
| 1 | Pad XY de efeitos | FEITO na 3.7.25 (quantidade × divisão da batida, com TRAVAR); teste no emulador |
| 2 | Master sync (botão MESTRE) | FEITO na 3.7.25, teste no emulador (ver relatório) |
| 3 | Biblioteca por álbum/artista/gênero/pasta, com capas | CAPAS e TABELA: feitos na 3.7.24. Agrupar por artista, gênero e pasta/álbum: FEITO na 3.7.25 (álbum = pasta; etiqueta de álbum do arquivo ainda não é lida) |
| 4 | Ondas coloridas por graves/médios/agudos | JÁ EXISTIA (6 tipos e 5 cores em AJUSTES › Aparência); vou conferir se o padrão está bom |
| 5 | Loops de 1/16 a 32 e loops salvos por música | FEITO na 3.7.25 |
| 6 | Mixer FX por canal + sampler de 16 pads | FEITO na 3.7.25: 16 pads (8 de bateria prontos), efeitos já são por deck, KILL na tela |
| 7 | Sequenciador de bateria | FEITO na 3.7.25 (4 linhas × 16 passos, segue o BPM do deck) |
| 8 | Sandbox (ouvir a próxima mixagem no fone) | JÁ EXISTIA (botão FONE + MIX FONE); explicado no tutorial |
| 9 | Tutoriais dentro do app | FEITO na 3.7.25 (AJUSTES › AJUDA, 6 passo a passo) |

## B. Melhorias combinadas antes
| Item | Estado |
|---|---|
| Fechamento ao trocar para decks C/D | CORRIGIDO na 3.7.24 |
| Lista dentro do DJ LIVE | FEITO (3.7.23); menor na 3.7.24 |
| Pratos maiores / botões confortáveis / textos cortados | PARCIAL (3.7.24): HI/MID/LOW, botões mais altos |
| Biblioteca em tabela com capa | FEITO na 3.7.24 |
| Tocar na onda para pular | FEITO E TESTADO (3.7.22) |
| AUTO DJ: mixagem mínima de 16 batidas e sync até 12% | FEITO E TESTADO (3.7.21/22) |
| Andamento variável falso | CORRIGIDO (3.7.21) |
| Gráficos da equalização incorretos | PRECISA DE UMA RESPOSTA SUA: qual gráfico? |
| Liberdade nos jog wheels | FEITO na 3.7.25: sensibilidade do scratch e força do empurrão em AJUSTES › PRATOS |
| Controle de mixagem profissional | PRECISA DE UMA RESPOSTA SUA: o que falta? |
| Editor de transições em linha do tempo / exportar mix | PENDENTE |
| Detecção de verso, refrão e buildup | PARCIAL (início, groove, drop, saída, breaks) |
| Atalhos de teclado | FEITO na 3.7.25 (F1–F11) |
| Stems: modelo melhor (Demucs opcional) | PENDENTE |
| Mais presets de controladora; botões LOAD da DJ2Go | PENDENTE |
| Teste de saída por bus (som separado do fone) | PENDENTE |
| Chave de assinatura separada para a Play Store | PENDENTE (decisão sua) |
| Tela vazia do DJ LIVE com chamada para ação | FEITO na 3.7.25 |

## C. Fora do alcance (sem contrato/hardware)
Streaming (Tidal, Beatport, Apple Music, SoundCloud), vinil de controle (DVS), iluminação DMX, exportar pen drive para CDJ.
