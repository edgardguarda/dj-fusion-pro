# Edgard Guarda DJ Studio — Relatório de evolução (versão 2.7.0)

Estados: **EXISTENTE E PRESERVADA** · **EXISTENTE E MELHORADA** · **IMPLEMENTADA E TESTADA** (passo automático no emulador) ·
**IMPLEMENTADA, AGUARDANDO VALIDAÇÃO** (compila e roda, mas o resultado musical só se confirma no seu celular) ·
**PARCIALMENTE IMPLEMENTADA** · **PENDENTE** · **BLOQUEADA POR DEPENDÊNCIA**.

## 1. Arquitetura (auditada)
- App Android em Kotlin + Jetpack Compose; motor de áudio próprio em C++17 com Oboe (2 decks, 48 kHz, fila sem trava).
- Banco SQLite local (faixas, análises, hot cues com nome); preferências em SharedPreferences; backup .zip.
- Teste automático: testes do motor em C++ (ASan/UBSan/TSan) + teste de ponta a ponta no emulador Android a cada versão.
- Restauração: `restauracao/` no GitHub (APK 2.6.0, código e histórico git) + backup automático dos dados no app (a cada 12 h, guarda 5).
- Mesma assinatura em todas as versões: a 2.7.0 instala por cima da 2.6.0 sem perder músicas, cues nem ajustes.

## Resultado do teste automático (emulador Android, 14/11/2026)
- **84 passos certos, 1 falha.** A falha foi na janela de arquivos do próprio Android ("IMPORTAR pelo seletor"): o botão mudou na hora do toque do robô (StaleObjectException). Esse passo passou nas 3 rodadas anteriores, e a escolha de pasta pelo mesmo seletor passou nesta rodada (TOCAR PASTA). Não é erro do app.
- Corrigido nesta versão depois dos testes: CUE fora de ordem com o celular ocupado; arrastar a onda perdia passos (andava 0,24 s; agora 5,9 s); MIXAR AGORA podia ser esquecido (agora começa em ~8 s, no compasso seguinte).
- Medidas nesta rodada: TOCAR PASTA escolheu, carregou e mixou sozinho uma pasta de 6 músicas; MIXAR AGORA começou em 7,9 s; tela do AUTO DJ mostrou próxima, nota, motivo e 3 alternativas.

## 2. Matriz de funções
| Função | Estado | Observação |
|---|---|---|
| Reprodução, pausa, CUE (estilo CDJ), seek | EXISTENTE E MELHORADA | testado; CUE em ordem mesmo com o celular ocupado |
| Decks (2), pitch ±8/16/25/50/WIDE, key-lock, pitch bend | EXISTENTE E MELHORADA | key-lock automático só quando precisa |
| Pratos (tela e controladora) | EXISTENTE E MELHORADA | posição exata, sem atraso; BUSCA; calibração |
| Mixer: volume, EQ 3 bandas, filtro, crossfader (3 curvas), gain/auto-gain, limitador | EXISTENTE E PRESERVADA | |
| Efeitos (8 tipos, 3 encaixes por deck), ECHO OUT, FREIO, VOLTA, FILTRO AUTO, ROLL | EXISTENTE E PRESERVADA | |
| Hot cues (8, com nome), cues automáticas | EXISTENTE E PRESERVADA | |
| Loops (auto, manual, ½ e ×2 por MIDI), salto de batidas, quantize, slip, reverso, censura | EXISTENTE E PRESERVADA | |
| BPM, grade, "1" do compasso, tom (Camelot), energia | EXISTENTE E PRESERVADA | grade de andamento variável: PENDENTE |
| Stems (voz, bateria, baixo, melodia) | EXISTENTE E PRESERVADA | separação por processamento de sinal (não IA) |
| Sampler (8 pads, amostras automáticas, captura) | EXISTENTE E PRESERVADA | botão AMOSTRAR agora na aba AMOSTRAS |
| Biblioteca, busca, ordenação, playlists, HARMONIZAR | EXISTENTE E PRESERVADA | |
| Importar pasta, pastas lembradas e atualizadas | EXISTENTE E MELHORADA | sem limite de 5000 arquivos |
| Gravação (M4A + lista de músicas), histórico da noite | EXISTENTE E PRESERVADA | |
| Ondas: 3 desenhos × 5 cores, batidas do outro deck, contador de frase, breaks | EXISTENTE E MELHORADA | testado; arrastar com a música parada procura o ponto |
| AUTO DJ: escolha explicável (nota 0–100%), 11 modos, pesos | IMPLEMENTADA, AGUARDANDO VALIDAÇÃO | escolha testada; gosto musical se valida no uso |
| AUTO DJ: transições EQ, filtro, eco, stems, corte, fade, reverb, loop, drop; 4–64 batidas | EXISTENTE E MELHORADA | reverb/loop/drop novos |
| AUTO DJ: frase, sync travado, troca de graves no compasso, automação pela posição da música | EXISTENTE E MELHORADA | |
| Anti-choque de vozes | PARCIALMENTE IMPLEMENTADA | só com stems prontos nas duas músicas |
| AUTO DJ: TOCAR PASTA sozinho | IMPLEMENTADA E TESTADA | pasta de 6 músicas no emulador; qualidade musical se confirma no seu celular |
| Modo híbrido: trocar a próxima, alternativas, MIXAR AGORA, mexer à mão | IMPLEMENTADA E TESTADA | MIXAR AGORA e alternativas testados |
| Aprendizado de preferências (trocas lembradas, ESQUECER) | PARCIALMENTE IMPLEMENTADA | aprende só com TROCAR/USAR |
| Pré-escuta da próxima (OUVIR NO FONE) | EXISTENTE E PRESERVADA | precisa de fone separado (controladora/modo dividido) |
| Controladoras MIDI: mapas prontos (116), assistente, codificação AUTO | EXISTENTE E MELHORADA | controladoras só HID: BLOQUEADA (Android) |
| Proteção contra silêncio, vigia da saída de áudio (USB tirado) | EXISTENTE E PRESERVADA | |
| Backup manual + automático, restauração | EXISTENTE E MELHORADA | |
| Modo retrato | EXISTENTE E PRESERVADA | |

## 3. Pendências e limites reais
- Separação de stems por IA: BLOQUEADA POR DEPENDÊNCIA (modelo não pode ser baixado neste ambiente).
- Grade para andamento variável (gravações ao vivo): PENDENTE.
- Editor de transição em linha do tempo / exportar mix montado: PENDENTE (a GRAVAÇÃO já exporta o set tocado).
- Pré-escuta da transição inteira sem afetar o som geral: depende de saída de fone separada.
- 4 decks: PENDENTE (o motor é de 2 decks).
- Aviso "app desconhecido" do Android: depende do cadastro de desenvolvedor no Google (conta do usuário).
