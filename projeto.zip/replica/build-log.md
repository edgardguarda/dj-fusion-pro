# Registro de construção

Regra deste projeto: um recurso só vira `yes` em `features.csv` depois de rodar de verdade no aparelho. Por enquanto nenhum está assim, porque o app ainda não foi instalado em nenhum celular.

## Marco M0 e M1: base e primeira versão (código escrito)

| parte | estado | como foi verificado |
| --- | --- | --- |
| Motor de áudio C++ (2 decks, crossfader, volumes, master, cue, seek, fim da faixa) | feito | 94 testes do motor + 225.622 verificações extras, com AddressSanitizer, UBSan e ThreadSanitizer |
| Callback de áudio sem alocar memória | feito | teste que conta alocações em 2.000 chamadas de render: zero |
| Conversor de taxa 44,1/96 kHz para 48 kHz | feito | erro máximo de 0,00004 em 44,1 para 48 kHz; tom de 40 kHz some em 96 para 48 kHz |
| Picos da waveform por faixa de frequência | feito | graves, médios e agudos separados em testes com tons de 60 Hz, 1 kHz e 9 kHz |
| Ponte JNI Kotlin e C++ | feita | 24 funções com nomes e tipos conferidos por script, e teste numa JVM real com `-Xcheck:jni` |
| Saída de áudio com Oboe | escrita | **não testada**: só compilada contra um Oboe falso que imita a API de memória |
| Decodificador (MediaCodec) | escrito | **não testado**: precisa de um Android |
| Telas Compose, ViewModel, biblioteca (SQLite) | escritas | **não compiladas nem rodadas**: sem Android SDK neste ambiente |
| Projeto Gradle, manifesto, ícone, CI | escritos | **não compilados**; o primeiro APK vai mostrar erros que só o compilador acha |

## Problemas achados e corrigidos nesta etapa

- **Carregar uma faixa era quadrático.** `reserve()` a cada bloco copiava o áudio inteiro de novo: 27,8 s para 4 minutos, e perto do limite de 15 minutos o app cairia. Agora 0,65 s. Há teste de regressão.
- **Falta de memória atravessando o JNI** derrubaria o app. Agora vira "faixa grande demais".
- **Memória nativa vazava** se o carregamento fosse cancelado no último instante.
- **Estado velho do motor** sobrevivia se a tela fosse fechada e reaberta com o processo vivo.
- **Tocar durante o carregamento** podia cortar o som; agora play e cue ficam desabilitados.
- **Falha de carregamento** apagava título e artista do deck; agora restaura.
- **Botões A e B da biblioteca** disparavam ao encostar, atrapalhando a rolagem; agora só no toque completo.
- **Sem serviço em primeiro plano**, o app agora pausa os decks e fecha o áudio ao sair da tela, e reabre ao voltar.

## Decisões

- A biblioteca da v1 usa o SQLite do próprio Android (tabela `tracks`), sem Room. O restante do `schema.sql` entra quando for preciso (playlists, timeline).
- O motor guarda cada faixa em 16 bits estéreo a 48 kHz, com limite de 15 minutos (cerca de 173 MB por faixa).
- Revisão do Kotlin feita por leitura independente, porque não há compilador aqui. Ela não achou erro de compilação, mas isso não garante nada até o primeiro build.

## O que falta para a v1 estar pronta de verdade

1. Compilar o APK (o ambiente daqui não alcança os servidores do Google).
2. Instalar no POCO X7 Pro e ouvir: importar, tocar nos dois decks, crossfader, cue, volume.
3. Medir latência e estabilidade do áudio no HyperOS.
4. Só então marcar os recursos como `yes`.

## Marco M2 e M4 parcial: EQ, filtro, pitch, sync, loops, hot cues e BPM (código escrito)

| parte | estado | como foi verificado |
| --- | --- | --- |
| EQ de 3 bandas (prateleira 200 Hz, pico 1 kHz, prateleira 4,5 kHz) | motor testado | neutro idêntico ao original; corte de -40 dB; +6 dB no máximo; interferência entre bandas menor que 1,5 dB |
| Filtro de DJ (passa-baixas e passa-altas) | motor testado | agudos e graves cortados em mais de 20 dB nos extremos; zona morta central exata |
| Pitch de 0,5x a 2x (interpolação cúbica) | motor testado | frequência e posição seguem a velocidade com erro menor que 0,1% |
| Loop | motor testado | fica preso no trecho, solta ao limpar, some ao carregar outra faixa |
| Detecção de BPM e primeira batida | testada com música sintética | 100, 120, 123,5, 128, 140, 150 e 174 BPM com erro menor que 0,01 BPM e batida a menos de 5 ms |
| Sem alocação no callback e sem corrida de threads | verificado | os mesmos testes de antes, agora com os comandos novos |
| Telas, banco (versão 2) e lógica de sync, loop e hot cue | escritas | **não compiladas nem rodadas** |

Limites conhecidos desta etapa: o pitch muda o tom junto (sem time-stretch); a detecção de BPM pode errar por uma oitava em algumas músicas (há botões ÷2 e ×2); o SYNC iguala o andamento e a batida uma vez, sem seguir mudanças; o loop não suaviza a emenda.

## Rodada de estabilidade e visual (2026-11-12)
- Áudio: buffer Oboe inicial de 4 rajadas, cresce sozinho a cada underrun; seno/cosseno do crossfader só quando ele se mexe; decodificação e análise em prioridade de segundo plano.
- Interface: posição e nível lidos só na hora de desenhar (sem recompor a tela 30x/s); ondas rolantes com grade de batidas e marcas; vinil com camada giratória de GPU; knobs de EQ/filtro; pads com cor. Ainda NÃO testado em aparelho.

## Lote profissional (2026-11-12, noite)
- Layout refeito no estilo Cross DJ/edjing: discos grandes, barra inferior CUE/PLAY/SYNC, crossfader no centro, TEMPO nas laterais, pads (hot cue, loop, efeitos) em painel por deck.
- Controladora: MidiHub (android.media.midi), tela CONTROLADORA com monitor, assistente e MIDI Learn. Sem mapa de fábrica da DJ2GO2: os números de nota/CC não são publicados na documentação do Mixxx, então o usuário ensina cada controle.
- Efeitos por deck (eco na batida, flanger, reverb) no motor C++, com testes. Pendente: key-lock (mudar andamento sem mudar o tom), scratch no disco, saída de fone (cue) pela placa da DJ2GO2.
- Biblioteca: BPM por faixa e ordenação por BPM.

## Revisão geral do código (2026-11-13)
Achados e correções:
- Motor: soma dos dois decks podia passar de 1.0 e cortar seco -> limitador suave (teste novo: nunca passa de 1.0, não amassa, não corta).
- Motor: NaN vindo da interface (volume, EQ, filtro, efeito) contaminava filtro/eco para sempre -> clamp01 troca NaN por 0 (teste novo).
- Áudio: números denormais em ARM causam engasgos -> flush-to-zero na thread de áudio (FPCR.FZ); buffer inicial de 6 rajadas, crescendo a cada underrun.
- Ponte JNI: nativeAppend agora confere offset/tamanho contra a capacidade do buffer direto.
- Decodificador: saída de segurança se o MediaCodec parar de responder depois do fim da entrada.
- ViewModel: a referência nativa da faixa agora é solta em finally (antes vazava se a carga fosse cancelada durante a análise).
- MIDI: abertura duplicada do mesmo aparelho (mensagens em dobro) impedida.
Testes: nativos 94+225622+225622+81 verificações, JNI OK. Compilação no Codemagic (build com todo o pacote anterior) passou; nada disso foi ouvido/visto num aparelho.

## Key-lock, scratch e fone (2026-11-13)
- Key-lock: esticamento por grãos (janela de Hann 2048, salto 1024, busca de fase por correlação). Teste: tom 440 Hz medido em 0,8x, 1,0x, 1,25x e 1,5x fica em 440 Hz; sem key-lock a 1,25x vai a 550 Hz.
- Scratch: comando de velocidade; segura o disco, anda para trás, sem nível DC quando a mão para, limites do início e do fim. Gesto no prato: ângulo do dedo -> velocidade (uma volta = 1,8 s).
- Fone (PFL): barramento antes do fader e do crossfader, com volume e mix cue/master; não altera o som geral (teste bit a bit). Saída: normal, dividida (E fone, D geral) ou 4 canais (1-2 geral, 3-4 fone), com queda automática se a placa não abrir 4 canais. Escolha da placa USB na aba CONTROLADORA.
- Não verificado: som real no aparelho; como a DJ2GO2 Touch expõe seus canais ao Android (se aceita 4 canais ou só estéreo).
