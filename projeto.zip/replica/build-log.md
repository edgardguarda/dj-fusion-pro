# Registro de construção

Regra deste projeto: um recurso só vira `yes` em `features.csv` depois de rodar de verdade no aparelho. Por enquanto nenhum está assim, porque o app ainda não foi instalado em nenhum celular.

## Marco M0 e M1: base e primeira versão (código escrito)

| parte | estado | como foi verificado |
| --- | --- | --- |
| Motor de áudio C++ (2 decks, crossfader, volumes, master, cue, seek, fim da faixa) | feito | 94 testes do motor + 225.622 verificações extras, com AddressSanitizer, UBSan e ThreadSanitizer |
| Callback de áudio sem alocar memória | feito | teste que conta alocações em 2.000 chamadas de render: zero |
| Conversor de taxa 44,1/96 kHz para 48 kHz | feito | erro máximo de 0,00004 em 44,1 para 48 kHz; tom de 40 kHz some em 96 para 48 kHz |
| Picos da waveform por faixa de frequência | feito | graves, médios e agudos separados em testes com tons de 60 Hz, 1 kHz e 9 kHz |
| Ponte JNI Kotlin e C++ | feita | 24 funções com nomes e tipos conferidos por script, e teste numa JVM real com `-Xcheck:jni` |
| Saída de áudio com Oboe | escrita | **não testada**: só compilada contra um Oboe falso que imita a API de memória |
| Decodificador (MediaCodec) | escrito | **não testado**: precisa de um Android |
| Telas Compose, ViewModel, biblioteca (SQLite) | escritas | **não compiladas nem rodadas**: sem Android SDK neste ambiente |
| Projeto Gradle, manifesto, ícone, CI | escritos | **não compilados**; o primeiro APK vai mostrar erros que só o compilador acha |

## Problemas achados e corrigidos nesta etapa

- **Carregar uma faixa era quadrático.** `reserve()` a cada bloco copiava o áudio inteiro de novo: 27,8 s para 4 minutos, e perto do limite de 15 minutos o app cairia. Agora 0,65 s. Há teste de regressão.
- **Falta de memória atravessando o JNI** derrubaria o app. Agora vira "faixa grande demais".
- **Memória nativa vazava** se o carregamento fosse cancelado no último instante.
- **Estado velho do motor** sobrevivia se a tela fosse fechada e reaberta com o processo vivo.
- **Tocar durante o carregamento** podia cortar o som; agora play e cue ficam desabilitados.
- **Falha de carregamento** apagava título e artista do deck; agora restaura.
- **Botões A e B da biblioteca** disparavam ao encostar, atrapalhando a rolagem; agora só no toque completo.
- **Sem serviço em primeiro plano**, o app agora pausa os decks e fecha o áudio ao sair da tela, e reabre ao voltar.

## Decisões

- A biblioteca da v1 usa o SQLite do próprio Android (tabela `tracks`), sem Room. O restante do `schema.sql` entra quando for preciso (playlists, timeline).
- O motor guarda cada faixa em 16 bits estéreo a 48 kHz, com limite de 15 minutos (cerca de 173 MB por faixa).
- Revisão do Kotlin feita por leitura independente, porque não há compilador aqui. Ela não achou erro de compilação, mas isso não garante nada até o primeiro build.

## O que falta para a v1 estar pronta de verdade

1. Compilar o APK (o ambiente daqui não alcança os servidores do Google).
2. Instalar no POCO X7 Pro e ouvir: importar, tocar nos dois decks, crossfader, cue, volume.
3. Medir latência e estabilidade do áudio no HyperOS.
4. Só então marcar os recursos como `yes`.

## Marco M2 e M4 parcial: EQ, filtro, pitch, sync, loops, hot cues e BPM (código escrito)

| parte | estado | como foi verificado |
| --- | --- | --- |
| EQ de 3 bandas (prateleira 200 Hz, pico 1 kHz, prateleira 4,5 kHz) | motor testado | neutro idêntico ao original; corte de -40 dB; +6 dB no máximo; interferência entre bandas menor que 1,5 dB |
| Filtro de DJ (passa-baixas e passa-altas) | motor testado | agudos e graves cortados em mais de 20 dB nos extremos; zona morta central exata |
| Pitch de 0,5x a 2x (interpolação cúbica) | motor testado | frequência e posição seguem a velocidade com erro menor que 0,1% |
| Loop | motor testado | fica preso no trecho, solta ao limpar, some ao carregar outra faixa |
| Detecção de BPM e primeira batida | testada com música sintética | 100, 120, 123,5, 128, 140, 150 e 174 BPM com erro menor que 0,01 BPM e batida a menos de 5 ms |
| Sem alocação no callback e sem corrida de threads | verificado | os mesmos testes de antes, agora com os comandos novos |
| Telas, banco (versão 2) e lógica de sync, loop e hot cue | escritas | **não compiladas nem rodadas** |

Limites conhecidos desta etapa: o pitch muda o tom junto (sem time-stretch); a detecção de BPM pode errar por uma oitava em algumas músicas (há botões ÷2 e ×2); o SYNC iguala o andamento e a batida uma vez, sem seguir mudanças; o loop não suaviza a emenda.

## Rodada de estabilidade e visual (2026-11-12)
- Áudio: buffer Oboe inicial de 4 rajadas, cresce sozinho a cada underrun; seno/cosseno do crossfader só quando ele se mexe; decodificação e análise em prioridade de segundo plano.
- Interface: posição e nível lidos só na hora de desenhar (sem recompor a tela 30x/s); ondas rolantes com grade de batidas e marcas; vinil com camada giratória de GPU; knobs de EQ/filtro; pads com cor. Ainda NÃO testado em aparelho.

## Lote profissional (2026-11-12, noite)
- Layout refeito no estilo Cross DJ/edjing: discos grandes, barra inferior CUE/PLAY/SYNC, crossfader no centro, TEMPO nas laterais, pads (hot cue, loop, efeitos) em painel por deck.
- Controladora: MidiHub (android.media.midi), tela CONTROLADORA com monitor, assistente e MIDI Learn. Sem mapa de fábrica da DJ2GO2: os números de nota/CC não são publicados na documentação do Mixxx, então o usuário ensina cada controle.
- Efeitos por deck (eco na batida, flanger, reverb) no motor C++, com testes. Pendente: key-lock (mudar andamento sem mudar o tom), scratch no disco, saída de fone (cue) pela placa da DJ2GO2.
- Biblioteca: BPM por faixa e ordenação por BPM.

## Revisão geral do código (2026-11-13)
Achados e correções:
- Motor: soma dos dois decks podia passar de 1.0 e cortar seco -> limitador suave (teste novo: nunca passa de 1.0, não amassa, não corta).
- Motor: NaN vindo da interface (volume, EQ, filtro, efeito) contaminava filtro/eco para sempre -> clamp01 troca NaN por 0 (teste novo).
- Áudio: números denormais em ARM causam engasgos -> flush-to-zero na thread de áudio (FPCR.FZ); buffer inicial de 6 rajadas, crescendo a cada underrun.
- Ponte JNI: nativeAppend agora confere offset/tamanho contra a capacidade do buffer direto.
- Decodificador: saída de segurança se o MediaCodec parar de responder depois do fim da entrada.
- ViewModel: a referência nativa da faixa agora é solta em finally (antes vazava se a carga fosse cancelada durante a análise).
- MIDI: abertura duplicada do mesmo aparelho (mensagens em dobro) impedida.
Testes: nativos 94+225622+225622+81 verificações, JNI OK. Compilação no Codemagic (build com todo o pacote anterior) passou; nada disso foi ouvido/visto num aparelho.

## Key-lock, scratch e fone (2026-11-13)
- Key-lock: esticamento por grãos (janela de Hann 2048, salto 1024, busca de fase por correlação). Teste: tom 440 Hz medido em 0,8x, 1,0x, 1,25x e 1,5x fica em 440 Hz; sem key-lock a 1,25x vai a 550 Hz.
- Scratch: comando de velocidade; segura o disco, anda para trás, sem nível DC quando a mão para, limites do início e do fim. Gesto no prato: ângulo do dedo -> velocidade (uma volta = 1,8 s).
- Fone (PFL): barramento antes do fader e do crossfader, com volume e mix cue/master; não altera o som geral (teste bit a bit). Saída: normal, dividida (E fone, D geral) ou 4 canais (1-2 geral, 3-4 fone), com queda automática se a placa não abrir 4 canais. Escolha da placa USB na aba CONTROLADORA.
- Não verificado: som real no aparelho; como a DJ2GO2 Touch expõe seus canais ao Android (se aceita 4 canais ou só estéreo).

## v6 (2026-11-13) — Camelot, AUTO DJ, amostras automáticas, jog
- Motor: detecção de tom (core/key.h), escolha de amostras (core/samples.h), sampler de 8 pads, partida sincronizada por fase (playSynced). Testes Linux: tom 24/24, amostras, alinhamento 10/10 dentro de 0,5 ms. Suíte nativa + JNI (com Oboe falso) passam.
- App: chips de tom, roda de Camelot, ordenação por tom, ANALISAR, aba AMOSTRAS, botões AUTO DJ e AMOSTRAR, jog por MIDI Learn com sensibilidade ajustável.
- Não verificado: compilação do Kotlin novo (primeiro build é o teste), comportamento no POCO X7 Pro, números MIDI do jog da DJ2GO2.

## v8 (2026-11-13) — decks maiores, DJ2GO2 de fábrica, teste no emulador
- Tela DJ LIVE refeita: prato ~25% maior, transporte embaixo de cada deck, crossfader alinhado, visor de tempo/BPM/tom.
- Mapa de fábrica da Numark DJ2GO2 Touch (números do mapeamento oficial do Mixxx), aplicado sozinho ao conectar.
- AUTO DJ analisa sozinho a biblioteca; botões avisam o que falta quando o deck está vazio.
- Teste de ponta a ponta no emulador (GitHub Actions, tela 2712x1220 como o POCO X7 Pro): importar, analisar, carregar, play/pause, cue, sync, key-lock, fone, faders, knobs, crossfader, scratch, hot cue, loop, efeitos, amostras, AUTO DJ e controladora. Fotos e APK saem na release "e2e-ultimo".
- Bugs achados pelo teste e corrigidos: knob de filtro cortado, scratch perdendo movimento com eventos no mesmo instante, faixa duplicada ao importar arquivo e pasta.

## v10 (2026-11-13) — stems, tom, slip, reverso, auto-gain
- Motor: stems por STFT (HPSS + centro estéreo), ganho por stem com som original bit a bit quando todos em 1; mudança de tom por grãos (WSOLA) sem mudar o andamento; ganho de entrada (trim) e medição de volume. Testes nativos e JNI passam.
- Bug do teste corrigido: a "voz" sintética tinha vibrato errado (frequência subindo sem parar).
- Bug corrigido: ÷2/×2 do BPM apagava tom e energia salvos.
- App: painel STEMS, ♭/TOM/♯, SLIP, REV, CENS, grade ◀▶, AUTO GAIN. Separação começa sozinha ao carregar (barra de progresso no prato).
- Não verificado: tempo de separação e qualidade no POCO X7 Pro com músicas reais.

## v11 (2026-11-13) — assinatura fixa, playlists, AUTO DJ mais inteligente
- APK assinado sempre com a mesma chave (app/assinatura-edgard.p12): as próximas versões instalam por cima, sem perder a biblioteca. versionCode 11.
- Stems protegidos: só até 12 min e só se sobrarem 300 MB livres; senão o painel avisa "indisponíveis".
- Controladora: modo PADS PERFORMANCE (hot cue = VOZ/BATERIA/BAIXO/MELODIA, loop = SLIP/REVERSO/CENSURA/TOM) e 15 funções novas para ENSINAR.
- Tom ajustado fica salvo por música.
- AUTO DJ: termina a transição no fim musical (ignora fade-out/silêncio; testado com kotlinc) e, com stems nas duas músicas, troca vozes e baixos no meio.
- Playlists com nome: salvar, abrir, apagar, + / − por música.
- Motor: carregar música solta o prato (scratch/reverso).

## v12 (2026-11-13) — controladora de verdade, saída dupla, músicas que não carregavam
- DJ2GO2 Touch: mapa refeito com os números do mapeamento oficial do Mixxx (conferido 22/22 com bytes reais):
  4 modos de pad (CUES com apagar segurando PAD MODE, AUTO LOOP, MANUAL LOOP com IN/OUT/RELOOP/início, SAMPLER),
  BROWSE e LOAD A/B, mensagem de início (sysex) e LEDs acesos pelo app. O mapa novo entra sozinho em quem tinha o antigo.
- Saída: dava para tocar só na saída padrão (com a controladora ligada, só nela). Agora escolhe a saída principal
  (controladora, alto-falante, fone com fio, Bluetooth) e uma segunda saída que toca junto (som geral ou pré-escuta).
  Com a DJ2GO2 o fone dela já liga sozinho (4 canais: MAIN = geral, fone = pré-escuta).
- Carregar música: WAV de 8, 24 e 32 bits passam a funcionar; tenta o decodificador de software do Android antes do
  do fabricante e, se um falhar, o próximo; abre pelo descritor quando o provedor recusa; a mensagem diz a causa.
- Sampler: 8 sons prontos (buzina, sirene, laser, 808, palma, subida, descida, explosão) desde o início.
- Efeitos mais fortes + TRANS e BITCRUSH; teste mede que cada efeito muda o som.
- Pads da tela por modos (CUES, LOOP com IN/OUT, SAMPLER, MANOBRAS), como na controladora.
- CONTROLADORA: último controle acionado, LEVEL = volume ou filtro, força do ajuste fino, relatório de diagnóstico.

## v13 (2026-11-13) — correções pelo relatório do POCO X7 Pro (Android 16)
- Relatório real: MP3 decodificado pelo Android (46 MB de áudio) mas "áudio vazio" no motor, nos dois decodificadores
  do aparelho. Solução: decodificador próprio (dr_mp3/dr_flac/dr_wav, domínio público) lendo direto do arquivo,
  usado primeiro para MP3, FLAC e WAV (8/16/24/32 bits); o do Android fica de reserva (AAC, OGG...).
  Testado: MP3 estéreo/mono, FLAC, WAV 8/24/32f (ASan), pela ponte JNI e no emulador.
- Relatório real: mapa da controladora alterado por ENSINAR (tempo A ligado ao prato B). Agora o mapa de fábrica
  é reaplicado toda vez que a DJ2GO2 liga.
- Confirmado no aparelho: botões, pads, fone, crossfader e jog chegam; saída em 4 canais na DJ2GO2 + alto-falante.

## v14 (2026-11-13) — CAUSA REAL de "nenhuma música carrega" no POCO
- No ARM com Android 11+ os ponteiros têm etiqueta no byte mais alto (Top-Byte Ignore / Memory Tagging). O
  identificador da faixa, convertido para Long, fica NEGATIVO. O app tratava "<= 0" como falha: a música era
  decodificada inteira e descartada, e o app tentava o próximo decodificador (o carregamento "reiniciava").
  No emulador x86 não há etiqueta, por isso os testes passavam. Corrigido: só 0 e -1 são códigos de erro.
- Teste novo (tests/check_handles.py) proíbe comparar identificadores nativos com > 0 / <= 0.

## v15 (2026-11-13) — pitch profissional, SYNC travado, AUTO DJ preciso, ROLL, PHASER
- Confirmado pelo usuário: música toca no POCO X7 Pro (v14).
- Pitch: faixa ±6/±8/±10/±16/±25/±50 %, leitura com 2 casas, pitch bend (segurar −/+), reset ao tocar no valor.
  SYNC abre a faixa sozinho se precisar.
- SYNC travado: segue o andamento e corrige a fase ~30x/s (teste: empurrar 0,2 batida e a trava traz de volta).
- AUTO DJ: trava de fase em toda a mixagem; a música que entra começa depois da introdução (num compasso);
  estilos escolhíveis (automático, graves, filtro, eco, stems, corte seco), duração 8/16/32 e tom automático
  (até ±2 semitons quando os tons chocam).
- Efeitos: PHASER (no ritmo) e divisão de batida (1/4 a 2) para eco/trans/phaser. Pad mode ROLL (1/8 a 1 batida,
  volta no ponto). Medidor de fase das batidas na mesa.

## v16 (2026-11-14) — carregamento rápido, visor e AutoMix no padrão VirtualDJ
- Carregamento: a música fica tocável assim que é decodificada; andamento, tom, energia e volume são analisados
  depois, em segundo plano (deck mostra "…" no BPM). Memória da faixa reservada de uma vez (FLAC/WAV).
  Decodificação: 6 min de MP3 em ~1,3 s (PC de teste).
- Visor do deck: BPM com 2 casas, TAP (4+ toques), tempo tocado/restante (toque), tom Camelot/letras (toque).
- AUTO DJ (como o AutoMix do VirtualDJ): tipos Inteligente, Fade (sem silêncio) e Sem mixagem, MIXAR AGORA
  (próximo compasso), andamento mantém/volta a 0%, lista das próximas, ligar/parar no painel.
- Correção: rótulo FILTRO cortado na mesa (medidor de fase e knobs menores).
- v15 confirmada no emulador: 62/62 (SYNC travado: fase 0,004 batida; corrige 0,2 batida para 0,009).

## v17 (1.7.0)
- Latência escolhível (BAIXA/NORMAL/SEGURA) no motor e na tela nova AJUSTES.
- Lista de músicas fixa na tela DJ (botão ☰ LISTA), ordenada pelo assistente, com A/B e BROWSE da controladora.
- Visão geral da onda mostra hot cues e a região do loop.
- QUANTIZE (botão Q e em AJUSTES): cues e loops caem na batida; salto de hot cue mantém a fase.
- Tela AJUSTES: saída de áudio (saiu da CONTROLADORA), latência, quantize e visor (tom em letras, tempo restante).
- Correção: anotação @Composable fora do lugar em HarmonyUi (quebraria a compilação).

## v18 (1.8.0)
- Logotipo oficial (EG) no ícone do app (adaptativo, fundo branco), na barra de cima, no centro dos pratos e em AJUSTES › SOBRE.
- Avisos da tela DJ na barra de cima (não cobrem mais as ondas nem os botões LISTA/Q).
- Abas dos pads com largura proporcional (MANOBRAS não corta).
- Trocar latência muda só o buffer, sem reabrir o som.
- CI publica o log de compilação (compilacao.txt).

## v19 (1.9.0)
- Console sempre cabe na tela: escala própria (986×443 dp) independente de "tamanho da exibição", fonte e recorte da câmera. E2E roda com densidade 520 e fonte 1,15 e confere que nenhum botão sai da tela.
- Pitch: faixas ±8, ±16 (padrão), ±25, ±50 e WIDE ±100% (motor 0..2×); faixa padrão em AJUSTES.
- Amostras: loops escolhidos por força + repetição (emendam sem salto), golpes presos na batida; depois de GERAR, cada música nova troca os pads do seu deck.
- AUTO DJ: mixa por cima da saída da música (onde os graves somem), a que entra chega na parte cheia no fim da mixagem, troca de graves no compasso do meio em 1 batida, médios da que sai mais baixos, stems sempre que prontos, eco curto se a grade for duvidosa, penalidade forte para andamento esticado acima de 6%.

## v20 (2.0.0)
- Visual estilo Serato/VirtualDJ: botões, painéis, knobs e faders escuros e planos (fim da prata escovada).
- Ondas coloridas pelo espectro (graves vermelho, médios verde, agudos azul) na onda rolante e na visão geral; frase de 16 batidas marcada na cor do deck; marca de CUE laranja; zoom com toque duplo (3/5/8/12/20 s).
- Prato virtual novo: disco escuro, anel de progresso (pisca vermelho nos últimos 30 s), marcador que gira, ponto do CUE, borda empurra/segura (pitch bend), meio faz scratch; modo VINIL (chip e AJUSTES), também na controladora.
- CUE como CDJ/Serato: parado marca (com quantize) e toca enquanto segura; soltar volta; PLAY durante a prévia continua. CUE da controladora também segura. PLAY com LED verde.
- Ícone com fundo escuro e logotipo claro; abertura (splash) no fundo da marca; logotipo maior na barra.
- SYNC travado corrige a fase mais rápido (ganho 1,2/s, até 3,5%).

## v21 (2.1.0)
- 8 hot cues por música (2 fileiras, 8 cores); hot cue 7 = ENTRADA e 8 = SAÍDA para o AUTO DJ.
- Deck A vermelho, deck B azul.
- Modos de pads novos: SALTO (1–32 batidas) e GRADE (◀▮ ▮▶, 1 AQUI, TAP, BPM ±0,1/±0,01). MANOBRAS ganhou DUPLA (instant double) e CAPTURA (compasso vira loop num pad).
- Detecção do "1" do compasso na análise; ajuste de grade mantém o compasso.
- Efeitos novos: FILTRO LFO e WOBBLE (tela EFEITOS).
- Gravação vira M4A (AAC 256 kbps) + lista das músicas com horários em Documentos; histórico da noite em AJUSTES.
- AUTO DJ: curva de energia (livre, aquecer, ondas, fechar) e pontos de mixagem manuais.
- Backup/restauração (biblioteca, grades, cues, playlists, ajustes).
- Modo retrato opcional com tela compacta.

## v22 (2.2.0)
- Os botões de baixo (CUE/PLAY) ficam fora da faixa de gestos do sistema: toque demorado no CUE não abre mais "apps recentes" (achado no teste: o app ia para segundo plano e parava).

## v23 (2.3.0)
- Margem fixa de 22 dp embaixo (o sistema não informa a faixa de gestos com as barras escondidas; o teste mostrou toques no PLAY indo para "recentes").

## v24 (2.4.0)
- Até 3 efeitos ao mesmo tempo por deck (encaixes FX1, FX2, FX3 em série), na tela DJ e em EFEITOS; botão DESLIGA zera os 3.
- Curva do crossfader: SUAVE, MIXAGEM (as duas cheias no meio) e CORTE (scratch), em AJUSTES › MIXAGEM.
- Cues automáticas: ao carregar uma música sem cues, as hot cues 1–4 marcam INÍCIO, GROOVE, DROP e SAÍDA (na batida). Botão CUES AUTO no menu da hot cue.
- Nomes nas hot cues: segurar o pad abre o menu (INTRO, VERSO, REFRÃO, PONTE, BREAK, DROP, VOZ, SAÍDA, sem nome, apagar). O nome aparece no pad e na onda.
- Proteção contra silêncio: se a música do ar chegar ao fim com o outro deck parado (sem AUTO DJ), o último compasso entra em loop no tempo.
- Diferença de BPM para o outro deck no visor (verde quando bate, amarelo perto, vermelho longe).
- Músicas que já foram ao ar ficam marcadas com ✓ na biblioteca e no navegador.
- Teste no emulador: volta ao app depois de uma falha (seletor de arquivos aberto não derruba os passos seguintes).

## v25 (2.5.0)
- Pratos sem atraso: o jog da controladora e o prato da tela movem a música por posição (o motor leva a agulha ao ponto em ~10 ms e para quando a mão para); antes a velocidade era estimada e seguia 90 ms depois de soltar. Mensagens do prato são tratadas na linha do MIDI, sem esperar a tela.
- Empurrão do prato proporcional ao giro (uma volta = 0,3 s); modo BUSCA (prato corre 20× mais rápido, sem som); calibração de passos por volta; codificação do prato (complemento de 2, centro 64, sinal, absoluto) para qualquer controladora.
- Folga do áudio menor em placas USB (rajadas grandes pedem menos rajadas): a controladora responde mais rápido.
- Avisos de modo da controladora (mesma nota fraca em dois canais, sem soltar) são ignorados; ENSINAR não aprende nota fraca; o SLIP preso na nota 0 do canal 5 da DJ2GO2 sai do mapa.
- Controles novos para mapear: BUSCA, empurrar/segurar, pitch 0%, loop ½ e ×2, hot cues 5–8, encaixe de efeito, desliga efeitos, cues automáticas, ECHO OUT, FREIO.
- Ondas: batidas do outro deck em triângulos embaixo (casar a batida de olho), compasso.batida e contagem até a próxima frase, loop sombreado, faixa de graves/breaks na visão geral, arrastar a onda (parado procura, tocando empurra).
- APK final sem modo de depuração (release), assinado com a mesma chave.

## v26 (2.6.0)
- Tirar e colocar a controladora não deixa mais o som mudo: a saída reabre numa linha própria esperando a vez (antes desistia se o app mexia na saída no mesmo instante) e um vigia reabre o som se ele parar por 2 s.
- Ondas em VERMELHO (padrão), CINZA ou ESPECTRO (AJUSTES › TELA); ajustes do visor agora ficam guardados.
- AJUSTES e CONTROLADORA reorganizados por assunto (menu à esquerda, um assunto por vez).
- MAPEAR: assistente ESSENCIAL (só o que toda controladora tem), lista por grupos, PULAR não volta mais ao mesmo controle.
- Biblioteca: IMPORTAR PASTA em destaque; pastas lembradas e atualizadas sozinhas ao abrir (ATUALIZAR PASTAS); sem limite de 5000 arquivos/8 subpastas; músicas de pasta usam a permissão da pasta (o Android só guarda 512 permissões por app).
- Duração máxima de faixa pela memória do aparelho (até 120 min); stems até 30 min.
- AUTO DJ: automação segue a posição da música que entra (cada compasso da mixagem cai no compasso da música), loop no final da que sai se ela acabaria antes da mixagem, AUTO-GAIN ligado, não repete artista em seguida.

## v27 (2.7.0)
- Proteção: ponto de restauração 2.6.0 no GitHub (restauracao/: APK, código completo e histórico git, conferidos byte a byte); backup automático dos dados ao abrir o app (5 últimos + cópia em Documentos), lista para restaurar em AJUSTES › BACKUP; backup inclui mapa da controladora e pastas.
- AUTO DJ: tela própria (aba AUTO DJ) com a próxima música, nota de compatibilidade 0–100% e o porquê, transição planejada, alternativas (USAR/TROCAR PRÓXIMA), OUVIR NO FONE; 11 modos (automático, inteligente, harmônico, por BPM, energia, festa, lounge, rádio, progressivo, criativo, personalizado com pesos); transições novas REVERB, LOOP e DROP; durações 4 e 64; anti-choque de vozes (com stems); aprendizado das trocas (com ESQUECER); TOCAR PASTA toca e mixa uma pasta sozinho; key-lock só quando a velocidade muda mais de 2% (no 0% fica desligado: som mais puro).
- Ondas: 3 desenhos (RGB, 3 BANDAS, CONTORNO) × 5 cores (vermelho, cinza, espectro, azul gelo, âmbar).
- Reprodução: folga mínima do áudio (12/24/60 ms) contra estalos com stems, key-lock e efeitos juntos.
- Controladoras: 116 mapas prontos (números dos mapas públicos do Mixxx), aplicados sozinhos pelo nome do aparelho; busca e USAR em CONTROLADORA; prato com codificação AUTO.
- Ícone do app centralizado com margem (fundo grafite em degradê, versão redonda e monocromática); logotipo da barra mais limpo.
- Aba AUTO DJ no lugar do painel dentro de EFEITOS; AMOSTRAR fica na aba AMOSTRAS.

## v28 (2.8.0)
- Diagnóstico de 14/11 14:38: SYNC apertado nos dois decks fazia um seguir o outro e o outro seguir o primeiro (os dois se perseguiam); agora só um segue e o outro vira MESTRE. Tom de montagem/medley saía vazio: agora mostra o tom provável com "?" (nunca usado como certo). Soltar do aviso de modo da DJ2GO2 não aparece mais como "(nenhum controle)". Diagnóstico mostra BPM com confiança, pitch, SYNC e andamento variável.
- GRADE INTELIGENTE: músicas que mudam de andamento (montagens como "Montagem Antena1", medleys, ao vivo) têm o andamento medido ao longo da faixa (janelas de 16 s); a grade troca no ponto certo de cada trecho, e SYNC, loops, saltos e o AUTO DJ seguem o trecho. Guardado para não medir de novo; correção à mão desliga para aquela música; liga/desliga em AJUSTES › MIXAGEM.
- Efeitos novos com som de verdade: TREMOLO, DELAY L/R (pingue-pongue), STUTTER e RUÍDO (riser) — 12 efeitos, 3 encaixes por deck.
- Biblioteca: gênero lido da etiqueta do arquivo (também das músicas antigas, em segundo plano), busca por gênero, ★ FAVORITAS e DUPLICADAS (mostra, nunca apaga sozinho). Banco de dados v6 só acrescenta colunas.
- AUTO DJ: 12º modo POR GÊNERO, peso do gênero no PERSONALIZADO e no INTELIGENTE; 11 perfis de energia (LIVRE, PROGRESSIVO, ONDAS, FECHAR, RELAXADO, SUAVE, EQUILIBRADO, FESTA, ALTA ENERGIA, PICO DE PISTA, PERSONALIZADO) que escolhem as músicas (nunca mexem no volume); transição curta em músicas de andamento variável.

## v29 (2.9.0)
- Auditoria: achado e corrigido o atraso do AUTO DJ para entrar (o ponto de entrada era recalculado a cada conferência; se a conferência passasse do compasso, pulava para o seguinte — MIXAR AGORA levou 29,7 s no teste da 2.8.0, e o mesmo podia atrasar a entrada normal perto do fim da música). Agora o ponto é travado 1,5 s antes e a posição é lida direto do motor.
- Modo dividido no alto-falante do celular (visto no diagnóstico de 14/11): um lado tocava a pré-escuta para todos. Sem fone/caixa/controladora, toca normal; o modo dividido volta sozinho quando ligar um.
- GRADE INTELIGENTE desligada devolve a grade geral aos decks; o mapa de andamento entra no backup.
- Novo: FILA do AUTO DJ (botão ▶▶ na biblioteca: "tocar em seguida"), PARAR SOZINHO depois de 5/10/20/40 músicas, LISTAS INTELIGENTES (regras de BPM, energia, gênero, favoritas, não tocadas; atualizam sozinhas ao abrir).
