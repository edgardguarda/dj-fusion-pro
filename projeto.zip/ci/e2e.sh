#!/usr/bin/env bash
# Roda no emulador do GitHub Actions: instala o app e o teste, usa o app de ponta a ponta e junta fotos e relatório.
set -x
mkdir -p e2e
adb shell settings put global hide_error_dialogs 1
adb shell wm density 440
sleep 45   # deixa o sistema do emulador terminar de iniciar (evita "launcher não está respondendo")
adb shell wm size
APK=$(ls fonte/app/build/outputs/apk/debug/*.apk | head -1)
TAPK=$(ls fonte/app/build/outputs/apk/androidTest/debug/*.apk | head -1)
adb install -r -g "$APK"
adb install -r -g "$TAPK"
adb shell rm -rf /data/local/tmp/e2e
adb shell mkdir -p /data/local/tmp/e2e
adb logcat -c
adb shell am instrument -w -r -e class app.djfusion.E2ETest app.djfusion.pro.test/androidx.test.runner.AndroidJUnitRunner > e2e/instrument.txt 2>&1 || true
adb pull /data/local/tmp/e2e e2e/telas || true
adb logcat -d > e2e/logcat.txt
grep " E2E" e2e/logcat.txt | sed 's/^.* E2E *: //' > e2e/relatorio.txt || true
set +x
echo "=============== RELATÓRIO ==============="
cat e2e/relatorio.txt
echo "=============== INSTRUMENTAÇÃO ==============="
grep -E "FAILURES|OK \(|Tests run|INSTRUMENTATION_|Error|Exception" e2e/instrument.txt | head -40
grep -nE "FATAL|AndroidRuntime" e2e/logcat.txt | head -20 || true
exit 0
