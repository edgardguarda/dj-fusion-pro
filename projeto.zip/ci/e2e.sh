#!/usr/bin/env bash
# Roda no emulador do GitHub Actions: instala o app e o teste, usa o app de ponta a ponta e junta fotos e relatório.
set -x
mkdir -p e2e
adb shell settings put global hide_error_dialogs 1
# densidade e fonte maiores que o padrão, como no celular do Edgard ("tamanho da exibição" grande):
# o console tem que caber inteiro, sem botões cortados
adb shell wm density 520
adb shell settings put system font_scale 1.15
# navegação por 3 botões: com gestos, um toque demorado do teste perto da borda de baixo abre "recentes"
adb shell cmd overlay enable com.android.internal.systemui.navbar.threebutton || true
sleep 45   # deixa o sistema do emulador terminar de iniciar (evita "launcher não está respondendo")
adb shell wm size
APK=$(ls fonte/app/build/outputs/apk/debug/*.apk | head -1)
TAPK=$(ls fonte/app/build/outputs/apk/androidTest/debug/*.apk | head -1)
adb install -r -g "$APK"
adb install -r -g "$TAPK"
adb shell rm -rf /data/local/tmp/e2e
adb shell mkdir -p /data/local/tmp/e2e
adb logcat -G 16M || true
adb logcat -c
timeout 2100 adb shell am instrument -w -r -e class app.djfusion.E2ETest app.djfusion.pro.test/androidx.test.runner.AndroidJUnitRunner > e2e/instrument.txt 2>&1 || true
adb pull /data/local/tmp/e2e e2e/telas || true
adb logcat -d > e2e/logcat.txt
grep " E2E" e2e/logcat.txt | sed 's/^.* E2E *: //' > e2e/passos-completo.txt || true
grep -v "^info  começando:" e2e/passos-completo.txt > e2e/relatorio.txt || true
# teste parado pelo limite de tempo: diz em qual passo estava
if ! grep -q "INSTRUMENTATION_CODE" e2e/instrument.txt; then echo "FALHA TESTE PARADO PELO LIMITE DE TEMPO no passo: $(grep '^info  começando:' e2e/passos-completo.txt | tail -1 | sed 's/^info  começando: //')" >> e2e/relatorio.txt; fi

# APK FINAL (release, embaralhado pelo R8): instala por cima, abre e confere que não fecha sozinho
RAPK=$(ls fonte/app/build/outputs/apk/release/*.apk 2>/dev/null | head -1)
if [ -n "$RAPK" ]; then
  adb logcat -c
  # o APK final tem outra assinatura: tira o de teste antes
  adb uninstall app.djfusion.pro.test > /dev/null 2>&1 || true
  adb uninstall app.djfusion.pro > /dev/null 2>&1 || true
  if adb install -r "$RAPK" > e2e/release-install.txt 2>&1; then
    adb shell am start -W -n app.djfusion.pro/app.djfusion.MainActivity > e2e/release-start.txt 2>&1
    sleep 12
    adb exec-out screencap -p > e2e/release-aberto.png || true
    PID=$(adb shell pidof app.djfusion.pro | tr -d '\r')
    adb logcat -d > e2e/release-logcat.txt
    if [ -n "$PID" ] && ! grep -q "FATAL EXCEPTION" e2e/release-logcat.txt; then
      echo "OK    APK FINAL (R8): instala, abre e fica aberto 12 s sem fechar" >> e2e/relatorio.txt
    else
      echo "FALHA APK FINAL (R8): fechou ao abrir :: $(grep -A3 'FATAL EXCEPTION' e2e/release-logcat.txt | tr '\n' ' ' | cut -c1-400)" >> e2e/relatorio.txt
    fi
  else
    echo "FALHA APK FINAL (R8): não instalou :: $(tail -2 e2e/release-install.txt | tr '\n' ' ')" >> e2e/relatorio.txt
  fi
else
  echo "FALHA APK FINAL (R8): não foi compilado (ver release.txt)" >> e2e/relatorio.txt
fi
# pacote da Play Store (.aab) junto com o resultado
cp fonte/app/build/outputs/bundle/release/*.aab e2e/ 2>/dev/null || true
set +x
echo "=============== RELATÓRIO ==============="
cat e2e/relatorio.txt
echo "=============== INSTRUMENTAÇÃO ==============="
grep -E "FAILURES|OK \(|Tests run|INSTRUMENTATION_|Error|Exception" e2e/instrument.txt | head -40
grep -nE "FATAL|AndroidRuntime" e2e/logcat.txt | head -20 || true
exit 0
