package app.djfusion

import android.content.ContentValues
import android.content.Context
import android.net.Uri
import android.os.SystemClock
import android.provider.MediaStore
import android.util.Log
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.semantics.SemanticsActions
import androidx.compose.ui.test.SemanticsNodeInteraction
import androidx.compose.ui.test.click
import androidx.compose.ui.test.junit4.createAndroidComposeRule
import androidx.compose.ui.test.onAllNodesWithContentDescription
import androidx.compose.ui.test.onNodeWithContentDescription
import androidx.compose.ui.test.onNodeWithText
import androidx.compose.ui.test.performClick
import androidx.compose.ui.test.performSemanticsAction
import androidx.compose.ui.test.performTouchInput
import androidx.compose.ui.test.swipe
import androidx.compose.ui.test.swipeDown
import androidx.compose.ui.test.swipeUp
import androidx.lifecycle.ViewModelProvider
import androidx.test.ext.junit.runners.AndroidJUnit4
import androidx.test.platform.app.InstrumentationRegistry
import androidx.test.uiautomator.By
import androidx.test.uiautomator.UiDevice
import androidx.test.uiautomator.Until
import app.djfusion.ui.AppViewModel
import org.junit.Assert.assertTrue
import org.junit.Rule
import org.junit.Test
import org.junit.runner.RunWith
import java.io.FileInputStream
import java.nio.ByteBuffer
import java.nio.ByteOrder
import java.util.regex.Pattern
import kotlin.math.PI
import kotlin.math.abs
import kotlin.math.cos
import kotlin.math.exp
import kotlin.math.sin

/**
 * Teste de ponta a ponta no emulador: usa o app como uma pessoa usaria (toques, arrastes, seletor de arquivos
 * do Android) e confere o estado real do motor depois de cada ação. Cada passo é registrado no logcat com a
 * etiqueta E2E (OK ou FALHA) e tira uma foto da tela em /data/local/tmp/e2e.
 */
@RunWith(AndroidJUnit4::class)
class E2ETest {
    @get:Rule
    val rule = createAndroidComposeRule<MainActivity>()

    private val inst = InstrumentationRegistry.getInstrumentation()
    private val device = UiDevice.getInstance(inst)
    private val ctx: Context get() = inst.targetContext
    private var fails = 0
    private var shotN = 0

    private val vm: AppViewModel by lazy {
        var v: AppViewModel? = null
        rule.runOnUiThread { v = ViewModelProvider(rule.activity)[AppViewModel::class.java] }
        v!!
    }

    // ------------------------------------------------------------------ utilitários

    private fun log(s: String) = Log.i("E2E", s)

    private fun shell(cmd: String): String {
        val pfd = inst.uiAutomation.executeShellCommand(cmd)
        return FileInputStream(pfd.fileDescriptor).use { it.readBytes().toString(Charsets.UTF_8) }.also { pfd.close() }
    }

    private fun shot(name: String) {
        SystemClock.sleep(350)
        shotN++
        shell("screencap -p /data/local/tmp/e2e/%02d_%s.png".format(shotN, name))
    }

    private fun check(cond: Boolean, msg: String) {
        if (!cond) throw AssertionError(msg)
    }

    private fun step(name: String, block: () -> Unit) {
        dismissSystemDialogs()
        try {
            block()
            log("OK    $name")
        } catch (t: Throwable) {
            fails++
            log("FALHA $name :: ${t.javaClass.simpleName}: ${t.message} | mensagem do app: ${vm.message.value}")
            runCatching { shot("FALHA_" + name.take(30).replace(Regex("[^A-Za-z0-9]"), "_")) }
        }
    }

    private fun waitFor(ms: Long, what: String, cond: () -> Boolean) {
        val end = SystemClock.uptimeMillis() + ms
        while (SystemClock.uptimeMillis() < end) {
            if (cond()) return
            SystemClock.sleep(100)
        }
        throw AssertionError("tempo esgotado esperando: $what")
    }

    private fun node(desc: String, substring: Boolean = false): SemanticsNodeInteraction =
        rule.onAllNodesWithContentDescription(desc, substring = substring)[0]

    /** Centro do controle na tela. Guardado na primeira consulta: tocando, o Compose nunca fica ocioso. */
    private val centers = HashMap<String, android.graphics.Point>()

    private fun center(desc: String, substring: Boolean = false): android.graphics.Point {
        val key = "$substring|$desc"
        centers[key]?.let { return it }
        val n = node(desc, substring).fetchSemanticsNode()
        val p = n.positionOnScreen
        val pt = android.graphics.Point((p.x + n.size.width / 2f).toInt(), (p.y + n.size.height / 2f).toInt())
        centers[key] = pt
        return pt
    }

    /** Mesmo lugar na tela com outra descrição (ex.: o botão Tocar vira Pausar). */
    private fun alias(newDesc: String, oldDesc: String, substring: Boolean = false) {
        centers["$substring|$newDesc"] = center(oldDesc, substring)
    }

    /** O emulador às vezes mostra "X não está respondendo" de outro app (ex.: o launcher): fecha com "Esperar". */
    private fun dismissSystemDialogs() {
        repeat(3) {
            if (device.hasObject(By.text(Pattern.compile("(?i).*(isn't responding|não está respondendo|keeps stopping).*")))) {
                (device.findObject(By.text(Pattern.compile("(?i)wait|aguardar")))
                    ?: device.findObject(By.text(Pattern.compile("(?i)close app|fechar app"))))?.click()
                SystemClock.sleep(800)
            }
        }
    }

    /** Toque de verdade (injetado pelo sistema, como um dedo), sem esperar o Compose ficar ocioso. */
    private fun tap(desc: String, substring: Boolean = false) {
        dismissSystemDialogs()
        val pt = center(desc, substring)
        check(device.click(pt.x, pt.y), "toque em '$desc' não foi aceito")
        SystemClock.sleep(300)
    }

    private fun tab(label: String) {
        tap(label)
        SystemClock.sleep(500)
    }

    private fun setProgress(desc: String, v: Float) {
        node(desc).performSemanticsAction(SemanticsActions.SetProgress) { it(v) }
        rule.waitForIdle()
    }

    private fun pos(deck: Int): Long = vm.live.value.decks[deck].positionFrames

    // ---------------------------------------------------------- áudio de teste

    /** Batida sintética: bumbo em cada tempo, chimbal no contratempo e um acorde. WAV 44,1 kHz estéreo. */
    private fun makeWav(bpm: Double, seconds: Int, chord: DoubleArray): ByteArray {
        val sr = 44100
        val n = sr * seconds
        val pcm = ByteBuffer.allocate(n * 4).order(ByteOrder.LITTLE_ENDIAN)
        val beat = 60.0 / bpm
        var seed = 12345L
        for (i in 0 until n) {
            val t = i.toDouble() / sr
            val tb = t % beat
            var s = 0.0
            s += 0.65 * sin(2 * PI * 55.0 * tb) * exp(-tb / 0.12)
            val off = (t + beat / 2) % beat
            seed = seed * 6364136223846793005L + 1442695040888963407L
            val noise = ((seed ushr 33) and 0xFFFF).toDouble() / 32768.0 - 1.0
            if (off < 0.04) s += 0.18 * noise * exp(-off / 0.012)
            for (f in chord) s += 0.07 * sin(2 * PI * f * t)
            val v = (s.coerceIn(-1.0, 1.0) * 30000).toInt().toShort()
            pcm.putShort(v); pcm.putShort(v)
        }
        val data = pcm.array()
        val out = ByteBuffer.allocate(44 + data.size).order(ByteOrder.LITTLE_ENDIAN)
        out.put("RIFF".toByteArray()); out.putInt(36 + data.size); out.put("WAVE".toByteArray())
        out.put("fmt ".toByteArray()); out.putInt(16); out.putShort(1); out.putShort(2)
        out.putInt(sr); out.putInt(sr * 4); out.putShort(4); out.putShort(16)
        out.put("data".toByteArray()); out.putInt(data.size); out.put(data)
        return out.array()
    }

    /** Grava o arquivo em Download/e2e pelo MediaStore (aparece no seletor de arquivos do Android). */
    private fun publish(name: String, bytes: ByteArray): Uri {
        val r = ctx.contentResolver
        r.delete(
            MediaStore.Downloads.EXTERNAL_CONTENT_URI,
            "${MediaStore.Downloads.DISPLAY_NAME} = ?", arrayOf(name),
        )
        val values = ContentValues().apply {
            put(MediaStore.Downloads.DISPLAY_NAME, name)
            put(MediaStore.Downloads.MIME_TYPE, "audio/x-wav")
            put(MediaStore.Downloads.RELATIVE_PATH, "Download/e2e")
            put(MediaStore.Downloads.IS_PENDING, 1)
        }
        val uri = r.insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, values)!!
        r.openOutputStream(uri)!!.use { it.write(bytes) }
        values.clear()
        values.put(MediaStore.Downloads.IS_PENDING, 0)
        r.update(uri, values, null, null)
        return uri
    }

    // ------------------------------------------------------- seletor do Android

    private fun pickerPackage(): Boolean =
        device.wait(Until.hasObject(By.pkg(Pattern.compile(".*documentsui.*"))), 10_000) == true

    private fun openDownloadsE2e() {
        // abre a lista de locais e vai em Downloads > e2e
        val roots = device.findObject(By.desc(Pattern.compile("(?i)show roots|mostrar raízes")))
        roots?.click()
        SystemClock.sleep(800)
        device.findObject(By.text(Pattern.compile("(?i)downloads?")))?.click()
        SystemClock.sleep(1200)
        device.wait(Until.findObject(By.text("e2e")), 5000)?.click()
        SystemClock.sleep(1200)
    }

    private fun pickFile(fileName: String) {
        check(pickerPackage(), "o seletor de arquivos do Android não abriu")
        SystemClock.sleep(1000)
        var item = device.findObject(By.text(fileName))
        if (item == null) {
            openDownloadsE2e()
            item = device.wait(Until.findObject(By.text(fileName)), 5000)
        }
        check(item != null, "o arquivo $fileName não aparece no seletor")
        item!!.click()
        SystemClock.sleep(1200)
        // modo de vários arquivos: o toque só marca; confirma com o botão de selecionar
        if (device.hasObject(By.pkg(Pattern.compile(".*documentsui.*")))) {
            val sel = device.findObject(By.res(Pattern.compile(".*:id/action_menu_select")))
                ?: device.findObject(By.text(Pattern.compile("(?i)select|selecionar|abrir|open")))
            sel?.click()
        }
        device.wait(Until.hasObject(By.pkg(ctx.packageName)), 8000)
    }

    private fun pickFolder() {
        check(pickerPackage(), "o seletor de pastas não abriu")
        SystemClock.sleep(1000)
        openDownloadsE2e()
        val use = device.wait(Until.findObject(By.text(Pattern.compile("(?i)use this folder|usar esta pasta"))), 5000)
        check(use != null, "botão USAR ESTA PASTA não apareceu")
        use!!.click()
        val allow = device.wait(Until.findObject(By.text(Pattern.compile("(?i)allow|permitir"))), 5000)
        allow?.click()
        device.wait(Until.hasObject(By.pkg(ctx.packageName)), 8000)
    }

    // ------------------------------------------------------------------------ teste

    @Test
    fun usarOAppDePontaAPonta() {
        shell("mkdir -p /data/local/tmp/e2e")
        val wavA = makeWav(120.0, 45, doubleArrayOf(220.0, 261.63, 329.63))   // lá menor
        val wavB = makeWav(126.0, 45, doubleArrayOf(261.63, 329.63, 392.0))   // dó maior
        val wavC = makeWav(100.0, 45, doubleArrayOf(185.0, 233.08, 277.18))   // fá# maior
        val uriA = publish("e2e_120.wav", wavA)
        val uriB = publish("e2e_126.wav", wavB)
        val uriC = publish("e2e_100.wav", wavC)

        step("app abre e liga o áudio") {
            waitFor(8000, "status do áudio") { vm.audioStatus.value.contains("Hz") }
            log("info  áudio: ${vm.audioStatus.value}")
        }
        shot("inicio")

        step("tocar sem música explica o que fazer") {
            tap("Tocar deck A")
            waitFor(2000, "mensagem") { vm.message.value?.contains("sem música") == true }
        }

        tab("BIBLIOTECA")
        shot("biblioteca_vazia")

        step("IMPORTAR pelo seletor do Android") {
            tap("Importar músicas do aparelho")
            pickFile("e2e_120.wav")
            waitFor(10_000, "faixa na biblioteca") { vm.tracks.value.any { it.title.startsWith("e2e_120") } }
        }
        if (vm.tracks.value.none { it.title.startsWith("e2e_120") }) vm.importUris(listOf(uriA))

        step("PASTA importa a pasta inteira") {
            tap("Importar uma pasta inteira de músicas")
            pickFolder()
            waitFor(15_000, "faixas da pasta") { vm.tracks.value.count { it.title.startsWith("e2e_") } >= 3 }
        }
        if (vm.tracks.value.none { it.title.startsWith("e2e_126") }) vm.importUris(listOf(uriB, uriC))
        waitFor(10_000, "3 faixas") { vm.tracks.value.map { it.title }.toSet().count { it.startsWith("e2e_") } >= 3 }
        shot("biblioteca_importada")

        step("ANALISAR detecta andamento e tom") {
            tap("Analisar andamento e tom", substring = true)
            waitFor(90_000, "análise") { vm.tracks.value.filter { it.title.startsWith("e2e_") }.all { it.analyzed } }
            val t120 = vm.tracks.value.first { it.title.startsWith("e2e_120") }
            log("info  BPM e2e_120 = ${t120.bpm}  tom = ${t120.key?.code}")
            check(abs(t120.bpm - 120.0) < 1.0, "BPM detectado ${t120.bpm}, esperado 120")
        }
        shot("biblioteca_analisada")

        step("ordenar por tom") {
            tap("Ordenar por Tom")
            waitFor(3000, "ordem") { vm.sort.value == app.djfusion.data.SortOrder.KEY }
            shot("ordem_tom")
            tap("Ordenar por Recentes")
        }

        step("carregar e2e_120 no deck A") {
            tap("Carregar e2e_120 no deck A")
            waitFor(20_000, "deck A carregado") { vm.decks.value[0].loaded && !vm.decks.value[0].loading }
            check(vm.decks.value[0].hasBpm, "deck A sem BPM")
        }
        step("carregar e2e_126 no deck B") {
            tap("Carregar e2e_126 no deck B")
            waitFor(20_000, "deck B carregado") { vm.decks.value[1].loaded && !vm.decks.value[1].loading }
        }

        tab("DJ LIVE")
        shot("decks_carregados")
        rule.waitForIdle()
        for (d in listOf("Tocar deck A", "Tocar deck B", "AUTO DJ", "BIBLIOTECA", "CONTROLADORA", "AMOSTRAS", "DJ LIVE")) center(d, d == "AUTO DJ")
        for (d in listOf("Cue do deck A", "Sync do deck B", "Key-lock do deck A", "Fone do deck A", "Prato do deck A", "Abrir pads", "Gerar amostras automaticamente")) center(d, true)
        alias("Pausar deck A", "Tocar deck A")
        alias("Pausar deck B", "Tocar deck B")

        step("PLAY deck A toca e a posição anda") {
            val info = IntArray(6); app.djfusion.audio.NativeEngine.nativeStreamInfo(info)
            log("info  fluxo: " + info.joinToString())
            val p0 = pos(0)
            val t0 = SystemClock.uptimeMillis()
            tap("Tocar deck A")
            log("info  toque levou ${SystemClock.uptimeMillis() - t0} ms")
            val st = LongArray(4)
            for (k in 1..12) {
                SystemClock.sleep(250)
                app.djfusion.audio.NativeEngine.nativeDeckState(0, st)
                log("info  t=${SystemClock.uptimeMillis() - t0}ms nativo flags=${st[0]} pos=${st[1]} ui.playing=${vm.decks.value[0].playing} pico=${app.djfusion.audio.NativeEngine.nativeMasterPeak()}")
            }
            check(vm.decks.value[0].playing, "deck A não está tocando")
            val adv = pos(0) - p0
            val secs = (SystemClock.uptimeMillis() - t0) / 1000.0
            log("info  andou ${adv / 48000.0} s de música em $secs s")
            check(adv > 48_000, "posição não andou ($adv quadros)")
        }
        step("medidor do master mostra som") {
            check(vm.live.value.masterPeak > 0.01f, "nível master ${vm.live.value.masterPeak}")
        }
        shot("tocando_A")

        step("PAUSE deck A") {
            tap("Pausar deck A")
            SystemClock.sleep(400)
            check(!vm.decks.value[0].playing, "deck A continua tocando")
        }
        step("CUE marca o ponto e volta") {
            tap("Cue do deck A", substring = true)
            SystemClock.sleep(300)
            val cue = vm.live.value.decks[0].cueFrames
            tap("Tocar deck A"); SystemClock.sleep(800)
            tap("Cue do deck A", substring = true); SystemClock.sleep(400)
            check(!vm.decks.value[0].playing, "CUE tocando deveria parar")
            check(abs(pos(0) - cue) < 4800, "CUE não voltou ao ponto (pos ${pos(0)} cue $cue)")
        }
        step("SYNC iguala o andamento do B ao do A") {
            tap("Sync do deck B", substring = true)
            SystemClock.sleep(300)
            val b = vm.decks.value[1]
            check(abs(b.playedBpm - vm.decks.value[0].playedBpm) < 0.2, "B ${b.playedBpm} x A ${vm.decks.value[0].playedBpm}")
        }
        step("KEY liga o key-lock") {
            tap("Key-lock do deck A", substring = true)
            check(vm.decks.value[0].keyLock, "key-lock não ligou")
        }
        step("FONE liga a pré-escuta") {
            tap("Fone do deck A", substring = true)
            check(vm.decks.value[0].cueOn, "fone não ligou")
            tap("Fone do deck A", substring = true)
        }
        step("fader de TEMPO (arrastar)") {
            node("Tempo do deck A", substring = true).performTouchInput { swipeUp() }
            rule.waitForIdle()
            check(vm.decks.value[0].rate > 1.05f, "rate ${vm.decks.value[0].rate}")
            setProgress("Tempo do deck A. Para cima acelera, para baixo desacelera. Meio é a velocidade normal.", 0.5f)
            check(vm.decks.value[0].rate == 1f, "tempo não voltou ao meio")
        }
        step("knob de GRAVE (arrastar)") {
            node("Equalizador graves do deck A", substring = true).performTouchInput {
                swipe(center, center + Offset(0f, 600f), 400)
            }
            rule.waitForIdle()
            check(vm.decks.value[0].eq[0] < 0.3f, "eq grave ${vm.decks.value[0].eq[0]}")
        }
        step("knob de FILTRO e volume do canal") {
            setProgress("Filtro do deck A. Esquerda corta os agudos, direita corta os graves, meio desliga. Toque duplo zera.", 0.2f)
            check(vm.decks.value[0].filter < 0.3f, "filtro")
            node("Volume do deck B").performTouchInput { swipeDown() }
            rule.waitForIdle()
            check(vm.volumes.value[1] < 0.2f, "volume B ${vm.volumes.value[1]}")
            node("Volume do deck B").performTouchInput { swipeUp() }
        }
        step("CROSSFADER (toque na ponta)") {
            node("Crossfader", substring = true).performTouchInput { click(Offset(width - 4f, height / 2f)) }
            rule.waitForIdle()
            check(vm.crossfader.value > 0.9f, "crossfader ${vm.crossfader.value}")
            node("Crossfader", substring = true).performTouchInput { click(center) }
        }
        step("MASTER e FONE do mixer") {
            setProgress("Volume master", 0.6f)
            check(abs(vm.master.value - 0.6f) < 0.01f, "master")
            setProgress("Volume do fone", 0.4f)
            check(abs(vm.hpLevel.value - 0.4f) < 0.01f, "fone")
        }
        step("visão geral: toque leva ao meio da música") {
            node("Visão geral do deck A", substring = true).performTouchInput { click(center) }
            SystemClock.sleep(300)
            val len = vm.decks.value[0].lengthFrames
            check(abs(pos(0) - len / 2) < len / 20, "pos ${pos(0)} de $len")
        }
        step("SCRATCH no prato (deck parado)") {
            val p0 = pos(0)
            val c = center("Prato do deck A", true)
            val n = node("Prato do deck A", substring = true).fetchSemanticsNode()
            val r = n.size.width * 0.36f
            val pts = Array(41) { i ->
                val a = i * PI.toFloat() / 40f
                android.graphics.Point((c.x + r * cos(a)).toInt(), (c.y + r * sin(a)).toInt())
            }
            device.swipe(pts, 4)   // meia volta em ~0,8 s, em tempo real
            SystemClock.sleep(300)
            log("info  scratch moveu ${(pos(0) - p0) / 48000.0} s")
            check(abs(pos(0) - p0) > 9600, "scratch não moveu a música (${pos(0) - p0})")
        }
        shot("mixer_ajustado")

        step("PADS abre hot cue, loop e efeito") {
            tap("Abrir pads", substring = true)
            check(vm.decks.value[0].padsOpen, "pads não abriram")
            SystemClock.sleep(500)
            rule.waitForIdle()
            for (d in listOf("Hot cue 1 do deck A", "Loop de 4 batida(s) no deck A", "Efeito ECO do deck A", "Dividir o andamento", "Dobrar o andamento", "Voltar ao prato do deck A")) center(d, true)
        }
        shot("pads_A")
        step("HOT CUE grava e volta") {
            tap("Hot cue 1 do deck A", substring = true)
            check(vm.decks.value[0].hotcues[0] >= 0, "hot cue não gravou")
        }
        step("LOOP de 4 batidas liga e desliga") {
            tap("Tocar deck A")
            tap("Loop de 4 batida(s) no deck A", substring = true)
            check(vm.decks.value[0].loopBeats == 4, "loop não ligou")
            tap("Loop de 4 batida(s) no deck A", substring = true)
            check(vm.decks.value[0].loopBeats == 0, "loop não desligou")
        }
        step("EFEITO eco liga") {
            tap("Efeito ECO do deck A", substring = true)
            check(vm.decks.value[0].fxType == 1, "eco não ligou")
            tap("Efeito ECO do deck A", substring = true)
        }
        step("÷2 e ×2 no BPM") {
            val b = vm.decks.value[0].bpm
            tap("Dividir o andamento", substring = true)
            check(abs(vm.decks.value[0].bpm - b / 2) < 0.01, "÷2")
            tap("Dobrar o andamento", substring = true)
            check(abs(vm.decks.value[0].bpm - b) < 0.01, "×2")
        }
        runCatching { tap("Voltar ao prato do deck A", substring = true) }
        if (vm.decks.value[0].playing) runCatching { tap("Pausar deck A") }

        step("AMOSTRAR gera pads") {
            tap("Gerar amostras automaticamente", substring = true)
            waitFor(20_000, "amostras") { vm.pads.value.any { it.ready } }
            log("info  pads: " + vm.pads.value.joinToString { it.label })
        }
        shot("amostras")
        step("pad de amostra toca") {
            val i = vm.pads.value.indexOfFirst { it.ready }
            tap("Pad ${i + 1}:", substring = true)
            waitFor(2000, "pad tocando") { vm.pads.value[i].playing }
        }
        step("volume das amostras") {
            setProgress("Volume das amostras", 0.5f)
            check(abs(vm.samplerVol.value - 0.5f) < 0.01f, "vol")
        }

        tab("CONTROLADORA")
        step("mapa da DJ2GO2 Touch") {
            tap("Aplicar o mapa de fábrica da Numark DJ2GO2 Touch")
            waitFor(2000, "mapa") { vm.midi.mapped.value.size >= 40 }
            check(vm.jog.ticksPerRev == 236, "jog ${vm.jog.ticksPerRev}")
        }
        step("saída de áudio: modo dividido") {
            tap("Modo de saída", substring = true)
            SystemClock.sleep(1500)
            log("info  saída: ${vm.outputNote.value}")
            vm.setOutputMode(0)
            SystemClock.sleep(1000)
        }
        shot("controladora")

        tab("DJ LIVE")
        step("AUTO DJ escolhe, carrega e mixa sozinho") {
            tap("AUTO DJ", substring = true)
            waitFor(30_000, "AUTO DJ preparar a próxima") { vm.autoDj.state.value.status.startsWith("Próxima") }
            shot("autodj_proxima")
            // adianta a música atual para perto do fim para não esperar a faixa inteira
            val cur = if (vm.decks.value[0].playing) 0 else 1
            val len = vm.decks.value[cur].lengthFrames
            app.djfusion.audio.NativeEngine.nativeSeek(cur, len - 48_000L * 22)
            waitFor(20_000, "mixagem começar") { vm.autoDj.state.value.mixing }
            shot("autodj_mixando")
            waitFor(40_000, "mixagem terminar") { !vm.autoDj.state.value.mixing && vm.decks.value[1 - cur].playing }
            check(!vm.decks.value[cur].playing, "deck que saiu continua tocando")
            check(abs(vm.crossfader.value - (if (cur == 0) 1f else 0f)) < 0.05f, "crossfader ${vm.crossfader.value}")
        }
        shot("autodj_depois")
        step("AUTO DJ desliga") {
            tap("AUTO DJ", substring = true)
            waitFor(3000, "desligar") { !vm.autoDj.state.value.active }
        }

        app.djfusion.audio.NativeEngine.nativePause(0)
        app.djfusion.audio.NativeEngine.nativePause(1)
        SystemClock.sleep(500)
        tab("BIBLIOTECA")
        rule.waitForIdle()
        step("remover faixa da biblioteca") {
            val before = vm.tracks.value.size
            tap("Remover e2e_100 da biblioteca", substring = true)
            waitFor(3000, "remover") { vm.tracks.value.size == before - 1 }
        }
        shot("fim")

        val crash = shell("logcat -d -s AndroidRuntime:E")
        if (crash.contains("FATAL")) { fails++; log("FALHA app travou: ${crash.takeLast(1500)}") }
        log("RESUMO falhas=$fails")
        assertTrue("$fails passo(s) falharam (veja E2E no logcat)", fails == 0)
    }
}
