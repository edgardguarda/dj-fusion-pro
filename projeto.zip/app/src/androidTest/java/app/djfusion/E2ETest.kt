package app.djfusion

import android.content.ContentValues
import android.content.Context
import android.net.Uri
import android.os.SystemClock
import android.provider.MediaStore
import android.util.Log
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.semantics.SemanticsActions
import androidx.compose.ui.test.SemanticsNodeInteraction
import androidx.compose.ui.test.click
import androidx.compose.ui.test.junit4.createAndroidComposeRule
import androidx.compose.ui.test.onAllNodesWithContentDescription
import androidx.compose.ui.test.onNodeWithContentDescription
import androidx.compose.ui.test.onNodeWithText
import androidx.compose.ui.test.performClick
import androidx.compose.ui.test.performScrollTo
import androidx.compose.ui.test.performSemanticsAction
import androidx.compose.ui.test.performTouchInput
import androidx.compose.ui.test.swipe
import androidx.compose.ui.test.swipeDown
import androidx.compose.ui.test.swipeUp
import androidx.lifecycle.ViewModelProvider
import androidx.test.ext.junit.runners.AndroidJUnit4
import androidx.test.platform.app.InstrumentationRegistry
import androidx.test.uiautomator.By
import androidx.test.uiautomator.UiDevice
import androidx.test.uiautomator.Until
import app.djfusion.ui.AppViewModel
import app.djfusion.ui.DisplayPrefs
import org.junit.Assert.assertTrue
import org.junit.Rule
import org.junit.Test
import org.junit.runner.RunWith
import java.io.FileInputStream
import java.nio.ByteBuffer
import java.nio.ByteOrder
import java.util.regex.Pattern
import kotlin.math.PI
import kotlin.math.abs
import kotlin.math.cos
import kotlin.math.exp
import kotlin.math.sin

/**
 * Teste de ponta a ponta no emulador: usa o app como uma pessoa usaria (toques, arrastes, seletor de arquivos
 * do Android) e confere o estado real do motor depois de cada ação. Cada passo é registrado no logcat com a
 * etiqueta E2E (OK ou FALHA) e tira uma foto da tela em /data/local/tmp/e2e.
 */
@RunWith(AndroidJUnit4::class)
class E2ETest {
    @get:Rule
    val rule = createAndroidComposeRule<MainActivity>()

    private val inst = InstrumentationRegistry.getInstrumentation()
    private val device = UiDevice.getInstance(inst)
    private val ctx: Context get() = inst.targetContext
    private var fails = 0
    private var shotN = 0

    private val vm: AppViewModel by lazy {
        var v: AppViewModel? = null
        rule.runOnUiThread { v = ViewModelProvider(rule.activity)[AppViewModel::class.java] }
        v!!
    }

    // ------------------------------------------------------------------ utilitários

    private fun log(s: String) = Log.i("E2E", s)

    private fun shell(cmd: String): String {
        val pfd = inst.uiAutomation.executeShellCommand(cmd)
        return FileInputStream(pfd.fileDescriptor).use { it.readBytes().toString(Charsets.UTF_8) }.also { pfd.close() }
    }

    private fun shot(name: String) {
        SystemClock.sleep(350)
        shotN++
        shell("screencap -p /data/local/tmp/e2e/%02d_%s.png".format(shotN, name))
    }

    private fun check(cond: Boolean, msg: String) {
        if (!cond) throw AssertionError(msg)
    }

    private fun step(name: String, block: () -> Unit) {
        dismissSystemDialogs()
        try {
            block()
            log("OK    $name")
        } catch (t: Throwable) {
            fails++
            log("FALHA $name :: ${t.javaClass.simpleName}: ${t.message} | mensagem do app: ${vm.message.value}")
            runCatching { shot("FALHA_" + name.take(30).replace(Regex("[^A-Za-z0-9]"), "_")) }
            backToApp()
        }
    }

    /** Depois de uma falha, outra tela (seletor do Android, apps recentes) pode ter ficado na frente: volta ao app. */
    private fun backToApp() {
        repeat(4) {
            if (device.hasObject(By.pkg(ctx.packageName))) return
            device.pressBack()
            SystemClock.sleep(800)
        }
        if (!device.hasObject(By.pkg(ctx.packageName))) {
            ctx.startActivity(
                android.content.Intent(ctx, MainActivity::class.java).addFlags(
                    android.content.Intent.FLAG_ACTIVITY_NEW_TASK or android.content.Intent.FLAG_ACTIVITY_REORDER_TO_FRONT,
                ),
            )
            device.wait(Until.hasObject(By.pkg(ctx.packageName)), 8000)
        }
        runCatching { rule.waitForIdle() }
    }

    private fun waitFor(ms: Long, what: String, cond: () -> Boolean) {
        val end = SystemClock.uptimeMillis() + ms
        while (SystemClock.uptimeMillis() < end) {
            if (cond()) return
            SystemClock.sleep(100)
        }
        throw AssertionError("tempo esgotado esperando: $what")
    }

    private fun node(desc: String, substring: Boolean = false): SemanticsNodeInteraction =
        rule.onAllNodesWithContentDescription(desc, substring = substring)[0]

    /** Centro do controle na tela. Guardado na primeira consulta: tocando, o Compose nunca fica ocioso. */
    private val centers = HashMap<String, android.graphics.Point>()

    private fun center(desc: String, substring: Boolean = false): android.graphics.Point {
        val key = "$substring|$desc"
        centers[key]?.let { return it }
        val n = node(desc, substring).fetchSemanticsNode()
        val p = n.positionOnScreen
        val pt = android.graphics.Point((p.x + n.size.width / 2f).toInt(), (p.y + n.size.height / 2f).toInt())
        centers[key] = pt
        return pt
    }

    /** Mesmo lugar na tela com outra descrição (ex.: o botão Tocar vira Pausar). */
    private fun alias(newDesc: String, oldDesc: String, substring: Boolean = false) {
        centers["$substring|$newDesc"] = center(oldDesc, substring)
    }

    /** O emulador às vezes mostra "X não está respondendo" de outro app (ex.: o launcher): fecha com "Esperar". */
    private fun dismissSystemDialogs() {
        repeat(3) {
            if (device.hasObject(By.text(Pattern.compile("(?i).*(isn't responding|não está respondendo|keeps stopping).*")))) {
                (device.findObject(By.text(Pattern.compile("(?i)wait|aguardar")))
                    ?: device.findObject(By.text(Pattern.compile("(?i)close app|fechar app"))))?.click()
                SystemClock.sleep(800)
            }
        }
    }

    /** Toque de verdade (injetado pelo sistema, como um dedo), sem esperar o Compose ficar ocioso. */
    private fun tap(desc: String, substring: Boolean = false) {
        dismissSystemDialogs()
        val pt = center(desc, substring)
        // o retorno do click pode ser falso quando outra janela abre no mesmo instante (ex.: seletor de arquivos);
        // o efeito do toque é conferido depois pelo próprio passo
        if (!device.click(pt.x, pt.y)) log("info  toque em '$desc' sem confirmação do sistema")
        SystemClock.sleep(300)
    }

    private fun tab(label: String) {
        tap(label)
        SystemClock.sleep(500)
        // sem nada tocando, deixa o Compose desenhar a tela nova (o relógio do teste só anda sincronizando)
        if (vm.decks.value.none { it.playing }) runCatching { rule.waitForIdle() }
    }

    private fun setProgress(desc: String, v: Float) {
        node(desc).performSemanticsAction(SemanticsActions.SetProgress) { it(v) }
        rule.waitForIdle()
    }

    private fun pos(deck: Int): Long = vm.live.value.decks[deck].positionFrames

    // ---------------------------------------------------------- áudio de teste

    /** Batida sintética: bumbo em cada tempo, chimbal no contratempo e um acorde. WAV 44,1 kHz estéreo. */
    private fun makeWav(bpm: Double, seconds: Int, chord: DoubleArray): ByteArray {
        val sr = 44100
        val n = sr * seconds
        val pcm = ByteBuffer.allocate(n * 4).order(ByteOrder.LITTLE_ENDIAN)
        val beat = 60.0 / bpm
        var seed = 12345L
        for (i in 0 until n) {
            val t = i.toDouble() / sr
            val tb = t % beat
            var s = 0.0
            s += 0.65 * sin(2 * PI * 55.0 * tb) * exp(-tb / 0.12)
            val off = (t + beat / 2) % beat
            seed = seed * 6364136223846793005L + 1442695040888963407L
            val noise = ((seed ushr 33) and 0xFFFF).toDouble() / 32768.0 - 1.0
            if (off < 0.04) s += 0.18 * noise * exp(-off / 0.012)
            for (f in chord) s += 0.07 * sin(2 * PI * f * t)
            val v = (s.coerceIn(-1.0, 1.0) * 30000).toInt().toShort()
            pcm.putShort(v); pcm.putShort(v)
        }
        val data = pcm.array()
        val out = ByteBuffer.allocate(44 + data.size).order(ByteOrder.LITTLE_ENDIAN)
        out.put("RIFF".toByteArray()); out.putInt(36 + data.size); out.put("WAVE".toByteArray())
        out.put("fmt ".toByteArray()); out.putInt(16); out.putShort(1); out.putShort(2)
        out.putInt(sr); out.putInt(sr * 4); out.putShort(4); out.putShort(16)
        out.put("data".toByteArray()); out.putInt(data.size); out.put(data)
        return out.array()
    }

    /** Grava o arquivo em Download/e2e pelo MediaStore (aparece no seletor de arquivos do Android). */
    private fun publish(name: String, bytes: ByteArray, mime: String = "audio/x-wav"): Uri {
        val r = ctx.contentResolver
        r.delete(
            MediaStore.Downloads.EXTERNAL_CONTENT_URI,
            "${MediaStore.Downloads.DISPLAY_NAME} = ?", arrayOf(name),
        )
        val values = ContentValues().apply {
            put(MediaStore.Downloads.DISPLAY_NAME, name)
            put(MediaStore.Downloads.MIME_TYPE, mime)
            put(MediaStore.Downloads.RELATIVE_PATH, "Download/e2e")
            put(MediaStore.Downloads.IS_PENDING, 1)
        }
        val uri = r.insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, values)!!
        r.openOutputStream(uri)!!.use { it.write(bytes) }
        values.clear()
        values.put(MediaStore.Downloads.IS_PENDING, 0)
        r.update(uri, values, null, null)
        return uri
    }

    // ------------------------------------------------------- seletor do Android

    private fun pickerPackage(): Boolean =
        device.wait(Until.hasObject(By.pkg(Pattern.compile(".*documentsui.*"))), 10_000) == true

    private fun openDownloadsE2e() {
        // abre a lista de locais e vai em Downloads > e2e
        val roots = device.findObject(By.desc(Pattern.compile("(?i)show roots|mostrar raízes")))
        roots?.click()
        SystemClock.sleep(800)
        device.findObject(By.text(Pattern.compile("(?i)downloads?")))?.click()
        SystemClock.sleep(1200)
        device.wait(Until.findObject(By.text("e2e")), 5000)?.click()
        SystemClock.sleep(1200)
    }

    private fun pickFile(fileName: String) {
        check(pickerPackage(), "o seletor de arquivos do Android não abriu")
        SystemClock.sleep(1000)
        var item = device.findObject(By.text(fileName))
        if (item == null) {
            openDownloadsE2e()
            item = device.wait(Until.findObject(By.text(fileName)), 5000)
        }
        check(item != null, "o arquivo $fileName não aparece no seletor")
        item!!.click()
        SystemClock.sleep(1200)
        // modo de vários arquivos: o toque só marca; confirma com o botão de selecionar
        if (device.hasObject(By.pkg(Pattern.compile(".*documentsui.*")))) {
            val sel = device.findObject(By.res(Pattern.compile(".*:id/action_menu_select")))
                ?: device.findObject(By.text(Pattern.compile("(?i)select|selecionar|abrir|open")))
            sel?.click()
        }
        device.wait(Until.hasObject(By.pkg(ctx.packageName)), 8000)
    }

    private fun pickFolder() {
        check(pickerPackage(), "o seletor de pastas não abriu")
        SystemClock.sleep(1000)
        openDownloadsE2e()
        val use = device.wait(Until.findObject(By.text(Pattern.compile("(?i)use this folder|usar esta pasta"))), 5000)
        check(use != null, "botão USAR ESTA PASTA não apareceu")
        use!!.click()
        val allow = device.wait(Until.findObject(By.text(Pattern.compile("(?i)allow|permitir"))), 5000)
        allow?.click()
        device.wait(Until.hasObject(By.pkg(ctx.packageName)), 8000)
    }

    // ------------------------------------------------------------------------ teste

    /** Alterna os modos do visor e volta (confere que não quebra a tela). */
    private fun DisplayPrefsToggle() {
        app.djfusion.ui.DisplayPrefs.remaining = true
        app.djfusion.ui.DisplayPrefs.keyLetters = true
        app.djfusion.ui.DisplayPrefs.remaining = false
        app.djfusion.ui.DisplayPrefs.keyLetters = false
    }

    @Test
    fun usarOAppDePontaAPonta() {
        shell("mkdir -p /data/local/tmp/e2e")
        val wavA = makeWav(120.0, 45, doubleArrayOf(220.0, 261.63, 329.63))   // lá menor
        val wavB = makeWav(126.0, 45, doubleArrayOf(261.63, 329.63, 392.0))   // dó maior
        val wavC = makeWav(100.0, 45, doubleArrayOf(185.0, 233.08, 277.18))   // fá# maior
        val uriA = publish("e2e_120.wav", wavA)
        val uriB = publish("e2e_126.wav", wavB)
        val uriC = publish("e2e_100.wav", wavC)
        // arquivos comprimidos de verdade (MP3 e AAC), decodificados pelos decodificadores do Android
        publish("e2e_124.mp3", inst.context.assets.open("e2e_124.mp3").use { it.readBytes() }, "audio/mpeg")
        publish("e2e_124b.m4a", inst.context.assets.open("e2e_124b.m4a").use { it.readBytes() }, "audio/mp4")
        val uriFlac = publish("e2e_flac.flac", inst.context.assets.open("e2e_flac.flac").use { it.readBytes() }, "audio/flac")
        val uriW24 = publish("e2e_wav24.wav", inst.context.assets.open("e2e_wav24.wav").use { it.readBytes() }, "audio/x-wav")

        step("sons prontos já estão nos pads") {
            waitFor(5000, "pads prontos") { vm.pads.value.all { it.ready } && vm.pads.value[0].label == "BUZINA" }
        }
        step("app abre e liga o áudio") {
            // cues automáticas e proteção contra silêncio têm passos próprios: desligadas no resto do teste
            rule.runOnUiThread { vm.setAutoCues(false); vm.setSilenceGuard(false) }
            waitFor(8000, "status do áudio") { vm.audioStatus.value.contains("Hz") }
            log("info  áudio: ${vm.audioStatus.value}")
        }
        shot("inicio")

        step("tocar sem música explica o que fazer") {
            tap("Tocar deck A")
            waitFor(2000, "mensagem") { vm.message.value?.contains("sem música") == true }
        }

        tab("BIBLIOTECA")
        shot("biblioteca_vazia")

        step("IMPORTAR pelo seletor do Android") {
            tap("Importar músicas do aparelho")
            pickFile("e2e_120.wav")
            waitFor(10_000, "faixa na biblioteca") { vm.tracks.value.any { it.title.startsWith("e2e_120") } }
        }
        if (vm.tracks.value.none { it.title.startsWith("e2e_120") }) vm.importUris(listOf(uriA))

        step("PASTA importa a pasta inteira") {
            tap("Importar uma pasta inteira de músicas")
            pickFolder()
            waitFor(15_000, "faixas da pasta") { vm.tracks.value.count { it.title.startsWith("e2e_") } >= 3 }
            waitFor(3000, "pasta lembrada") { vm.folders.value.size == 1 }
        }
        if (vm.tracks.value.none { it.title.startsWith("e2e_126") }) vm.importUris(listOf(uriB, uriC))
        waitFor(10_000, "3 faixas") { vm.tracks.value.map { it.title }.toSet().count { it.startsWith("e2e_") } >= 3 }
        shot("biblioteca_importada")

        step("ANALISAR detecta andamento e tom") {
            tap("Analisar andamento e tom", substring = true)
            waitFor(90_000, "análise") { vm.tracks.value.filter { it.title.startsWith("e2e_") }.all { it.analyzed } }
            val t120 = vm.tracks.value.first { it.title.startsWith("e2e_120") }
            log("info  BPM e2e_120 = ${t120.bpm}  tom = ${t120.key?.code}")
            check(abs(t120.bpm - 120.0) < 1.0, "BPM detectado ${t120.bpm}, esperado 120")
        }
        shot("biblioteca_analisada")

        step("ordenar por tom") {
            tap("Ordenar por Tom")
            waitFor(3000, "ordem") { vm.sort.value == app.djfusion.data.SortOrder.KEY }
            shot("ordem_tom")
            tap("Ordenar por Recentes")
        }

        step("carregar e2e_120 no deck A") {
            vm.setSearch("e2e_12"); SystemClock.sleep(800); rule.waitForIdle()
            tap("Carregar e2e_120 no deck A")
            waitFor(20_000, "deck A carregado") { vm.decks.value[0].loaded && !vm.decks.value[0].loading && !vm.decks.value[0].analyzing }
            check(vm.decks.value[0].hasBpm, "deck A sem BPM")
        }
        step("carregar e2e_126 no deck B") {
            tap("Carregar e2e_126 no deck B")
            waitFor(20_000, "deck B carregado") { vm.decks.value[1].loaded && !vm.decks.value[1].loading && !vm.decks.value[1].analyzing }
        }
        vm.setSearch(""); SystemClock.sleep(500)

        tab("DJ LIVE")
        shot("decks_carregados")
        rule.waitForIdle()
        for (d in listOf("Tocar deck A", "Tocar deck B", "AUTO DJ: o programa", "BIBLIOTECA", "CONTROLADORA", "AMOSTRAS", "DJ LIVE", "EFEITOS", "AJUSTES")) center(d, d == "AUTO DJ: o programa")
        center("Gravar o set", true)
        alias("Parar a gravação do set e salvar", "Gravar o set", true)
        for (d in listOf("Cue do deck A", "Sync do deck B", "Key-lock do deck A", "Fone do deck A", "Prato do deck A", "Abrir pads",
                "Slip do deck A", "Subir o tom do deck A", "Ajustar o tom do deck A", "Abrir stems do deck A", "Auto-gain",
                "Faixa do pitch do deck A", "Empurrar a música do deck A")) center(d, true)
        alias("Fechar stems do deck A", "Abrir stems do deck A", true)
        alias("Pausar deck A", "Tocar deck A")
        alias("Pausar deck B", "Tocar deck B")

        step("tela inteira: nenhum botão cortado (densidade e fonte grandes)") {
            val root = rule.onAllNodes(androidx.compose.ui.test.isRoot())[0].fetchSemanticsNode().size
            for (d in listOf("Gravar o set", "AUTO DJ: o programa", "AJUSTES", "Abrir stems do deck A", "Abrir stems do deck B", "Abrir pads",
                    "Cue do deck A", "Fone do deck A", "Faixa do pitch do deck A")) {
                val n = node(d, true).fetchSemanticsNode()
                val b = n.boundsInRoot
                log("info  $d: ${b.left.toInt()},${b.top.toInt()} – ${b.right.toInt()},${b.bottom.toInt()} (tela ${root.width}×${root.height})")
                check(b.left >= -1f && b.top >= -1f && b.right <= root.width + 1f && b.bottom <= root.height + 1f, "'$d' cortado: $b")
                check(b.width > 20f && b.height > 20f, "'$d' espremido: $b")
            }
        }
        step("LISTA fixa na tela DJ carrega no deck B") {
            val back = vm.tracks.value.first { it.title.startsWith("e2e_126") }
            tap("Mostrar ou esconder a lista", substring = true)
            waitFor(2000, "lista aberta") { vm.browserDock.value }
            vm.setSearch("e2e_124b"); SystemClock.sleep(800); rule.waitForIdle()
            shot("lista_fixa")
            val row = vm.tracks.value.first { it.title.startsWith("e2e_124b") }
            tap("Carregar ${row.title} no deck B (lista fixa)")
            waitFor(30_000, "lista: deck B") { vm.decks.value[1].let { it.trackId == row.id && it.loaded && !it.loading && !it.analyzing } }
            vm.setSearch("")
            tap("Mostrar ou esconder a lista", substring = true)
            waitFor(2000, "lista fechada") { !vm.browserDock.value }
            // devolve a e2e_126 ao deck B para os testes seguintes
            rule.runOnUiThread { vm.loadTrack(1, back) }
            waitFor(30_000, "deck B de volta") { vm.decks.value[1].let { it.trackId == back.id && it.loaded && !it.loading && !it.analyzing } }
            rule.waitForIdle()
        }

        step("CARREGAR pelo navegador da tela DJ (MP3)") {
            tap("Carregar música no deck A")
            waitFor(3000, "navegador") { vm.browserDeck.value == 0 }
            SystemClock.sleep(500)
            rule.waitForIdle()
            shot("navegador")
            val tLoad = SystemClock.uptimeMillis()
            tap("Carregar Teste MP3 124 no deck A (navegador)")
            waitFor(30_000, "MP3 tocável") { vm.decks.value[0].let { it.loaded && !it.loading && it.title.startsWith("Teste MP3") } }
            log("info  MP3 tocável em ${(SystemClock.uptimeMillis() - tLoad) / 1000.0} s (análise continua em segundo plano)")
            waitFor(30_000, "MP3 no deck A") { vm.decks.value[0].let { it.loaded && !it.loading && !it.analyzing && it.title.startsWith("Teste MP3") } }
            val d = vm.decks.value[0]
            log("info  MP3: ${d.lengthFrames / 48000.0} s, BPM ${d.bpm}, tom ${d.key?.code}, energia ${d.energyLevel}")
            check(d.lengthFrames > 48_000L * 35, "MP3 curto demais: ${d.lengthFrames}")
            check(abs(d.bpm - 124.0) < 1.0, "BPM do MP3 ${d.bpm}")
            waitFor(3000, "navegador fechar") { vm.browserDeck.value == null }
            rule.waitForIdle()   // desenha a tela sem o navegador antes dos próximos toques
        }
        step("AAC (m4a) decodifica e carrega") {
            val row = vm.tracks.value.first { it.title.startsWith("e2e_124b") }
            vm.loadTrack(1, row)
            waitFor(30_000, "M4A no deck B") { vm.decks.value[1].let { it.loaded && !it.loading && !it.analyzing && it.trackId == row.id } }
            check(vm.decks.value[1].lengthFrames > 48_000L * 35, "M4A curto: ${vm.decks.value[1].lengthFrames}")
        }
        step("FLAC e WAV de 24 bits carregam (decodificador próprio)") {
            vm.importUris(listOf(uriFlac, uriW24))   // a PASTA já pode ter trazido os dois
            waitFor(15_000, "importar") { vm.tracks.value.count { it.title.startsWith("e2e_flac") || it.title.startsWith("e2e_wav24") } >= 2 }
            for (prefix in listOf("e2e_flac", "e2e_wav24")) {
                val row = vm.tracks.value.first { it.title.startsWith(prefix) }
                vm.loadTrack(0, row)
                waitFor(30_000, "$prefix no deck A") { vm.decks.value[0].let { it.trackId == row.id && it.loaded && !it.loading && !it.analyzing } }
                val sec = vm.decks.value[0].lengthFrames / 48000.0
                log("info  $prefix: $sec s, BPM ${vm.decks.value[0].bpm}")
                check(abs(sec - 12.0) < 0.3, "$prefix com $sec s")
            }
            log("info  erros de leitura: " + app.djfusion.audio.TrackDecoder.recentErrors.joinToString(" | ").ifEmpty { "nenhum" })
        }
        // volta às faixas do resto do teste
        vm.loadTrack(0, vm.tracks.value.first { it.title.startsWith("e2e_120") })
        vm.loadTrack(1, vm.tracks.value.first { it.title.startsWith("e2e_126") })
        waitFor(30_000, "decks de volta") {
            vm.decks.value[0].title.startsWith("e2e_120") && vm.decks.value[1].title.startsWith("e2e_126") &&
                vm.decks.value.none { it.loading } && vm.decks.value.all { it.loaded && it.hasBpm }
        }
        val tStems = SystemClock.uptimeMillis()
        waitFor(120_000, "stems dos dois decks") { vm.decks.value.all { it.stemsReady } }
        log("info  stems dos dois decks prontos em ${(SystemClock.uptimeMillis() - tStems) / 1000.0} s (depois de carregar)")
        SystemClock.sleep(500)
        rule.waitForIdle()

        step("PLAY deck A toca e a posição anda") {
            val info = IntArray(6); app.djfusion.audio.NativeEngine.nativeStreamInfo(info)
            log("info  fluxo: " + info.joinToString())
            val p0 = pos(0)
            val t0 = SystemClock.uptimeMillis()
            tap("Tocar deck A")
            log("info  toque levou ${SystemClock.uptimeMillis() - t0} ms")
            val st = LongArray(4)
            for (k in 1..12) {
                SystemClock.sleep(250)
                app.djfusion.audio.NativeEngine.nativeDeckState(0, st)
                log("info  t=${SystemClock.uptimeMillis() - t0}ms nativo flags=${st[0]} pos=${st[1]} ui.playing=${vm.decks.value[0].playing} pico=${app.djfusion.audio.NativeEngine.nativeMasterPeak()}")
            }
            check(vm.decks.value[0].playing, "deck A não está tocando")
            val adv = pos(0) - p0
            val secs = (SystemClock.uptimeMillis() - t0) / 1000.0
            log("info  andou ${adv / 48000.0} s de música em $secs s")
            check(adv > 48_000, "posição não andou ($adv quadros)")
        }
        step("medidor do master mostra som") {
            check(vm.live.value.masterPeak > 0.01f, "nível master ${vm.live.value.masterPeak}")
        }
        shot("tocando_A")

        step("PAUSE deck A") {
            tap("Pausar deck A")
            SystemClock.sleep(400)
            check(!vm.decks.value[0].playing, "deck A continua tocando")
        }
        step("CUE marca o ponto e volta") {
            app.djfusion.audio.NativeEngine.nativeSeek(0, 48_000L * 5)
            SystemClock.sleep(300)
            tap("Cue do deck A", substring = true)
            SystemClock.sleep(300)
            waitFor(3000, "toque no CUE terminar") { !vm.decks.value[0].playing }
            val cue = vm.live.value.decks[0].cueFrames
            tap("Tocar deck A"); SystemClock.sleep(800)
            waitFor(3000, "PLAY tocar") { vm.decks.value[0].playing }
            tap("Cue do deck A", substring = true); SystemClock.sleep(400)
            check(!vm.decks.value[0].playing, "CUE tocando deveria parar")
            check(abs(pos(0) - cue) < 4800, "CUE não voltou ao ponto (pos ${pos(0)} cue $cue)")
        }
        step("CUE segurado: toca enquanto aperta e volta ao soltar (CDJ)") {
            if (vm.decks.value[0].playing) { tap("Pausar deck A"); SystemClock.sleep(300) }
            val cue = vm.live.value.decks[0].cueFrames
            app.djfusion.audio.NativeEngine.nativeSeek(0, cue); SystemClock.sleep(200)
            rule.runOnUiThread { vm.cueDown(0) }
            SystemClock.sleep(900)
            check(vm.decks.value[0].playing, "CUE segurado não tocou")
            check(pos(0) > cue + 9600, "prévia não andou")
            rule.runOnUiThread { vm.cueUp(0) }
            waitFor(2000, "soltar o CUE parar") { !vm.decks.value[0].playing }
            check(abs(pos(0) - cue) < 4800, "soltar o CUE não voltou ao ponto")
            // CUE segurado + PLAY: continua tocando
            rule.runOnUiThread { vm.cueDown(0) }; SystemClock.sleep(300)
            rule.runOnUiThread { vm.togglePlay(0) }; rule.runOnUiThread { vm.cueUp(0) }
            SystemClock.sleep(600)
            check(vm.decks.value[0].playing, "CUE + PLAY deveria continuar tocando")
            app.djfusion.audio.NativeEngine.nativePause(0); SystemClock.sleep(300)
        }
        step("PRATO: borda empurra (pitch bend) sem mudar o pitch") {
            app.djfusion.audio.NativeEngine.nativePlay(0); SystemClock.sleep(300)
            val r0 = vm.decks.value[0].rate
            rule.runOnUiThread { vm.jogBend(0, true, 1.5f) }
            SystemClock.sleep(200)
            rule.runOnUiThread { vm.jogBend(0, false, 0f) }
            check(vm.decks.value[0].rate == r0, "empurrar mudou o pitch")
            rule.runOnUiThread { vm.cycleWaveZoom() }
            app.djfusion.audio.NativeEngine.nativePause(0); SystemClock.sleep(300)
        }
        step("SYNC iguala o andamento do B ao do A") {
            tap("Sync do deck B", substring = true)
            SystemClock.sleep(300)
            check(vm.decks.value[1].syncLock, "SYNC não travou")
            val b = vm.decks.value[1]
            check(abs(b.playedBpm - vm.decks.value[0].playedBpm) < 0.2, "B ${b.playedBpm} x A ${vm.decks.value[0].playedBpm}")
        }
        step("KEY liga o key-lock") {
            tap("Key-lock do deck A", substring = true)
            check(vm.decks.value[0].keyLock, "key-lock não ligou")
        }
        step("FONE liga a pré-escuta") {
            tap("Fone do deck A", substring = true)
            check(vm.decks.value[0].cueOn, "fone não ligou")
            tap("Fone do deck A", substring = true)
        }
        step("fader de TEMPO (arrastar)") {
            node("Tempo do deck A", substring = true).performTouchInput { swipeUp() }
            rule.waitForIdle()
            check(vm.decks.value[0].rate > 1.05f, "rate ${vm.decks.value[0].rate}")
            setProgress("Tempo do deck A. Para cima acelera, para baixo desacelera. Meio é a velocidade normal.", 0.5f)
            check(vm.decks.value[0].rate == 1f, "tempo não voltou ao meio")
        }
        step("TAP de BPM e visor (restante, tom em letras)") {
            rule.runOnUiThread {
                DisplayPrefsToggle()
            }
            val bpm0 = vm.decks.value[0].bpm
            val f0 = vm.decks.value[0].firstBeatFrame
            for (i in 0 until 5) { rule.runOnUiThread { vm.tapBpm(0) }; SystemClock.sleep(500) }
            log("info  TAP: ${vm.decks.value[0].bpm} BPM (batidas a cada 0,5 s)")
            check(abs(vm.decks.value[0].bpm - 120.0) < 3.0, "tap ${vm.decks.value[0].bpm}")
            rule.runOnUiThread { vm.setBeatGrid(0, bpm0, f0) }
            check(abs(vm.decks.value[0].bpm - bpm0) < 0.01 && vm.decks.value[0].firstBeatFrame == f0, "grade não voltou")
        }
        step("PITCH: faixa ±16/±25/±50/WIDE, fader e reset") {
            check(vm.decks.value[0].pitchRange == 16, "faixa inicial ${vm.decks.value[0].pitchRange}")
            tap("Faixa do pitch do deck A", substring = true)
            check(vm.decks.value[0].pitchRange == 25, "faixa ${vm.decks.value[0].pitchRange}")
            tap("Faixa do pitch do deck A", substring = true)
            check(vm.decks.value[0].pitchRange == 50, "faixa ${vm.decks.value[0].pitchRange}")
            rule.runOnUiThread { vm.setPitchFader(0, 1f) }
            check(abs(vm.decks.value[0].rate - 1.5f) < 0.001f, "rate ${vm.decks.value[0].rate}")
            rule.runOnUiThread { vm.setPitchRange(0, 100); vm.setPitchFader(0, 0.25f) }
            check(abs(vm.decks.value[0].rate - 0.5f) < 0.001f, "WIDE rate ${vm.decks.value[0].rate}")
            rule.runOnUiThread { vm.resetPitch(0); vm.setPitchRange(0, 16) }
            check(vm.decks.value[0].rate == 1f && vm.decks.value[0].pitchRange == 16, "reset")
        }
        step("SYNC travado mantém a batida colada (correção de fase)") {
            val n = app.djfusion.audio.NativeEngine
            fun phaseErr(): Double {
                val a = vm.decks.value[0]; val b = vm.decks.value[1]
                val ba = (pos(0) - a.firstBeatFrame) / (48000.0 * 60 / a.bpm)
                val bb = (pos(1) - b.firstBeatFrame) / (48000.0 * 60 / b.bpm)
                var e = (ba - Math.floor(ba)) - (bb - Math.floor(bb))
                if (e > 0.5) e -= 1.0 else if (e < -0.5) e += 1.0
                return e
            }
            n.nativeSeek(0, 48_000L * 5); n.nativeSeek(1, 48_000L * 9)
            n.nativePlay(0); n.nativePlay(1)
            SystemClock.sleep(500)
            rule.runOnUiThread { if (vm.decks.value[1].syncLock) vm.setSyncLock(1, false); vm.syncButton(1) }
            check(vm.decks.value[1].syncLock, "sync não travou")
            SystemClock.sleep(2500)
            val e1 = phaseErr()
            // empurra o deck B 0,2 batida para fora da fase: a trava deve trazer de volta
            val beatB = 48000.0 * 60 / vm.decks.value[1].bpm
            n.nativeSeek(1, pos(1) + (0.2 * beatB).toLong())
            SystemClock.sleep(4000)
            val e2 = phaseErr()
            log("info  fase com SYNC travado: ${"%.3f".format(e1)} batida; depois de empurrar 0,2: ${"%.3f".format(e2)} batida")
            check(abs(e1) < 0.03, "fase inicial ${e1}")
            check(abs(e2) < 0.04, "a trava não corrigiu: ${e2}")
            rule.runOnUiThread { vm.syncButton(1) }
            check(!vm.decks.value[1].syncLock, "não destravou")
            n.nativePause(0); n.nativePause(1)
            SystemClock.sleep(300)
        }
        step("knob de GRAVE (arrastar)") {
            node("Equalizador graves do deck A", substring = true).performTouchInput {
                swipe(center, center + Offset(0f, 600f), 400)
            }
            rule.waitForIdle()
            check(vm.decks.value[0].eq[0] < 0.3f, "eq grave ${vm.decks.value[0].eq[0]}")
        }
        step("knob de FILTRO e volume do canal") {
            setProgress("Filtro do deck A. Esquerda corta os agudos, direita corta os graves, meio desliga. Toque duplo zera.", 0.2f)
            check(vm.decks.value[0].filter < 0.3f, "filtro")
            node("Volume do deck B").performTouchInput { swipeDown() }
            rule.waitForIdle()
            check(vm.volumes.value[1] < 0.2f, "volume B ${vm.volumes.value[1]}")
            node("Volume do deck B").performTouchInput { swipeUp() }
        }
        step("CROSSFADER (toque na ponta)") {
            node("Crossfader", substring = true).performTouchInput { click(Offset(width - 4f, height / 2f)) }
            rule.waitForIdle()
            check(vm.crossfader.value > 0.9f, "crossfader ${vm.crossfader.value}")
            node("Crossfader", substring = true).performTouchInput { click(center) }
        }
        step("MASTER e FONE do mixer") {
            setProgress("Volume master", 0.6f)
            check(abs(vm.master.value - 0.6f) < 0.01f, "master")
            setProgress("Volume do fone", 0.4f)
            check(abs(vm.hpLevel.value - 0.4f) < 0.01f, "fone")
        }
        step("visão geral: toque leva ao meio da música") {
            node("Visão geral do deck A", substring = true).performTouchInput { click(center) }
            SystemClock.sleep(300)
            val len = vm.decks.value[0].lengthFrames
            check(abs(pos(0) - len / 2) < len / 20, "pos ${pos(0)} de $len")
        }
        step("SCRATCH no prato (deck parado)") {
            val p0 = pos(0)
            val c = center("Prato do deck A", true)
            val n = node("Prato do deck A", substring = true).fetchSemanticsNode()
            val r = n.size.width * 0.36f
            val pts = Array(41) { i ->
                val a = i * PI.toFloat() / 40f
                android.graphics.Point((c.x + r * cos(a)).toInt(), (c.y + r * sin(a)).toInt())
            }
            device.swipe(pts, 4)   // meia volta em ~0,8 s, em tempo real
            SystemClock.sleep(300)
            log("info  scratch moveu ${(pos(0) - p0) / 48000.0} s")
            check(abs(pos(0) - p0) > 9600, "scratch não moveu a música (${pos(0) - p0})")
        }
        shot("mixer_ajustado")

        step("PADS abre nos modos (CUES)") {
            tap("Abrir pads", substring = true)
            check(vm.decks.value[0].padsOpen, "pads não abriram")
            SystemClock.sleep(500)
            rule.waitForIdle()
            for (d in listOf("Hot cue 1 do deck A", "Hot cue 8 do deck A", "Efeito ECO do deck A", "Efeito TRANS do deck A",
                "Dividir o andamento", "Dobrar o andamento", "Voltar ao prato do deck A",
                "Modo dos pads CUES do deck A", "Modo dos pads LOOP do deck A", "Modo dos pads SAMPLER do deck A", "Modo dos pads MANOBRAS do deck A",
                "Modo dos pads ROLL do deck A", "Modo dos pads SALTO do deck A", "Modo dos pads GRADE do deck A")) center(d, true)
        }
        shot("pads_A")
        step("HOT CUE grava e volta") {
            tap("Hot cue 1 do deck A", substring = true)
            check(vm.decks.value[0].hotcues[0] >= 0, "hot cue não gravou")
            val d = vm.decks.value[0]
            if (vm.quantize.value && d.hasBpm) {
                val beat = 48000.0 * 60 / d.bpm
                val off = ((d.hotcues[0] - d.firstBeatFrame) / beat).let { it - Math.round(it) }
                log("info  QUANTIZE: hot cue a ${"%.3f".format(off)} batida da grade")
                check(abs(off) < 0.02, "hot cue fora da batida ($off)")
            }
        }
        step("EFEITOS eco e trans ligam") {
            tap("Efeito ECO do deck A", substring = true)
            check(vm.decks.value[0].fxType == 1, "eco não ligou")
            tap("Efeito TRANS do deck A", substring = true)
            check(vm.decks.value[0].fxType == 4, "trans não ligou")
            tap("Efeito TRANS do deck A", substring = true)
            check(vm.decks.value[0].fxType == 0, "efeito não desligou")
        }
        step("PULO DE BATIDA +4") {
            app.djfusion.audio.NativeEngine.nativePause(0); app.djfusion.audio.NativeEngine.nativePause(1)
            SystemClock.sleep(300)
            tap("Modo dos pads SALTO do deck A", substring = true)
            check(vm.decks.value[0].padMode == 5, "modo salto")
            SystemClock.sleep(400); rule.waitForIdle()
            shot("pads_salto")
            app.djfusion.audio.NativeEngine.nativePause(0)
            app.djfusion.audio.NativeEngine.nativeSeek(0, 48_000L * 10)
            SystemClock.sleep(400)
            val p0 = pos(0)
            tap("Pular +4 batida(s) no deck A", substring = true)
            SystemClock.sleep(400)
            val beat = 48000.0 * 60 / vm.decks.value[0].bpm
            check(abs((pos(0) - p0) - 4 * beat) < beat * 0.6, "pulou ${(pos(0) - p0) / beat} batidas")
        }
        step("ONDA: arrastar procura o ponto com a música parada") {
            app.djfusion.audio.NativeEngine.nativePause(0); app.djfusion.audio.NativeEngine.nativePause(1)
            app.djfusion.audio.NativeEngine.nativeSeek(0, 48_000L * 8)
            SystemClock.sleep(400); rule.waitForIdle()
            val p0 = pos(0)
            node("Onda do deck A", substring = true).performTouchInput { swipe(Offset(width * 0.8f, height / 2f), Offset(width * 0.3f, height / 2f), 400) }
            SystemClock.sleep(300)
            log("info  arrastar a onda: ${(pos(0) - p0) / 48000.0} s")
            check(pos(0) - p0 > 48_000L / 2, "arrastar a onda não andou (${pos(0) - p0})")
            shot("onda_arrastada")
        }
        step("GRADE: 1 aqui e BPM fino") {
            rule.runOnUiThread { vm.setPadMode(0, 6) }
            SystemClock.sleep(400); rule.waitForIdle()
            shot("pads_grade")
            val b0 = vm.decks.value[0].bpm
            rule.runOnUiThread { vm.adjustBpm(0, 0.1) }
            check(abs(vm.decks.value[0].bpm - (b0 + 0.1)) < 0.001, "bpm +0,1")
            rule.runOnUiThread { vm.adjustBpm(0, -0.1) }
            check(abs(vm.decks.value[0].bpm - b0) < 0.001, "bpm voltou")
            val f0 = vm.decks.value[0].firstBeatFrame
            rule.runOnUiThread { vm.downbeatHere(0) }
            val beat = 48000.0 * 60 / vm.decks.value[0].bpm
            val ph = ((pos(0) - vm.decks.value[0].firstBeatFrame) / (16 * beat)).let { it - Math.round(it) }
            check(abs(ph) < 0.01, "1 aqui fora do lugar ($ph)")
            rule.runOnUiThread { vm.setBeatGrid(0, b0, f0); vm.setPadMode(0, 0) }
        }
        step("÷2 e ×2 no BPM") {
            val b = vm.decks.value[0].bpm
            tap("Dividir o andamento", substring = true)
            check(abs(vm.decks.value[0].bpm - b / 2) < 0.01, "÷2")
            tap("Dobrar o andamento", substring = true)
            check(abs(vm.decks.value[0].bpm - b) < 0.01, "×2")
        }
        step("SAMPLER nos pads da tela") {
            tap("Modo dos pads SAMPLER do deck A", substring = true)
            check(vm.decks.value[0].padMode == 2, "modo sampler")
            SystemClock.sleep(400)
            rule.waitForIdle()
            shot("pads_sampler")
            vm.loadBuiltinPads(quiet = true)
            SystemClock.sleep(600)
            tap("Pad 1 do sampler (deck A)", substring = true)
            waitFor(2000, "buzina tocando") { vm.pads.value[0].playing }
        }
        step("modo LOOP") {
            tap("Modo dos pads LOOP do deck A", substring = true)
            check(vm.decks.value[0].padMode == 1, "modo loop")
            SystemClock.sleep(400)
            rule.waitForIdle()
            for (d in listOf("Loop de 4 batida(s) no deck A", "Loop de 1 batida(s) no deck A", "LOOP IN do deck A", "LOOP OUT do deck A", "RELOOP do deck A")) center(d, true)
            shot("pads_loop")
        }
        step("LOOP de 4 batidas liga e desliga") {
            tap("Tocar deck A")
            tap("Loop de 4 batida(s) no deck A", substring = true)
            check(vm.decks.value[0].loopBeats == 4, "loop não ligou")
            tap("Loop de 4 batida(s) no deck A", substring = true)
            check(vm.decks.value[0].loopBeats == 0, "loop não desligou")
        }
        step("LOOP MANUAL: IN, OUT e RELOOP") {
            app.djfusion.audio.NativeEngine.nativeSeek(0, 48_000L * 10)
            if (!vm.decks.value[0].playing) tap("Tocar deck A")
            SystemClock.sleep(400)
            tap("LOOP IN do deck A", substring = true)
            val a = vm.manualLoop.value[0].first
            check(a > 0, "loop in não marcou")
            SystemClock.sleep(1200)
            tap("LOOP OUT do deck A", substring = true)
            val b = vm.manualLoop.value[0].second
            check(vm.decks.value[0].loopBeats == -1 && b > a, "loop manual não ligou ($a..$b)")
            SystemClock.sleep(2500)
            val p = pos(0)
            log("info  loop manual ${a / 48000.0}..${b / 48000.0} s, posição ${p / 48000.0} s")
            check(p in (a - 2400)..(b + 2400), "saiu do loop: ${p / 48000.0} s")
            tap("RELOOP do deck A", substring = true)
            check(vm.decks.value[0].loopBeats == 0, "reloop não soltou")
        }
        step("SLIP: depois do loop a música volta onde estaria") {
            if (!vm.decks.value[0].slip) tap("Slip do deck A", substring = true)
            check(vm.decks.value[0].slip, "slip não ligou")
            app.djfusion.audio.NativeEngine.nativeSeek(0, 48_000L * 8)
            if (!vm.decks.value[0].playing) tap("Tocar deck A")
            SystemClock.sleep(600)
            val p0 = pos(0); val t0 = SystemClock.uptimeMillis()
            tap("Loop de 1 batida(s) no deck A", substring = true)
            check(vm.decks.value[0].loopBeats == 1, "loop de 1 não ligou")
            SystemClock.sleep(2200)
            tap("Loop de 1 batida(s) no deck A", substring = true)
            SystemClock.sleep(300)
            val exp = p0 + (SystemClock.uptimeMillis() - t0) / 1000.0 * 48000 * vm.decks.value[0].rate
            log("info  slip: posição ${pos(0) / 48000.0} s, esperada ${exp / 48000.0} s")
            check(abs(pos(0) - exp) < 48000 * 0.3, "slip não voltou ao ponto")
        }
        // manobras: precisa da tela parada para achar os botões novos
        if (vm.decks.value[0].playing) tap("Pausar deck A")
        SystemClock.sleep(300)
        step("modo MANOBRAS") {
            tap("Modo dos pads MANOBRAS do deck A", substring = true)
            check(vm.decks.value[0].padMode == 3, "modo manobras")
            SystemClock.sleep(400)
            rule.waitForIdle()
            for (d in listOf("Reverso do deck A", "Censura do deck A", "Capturar o compasso do deck A")) center(d, true)
            shot("pads_manobras")
        }
        step("CAPTURA: compasso vira loop num pad") {
            tap("Capturar o compasso do deck A", substring = true)
            waitFor(3000, "captura") { vm.pads.value.any { it.label.contains("CAPTURA") } }
        }
        step("GRADE de batidas anda 5 ms") {
            rule.runOnUiThread { vm.setPadMode(0, 6) }
            SystemClock.sleep(400); rule.waitForIdle()
            val f0 = vm.decks.value[0].firstBeatFrame
            tap("Grade de batidas do deck A 5 ms para frente", substring = true)
            val beat = (48000.0 * 60 / vm.decks.value[0].bpm).toLong()
            check((vm.decks.value[0].firstBeatFrame - f0 - 240).mod(beat) == 0L, "grade ${vm.decks.value[0].firstBeatFrame} (antes $f0)")
            rule.runOnUiThread { vm.setPadMode(0, 3) }
            // deixa a tela redesenhar os pads de MANOBRAS antes dos próximos toques (senão o toque cai na GRADE)
            SystemClock.sleep(300); rule.waitForIdle(); SystemClock.sleep(200)
        }
        step("REVERSO toca para trás e volta (com SLIP)") {
            app.djfusion.audio.NativeEngine.nativeSeek(0, 48_000L * 12)
            if (!vm.decks.value[0].playing) tap("Tocar deck A")
            SystemClock.sleep(500)
            val p0 = pos(0); val t0 = SystemClock.uptimeMillis()
            tap("Reverso do deck A", substring = true)
            check(vm.decks.value[0].reverse, "reverso não ligou")
            SystemClock.sleep(500); val r1 = pos(0)
            SystemClock.sleep(700); val r2 = pos(0)
            check(r2 < r1, "não andou para trás ($r1 -> $r2)")
            tap("Reverso do deck A", substring = true)
            check(!vm.decks.value[0].reverse, "reverso não desligou")
            SystemClock.sleep(300)
            val exp = p0 + (SystemClock.uptimeMillis() - t0) / 1000.0 * 48000 * vm.decks.value[0].rate
            check(abs(pos(0) - exp) < 48000 * 0.35, "depois do reverso: ${pos(0) / 48000.0} s, esperado ${exp / 48000.0} s")
        }
        step("CENSURA: 2 batidas para trás e volta no ponto certo") {
            val p0 = pos(0); val t0 = SystemClock.uptimeMillis()
            tap("Censura do deck A", substring = true)
            SystemClock.sleep(200)
            check(vm.decks.value[0].reverse, "censura não começou")
            waitFor(4000, "censura acabar") { !vm.decks.value[0].reverse }
            SystemClock.sleep(300)
            val exp = p0 + (SystemClock.uptimeMillis() - t0) / 1000.0 * 48000 * vm.decks.value[0].rate
            check(abs(pos(0) - exp) < 48000 * 0.3, "depois da censura: ${pos(0) / 48000.0} s, esperado ${exp / 48000.0} s")
        }
        if (vm.decks.value[0].playing) runCatching { tap("Pausar deck A") }
        SystemClock.sleep(300)
        step("ROLL repete e volta no ponto; PHASER e divisão do efeito") {
            tap("Modo dos pads ROLL do deck A", substring = true)
            check(vm.decks.value[0].padMode == 4, "modo roll")
            SystemClock.sleep(400)
            rule.waitForIdle()
            for (d in listOf("Roll de 1/4 de batida no deck A", "Efeito do deck A em 1/2 de batida", "Efeito PHASER do deck A")) center(d, true)
            shot("pads_roll")
            tap("Efeito PHASER do deck A", substring = true)
            check(vm.decks.value[0].fxType == 6, "phaser não ligou")
            tap("Efeito do deck A em 1/2 de batida", substring = true)
            check(vm.decks.value[0].fxBeats == 0.5f, "divisão ${vm.decks.value[0].fxBeats}")
            tap("Efeito PHASER do deck A", substring = true)
            app.djfusion.audio.NativeEngine.nativeSeek(0, 48_000L * 15)
            if (!vm.decks.value[0].playing) tap("Tocar deck A")
            SystemClock.sleep(500)
            val p0 = pos(0); val t0 = SystemClock.uptimeMillis()
            tap("Roll de 1/4 de batida no deck A", substring = true)
            check(vm.decks.value[0].rollBeats == 0.25f, "roll não ligou")
            SystemClock.sleep(600); val r1 = pos(0); SystemClock.sleep(400); val r2 = pos(0)
            val beat = 48000.0 * 60 / vm.decks.value[0].bpm
            check(abs(r2 - r1) < beat * 0.6 || r2 < r1, "não está repetindo (${r1} -> ${r2})")
            tap("Roll de 1/4 de batida no deck A", substring = true)
            SystemClock.sleep(300)
            val exp = p0 + (SystemClock.uptimeMillis() - t0) / 1000.0 * 48000
            log("info  roll: depois ${pos(0) / 48000.0} s, esperado ${exp / 48000.0} s")
            check(vm.decks.value[0].rollBeats == 0f, "roll não desligou")
            check(abs(pos(0) - exp) < 48000 * 0.3, "roll não voltou no ponto")
        }
        if (vm.decks.value[0].playing) runCatching { tap("Pausar deck A") }
        if (vm.decks.value[0].slip) tap("Slip do deck A", substring = true)
        runCatching { tap("Voltar ao prato do deck A", substring = true) }
        SystemClock.sleep(400)

        step("TOM ♯ e TOM automático (sem mudar o andamento)") {
            val bpm = vm.decks.value[0].playedBpm
            tap("Subir o tom do deck A", substring = true)
            check(vm.decks.value[0].keyShift == 1, "tom ${vm.decks.value[0].keyShift}")
            check(vm.decks.value[0].playedBpm == bpm, "andamento mudou")
            tap("Ajustar o tom do deck A", substring = true)
            val a = vm.decks.value[0].shownKey; val b = vm.decks.value[1].shownKey
            log("info  tom A ${a?.code} (deslocado ${vm.decks.value[0].keyShift}) x B ${b?.code}")
            check(app.djfusion.harmony.MixAdvisor.keyRelation(b, a).keyScore <= 0.6, "tons não combinam: ${a?.code} x ${b?.code}")
            vm.setKeyShift(0, 0)
        }
        step("STEMS separam e mixam voz, bateria, baixo e melodia") {
            waitFor(90_000, "stems do deck A") { vm.decks.value[0].stemsReady }
            tap("Abrir stems do deck A", substring = true)
            check(vm.decks.value[0].stemsOpen, "painel de stems não abriu")
            SystemClock.sleep(500)
            rule.waitForIdle()
            shot("stems_A")
            tap("Instrumental do deck A", substring = true)
            check(vm.decks.value[0].stemGains == listOf(0f, 1f, 1f, 1f), "instrumental ${vm.decks.value[0].stemGains}")
            setProgress("Volume do stem BATERIA do deck A", 0.3f)
            check(abs(vm.decks.value[0].stemGains[1] - 0.3f) < 0.02f, "fader bateria ${vm.decks.value[0].stemGains}")
            tap("Acapella do deck A", substring = true)
            check(vm.decks.value[0].stemGains == listOf(1f, 0f, 0f, 0f), "acapella ${vm.decks.value[0].stemGains}")
            tap("Todos os stems do deck A de volta", substring = true)
            check(vm.decks.value[0].stemGains.all { it == 1f }, "tudo ${vm.decks.value[0].stemGains}")
            tap("Fechar stems do deck A", substring = true)
            check(!vm.decks.value[0].stemsOpen, "stems não fechou")
            rule.waitForIdle()
        }
        step("AUTO-GAIN iguala o volume") {
            val d = vm.decks.value[0]
            log("info  volume medido ${d.loudness} dBFS, ganho ${d.trim}")
            check(d.loudness < -1f, "volume não medido")
            val exp = Math.pow(10.0, (AppViewModel.TARGET_DB - d.loudness) / 20.0).toFloat().coerceIn(0.25f, 2.5f)
            check(vm.autoGain.value && abs(d.trim - exp) < 0.01f, "ganho ${d.trim}, esperado $exp")
            tap("Auto-gain", substring = true)
            check(!vm.autoGain.value && vm.decks.value[0].trim == 1f, "auto-gain não desligou")
            tap("Auto-gain", substring = true)
            check(vm.autoGain.value, "auto-gain não religou")
        }
        shot("stems_tom_ganho")

        tab("AMOSTRAS")
        step("AMOSTRAR gera pads") {
            tap("Escolher sozinho os melhores trechos", substring = true)
            waitFor(20_000, "amostras") { vm.pads.value.any { it.ready && it.loop } }
            log("info  pads: " + vm.pads.value.joinToString { it.label })
        }
        shot("amostras")
        step("pad de amostra toca") {
            val i = vm.pads.value.indexOfFirst { it.ready && it.loop }
            rule.waitForIdle()
            tap("Pad ${i + 1}:", substring = true)
            waitFor(3000, "pad tocando") { vm.pads.value[i].playing }
            tap("Pad ${i + 1}:", substring = true)
            waitFor(3000, "pad parou") { !vm.pads.value[i].playing }
        }
        step("volume das amostras") {
            setProgress("Volume das amostras", 0.5f)
            check(abs(vm.samplerVol.value - 0.5f) < 0.01f, "vol")
        }

        tab("EFEITOS")
        shot("efeitos")
        rule.waitForIdle()
        for (d in listOf("Efeito ECO do deck A (tela", "Filtro automático do deck A", "Freio do deck A", "Volta do deck A", "Echo out do deck B")) center(d, true)
        step("EFEITOS novos: FILTRO LFO e WOBBLE") {
            rule.runOnUiThread { vm.setFx(0, 7) }
            check(vm.decks.value[0].fxType == 7, "filtro lfo")
            rule.runOnUiThread { vm.setFx(0, 8) }
            check(vm.decks.value[0].fxType == 8, "wobble")
            rule.runOnUiThread { vm.setFx(0, 8) }
            check(vm.decks.value[0].fxType == 0, "desligar")
        }
        step("EFEITOS: eco liga pela tela de efeitos") {
            tap("Efeito ECO do deck A (tela", substring = true)
            check(vm.decks.value[0].fxType == 1, "eco ${vm.decks.value[0].fxType}")
            tap("Efeito ECO do deck A (tela", substring = true)
        }
        step("3 EFEITOS juntos (encaixes FX1, FX2 e FX3)") {
            tap("Efeito ECO do deck A (tela", substring = true)
            tap("Encaixe FX2 do deck A (tela", substring = true)
            check(vm.decks.value[0].fxSel == 1, "encaixe FX2 ${vm.decks.value[0].fxSel}")
            tap("Efeito REVERB do deck A (tela", substring = true)
            tap("Encaixe FX3 do deck A (tela", substring = true)
            tap("Efeito PHASER do deck A (tela", substring = true)
            val d = vm.decks.value[0]
            log("info  efeitos: FX1=${d.fxType} FX2=${d.fx2Type} FX3=${d.fx3Type}")
            check(d.fxType == 1 && d.fx2Type == 3 && d.fx3Type == 6, "três efeitos: ${d.fxType} ${d.fx2Type} ${d.fx3Type}")
            SystemClock.sleep(400); shot("tres_efeitos")
            tap("Desligar os 3 efeitos do deck A", substring = true)
            check(vm.decks.value[0].let { it.fxType == 0 && it.fx2Type == 0 && it.fx3Type == 0 }, "desligar os 3")
            tap("Encaixe FX1 do deck A (tela", substring = true)
            check(vm.decks.value[0].fxSel == 0, "voltar ao FX1")
        }
        step("FILTRO AUTO sobe o filtro sozinho") {
            tap("Filtro automático do deck A", substring = true)
            SystemClock.sleep(3000)
            check(vm.decks.value[0].filter > 0.55f, "filtro ${vm.decks.value[0].filter}")
        }
        step("GRAVAR grava o set num WAV") {
            app.djfusion.audio.NativeEngine.nativeSeek(0, 48_000L * 5)
            app.djfusion.audio.NativeEngine.nativePlay(0)
            tap("Gravar o set", substring = true)
            waitFor(3000, "gravando") { vm.recordingSince.value != null }
            SystemClock.sleep(3000)
            tap("Parar a gravação do set e salvar", substring = true)
            waitFor(8000, "set salvo") { vm.message.value?.startsWith("Set gravado") == true }
            log("info  ${vm.message.value}")
        }
        step("FREIO para o disco devagar") {
            app.djfusion.audio.NativeEngine.nativePlay(0)
            SystemClock.sleep(500)
            tap("Freio do deck A", substring = true)
            waitFor(4000, "parar") { !vm.decks.value[0].playing }
        }
        step("VOLTA gira o disco para trás") {
            app.djfusion.audio.NativeEngine.nativePlay(0); SystemClock.sleep(700)
            val p0 = pos(0)
            tap("Volta do deck A", substring = true)
            waitFor(4000, "parar") { !vm.decks.value[0].playing }
            check(pos(0) < p0, "não voltou (${pos(0)} >= $p0)")
        }
        shot("efeitos_usados")
        app.djfusion.audio.NativeEngine.nativePause(0)
        SystemClock.sleep(300)

        tab("CONTROLADORA")
        step("mapa da DJ2GO2 Touch") {
            rule.waitForIdle()
            node("Aplicar o mapa de fábrica da Numark DJ2GO2 Touch").performScrollTo()
            rule.waitForIdle()
            tap("Aplicar o mapa de fábrica da Numark DJ2GO2 Touch")
            waitFor(2000, "mapa") { vm.midi.mapped.value.size >= 40 }
            check(vm.jog.ticksPerRev == 236, "jog ${vm.jog.ticksPerRev}")
        }
        tab("AJUSTES")
        step("AJUSTES: latência baixa, normal e quantize") {
            rule.waitForIdle()
            tap("Seção de ajustes SOM", substring = true); SystemClock.sleep(300); rule.waitForIdle()
            node("Latência baixa", true).performScrollTo(); rule.waitForIdle()
            tap("Latência baixa", substring = true)
            waitFor(2000, "latência baixa") { vm.latency.value == 0 }
            SystemClock.sleep(1200)
            log("info  latência baixa: ${vm.audioStatus.value}")
            tap("Latência normal", substring = true)
            waitFor(2000, "latência normal") { vm.latency.value == 1 }
            tap("Seção de ajustes PRATOS", substring = true); SystemClock.sleep(300); rule.waitForIdle()
            node("Modo vinil desligado", true).performScrollTo(); rule.waitForIdle()
            tap("Modo vinil desligado", substring = true)
            waitFor(2000, "vinil off") { !vm.vinyl.value }
            node("Modo vinil ligado", true).performScrollTo(); rule.waitForIdle()
            tap("Modo vinil ligado", substring = true)
            waitFor(2000, "vinil on") { vm.vinyl.value }
            tap("Seção de ajustes MIXAGEM", substring = true); SystemClock.sleep(300); rule.waitForIdle()
            node("Quantize desligado", true).performScrollTo(); rule.waitForIdle()
            tap("Quantize desligado", substring = true)
            waitFor(2000, "quantize off") { !vm.quantize.value }
            node("Quantize ligado", true).performScrollTo(); rule.waitForIdle()
            tap("Quantize ligado", substring = true)
            waitFor(2000, "quantize on") { vm.quantize.value }
            shot("ajustes")
            rule.runOnUiThread { vm.exportBackup() }
            waitFor(8000, "backup") { vm.message.value?.contains("Backup salvo") == true }
            log("info  " + vm.message.value)
        }
        step("saída de áudio: modo dividido") {
            tap("Seção de ajustes SOM", substring = true); SystemClock.sleep(300); rule.waitForIdle()
            node("Modo de saída", true).performScrollTo(); rule.waitForIdle()
            tap("Modo de saída", substring = true)
            SystemClock.sleep(1500)
            log("info  saída: ${vm.outputNote.value}")
            vm.setOutputMode(0)
            SystemClock.sleep(1000)
        }
        step("MIXAGEM: curva do crossfader") {
            tap("Seção de ajustes MIXAGEM", substring = true); SystemClock.sleep(300); rule.waitForIdle()
            node("Crossfader mixagem", true).performScrollTo(); rule.waitForIdle()
            tap("Crossfader mixagem", substring = true)
            waitFor(2000, "curva mixagem") { vm.xfCurve.value == 1 }
            tap("Crossfader corte", substring = true)
            waitFor(2000, "curva corte") { vm.xfCurve.value == 2 }
            tap("Crossfader suave", substring = true)
            waitFor(2000, "curva suave") { vm.xfCurve.value == 0 }
            shot("ajustes_mixagem")
        }
        step("TELA: cor das ondas (vermelho, cinza, espectro)") {
            tap("Seção de ajustes TELA", substring = true); SystemClock.sleep(300); rule.waitForIdle()
            tap("Ondas em tons de cinza", substring = true)
            waitFor(2000, "cinza") { DisplayPrefs.waveStyle == 1 }
            tap("Ondas coloridas pelo espectro", substring = true)
            waitFor(2000, "espectro") { DisplayPrefs.waveStyle == 2 }
            tap("Ondas em tons de vermelho", substring = true)
            waitFor(2000, "vermelho") { DisplayPrefs.waveStyle == 0 }
            tap("Onda em 3 bandas", substring = true)
            waitFor(2000, "3 bandas") { DisplayPrefs.waveType == 1 }
            shot("ajustes_tela_3bandas")
            tap("Onda em contorno", substring = true)
            waitFor(2000, "contorno") { DisplayPrefs.waveType == 2 }
            tap("Onda RGB", substring = true)
            waitFor(2000, "rgb") { DisplayPrefs.waveType == 0 }
            shot("ajustes_tela")
        }
        step("SOM volta sozinho quando a saída cai (controladora tirada)") {
            val nE = app.djfusion.audio.NativeEngine
            val c0 = nE.nativeAudioCallbacks()
            SystemClock.sleep(300)
            check(nE.nativeAudioCallbacks() != c0, "o som não estava rodando antes")
            nE.nativeDebugKillStream()
            SystemClock.sleep(400)
            val c1 = nE.nativeAudioCallbacks()
            SystemClock.sleep(300)
            check(nE.nativeAudioCallbacks() == c1, "a saída não caiu no teste")
            waitFor(8000, "som religado") { val a = nE.nativeAudioCallbacks(); SystemClock.sleep(200); nE.nativeAudioCallbacks() != a }
            log("info  " + vm.message.value)
        }
        step("CUES AUTOMÁTICAS e nome da hot cue") {
            rule.runOnUiThread { vm.prepareCues(0) }
            waitFor(3000, "cues automáticas") { (0..3).any { vm.decks.value[0].hotcues[it] >= 0 } }
            val d = vm.decks.value[0]
            log("info  cues automáticas: " + (0..3).joinToString { "${it + 1}=${if (d.hotcues[it] >= 0) "%.1fs %s".format(d.hotcues[it] / 48000.0, d.hotcueNames[it]) else "—"}" })
            val beat = 48000.0 * 60 / d.bpm
            for (sl in 0..3) if (d.hotcues[sl] >= 0) {
                val off = ((d.hotcues[sl] - d.firstBeatFrame) / beat).let { it - Math.round(it) }
                check(abs(off) < 0.02, "cue automática ${sl + 1} fora da batida ($off)")
            }
            val slot = (0..3).first { d.hotcues[it] >= 0 }
            rule.runOnUiThread { vm.openCueEdit(0, slot) }
            rule.waitForIdle(); SystemClock.sleep(300)
            shot("menu_hot_cue")
            tap("Nome DROP para a hot cue ${slot + 1} do deck A", substring = true)
            waitFor(2000, "nome") { vm.decks.value[0].hotcueNames[slot] == "DROP" }
            check(vm.cueEdit.value == null, "menu não fechou")
            rule.runOnUiThread { for (sl in 0..3) vm.clearHotcue(0, sl) }
            check((0..3).all { vm.decks.value[0].hotcues[it] < 0 }, "limpar cues")
        }
        step("PROTEÇÃO contra silêncio: o final entra em loop") {
            val nE = app.djfusion.audio.NativeEngine
            nE.nativePause(1); nE.nativePause(0)
            rule.runOnUiThread { vm.setSilenceGuard(true) }
            val d = vm.decks.value[0]
            check(d.loopBeats == 0, "deck A já em loop")
            val beat = 48000.0 * 60 / d.bpm
            val end = app.djfusion.harmony.TrackShape.musicalEnd(d.wave, d.lengthFrames)
            nE.nativeSeek(0, (end - 9 * beat).toLong())
            SystemClock.sleep(300)
            nE.nativePlay(0)
            waitFor(4000, "loop de proteção") { vm.decks.value[0].loopBeats == 4 }
            SystemClock.sleep(2500)
            check(vm.decks.value[0].playing, "o som parou")
            check(pos(0) < end, "passou do fim (${pos(0)} >= $end)")
            log("info  ${vm.message.value}")
            rule.runOnUiThread { vm.toggleLoop(0, 4); vm.setSilenceGuard(false) }
            nE.nativePause(0)
            SystemClock.sleep(300)
            check(vm.decks.value[0].loopBeats == 0, "loop não soltou")
        }
        tab("CONTROLADORA")
        shot("controladora")
        step("DJ2GO2 simulada: BROWSE, LOAD, hot cue, loop manual, sampler e jog") {
            fun midi(vararg b: Int) = rule.runOnUiThread { vm.midi.inject(ByteArray(b.size) { b[it].toByte() }) }
            vm.midi.applyDj2go2()
            app.djfusion.audio.NativeEngine.nativePause(0); app.djfusion.audio.NativeEngine.nativePause(1)
            SystemClock.sleep(300)
            // BROWSE gira 2 passos e LOAD B carrega a música destacada
            midi(0xBF, 0x00, 0x01); midi(0xBF, 0x00, 0x01)
            val idx = vm.browseIndex.value
            val want = vm.tracks.value[idx]
            midi(0x9F, 0x03, 0x7F); midi(0x8F, 0x03, 0x00)
            waitFor(30_000, "LOAD B") { vm.decks.value[1].let { it.trackId == want.id && it.loaded && !it.loading && !it.analyzing } }
            // play pela controladora
            midi(0x91, 0x00, 0x7F); midi(0x81, 0x00, 0x00)
            waitFor(2000, "play B") { vm.decks.value[1].playing }
            // modo CUES: pad 2 grava hot cue; segurando PAD MODE (0x0A) apaga
            midi(0x95, 0x02, 0x7F); midi(0x85, 0x02, 0x00)
            waitFor(2000, "hot cue 2") { vm.decks.value[1].hotcues[1] >= 0 }
            midi(0x95, 0x0A, 0x7F)
            waitFor(2000, "apagar hot cue 2") { vm.decks.value[1].hotcues[1] < 0 }
            // modo MANUAL: IN, espera, OUT
            midi(0x95, 0x21, 0x7F); SystemClock.sleep(1000); midi(0x95, 0x22, 0x7F)
            waitFor(2000, "loop manual") { vm.decks.value[1].loopBeats == -1 }
            midi(0x95, 0x23, 0x7F)
            waitFor(2000, "reloop solta") { vm.decks.value[1].loopBeats == 0 }
            // modo AUTO: loop de 2
            midi(0x95, 0x12, 0x7F)
            waitFor(2000, "auto loop 2") { vm.decks.value[1].loopBeats == 2 }
            midi(0x95, 0x12, 0x7F)
            // modo SAMPLER: pad 5 (primeiro do deck B)
            vm.loadBuiltinPads(quiet = true); SystemClock.sleep(500)
            midi(0x95, 0x31, 0x7F)
            waitFor(3000, "sampler pad 5") { vm.pads.value[4].playing }
            // jog: dedo no prato segura a música; girar para trás volta
            val p0 = pos(1)
            midi(0x91, 0x06, 0x7F)
            for (k in 0 until 40) { midi(0xB1, 0x06, 0x7C); SystemClock.sleep(10) }   // -4 passos por mensagem
            SystemClock.sleep(150)
            val p1 = pos(1)
            midi(0x81, 0x06, 0x00)
            log("info  jog: ${p0 / 48000.0} s -> ${p1 / 48000.0} s")
            check(p1 < p0, "jog para trás não voltou a música ($p0 -> $p1)")
            SystemClock.sleep(400)
            check(vm.decks.value[1].playing, "soltar o prato não voltou a tocar")
            midi(0x91, 0x00, 0x7F)
            waitFor(2000, "pause B") { !vm.decks.value[1].playing }
            log("info  diagnóstico (início): " + vm.diagnosticsText().lines().take(12).joinToString(" | "))
        }
        step("MAPAS PRONTOS: controladoras conhecidas no app") {
            val all = app.djfusion.midi.MidiPresets.all(ctx)
            log("info  mapas prontos: ${all.size}")
            check(all.size >= 50, "só ${all.size} mapas prontos")
            val ddj = app.djfusion.midi.MidiPresets.match(ctx, "DDJ-400")
            log("info  DDJ-400 -> ${ddj?.name} (${ddj?.map?.size} controles)")
            check(ddj != null && ddj.name.contains("400"), "DDJ-400 não reconhecida")
            check(app.djfusion.midi.MidiPresets.match(ctx, "XYZ desconhecida") == null, "reconheceu aparelho inexistente")
        }
        step("MAPEAR: assistente essencial pede só o que falta") {
            rule.runOnUiThread { vm.midi.startWizard(essentialOnly = true) }
            SystemClock.sleep(300); rule.waitForIdle()
            val l = vm.midi.learning.value
            log("info  assistente essencial começou em: $l")
            check(l != null && l in app.djfusion.midi.MidiTargets.essential, "assistente pediu $l")
            rule.runOnUiThread { vm.midi.skipLearn() }
            check(vm.midi.learning.value != l, "PULAR não andou")
            shot("mapear")
            rule.runOnUiThread { vm.midi.cancelLearn() }
        }
        step("CONTROLADORA qualquer: aviso de modo ignorado, codificações do prato, calibração e BUSCA") {
            fun midi(vararg b: Int) = rule.runOnUiThread { vm.midi.inject(ByteArray(b.size) { b[it].toByte() }) }
            val nE = app.djfusion.audio.NativeEngine
            nE.nativePause(0); nE.nativePause(1); SystemClock.sleep(300)
            // ENSINAR ignora nota fraca (aviso da controladora) e aprende o aperto de verdade
            rule.runOnUiThread { vm.midi.learn("d1.slip") }
            midi(0x94, 0x00, 0x07)
            SystemClock.sleep(100)
            check(vm.midi.learning.value == "d1.slip", "aprendeu nota fraca")
            midi(0x94, 0x00, 0x7F)
            waitFor(1000, "aprender SLIP") { vm.midi.learning.value == null && vm.midi.mapped.value["d1.slip"] != null }
            // a mesma nota fraca em dois canais (troca de modo da controladora) não aciona nada
            val slip0 = vm.decks.value[1].slip
            midi(0x94, 0x00, 0x07); midi(0x95, 0x00, 0x07)
            SystemClock.sleep(200)
            check(vm.decks.value[1].slip == slip0, "aviso de modo acionou o SLIP")
            midi(0x94, 0x00, 0x7F); midi(0x84, 0x00, 0x00)
            waitFor(1000, "SLIP pelo botão") { vm.decks.value[1].slip != slip0 }
            rule.runOnUiThread { if (vm.decks.value[1].slip != slip0) vm.toggleSlip(1); vm.midi.clear("d1.slip") }
            // prato em modo ABSOLUTO (0..127): com o dedo, 9 passos de 10 = 90 passos para frente
            rule.runOnUiThread { vm.midi.setJogMode(0, 4) }
            nE.nativeSeek(0, 48_000L * 5); SystemClock.sleep(300)
            val p0 = pos(0)
            midi(0x90, 0x06, 0x7F)
            for (v in 10..100 step 10) { midi(0xB0, 0x06, v); SystemClock.sleep(10) }
            SystemClock.sleep(200)
            val p1 = pos(0)
            midi(0x80, 0x06, 0x00)
            val expect = 90 * 48000.0 * 1.8 / vm.jog.ticksPerRev
            log("info  prato absoluto: ${(p1 - p0) / 48000.0} s (esperado ${expect / 48000.0} s)")
            check(abs((p1 - p0) - expect) < 48000 * 0.05, "prato absoluto andou ${p1 - p0}, esperado $expect")
            rule.runOnUiThread { vm.midi.setJogMode(0, 0) }
            // calibração: uma volta da DJ2GO2 = 236 passos
            rule.runOnUiThread { vm.jog.startCalibration(0) }
            for (k in 0 until 59) midi(0xB0, 0x06, 0x04)
            val n = vm.jog.finishCalibration()
            check(n == 236 && vm.jog.ticksPerRev == 236, "calibração deu $n")
            // BUSCA: o prato corre a música 20 vezes mais rápido
            rule.runOnUiThread { vm.jog.setSearch(0, true) }
            nE.nativeSeek(0, 48_000L * 3); SystemClock.sleep(300)
            val s0 = pos(0)
            for (k in 0 until 10) { midi(0xB0, 0x06, 0x05); SystemClock.sleep(5) }
            SystemClock.sleep(300)
            log("info  BUSCA: ${(pos(0) - s0) / 48000.0} s com 50 passos")
            check(pos(0) - s0 > 48_000L * 5, "BUSCA andou só ${(pos(0) - s0) / 48000.0} s")
            rule.runOnUiThread { vm.jog.setSearch(0, false) }
        }

        tab("BIBLIOTECA")
        rule.waitForIdle()
        step("HARMONIZAR monta a ordem do set") {
            tap("Harmonizar", substring = true)
            waitFor(30_000, "set") { vm.setOrder.value.size >= 2 }
            log("info  set: " + vm.setOrder.value.joinToString())
            check(vm.tracks.value.all { it.energyLevel in 1..10 }, "energia não medida")
            log("info  energia: " + vm.tracks.value.joinToString { "${it.title}=E${it.energyLevel}" })
        }
        shot("harmonizado")
        step("PLAYLIST: salvar, tirar música e abrir") {
            vm.savePlaylist("Festa")
            waitFor(2000, "salva") { vm.playlists.value["Festa"]?.size == vm.setOrder.value.size && vm.activePlaylist.value == "Festa" }
            vm.setSearch("e2e_100")
            SystemClock.sleep(800)
            rule.waitForIdle()
            tap("Tirar e2e_100 na playlist", substring = true)
            val id100 = vm.tracks.value.first { it.title.startsWith("e2e_100") }.id
            waitFor(2000, "tirar") { id100 !in vm.setOrder.value && vm.playlists.value["Festa"]?.contains(id100) == false }
            vm.setSearch("")
            SystemClock.sleep(800)
            rule.waitForIdle()
            tap("Playlists: abrir", substring = true)
            SystemClock.sleep(600)
            rule.waitForIdle()
            shot("playlists")
            tap("Abrir a playlist Festa", substring = true)
            waitFor(3000, "abrir") { vm.activePlaylist.value == "Festa" && vm.sort.value == app.djfusion.data.SortOrder.SET }
            rule.waitForIdle()
            log("info  playlist Festa: " + vm.setOrder.value.joinToString())
        }
        tab("DJ LIVE")
        step("AUTO DJ escolhe, carrega e mixa sozinho") {
            tap("AUTO DJ: o programa", substring = true)
            waitFor(30_000, "AUTO DJ preparar a próxima") { vm.autoDj.state.value.status.startsWith("Próxima") }
            shot("autodj_proxima")
            // adianta a música atual para perto do fim para não esperar a faixa inteira
            val cur = if (vm.decks.value[0].playing) 0 else 1
            val len = vm.decks.value[cur].lengthFrames
            app.djfusion.audio.NativeEngine.nativeSeek(cur, len - 48_000L * 22)
            waitFor(45_000, "mixagem começar") { vm.autoDj.state.value.mixing }
            shot("autodj_mixando")
            waitFor(40_000, "mixagem terminar") { !vm.autoDj.state.value.mixing && vm.decks.value[1 - cur].playing }
            check(!vm.decks.value[cur].playing, "deck que saiu continua tocando")
            check(abs(vm.crossfader.value - (if (cur == 0) 1f else 0f)) < 0.05f, "crossfader ${vm.crossfader.value}")
        }
        shot("autodj_depois")
        step("AUTO DJ: MIXAR AGORA começa a transição no próximo compasso") {
            waitFor(40_000, "próxima preparada") { vm.autoDj.state.value.status.startsWith("Próxima") }
            val t0 = SystemClock.uptimeMillis()
            rule.runOnUiThread { vm.autoDj.mixNow() }
            waitFor(15_000, "mixar agora") { vm.autoDj.state.value.mixing }
            log("info  MIXAR AGORA: transição começou em ${(SystemClock.uptimeMillis() - t0) / 1000.0} s")
        }
        step("HISTÓRICO: músicas que foram ao ar") {
            log("info  histórico: " + vm.history.value.joinToString { it.title })
            check(vm.history.value.size >= 2, "histórico com ${vm.history.value.size}")
        }
        step("AUTO DJ: tela mostra a próxima com nota, motivo e alternativas") {
            tab("AUTO DJ")
            SystemClock.sleep(1500)   // com música tocando a tela nunca fica parada: espera um pouco em vez de waitForIdle
            val pl = vm.autoDj.plan.value
            log("info  próxima: ${pl.next?.row?.title} ${pl.next?.compat}% · ${pl.next?.why} · ${pl.style} · ${pl.beats} batidas · alternativas ${pl.alternatives.size}")
            check(pl.next != null && pl.next.compat in 0..100 && pl.next.why.isNotEmpty(), "plano vazio")
            shot("autodj_tela")
            tab("DJ LIVE")
        }
        step("AUTO DJ desliga") {
            tap("AUTO DJ: o programa", substring = true)
            waitFor(3000, "desligar") { !vm.autoDj.state.value.active }
        }
        step("TOCAR PASTA: o AUTO DJ toca e mixa uma pasta sozinho") {
            app.djfusion.audio.NativeEngine.nativePause(0); app.djfusion.audio.NativeEngine.nativePause(1)
            tab("AUTO DJ")
            rule.waitForIdle()
            tap("Tocar uma pasta inteira com o AUTO DJ", substring = true)
            pickFolder()
            waitFor(60_000, "AUTO DJ com a pasta") { vm.autoDj.state.value.active && vm.autoDj.plan.value.source.startsWith("pasta") }
            waitFor(60_000, "tocando sozinho") { vm.decks.value.any { it.playing } && vm.autoDj.state.value.status.startsWith("Próxima") }
            log("info  TOCAR PASTA: ${vm.autoDj.plan.value.source} · ${vm.autoDj.state.value.status}")
            shot("tocar_pasta")
            rule.runOnUiThread { vm.autoDj.stop(); vm.autoDj.clearPool() }
            app.djfusion.audio.NativeEngine.nativePause(0); app.djfusion.audio.NativeEngine.nativePause(1)
            tab("DJ LIVE")
        }

        app.djfusion.audio.NativeEngine.nativePause(0)
        app.djfusion.audio.NativeEngine.nativePause(1)
        SystemClock.sleep(500)
        tab("BIBLIOTECA")
        rule.waitForIdle()
        step("remover faixa da biblioteca") {
            vm.setSort(app.djfusion.data.SortOrder.RECENT)
            vm.setSearch("e2e_100")
            SystemClock.sleep(800)
            rule.waitForIdle()
            val before = vm.tracks.value.size
            tap("Remover e2e_100 da biblioteca", substring = true)
            waitFor(3000, "remover") { vm.tracks.value.size == before - 1 }
        }
        shot("fim")

        val crash = shell("logcat -d -s AndroidRuntime:E")
        if (crash.contains("FATAL")) { fails++; log("FALHA app travou: ${crash.takeLast(1500)}") }
        log("RESUMO falhas=$fails")
        assertTrue("$fails passo(s) falharam (veja E2E no logcat)", fails == 0)
    }
}
