package app.djfusion.midi

import android.content.Context

/**
 * Mapas prontos de controladoras MIDI (arquivo assets/controladoras.json). Os números de cada botão foram
 * extraídos dos mapas públicos do Mixxx (res/controllers, licença GPL-2.0 ou posterior): só a tabela
 * "controle do app -> nota/controle MIDI", sem código. Controles que no Mixxx dependem de script entram por
 * aproximação (prato, play, cue…) e podem ser corrigidos em MAPEAR.
 */
object MidiPresets {
    data class Preset(val name: String, val file: String, val map: Map<String, Int>, val rel: Map<String, Int>)

    @Volatile private var cache: List<Preset>? = null

    fun all(context: Context): List<Preset> {
        cache?.let { return it }
        // mapas do Mixxx + mapas conferidos pelo próprio app (controladoras que o Mixxx não tem, como a Party Mix Live)
        val list = (read(context, "controladoras.json") + read(context, "controladoras-extra.json"))
            .distinctBy { it.name }.sortedBy { it.name.lowercase() }
        cache = list
        return list
    }

    private fun read(context: Context, file: String): List<Preset> =
        try {
            val txt = context.assets.open(file).bufferedReader().use { it.readText() }
            val root = org.json.JSONObject(txt)
            val arr = root.getJSONArray("presets")
            (0 until arr.length()).mapNotNull { i ->
                val o = arr.getJSONObject(i)
                val m = o.getJSONObject("m")
                val map = HashMap<String, Int>()
                for (k in m.keys()) if (MidiTargets.get(k) != null) map[k] = m.getInt(k)
                val r = o.optJSONObject("r")
                val rel = HashMap<String, Int>()
                if (r != null) for (k in r.keys()) rel[k] = r.getInt(k)
                if (map.size < 6) null else Preset(o.getString("n"), o.optString("f", o.getString("n")), map, rel)
            }
        } catch (_: Exception) {
            emptyList()
        }

    /**
     * Acertos que o mapa extraído do Mixxx não traz (ou que ficaram invertidos), conferidos no relatório de diagnóstico da própria
     * controladora: sentido do fader de tempo, BROWSE e os botões de empurrar o prato.
     */
    fun fix(presetName: String, map: MidiMap) {
        if (presetName == "Numark DJ2Go") {
            fun cc(n: Int) = (0xB0 shl 16) or n
            fun note(n: Int) = (0x90 shl 16) or n
            for (d in 0..1) map.setRel("d$d.tempo", 2)   // o fader de tempo da DJ2Go chegava ao contrário (em cima acelerava)
            map.assign("browse", cc(26)); map.setRel("browse", 0)   // CC 26: 1 = gira para frente, 127 = para trás
            map.assign("d0.benddown", note(67)); map.assign("d0.bendup", note(68))
            map.assign("d1.benddown", note(69)); map.assign("d1.bendup", note(70))
        }
    }

    private fun norm(s: String) = s.lowercase().filter { it.isLetterOrDigit() }

    /** Mapa pronto que combina com o nome do aparelho (o mais específico), ou null. */
    fun match(context: Context, deviceName: String): Preset? {
        val dev = norm(deviceName)
        if (dev.length < 3) return null
        var best: Preset? = null
        var bestLen = 0
        for (p in all(context)) {
            for (cand in listOf(p.name, p.file)) {
                val c = norm(cand)
                // o nome do aparelho costuma ser o modelo sem a marca ("DDJ-400"); o mapa tem marca + modelo
                // (nome só com letras, como "Party Mix Live", também vale quando é comprido o bastante para não ser ambíguo)
                val ok = (c.contains(dev) && (dev.any { it.isDigit() } || dev.length >= 9)) || (dev.contains(c) && c.length >= 5)
                val score = minOf(c.length, dev.length)
                if (ok && score > bestLen) { best = p; bestLen = score }
            }
        }
        return best
    }
}
