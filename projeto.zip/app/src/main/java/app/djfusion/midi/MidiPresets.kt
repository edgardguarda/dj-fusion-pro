package app.djfusion.midi

import android.content.Context

/**
 * Mapas prontos de controladoras MIDI (arquivo assets/controladoras.json). Os números de cada botão foram
 * extraídos dos mapas públicos do Mixxx (res/controllers, licença GPL-2.0 ou posterior): só a tabela
 * "controle do app -> nota/controle MIDI", sem código. Controles que no Mixxx dependem de script entram por
 * aproximação (prato, play, cue…) e podem ser corrigidos em MAPEAR.
 */
object MidiPresets {
    data class Preset(val name: String, val file: String, val map: Map<String, Int>, val rel: Map<String, Int>)

    @Volatile private var cache: List<Preset>? = null

    fun all(context: Context): List<Preset> {
        cache?.let { return it }
        val list = try {
            val txt = context.assets.open("controladoras.json").bufferedReader().use { it.readText() }
            val root = org.json.JSONObject(txt)
            val arr = root.getJSONArray("presets")
            (0 until arr.length()).mapNotNull { i ->
                val o = arr.getJSONObject(i)
                val m = o.getJSONObject("m")
                val map = HashMap<String, Int>()
                for (k in m.keys()) if (MidiTargets.get(k) != null) map[k] = m.getInt(k)
                val r = o.optJSONObject("r")
                val rel = HashMap<String, Int>()
                if (r != null) for (k in r.keys()) rel[k] = r.getInt(k)
                if (map.size < 6) null else Preset(o.getString("n"), o.optString("f", o.getString("n")), map, rel)
            }.sortedBy { it.name.lowercase() }
        } catch (_: Exception) {
            emptyList()
        }
        cache = list
        return list
    }

    private fun norm(s: String) = s.lowercase().filter { it.isLetterOrDigit() }

    /** Mapa pronto que combina com o nome do aparelho (o mais específico), ou null. */
    fun match(context: Context, deviceName: String): Preset? {
        val dev = norm(deviceName)
        if (dev.length < 3) return null
        var best: Preset? = null
        var bestLen = 0
        for (p in all(context)) {
            for (cand in listOf(p.name, p.file)) {
                val c = norm(cand)
                // o nome do aparelho costuma ser o modelo sem a marca ("DDJ-400"); o mapa tem marca + modelo
                val ok = (c.contains(dev) && dev.any { it.isDigit() }) || (dev.contains(c) && c.length >= 5)
                val score = minOf(c.length, dev.length)
                if (ok && score > bestLen) { best = p; bestLen = score }
            }
        }
        return best
    }
}
