package app.djfusion.midi

/** Um controle do app que uma controladora pode comandar. [continuous] = botão giratório ou fader. */
data class MidiTarget(val id: String, val label: String, val continuous: Boolean)

object MidiTargets {
    val all: List<MidiTarget> = buildList {
        for (d in 0..1) {
            val n = if (d == 0) "A" else "B"
            add(MidiTarget("d$d.play", "Play/Pause do deck $n", false))
            add(MidiTarget("d$d.cue", "Cue do deck $n", false))
            add(MidiTarget("d$d.sync", "Sync do deck $n", false))
            add(MidiTarget("d$d.vol", "Volume do deck $n", true))
            add(MidiTarget("d$d.eqhi", "Agudos do deck $n", true))
            add(MidiTarget("d$d.eqmid", "Médios do deck $n", true))
            add(MidiTarget("d$d.eqlo", "Graves do deck $n", true))
            add(MidiTarget("d$d.filter", "Filtro do deck $n", true))
            add(MidiTarget("d$d.tempo", "Tempo (pitch) do deck $n", true))
            add(MidiTarget("d$d.fxeco", "Eco do deck $n", false))
            add(MidiTarget("d$d.fxflg", "Flanger do deck $n", false))
            add(MidiTarget("d$d.fxrev", "Reverb do deck $n", false))
            add(MidiTarget("d$d.fxamt", "Quantidade de efeito do deck $n", true))
            add(MidiTarget("d$d.keylock", "Key-lock do deck $n", false))
            add(MidiTarget("d$d.pfl", "Fone (pré-escuta) do deck $n", false))
            for (s in 1..4) add(MidiTarget("d$d.hot$s", "Hot cue $s do deck $n", false))
            for (b in intArrayOf(1, 2, 4, 8)) add(MidiTarget("d$d.loop$b", "Loop de $b batida(s) do deck $n", false))
        }
        add(MidiTarget("xfade", "Crossfader", true))
        add(MidiTarget("master", "Volume master", true))
        add(MidiTarget("hpvol", "Volume do fone", true))
        add(MidiTarget("hpmix", "Mistura cue/master do fone", true))
    }
    private val byId = all.associateBy { it.id }
    fun get(id: String): MidiTarget? = byId[id]
}

/** Mensagem MIDI já interpretada. [type]: 0x90 nota, 0xB0 controle (CC), 0xE0 pitch bend. */
data class MidiMsg(val type: Int, val channel: Int, val number: Int, val value: Int, val max: Int) {
    /** Chave estável: tipo, canal e número (pitch bend não tem número). */
    val key: Int get() = (type shl 16) or (channel shl 8) or number
    val fraction: Float get() = if (max <= 0) 0f else value.toFloat() / max
    /** Botão apertado: nota com velocidade, ou CC/bend com valor alto. */
    val pressed: Boolean get() = when (type) {
        0x90 -> value > 0
        else -> value >= max / 2
    }
    fun describe(): String = when (type) {
        0x90 -> "Nota nº $number  canal ${channel + 1}  ${if (value > 0) "pressionada, força $value" else "solta"}"
        0xB0 -> "Controle nº $number  canal ${channel + 1}  valor $value"
        else -> "Pitch bend  canal ${channel + 1}  valor $value"
    }
}

/** Lê bytes MIDI crus (pode vir mais de uma mensagem por pacote, com "running status"). */
class MidiParser(private val out: (MidiMsg) -> Unit) {
    private var status = 0

    fun feed(data: ByteArray, offset: Int, count: Int) {
        var i = offset
        val end = offset + count
        while (i < end) {
            val b = data[i].toInt() and 0xFF
            if (b >= 0xF8) { i++; continue }                         // relógio e afins
            if (b >= 0xF0) {                                         // sysex e mensagens de sistema: ignora
                status = 0
                i++
                while (i < end && (data[i].toInt() and 0x80) == 0) i++
                continue
            }
            if (b and 0x80 != 0) { status = b; i++ }
            if (status == 0) { i++; continue }
            val kind = status and 0xF0
            val len = if (kind == 0xC0 || kind == 0xD0) 1 else 2
            if (i + len > end) break
            val d1 = data[i].toInt() and 0x7F
            val d2 = if (len == 2) data[i + 1].toInt() and 0x7F else 0
            i += len
            val ch = status and 0x0F
            when (kind) {
                0x90 -> out(MidiMsg(0x90, ch, d1, d2, 127))
                0x80 -> out(MidiMsg(0x90, ch, d1, 0, 127))           // nota solta vira nota com força 0
                0xB0 -> out(MidiMsg(0xB0, ch, d1, d2, 127))
                0xE0 -> out(MidiMsg(0xE0, ch, 0, d1 or (d2 shl 7), 16383))
            }
        }
    }
}

/** Tabela controle -> chave MIDI, com texto de salvamento simples. */
class MidiMap {
    private val byTarget = LinkedHashMap<String, Int>()

    fun keyOf(target: String): Int? = byTarget[target]
    fun targetOf(key: Int): String? = byTarget.entries.firstOrNull { it.value == key }?.key
    fun assign(target: String, key: Int) {
        // uma chave comanda um controle só, e um controle tem uma chave só
        byTarget.entries.removeAll { it.value == key || it.key == target }
        byTarget[target] = key
    }
    fun clear(target: String) { byTarget.remove(target) }
    fun clearAll() { byTarget.clear() }
    fun count(): Int = byTarget.size

    fun serialize(): String = byTarget.entries.joinToString("\n") { "${it.key}=${it.value}" }
    fun load(text: String) {
        byTarget.clear()
        for (line in text.lineSequence()) {
            val p = line.split('=')
            if (p.size != 2) continue
            val k = p[1].trim().toIntOrNull() ?: continue
            if (MidiTargets.get(p[0]) != null) byTarget[p[0]] = k
        }
    }

    companion object {
        fun describeKey(key: Int): String {
            val type = (key shr 16) and 0xFF
            val ch = (key shr 8) and 0xFF
            val n = key and 0xFF
            return when (type) {
                0x90 -> "Nota $n · canal ${ch + 1}"
                0xB0 -> "Controle $n · canal ${ch + 1}"
                else -> "Pitch bend · canal ${ch + 1}"
            }
        }
    }
}
