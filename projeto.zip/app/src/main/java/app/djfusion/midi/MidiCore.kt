package app.djfusion.midi

/** Um controle do app que uma controladora pode comandar. [continuous] = botão giratório ou fader. */
data class MidiTarget(
    val id: String,
    val label: String,
    val continuous: Boolean,
    /** Giro sem fim (jog wheel): manda quantos passos girou, com sinal. */
    val relative: Boolean = false,
    /** Botão que importa também ao soltar (toque no prato): manda 1 ao apertar e 0 ao soltar. */
    val hold: Boolean = false,
)

object MidiTargets {
    val all: List<MidiTarget> = buildList {
        for (d in 0..1) {
            val n = if (d == 0) "A" else "B"
            add(MidiTarget("d$d.play", "Play/Pause do deck $n", false))
            add(MidiTarget("d$d.cue", "Cue do deck $n", false, hold = true))
            add(MidiTarget("d$d.sync", "Sync do deck $n", false))
            add(MidiTarget("d$d.vol", "Volume do deck $n", true))
            add(MidiTarget("d$d.eqhi", "Agudos do deck $n", true))
            add(MidiTarget("d$d.eqmid", "Médios do deck $n", true))
            add(MidiTarget("d$d.eqlo", "Graves do deck $n", true))
            add(MidiTarget("d$d.filter", "Filtro do deck $n", true))
            add(MidiTarget("d$d.tempo", "Tempo (pitch) do deck $n", true))
            add(MidiTarget("d$d.fxeco", "Eco do deck $n", false))
            add(MidiTarget("d$d.fxflg", "Flanger do deck $n", false))
            add(MidiTarget("d$d.fxrev", "Reverb do deck $n", false))
            add(MidiTarget("d$d.fxamt", "Quantidade de efeito do deck $n", true))
            add(MidiTarget("d$d.keylock", "Key-lock do deck $n", false))
            add(MidiTarget("d$d.pfl", "Fone (pré-escuta) do deck $n", false))
            add(MidiTarget("d$d.jog", "Prato (jog wheel) do deck $n: gire", true, relative = true))
            add(MidiTarget("d$d.jogtouch", "Toque no prato (jog) do deck $n: encoste o dedo", false, hold = true))
            for (s in 1..4) add(MidiTarget("d$d.hot$s", "Hot cue $s do deck $n", false))
            for (b in intArrayOf(1, 2, 4, 8)) add(MidiTarget("d$d.loop$b", "Loop de $b batida(s) do deck $n", false))
            for (s in 1..4) add(MidiTarget("d$d.hotdel$s", "Apagar hot cue $s do deck $n", false))
            add(MidiTarget("d$d.loopin", "LOOP IN do deck $n (início do loop manual)", false))
            add(MidiTarget("d$d.loopout", "LOOP OUT do deck $n (fim do loop manual)", false))
            add(MidiTarget("d$d.reloop", "RELOOP do deck $n (liga/desliga o loop)", false))
            add(MidiTarget("d$d.loopstart", "Volta ao início do loop do deck $n", false))
            add(MidiTarget("d$d.load", "LOAD: carrega no deck $n a música selecionada", false))
            add(MidiTarget("d$d.stemv", "Liga/corta a VOZ do deck $n (stems)", false))
            add(MidiTarget("d$d.stemd", "Liga/corta a BATERIA do deck $n (stems)", false))
            add(MidiTarget("d$d.stemb", "Liga/corta o BAIXO do deck $n (stems)", false))
            add(MidiTarget("d$d.stemm", "Liga/corta a MELODIA do deck $n (stems)", false))
            add(MidiTarget("d$d.acapella", "ACAPELLA do deck $n (só a voz)", false))
            add(MidiTarget("d$d.instr", "INSTRUMENTAL do deck $n (sem voz)", false))
            add(MidiTarget("d$d.stemall", "Todos os stems do deck $n de volta", false))
            add(MidiTarget("d$d.slip", "SLIP do deck $n", false))
            add(MidiTarget("d$d.rev", "REVERSO do deck $n", false))
            add(MidiTarget("d$d.censor", "CENSURA do deck $n", false))
            add(MidiTarget("d$d.keyup", "Tom +1 semitom do deck $n", false))
            add(MidiTarget("d$d.keydown", "Tom -1 semitom do deck $n", false))
            add(MidiTarget("d$d.keymatch", "TOM automático do deck $n", false))
            add(MidiTarget("d$d.jumpf", "Pulo +4 batidas do deck $n", false))
            add(MidiTarget("d$d.jumpb", "Pulo -4 batidas do deck $n", false))
        }
        add(MidiTarget("xfade", "Crossfader", true))
        add(MidiTarget("master", "Volume master", true))
        add(MidiTarget("autodj", "Liga/desliga o AUTO DJ", false))
        add(MidiTarget("automixnow", "AUTO DJ: mixar agora", false))
        for (p in 1..8) add(MidiTarget("pad$p", "Pad $p do sampler", false))
        add(MidiTarget("hpvol", "Volume do fone", true))
        add(MidiTarget("hpmix", "Mistura cue/master do fone", true))
        add(MidiTarget("browse", "BROWSE: gire para escolher a música", true, relative = true))
        add(MidiTarget("browsepush", "BROWSE: aperte para abrir a lista de músicas", false))
    }
    private val byId = all.associateBy { it.id }
    fun get(id: String): MidiTarget? = byId[id]
}

/** Mensagem MIDI já interpretada. [type]: 0x90 nota, 0xB0 controle (CC), 0xE0 pitch bend. */
data class MidiMsg(val type: Int, val channel: Int, val number: Int, val value: Int, val max: Int) {
    /** Chave estável: tipo, canal e número (pitch bend não tem número). */
    val key: Int get() = (type shl 16) or (channel shl 8) or number
    val fraction: Float get() = if (max <= 0) 0f else value.toFloat() / max
    /** Botão apertado: nota com velocidade, ou CC/bend com valor alto. */
    val pressed: Boolean get() = when (type) {
        0x90 -> value > 0
        else -> value >= max / 2
    }
    fun describe(): String = when (type) {
        0x90 -> "Nota nº $number  canal ${channel + 1}  ${if (value > 0) "pressionada, força $value" else "solta"}"
        0xB0 -> "Controle nº $number  canal ${channel + 1}  valor $value"
        else -> "Pitch bend  canal ${channel + 1}  valor $value"
    }
}

/** Lê bytes MIDI crus (pode vir mais de uma mensagem por pacote, com "running status"). */
class MidiParser(private val out: (MidiMsg) -> Unit) {
    private var status = 0

    fun feed(data: ByteArray, offset: Int, count: Int) {
        var i = offset
        val end = offset + count
        while (i < end) {
            val b = data[i].toInt() and 0xFF
            if (b >= 0xF8) { i++; continue }                         // relógio e afins
            if (b >= 0xF0) {                                         // sysex e mensagens de sistema: ignora
                status = 0
                i++
                while (i < end && (data[i].toInt() and 0x80) == 0) i++
                continue
            }
            if (b and 0x80 != 0) { status = b; i++ }
            if (status == 0) { i++; continue }
            val kind = status and 0xF0
            val len = if (kind == 0xC0 || kind == 0xD0) 1 else 2
            if (i + len > end) break
            val d1 = data[i].toInt() and 0x7F
            val d2 = if (len == 2) data[i + 1].toInt() and 0x7F else 0
            i += len
            val ch = status and 0x0F
            when (kind) {
                0x90 -> out(MidiMsg(0x90, ch, d1, d2, 127))
                0x80 -> out(MidiMsg(0x90, ch, d1, 0, 127))           // nota solta vira nota com força 0
                0xB0 -> out(MidiMsg(0xB0, ch, d1, d2, 127))
                0xE0 -> out(MidiMsg(0xE0, ch, 0, d1 or (d2 shl 7), 16383))
            }
        }
    }
}

/** Tabela controle -> chave MIDI, com texto de salvamento simples. */
class MidiMap {
    private val byTarget = LinkedHashMap<String, Int>()
    private val rel = HashMap<String, Int>()   // jog: 0 = complemento de dois (1 = +1, 127 = -1), 1 = centrado em 64

    fun relMode(target: String): Int = rel[target] ?: 0
    fun setRel(target: String, mode: Int) { rel[target] = mode }

    fun keyOf(target: String): Int? = byTarget[target]
    fun targetOf(key: Int): String? = byTarget.entries.firstOrNull { it.value == key }?.key
    fun assign(target: String, key: Int) {
        // uma chave comanda um controle só, e um controle tem uma chave só
        byTarget.entries.removeAll { it.value == key || it.key == target }
        rel.remove(target)
        byTarget[target] = key
    }
    fun clear(target: String) { byTarget.remove(target); rel.remove(target) }
    fun clearAll() { byTarget.clear(); rel.clear() }
    fun count(): Int = byTarget.size

    fun serialize(): String = byTarget.entries.joinToString("\n") {
        val r = rel[it.key]
        if (r != null) "${it.key}=${it.value},$r" else "${it.key}=${it.value}"
    }
    fun load(text: String) {
        byTarget.clear()
        rel.clear()
        for (line in text.lineSequence()) {
            val p = line.split('=')
            if (p.size != 2) continue
            val q = p[1].split(',')
            val k = q[0].trim().toIntOrNull() ?: continue
            if (MidiTargets.get(p[0]) != null) {
                byTarget[p[0]] = k
                q.getOrNull(1)?.trim()?.toIntOrNull()?.let { rel[p[0]] = it }
            }
        }
    }

    companion object {
        fun describeKey(key: Int): String {
            val type = (key shr 16) and 0xFF
            val ch = (key shr 8) and 0xFF
            val n = key and 0xFF
            return when (type) {
                0x90 -> "Nota $n · canal ${ch + 1}"
                0xB0 -> "Controle $n · canal ${ch + 1}"
                else -> "Pitch bend · canal ${ch + 1}"
            }
        }
    }
}


/**
 * Mapa de fábrica da Numark DJ2GO2 Touch, com os números conferidos no mapeamento oficial do Mixxx
 * (res/controllers/Numark_DJ2GO2_Touch.midi.xml): deck A no canal 1, deck B no canal 2, pads nos canais 5 e 6,
 * mestre/crossfader/fone no canal 16. O prato manda CC 6 em complemento de dois (1 = frente, 127 = trás),
 * 236 passos por volta, e o toque no prato é a nota 6.
 */
object Dj2go2Touch {
    const val TICKS_PER_REV = 236
    /** Versão do mapa de fábrica: subir quando mudar, para reaplicar sozinho em quem tem o antigo. */
    const val MAP_VERSION = 2
    /** Mensagem que a DJ2GO2 espera ao conectar (pede o estado atual dos controles), igual à do Mixxx. */
    val INIT_SYSEX = byteArrayOf(0xF0.toByte(), 0x00, 0x01, 0x3F, 0x3C, 0x48, 0xF7.toByte())
    fun note(ch: Int, n: Int) = (0x90 shl 16) or (ch shl 8) or n
    fun cc(ch: Int, n: Int) = (0xB0 shl 16) or (ch shl 8) or n

    fun matches(deviceName: String): Boolean = deviceName.contains("DJ2GO2", ignoreCase = true)

    /**
     * controle do app -> (chave MIDI, modo: jog 0 = complemento de dois; tempo 2 = invertido).
     * Números do mapeamento oficial do Mixxx. Os pads mudam de número conforme o modo escolhido no
     * botão PAD MODE da própria controladora: CUES 0x01-0x04 (segurando PAD MODE: 0x09-0x0C apaga),
     * AUTO LOOP 0x11-0x14, MANUAL LOOP 0x21-0x24 (in, out, liga/desliga, volta ao início), SAMPLER 0x31-0x34.
     */
    val entries: List<Triple<String, Int, Int?>> = buildList {
        for (d in 0..1) {
            val ch = d            // canal 1 (A) ou 2 (B)
            val pads = 4 + d      // canal 5 (A) ou 6 (B)
            add(Triple("d$d.play", note(ch, 0x00), null))
            add(Triple("d$d.cue", note(ch, 0x01), null))
            add(Triple("d$d.sync", note(ch, 0x02), null))
            add(Triple("d$d.pfl", note(ch, 0x1B), null))
            add(Triple("d$d.jogtouch", note(ch, 0x06), null))
            add(Triple("d$d.jog", cc(ch, 0x06), 0))
            add(Triple("d$d.tempo", cc(ch, 0x09), 2))
            add(Triple("d$d.vol", cc(ch, 0x16), null))
            for (s in 1..4) add(Triple("d$d.hot$s", note(pads, s), null))
            for (s in 1..4) add(Triple("d$d.hotdel$s", note(pads, 0x08 + s), null))
            val beats = intArrayOf(1, 2, 4, 8)
            for (i in 0..3) add(Triple("d$d.loop${beats[i]}", note(pads, 0x11 + i), null))
            add(Triple("d$d.loopin", note(pads, 0x21), null))
            add(Triple("d$d.loopout", note(pads, 0x22), null))
            add(Triple("d$d.reloop", note(pads, 0x23), null))
            add(Triple("d$d.loopstart", note(pads, 0x24), null))
            for (i in 0..3) add(Triple("pad${d * 4 + i + 1}", note(pads, 0x31 + i), null))
            add(Triple("d$d.load", note(15, 0x02 + d), null))
        }
        add(Triple("xfade", cc(15, 0x08), null))
        add(Triple("master", cc(15, 0x0A), null))
        add(Triple("hpvol", cc(15, 0x0C), null))
        add(Triple("browse", cc(15, 0x00), 0))
        add(Triple("browsepush", note(15, 0x06), null))
    }

    fun applyTo(map: MidiMap) {
        for ((target, key, mode) in entries) {
            map.assign(target, key)
            if (mode != null) map.setRel(target, mode)
        }
    }
}
