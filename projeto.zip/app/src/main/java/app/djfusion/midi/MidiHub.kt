package app.djfusion.midi

import android.content.Context
import android.media.midi.MidiDevice
import android.media.midi.MidiDeviceInfo
import android.media.midi.MidiManager
import android.media.midi.MidiReceiver
import android.os.Handler
import android.os.Looper
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

/**
 * Liga controladoras MIDI USB (classe padrão, como a Numark DJ2GO2 Touch) aos controles do app.
 * Tudo acontece na thread principal. Não há mapa pronto de fábrica: o usuário ensina cada controle
 * (MIDI Learn) e o mapa fica salvo. [onControl] recebe o id do controle e o valor de 0 a 1
 * (botões mandam 1 ao apertar).
 */
class MidiHub(
    private val context: Context,
    /** Chamado quando o mapa de fábrica da DJ2GO2 Touch é aplicado (para ajustar o jog). */
    private val onPreset: () -> Unit = {},
    private val onControl: (String, Float) -> Unit,
) {
    private val main = Handler(Looper.getMainLooper())
    private val manager = context.getSystemService(Context.MIDI_SERVICE) as? MidiManager
    private val prefs = context.getSharedPreferences("midi", Context.MODE_PRIVATE)
    private val map = MidiMap().also { it.load(prefs.getString("map", "") ?: "") }
    private val open = HashMap<Int, MidiDevice>()
    private val opening = HashSet<Int>()   // aberturas em andamento: evita abrir o mesmo aparelho duas vezes

    private val _devices = MutableStateFlow<List<String>>(emptyList())
    val devices: StateFlow<List<String>> = _devices.asStateFlow()
    private val _log = MutableStateFlow<List<String>>(emptyList())
    val log: StateFlow<List<String>> = _log.asStateFlow()
    private val _learning = MutableStateFlow<String?>(null)
    val learning: StateFlow<String?> = _learning.asStateFlow()
    private val _mapped = MutableStateFlow<Map<String, Int>>(snapshot())
    val mapped: StateFlow<Map<String, Int>> = _mapped.asStateFlow()
    /** Assistente: aprende todos os controles ainda vazios, um depois do outro. */
    private val _wizard = MutableStateFlow(false)
    val wizard: StateFlow<Boolean> = _wizard.asStateFlow()

    val supported: Boolean get() = manager != null

    private val callback = object : MidiManager.DeviceCallback() {
        override fun onDeviceAdded(device: MidiDeviceInfo) { openDevice(device) }
        override fun onDeviceRemoved(device: MidiDeviceInfo) {
            opening.remove(device.id)
            open.remove(device.id)?.let { runCatching { it.close() } }
            refreshDevices()
        }
    }

    fun start() {
        val m = manager ?: return
        m.registerDeviceCallback(callback, main)
        for (info in m.devices) openDevice(info)
        refreshDevices()
    }

    fun stop() {
        manager?.unregisterDeviceCallback(callback)
        for (d in open.values) runCatching { d.close() }
        open.clear()
        _devices.value = emptyList()
    }

    private fun name(info: MidiDeviceInfo): String {
        val p = info.properties
        return p.getString(MidiDeviceInfo.PROPERTY_PRODUCT) ?: p.getString(MidiDeviceInfo.PROPERTY_NAME) ?: "Dispositivo MIDI"
    }

    private fun refreshDevices() {
        val m = manager ?: return
        _devices.value = m.devices.filter { it.outputPortCount > 0 }.map { name(it) }
    }

    private fun openDevice(info: MidiDeviceInfo) {
        val m = manager ?: return
        if (info.outputPortCount == 0 || open.containsKey(info.id) || !opening.add(info.id)) return
        m.openDevice(info, { device ->
            opening.remove(info.id)
            if (device == null) return@openDevice
            open[info.id] = device
            // DJ2GO2 Touch sem nada aprendido: já liga com o mapa de fábrica
            if (Dj2go2Touch.matches(name(info)) && map.count() == 0) applyDj2go2()
            val port = device.openOutputPort(0)
            if (port != null) {
                val parser = MidiParser { msg -> main.post { handle(msg) } }
                port.connect(object : MidiReceiver() {
                    override fun onSend(msg: ByteArray, offset: Int, count: Int, timestamp: Long) {
                        parser.feed(msg, offset, count)
                    }
                })
            }
            refreshDevices()
        }, main)
    }

    // --------------------------------------------------------------- mensagens

    private var lastLogKey = -1

    private fun handle(msg: MidiMsg) {
        // monitor: agrupa giros seguidos do mesmo controle numa linha só
        val line = msg.describe()
        val cur = _log.value
        _log.value = if (msg.key == lastLogKey && cur.isNotEmpty()) listOf(line) + cur.drop(1) else (listOf(line) + cur).take(14)
        lastLogKey = msg.key

        val learn = _learning.value
        if (learn != null) {
            val t = MidiTargets.get(learn)
            if (t != null) {
                // botão: só aprende no aperto (ignora o soltar); controle contínuo aprende no primeiro movimento
                val ok = when {
                    t.relative -> msg.type == 0xB0      // jog: só controle (CC) que gira
                    t.continuous -> msg.type != 0x90 || msg.value > 0
                    else -> msg.pressed
                }
                if (ok) {
                    map.assign(learn, msg.key)
                    // jog: valores perto de 64 = centrado em 64; perto de 0 e 127 = complemento de dois
                    if (t.relative) map.setRel(learn, if (msg.value in 40..88) 1 else 0)
                    save()
                    _learning.value = if (_wizard.value) nextEmpty() else null
                    if (_learning.value == null) _wizard.value = false
                }
            }
            return
        }
        val id = map.targetOf(msg.key) ?: return
        val t = MidiTargets.get(id) ?: return
        when {
            t.relative -> if (msg.type == 0xB0) {
                val delta = if (map.relMode(id) == 1) msg.value - 64 else (if (msg.value < 64) msg.value else msg.value - 128)
                if (delta != 0) onControl(id, delta.toFloat())
            }
            t.hold -> onControl(id, if (msg.pressed) 1f else 0f)
            t.continuous -> onControl(id, if (map.relMode(id) == 2) 1f - msg.fraction else msg.fraction)
            else -> if (msg.pressed) onControl(id, 1f)
        }
    }

    // --------------------------------------------------------------- aprendizado

    private fun nextEmpty(): String? = MidiTargets.all.firstOrNull { map.keyOf(it.id) == null }?.id

    fun learn(target: String) { _wizard.value = false; _learning.value = target }
    fun cancelLearn() { _learning.value = null; _wizard.value = false }
    fun startWizard() {
        val n = nextEmpty()
        _wizard.value = n != null
        _learning.value = n
    }
    fun skipLearn() {
        val cur = _learning.value ?: return
        val ids = MidiTargets.all.map { it.id }
        val next = ids.drop(ids.indexOf(cur) + 1).firstOrNull { map.keyOf(it) == null }
        _learning.value = next
        if (next == null) _wizard.value = false
    }
    fun clear(target: String) { map.clear(target); save() }

    /** Aplica o mapa de fábrica da Numark DJ2GO2 Touch (substitui o que estiver nesses controles). */
    fun applyDj2go2() {
        Dj2go2Touch.applyTo(map)
        save()
        cancelLearn()
        onPreset()
    }

    /** Inverte a direção do fader de tempo aprendido (algumas controladoras mandam 0 em cima). */
    fun toggleTempoInvert(deck: Int) {
        val id = "d$deck.tempo"
        if (map.keyOf(id) == null) return
        map.setRel(id, if (map.relMode(id) == 2) 0 else 2)
        save()
    }
    private fun invSet(): Set<Int> = (0..1).filter { map.relMode("d$it.tempo") == 2 }.toSet()
    private val _tempoInv = MutableStateFlow(invSet())
    /** Decks cujo fader de tempo da controladora está invertido. */
    val tempoInv: StateFlow<Set<Int>> = _tempoInv.asStateFlow()
    fun clearAll() { map.clearAll(); save(); cancelLearn() }

    private fun snapshot(): Map<String, Int> =
        MidiTargets.all.mapNotNull { t -> map.keyOf(t.id)?.let { t.id to it } }.toMap()

    private fun save() {
        prefs.edit().putString("map", map.serialize()).apply()
        _mapped.value = snapshot()
        _tempoInv.value = invSet()
    }
}
