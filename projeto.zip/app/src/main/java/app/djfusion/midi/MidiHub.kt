package app.djfusion.midi

import android.content.Context
import android.media.midi.MidiDevice
import android.media.midi.MidiDeviceInfo
import android.media.midi.MidiManager
import android.media.midi.MidiReceiver
import android.os.Handler
import android.os.Looper
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

/**
 * Liga controladoras MIDI USB (classe padrão, como a Numark DJ2GO2 Touch) aos controles do app.
 * Tudo acontece na thread principal. Não há mapa pronto de fábrica: o usuário ensina cada controle
 * (MIDI Learn) e o mapa fica salvo. [onControl] recebe o id do controle e o valor de 0 a 1
 * (botões mandam 1 ao apertar).
 */
class MidiHub(
    private val context: Context,
    /** Chamado quando o mapa de fábrica da DJ2GO2 Touch é aplicado (para ajustar o jog). */
    private val onPreset: () -> Unit = {},
    private val onControl: (String, Float) -> Unit,
) {
    private val main = Handler(Looper.getMainLooper())
    private val manager = context.getSystemService(Context.MIDI_SERVICE) as? MidiManager
    private val prefs = context.getSharedPreferences("midi", Context.MODE_PRIVATE)
    private val map = MidiMap().also { it.load(prefs.getString("map", "") ?: "") }
    private val open = HashMap<Int, MidiDevice>()
    /** Portas para enviar à controladora (LEDs e mensagem de início). */
    private val outPorts = HashMap<Int, android.media.midi.MidiInputPort>()
    /** Últimas mensagens recebidas, cruas, com o controle que acionaram (relatório de diagnóstico). */
    val diag: java.util.ArrayDeque<String> = java.util.ArrayDeque()
    private val ledState = HashMap<Int, Int>()
    private val opening = HashSet<Int>()   // aberturas em andamento: evita abrir o mesmo aparelho duas vezes

    private val _devices = MutableStateFlow<List<String>>(emptyList())
    val devices: StateFlow<List<String>> = _devices.asStateFlow()
    private val _log = MutableStateFlow<List<String>>(emptyList())
    val log: StateFlow<List<String>> = _log.asStateFlow()
    private val _learning = MutableStateFlow<String?>(null)
    val learning: StateFlow<String?> = _learning.asStateFlow()
    private val _mapped = MutableStateFlow<Map<String, Int>>(snapshot())
    val mapped: StateFlow<Map<String, Int>> = _mapped.asStateFlow()
    /** Assistente: aprende todos os controles ainda vazios, um depois do outro. */
    private val _wizard = MutableStateFlow(false)
    val wizard: StateFlow<Boolean> = _wizard.asStateFlow()

    val supported: Boolean get() = manager != null

    private val callback = object : MidiManager.DeviceCallback() {
        override fun onDeviceAdded(device: MidiDeviceInfo) { openDevice(device) }
        override fun onDeviceRemoved(device: MidiDeviceInfo) {
            opening.remove(device.id)
            outPorts.remove(device.id)?.let { runCatching { it.close() } }
            open.remove(device.id)?.let { runCatching { it.close() } }
            refreshDevices()
        }
    }

    fun start() {
        val m = manager ?: return
        m.registerDeviceCallback(callback, main)
        for (info in m.devices) openDevice(info)
        refreshDevices()
    }

    fun stop() {
        manager?.unregisterDeviceCallback(callback)
        for (p in outPorts.values) runCatching { p.close() }
        outPorts.clear()
        for (d in open.values) runCatching { d.close() }
        open.clear()
        _devices.value = emptyList()
    }

    private fun name(info: MidiDeviceInfo): String {
        val p = info.properties
        return p.getString(MidiDeviceInfo.PROPERTY_PRODUCT) ?: p.getString(MidiDeviceInfo.PROPERTY_NAME) ?: "Dispositivo MIDI"
    }

    private fun refreshDevices() {
        val m = manager ?: return
        _devices.value = m.devices.filter { it.outputPortCount > 0 }.map { name(it) }
    }

    private fun openDevice(info: MidiDeviceInfo) {
        val m = manager ?: return
        if (info.outputPortCount == 0 || open.containsKey(info.id) || !opening.add(info.id)) return
        m.openDevice(info, { device ->
            opening.remove(info.id)
            if (device == null) return@openDevice
            open[info.id] = device
            val isDj2go2 = Dj2go2Touch.matches(name(info))
            // DJ2GO2 Touch: o mapa de fábrica é reaplicado toda vez que ela liga (um ENSINAR errado não estraga
            // o prato, o tempo nem os pads); controles extras ensinados pelo DJ continuam valendo
            if (isDj2go2) {
                applyDj2go2()
                prefs.edit().putInt("dj2go2v", Dj2go2Touch.MAP_VERSION).apply()
            }
            if (info.inputPortCount > 0) {
                device.openInputPort(0)?.let { p ->
                    outPorts[info.id] = p
                    ledState.clear()
                    if (isDj2go2) runCatching { p.send(Dj2go2Touch.INIT_SYSEX, 0, Dj2go2Touch.INIT_SYSEX.size) }
                    main.postDelayed({ onConnected() }, 300)
                }
            }
            note("conectada: ${name(info)} (entradas ${info.inputPortCount}, saídas ${info.outputPortCount})")
            val port = device.openOutputPort(0)
            if (port != null) {
                val parser = MidiParser { msg -> main.post { handle(msg) } }
                port.connect(object : MidiReceiver() {
                    override fun onSend(msg: ByteArray, offset: Int, count: Int, timestamp: Long) {
                        parser.feed(msg, offset, count)
                    }
                })
            }
            refreshDevices()
        }, main)
    }

    // --------------------------------------------------------------- mensagens

    private var lastLogKey = -1
    private var lastDiagKey = -1
    private val _lastAction = MutableStateFlow("")
    /** O que o último controle tocado fez (mostrado no monitor). */
    val lastAction: StateFlow<String> = _lastAction.asStateFlow()

    /** Texto do mapa atual para o relatório. */
    fun describeMap(): String = MidiTargets.all.mapNotNull { t -> map.keyOf(t.id)?.let { "  ${t.label}: ${MidiMap.describeKey(it)}" } }.joinToString("\n")
    fun describeDevices(): String = manager?.devices?.joinToString("\n") { "  ${name(it)}: entradas ${it.inputPortCount}, saídas ${it.outputPortCount}" } ?: "  MIDI indisponível"

    private fun note(text: String) {
        val ts = java.text.SimpleDateFormat("HH:mm:ss.SSS", java.util.Locale.ROOT).format(java.util.Date())
        diag.addFirst("$ts $text")
        while (diag.size > 400) diag.pollLast()
    }

    /** Chamado quando a controladora conecta (o app reacende os LEDs). */
    var onConnected: () -> Unit = {}

    /** Acende ou apaga o LED do botão ligado ao controle [target] (se a controladora tiver LED nele). */
    fun led(target: String, on: Boolean) {
        if (outPorts.isEmpty()) return
        val key = map.keyOf(target) ?: return
        val type = (key shr 16) and 0xFF
        if (type != 0x90) return
        val v = if (on) 0x7F else 0x00
        if (ledState[key] == v) return
        ledState[key] = v
        val ch = (key shr 8) and 0x0F
        val msg = byteArrayOf((0x90 or ch).toByte(), (key and 0x7F).toByte(), v.toByte())
        for (p in outPorts.values) runCatching { p.send(msg, 0, 3) }
    }

    private val injectParser = MidiParser { msg -> handle(msg) }
    /** Processa bytes MIDI como se viessem da controladora (usado no teste automático, sem aparelho). */
    fun inject(bytes: ByteArray) = injectParser.feed(bytes, 0, bytes.size)

    /** Esquece o estado dos LEDs (força reenviar tudo). */
    fun resetLeds() = ledState.clear()

    private fun handle(msg: MidiMsg) {
        // monitor: agrupa giros seguidos do mesmo controle numa linha só
        val line = msg.describe()
        val cur = _log.value
        _log.value = if (msg.key == lastLogKey && cur.isNotEmpty()) listOf(line) + cur.drop(1) else (listOf(line) + cur).take(14)
        lastLogKey = msg.key

        val learn = _learning.value
        if (learn != null) {
            val t = MidiTargets.get(learn)
            if (t != null) {
                // botão: só aprende no aperto (ignora o soltar); controle contínuo aprende no primeiro movimento
                val ok = when {
                    t.relative -> msg.type == 0xB0      // jog: só controle (CC) que gira
                    t.continuous -> msg.type != 0x90 || msg.value > 0
                    else -> msg.pressed
                }
                if (ok) {
                    map.assign(learn, msg.key)
                    // jog: valores perto de 64 = centrado em 64; perto de 0 e 127 = complemento de dois
                    if (t.relative) map.setRel(learn, if (msg.value in 40..88) 1 else 0)
                    save()
                    _learning.value = if (_wizard.value) nextEmpty() else null
                    if (_learning.value == null) _wizard.value = false
                }
            }
            return
        }
        val id = map.targetOf(msg.key)
        if (msg.type != 0xB0 || msg.key != lastDiagKey) {
            note("%s -> %s".format(msg.describe(), id?.let { MidiTargets.get(it)?.label } ?: "(nenhum controle)"))
        }
        lastDiagKey = msg.key
        _lastAction.value = id?.let { MidiTargets.get(it)?.label } ?: "sem função: ${msg.describe()}"
        if (id == null) return
        val t = MidiTargets.get(id) ?: return
        when {
            t.relative -> if (msg.type == 0xB0) {
                val delta = if (map.relMode(id) == 1) msg.value - 64 else (if (msg.value < 64) msg.value else msg.value - 128)
                if (delta != 0) onControl(id, delta.toFloat())
            }
            t.hold -> onControl(id, if (msg.pressed) 1f else 0f)
            t.continuous -> onControl(id, if (map.relMode(id) == 2) 1f - msg.fraction else msg.fraction)
            else -> if (msg.pressed) onControl(id, 1f)
        }
    }

    // --------------------------------------------------------------- aprendizado

    private fun nextEmpty(): String? = MidiTargets.all.firstOrNull { map.keyOf(it.id) == null }?.id

    fun learn(target: String) { _wizard.value = false; _learning.value = target }
    fun cancelLearn() { _learning.value = null; _wizard.value = false }
    fun startWizard() {
        val n = nextEmpty()
        _wizard.value = n != null
        _learning.value = n
    }
    fun skipLearn() {
        val cur = _learning.value ?: return
        val ids = MidiTargets.all.map { it.id }
        val next = ids.drop(ids.indexOf(cur) + 1).firstOrNull { map.keyOf(it) == null }
        _learning.value = next
        if (next == null) _wizard.value = false
    }
    fun clear(target: String) { map.clear(target); save() }

    /** Aplica o mapa de fábrica da Numark DJ2GO2 Touch (substitui o que estiver nesses controles). */
    fun applyDj2go2() {
        Dj2go2Touch.applyTo(map)
        save()
        cancelLearn()
        onPreset()
    }

    /** Inverte a direção do fader de tempo aprendido (algumas controladoras mandam 0 em cima). */
    fun toggleTempoInvert(deck: Int) {
        val id = "d$deck.tempo"
        if (map.keyOf(id) == null) return
        map.setRel(id, if (map.relMode(id) == 2) 0 else 2)
        save()
    }
    private fun invSet(): Set<Int> = (0..1).filter { map.relMode("d$it.tempo") == 2 }.toSet()
    private val _tempoInv = MutableStateFlow(invSet())
    /** Decks cujo fader de tempo da controladora está invertido. */
    val tempoInv: StateFlow<Set<Int>> = _tempoInv.asStateFlow()
    fun clearAll() { map.clearAll(); save(); cancelLearn() }

    private fun snapshot(): Map<String, Int> =
        MidiTargets.all.mapNotNull { t -> map.keyOf(t.id)?.let { t.id to it } }.toMap()

    private fun save() {
        prefs.edit().putString("map", map.serialize()).apply()
        _mapped.value = snapshot()
        _tempoInv.value = invSet()
    }
}
