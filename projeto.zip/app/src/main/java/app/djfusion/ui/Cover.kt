package app.djfusion.ui

import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.media.MediaMetadataRetriever
import android.net.Uri
import android.util.LruCache
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.produceState
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

/**
 * Capa do álbum guardada dentro do arquivo de música (MP3, M4A, FLAC). Lê uma vez, reduz para caber num quadradinho
 * e guarda na memória; sem capa, mostra um quadrado colorido com a inicial (a cor é sempre a mesma para o mesmo título).
 */
private object CoverCache {
    val cache = object : LruCache<String, Bitmap>(24 * 1024 * 1024) {
        override fun sizeOf(key: String, value: Bitmap): Int = value.byteCount
    }
    /** Faixas que já sabemos que não têm capa (para não abrir o arquivo de novo a cada rolagem). */
    val none = java.util.Collections.synchronizedSet(HashSet<String>())
}

private fun loadCover(context: android.content.Context, uri: String, px: Int): Bitmap? {
    CoverCache.cache.get(uri)?.let { return it }
    if (uri in CoverCache.none) return null
    val r = MediaMetadataRetriever()
    return try {
        r.setDataSource(context, Uri.parse(uri))
        val raw = r.embeddedPicture
        if (raw == null) { CoverCache.none.add(uri); null } else {
            val o = BitmapFactory.Options().apply { inJustDecodeBounds = true }
            BitmapFactory.decodeByteArray(raw, 0, raw.size, o)
            var sample = 1
            while (o.outWidth / (sample * 2) >= px && o.outHeight / (sample * 2) >= px) sample *= 2
            val bmp = BitmapFactory.decodeByteArray(raw, 0, raw.size, BitmapFactory.Options().apply { inSampleSize = sample })
            if (bmp == null) { CoverCache.none.add(uri); null } else { CoverCache.cache.put(uri, bmp); bmp }
        }
    } catch (_: Throwable) {
        CoverCache.none.add(uri); null
    } finally {
        runCatching { r.release() }
    }
}

@Composable
fun CoverArt(uri: String, title: String, size: Dp, modifier: Modifier = Modifier) {
    val context = LocalContext.current
    val px = (size.value * context.resources.displayMetrics.density).toInt().coerceAtLeast(32)
    val bmp by produceState<Bitmap?>(CoverCache.cache.get(uri), uri) {
        if (value == null) value = withContext(Dispatchers.IO) { loadCover(context, uri, px) }
    }
    val shape = RoundedCornerShape(6.dp)
    Box(modifier.size(size).clip(shape), contentAlignment = Alignment.Center) {
        val b = bmp
        if (b != null) {
            Image(b.asImageBitmap(), contentDescription = null, contentScale = ContentScale.Crop, modifier = Modifier.fillMaxSize())
        } else {
            val hue = ((title.hashCode() and 0x7fffffff) % 360).toFloat()
            Box(Modifier.fillMaxSize().background(Color.hsv(hue, 0.45f, 0.35f)), contentAlignment = Alignment.Center) {
                Text(title.trim().take(1).uppercase().ifEmpty { "♪" }, color = Color.White.copy(alpha = 0.85f), fontSize = (size.value * 0.42f).sp, fontWeight = FontWeight.ExtraBold)
            }
        }
    }
}
