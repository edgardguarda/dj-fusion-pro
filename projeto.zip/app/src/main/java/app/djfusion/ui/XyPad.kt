package app.djfusion.ui

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.gestures.awaitEachGesture
import androidx.compose.foundation.gestures.awaitFirstDown
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.unit.dp

/**
 * Pad XY (como o de Cross DJ, WeDJ e edjing): o dedo escolhe dois valores de uma vez. [x] e [y] vão de 0 a 1
 * (y = 1 no alto). Chama [onMove] enquanto o dedo está na tela e [onRelease] quando solta.
 */
@Composable
fun XyPad(
    x: Float, y: Float, accent: Color, description: String,
    modifier: Modifier = Modifier,
    onMove: (Float, Float) -> Unit,
    onRelease: () -> Unit,
) {
    val move = rememberUpdatedState(onMove)
    val release = rememberUpdatedState(onRelease)
    var touching by remember { mutableStateOf(false) }
    Canvas(
        modifier.clip(RoundedCornerShape(10.dp)).background(Color(0xFF0B0D10))
            .semantics { contentDescription = description }
            .pointerInput(Unit) {
                awaitEachGesture {
                    val down = awaitFirstDown()
                    down.consume()
                    touching = true
                    move.value((down.position.x / size.width).coerceIn(0f, 1f), 1f - (down.position.y / size.height).coerceIn(0f, 1f))
                    do {
                        val ev = awaitPointerEvent()
                        val ch = ev.changes.first()
                        if (ch.pressed) {
                            move.value((ch.position.x / size.width).coerceIn(0f, 1f), 1f - (ch.position.y / size.height).coerceIn(0f, 1f))
                            ch.consume()
                        }
                    } while (ev.changes.any { it.pressed })
                    touching = false
                    release.value()
                }
            },
    ) {
        val w = size.width
        val h = size.height
        val grid = Color(0xFF1E232A)
        for (i in 1..3) {
            drawLine(grid, Offset(w * i / 4f, 0f), Offset(w * i / 4f, h), 1f)
            drawLine(grid, Offset(0f, h * i / 4f), Offset(w, h * i / 4f), 1f)
        }
        val cx = w * x.coerceIn(0f, 1f)
        val cy = h * (1f - y.coerceIn(0f, 1f))
        val glow = accent.copy(alpha = if (touching) 0.35f else 0.18f)
        drawLine(glow, Offset(cx, 0f), Offset(cx, h), 2f)
        drawLine(glow, Offset(0f, cy), Offset(w, cy), 2f)
        drawCircle(accent.copy(alpha = if (touching) 0.30f else 0.12f), radius = 26.dp.toPx(), center = Offset(cx, cy))
        drawCircle(accent, radius = 11.dp.toPx(), center = Offset(cx, cy), style = Stroke(width = 2.dp.toPx()))
        drawCircle(accent, radius = 5.dp.toPx(), center = Offset(cx, cy))
    }
}
