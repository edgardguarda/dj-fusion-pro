package app.djfusion.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.foundation.clickable
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.runtime.getValue
import androidx.compose.foundation.layout.size
import androidx.compose.runtime.setValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import app.djfusion.midi.MidiMap
import app.djfusion.midi.MidiTargets
import app.djfusion.ui.theme.Metal

/**
 * Tela da controladora: mostra se há uma conectada, o que ela está mandando (monitor) e deixa
 * ensinar cada botão ao app. Não existe mapa pronto de fábrica; o assistente leva o usuário
 * controle por controle.
 */
@Composable
fun MidiScreen(vm: AppViewModel) {
    val hub = vm.midi
    val devices by hub.devices.collectAsStateWithLifecycle()
    val log by hub.log.collectAsStateWithLifecycle()
    val learning by hub.learning.collectAsStateWithLifecycle()
    val mapped by hub.mapped.collectAsStateWithLifecycle()
    val wizard by hub.wizard.collectAsStateWithLifecycle()

    Row(Modifier.fillMaxSize().background(Metal.Bg).padding(12.dp), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
        Column(
            Modifier.weight(0.9f).fillMaxHeight().verticalScroll(rememberScrollState()),
            verticalArrangement = Arrangement.spacedBy(10.dp),
        ) {
            OutputPanel(vm)
            JogPanel(vm)
            Panel("CONTROLADORA") {
                if (!hub.supported) {
                    Text("Este aparelho não tem suporte a MIDI.", color = Metal.Danger, fontSize = 14.sp)
                } else if (devices.isEmpty()) {
                    Text(
                        "Nenhuma controladora detectada. Ligue a Numark (ou outra) no celular pelo cabo USB, com adaptador OTG se precisar.",
                        color = Metal.TextMuted, fontSize = 14.sp,
                    )
                } else {
                    for (d in devices) Text("● $d", color = Metal.Success, fontSize = 16.sp, fontWeight = FontWeight.Bold)
                    Text("Conectada. Mexa em qualquer controle: ele aparece no monitor abaixo.", color = Metal.TextMuted, fontSize = 13.sp)
                }
            }
            Panel("MONITOR (o que a controladora está enviando)") {
                if (log.isEmpty()) Text("Nada ainda.", color = Metal.TextMuted, fontSize = 13.sp)
                for (l in log.take(8)) Text(l, color = Metal.Text, fontSize = 13.sp, fontFamily = FontFamily.Monospace)
            }
            Panel("ENSINAR OS CONTROLES") {
                Text(
                    "${mapped.size} de ${MidiTargets.all.size} controles ensinados.",
                    color = Metal.Text, fontSize = 14.sp, fontWeight = FontWeight.Bold,
                )
                Text(
                    "Toque em ASSISTENTE: o app pede um controle por vez. Aperte ou gire o controle correspondente na controladora. Use PULAR para o que ela não tem.",
                    color = Metal.TextMuted, fontSize = 12.sp,
                )
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.fillMaxWidth().height(44.dp)) {
                    MetalButton(
                        description = if (wizard) "Parar o assistente" else "Iniciar o assistente de aprendizado",
                        onPress = { if (wizard) hub.cancelLearn() else hub.startWizard() },
                        led = Metal.Success, ledOn = wizard,
                        modifier = Modifier.weight(1f).fillMaxHeight(),
                    ) { Text(if (wizard) "PARAR" else "ASSISTENTE", color = Metal.OnMetal, fontSize = 13.sp, fontWeight = FontWeight.ExtraBold) }
                    MetalButton(
                        description = "Pular este controle",
                        onPress = { hub.skipLearn() }, enabled = learning != null,
                        modifier = Modifier.weight(1f).fillMaxHeight(),
                    ) { Text("PULAR", color = Metal.OnMetal, fontSize = 13.sp, fontWeight = FontWeight.ExtraBold) }
                    MetalButton(
                        description = "Apagar tudo que foi ensinado",
                        onPress = { hub.clearAll() }, enabled = mapped.isNotEmpty(),
                        modifier = Modifier.weight(1f).fillMaxHeight(),
                    ) { Text("LIMPAR", color = Metal.Danger, fontSize = 13.sp, fontWeight = FontWeight.ExtraBold) }
                }
            }
        }
        Column(Modifier.weight(1.1f).fillMaxHeight().background(Metal.Surface, RoundedCornerShape(10.dp)).padding(8.dp)) {
            val cur = learning?.let { MidiTargets.get(it) }
            Text(
                if (cur != null) "Aperte ou gire na controladora: ${cur.label}" else "Controles",
                color = if (cur != null) Metal.Warning else Metal.TextMuted,
                fontSize = 14.sp, fontWeight = FontWeight.Bold, modifier = Modifier.padding(bottom = 6.dp),
            )
            LazyColumn(Modifier.fillMaxSize(), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                items(MidiTargets.all, key = { it.id }) { t ->
                    val key = mapped[t.id]
                    val active = learning == t.id
                    Row(
                        Modifier.fillMaxWidth().height(40.dp)
                            .background(if (active) Color(0xFF3A3320) else Color(0xFF22262B), RoundedCornerShape(8.dp))
                            .padding(start = 10.dp),
                        verticalAlignment = Alignment.CenterVertically,
                    ) {
                        Column(Modifier.weight(1f)) {
                            Text(t.label, color = Metal.Text, fontSize = 13.sp, fontWeight = FontWeight.SemiBold, maxLines = 1)
                            Text(
                                if (active) "esperando…" else if (key != null) MidiMap.describeKey(key) else "não ensinado",
                                color = if (key != null) Metal.Success else Metal.TextMuted, fontSize = 11.sp,
                            )
                        }
                        MetalButton(
                            description = "Ensinar ${t.label}",
                            onPress = { hub.learn(t.id) },
                            modifier = Modifier.width(76.dp).fillMaxHeight().padding(vertical = 3.dp),
                        ) { Text(if (key != null) "REFAZER" else "ENSINAR", color = Metal.OnMetal, fontSize = 10.sp, fontWeight = FontWeight.ExtraBold) }
                        Spacer(Modifier.width(4.dp))
                        MetalButton(
                            description = "Esquecer ${t.label}",
                            onPress = { hub.clear(t.id) }, enabled = key != null,
                            modifier = Modifier.width(36.dp).fillMaxHeight().padding(vertical = 3.dp),
                        ) { Text("✕", color = Metal.OnMetal, fontSize = 12.sp, fontWeight = FontWeight.ExtraBold) }
                        Spacer(Modifier.width(4.dp))
                    }
                }
            }
        }
    }
}

@Composable
private fun Panel(title: String, content: @Composable () -> Unit) {
    Column(
        Modifier.fillMaxWidth().background(Metal.Surface, RoundedCornerShape(10.dp)).padding(12.dp),
        verticalArrangement = Arrangement.spacedBy(6.dp),
    ) {
        Text(title, color = Metal.TextMuted, fontSize = 11.sp, fontWeight = FontWeight.Bold, letterSpacing = 1.5.sp)
        content()
    }
}

/** Saída de áudio e fone: escolhe a placa USB (DJ2GO2) e como o fone é entregue. */
@Composable
private fun OutputPanel(vm: AppViewModel) {
    val mode by vm.outputMode.collectAsStateWithLifecycle()
    val device by vm.outputDevice.collectAsStateWithLifecycle()
    val usb by vm.usbOutputs.collectAsStateWithLifecycle()
    val note by vm.outputNote.collectAsStateWithLifecycle()
    Panel("SAÍDA DE ÁUDIO E FONE") {
        if (usb.isEmpty()) {
            Text(
                "Nenhuma placa de som USB detectada. Com a DJ2GO2 ligada no USB, ela aparece aqui.",
                color = Metal.TextMuted, fontSize = 13.sp,
            )
        } else {
            for (u in usb) {
                val chosen = device == u.id || (device == -1 && u == usb.first())
                Text(
                    (if (chosen) "● " else "○ ") + "${u.name}  (${u.channels} canais)",
                    color = if (chosen) Metal.Success else Metal.Text, fontSize = 14.sp, fontWeight = FontWeight.Bold,
                    modifier = Modifier.fillMaxWidth().clickable { vm.setOutputDevice(u.id) }.padding(vertical = 4.dp),
                )
            }
        }
        val modes = listOf(
            "NORMAL" to "Só som geral em estéreo. O fone fica sem pré-escuta.",
            "DIVIDIDO" to "Esquerdo = fone, direito = som geral (mono). Use com cabo Y ou separador de fone.",
            "4 CANAIS" to "Canais 1-2 = som geral, 3-4 = fone. Precisa de placa USB com 4 saídas.",
        )
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.fillMaxWidth().height(44.dp)) {
            for ((i, m) in modes.withIndex()) {
                MetalButton(
                    description = "Modo de saída ${m.first}. ${m.second}",
                    onPress = { vm.setOutputMode(i) },
                    led = Metal.Success, ledOn = mode == i,
                    modifier = Modifier.weight(1f).fillMaxHeight(),
                ) { Text(m.first, color = Metal.OnMetal, fontSize = 12.sp, fontWeight = FontWeight.ExtraBold) }
            }
        }
        Text(modes[mode].second, color = Metal.TextMuted, fontSize = 12.sp)
        if (note.isNotEmpty()) Text(note, color = Metal.Warning, fontSize = 12.sp)
        Text(
            "Depois use o botão FONE de cada deck na tela DJ LIVE para ouvir o deck no fone antes de soltá-lo.",
            color = Metal.TextMuted, fontSize = 12.sp,
        )
    }
}


@Composable
private fun JogPanel(vm: AppViewModel) {
    var tpr by remember { mutableStateOf(vm.jog.ticksPerRev) }
    Panel("JOG WHEEL (scratch)") {
        Text(
            "Para o prato da controladora fazer scratch: use o ASSISTENTE e gire o prato (alvo \"jog\") e toque nele (alvo \"jogtouch\"). " +
                "Os números da DJ2GO2 são aprendidos na hora, sem depender de tabela.",
            color = Metal.TextMuted, fontSize = 12.sp,
        )
        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(10.dp), modifier = Modifier.padding(top = 6.dp)) {
            Text("Passos por volta: $tpr", color = Metal.Text, fontSize = 13.sp, fontWeight = FontWeight.Bold)
            MetalButton("Diminuir passos por volta", { tpr = (tpr / 2).coerceAtLeast(32); vm.jog.setTicksPerRev(tpr) }, modifier = Modifier.size(44.dp)) {
                Text("−", color = Metal.OnMetal, fontSize = 20.sp, fontWeight = FontWeight.ExtraBold, modifier = Modifier.align(Alignment.Center))
            }
            MetalButton("Aumentar passos por volta", { tpr = (tpr * 2).coerceAtMost(1024); vm.jog.setTicksPerRev(tpr) }, modifier = Modifier.size(44.dp)) {
                Text("+", color = Metal.OnMetal, fontSize = 20.sp, fontWeight = FontWeight.ExtraBold, modifier = Modifier.align(Alignment.Center))
            }
        }
        Text("Se o scratch ficar lento demais, diminua; se ficar rápido demais, aumente.", color = Metal.TextMuted, fontSize = 11.sp)
    }
}
