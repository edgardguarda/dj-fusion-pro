package app.djfusion.ui

import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color
import androidx.compose.runtime.setValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.material3.AlertDialog
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.role
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import app.djfusion.data.SortOrder
import app.djfusion.harmony.Camelot
import app.djfusion.ui.theme.Metal

@Composable
fun LibraryScreen(vm: AppViewModel) {
    val tracks by vm.tracks.collectAsStateWithLifecycle()
    val search by vm.search.collectAsStateWithLifecycle()
    val sort by vm.sort.collectAsStateWithLifecycle()
    val decks by vm.decks.collectAsStateWithLifecycle()
    val ly by vm.layers.collectAsStateWithLifecycle()
    val analysis by vm.analysisProgress.collectAsStateWithLifecycle()
    val setOrder by vm.setOrder.collectAsStateWithLifecycle()
    val activePl by vm.activePlaylist.collectAsStateWithLifecycle()
    val folders by vm.folders.collectAsStateWithLifecycle()
    val libFilter by vm.libFilter.collectAsStateWithLifecycle()
    val queue by vm.autoDj.queue.collectAsStateWithLifecycle()
    var showPl by remember { mutableStateOf(false) }
    if (showPl) PlaylistDialog(vm) { showPl = false }
    val setPos = remember(setOrder) { setOrder.withIndex().associate { it.value to it.index + 1 } }
    // tom de referência: o do deck que está tocando; senão o de qualquer deck carregado
    val refDeck = decks.firstOrNull { it.playing && it.shownKey != null } ?: decks.firstOrNull { it.loaded && it.shownKey != null }
    val refKey = refDeck?.shownKey
    // filtros rápidos para achar a próxima música: tom que combina e andamento parecido com o deck que está tocando, ou ainda não tocadas hoje
    var quick by androidx.compose.runtime.saveable.rememberSaveable { mutableStateOf(0) }
    val playedNow by vm.playedIds.collectAsStateWithLifecycle()
    val refBpm = refDeck?.takeIf { it.hasBpm }?.playedBpm ?: 0.0
    val shown = remember(tracks, quick, refKey, refBpm, playedNow) {
        when (quick) {
            1 -> if (refKey == null) tracks else tracks.filter { r -> r.key?.let { Camelot.distance(refKey, it) <= 1 } == true }
            2 -> if (refBpm <= 0.0) tracks else tracks.filter { r -> r.bpm > 0 && kotlin.math.abs(r.bpm - refBpm) / refBpm <= 0.06 }
            3 -> tracks.filter { it.id !in playedNow }
            else -> tracks
        }
    }

    val picker = rememberLauncherForActivityResult(ActivityResultContracts.OpenMultipleDocuments()) { uris ->
        vm.importUris(uris)
    }
    val folderPicker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocumentTree()) { uri ->
        if (uri != null) vm.importFolder(uri)
    }

    Row(Modifier.fillMaxSize().background(Metal.Bg).padding(horizontal = 14.dp, vertical = 8.dp)) {
    Column(Modifier.weight(1f).fillMaxHeight()) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            MetalButton(
                description = "Importar músicas do aparelho",
                onPress = { picker.launch(arrayOf("*/*")) },
                modifier = Modifier.weight(1f).height(46.dp),
            ) {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Text("IMPORTAR", color = Metal.OnMetal, fontSize = 13.sp, fontWeight = FontWeight.ExtraBold)
                    Text("MÚSICAS", color = Metal.TextMuted, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                }
            }
            Spacer(Modifier.width(8.dp))
            MetalButton(
                description = "Importar uma pasta inteira de músicas",
                onPress = { folderPicker.launch(null) },
                led = Metal.Success, ledOn = folders.isNotEmpty(),
                modifier = Modifier.weight(1.1f).height(46.dp),
            ) {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Text("IMPORTAR", color = Metal.OnMetal, fontSize = 13.sp, fontWeight = FontWeight.ExtraBold)
                    Text(if (folders.isEmpty()) "PASTA INTEIRA" else "PASTA (${folders.size})", color = Metal.TextMuted, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                }
            }
            if (folders.isNotEmpty()) {
                Spacer(Modifier.width(8.dp))
                MetalButton(
                    description = "Atualizar as pastas importadas: procurar músicas novas",
                    onPress = { vm.rescanFolders() },
                    modifier = Modifier.weight(1f).height(46.dp),
                ) {
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Text("ATUALIZAR", color = Metal.OnMetal, fontSize = 12.sp, fontWeight = FontWeight.ExtraBold)
                        Text("PASTAS", color = Metal.TextMuted, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                    }
                }
            }
            Spacer(Modifier.width(8.dp))
            MetalButton(
                description = if (analysis != null) "Parar a análise da biblioteca" else "Analisar andamento e tom de todas as músicas da biblioteca",
                onPress = { vm.analyzeLibrary() },
                led = Metal.Success, ledOn = analysis != null,
                modifier = Modifier.weight(1f).height(46.dp),
            ) {
                Text(
                    if (analysis != null) "PARAR · $analysis" else "ANALISAR",
                    color = Metal.OnMetal, fontSize = if (analysis != null) 11.sp else 14.sp, fontWeight = FontWeight.ExtraBold,
                )
            }
            Spacer(Modifier.width(8.dp))
            MetalButton(
                description = "Harmonizar: montar a ordem do set por tom, andamento e energia",
                onPress = { vm.harmonize() },
                led = Metal.Success, ledOn = setOrder.isNotEmpty(),
                modifier = Modifier.weight(1f).height(46.dp),
            ) {
                Text("HARMONIZAR", color = Metal.OnMetal, fontSize = 13.sp, fontWeight = FontWeight.ExtraBold, maxLines = 1)
            }
        }
        OutlinedTextField(
            value = search,
            onValueChange = vm::setSearch,
            singleLine = true,
            placeholder = { Text("Buscar por música ou artista", maxLines = 1) },
            modifier = Modifier.fillMaxWidth().padding(top = 2.dp),
        )
        Row(
            Modifier.fillMaxWidth().padding(vertical = 2.dp).horizontalScroll(rememberScrollState()),
            horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically,
        ) {
            Text("${shown.size} faixa(s) · Ordenar:", color = Metal.TextMuted, fontSize = 13.sp, maxLines = 1, softWrap = false)
            SortChip("Recentes", sort == SortOrder.RECENT) { vm.setSort(SortOrder.RECENT) }
            SortChip("Título", sort == SortOrder.TITLE) { vm.setSort(SortOrder.TITLE) }
            SortChip("Artista", sort == SortOrder.ARTIST) { vm.setSort(SortOrder.ARTIST) }
            SortChip("BPM", sort == SortOrder.BPM) { vm.setSort(SortOrder.BPM) }
            SortChip("Tom", sort == SortOrder.KEY) { vm.setSort(SortOrder.KEY) }
            if (setOrder.isNotEmpty()) SortChip("Set", sort == SortOrder.SET) { vm.setSort(SortOrder.SET) }
            SortChip("★ Favoritas", libFilter == 1, "Mostrar só as favoritas") { vm.setLibFilter(1) }
            SortChip("Duplicadas", libFilter == 2, "Mostrar possíveis músicas duplicadas") { vm.setLibFilter(2) }
            SortChip("Tom que combina", quick == 1, "Mostrar só músicas com tom que combina com o deck tocando") { quick = if (quick == 1) 0 else 1 }
            SortChip("BPM parecido", quick == 2, "Mostrar só músicas com andamento até 6% de diferença do deck tocando") { quick = if (quick == 2) 0 else 2 }
            SortChip("Não tocadas", quick == 3, "Mostrar só músicas que ainda não tocaram hoje") { quick = if (quick == 3) 0 else 3 }
            Box(
                Modifier.heightIn(min = 48.dp).clip(RoundedCornerShape(50))
                    .semantics { role = Role.Button; contentDescription = "Playlists: abrir, salvar e apagar" }
                    .clickable { showPl = true },
                contentAlignment = Alignment.Center,
            ) {
                Text(
                    "☰ " + (activePl?.let { if (it.length > 12) it.take(11) + "…" else it } ?: "PLAYLISTS"),
                    color = Metal.Text, fontSize = 13.sp, fontWeight = FontWeight.ExtraBold, maxLines = 1, overflow = TextOverflow.Ellipsis,
                    modifier = Modifier.clip(RoundedCornerShape(50)).background(Color(0xFF203A2C)).padding(horizontal = 14.dp, vertical = 6.dp),
                )
            }
        }

        if (shown.isEmpty()) {
            Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                Text(
                    if (quick != 0 && tracks.isNotEmpty()) {
                        "Nenhuma música com esse filtro agora. Toque no filtro de novo para desligar" +
                            (if (quick != 3) " (ele compara com o deck que está tocando)." else ".")
                    } else if (libFilter == 1) {
                        "Nenhuma favorita ainda. Toque na estrela ☆ de uma música."
                    } else if (libFilter == 2) {
                        "Nenhuma música duplicada encontrada."
                    } else if (search.isBlank()) {
                        "Sua biblioteca está vazia.\nToque em IMPORTAR e escolha músicas do aparelho (MP3, WAV, FLAC, AAC, OGG)."
                    } else {
                        "Nenhuma faixa encontrada para \"$search\"."
                    },
                    color = Metal.TextMuted, fontSize = 15.sp,
                )
            }
        } else {
            LazyColumn(Modifier.fillMaxSize(), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                items(shown, key = { it.id }) { row ->
                    Row(
                        Modifier.fillMaxWidth().clip(RoundedCornerShape(10.dp)).background(Metal.Surface)
                            .padding(horizontal = 12.dp, vertical = 2.dp).heightIn(min = 48.dp),
                        verticalAlignment = Alignment.CenterVertically,
                    ) {
                        Column(Modifier.weight(1f)) {
                            val played = row.id in vm.playedIds.collectAsStateWithLifecycle().value
                            Text((if (played) "✓ " else "") + row.title, color = if (played) Metal.TextMuted else Metal.Text, fontSize = 15.sp, fontWeight = FontWeight.SemiBold, maxLines = 1, overflow = TextOverflow.Ellipsis)
                            Text(
                                (if (row.artist.isEmpty()) "Artista desconhecido" else row.artist) + if (row.genre.isNotEmpty()) " · ${row.genre}" else "",
                                color = Metal.TextMuted, fontSize = 12.sp, maxLines = 1, overflow = TextOverflow.Ellipsis,
                            )
                        }
                        Box(
                            Modifier.size(44.dp).clip(RoundedCornerShape(10.dp))
                                .semantics { role = Role.Button; contentDescription = (if (row.favorite) "Tirar ${row.title} das favoritas" else "Marcar ${row.title} como favorita") }
                                .clickable { vm.toggleFavorite(row) },
                            contentAlignment = Alignment.Center,
                        ) {
                            Text(if (row.favorite) "★" else "☆", color = if (row.favorite) Color(0xFFFFC14D) else Metal.TextMuted, fontSize = 22.sp)
                        }
                        setPos[row.id]?.let { n ->
                            Text("#$n", color = Metal.Success, fontSize = 13.sp, fontWeight = FontWeight.ExtraBold, modifier = Modifier.padding(end = 10.dp))
                        }
                        if (row.energyLevel > 0) {
                            Text(
                                "E${row.energyLevel}", color = energyColor(row.energyLevel), fontSize = 13.sp, fontWeight = FontWeight.ExtraBold,
                                modifier = Modifier.padding(end = 10.dp).semantics { contentDescription = "Energia ${row.energyLevel} de 10" },
                            )
                        }
                        KeyChip(row.key, refKey, small = true, modifier = Modifier.padding(end = 10.dp))
                        Text(
                            if (row.bpm > 0) String.format(java.util.Locale.ROOT, "%.0f BPM", row.bpm) else "— BPM",
                            color = if (row.bpm > 0) Metal.Text else Metal.TextMuted, fontSize = 13.sp, fontWeight = FontWeight.Bold,
                        )
                        Text(formatTime(row.durationMs), color = Metal.TextMuted, fontSize = 13.sp, modifier = Modifier.padding(horizontal = 12.dp))
                        val queued = queue.indexOf(row.id)
                        Box(
                            Modifier.size(44.dp).clip(RoundedCornerShape(10.dp))
                                .background(if (queued >= 0) Color(0xFF3A3020) else Metal.SurfaceRaised)
                                .semantics { role = Role.Button; contentDescription = (if (queued >= 0) "Tirar ${row.title} da fila do AUTO DJ" else "Tocar ${row.title} em seguida no AUTO DJ (fila)") }
                                .clickable { vm.autoDj.toggleQueue(row) },
                            contentAlignment = Alignment.Center,
                        ) {
                            Text(if (queued >= 0) "${queued + 1}º" else "▶▶", color = if (queued >= 0) Metal.Warning else Metal.TextMuted, fontSize = if (queued >= 0) 15.sp else 11.sp, fontWeight = FontWeight.ExtraBold)
                        }
                        Spacer(Modifier.width(6.dp))
                        val inSet = row.id in setPos
                        Box(
                            Modifier.size(44.dp).clip(RoundedCornerShape(10.dp))
                                .background(if (inSet) Color(0xFF203A2C) else Metal.SurfaceRaised)
                                .semantics { role = Role.Button; contentDescription = (if (inSet) "Tirar " else "Pôr ") + "${row.title} na playlist" }
                                .clickable { vm.toggleInSet(row) },
                            contentAlignment = Alignment.Center,
                        ) {
                            Text(if (inSet) "−" else "+", color = if (inSet) Metal.Success else Metal.Text, fontSize = 22.sp, fontWeight = FontWeight.Bold)
                        }
                        Spacer(Modifier.width(8.dp))
                        for (deck in ly) {
                            MetalButton(
                                description = "Carregar ${row.title} no deck ${AppViewModel.deckName(deck)}",
                                onPress = { vm.loadTrack(deck, row) },
                                fireOnPress = false,
                                led = deckColor(deck), ledOn = decks[deck].trackId == row.id && decks[deck].loaded,
                                modifier = Modifier.size(width = 56.dp, height = 48.dp),
                            ) {
                                Text(AppViewModel.deckName(deck), color = Metal.OnMetal, fontSize = 18.sp, fontWeight = FontWeight.ExtraBold)
                            }
                            Spacer(Modifier.width(8.dp))
                        }
                        Box(
                            Modifier.size(48.dp).clip(RoundedCornerShape(10.dp))
                                .semantics {
                                    contentDescription = "Remover ${row.title} da biblioteca. O arquivo não é apagado."
                                    role = Role.Button
                                }
                                .clickable { vm.removeFromLibrary(row) },
                            contentAlignment = Alignment.Center,
                        ) {
                            Text("✕", color = Metal.TextMuted, fontSize = 18.sp)
                        }
                    }
                }
            }
        }
    }
    Column(
        Modifier.width(196.dp).fillMaxHeight().padding(start = 12.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
    ) {
        Text("RODA DE CAMELOT", color = Metal.TextMuted, fontSize = 11.sp, fontWeight = FontWeight.Bold, letterSpacing = 1.sp)
        CamelotWheel(listOf(decks[ly[0]].shownKey, decks[ly[1]].shownKey), refKey, Modifier.size(150.dp).padding(top = 2.dp))
        for (deck in ly) {
            val k = decks[deck].shownKey
            Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.padding(top = 4.dp)) {
                Text("Deck ${AppViewModel.deckName(deck)}  ", color = Metal.TextMuted, fontSize = 12.sp)
                KeyChip(k, decks[deck xor 1].shownKey)
                if (k != null && decks[deck].rate != 1f && !decks[deck].keyLock && Camelot.semitonesFor(decks[deck].rate) != 0) {
                    Text("  tom mudou com a velocidade", color = Metal.Warning, fontSize = 11.sp)
                }
            }
        }
        Text(
            "Brilhante: combina · apagado: choca. Ligue KEY para o tom não mudar com o tempo.",
            color = Metal.TextMuted, fontSize = 11.sp, modifier = Modifier.padding(top = 4.dp),
        )
        val idle = if (decks[ly[0]].playing && !decks[ly[1]].playing) ly[1] else if (decks[ly[1]].playing && !decks[ly[0]].playing) ly[0] else ly[1]
        SuggestionList(vm, idle, tracks, Modifier.fillMaxWidth().padding(top = 6.dp))
    }
    }
}

/** Janela das playlists: salvar a atual com nome, abrir, apagar ou começar uma nova. */
@Composable
private fun PlaylistDialog(vm: AppViewModel, onClose: () -> Unit) {
    val lists by vm.playlists.collectAsStateWithLifecycle()
    val active by vm.activePlaylist.collectAsStateWithLifecycle()
    val setOrder by vm.setOrder.collectAsStateWithLifecycle()
    var name by remember { mutableStateOf(active ?: "") }
    val smart by vm.smartLists.collectAsStateWithLifecycle()
    var rBpm by remember { mutableStateOf(0) }
    var rEnergy by remember { mutableStateOf(0) }
    var rGenre by remember { mutableStateOf("") }
    var rFav by remember { mutableStateOf(false) }
    var rNew by remember { mutableStateOf(false) }
    AlertDialog(
        onDismissRequest = onClose,
        containerColor = Metal.Surface,
        title = { Text("PLAYLISTS", color = Metal.Text, fontWeight = FontWeight.ExtraBold) },
        text = {
            Column(Modifier.verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text(
                    "Playlist atual: ${setOrder.size} música(s)" + (active?.let { " · \"$it\"" } ?: " (sem nome)") +
                        ". Use + nas músicas para montar. O AUTO DJ segue a ordem; HARMONIZAR reordena só ela.",
                    color = Metal.TextMuted, fontSize = 12.sp,
                )
                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedTextField(
                        value = name, onValueChange = { name = it }, singleLine = true,
                        placeholder = { Text("Nome da playlist") }, modifier = Modifier.weight(1f),
                    )
                    MetalButton("Salvar a playlist atual com este nome", { vm.savePlaylist(name) }, modifier = Modifier.width(96.dp).height(52.dp)) {
                        Text("SALVAR", color = Metal.OnMetal, fontSize = 13.sp, fontWeight = FontWeight.ExtraBold)
                    }
                    MetalButton("Começar uma playlist nova, vazia", { vm.newPlaylist(); name = "" }, modifier = Modifier.width(86.dp).height(52.dp)) {
                        Text("NOVA", color = Metal.OnMetal, fontSize = 13.sp, fontWeight = FontWeight.ExtraBold)
                    }
                }
                Text("LISTA INTELIGENTE: escolha as regras e toque em MONTAR. Salva com nome, ela se atualiza sozinha ao abrir.", color = Metal.TextMuted, fontSize = 12.sp)
                Row(Modifier.fillMaxWidth().height(44.dp), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    MetalButton("Regra de andamento da lista inteligente: ${SmartRule.BPM_BANDS[rBpm]}", { rBpm = (rBpm + 1) % SmartRule.BPM_BANDS.size }, led = Metal.Success, ledOn = rBpm > 0, modifier = Modifier.weight(1.2f).fillMaxHeight()) {
                        Text("BPM ${SmartRule.BPM_BANDS[rBpm]}", color = Metal.OnMetal, fontSize = 11.sp, fontWeight = FontWeight.ExtraBold, maxLines = 1, modifier = Modifier.align(Alignment.Center))
                    }
                    MetalButton("Regra de energia da lista inteligente: ${SmartRule.ENERGY_BANDS[rEnergy]}", { rEnergy = (rEnergy + 1) % SmartRule.ENERGY_BANDS.size }, led = Metal.Success, ledOn = rEnergy > 0, modifier = Modifier.weight(1.2f).fillMaxHeight()) {
                        Text("ENERGIA ${SmartRule.ENERGY_BANDS[rEnergy]}", color = Metal.OnMetal, fontSize = 11.sp, fontWeight = FontWeight.ExtraBold, maxLines = 1, modifier = Modifier.align(Alignment.Center))
                    }
                    MetalButton("Regra da lista inteligente: só favoritas", { rFav = !rFav }, led = Metal.Success, ledOn = rFav, modifier = Modifier.weight(1f).fillMaxHeight()) {
                        Text("★ FAVORITAS", color = Metal.OnMetal, fontSize = 11.sp, fontWeight = FontWeight.ExtraBold, maxLines = 1, modifier = Modifier.align(Alignment.Center))
                    }
                    MetalButton("Regra da lista inteligente: só as que ainda não tocaram", { rNew = !rNew }, led = Metal.Success, ledOn = rNew, modifier = Modifier.weight(1f).fillMaxHeight()) {
                        Text("NÃO TOCADAS", color = Metal.OnMetal, fontSize = 11.sp, fontWeight = FontWeight.ExtraBold, maxLines = 1, modifier = Modifier.align(Alignment.Center))
                    }
                }
                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedTextField(
                        value = rGenre, onValueChange = { rGenre = it.take(40) }, singleLine = true,
                        placeholder = { Text("Gênero (ex.: pop, house) — opcional") }, modifier = Modifier.weight(1f),
                    )
                    MetalButton("Montar a lista inteligente com estas regras", { vm.buildSmartList(SmartRule(rBpm, rEnergy, rGenre, rFav, rNew)) }, modifier = Modifier.width(96.dp).height(52.dp)) {
                        Text("MONTAR", color = Metal.OnMetal, fontSize = 13.sp, fontWeight = FontWeight.ExtraBold)
                    }
                }
                if (lists.isEmpty()) Text("Nenhuma playlist salva ainda.", color = Metal.TextMuted, fontSize = 13.sp)
                LazyColumn(Modifier.heightIn(max = 160.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                    items(lists.keys.toList(), key = { it }) { pl ->
                        Row(
                            Modifier.fillMaxWidth().clip(RoundedCornerShape(8.dp))
                                .background(if (pl == active) Color(0xFF203A2C) else Metal.SurfaceRaised)
                                .semantics { role = Role.Button; contentDescription = "Abrir a playlist $pl" }
                                .clickable { vm.openPlaylist(pl); name = pl; onClose() }
                                .padding(horizontal = 12.dp, vertical = 8.dp),
                            verticalAlignment = Alignment.CenterVertically,
                        ) {
                            Text((if (pl in smart) "⚡ " else "") + pl, color = Metal.Text, fontSize = 15.sp, fontWeight = FontWeight.SemiBold, modifier = Modifier.weight(1f), maxLines = 1, overflow = TextOverflow.Ellipsis)
                            Text("${lists[pl]?.size ?: 0} músicas", color = Metal.TextMuted, fontSize = 12.sp, modifier = Modifier.padding(horizontal = 10.dp))
                            Box(
                                Modifier.size(40.dp).clip(RoundedCornerShape(8.dp))
                                    .semantics { role = Role.Button; contentDescription = "Apagar a playlist $pl" }
                                    .clickable { vm.deletePlaylist(pl) },
                                contentAlignment = Alignment.Center,
                            ) { Text("✕", color = Metal.TextMuted, fontSize = 16.sp) }
                        }
                    }
                }
            }
        },
        confirmButton = {
            MetalButton("Fechar as playlists", onClose, modifier = Modifier.width(96.dp).height(44.dp)) {
                Text("FECHAR", color = Metal.OnMetal, fontSize = 13.sp, fontWeight = FontWeight.ExtraBold)
            }
        },
    )
}

@Composable
private fun SortChip(label: String, selected: Boolean, description: String = "Ordenar por $label", onClick: () -> Unit) {
    val shape = RoundedCornerShape(50)
    Box(
        Modifier.heightIn(min = 42.dp).clip(shape)
            .semantics { role = Role.Button; contentDescription = description }
            .clickable(onClick = onClick),
        contentAlignment = Alignment.Center,
    ) {
        Box(
            Modifier.clip(shape)
                .background(if (selected) Metal.DeckA else Metal.SurfaceRaised)
                .padding(horizontal = 14.dp, vertical = 6.dp),
        ) {
            Text(label, color = if (selected) Metal.OnDeckA else Metal.Text, fontSize = 13.sp, fontWeight = FontWeight.SemiBold)
        }
    }
}


/** Cor da energia: azul (calma) a vermelho (pico). */
internal fun energyColor(level: Int): androidx.compose.ui.graphics.Color = when {
    level <= 3 -> androidx.compose.ui.graphics.Color(0xFF6CA8FF)
    level <= 6 -> androidx.compose.ui.graphics.Color(0xFFFFD166)
    level <= 8 -> androidx.compose.ui.graphics.Color(0xFFFF8A3D)
    else -> androidx.compose.ui.graphics.Color(0xFFFF4D4D)
}
