package app.djfusion.ui

import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.role
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import app.djfusion.data.SortOrder
import app.djfusion.harmony.Camelot
import app.djfusion.ui.theme.Metal

@Composable
fun LibraryScreen(vm: AppViewModel) {
    val tracks by vm.tracks.collectAsStateWithLifecycle()
    val search by vm.search.collectAsStateWithLifecycle()
    val sort by vm.sort.collectAsStateWithLifecycle()
    val decks by vm.decks.collectAsStateWithLifecycle()
    val analysis by vm.analysisProgress.collectAsStateWithLifecycle()
    val setOrder by vm.setOrder.collectAsStateWithLifecycle()
    val setPos = remember(setOrder) { setOrder.withIndex().associate { it.value to it.index + 1 } }
    // tom de referência: o do deck que está tocando; senão o de qualquer deck carregado
    val refDeck = decks.firstOrNull { it.playing && it.shownKey != null } ?: decks.firstOrNull { it.loaded && it.shownKey != null }
    val refKey = refDeck?.shownKey

    val picker = rememberLauncherForActivityResult(ActivityResultContracts.OpenMultipleDocuments()) { uris ->
        vm.importUris(uris)
    }
    val folderPicker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocumentTree()) { uri ->
        if (uri != null) vm.importFolder(uri)
    }

    Row(Modifier.fillMaxSize().background(Metal.Bg).padding(horizontal = 14.dp, vertical = 8.dp)) {
    Column(Modifier.weight(1f).fillMaxHeight()) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            OutlinedTextField(
                value = search,
                onValueChange = vm::setSearch,
                singleLine = true,
                placeholder = { Text("Buscar", maxLines = 1) },
                modifier = Modifier.weight(1f),
            )
            Spacer(Modifier.width(10.dp))
            MetalButton(
                description = "Importar músicas do aparelho",
                onPress = { picker.launch(arrayOf("*/*")) },
                modifier = Modifier.width(132.dp).height(56.dp),
            ) {
                Text("IMPORTAR", color = Metal.OnMetal, fontSize = 14.sp, fontWeight = FontWeight.ExtraBold)
            }
            Spacer(Modifier.width(8.dp))
            MetalButton(
                description = "Importar uma pasta inteira de músicas",
                onPress = { folderPicker.launch(null) },
                modifier = Modifier.width(110.dp).height(56.dp),
            ) {
                Text("PASTA", color = Metal.OnMetal, fontSize = 14.sp, fontWeight = FontWeight.ExtraBold)
            }
            Spacer(Modifier.width(8.dp))
            MetalButton(
                description = if (analysis != null) "Parar a análise da biblioteca" else "Analisar andamento e tom de todas as músicas da biblioteca",
                onPress = { vm.analyzeLibrary() },
                led = Metal.Success, ledOn = analysis != null,
                modifier = Modifier.width(132.dp).height(56.dp),
            ) {
                Text(
                    if (analysis != null) "PARAR · $analysis" else "ANALISAR",
                    color = Metal.OnMetal, fontSize = if (analysis != null) 11.sp else 14.sp, fontWeight = FontWeight.ExtraBold,
                )
            }
            Spacer(Modifier.width(8.dp))
            MetalButton(
                description = "Harmonizar: montar a ordem do set por tom, andamento e energia",
                onPress = { vm.harmonize() },
                led = Metal.Success, ledOn = setOrder.isNotEmpty(),
                modifier = Modifier.width(140.dp).height(56.dp),
            ) {
                Text("HARMONIZAR", color = Metal.OnMetal, fontSize = 13.sp, fontWeight = FontWeight.ExtraBold, maxLines = 1)
            }
        }
        Row(Modifier.padding(vertical = 8.dp), horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically) {
            Text("Ordenar:", color = Metal.TextMuted, fontSize = 13.sp)
            SortChip("Recentes", sort == SortOrder.RECENT) { vm.setSort(SortOrder.RECENT) }
            SortChip("Título", sort == SortOrder.TITLE) { vm.setSort(SortOrder.TITLE) }
            SortChip("Artista", sort == SortOrder.ARTIST) { vm.setSort(SortOrder.ARTIST) }
            SortChip("BPM", sort == SortOrder.BPM) { vm.setSort(SortOrder.BPM) }
            SortChip("Tom", sort == SortOrder.KEY) { vm.setSort(SortOrder.KEY) }
            if (setOrder.isNotEmpty()) SortChip("Set", sort == SortOrder.SET) { vm.setSort(SortOrder.SET) }
            Spacer(Modifier.weight(1f))
            Text("${tracks.size} faixa(s)", color = Metal.TextMuted, fontSize = 13.sp)
        }

        if (tracks.isEmpty()) {
            Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                Text(
                    if (search.isBlank()) {
                        "Sua biblioteca está vazia.\nToque em IMPORTAR e escolha músicas do aparelho (MP3, WAV, FLAC, AAC, OGG)."
                    } else {
                        "Nenhuma faixa encontrada para \"$search\"."
                    },
                    color = Metal.TextMuted, fontSize = 15.sp,
                )
            }
        } else {
            LazyColumn(Modifier.fillMaxSize(), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                items(tracks, key = { it.id }) { row ->
                    Row(
                        Modifier.fillMaxWidth().clip(RoundedCornerShape(10.dp)).background(Metal.Surface)
                            .padding(horizontal = 12.dp, vertical = 6.dp).heightIn(min = 56.dp),
                        verticalAlignment = Alignment.CenterVertically,
                    ) {
                        Column(Modifier.weight(1f)) {
                            Text(row.title, color = Metal.Text, fontSize = 15.sp, fontWeight = FontWeight.SemiBold, maxLines = 1, overflow = TextOverflow.Ellipsis)
                            Text(
                                if (row.artist.isEmpty()) "Artista desconhecido" else row.artist,
                                color = Metal.TextMuted, fontSize = 12.sp, maxLines = 1, overflow = TextOverflow.Ellipsis,
                            )
                        }
                        setPos[row.id]?.let { n ->
                            Text("#$n", color = Metal.Success, fontSize = 13.sp, fontWeight = FontWeight.ExtraBold, modifier = Modifier.padding(end = 10.dp))
                        }
                        if (row.energyLevel > 0) {
                            Text(
                                "E${row.energyLevel}", color = energyColor(row.energyLevel), fontSize = 13.sp, fontWeight = FontWeight.ExtraBold,
                                modifier = Modifier.padding(end = 10.dp).semantics { contentDescription = "Energia ${row.energyLevel} de 10" },
                            )
                        }
                        KeyChip(row.key, refKey, small = true, modifier = Modifier.padding(end = 10.dp))
                        Text(
                            if (row.bpm > 0) String.format(java.util.Locale.ROOT, "%.0f BPM", row.bpm) else "— BPM",
                            color = if (row.bpm > 0) Metal.Text else Metal.TextMuted, fontSize = 13.sp, fontWeight = FontWeight.Bold,
                        )
                        Text(formatTime(row.durationMs), color = Metal.TextMuted, fontSize = 13.sp, modifier = Modifier.padding(horizontal = 12.dp))
                        for (deck in 0..1) {
                            MetalButton(
                                description = "Carregar ${row.title} no deck ${AppViewModel.deckName(deck)}",
                                onPress = { vm.loadTrack(deck, row) },
                                fireOnPress = false,
                                led = deckColor(deck), ledOn = decks[deck].trackId == row.id && decks[deck].loaded,
                                modifier = Modifier.size(width = 56.dp, height = 48.dp),
                            ) {
                                Text(AppViewModel.deckName(deck), color = Metal.OnMetal, fontSize = 18.sp, fontWeight = FontWeight.ExtraBold)
                            }
                            Spacer(Modifier.width(8.dp))
                        }
                        Box(
                            Modifier.size(48.dp).clip(RoundedCornerShape(10.dp))
                                .semantics {
                                    contentDescription = "Remover ${row.title} da biblioteca. O arquivo não é apagado."
                                    role = Role.Button
                                }
                                .clickable { vm.removeFromLibrary(row) },
                            contentAlignment = Alignment.Center,
                        ) {
                            Text("✕", color = Metal.TextMuted, fontSize = 18.sp)
                        }
                    }
                }
            }
        }
    }
    Column(
        Modifier.width(196.dp).fillMaxHeight().padding(start = 12.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
    ) {
        Text("RODA DE CAMELOT", color = Metal.TextMuted, fontSize = 10.sp, fontWeight = FontWeight.Bold, letterSpacing = 1.sp)
        CamelotWheel(listOf(decks[0].shownKey, decks[1].shownKey), refKey, Modifier.size(150.dp).padding(top = 2.dp))
        for (deck in 0..1) {
            val k = decks[deck].shownKey
            Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.padding(top = 4.dp)) {
                Text("Deck ${AppViewModel.deckName(deck)}  ", color = Metal.TextMuted, fontSize = 12.sp)
                KeyChip(k, if (deck == 0) decks[1].shownKey else decks[0].shownKey)
                if (k != null && decks[deck].rate != 1f && !decks[deck].keyLock && Camelot.semitonesFor(decks[deck].rate) != 0) {
                    Text("  tom mudou com a velocidade", color = Metal.Warning, fontSize = 9.sp)
                }
            }
        }
        Text(
            "Brilhante: combina · apagado: choca. Ligue KEY para o tom não mudar com o tempo.",
            color = Metal.TextMuted, fontSize = 9.sp, modifier = Modifier.padding(top = 4.dp),
        )
        val idle = if (decks[0].playing && !decks[1].playing) 1 else if (decks[1].playing && !decks[0].playing) 0 else 1
        SuggestionList(vm, idle, tracks, Modifier.fillMaxWidth().padding(top = 6.dp))
    }
    }
}

@Composable
private fun SortChip(label: String, selected: Boolean, onClick: () -> Unit) {
    val shape = RoundedCornerShape(50)
    Box(
        Modifier.heightIn(min = 48.dp).clip(shape)
            .semantics { role = Role.Button; contentDescription = "Ordenar por $label" }
            .clickable(onClick = onClick),
        contentAlignment = Alignment.Center,
    ) {
        Box(
            Modifier.clip(shape)
                .background(if (selected) Metal.DeckA else Metal.SurfaceRaised)
                .padding(horizontal = 14.dp, vertical = 6.dp),
        ) {
            Text(label, color = if (selected) Metal.OnDeckA else Metal.Text, fontSize = 13.sp, fontWeight = FontWeight.SemiBold)
        }
    }
}


/** Cor da energia: azul (calma) a vermelho (pico). */
internal fun energyColor(level: Int): androidx.compose.ui.graphics.Color = when {
    level <= 3 -> androidx.compose.ui.graphics.Color(0xFF6CA8FF)
    level <= 6 -> androidx.compose.ui.graphics.Color(0xFFFFD166)
    level <= 8 -> androidx.compose.ui.graphics.Color(0xFFFF8A3D)
    else -> androidx.compose.ui.graphics.Color(0xFFFF4D4D)
}
