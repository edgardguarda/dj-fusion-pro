package app.djfusion.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.role
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import app.djfusion.midi.MidiTargets
import app.djfusion.ui.theme.Metal
import kotlinx.coroutines.delay

/**
 * Selo de estado na barra de cima: ✓ verde quando está tudo certo, ⚠ N em âmbar quando o app achou problemas.
 * Toque: abre VERIFICAR (problemas com correção de um toque, controladora e relatório).
 */
@Composable
fun StatusChip(vm: AppViewModel, onOpen: () -> Unit) {
    val problems by vm.problems.collectAsStateWithLifecycle()
    val devices by vm.midi.devices.collectAsStateWithLifecycle()
    val n = problems.size
    val desc = if (n == 0) "Verificar: tudo certo" + (if (devices.isNotEmpty()) ", controladora conectada" else "") else "Verificar: $n problema(s) encontrado(s). Toque para ver e corrigir"
    Box(
        Modifier.height(36.dp).width(72.dp).clip(RoundedCornerShape(8.dp))
            .background(if (n == 0) Color(0xFF1E2A22) else Color(0xFF3A2E14))
            .semantics { role = Role.Button; contentDescription = desc }
            .clickable(onClick = onOpen),
        contentAlignment = Alignment.Center,
    ) {
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            Text(if (n == 0) "✓ OK" else "⚠ $n", color = if (n == 0) Metal.Success else Metal.Warning, fontSize = 14.sp, fontWeight = FontWeight.ExtraBold, maxLines = 1)
            Text(if (devices.isNotEmpty()) "MIDI ●" else "MIDI ○", color = if (devices.isNotEmpty()) Metal.Success else Metal.TextMuted, fontSize = 9.sp, fontWeight = FontWeight.Bold, maxLines = 1)
        }
    }
}

/** VERIFICAR: lista o que o app achou de errado, com o botão que corrige; e o relatório completo para mandar. */
@Composable
fun ProblemsDialog(vm: AppViewModel, onClose: () -> Unit) {
    val problems by vm.problems.collectAsStateWithLifecycle()
    val devices by vm.midi.devices.collectAsStateWithLifecycle()
    val mapped by vm.midi.mapped.collectAsStateWithLifecycle()
    val preset by vm.midi.presetName.collectAsStateWithLifecycle()
    LaunchedEffect(Unit) { vm.refreshProblemsNow() }
    AlertDialog(
        onDismissRequest = onClose,
        title = { Text("VERIFICAR", fontWeight = FontWeight.ExtraBold) },
        text = {
            Column(Modifier.heightIn(max = 330.dp).verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text(
                    if (devices.isEmpty()) "Controladora: nenhuma conectada."
                    else "Controladora: ${devices.joinToString()} · ${mapped.size} controles mapeados" + (if (preset.isNotEmpty()) " · mapa: $preset" else ""),
                    color = Metal.Text, fontSize = 13.sp,
                )
                if (problems.isEmpty()) {
                    Text("✓ Nenhum problema encontrado agora.", color = Metal.Success, fontSize = 15.sp, fontWeight = FontWeight.Bold)
                }
                for (p in problems) {
                    Column(
                        Modifier.fillMaxWidth().clip(RoundedCornerShape(8.dp)).background(Color(0xFF22262B)).padding(10.dp),
                        verticalArrangement = Arrangement.spacedBy(4.dp),
                    ) {
                        Text("⚠ " + p.title, color = Metal.Warning, fontSize = 14.sp, fontWeight = FontWeight.ExtraBold)
                        Text(p.detail, color = Metal.Text, fontSize = 12.sp)
                        val fix = p.fix
                        if (fix != null && p.fixLabel != null) {
                            MetalButton("Corrigir: ${p.fixLabel}", { fix(); vm.refreshProblemsNow() }, modifier = Modifier.height(36.dp)) {
                                Text(p.fixLabel, color = Metal.OnMetal, fontSize = 12.sp, fontWeight = FontWeight.ExtraBold, modifier = Modifier.align(Alignment.Center).padding(horizontal = 12.dp))
                            }
                        }
                    }
                }
                Text(
                    "O RELATÓRIO junta tudo (som, controladora, botões sem função, erros e fechamentos) e salva em Download. Mande para quem cuida do app.",
                    color = Metal.TextMuted, fontSize = 11.sp,
                )
            }
        },
        confirmButton = { TextButton(onClick = { vm.exportDiagnostics() }) { Text("RELATÓRIO") } },
        dismissButton = {
            Row {
                if (devices.isNotEmpty()) TextButton(onClick = { vm.openMidiScreen(); onClose() }) { Text("CONTROLADORA") }
                TextButton(onClick = onClose) { Text("FECHAR") }
            }
        },
    )
}

/**
 * Assistente da controladora (aparece sozinho por cima de qualquer tela):
 * - botão sem função: "o que ele faz?" com as funções prováveis (pads em sequência, botões giratórios…);
 * - controladora reconhecida pelo jeito de mandar mensagens: oferece o mapa pronto certo.
 */
@Composable
fun MidiAssistBanner(vm: AppViewModel, modifier: Modifier = Modifier) {
    val hub = vm.midi
    val unknown by hub.unknown.collectAsStateWithLifecycle()
    val learning by hub.learning.collectAsStateWithLifecycle()
    val suggest by hub.suggestPreset.collectAsStateWithLifecycle()
    var pickFor by remember { mutableStateOf<Int?>(null) }
    val s = suggest
    val u = unknown
    if (learning != null) return
    if (s != null) {
        Card(modifier) {
            Text("Esta controladora parece: ${s.first}", color = Metal.Text, fontSize = 13.sp, fontWeight = FontWeight.ExtraBold, maxLines = 1, overflow = TextOverflow.Ellipsis)
            Text(s.second, color = Metal.TextMuted, fontSize = 11.sp, maxLines = 2)
            Row(horizontalArrangement = Arrangement.spacedBy(6.dp), modifier = Modifier.height(34.dp)) {
                MetalButton("Usar o mapa pronto ${s.first}", { hub.applySuggestedPreset() }, led = Metal.Success, ledOn = true, modifier = Modifier.width(150.dp).height(34.dp)) {
                    Text("USAR ESTE MAPA", color = Metal.OnMetal, fontSize = 11.sp, fontWeight = FontWeight.ExtraBold, modifier = Modifier.align(Alignment.Center))
                }
                MetalButton("Não usar o mapa sugerido", { hub.dismissSuggestedPreset() }, modifier = Modifier.width(70.dp).height(34.dp)) {
                    Text("NÃO", color = Metal.OnMetal, fontSize = 11.sp, fontWeight = FontWeight.ExtraBold, modifier = Modifier.align(Alignment.Center))
                }
            }
        }
    } else if (u != null) {
        LaunchedEffect(u.key, u.count) { delay(15_000); hub.dismissUnknown() }
        Card(modifier) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(
                    "Controle sem função: ${u.desc}" + (if (u.count > 1) " (${u.count}×)" else "") + ". O que ele faz?",
                    color = Metal.Text, fontSize = 12.sp, fontWeight = FontWeight.Bold, maxLines = 1, overflow = TextOverflow.Ellipsis,
                    modifier = Modifier.weight(1f),
                )
                Text(
                    "✕", color = Metal.TextMuted, fontSize = 16.sp,
                    modifier = Modifier.semantics { role = Role.Button; contentDescription = "Fechar o aviso do controle sem função" }.clickable { hub.dismissUnknown() }.padding(horizontal = 8.dp),
                )
            }
            Row(horizontalArrangement = Arrangement.spacedBy(5.dp), modifier = Modifier.fillMaxWidth().height(34.dp)) {
                for (id in u.suggestions.take(3)) {
                    MetalButton("Este controle é: ${MidiTargets.get(id)?.label ?: id}", { hub.assignKey(id, u.key) }, modifier = Modifier.weight(1f).height(34.dp)) {
                        Text(shortLabel(id), color = Metal.OnMetal, fontSize = 10.sp, fontWeight = FontWeight.ExtraBold, maxLines = 1, overflow = TextOverflow.Ellipsis, modifier = Modifier.align(Alignment.Center).padding(horizontal = 3.dp))
                    }
                }
                MetalButton("Escolher outra função para este controle", { pickFor = u.key }, modifier = Modifier.width(70.dp).height(34.dp)) {
                    Text("OUTRA…", color = Metal.OnMetal, fontSize = 10.sp, fontWeight = FontWeight.ExtraBold, modifier = Modifier.align(Alignment.Center))
                }
                MetalButton("Este controle não tem função (não perguntar mais)", { hub.ignoreKey(u.key) }, modifier = Modifier.width(84.dp).height(34.dp)) {
                    Text("SEM FUNÇÃO", color = Metal.OnMetal, fontSize = 10.sp, fontWeight = FontWeight.ExtraBold, maxLines = 1, modifier = Modifier.align(Alignment.Center))
                }
            }
        }
    }
    pickFor?.let { key -> TargetPicker(onPick = { id -> hub.assignKey(id, key); pickFor = null }, onClose = { pickFor = null }) }
}

@Composable
private fun Card(modifier: Modifier, content: @Composable () -> Unit) {
    Column(
        modifier.clip(RoundedCornerShape(10.dp)).background(Color(0xF2202A33)).padding(horizontal = 10.dp, vertical = 6.dp),
        verticalArrangement = Arrangement.spacedBy(4.dp),
    ) { content() }
}

/** Nome curto de uma função para caber num botão ("HOT CUE 2 · B"). */
fun shortLabel(id: String): String {
    val deck = if (id.length > 2 && id[0] == 'd' && id[2] == '.') " · " + AppViewModel.deckName(id[1].digitToInt()) else ""
    val k = if (deck.isNotEmpty()) id.substring(3) else id
    val name = when {
        k.startsWith("hotdel") -> "APAGAR CUE ${k.substring(6)}"
        k.startsWith("hot") -> "HOT CUE ${k.substring(3)}"
        k.startsWith("loop") && k.substring(4).toIntOrNull() != null -> "LOOP ${k.substring(4)}"
        k.startsWith("pad") -> "PAD ${k.substring(3)}"
        else -> mapOf(
            "play" to "PLAY", "cue" to "CUE", "sync" to "SYNC", "vol" to "VOLUME", "eqhi" to "AGUDOS", "eqmid" to "MÉDIOS",
            "eqlo" to "GRAVES", "filter" to "FILTRO", "tempo" to "PITCH", "pfl" to "FONE", "jog" to "PRATO", "load" to "LOAD",
            "keylock" to "KEY", "loopin" to "LOOP IN", "loopout" to "LOOP OUT", "reloop" to "RELOOP", "bendup" to "BEND +",
            "benddown" to "BEND −", "fxamt" to "FX QTD", "xfade" to "CROSSFADER", "master" to "MASTER", "hpvol" to "VOL. FONE",
            "hpmix" to "MIX FONE", "browse" to "BROWSE (girar)", "browsepush" to "BROWSE (apertar)",
        )[k] ?: (MidiTargets.get(id)?.label?.uppercase() ?: id)
    }
    return name + deck
}

/** Lista de todas as funções, com busca, para ensinar um controle. */
@Composable
fun TargetPicker(onPick: (String) -> Unit, onClose: () -> Unit) {
    var q by remember { mutableStateOf("") }
    val list = remember(q) {
        val k = q.trim().lowercase()
        MidiTargets.all.filter { k.isEmpty() || it.label.lowercase().contains(k) }
    }
    AlertDialog(
        onDismissRequest = onClose,
        title = { Text("O que este controle faz?") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                OutlinedTextField(value = q, onValueChange = { q = it }, singleLine = true, placeholder = { Text("Buscar (ex.: loop, volume, deck B)") })
                LazyColumn(Modifier.heightIn(max = 240.dp), verticalArrangement = Arrangement.spacedBy(2.dp)) {
                    items(list, key = { it.id }) { t ->
                        Text(
                            t.label, color = Metal.Text, fontSize = 14.sp,
                            modifier = Modifier.fillMaxWidth().clip(RoundedCornerShape(6.dp)).background(Color(0xFF22262B))
                                .semantics { role = Role.Button; contentDescription = "Função: ${t.label}" }
                                .clickable { onPick(t.id) }.padding(horizontal = 10.dp, vertical = 9.dp),
                        )
                    }
                }
            }
        },
        confirmButton = { TextButton(onClick = onClose) { Text("CANCELAR") } },
    )
}
