package app.djfusion.ui

import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.border
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.role
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import app.djfusion.data.TrackRow
import app.djfusion.harmony.MixAdvisor
import app.djfusion.harmony.SetTrack
import app.djfusion.ui.theme.Metal

private fun TrackRow.asSet() = SetTrack(id, bpm, key, energy)

/** Linha de uma música com a explicação da técnica de mixagem em relação à referência. */
data class Ranked(val row: TrackRow, val relation: String?, val detail: String?, val good: Int)

/** Ordena a biblioteca pelo assistente de mixagem (melhor combinação primeiro) em relação a [ref]. */
fun rankTracks(tracks: List<TrackRow>, ref: SetTrack?): List<Ranked> {
    if (ref == null) return tracks.map { Ranked(it, null, null, 0) }
    val analyzed = tracks.filter { it.bpm > 0 }
    val sug = MixAdvisor.suggest(ref, analyzed.map { it.asSet() }, limit = analyzed.size)
    val byId = tracks.associateBy { it.id }
    val ranked = sug.mapNotNull { s ->
        byId[s.track.id]?.let { row ->
            val good = when {
                s.score < 1.2 -> 2
                s.score < 3.0 -> 1
                else -> 0
            }
            Ranked(row, s.key.name, listOf(s.bpm.label, s.energyText, s.key.technique).filter { it.isNotEmpty() }.joinToString(" · "), good)
        }
    }
    val rest = tracks.filter { it.bpm <= 0 && it.id != ref.id }.map { Ranked(it, "não analisada", null, 0) }
    return ranked + rest
}

private fun goodColor(g: Int) = when (g) {
    2 -> Metal.Success
    1 -> Metal.Warning
    else -> Color(0xFFFF6B6B)
}

/**
 * Navegador rápido: carrega música num deck sem sair da tela DJ. A lista vem ordenada pelo assistente de
 * mixagem (tom, andamento e energia em relação ao outro deck), com a técnica sugerida em cada linha.
 */
@Composable
fun QuickBrowser(vm: AppViewModel, deck: Int) {
    val tracks by vm.tracks.collectAsStateWithLifecycle()
    val search by vm.search.collectAsStateWithLifecycle()
    val decks by vm.decks.collectAsStateWithLifecycle()
    val name = AppViewModel.deckName(deck)
    val ref = remember(decks) { vm.referenceFor(deck) }
    val ranked = remember(tracks, ref) { rankTracks(tracks, ref) }
    val sel by vm.browseIndex.collectAsStateWithLifecycle()
    val listState = androidx.compose.foundation.lazy.rememberLazyListState()
    // o botão BROWSE da controladora anda nesta lista; LOAD A/B carrega a destacada
    androidx.compose.runtime.LaunchedEffect(ranked) { vm.setBrowseList(ranked.map { it.row.id }) }
    androidx.compose.runtime.LaunchedEffect(sel) { if (sel in ranked.indices) listState.animateScrollToItem(maxOf(0, sel - 2)) }
    val picker = rememberLauncherForActivityResult(ActivityResultContracts.OpenMultipleDocuments()) { uris -> vm.importUris(uris) }
    val folderPicker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocumentTree()) { uri -> if (uri != null) vm.importFolder(uri) }

    Box(
        Modifier.fillMaxSize().background(Color(0xCC000000))
            .clickable { vm.closeBrowser() }
            .semantics { contentDescription = "Fechar o navegador de músicas" },
        contentAlignment = Alignment.Center,
    ) {
        Column(
            Modifier.fillMaxWidth(0.86f).fillMaxHeight(0.92f)
                .clip(RoundedCornerShape(14.dp)).background(Metal.Surface)
                .pointerInput(Unit) { detectTapGestures { } }   // toque no painel não fecha
                .padding(12.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp),
        ) {
            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Text("CARREGAR NO DECK $name", color = deckColor(deck), fontSize = 16.sp, fontWeight = FontWeight.ExtraBold)
                OutlinedTextField(
                    value = search, onValueChange = vm::setSearch, singleLine = true,
                    placeholder = { Text("Buscar", maxLines = 1) }, modifier = Modifier.weight(1f),
                )
                MetalButton("Importar músicas do aparelho (navegador)", { picker.launch(arrayOf("*/*")) }, modifier = Modifier.width(110.dp).height(52.dp)) {
                    Text("IMPORTAR", color = Metal.OnMetal, fontSize = 13.sp, fontWeight = FontWeight.ExtraBold)
                }
                MetalButton("Importar uma pasta (navegador)", { folderPicker.launch(null) }, modifier = Modifier.width(86.dp).height(52.dp)) {
                    Text("PASTA", color = Metal.OnMetal, fontSize = 13.sp, fontWeight = FontWeight.ExtraBold)
                }
                MetalButton("Fechar o navegador", { vm.closeBrowser() }, modifier = Modifier.width(86.dp).height(52.dp)) {
                    Text("FECHAR", color = Metal.OnMetal, fontSize = 13.sp, fontWeight = FontWeight.ExtraBold)
                }
            }
            Text(
                if (ref != null) "Ordenadas pelo assistente de mixagem: as melhores para entrar depois do outro deck aparecem primeiro."
                else "Toque numa música para carregar no deck $name.",
                color = Metal.TextMuted, fontSize = 12.sp,
            )
            if (tracks.isEmpty()) {
                Text("Biblioteca vazia. Toque em IMPORTAR ou PASTA.", color = Metal.Text, fontSize = 15.sp, modifier = Modifier.padding(top = 20.dp))
            }
            LazyColumn(Modifier.fillMaxSize(), state = listState, verticalArrangement = Arrangement.spacedBy(5.dp)) {
                itemsIndexed(ranked, key = { _, r -> r.row.id }) { i, r -> BrowserRow(vm, deck, r, decks[deck].trackId == r.row.id, i == sel) }
            }
        }
    }
}

@Composable
private fun BrowserRow(vm: AppViewModel, deck: Int, r: Ranked, current: Boolean, selected: Boolean) {
    val row = r.row
    Row(
        Modifier.fillMaxWidth().heightIn(min = 54.dp).clip(RoundedCornerShape(9.dp))
            .background(if (current) Color(0xFF3A2020) else Metal.SurfaceRaised)
            .then(if (selected) Modifier.border(2.dp, Metal.DeckA, RoundedCornerShape(9.dp)) else Modifier)
            .semantics { role = Role.Button; contentDescription = "Carregar ${row.title} no deck ${AppViewModel.deckName(deck)} (navegador)" }
            .clickable { vm.loadFromBrowser(deck, row) }
            .padding(horizontal = 12.dp, vertical = 6.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Column(Modifier.weight(1f)) {
            Text(row.title, color = Metal.Text, fontSize = 15.sp, fontWeight = FontWeight.SemiBold, maxLines = 1, overflow = TextOverflow.Ellipsis)
            if (r.relation != null) {
                Text(
                    r.relation + (r.detail?.let { " · $it" } ?: ""),
                    color = goodColor(r.good), fontSize = 11.sp, maxLines = 1, overflow = TextOverflow.Ellipsis,
                )
            } else if (row.artist.isNotEmpty()) {
                Text(row.artist, color = Metal.TextMuted, fontSize = 11.sp, maxLines = 1)
            }
        }
        if (row.energyLevel > 0) Text("E${row.energyLevel}", color = energyColor(row.energyLevel), fontSize = 13.sp, fontWeight = FontWeight.ExtraBold, modifier = Modifier.padding(horizontal = 8.dp))
        KeyChip(row.key, null, small = true)
        Spacer(Modifier.width(8.dp))
        Text(if (row.bpm > 0) String.format(java.util.Locale.ROOT, "%.0f BPM", row.bpm) else "— BPM", color = Metal.Text, fontSize = 13.sp, fontWeight = FontWeight.Bold)
        Spacer(Modifier.width(8.dp))
        Text(formatTime(row.durationMs), color = Metal.TextMuted, fontSize = 12.sp)
    }
}

/** Lista curta de sugestões (painel da biblioteca): as próximas melhores para o deck [deck]. */
@Composable
fun SuggestionList(vm: AppViewModel, deck: Int, tracks: List<TrackRow>, modifier: Modifier = Modifier) {
    val decks by vm.decks.collectAsStateWithLifecycle()
    val ref = remember(decks) { vm.referenceFor(deck) }
    val loadedIds = decks.map { it.trackId }
    val ranked = remember(tracks, ref, loadedIds) {
        if (ref == null) emptyList() else rankTracks(tracks, ref).filter { it.relation != "não analisada" && it.row.id !in loadedIds }.take(4)
    }
    Column(modifier, verticalArrangement = Arrangement.spacedBy(4.dp)) {
        Text("PRÓXIMAS SUGERIDAS (deck ${AppViewModel.deckName(deck)})", color = Metal.TextMuted, fontSize = 10.sp, fontWeight = FontWeight.Bold, letterSpacing = 1.sp)
        if (ref == null) Text("Carregue uma música analisada no outro deck para ver sugestões.", color = Metal.TextMuted, fontSize = 10.sp)
        for (r in ranked) {
            Column(
                Modifier.fillMaxWidth().clip(RoundedCornerShape(6.dp)).background(Metal.SurfaceRaised)
                    .semantics { role = Role.Button; contentDescription = "Sugestão: carregar ${r.row.title} no deck ${AppViewModel.deckName(deck)}" }
                    .clickable { vm.loadTrack(deck, r.row) }
                    .padding(horizontal = 6.dp, vertical = 3.dp),
            ) {
                Text(r.row.title, color = Metal.Text, fontSize = 11.sp, fontWeight = FontWeight.SemiBold, maxLines = 1, overflow = TextOverflow.Ellipsis)
                Text(r.relation ?: "", color = goodColor(r.good), fontSize = 9.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
            }
        }
    }
}


/**
 * Lista de músicas fixa embaixo dos decks (como no VirtualDJ): busca, ordem pelo assistente de mixagem em relação
 * ao deck que está tocando, tom e andamento, e botões A / B para carregar. O BROWSE da controladora anda nela.
 */
@Composable
fun BrowserDock(vm: AppViewModel, modifier: Modifier = Modifier) {
    val tracks by vm.tracks.collectAsStateWithLifecycle()
    val search by vm.search.collectAsStateWithLifecycle()
    val decks by vm.decks.collectAsStateWithLifecycle()
    val sel by vm.browseIndex.collectAsStateWithLifecycle()
    // referência: o deck que está tocando; as sugestões são para o outro
    val target = if (decks[0].playing && !decks[1].playing) 1 else 0
    val ref = remember(decks) { vm.referenceFor(target) }
    val ranked = remember(tracks, ref) { rankTracks(tracks, ref) }
    val listState = androidx.compose.foundation.lazy.rememberLazyListState()
    androidx.compose.runtime.LaunchedEffect(ranked) { vm.setBrowseList(ranked.map { it.row.id }) }
    androidx.compose.runtime.LaunchedEffect(sel) { if (sel in ranked.indices) listState.animateScrollToItem(maxOf(0, sel - 1)) }
    Column(modifier.background(Color(0xFF0E1013)).padding(horizontal = 8.dp, vertical = 4.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Text("♪ LISTA", color = Metal.DeckA, fontSize = 12.sp, fontWeight = FontWeight.ExtraBold)
            androidx.compose.foundation.text.BasicTextField(
                value = search, onValueChange = vm::setSearch, singleLine = true,
                textStyle = androidx.compose.ui.text.TextStyle(color = Metal.Text, fontSize = 13.sp),
                cursorBrush = androidx.compose.ui.graphics.SolidColor(Metal.DeckA),
                modifier = Modifier.weight(1f).clip(RoundedCornerShape(6.dp)).background(Metal.SurfaceRaised)
                    .padding(horizontal = 8.dp, vertical = 5.dp)
                    .semantics { contentDescription = "Buscar na lista fixa" },
                decorationBox = { inner -> Box { if (search.isEmpty()) Text("Buscar música, artista…", color = Metal.TextMuted, fontSize = 13.sp); inner() } },
            )
            Text(
                if (ref != null) "sugestões para o deck ${AppViewModel.deckName(target)}" else "${tracks.size} músicas",
                color = Metal.TextMuted, fontSize = 11.sp, maxLines = 1,
            )
        }
        if (tracks.isEmpty()) Text("Biblioteca vazia. Importe na aba BIBLIOTECA.", color = Metal.TextMuted, fontSize = 12.sp)
        LazyColumn(Modifier.fillMaxSize(), state = listState, verticalArrangement = Arrangement.spacedBy(3.dp)) {
            itemsIndexed(ranked, key = { _, r -> r.row.id }) { i, r ->
                val row = r.row
                Row(
                    Modifier.fillMaxWidth().height(34.dp).clip(RoundedCornerShape(6.dp))
                        .background(if (i == sel) Color(0xFF2A1A1A) else Metal.Surface)
                        .then(if (i == sel) Modifier.border(1.dp, Metal.DeckA, RoundedCornerShape(6.dp)) else Modifier)
                        .padding(start = 8.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                ) {
                    Text(
                        row.title + if (row.artist.isNotEmpty()) "  ·  ${row.artist}" else "",
                        color = Metal.Text, fontSize = 13.sp, maxLines = 1, overflow = TextOverflow.Ellipsis, modifier = Modifier.weight(1f),
                    )
                    if (r.relation != null && r.relation != "não analisada") {
                        Text(r.relation, color = goodColor(r.good), fontSize = 10.sp, maxLines = 1, overflow = TextOverflow.Ellipsis, modifier = Modifier.width(120.dp))
                    }
                    KeyChip(row.key, ref?.key, small = true)
                    Text(if (row.bpm > 0) String.format(java.util.Locale.ROOT, "%.1f", row.bpm) else "—", color = Metal.Text, fontSize = 12.sp, fontWeight = FontWeight.Bold, modifier = Modifier.width(44.dp))
                    Text(formatTime(row.durationMs), color = Metal.TextMuted, fontSize = 11.sp, modifier = Modifier.width(38.dp))
                    for (deck in 0..1) {
                        val loaded = decks[deck].trackId == row.id && decks[deck].loaded
                        Box(
                            Modifier.width(40.dp).fillMaxHeight().clip(RoundedCornerShape(6.dp))
                                .background(if (loaded) deckColor(deck) else Color(0xFF2A2F35))
                                .semantics { role = Role.Button; contentDescription = "Carregar ${row.title} no deck ${AppViewModel.deckName(deck)} (lista fixa)" }
                                .clickable { vm.loadTrack(deck, row) },
                            contentAlignment = Alignment.Center,
                        ) { Text(AppViewModel.deckName(deck), color = if (loaded) Color.White else Metal.Text, fontSize = 14.sp, fontWeight = FontWeight.ExtraBold) }
                    }
                }
            }
        }
    }
}
