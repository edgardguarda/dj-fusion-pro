package app.djfusion.ui

import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.role
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import app.djfusion.data.TrackRow
import app.djfusion.harmony.MixAdvisor
import app.djfusion.harmony.SetTrack
import app.djfusion.ui.theme.Metal

private fun TrackRow.asSet() = SetTrack(id, bpm, key, energy)

/** Linha de uma música com a explicação da técnica de mixagem em relação à referência. */
data class Ranked(val row: TrackRow, val relation: String?, val detail: String?, val good: Int)

/** Ordena a biblioteca pelo assistente de mixagem (melhor combinação primeiro) em relação a [ref]. */
fun rankTracks(tracks: List<TrackRow>, ref: SetTrack?): List<Ranked> {
    if (ref == null) return tracks.map { Ranked(it, null, null, 0) }
    val analyzed = tracks.filter { it.bpm > 0 }
    val sug = MixAdvisor.suggest(ref, analyzed.map { it.asSet() }, limit = analyzed.size)
    val byId = tracks.associateBy { it.id }
    val ranked = sug.mapNotNull { s ->
        byId[s.track.id]?.let { row ->
            val good = when {
                s.score < 1.2 -> 2
                s.score < 3.0 -> 1
                else -> 0
            }
            Ranked(row, s.key.name, listOf(s.bpm.label, s.energyText, s.key.technique).filter { it.isNotEmpty() }.joinToString(" · "), good)
        }
    }
    val rest = tracks.filter { it.bpm <= 0 && it.id != ref.id }.map { Ranked(it, "não analisada", null, 0) }
    return ranked + rest
}

private fun goodColor(g: Int) = when (g) {
    2 -> Metal.Success
    1 -> Metal.Warning
    else -> Color(0xFFFF6B6B)
}

/**
 * Navegador rápido: carrega música num deck sem sair da tela DJ. A lista vem ordenada pelo assistente de
 * mixagem (tom, andamento e energia em relação ao outro deck), com a técnica sugerida em cada linha.
 */
@Composable
fun QuickBrowser(vm: AppViewModel, deck: Int) {
    val tracks by vm.tracks.collectAsStateWithLifecycle()
    val search by vm.search.collectAsStateWithLifecycle()
    val decks by vm.decks.collectAsStateWithLifecycle()
    val name = AppViewModel.deckName(deck)
    val ref = remember(decks) { vm.referenceFor(deck) }
    val ranked = remember(tracks, ref) { rankTracks(tracks, ref) }
    val picker = rememberLauncherForActivityResult(ActivityResultContracts.OpenMultipleDocuments()) { uris -> vm.importUris(uris) }
    val folderPicker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocumentTree()) { uri -> if (uri != null) vm.importFolder(uri) }

    Box(
        Modifier.fillMaxSize().background(Color(0xCC000000))
            .clickable { vm.closeBrowser() }
            .semantics { contentDescription = "Fechar o navegador de músicas" },
        contentAlignment = Alignment.Center,
    ) {
        Column(
            Modifier.fillMaxWidth(0.86f).fillMaxHeight(0.92f)
                .clip(RoundedCornerShape(14.dp)).background(Metal.Surface)
                .pointerInput(Unit) { detectTapGestures { } }   // toque no painel não fecha
                .padding(12.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp),
        ) {
            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Text("CARREGAR NO DECK $name", color = deckColor(deck), fontSize = 16.sp, fontWeight = FontWeight.ExtraBold)
                OutlinedTextField(
                    value = search, onValueChange = vm::setSearch, singleLine = true,
                    placeholder = { Text("Buscar", maxLines = 1) }, modifier = Modifier.weight(1f),
                )
                MetalButton("Importar músicas do aparelho (navegador)", { picker.launch(arrayOf("*/*")) }, modifier = Modifier.width(110.dp).height(52.dp)) {
                    Text("IMPORTAR", color = Metal.OnMetal, fontSize = 13.sp, fontWeight = FontWeight.ExtraBold)
                }
                MetalButton("Importar uma pasta (navegador)", { folderPicker.launch(null) }, modifier = Modifier.width(86.dp).height(52.dp)) {
                    Text("PASTA", color = Metal.OnMetal, fontSize = 13.sp, fontWeight = FontWeight.ExtraBold)
                }
                MetalButton("Fechar o navegador", { vm.closeBrowser() }, modifier = Modifier.width(86.dp).height(52.dp)) {
                    Text("FECHAR", color = Metal.OnMetal, fontSize = 13.sp, fontWeight = FontWeight.ExtraBold)
                }
            }
            Text(
                if (ref != null) "Ordenadas pelo assistente de mixagem: as melhores para entrar depois do outro deck aparecem primeiro."
                else "Toque numa música para carregar no deck $name.",
                color = Metal.TextMuted, fontSize = 12.sp,
            )
            if (tracks.isEmpty()) {
                Text("Biblioteca vazia. Toque em IMPORTAR ou PASTA.", color = Metal.Text, fontSize = 15.sp, modifier = Modifier.padding(top = 20.dp))
            }
            LazyColumn(Modifier.fillMaxSize(), verticalArrangement = Arrangement.spacedBy(5.dp)) {
                items(ranked, key = { it.row.id }) { r -> BrowserRow(vm, deck, r, decks[deck].trackId == r.row.id) }
            }
        }
    }
}

@Composable
private fun BrowserRow(vm: AppViewModel, deck: Int, r: Ranked, current: Boolean) {
    val row = r.row
    Row(
        Modifier.fillMaxWidth().heightIn(min = 54.dp).clip(RoundedCornerShape(9.dp))
            .background(if (current) Color(0xFF3A2020) else Metal.SurfaceRaised)
            .semantics { role = Role.Button; contentDescription = "Carregar ${row.title} no deck ${AppViewModel.deckName(deck)} (navegador)" }
            .clickable { vm.loadFromBrowser(deck, row) }
            .padding(horizontal = 12.dp, vertical = 6.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Column(Modifier.weight(1f)) {
            Text(row.title, color = Metal.Text, fontSize = 15.sp, fontWeight = FontWeight.SemiBold, maxLines = 1, overflow = TextOverflow.Ellipsis)
            if (r.relation != null) {
                Text(
                    r.relation + (r.detail?.let { " · $it" } ?: ""),
                    color = goodColor(r.good), fontSize = 11.sp, maxLines = 1, overflow = TextOverflow.Ellipsis,
                )
            } else if (row.artist.isNotEmpty()) {
                Text(row.artist, color = Metal.TextMuted, fontSize = 11.sp, maxLines = 1)
            }
        }
        if (row.energyLevel > 0) Text("E${row.energyLevel}", color = energyColor(row.energyLevel), fontSize = 13.sp, fontWeight = FontWeight.ExtraBold, modifier = Modifier.padding(horizontal = 8.dp))
        KeyChip(row.key, null, small = true)
        Spacer(Modifier.width(8.dp))
        Text(if (row.bpm > 0) String.format(java.util.Locale.ROOT, "%.0f BPM", row.bpm) else "— BPM", color = Metal.Text, fontSize = 13.sp, fontWeight = FontWeight.Bold)
        Spacer(Modifier.width(8.dp))
        Text(formatTime(row.durationMs), color = Metal.TextMuted, fontSize = 12.sp)
    }
}

/** Lista curta de sugestões (painel da biblioteca): as próximas melhores para o deck [deck]. */
@Composable
fun SuggestionList(vm: AppViewModel, deck: Int, tracks: List<TrackRow>, modifier: Modifier = Modifier) {
    val decks by vm.decks.collectAsStateWithLifecycle()
    val ref = remember(decks) { vm.referenceFor(deck) }
    val ranked = remember(tracks, ref) { if (ref == null) emptyList() else rankTracks(tracks, ref).filter { it.relation != "não analisada" }.take(4) }
    Column(modifier, verticalArrangement = Arrangement.spacedBy(4.dp)) {
        Text("PRÓXIMAS SUGERIDAS (deck ${AppViewModel.deckName(deck)})", color = Metal.TextMuted, fontSize = 10.sp, fontWeight = FontWeight.Bold, letterSpacing = 1.sp)
        if (ref == null) Text("Carregue uma música analisada no outro deck para ver sugestões.", color = Metal.TextMuted, fontSize = 10.sp)
        for (r in ranked) {
            Column(
                Modifier.fillMaxWidth().clip(RoundedCornerShape(6.dp)).background(Metal.SurfaceRaised)
                    .semantics { role = Role.Button; contentDescription = "Sugestão: carregar ${r.row.title} no deck ${AppViewModel.deckName(deck)}" }
                    .clickable { vm.loadTrack(deck, r.row) }
                    .padding(horizontal = 6.dp, vertical = 3.dp),
            ) {
                Text(r.row.title, color = Metal.Text, fontSize = 11.sp, fontWeight = FontWeight.SemiBold, maxLines = 1, overflow = TextOverflow.Ellipsis)
                Text(r.relation ?: "", color = goodColor(r.good), fontSize = 9.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
            }
        }
    }
}
