package app.djfusion.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.State
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import app.djfusion.ui.theme.Metal

/**
 * Tela em pé (retrato): as duas ondas, dois decks compactos (prato, CUE, PLAY, SYNC e pitch) e o mixer
 * essencial (volumes, graves/médios/agudos e crossfader). Para a mesa completa, deite o celular.
 */
@Composable
fun PortraitScreen(vm: AppViewModel) {
    val decks by vm.decks.collectAsStateWithLifecycle()
    val live = vm.live.collectAsStateWithLifecycle()
    val auto by vm.autoDj.state.collectAsStateWithLifecycle()
    val ctx = LocalContext.current
    Column(Modifier.fillMaxSize().background(Metal.Bg)) {
        Row(Modifier.fillMaxWidth().height(48.dp).background(Color(0xFF16191D)).padding(end = 6.dp), verticalAlignment = Alignment.CenterVertically) {
            BrandTitle(markSize = 32.dp)
            Spacer(Modifier.weight(1f))
            MetalButton(
                description = if (auto.active) "AUTO DJ ligado. Toque para parar" else "AUTO DJ: o programa escolhe e mixa as músicas sozinho",
                onPress = { vm.autoDj.toggle() }, led = Metal.Success, ledOn = auto.active,
                modifier = Modifier.width(96.dp).height(36.dp),
            ) { Text("AUTO DJ", color = Metal.OnMetal, fontSize = 12.sp, fontWeight = FontWeight.ExtraBold) }
            Spacer(Modifier.width(6.dp))
            MetalButton(
                description = "Voltar para a tela deitada (mesa completa)",
                onPress = { vm.setPortrait(false, ctx as? android.app.Activity) },
                modifier = Modifier.width(96.dp).height(36.dp),
            ) { Text("DEITAR", color = Metal.OnMetal, fontSize = 12.sp, fontWeight = FontWeight.ExtraBold) }
        }
        for (deck in 0..1) PortraitWave(vm, deck, decks[deck], live)
        PortraitDeck(vm, 0, decks[0], live, Modifier.fillMaxWidth().weight(1f))
        PortraitMixer(vm, decks, Modifier.fillMaxWidth().height(150.dp))
        PortraitDeck(vm, 1, decks[1], live, Modifier.fillMaxWidth().weight(1f))
    }
}

@Composable
private fun PortraitWave(vm: AppViewModel, deck: Int, ui: DeckUi, live: State<LiveUi>) {
    val zoom by vm.waveZoom.collectAsStateWithLifecycle()
    val color = deckColor(deck)
    Column(Modifier.fillMaxWidth().height(78.dp).padding(bottom = 2.dp)) {
        Box(Modifier.fillMaxWidth().weight(1f)) {
            ScrollingWave(
                peaks = ui.wave, position = { live.value.decks[deck].positionFrames },
                bpm = if (ui.hasBpm) ui.bpm else 0.0, firstBeatFrame = ui.firstBeatFrame, hotcues = ui.hotcues,
                cue = { live.value.decks[deck].cueFrames }, deckColor = color,
                viewSeconds = AppViewModel.WAVE_ZOOMS[zoom], modifier = Modifier.fillMaxSize(),
            )
            Text(
                "${AppViewModel.deckName(deck)}  " + if (ui.loaded) ui.title else "vazio · toque em CARREGAR",
                color = Color.White, fontSize = 12.sp, fontWeight = FontWeight.Bold, maxLines = 1, overflow = TextOverflow.Ellipsis,
                modifier = Modifier.align(Alignment.TopStart).padding(4.dp).background(Color(0xAA000000)).padding(horizontal = 4.dp),
            )
        }
        OverviewStrip(
            peaks = ui.wave, position = { live.value.decks[deck].positionFrames }, lengthFrames = ui.lengthFrames,
            deckColor = color, description = "Visão geral do deck ${AppViewModel.deckName(deck)} (retrato)",
            onSeek = { vm.seekFraction(deck, it) }, modifier = Modifier.fillMaxWidth().height(12.dp), hotcues = ui.hotcues,
        )
    }
}

@Composable
private fun PortraitDeck(vm: AppViewModel, deck: Int, ui: DeckUi, live: State<LiveUi>, modifier: Modifier) {
    val name = AppViewModel.deckName(deck)
    val color = deckColor(deck)
    val ready = ui.loaded && !ui.loading
    Row(modifier.brushedSilver().padding(6.dp), horizontalArrangement = Arrangement.spacedBy(6.dp), verticalAlignment = Alignment.CenterVertically) {
        Platter(
            deckColor = color,
            position = { live.value.decks[deck].positionFrames },
            lengthFrames = { ui.lengthFrames },
            modifier = Modifier.fillMaxHeight().width(150.dp),
            onScratch = if (ready) ({ a: Boolean, v: Float -> vm.scratch(deck, a, v) }) else null,
            onBend = if (ready) ({ a: Boolean, v: Float -> vm.jogBend(deck, a, v) }) else null,
            vinyl = { vm.vinyl.value }, playing = { vm.decks.value[deck].playing },
            cue = { live.value.decks[deck].cueFrames },
        ) { EgMark(Modifier.size(42.dp)) }
        Column(Modifier.weight(1f).fillMaxHeight(), verticalArrangement = Arrangement.spacedBy(5.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(
                    if (ui.hasBpm) String.format(java.util.Locale.ROOT, "%.2f", ui.playedBpm) else "—",
                    color = Metal.Text, fontSize = 22.sp, fontWeight = FontWeight.ExtraBold,
                )
                Text("  BPM  ", color = Metal.TextMuted, fontSize = 10.sp)
                KeyChip(ui.shownKey, null, small = true)
                Spacer(Modifier.weight(1f))
                MetalButton("Carregar música no deck $name", { vm.openBrowser(deck) }, modifier = Modifier.width(74.dp).height(30.dp)) {
                    Text("CARREGAR", color = Metal.OnMetal, fontSize = 9.sp, fontWeight = FontWeight.ExtraBold)
                }
            }
            MetalFader(
                value = vm.pitchFaderValue(ui), onChange = { vm.setPitchFader(deck, it) }, accent = color,
                description = "Pitch do deck $name (retrato)", modifier = Modifier.fillMaxWidth().height(34.dp), vertical = false,
            )
            Row(Modifier.fillMaxWidth().weight(1f), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                MetalButton(
                    "Cue do deck $name (retrato)", { vm.cueDown(deck) }, onRelease = { vm.cueUp(deck) }, enabled = ready,
                    led = Color(0xFFFF8A3D), ledOn = ready && !ui.playing, modifier = Modifier.weight(1f).fillMaxHeight(),
                ) { Text("CUE", color = Color(0xFFFF8A3D), fontSize = 15.sp, fontWeight = FontWeight.ExtraBold) }
                MetalButton(
                    if (ui.playing) "Pausar deck $name (retrato)" else "Tocar deck $name (retrato)", { vm.togglePlay(deck) }, enabled = ready,
                    led = Metal.Success, ledOn = ui.playing, modifier = Modifier.weight(1.3f).fillMaxHeight(),
                ) { TransportGlyph(ui.playing, if (ui.playing) Metal.Success else Metal.OnMetal, Modifier.size(24.dp)) }
                MetalButton(
                    "Sync do deck $name (retrato)", { vm.syncButton(deck) }, enabled = ready,
                    led = color, ledOn = ui.syncLock, modifier = Modifier.weight(1f).fillMaxHeight(),
                ) { Text("SYNC", color = Metal.OnMetal, fontSize = 13.sp, fontWeight = FontWeight.ExtraBold) }
            }
        }
    }
}

@Composable
private fun PortraitMixer(vm: AppViewModel, decks: List<DeckUi>, modifier: Modifier) {
    val vols by vm.volumes.collectAsStateWithLifecycle()
    val xf by vm.crossfader.collectAsStateWithLifecycle()
    Column(modifier.brushedBlack().padding(horizontal = 8.dp, vertical = 4.dp)) {
        Row(Modifier.fillMaxWidth().weight(1f), verticalAlignment = Alignment.CenterVertically) {
            for (deck in 0..1) {
                val name = AppViewModel.deckName(deck)
                val color = deckColor(deck)
                if (deck == 1) Spacer(Modifier.weight(1f))
                MetalFader(
                    value = vols[deck], onChange = { vm.setVolume(deck, it) }, accent = color, fill = true,
                    description = "Volume do deck $name (retrato)", modifier = Modifier.width(36.dp).fillMaxHeight(),
                )
                for ((band, label) in listOf(2 to "AGU", 1 to "MÉD", 0 to "GRA")) {
                    Column(horizontalAlignment = Alignment.CenterHorizontally, modifier = Modifier.padding(horizontal = 2.dp)) {
                        Knob(
                            decks[deck].eq[band], { vm.setEq(deck, band, it) }, color,
                            "Equalizador $label do deck $name (retrato)", Modifier.size(40.dp),
                        )
                        Text(label, color = Metal.TextMuted, fontSize = 9.sp)
                    }
                }
            }
        }
        MetalFader(
            value = xf, onChange = vm::setCrossfader, accent = Color(0xFFE6E9EC),
            description = "Crossfader (retrato)", modifier = Modifier.fillMaxWidth().height(36.dp), vertical = false,
        )
    }
}
