package app.djfusion.ui

import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import app.djfusion.ui.theme.Metal

/**
 * Tela AUTO DJ: o que está tocando, a próxima música com a nota de compatibilidade e o porquê, a transição
 * planejada, alternativas (troca com um toque), TOCAR PASTA (sozinho do começo ao fim) e os ajustes:
 * modo, estilo, duração, energia, tom automático, andamento e anti-choque de vozes.
 */
@Composable
fun AutoDjScreen(vm: AppViewModel) {
    Row(Modifier.fillMaxSize().background(Metal.Bg).padding(12.dp), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
        AutoDjNow(vm, Modifier.weight(1.05f).fillMaxHeight())
        AutoDjSettings(vm, Modifier.weight(1f).fillMaxHeight())
    }
}

@Composable
private fun AutoDjNow(vm: AppViewModel, modifier: Modifier) {
    val auto by vm.autoDj.state.collectAsStateWithLifecycle()
    val plan by vm.autoDj.plan.collectAsStateWithLifecycle()
    val decks by vm.decks.collectAsStateWithLifecycle()
    val folderPick = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocumentTree()) { uri -> if (uri != null) vm.autoDjFolder(uri) }
    Column(modifier.verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(10.dp)) {
        Panel("AUTO DJ") {
            Row(Modifier.fillMaxWidth().height(48.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                MetalButton(if (auto.active) "Parar o AUTO DJ" else "Ligar o AUTO DJ", { vm.autoDj.toggle() }, led = Metal.Success, ledOn = auto.active, modifier = Modifier.weight(1f).fillMaxHeight()) {
                    Text(if (auto.active) "PARAR" else "LIGAR", color = Metal.OnMetal, fontSize = 14.sp, fontWeight = FontWeight.ExtraBold, modifier = Modifier.align(Alignment.Center))
                }
                MetalButton("Mixar agora: AUTO DJ começa a transição no próximo compasso", { vm.autoDj.mixNow() }, enabled = auto.active, modifier = Modifier.weight(1.2f).fillMaxHeight()) {
                    Text("MIXAR AGORA", color = Metal.OnMetal, fontSize = 12.sp, fontWeight = FontWeight.ExtraBold, maxLines = 1, modifier = Modifier.align(Alignment.Center))
                }
                MetalButton("Tocar uma pasta inteira com o AUTO DJ, sozinho", { folderPick.launch(null) }, led = Metal.DeckA, ledOn = plan.source.startsWith("pasta"), modifier = Modifier.weight(1.2f).fillMaxHeight()) {
                    Text("TOCAR PASTA", color = Metal.OnMetal, fontSize = 12.sp, fontWeight = FontWeight.ExtraBold, maxLines = 1, modifier = Modifier.align(Alignment.Center))
                }
            }
            Text(
                if (auto.active) auto.status.ifEmpty { "Ligado." } else "Desligado. LIGAR usa a biblioteca (ou a playlist/ordem HARMONIZAR). TOCAR PASTA: escolha uma pasta e ele toca e mixa tudo sozinho.",
                color = if (auto.active) Metal.Success else Metal.TextMuted, fontSize = 12.sp, maxLines = 3,
            )
            Text("Fonte: ${plan.source}", color = Metal.TextMuted, fontSize = 11.sp)
        }
        val playing = decks.firstOrNull { it.playing }
        Panel("PRÓXIMA TRANSIÇÃO") {
            val n = plan.next
            if (n == null) {
                Text("Quando o AUTO DJ estiver ligado, aqui aparece a próxima música, a nota de compatibilidade e como ele vai mixar.", color = Metal.TextMuted, fontSize = 12.sp)
            } else {
                Text("Tocando: ${playing?.title ?: "—"}", color = Metal.TextMuted, fontSize = 12.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(n.row.title, color = Metal.Text, fontSize = 16.sp, fontWeight = FontWeight.ExtraBold, maxLines = 1, overflow = TextOverflow.Ellipsis, modifier = Modifier.weight(1f))
                    CompatBadge(n.compat)
                }
                Text(n.why, color = Metal.Text, fontSize = 12.sp)
                Text("Transição: ${plan.style} · ${plan.beats} batidas · batidas travadas (sync) do começo ao fim", color = Metal.TextMuted, fontSize = 12.sp)
                Row(Modifier.fillMaxWidth().height(44.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    MetalButton("Trocar a próxima música pela melhor alternativa", { vm.autoDj.skipNext() }, enabled = auto.active && plan.alternatives.isNotEmpty(), modifier = Modifier.weight(1f).fillMaxHeight()) {
                        Text("TROCAR PRÓXIMA", color = Metal.OnMetal, fontSize = 11.sp, fontWeight = FontWeight.ExtraBold, maxLines = 1, modifier = Modifier.align(Alignment.Center))
                    }
                    val inc = plan.incoming
                    MetalButton("Ouvir a próxima no fone antes de entrar", { if (inc in 0..1) vm.toggleHeadphoneCue(inc) }, enabled = inc in 0..1, led = Metal.Warning, ledOn = inc in 0..1 && decks[inc].cueOn, modifier = Modifier.weight(1f).fillMaxHeight()) {
                        Text("OUVIR NO FONE", color = Metal.OnMetal, fontSize = 11.sp, fontWeight = FontWeight.ExtraBold, maxLines = 1, modifier = Modifier.align(Alignment.Center))
                    }
                }
                Text("OUVIR NO FONE usa a pré-escuta: só funciona com fone separado (controladora com saída de fone ou modo dividido). No alto-falante a pré-escuta sairia junto com o som geral.", color = Metal.TextMuted, fontSize = 10.sp)
            }
        }
        if (plan.alternatives.isNotEmpty()) Panel("ALTERNATIVAS") {
            for (a in plan.alternatives) {
                Row(Modifier.fillMaxWidth().height(46.dp).clip(RoundedCornerShape(8.dp)).background(Color(0xFF22262B)).padding(start = 10.dp), verticalAlignment = Alignment.CenterVertically) {
                    Column(Modifier.weight(1f)) {
                        Text(a.row.title, color = Metal.Text, fontSize = 13.sp, fontWeight = FontWeight.SemiBold, maxLines = 1, overflow = TextOverflow.Ellipsis)
                        Text(a.why, color = Metal.TextMuted, fontSize = 10.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
                    }
                    CompatBadge(a.compat)
                    MetalButton("Usar ${a.row.title} como próxima", { vm.autoDj.useAlternative(a.row.id) }, enabled = auto.active, modifier = Modifier.width(70.dp).fillMaxHeight().padding(3.dp)) {
                        Text("USAR", color = Metal.OnMetal, fontSize = 11.sp, fontWeight = FontWeight.ExtraBold, modifier = Modifier.align(Alignment.Center))
                    }
                }
            }
        }
    }
}

@Composable
private fun CompatBadge(compat: Int) {
    val c = when { compat >= 80 -> Metal.Success; compat >= 60 -> Metal.Warning; else -> Color(0xFFFF6B6B) }
    Box(Modifier.padding(horizontal = 6.dp).clip(RoundedCornerShape(6.dp)).background(c.copy(alpha = 0.18f)).padding(horizontal = 8.dp, vertical = 3.dp)) {
        Text("$compat%", color = c, fontSize = 13.sp, fontWeight = FontWeight.ExtraBold)
    }
}

@Composable
private fun AutoDjSettings(vm: AppViewModel, modifier: Modifier) {
    val a = vm.autoDj
    val mode by a.mode.collectAsStateWithLifecycle()
    val style by a.styleChoice.collectAsStateWithLifecycle()
    val beats by a.beatsChoice.collectAsStateWithLifecycle()
    val autoKey by a.autoKey.collectAsStateWithLifecycle()
    val keepTempo by a.keepTempo.collectAsStateWithLifecycle()
    val anti by a.antiClash.collectAsStateWithLifecycle()
    val em by a.energyMode.collectAsStateWithLifecycle()
    val learned by a.learned.collectAsStateWithLifecycle()
    Column(modifier.verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(10.dp)) {
        Panel("MODO") {
            for (row in a.modes.indices.chunked(4)) Row(Modifier.fillMaxWidth().height(38.dp), horizontalArrangement = Arrangement.spacedBy(5.dp)) {
                for (i in row) MetalButton("Modo do AUTO DJ: ${a.modes[i].name}", { a.setMode(i) }, led = Metal.Success, ledOn = mode == i, modifier = Modifier.weight(1f).fillMaxHeight()) {
                    Text(a.modes[i].name, color = Metal.OnMetal, fontSize = 9.sp, fontWeight = FontWeight.ExtraBold, maxLines = 1, softWrap = false, modifier = Modifier.align(Alignment.Center))
                }
                for (k in row.size until 4) Box(Modifier.weight(1f))
            }
            Text(a.modes[mode].desc, color = Metal.Text, fontSize = 12.sp)
            if (a.modes[mode].name == "PERSONALIZADO") {
                val w by a.weights.collectAsStateWithLifecycle()
                for ((i, label) in listOf("ANDAMENTO", "TOM", "ENERGIA", "GÊNERO").withIndex()) {
                    Text("$label: peso ${"%.1f".format(java.util.Locale.ROOT, w[i])}", color = Metal.Text, fontSize = 12.sp)
                    MetalFader(value = w[i] / 3f, onChange = { a.setWeight(i, it * 3f) }, accent = Metal.DeckA, description = "Peso de $label na escolha do AUTO DJ", modifier = Modifier.fillMaxWidth().height(30.dp), vertical = false)
                }
            }
        }
        Panel("TRANSIÇÃO") {
            val styles = listOf("PELO MODO", "GRAVES (EQ)", "FILTRO", "ECO", "STEMS (VOZES)", "CORTE SECO", "FADE", "SEM MIXAGEM", "REVERB", "LOOP", "DROP")
            for (row in styles.indices.chunked(4)) Row(Modifier.fillMaxWidth().height(36.dp), horizontalArrangement = Arrangement.spacedBy(5.dp)) {
                for (i in row) MetalButton("Transição do AUTO DJ: ${styles[i]}", { a.setStyleChoice(i) }, led = Metal.Success, ledOn = style == i, modifier = Modifier.weight(1f).fillMaxHeight()) {
                    Text(styles[i], color = Metal.OnMetal, fontSize = 9.sp, fontWeight = FontWeight.ExtraBold, maxLines = 1, softWrap = false, modifier = Modifier.align(Alignment.Center))
                }
                for (k in row.size until 4) Box(Modifier.weight(1f))
            }
            Text("DURAÇÃO (batidas)", color = Metal.TextMuted, fontSize = 10.sp, fontWeight = FontWeight.Bold)
            Row(Modifier.fillMaxWidth().height(36.dp), horizontalArrangement = Arrangement.spacedBy(5.dp)) {
                for ((label, v) in listOf("AUTO" to 0, "4" to 4, "8" to 8, "16" to 16, "32" to 32, "64" to 64)) {
                    MetalButton("Duração da transição do AUTO DJ: $label", { a.setBeatsChoice(v) }, led = Metal.Success, ledOn = beats == v, modifier = Modifier.weight(1f).fillMaxHeight()) {
                        Text(label, color = Metal.OnMetal, fontSize = 11.sp, fontWeight = FontWeight.ExtraBold, maxLines = 1, modifier = Modifier.align(Alignment.Center))
                    }
                }
            }
            Text("Sem compatibilidade de tom ou andamento, ele usa uma transição segura (eco) em vez de forçar.", color = Metal.TextMuted, fontSize = 11.sp)
        }
        Panel("ENERGIA DA NOITE") {
            val names = AutoDj.ENERGY_PROFILES
            for (row in names.indices.chunked(4)) Row(Modifier.fillMaxWidth().height(36.dp), horizontalArrangement = Arrangement.spacedBy(5.dp)) {
                for (v in row) {
                    MetalButton("Curva de energia do AUTO DJ: ${names[v]}", { a.setEnergyMode(v) }, led = Metal.Success, ledOn = em == v, modifier = Modifier.weight(1f).fillMaxHeight()) {
                        Text(names[v], color = Metal.OnMetal, fontSize = 10.sp, fontWeight = FontWeight.ExtraBold, maxLines = 1, softWrap = false, modifier = Modifier.align(Alignment.Center))
                    }
                }
                for (k in row.size until 4) Box(Modifier.weight(1f))
            }
            if (names.getOrNull(em) == "PERSONALIZADO") {
                val t by a.energyTarget.collectAsStateWithLifecycle()
                Text("Energia desejada: ${1 + Math.round(t * 9f)} de 10", color = Metal.Text, fontSize = 12.sp)
                MetalFader(value = t, onChange = { a.setEnergyTarget(it) }, accent = Metal.DeckA, description = "Energia desejada do AUTO DJ", modifier = Modifier.fillMaxWidth().height(30.dp), vertical = false)
            }
            Text(
                "LIVRE segue a música atual. PROGRESSIVO aquece até o pico, ONDAS sobe e respira, FECHAR desce para o fim da noite; " +
                    "os outros mantêm a pista no nível escolhido. A energia escolhe as MÚSICAS (nunca mexe no volume). " +
                    "Os modos ENERGIA, FESTA, LOUNGE e PROGRESSIVO de cima têm a curva própria.",
                color = Metal.TextMuted, fontSize = 11.sp,
            )
        }
        Panel("INTELIGÊNCIA") {
            MetalButton("AUTO DJ ajusta o tom da música que entra quando os tons chocam", { a.toggleAutoKey() }, led = Metal.Success, ledOn = autoKey, modifier = Modifier.fillMaxWidth().height(40.dp)) {
                Text("TOM AUTOMÁTICO: ${if (autoKey) "LIGADO" else "DESLIGADO"}", color = Metal.OnMetal, fontSize = 11.sp, fontWeight = FontWeight.ExtraBold, maxLines = 1, modifier = Modifier.align(Alignment.Center))
            }
            MetalButton("AUTO DJ mantém o andamento entre as músicas", { a.toggleKeepTempo() }, led = Metal.Success, ledOn = keepTempo, modifier = Modifier.fillMaxWidth().height(40.dp)) {
                Text(if (keepTempo) "ANDAMENTO: MANTÉM" else "ANDAMENTO: VOLTA A 0% DEVAGAR", color = Metal.OnMetal, fontSize = 11.sp, fontWeight = FontWeight.ExtraBold, maxLines = 1, modifier = Modifier.align(Alignment.Center))
            }
            MetalButton("Anti-choque de vozes: com stems prontos, só uma voz toca por vez na transição", { a.toggleAntiClash() }, led = Metal.Success, ledOn = anti, modifier = Modifier.fillMaxWidth().height(40.dp)) {
                Text("ANTI-CHOQUE DE VOZES: ${if (anti) "LIGADO" else "DESLIGADO"}", color = Metal.OnMetal, fontSize = 11.sp, fontWeight = FontWeight.ExtraBold, maxLines = 1, modifier = Modifier.align(Alignment.Center))
            }
            Text("Anti-choque precisa dos stems prontos nas duas músicas (o app separa sozinho ao carregar, até 30 min).", color = Metal.TextMuted, fontSize = 11.sp)
            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Text("Aprendizado: $learned troca(s) lembrada(s)", color = Metal.Text, fontSize = 12.sp, modifier = Modifier.weight(1f))
                MetalButton("Esquecer o aprendizado do AUTO DJ", { a.forgetLearning() }, enabled = learned > 0, modifier = Modifier.width(120.dp).height(38.dp)) {
                    Text("ESQUECER", color = Metal.OnMetal, fontSize = 11.sp, fontWeight = FontWeight.ExtraBold, modifier = Modifier.align(Alignment.Center))
                }
            }
            Text("Pontos de mixagem: hot cue 7 = onde a música ENTRA, hot cue 8 = onde ela SAI. O AUTO DJ respeita os seus pontos.", color = Metal.TextMuted, fontSize = 11.sp)
        }
    }
}
