package app.djfusion.ui.theme

// Gerado a partir de replica/design/tokens.json. Mudou o token, mude aqui.
// O nome do pacote é provisório e muda no /replica-brand.

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Typography
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.staticCompositionLocalOf
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.em
import androidx.compose.ui.unit.sp

object Metal {
    val Bg = Color(0xFF09090A)
    val Surface = Color(0xFF151618)
    val SurfaceRaised = Color(0xFF222326)
    val Border = Color(0xFF3A3C40)
    val BorderInput = Color(0xFF7C8791)
    val Text = Color(0xFFE6E9EC)
    val TextMuted = Color(0xFF9AA4AE)
    var DeckA by mutableStateOf(Color(0xFFFF2A2A))       // LED vermelho (muda com a SKIN)
    val OnDeckA = Color(0xFFFFFFFF)
    var DeckB by mutableStateOf(Color(0xFF2F9BFF))       // deck B azul (A vermelho): como no Serato, um deck de cada cor
    val OnDeckB = Color(0xFFFFFFFF)
    val MetalLight = Color(0xFFD5DADF)
    val MetalMid = Color(0xFFA9B1B9)
    val MetalDark = Color(0xFF6B747D)
    val OnMetal = Color(0xFFE8EAED)    // texto sobre os botões escuros
    /** SKINS: pares de cores dos decks A e B. */
    val SKIN_NAMES = listOf("CLÁSSICA", "VERDE E ROXO", "LARANJA E CIANO", "AMARELO E ROSA")
    private val SKIN_COLORS = listOf(
        Color(0xFFFF2A2A) to Color(0xFF2F9BFF), Color(0xFF3DDC84) to Color(0xFFB36BFF),
        Color(0xFFFF8A1F) to Color(0xFF22D3EE), Color(0xFFFFD21F) to Color(0xFFFF4FA3),
    )
    fun applySkin(i: Int) { val c = SKIN_COLORS[i.coerceIn(0, SKIN_COLORS.lastIndex)]; DeckA = c.first; DeckB = c.second }
    val Danger = Color(0xFFFF6B6B)
    val Success = Color(0xFF4CD08A)
    val Warning = Color(0xFFFFD166)
    val WaveLow = Color(0xFFFF3B30)
    val WaveMid = Color(0xFFC9CDD2)
    val WaveHigh = Color(0xFFFFFFFF)

    /** Alumínio escovado: faixas horizontais claras e escuras. A textura fina é desenhada no Canvas. */
    val BrushedPlate = Brush.verticalGradient(
        listOf(
            Color(0xFFD5DADF), Color(0xFFA9B1B9), Color(0xFFC4CAD0),
            Color(0xFF8F979F), Color(0xFFB8BFC6),
        )
    )
    val GraphitePanel = Brush.verticalGradient(
        listOf(Color(0xFF2B3036), Color(0xFF1C2025), Color(0xFF262B31))
    )
}

object Dim {
    val TouchMin = 48.dp
    val Button = 56.dp
    val Pad = 72.dp
    val FaderHandle = 64.dp
    val Sm = 6.dp
    val Md = 10.dp
    val Lg = 16.dp
}

val LocalDeckColors = staticCompositionLocalOf { Metal.DeckA to Metal.DeckB }

private val Scheme = darkColorScheme(
    background = Metal.Bg,
    surface = Metal.Surface,
    surfaceVariant = Metal.SurfaceRaised,
    outline = Metal.BorderInput,
    outlineVariant = Metal.Border,
    onBackground = Metal.Text,
    onSurface = Metal.Text,
    onSurfaceVariant = Metal.TextMuted,
    primary = Metal.DeckA,
    onPrimary = Metal.OnDeckA,
    secondary = Metal.DeckB,
    onSecondary = Metal.OnDeckB,
    error = Metal.Danger,
)

// Fontes Inter e JetBrains Mono (OFL) entram em res/font na fase de construção.
private val Type = Typography(
    // estilo padrão de Text: altura de linha proporcional ao tamanho (textos pequenos não ocupam linha de 24sp)
    bodyLarge = TextStyle(fontSize = 16.sp, lineHeight = 1.25.em, fontWeight = FontWeight.Normal),
    labelSmall = TextStyle(fontSize = 12.sp, lineHeight = 16.sp, fontWeight = FontWeight.SemiBold),
    bodyMedium = TextStyle(fontSize = 14.sp, lineHeight = 20.sp, fontWeight = FontWeight.Normal),
    titleMedium = TextStyle(fontSize = 16.sp, lineHeight = 22.sp, fontWeight = FontWeight.SemiBold),
    headlineSmall = TextStyle(fontSize = 20.sp, lineHeight = 26.sp, fontWeight = FontWeight.Bold),
    headlineMedium = TextStyle(fontSize = 28.sp, lineHeight = 32.sp, fontWeight = FontWeight.Bold),
    displaySmall = TextStyle(fontSize = 40.sp, lineHeight = 44.sp, fontWeight = FontWeight.Bold),
)

/** O app é sempre escuro: o metal brilha melhor sobre grafite e a cena de DJ costuma ser escura. */
@Composable
fun DjFusionTheme(content: @Composable () -> Unit) {
    MaterialTheme(colorScheme = Scheme, typography = Type, content = content)
}
