package app.djfusion.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.semantics
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import app.djfusion.ui.theme.Metal

/** Pads de amostras escolhidas automaticamente a partir das músicas dos decks. */
@Composable
fun SamplerScreen(vm: AppViewModel) {
    val pads by vm.pads.collectAsStateWithLifecycle()
    val vol by vm.samplerVol.collectAsStateWithLifecycle()
    var tab by remember { mutableIntStateOf(0) }
    Row(Modifier.fillMaxSize().background(Metal.Bg).padding(14.dp)) {
        Column(Modifier.weight(1f).fillMaxHeight(), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Row(Modifier.fillMaxWidth().height(36.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                MetalButton(
                    description = "Mostrar os 16 pads do sampler", onPress = { tab = 0 },
                    led = Metal.DeckA, ledOn = tab == 0, modifier = Modifier.weight(1f).fillMaxHeight(),
                ) { Text("16 PADS", color = Metal.OnMetal, fontSize = 13.sp, fontWeight = FontWeight.ExtraBold, modifier = Modifier.align(Alignment.Center)) }
                MetalButton(
                    description = "Mostrar o sequenciador de bateria", onPress = { tab = 1 },
                    led = Metal.DeckB, ledOn = tab == 1, modifier = Modifier.weight(1f).fillMaxHeight(),
                ) { Text("SEQUENCIADOR DE BATERIA", color = Metal.OnMetal, fontSize = 13.sp, fontWeight = FontWeight.ExtraBold, modifier = Modifier.align(Alignment.Center)) }
            }
            if (tab == 1) { DrumSequencer(vm, pads); return@Column }
            for (row in 0..3) {
                Row(Modifier.weight(1f), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    for (col in 0..3) {
                        val i = row * 4 + col
                        val p = pads[i]
                        MetalButton(
                            description = if (p.ready) "Pad ${i + 1}: ${p.label}" else "Pad ${i + 1} vazio",
                            onPress = { vm.padPress(i) },
                            enabled = p.ready,
                            led = Metal.DeckA, ledOn = p.playing,
                            modifier = Modifier.weight(1f).fillMaxHeight(),
                        ) {
                            Column(horizontalAlignment = Alignment.CenterHorizontally, modifier = Modifier.align(Alignment.Center).padding(2.dp)) {
                                Text("${i + 1}", color = Metal.OnMetal, fontSize = 16.sp, fontWeight = FontWeight.ExtraBold)
                                Text(
                                    if (p.ready) p.label else "vazio",
                                    color = Metal.OnMetal, fontSize = 11.sp, fontWeight = FontWeight.Bold, textAlign = TextAlign.Center,
                                )
                                if (p.ready) Text(if (p.loop) "LOOP" else "1 VEZ", color = Metal.TextMuted, fontSize = 10.sp)
                            }
                        }
                    }
                }
            }
        }
        Column(Modifier.width(150.dp).fillMaxHeight().padding(start = 14.dp), horizontalAlignment = Alignment.CenterHorizontally) {
            MetalButton(
                description = "Escolher sozinho os melhores trechos das músicas dos decks",
                onPress = { vm.buildSamples() },
                led = Metal.Success, ledOn = pads.any { it.ready },
                modifier = Modifier.weight(1f).fillMaxWidth(),
            ) { Text("GERAR\nAMOSTRAS", color = Metal.OnMetal, fontSize = 14.sp, fontWeight = FontWeight.ExtraBold, textAlign = TextAlign.Center, modifier = Modifier.align(Alignment.Center)) }
            Spacer(Modifier.height(8.dp))
            MetalButton(
                description = "Sons prontos de DJ nos pads",
                onPress = { vm.loadBuiltinPads() },
                modifier = Modifier.weight(0.6f).fillMaxWidth(),
            ) { Text("SONS\nPRONTOS", color = Metal.OnMetal, fontSize = 12.sp, fontWeight = FontWeight.ExtraBold, textAlign = TextAlign.Center, modifier = Modifier.align(Alignment.Center)) }
            Spacer(Modifier.height(8.dp))
            MetalButton(
                description = "Limpar os pads",
                onPress = { vm.clearSamples() },
                modifier = Modifier.weight(0.6f).fillMaxWidth(),
            ) { Text("LIMPAR", color = Metal.OnMetal, fontSize = 13.sp, fontWeight = FontWeight.ExtraBold, modifier = Modifier.align(Alignment.Center)) }
            Spacer(Modifier.height(8.dp))
            Text("VOLUME", color = Metal.TextMuted, fontSize = 11.sp, fontWeight = FontWeight.Bold)
            Knob(vol, { vm.setSamplerVolume(it) }, Metal.DeckA, "Volume das amostras", Modifier.size(64.dp), centered = false)
            val mic by vm.mic.collectAsStateWithLifecycle()
            Text("MICROFONE", color = Metal.TextMuted, fontSize = 11.sp, fontWeight = FontWeight.Bold, modifier = Modifier.padding(top = 4.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(6.dp), verticalAlignment = Alignment.CenterVertically) {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Knob(mic.gain / 2f, { vm.setMicGain(it * 2f) }, Metal.DeckB, "Volume do microfone", Modifier.size(46.dp), centered = false)
                    Text("VOLUME", color = Metal.TextMuted, fontSize = 11.sp)
                }
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Knob(mic.talkAmount / 0.9f, { vm.setTalkAmount(it * 0.9f) }, Metal.DeckB, "Talkover: quanto a música abaixa quando você fala", Modifier.size(46.dp), centered = false)
                    Text("TALKOVER", color = Metal.TextMuted, fontSize = 11.sp)
                }
            }
            Text(
                "Pads 1–4 = deck A ou C, 5–8 = deck B ou D, 9–16 = sons e bateria prontos. Ligue o MIC na tela DJ.",
                color = Metal.TextMuted, fontSize = 11.sp, textAlign = TextAlign.Center, modifier = Modifier.padding(top = 2.dp),
            )
        }
    }
}

/**
 * Sequenciador de bateria: 4 linhas × 16 passos (um compasso). Cada linha toca um pad do sampler; toque no nome
 * da linha para trocar o som. Segue o andamento do deck que está tocando ou o BPM escolhido aqui.
 */
@Composable
private fun DrumSequencer(vm: AppViewModel, pads: List<PadUi>) {
    val q by vm.seq.collectAsStateWithLifecycle()
    Column(Modifier.fillMaxSize(), verticalArrangement = Arrangement.spacedBy(6.dp)) {
        Row(Modifier.fillMaxWidth().height(40.dp), horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically) {
            MetalButton(
                description = if (q.playing) "Parar o sequenciador de bateria" else "Tocar o sequenciador de bateria",
                onPress = { vm.seqToggle() }, led = Metal.Success, ledOn = q.playing,
                modifier = Modifier.weight(1.2f).fillMaxHeight(),
            ) { Text(if (q.playing) "■ PARAR" else "▶ TOCAR", color = Metal.OnMetal, fontSize = 14.sp, fontWeight = FontWeight.ExtraBold, modifier = Modifier.align(Alignment.Center)) }
            MetalButton(
                description = "Seguir o andamento do deck que está tocando (ligado: ${q.followDeck})",
                onPress = { vm.seqFollowDeck() }, led = Metal.DeckA, ledOn = q.followDeck,
                modifier = Modifier.weight(1.2f).fillMaxHeight(),
            ) { Text("SEGUIR DECK", color = Metal.OnMetal, fontSize = 12.sp, fontWeight = FontWeight.ExtraBold, modifier = Modifier.align(Alignment.Center)) }
            MetalButton(
                description = "Diminuir o BPM do sequenciador", onPress = { vm.seqSetBpm(q.bpm - 1f) },
                modifier = Modifier.weight(0.5f).fillMaxHeight(),
            ) { Text("−", color = Metal.OnMetal, fontSize = 18.sp, fontWeight = FontWeight.ExtraBold, modifier = Modifier.align(Alignment.Center)) }
            Text(String.format(java.util.Locale.ROOT, "%.0f BPM", q.bpm), color = Metal.OnMetal, fontSize = 14.sp, fontWeight = FontWeight.Bold, modifier = Modifier.weight(0.9f), textAlign = TextAlign.Center)
            MetalButton(
                description = "Aumentar o BPM do sequenciador", onPress = { vm.seqSetBpm(q.bpm + 1f) },
                modifier = Modifier.weight(0.5f).fillMaxHeight(),
            ) { Text("+", color = Metal.OnMetal, fontSize = 18.sp, fontWeight = FontWeight.ExtraBold, modifier = Modifier.align(Alignment.Center)) }
            MetalButton(
                description = "Colocar um ritmo base pronto no sequenciador", onPress = { vm.seqPreset() },
                modifier = Modifier.weight(1f).fillMaxHeight(),
            ) { Text("RITMO BASE", color = Metal.OnMetal, fontSize = 12.sp, fontWeight = FontWeight.ExtraBold, modifier = Modifier.align(Alignment.Center)) }
            MetalButton(
                description = "Apagar todos os passos do sequenciador", onPress = { vm.seqClear() },
                modifier = Modifier.weight(0.8f).fillMaxHeight(),
            ) { Text("LIMPAR", color = Metal.OnMetal, fontSize = 12.sp, fontWeight = FontWeight.ExtraBold, modifier = Modifier.align(Alignment.Center)) }
        }
        for (r in 0 until AppViewModel.SEQ_ROWS) {
            val slot = q.slots[r]
            Row(Modifier.fillMaxWidth().weight(1f), horizontalArrangement = Arrangement.spacedBy(4.dp), verticalAlignment = Alignment.CenterVertically) {
                MetalButton(
                    description = "Som da linha ${r + 1}: ${pads.getOrNull(slot)?.label ?: "vazio"}. Toque para trocar pelo próximo pad.",
                    onPress = { vm.seqNextSound(r) },
                    modifier = Modifier.width(96.dp).fillMaxHeight(),
                ) {
                    Text(
                        pads.getOrNull(slot)?.takeIf { it.ready }?.label ?: "pad ${slot + 1}",
                        color = Metal.OnMetal, fontSize = 11.sp, fontWeight = FontWeight.ExtraBold, textAlign = TextAlign.Center, maxLines = 2,
                        modifier = Modifier.align(Alignment.Center).padding(2.dp),
                    )
                }
                for (st in 0 until 16) {
                    val on = (q.steps[r] shr st) and 1 == 1
                    val here = q.step == st
                    val base = if (st / 4 % 2 == 0) Color(0xFF2A2F36) else Color(0xFF353B44)
                    Box(
                        Modifier.weight(1f).fillMaxHeight().padding(vertical = 2.dp)
                            .clip(RoundedCornerShape(6.dp))
                            .background(if (on) (if (here) Color(0xFFFFFFFF) else Metal.DeckA) else if (here) Color(0xFF5A6470) else base)
                            .semantics { contentDescription = "Linha ${r + 1}, passo ${st + 1}: ${if (on) "ligado" else "desligado"}" }
                            .clickable(role = Role.Button) { vm.seqToggleStep(r, st) },
                    )
                }
            }
        }
        Text("Cada quadrado é 1/16 de compasso. Os quatro primeiros são o 1º tempo.", color = Metal.TextMuted, fontSize = 11.sp)
    }
}
