package app.djfusion.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import app.djfusion.ui.theme.Metal

/** Pads de amostras escolhidas automaticamente a partir das músicas dos decks. */
@Composable
fun SamplerScreen(vm: AppViewModel) {
    val pads by vm.pads.collectAsStateWithLifecycle()
    val vol by vm.samplerVol.collectAsStateWithLifecycle()
    Row(Modifier.fillMaxSize().background(Metal.Bg).padding(14.dp)) {
        Column(Modifier.weight(1f).fillMaxHeight(), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            for (row in 0..1) {
                Row(Modifier.weight(1f), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    for (col in 0..3) {
                        val i = row * 4 + col
                        val p = pads[i]
                        MetalButton(
                            description = if (p.ready) "Pad ${i + 1}: ${p.label}" else "Pad ${i + 1} vazio",
                            onPress = { vm.padPress(i) },
                            enabled = p.ready,
                            led = Metal.DeckA, ledOn = p.playing,
                            modifier = Modifier.weight(1f).fillMaxHeight(),
                        ) {
                            Column(horizontalAlignment = Alignment.CenterHorizontally, modifier = Modifier.align(Alignment.Center).padding(6.dp)) {
                                Text("${i + 1}", color = Metal.OnMetal, fontSize = 20.sp, fontWeight = FontWeight.ExtraBold)
                                Text(
                                    if (p.ready) p.label else "vazio",
                                    color = Metal.OnMetal, fontSize = 11.sp, fontWeight = FontWeight.Bold, textAlign = TextAlign.Center,
                                )
                                if (p.ready) Text(if (p.loop) "LOOP · liga e desliga" else "TOCA UMA VEZ", color = Metal.OnMetal, fontSize = 11.sp)
                            }
                        }
                    }
                }
            }
        }
        Column(Modifier.width(150.dp).fillMaxHeight().padding(start = 14.dp), horizontalAlignment = Alignment.CenterHorizontally) {
            MetalButton(
                description = "Escolher sozinho os melhores trechos das músicas dos decks",
                onPress = { vm.buildSamples() },
                led = Metal.Success, ledOn = pads.any { it.ready },
                modifier = Modifier.weight(1f).fillMaxWidth(),
            ) { Text("GERAR\nAMOSTRAS", color = Metal.OnMetal, fontSize = 14.sp, fontWeight = FontWeight.ExtraBold, textAlign = TextAlign.Center, modifier = Modifier.align(Alignment.Center)) }
            Spacer(Modifier.height(8.dp))
            MetalButton(
                description = "Sons prontos de DJ nos pads",
                onPress = { vm.loadBuiltinPads() },
                modifier = Modifier.weight(0.6f).fillMaxWidth(),
            ) { Text("SONS\nPRONTOS", color = Metal.OnMetal, fontSize = 12.sp, fontWeight = FontWeight.ExtraBold, textAlign = TextAlign.Center, modifier = Modifier.align(Alignment.Center)) }
            Spacer(Modifier.height(8.dp))
            MetalButton(
                description = "Limpar os pads",
                onPress = { vm.clearSamples() },
                modifier = Modifier.weight(0.6f).fillMaxWidth(),
            ) { Text("LIMPAR", color = Metal.OnMetal, fontSize = 13.sp, fontWeight = FontWeight.ExtraBold, modifier = Modifier.align(Alignment.Center)) }
            Spacer(Modifier.height(8.dp))
            Text("VOLUME", color = Metal.TextMuted, fontSize = 11.sp, fontWeight = FontWeight.Bold)
            Knob(vol, { vm.setSamplerVolume(it) }, Metal.DeckA, "Volume das amostras", Modifier.size(64.dp), centered = false)
            val mic by vm.mic.collectAsStateWithLifecycle()
            Text("MICROFONE", color = Metal.TextMuted, fontSize = 11.sp, fontWeight = FontWeight.Bold, modifier = Modifier.padding(top = 4.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(6.dp), verticalAlignment = Alignment.CenterVertically) {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Knob(mic.gain / 2f, { vm.setMicGain(it * 2f) }, Metal.DeckB, "Volume do microfone", Modifier.size(46.dp), centered = false)
                    Text("VOLUME", color = Metal.TextMuted, fontSize = 11.sp)
                }
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Knob(mic.talkAmount / 0.9f, { vm.setTalkAmount(it * 0.9f) }, Metal.DeckB, "Talkover: quanto a música abaixa quando você fala", Modifier.size(46.dp), centered = false)
                    Text("TALKOVER", color = Metal.TextMuted, fontSize = 11.sp)
                }
            }
            Text(
                "Pads 1–4 = deck A ou C, 5–8 = deck B ou D. Ligue o MIC na tela DJ.",
                color = Metal.TextMuted, fontSize = 11.sp, textAlign = TextAlign.Center, modifier = Modifier.padding(top = 2.dp),
            )
        }
    }
}
