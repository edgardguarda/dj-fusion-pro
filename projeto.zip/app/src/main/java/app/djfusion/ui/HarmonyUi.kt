package app.djfusion.ui

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.drawText
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.rememberTextMeasurer
import androidx.compose.ui.unit.sp
import androidx.compose.ui.unit.dp
import app.djfusion.harmony.Camelot
import app.djfusion.harmony.MusicalKey
import kotlin.math.cos
import kotlin.math.min
import kotlin.math.sin

/** Cor de uma casa da Roda de Camelot (cada número tem o seu matiz; menor = A mais escuro, maior = B mais claro). */
fun camelotColor(key: MusicalKey): Color {
    val sat = if (key.minor) 0.55f else 0.65f
    val value = if (key.minor) 0.78f else 0.95f
    return Color.hsv(Camelot.hue(key.number), sat, value)
}

private fun compatColor(a: MusicalKey, b: MusicalKey): Color = when (Camelot.distance(a, b)) {
    0, 1 -> Color(0xFF4CD08A)
    2 -> Color(0xFFFFD166)
    else -> Color(0xFFFF6B6B)
}

/**
 * Etiqueta da tonalidade no estilo Camelot ("8A"). Com [other] mostra a compatibilidade na borda:
 * verde = combina bem, amarela = aceitável, vermelha = choca.
 */
object DisplayPrefs {
    /** Tom em letras (Am, F#) em vez de Camelot (8A). */
    var keyLetters by androidx.compose.runtime.mutableStateOf(false)
    /** Visor do deck mostra o tempo que falta em vez do tocado. */
    var remaining by androidx.compose.runtime.mutableStateOf(false)
    /** Cor das ondas: 0 vermelho, 1 cinza, 2 espectro, 3 azul gelo, 4 âmbar. */
    var waveStyle by androidx.compose.runtime.mutableStateOf(0)
    /** Desenho das ondas: 0 RGB (cor pelo espectro), 1 3 BANDAS (graves/médios/agudos em camadas), 2 CONTORNO. */
    var waveType by androidx.compose.runtime.mutableStateOf(0)
}

@Composable
fun KeyChip(key: MusicalKey?, other: MusicalKey?, modifier: Modifier = Modifier, small: Boolean = false, guess: MusicalKey? = null) {
    val shape = RoundedCornerShape(6.dp)
    var m = modifier
    if (key != null && other != null) m = m.border(2.dp, compatColor(key, other), shape)
    Box(
        m.background(if (key != null) camelotColor(key) else Color(0xFF2A2C30), shape)
            .padding(horizontal = if (small) 5.dp else 8.dp, vertical = if (small) 2.dp else 3.dp),
        contentAlignment = Alignment.Center,
    ) {
        Text(
            key?.let { if (DisplayPrefs.keyLetters) it.letter else it.code }
                ?: guess?.let { (if (DisplayPrefs.keyLetters) it.letter else it.code) + "?" } ?: "—",
            color = if (key != null) Color(0xFF101114) else Color(0xFF9AA4AE),
            fontSize = if (small) 11.sp else 13.sp, fontWeight = FontWeight.ExtraBold,
        )
    }
}

/**
 * A Roda de Camelot: anel de fora = tons maiores (B), de dentro = menores (A), do 1 ao 12 em sentido horário
 * com o 12 no topo. As casas dos tons que estão nos decks ganham um contorno; as compatíveis com [ref] ficam acesas.
 */
@Composable
fun CamelotWheel(deckKeys: List<MusicalKey?>, ref: MusicalKey?, modifier: Modifier = Modifier) {
    val measurer = rememberTextMeasurer()
    Canvas(modifier) {
        val d = min(size.width, size.height)
        val c = Offset(size.width / 2f, size.height / 2f)
        val outerR = d / 2f - 2.dp.toPx()
        val ringW = outerR * 0.30f
        val gap = 2.dp.toPx()
        for (number in 1..12) {
            // ângulo central da casa: 12 no topo, sentido horário
            val center = ((number % 12) * 30f) - 90f
            for (minor in booleanArrayOf(false, true)) {
                val key = keyFromCamelot(number, minor)
                val rOut = if (minor) outerR - ringW - gap else outerR
                val mid = rOut - ringW / 2f
                // brilho pela técnica: mesmo tom/relativa/quinta = aceso, boost/diagonal = médio, choque = apagado
                val score = if (ref == null) 0.0 else app.djfusion.harmony.MixAdvisor.keyRelation(ref, key).keyScore
                val base = camelotColor(key)
                val col = when {
                    score <= 0.6 -> base
                    score <= 1.4 -> base.copy(alpha = 0.70f)
                    score <= 2.0 -> base.copy(alpha = 0.42f)
                    else -> base.copy(alpha = 0.14f)
                }
                val tl = Offset(c.x - mid, c.y - mid)
                drawArc(
                    col, center - 14f, 28f, false, tl, Size(mid * 2, mid * 2),
                    style = Stroke(ringW, cap = androidx.compose.ui.graphics.StrokeCap.Butt),
                )
                if (deckKeys.any { it != null && it.number == number && it.minor == minor }) {
                    drawArc(
                        Color.White, center - 14f, 28f, false, Offset(c.x - rOut + 1.dp.toPx(), c.y - rOut + 1.dp.toPx()),
                        Size((rOut - 1.dp.toPx()) * 2, (rOut - 1.dp.toPx()) * 2), style = Stroke(2.5f.dp.toPx()),
                    )
                }
                val ang = Math.toRadians(center.toDouble())
                val tx = c.x + (cos(ang) * mid).toFloat()
                val ty = c.y + (sin(ang) * mid).toFloat()
                val text = "$number${if (minor) "A" else "B"}"
                val layout = measurer.measure(text, TextStyle(fontSize = 9.sp, fontWeight = FontWeight.Bold, color = Color(0xFF101114)))
                drawText(layout, topLeft = Offset(tx - layout.size.width / 2f, ty - layout.size.height / 2f))
            }
        }
    }
}

/** Tonalidade a partir da casa da roda. */
fun keyFromCamelot(number: Int, minor: Boolean): MusicalKey {
    // maior com número n: posição nas quintas f = n - 8 (8B = Dó); a nota é f*7 mod 12 (7 é o inverso de 7 mod 12)
    val fifths = ((number - 8) % 12 + 12) % 12
    val majorTonic = (fifths * 7) % 12
    return if (minor) MusicalKey((majorTonic + 9) % 12, true) else MusicalKey(majorTonic, false)
}
