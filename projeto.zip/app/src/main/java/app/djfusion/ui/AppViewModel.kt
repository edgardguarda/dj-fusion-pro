package app.djfusion.ui

import android.app.Application
import android.content.Intent
import android.media.MediaMetadataRetriever
import android.net.Uri
import android.provider.OpenableColumns
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import app.djfusion.audio.DecodeResult
import app.djfusion.audio.NativeEngine
import app.djfusion.audio.TrackDecoder
import app.djfusion.midi.MidiHub
import app.djfusion.data.Analysis
import app.djfusion.data.LibraryDb
import app.djfusion.data.SortOrder
import app.djfusion.data.TrackRow
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

/** Parte do deck que muda pouco (carregar, tocar, parar). */
data class DeckUi(
    val trackId: Long = -1,
    val title: String = "",
    val artist: String = "",
    val loaded: Boolean = false,
    val playing: Boolean = false,
    val loading: Boolean = false,
    val loadProgress: Float = 0f,
    val lengthFrames: Long = 0,
    val wave: ByteArray? = null,
    /** Andamento da faixa original (0 = não detectado) e onde cai a primeira batida. */
    val bpm: Double = 0.0,
    val firstBeatFrame: Long = 0,
    val bpmConfidence: Float = 0f,
    /** Velocidade de reprodução (1 = normal). O andamento tocado é bpm x rate. */
    val rate: Float = 1f,
    /** 0 = sem loop, senão o tamanho do loop em batidas. */
    val loopBeats: Int = 0,
    /** Hot cues: quadro de cada uma das 4 posições, -1 quando vazia. */
    val hotcues: List<Long> = listOf(-1L, -1L, -1L, -1L),
    /** Equalizador graves, médios, agudos (0,5 = neutro) e filtro (0,5 = desligado). */
    val eq: List<Float> = listOf(0.5f, 0.5f, 0.5f),
    val filter: Float = 0.5f,
    /** Efeito do deck: 0 desligado, 1 eco, 2 flanger, 3 reverb, e a mistura de 0 a 1. */
    val fxType: Int = 0,
    val fxAmount: Float = 0.5f,
) {
    val hasBpm: Boolean get() = bpm > 0.0 && bpmConfidence >= AppViewModel.MIN_BPM_CONFIDENCE
    val playedBpm: Double get() = bpm * rate
}

/** Parte que muda ~30 vezes por segundo (posição e nível). Fica separada para não redesenhar tudo. */
data class DeckLive(
    val positionFrames: Long = 0,
    val cueFrames: Long = 0,
    val peak: Float = 0f,
)

data class LiveUi(
    val decks: List<DeckLive> = listOf(DeckLive(), DeckLive()),
    val masterPeak: Float = 0f,
)

class AppViewModel(app: Application) : AndroidViewModel(app) {
    private val db = LibraryDb(app)

    private val _decks = MutableStateFlow(listOf(DeckUi(), DeckUi()))
    val decks: StateFlow<List<DeckUi>> = _decks.asStateFlow()

    private val _live = MutableStateFlow(LiveUi())
    val live: StateFlow<LiveUi> = _live.asStateFlow()

    private val _volumes = MutableStateFlow(listOf(1f, 1f))
    val volumes: StateFlow<List<Float>> = _volumes.asStateFlow()
    private val _crossfader = MutableStateFlow(0.5f)
    val crossfader: StateFlow<Float> = _crossfader.asStateFlow()
    private val _master = MutableStateFlow(0.8f)
    val master: StateFlow<Float> = _master.asStateFlow()

    private val _message = MutableStateFlow<String?>(null)
    val message: StateFlow<String?> = _message.asStateFlow()

    private val _audioStatus = MutableStateFlow("Áudio desligado")
    val audioStatus: StateFlow<String> = _audioStatus.asStateFlow()

    val search = MutableStateFlow("")
    val sort = MutableStateFlow(SortOrder.RECENT)
    private val libraryVersion = MutableStateFlow(0)

    val tracks: StateFlow<List<TrackRow>> =
        combine(search, sort, libraryVersion) { s, o, _ -> s to o }
            .map { (s, o) -> withContext(Dispatchers.IO) { db.query(s, o) } }
            .stateIn(viewModelScope, SharingStarted.Eagerly, emptyList())

    private val decodeJobs = arrayOfNulls<Job>(2)

    private var foreground = true

    /** Controladoras MIDI USB (Numark etc.). Os controles aprendidos chegam em [onMidi]. */
    val midi = MidiHub(app) { id, v -> onMidi(id, v) }

    private fun onMidi(id: String, v: Float) {
        if (id == "xfade") { setCrossfader(v); return }
        if (id == "master") { setMaster(v); return }
        val deck = id[1].digitToInt()
        val k = id.substring(3)
        when {
            k == "play" -> togglePlay(deck)
            k == "cue" -> cue(deck)
            k == "sync" -> sync(deck)
            k == "vol" -> setVolume(deck, v)
            k == "eqhi" -> setEq(deck, 2, v)
            k == "eqmid" -> setEq(deck, 1, v)
            k == "eqlo" -> setEq(deck, 0, v)
            k == "filter" -> setFilter(deck, v)
            k == "tempo" -> setPitchFader(deck, v)
            k == "fxamt" -> setFxAmount(deck, v)
            k == "fxeco" -> setFx(deck, 1)
            k == "fxflg" -> setFx(deck, 2)
            k == "fxrev" -> setFx(deck, 3)
            k.startsWith("hot") -> hotcue(deck, k.substring(3).toInt() - 1)
            k.startsWith("loop") -> toggleLoop(deck, k.substring(4).toInt())
        }
    }
    private var stopJob: Job? = null

    init {
        midi.start()
        // O motor C++ vive no processo, não na Activity: se a tela foi fechada e reaberta sem o processo
        // morrer, ele ainda guarda as faixas e o estado de tocar da vez anterior. Começamos do zero.
        for (d in 0..1) {
            NativeEngine.nativeUnload(d)
            NativeEngine.nativeSetRate(d, 1f)
            NativeEngine.nativeSetFilter(d, 0.5f)
            NativeEngine.nativeSetFx(d, 0, 0.5f, 0.5f)
            NativeEngine.nativeClearLoop(d)
            for (b in 0..2) NativeEngine.nativeSetEq(d, b, 0.5f)
        }
        startPolling()
    }

    /**
     * Chamado pela Activity em onStart (true) e onStop (false). Sem serviço em primeiro plano o Android
     * não garante áudio em segundo plano, então ao sair o app pausa os decks e fecha a saída de áudio.
     */
    fun onForeground(on: Boolean) {
        foreground = on
        stopJob?.cancel()
        if (on) {
            startAudio()
        } else {
            NativeEngine.nativePause(0)
            NativeEngine.nativePause(1)
            stopJob = viewModelScope.launch(Dispatchers.Default) {
                delay(150) // deixa a rampa de 4 ms da pausa terminar antes de fechar o fluxo
                if (!foreground) NativeEngine.nativeStop()
            }
        }
    }

    private fun startAudio() {
        // Abrir o fluxo exclusivo do Oboe pode demorar: fora da thread principal.
        viewModelScope.launch(Dispatchers.Default) {
            val ok = NativeEngine.nativeStart()
            if (ok) {
                NativeEngine.nativeSetMaster(_master.value)
                NativeEngine.nativeSetCrossfader(_crossfader.value)
                NativeEngine.nativeSetVolume(0, _volumes.value[0])
                NativeEngine.nativeSetVolume(1, _volumes.value[1])
                val info = IntArray(4)
                NativeEngine.nativeStreamInfo(info)
                val bufferMs = if (info[0] > 0) info[2] * 1000f / info[0] else 0f
                _audioStatus.value = "%d Hz · buffer %.0f ms".format(java.util.Locale.ROOT, info[0], bufferMs)
            } else {
                _audioStatus.value = "Sem áudio"
                say("Não consegui abrir a saída de áudio do aparelho.")
            }
        }
    }

    private fun startPolling() {
        viewModelScope.launch {
            val buf = LongArray(4)
            var tick = 0
            while (isActive) {
                if (!foreground) {
                    delay(250)
                    continue
                }
                val states = ArrayList<LongArray>(2)
                val lives = ArrayList<DeckLive>(2)
                for (d in 0..1) {
                    NativeEngine.nativeDeckState(d, buf)
                    states.add(buf.copyOf())
                    lives.add(DeckLive(buf[1], buf[2], NativeEngine.nativeDeckPeak(d)))
                }
                _live.value = LiveUi(lives, NativeEngine.nativeMasterPeak())
                _decks.update { list ->
                    list.mapIndexed { i, d ->
                        val flags = states[i][0]
                        val playing = (flags and 2L) != 0L
                        val loaded = (flags and 1L) != 0L
                        if (d.playing == playing && d.loaded == loaded) d else d.copy(playing = playing, loaded = loaded)
                    }
                }
                if (++tick % 30 == 0) launch(Dispatchers.Default) { NativeEngine.nativeCollectGarbage() }
                delay(33)
            }
        }
    }

    // ----------------------------------------------------------------- mensagens

    fun say(text: String) {
        _message.value = text
    }

    fun clearMessage(text: String) {
        _message.update { if (it == text) null else it }
    }

    // ------------------------------------------------------------------- decks

    fun togglePlay(deck: Int) {
        if (_decks.value[deck].loading) {
            say("Espere a música terminar de carregar no deck ${deckName(deck)}.")
            return
        }
        val st = LongArray(4)
        NativeEngine.nativeDeckState(deck, st)
        if ((st[0] and 1L) == 0L) {
            say("Deck ${deckName(deck)} sem música. Abra a Biblioteca e toque em ${deckName(deck)}.")
            return
        }
        if ((st[0] and 2L) != 0L) NativeEngine.nativePause(deck) else NativeEngine.nativePlay(deck)
    }

    fun cue(deck: Int) = NativeEngine.nativeCue(deck)

    fun seekFraction(deck: Int, fraction: Float) {
        val length = _decks.value[deck].lengthFrames
        if (length <= 0) return
        NativeEngine.nativeSeek(deck, (fraction.coerceIn(0f, 1f) * length).toLong())
    }

    fun setVolume(deck: Int, v: Float) {
        _volumes.update { list -> list.mapIndexed { i, old -> if (i == deck) v else old } }
        NativeEngine.nativeSetVolume(deck, v)
    }

    fun setCrossfader(x: Float) {
        _crossfader.value = x
        NativeEngine.nativeSetCrossfader(x)
    }

    fun setMaster(v: Float) {
        _master.value = v
        NativeEngine.nativeSetMaster(v)
    }

    // ------------------------------------------------- equalizador, filtro e pitch

    private fun snapCenter(v: Float): Float = if (kotlin.math.abs(v - 0.5f) < 0.03f) 0.5f else v.coerceIn(0f, 1f)

    fun setEq(deck: Int, band: Int, v: Float) {
        val x = snapCenter(v)
        setDeck(deck) { d -> d.copy(eq = d.eq.mapIndexed { i, old -> if (i == band) x else old }) }
        NativeEngine.nativeSetEq(deck, band, x)
    }

    fun setFilter(deck: Int, v: Float) {
        val x = snapCenter(v)
        setDeck(deck) { it.copy(filter = x) }
        NativeEngine.nativeSetFilter(deck, x)
    }

    /** Posição do fader de pitch (0 a 1, 0,5 = velocidade normal) para a velocidade. */
    fun setPitchFader(deck: Int, fader: Float) {
        val f = if (kotlin.math.abs(fader - 0.5f) < 0.015f) 0.5f else fader.coerceIn(0f, 1f)
        applyRate(deck, PITCH_MIN + (PITCH_MAX - PITCH_MIN) * f)
    }

    private fun applyRate(deck: Int, rate: Float) {
        setDeck(deck) { it.copy(rate = rate) }
        NativeEngine.nativeSetRate(deck, rate)
        pushFx(deck)
    }

    /** Liga o efeito [type] (toque de novo no mesmo para desligar). */
    fun setFx(deck: Int, type: Int) {
        val cur = _decks.value[deck].fxType
        setDeck(deck) { it.copy(fxType = if (cur == type) 0 else type) }
        pushFx(deck)
    }

    fun setFxAmount(deck: Int, v: Float) {
        setDeck(deck) { it.copy(fxAmount = v.coerceIn(0f, 1f)) }
        pushFx(deck)
    }

    /** Envia o efeito ao motor; o eco acompanha a batida do que está tocando. */
    private fun pushFx(deck: Int) {
        val d = _decks.value[deck]
        val beat = if (d.hasBpm) (60.0 / d.playedBpm).toFloat() else 0.5f
        NativeEngine.nativeSetFx(deck, d.fxType, d.fxAmount, beat)
    }

    /** Dobra ou divide por 2 o andamento detectado (a detecção pode errar por uma oitava). */
    fun scaleBpm(deck: Int, factor: Double) {
        setDeck(deck) { it.copy(bpm = (it.bpm * factor).coerceIn(30.0, 300.0)) }
        pushFx(deck)
        val d = _decks.value[deck]
        if (d.trackId >= 0 && d.bpm > 0) {
            viewModelScope.launch(Dispatchers.IO) { db.saveAnalysis(d.trackId, Analysis(d.bpm, d.firstBeatFrame, d.bpmConfidence)) }
        }
    }

    private fun posMod(a: Double, m: Double): Double = ((a % m) + m) % m

    /**
     * SYNC: iguala o andamento tocado deste deck ao do outro e, se o outro está tocando, alinha também a batida.
     * Só funciona com andamento detectado nos dois. Não é um SYNC contínuo: se o andamento oscilar, refaça.
     */
    fun sync(deck: Int) {
        val me = _decks.value[deck]
        val other = _decks.value[1 - deck]
        val name = deckName(deck)
        if (!me.loaded || !other.loaded) { say("SYNC precisa de música nos dois decks."); return }
        if (!me.hasBpm || !other.hasBpm) { say("SYNC precisa do andamento detectado nos dois decks."); return }
        val targetBpm = other.playedBpm
        var factor = 1.0
        var best = Double.MAX_VALUE
        for (k in doubleArrayOf(1.0, 2.0, 0.5)) {
            val r = targetBpm / (me.bpm * k)
            if (r in PITCH_MIN.toDouble()..PITCH_MAX.toDouble() && kotlin.math.abs(r - 1.0) < best) {
                best = kotlin.math.abs(r - 1.0)
                factor = k
            }
        }
        if (best == Double.MAX_VALUE) {
            say("Andamentos muito diferentes (%.1f e %.1f BPM). Ajuste o pitch à mão.".format(java.util.Locale.ROOT, me.bpm, targetBpm))
            return
        }
        applyRate(deck, (targetBpm / (me.bpm * factor)).toFloat())
        var aligned = false
        if (factor == 1.0 && other.playing) {
            val a = LongArray(4); val b = LongArray(4)
            NativeEngine.nativeDeckState(deck, a); NativeEngine.nativeDeckState(1 - deck, b)
            val sr = NativeEngine.SAMPLE_RATE.toDouble()
            val otherBeat = 60.0 * sr / other.bpm
            val myBeat = 60.0 * sr / me.bpm
            val phase = posMod(b[1] - other.firstBeatFrame.toDouble(), otherBeat) / otherBeat
            val cur = posMod(a[1] - me.firstBeatFrame.toDouble(), myBeat)
            var delta = phase * myBeat - cur
            if (delta > myBeat / 2) delta -= myBeat else if (delta < -myBeat / 2) delta += myBeat
            val target = (a[1] + delta).toLong().coerceIn(0L, (me.lengthFrames - 1).coerceAtLeast(0L))
            NativeEngine.nativeSeek(deck, target)
            aligned = true
        }
        say("Deck $name em %.1f BPM%s.".format(java.util.Locale.ROOT, targetBpm, if (aligned) ", batida alinhada" else ""))
    }

    // ------------------------------------------------------------- loops e hot cues

    fun toggleLoop(deck: Int, beats: Int) {
        val d = _decks.value[deck]
        if (!d.loaded) return
        if (d.loopBeats == beats) {
            NativeEngine.nativeClearLoop(deck)
            setDeck(deck) { it.copy(loopBeats = 0) }
            return
        }
        if (!d.hasBpm) { say("Loop por batidas precisa do andamento detectado."); return }
        val st = LongArray(4)
        NativeEngine.nativeDeckState(deck, st)
        val beat = 60.0 * NativeEngine.SAMPLE_RATE / d.bpm
        val first = d.firstBeatFrame.toDouble()
        val start = kotlin.math.max(0.0, first + kotlin.math.floor((st[1] - first) / beat) * beat)
        val end = start + beats * beat
        if (end > d.lengthFrames) { say("Perto demais do fim da música para esse loop."); return }
        NativeEngine.nativeSetLoop(deck, start.toLong(), end.toLong())
        setDeck(deck) { it.copy(loopBeats = beats) }
    }

    /** Toque numa hot cue vazia grava a posição atual. Numa gravada, vai até ela e toca. */
    fun hotcue(deck: Int, slot: Int) {
        val d = _decks.value[deck]
        if (!d.loaded || d.loading || d.trackId < 0 || slot !in 0..3) return
        val saved = d.hotcues[slot]
        if (saved < 0) {
            val st = LongArray(4)
            NativeEngine.nativeDeckState(deck, st)
            val frame = st[1]
            setDeck(deck) { it.copy(hotcues = it.hotcues.mapIndexed { i, old -> if (i == slot) frame else old }) }
            val id = d.trackId
            viewModelScope.launch(Dispatchers.IO) { db.setHotcue(id, slot, frame) }
        } else {
            NativeEngine.nativeSeek(deck, saved)
            if (!d.playing) NativeEngine.nativePlay(deck)
        }
    }

    fun clearHotcue(deck: Int, slot: Int) {
        val d = _decks.value[deck]
        if (d.trackId < 0 || slot !in 0..3 || d.hotcues[slot] < 0) return
        setDeck(deck) { it.copy(hotcues = it.hotcues.mapIndexed { i, old -> if (i == slot) -1L else old }) }
        val id = d.trackId
        viewModelScope.launch(Dispatchers.IO) { db.deleteHotcue(id, slot) }
        say("Hot cue ${slot + 1} apagada.")
    }

    // ------------------------------------------------------------ carregar faixa

    fun loadTrack(deck: Int, row: TrackRow) {
        val current = _decks.value[deck]
        if (current.playing) {
            say("Pause o deck ${deckName(deck)} antes de carregar outra música.")
            return
        }
        decodeJobs[deck]?.cancel()
        setDeck(deck) { it.copy(loading = true, loadProgress = 0f, title = row.title, artist = row.artist) }
        say("Carregando no deck ${deckName(deck)}…")
        decodeJobs[deck] = viewModelScope.launch {
            val result = TrackDecoder.decode(getApplication(), Uri.parse(row.uri)) { p ->
                setDeck(deck) { it.copy(loadProgress = p) }
            }
            when (result) {
                is DecodeResult.Ready -> {
                    val frames = NativeEngine.nativeTrackFrames(result.trackHandle)
                    val wave = NativeEngine.nativeTrackPeaks(result.trackHandle)
                    val ok = NativeEngine.nativeLoad(deck, result.trackHandle)
                    var analysis = Analysis(0.0, 0L, 0f)
                    var hot = listOf(-1L, -1L, -1L, -1L)
                    if (ok) {
                        say("Analisando o andamento…")
                        withContext(Dispatchers.Default) {
                            android.os.Process.setThreadPriority(android.os.Process.THREAD_PRIORITY_BACKGROUND)
                            val cached = db.analysis(row.id)
                            analysis = cached ?: run {
                                val out = DoubleArray(3)
                                NativeEngine.nativeAnalyze(result.trackHandle, out)
                                Analysis(out[0], out[1].toLong(), out[2].toFloat()).also { db.saveAnalysis(row.id, it) }
                            }
                            hot = db.hotcues(row.id)
                        }
                    }
                    NativeEngine.nativeFreeTrack(result.trackHandle)
                    if (ok) {
                        NativeEngine.nativeSetRate(deck, 1f)
                        setDeck(deck) {
                            it.copy(
                                trackId = row.id, title = row.title, artist = row.artist, loading = false,
                                loadProgress = 1f, lengthFrames = frames, wave = wave,
                                bpm = analysis.bpm, firstBeatFrame = analysis.firstBeatFrame,
                                bpmConfidence = analysis.confidence, rate = 1f, loopBeats = 0, hotcues = hot,
                            )
                        }
                        say("${row.title} pronta no deck ${deckName(deck)}.")
                    } else {
                        setDeck(deck) { it.copy(loading = false, title = current.title, artist = current.artist) }
                        say("O motor de áudio recusou a faixa.")
                    }
                }
                is DecodeResult.Failed -> {
                    setDeck(deck) { it.copy(loading = false, title = current.title, artist = current.artist) }
                    say(result.reason)
                }
            }
        }
    }

    private fun setDeck(deck: Int, change: (DeckUi) -> DeckUi) {
        _decks.update { list -> list.mapIndexed { i, d -> if (i == deck) change(d) else d } }
    }

    // ---------------------------------------------------------------- biblioteca

    fun setSearch(text: String) {
        search.value = text
    }

    fun setSort(order: SortOrder) {
        sort.value = order
    }

    fun removeFromLibrary(row: TrackRow) {
        viewModelScope.launch(Dispatchers.IO) {
            db.delete(row.id)
            libraryVersion.update { it + 1 }
        }
    }

    fun importUris(uris: List<Uri>) {
        if (uris.isEmpty()) return
        viewModelScope.launch(Dispatchers.IO) {
            var added = 0
            var duplicated = 0
            var invalid = 0
            for (uri in uris) {
                try {
                    getApplication<Application>().contentResolver
                        .takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION)
                } catch (_: Exception) {
                    // nem todo provedor oferece permissão persistente
                }
                val meta = readMetadata(uri)
                if (meta == null) {
                    invalid++
                } else if (db.insert(uri.toString(), meta.title, meta.artist, meta.durationMs)) {
                    added++
                } else {
                    duplicated++
                }
            }
            libraryVersion.update { it + 1 }
            val parts = ArrayList<String>()
            if (added > 0) parts.add("$added adicionada(s)")
            if (duplicated > 0) parts.add("$duplicated já estava(m) na biblioteca")
            if (invalid > 0) parts.add("$invalid não é/são áudio")
            say(parts.joinToString(" · "))
        }
    }

    private class Meta(val title: String, val artist: String, val durationMs: Long)

    private fun readMetadata(uri: Uri): Meta? {
        val ctx = getApplication<Application>()
        val r = MediaMetadataRetriever()
        try {
            r.setDataSource(ctx, uri)
            if (r.extractMetadata(MediaMetadataRetriever.METADATA_KEY_HAS_AUDIO) != "yes") return null
            val duration = r.extractMetadata(MediaMetadataRetriever.METADATA_KEY_DURATION)?.toLongOrNull() ?: 0L
            val title = r.extractMetadata(MediaMetadataRetriever.METADATA_KEY_TITLE)?.trim().orEmpty()
            val artist = r.extractMetadata(MediaMetadataRetriever.METADATA_KEY_ARTIST)?.trim().orEmpty()
            return Meta(title.ifEmpty { displayName(uri) }, artist, duration)
        } catch (_: Exception) {
            return null
        } finally {
            try {
                r.release()
            } catch (_: Exception) {
            }
        }
    }

    private fun displayName(uri: Uri): String {
        try {
            getApplication<Application>().contentResolver
                .query(uri, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)?.use { c ->
                    if (c.moveToFirst()) {
                        val name = c.getString(0)
                        if (!name.isNullOrBlank()) return name.substringBeforeLast('.')
                    }
                }
        } catch (_: Exception) {
        }
        return "Faixa sem título"
    }

    override fun onCleared() {
        decodeJobs.forEach { it?.cancel() }
        midi.stop()
        NativeEngine.nativeStop()
    }

    companion object {
        /** Faixa de velocidade do fader de pitch: -10% a +10%. */
        const val PITCH_MIN = 0.9f
        const val PITCH_MAX = 1.1f
        /** Abaixo disto o andamento detectado é tratado como "não detectado". */
        const val MIN_BPM_CONFIDENCE = 0.3f

        fun deckName(deck: Int) = if (deck == 0) "A" else "B"
    }
}
