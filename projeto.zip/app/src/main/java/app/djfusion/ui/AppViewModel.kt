package app.djfusion.ui

import app.djfusion.ErrorLog

import android.app.Application
import android.content.Intent
import android.media.MediaMetadataRetriever
import android.net.Uri
import android.provider.OpenableColumns
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import app.djfusion.audio.DecodeResult
import app.djfusion.audio.NativeEngine
import app.djfusion.audio.NeuralStems
import app.djfusion.audio.TrackDecoder
import app.djfusion.ui.theme.Metal
import app.djfusion.audio.OutputRouter
import app.djfusion.audio.AudioOut
import app.djfusion.harmony.Camelot
import app.djfusion.harmony.Harmonizer
import app.djfusion.harmony.MixAdvisor
import app.djfusion.harmony.MusicalKey
import app.djfusion.harmony.SetTrack
import app.djfusion.midi.Dj2go2Touch
import app.djfusion.midi.MidiHub
import app.djfusion.data.Analysis
import app.djfusion.data.LibraryDb
import app.djfusion.data.SortOrder
import app.djfusion.data.TrackRow
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import kotlinx.coroutines.sync.withLock

/**
 * Regra de uma LISTA INTELIGENTE (playlist que se monta sozinha):
 * [bpm] 0 todos, 1 até 100, 2 100–115, 3 115–128, 4 128–140, 5 acima de 140 ·
 * [energy] 0 todas, 1 baixa (1–4), 2 média (4–7), 3 alta (7–10) · [genre] parte do nome do gênero ·
 * [fav] só favoritas · [unplayed] só as que ainda não tocaram.
 */
data class SmartRule(val bpm: Int = 0, val energy: Int = 0, val genre: String = "", val fav: Boolean = false, val unplayed: Boolean = false) {
    val isEmpty: Boolean get() = bpm == 0 && energy == 0 && genre.isBlank() && !fav && !unplayed
    fun encode(): String = "$bpm|$energy|${if (fav) 1 else 0}|${if (unplayed) 1 else 0}|${genre.trim().take(40)}"
    fun describe(): String = listOfNotNull(
        BPM_BANDS.getOrNull(bpm)?.takeIf { bpm > 0 }?.let { "$it BPM" },
        ENERGY_BANDS.getOrNull(energy)?.takeIf { energy > 0 }?.let { "energia ${it.lowercase()}" },
        genre.trim().takeIf { it.isNotEmpty() }?.let { "gênero \"$it\"" },
        if (fav) "favoritas" else null,
        if (unplayed) "ainda não tocadas" else null,
    ).joinToString(" · ").ifEmpty { "todas as músicas" }

    companion object {
        val BPM_BANDS = listOf("TODOS", "ATÉ 100", "100–115", "115–128", "128–140", "140+")
        val ENERGY_BANDS = listOf("TODAS", "BAIXA", "MÉDIA", "ALTA")
        fun decode(t: String): SmartRule? {
            val f = t.split('|', limit = 5)
            if (f.size != 5) return null
            return SmartRule(f[0].toIntOrNull() ?: 0, f[1].toIntOrNull() ?: 0, f[4], f[2] == "1", f[3] == "1")
        }
    }
}

/** Trecho de andamento de uma música: começa em [start] (quadros), com [bpm] e uma batida em [beat]. */
data class TempoSec(val start: Long, val bpm: Double, val beat: Long)

/** Parte do deck que muda pouco (carregar, tocar, parar). */
data class DeckUi(
    val trackId: Long = -1,
    val title: String = "",
    val artist: String = "",
    val loaded: Boolean = false,
    val playing: Boolean = false,
    val loading: Boolean = false,
    val loadProgress: Float = 0f,
    val lengthFrames: Long = 0,
    val wave: ByteArray? = null,
    /** Andamento da faixa original (0 = não detectado) e onde cai a primeira batida. */
    val bpm: Double = 0.0,
    val firstBeatFrame: Long = 0,
    val bpmConfidence: Float = 0f,
    /** Velocidade de reprodução (1 = normal). O andamento tocado é bpm x rate. */
    val rate: Float = 1f,
    /** 0 = sem loop, senão o tamanho do loop em batidas. */
    val loopBeats: Int = 0,
    /** Hot cues: quadro de cada uma das 4 posições, -1 quando vazia. */
    val hotcues: List<Long> = List(8) { -1L },
    /** Equalizador graves, médios, agudos (0,5 = neutro) e filtro (0,5 = desligado). */
    val eq: List<Float> = listOf(0.5f, 0.5f, 0.5f),
    val filter: Float = 0.5f,
    /** Efeito do deck: 0 desligado, 1 eco, 2 flanger, 3 reverb, e a mistura de 0 a 1. */
    val fxType: Int = 0,
    val fxAmount: Float = 0.5f,
    /** Encaixes 2 e 3 de efeito (tocam junto com o primeiro, em série) e o encaixe que os botões controlam (0..2). */
    val fx2Type: Int = 0,
    val fx2Amount: Float = 0.5f,
    val fx3Type: Int = 0,
    val fx3Amount: Float = 0.5f,
    val fxSel: Int = 0,
    /** Nome de cada hot cue ("" = sem nome; mostra o número). */
    val hotcueNames: List<String> = List(8) { "" },
    /** Key-lock: o andamento muda sem mudar o tom. */
    val keyLock: Boolean = false,
    /** Pré-escuta no fone (PFL). */
    val cueOn: Boolean = false,
    /** Tonalidade detectada da faixa (nota 0..11, -1 = desconhecida), modo e confiança. */
    val keyTonic: Int = -1,
    val keyMinor: Boolean = false,
    val keyConf: Float = 0f,
    /** A área do prato mostra os pads (hot cue, loop, efeito) em vez do prato. */
    val padsOpen: Boolean = false,
    /** Modo dos pads na tela: 0 CUES, 1 LOOP, 2 SAMPLER, 3 MANOBRAS, 4 ROLL (como o PAD MODE da controladora). */
    val padMode: Int = 0,
    /** Música já tocável, mas o andamento/tom/energia ainda estão sendo analisados em segundo plano. */
    val analyzing: Boolean = false,
    /** Faixa do fader de pitch em % (±6 a ±50). */
    val pitchRange: Int = 8,
    /** SYNC travado: segue o andamento e corrige a fase da batida o tempo todo. */
    val syncLock: Boolean = false,
    /** Divisão de batida dos efeitos (eco, trans, phaser): 0,25 a 2 batidas. */
    val fxBeats: Float = 0.75f,
    /** ROLL ativo (tamanho em batidas, 0 = desligado). */
    val rollBeats: Float = 0f,
    /** Energia da faixa de 0 a 1 (-1 = não medida). */
    val energy: Float = -1f,
    /** Stems: -2 = indisponíveis (música longa/pouca memória), -1 = não separados, 0..1 = separando, 1 = prontos. */
    val stemProgress: Float = -1f,
    /** Ganho de voz, bateria, baixo e melodia (0..1). */
    val stemGains: List<Float> = listOf(1f, 1f, 1f, 1f),
    /** A área do prato mostra o painel de stems. */
    val stemsOpen: Boolean = false,
    /** Tom deslocado em semitons (-12..12), sem mudar o andamento. */
    val keyShift: Int = 0,
    /** SLIP: depois de scratch, loop, reverso ou censura, a música volta onde estaria. */
    val slip: Boolean = false,
    /** Tocando ao contrário (REVERSO). */
    val reverse: Boolean = false,
    /** Volume médio medido (dBFS, 0 = não medido) e ganho de entrada aplicado pelo auto-gain. */
    val loudness: Float = 0f,
    val trim: Float = 1f,
    /** Trechos de andamento (música que muda de velocidade, como montagens); vazio = andamento constante. */
    val tempoSections: List<TempoSec> = emptyList(),
    /** Trecho da grade em uso agora (-1 = grade geral da música). */
    val tempoIdx: Int = -1,
) {
    /** A música muda de andamento (GRADE INTELIGENTE segue os trechos). */
    val tempoVariable: Boolean get() = tempoSections.size > 1
    /** Tom provável, sem confiança suficiente (mostrado com "?", nunca usado como certo). */
    val keyGuess: MusicalKey?
        get() = if (key == null && keyTonic in 0..11 && keyConf > 0.05f) MusicalKey.of(keyTonic, keyMinor) else null
    val shownKeyGuess: MusicalKey? get() = (if (keyLock) keyGuess else keyGuess?.shifted(Camelot.semitonesFor(rate)))?.shifted(keyShift)
    val stemsReady: Boolean get() = stemProgress >= 1f
    fun fxTypeAt(slot: Int): Int = when (slot) { 0 -> fxType; 1 -> fx2Type; else -> fx3Type }
    fun fxAmountAt(slot: Int): Float = when (slot) { 0 -> fxAmount; 1 -> fx2Amount; else -> fx3Amount }
    /** Efeito e mistura do encaixe que os botões controlam agora. */
    val selFxType: Int get() = fxTypeAt(fxSel)
    val selFxAmount: Float get() = fxAmountAt(fxSel)
    /** Encaixe (0..2) onde o efeito [type] está ligado, ou -1. */
    fun fxSlotOf(type: Int): Int = (0..2).firstOrNull { fxTypeAt(it) == type } ?: -1
    fun withFx(slot: Int, type: Int = fxTypeAt(slot), amount: Float = fxAmountAt(slot)): DeckUi = when (slot) {
        0 -> copy(fxType = type, fxAmount = amount)
        1 -> copy(fx2Type = type, fx2Amount = amount)
        else -> copy(fx3Type = type, fx3Amount = amount)
    }
    val energyLevel: Int get() = if (energy < 0f) 0 else (1 + Math.round(energy * 9f)).coerceIn(1, 10)
    /** Tonalidade original, se detectada com confiança. */
    val key: MusicalKey?
        get() = if (keyTonic in 0..11 && keyConf >= Camelot.MIN_CONFIDENCE) MusicalKey.of(keyTonic, keyMinor) else null
    /** Tonalidade que se ouve agora: sem key-lock, mudar a velocidade desloca o tom. */
    val shownKey: MusicalKey? get() = (if (keyLock) key else key?.shifted(Camelot.semitonesFor(rate)))?.shifted(keyShift)
    val hasBpm: Boolean get() = bpm > 0.0 && bpmConfidence >= AppViewModel.MIN_BPM_CONFIDENCE
    val playedBpm: Double get() = bpm * rate
}

/** Um pad do sampler. */
data class PadUi(
    val label: String = "", val loop: Boolean = false, val ready: Boolean = false, val playing: Boolean = false,
    /** Andamento original do trecho (0 = sem andamento): loops seguem o andamento do deck que está tocando. */
    val bpm: Double = 0.0,
)

/** Parte que muda ~30 vezes por segundo (posição e nível). Fica separada para não redesenhar tudo. */
data class DeckLive(
    val positionFrames: Long = 0,
    val cueFrames: Long = 0,
    val peak: Float = 0f,
)

data class LiveUi(
    val decks: List<DeckLive> = List(AppViewModel.DECKS) { DeckLive() },
    val masterPeak: Float = 0f,
    val micPeak: Float = 0f,
)

/** Microfone: ligado, volume (0 a 2) e talkover (a música abaixa quando você fala). */
data class MicUi(
    val on: Boolean = false,
    val gain: Float = 1f,
    val talkover: Boolean = true,
    val talkAmount: Float = 0.6f,
)

class AppViewModel(app: Application) : AndroidViewModel(app) {
    private val db = LibraryDb(app)
    private val outPrefs = app.getSharedPreferences("output", android.content.Context.MODE_PRIVATE)
    // CROSSFADER FX (declarado cedo: o crossfader pode ser mexido durante a inicialização)
    private val _xfFx = MutableStateFlow(outPrefs.getInt("xf_fx", 0).coerceIn(0, 2))
    private val xfFxOn = BooleanArray(DECKS)

    /** Saída do fone: 0 só som geral, 1 dividido (E fone, D geral), 2 quatro canais (1-2 geral, 3-4 fone). */
    /** Modo do fone: 0 sem fone, 1 dividido, 2 quatro canais. -1 nas preferências = automático. */
    private val _outModePref = MutableStateFlow(outPrefs.getInt("mode2", -1).coerceIn(-1, 2))
    private val _outMode = MutableStateFlow(0)
    val outputMode: StateFlow<Int> = _outMode.asStateFlow()
    /** Segunda saída que toca junto (0 = nenhuma) e o que ela toca (0 = som geral, 1 = fone). */
    private val _mirrorDevice = MutableStateFlow(outPrefs.getInt("mirror", 0))
    val mirrorDevice: StateFlow<Int> = _mirrorDevice.asStateFlow()
    private val _mirrorWhat = MutableStateFlow(outPrefs.getInt("mirrorWhat", 0))
    val mirrorWhat: StateFlow<Int> = _mirrorWhat.asStateFlow()
    /** Aparelho de saída escolhido: -1 = automático (a primeira placa USB). */
    private val _outDevice = MutableStateFlow(outPrefs.getInt("device2", -1))
    val outputDevice: StateFlow<Int> = _outDevice.asStateFlow()
    private val _outNote = MutableStateFlow("")
    val outputNote: StateFlow<String> = _outNote.asStateFlow()
    private val _hpLevel = MutableStateFlow(0.7f)
    val hpLevel: StateFlow<Float> = _hpLevel.asStateFlow()
    private val _hpMix = MutableStateFlow(0f)
    val hpMix: StateFlow<Float> = _hpMix.asStateFlow()
    val router = OutputRouter(app) { applyOutput() }
    val outputs: StateFlow<List<AudioOut>> get() = router.devices

    private val _defaultPitch = MutableStateFlow(outPrefs.getInt("pitchRange", 8).let { if (it in PITCH_RANGES) it else 8 })
    /** Faixa do pitch com que os decks começam (AJUSTES). */
    val defaultPitch: StateFlow<Int> = _defaultPitch.asStateFlow()
    private val _decks = MutableStateFlow(List(DECKS) { DeckUi(pitchRange = _defaultPitch.value) })
    val decks: StateFlow<List<DeckUi>> = _decks.asStateFlow()

    /** Deck mostrado em cada lado da tela: esquerda = A ou C, direita = B ou D (como as camadas de uma controladora). */
    private val _layers = MutableStateFlow(listOf(0, 1))

    // microfone (declarado cedo: a leitura periódica começa dentro do construtor)
    private val _mic = MutableStateFlow(
        MicUi(
            gain = outPrefs.getFloat("micGain", 1f).coerceIn(0f, 2f),
            talkover = outPrefs.getBoolean("talkover", true),
            talkAmount = outPrefs.getFloat("talkAmount", 0.6f).coerceIn(0f, 0.9f),
        ),
    )
    val mic: StateFlow<MicUi> = _mic.asStateFlow()
    val layers: StateFlow<List<Int>> = _layers.asStateFlow()
    /** Deck que a controladora e a tela comandam neste lado (0 = esquerdo, 1 = direito). */
    fun layerDeck(side: Int): Int = _layers.value[side.coerceIn(0, 1)]
    /** Troca o deck do lado: A vira C (e C volta a A); B vira D (e D volta a B). */
    fun toggleLayer(side: Int) {
        val sd = side.coerceIn(0, 1)
        _layers.update { l -> l.mapIndexed { i, d -> if (i == sd) d xor 2 else d } }
        hwOwned.removeAll { it.startsWith("d$sd.") }   // os controles físicos voltam a esperar a posição do deck novo
        say("Lado ${if (sd == 0) "esquerdo" else "direito"}: deck ${deckName(layerDeck(sd))}.")
        syncLeds()
    }

    private val _live = MutableStateFlow(LiveUi())
    val live: StateFlow<LiveUi> = _live.asStateFlow()

    private val _volumes = MutableStateFlow(List(DECKS) { 1f })
    val volumes: StateFlow<List<Float>> = _volumes.asStateFlow()
    private val _crossfader = MutableStateFlow(0.5f)
    val crossfader: StateFlow<Float> = _crossfader.asStateFlow()
    private val _master = MutableStateFlow(0.8f)
    val master: StateFlow<Float> = _master.asStateFlow()

    private val _message = MutableStateFlow<String?>(null)
    val message: StateFlow<String?> = _message.asStateFlow()

    private val _audioStatus = MutableStateFlow("Áudio desligado")
    val audioStatus: StateFlow<String> = _audioStatus.asStateFlow()

    val search = MutableStateFlow("")
    val sort = MutableStateFlow(SortOrder.RECENT)
    private val libraryVersion = MutableStateFlow(0)

    private val setPrefs = app.getSharedPreferences("set", android.content.Context.MODE_PRIVATE)
    private val _set = MutableStateFlow(
        setPrefs.getString("ids", "").orEmpty().split(',').mapNotNull { it.toLongOrNull() },
    )
    /** Ordem do set montada pelo HARMONIZAR (ids das faixas). O AUTO DJ segue esta ordem. */
    val setOrder: StateFlow<List<Long>> = _set.asStateFlow()

    /** Filtro da biblioteca: 0 todas, 1 só favoritas, 2 possíveis duplicadas. */
    private val _libFilter = MutableStateFlow(0)
    val libFilter: StateFlow<Int> = _libFilter.asStateFlow()
    fun setLibFilter(f: Int) { _libFilter.value = if (_libFilter.value == f) 0 else f.coerceIn(0, 2) }

    val tracks: StateFlow<List<TrackRow>> =
        combine(search, sort, libraryVersion, _set, _libFilter) { s, o, _, _, f -> Triple(s, o, f) }
            .map { (s, o, f) ->
                val rows = withContext(Dispatchers.IO) { db.query(s, o) }
                val sorted = if (o == SortOrder.SET) {
                    val pos = _set.value.withIndex().associate { it.value to it.index }
                    rows.sortedBy { pos[it.id] ?: Int.MAX_VALUE }
                } else rows
                when (f) {
                    1 -> sorted.filter { it.favorite }
                    2 -> duplicatesOf(sorted)
                    else -> sorted
                }
            }
            .stateIn(viewModelScope, SharingStarted.Eagerly, emptyList())

    /** Liga/desliga a estrela (favorita) da faixa. */
    fun toggleFavorite(row: TrackRow) {
        viewModelScope.launch(Dispatchers.IO) {
            db.setFavorite(row.id, !row.favorite)
            libraryVersion.update { it + 1 }
        }
    }

    /**
     * Possíveis duplicadas: mesmo título e artista (sem diferença de maiúsculas, acentos e espaços)
     * e duração parecida (até 3 s). Nada é apagado sozinho: a lista mostra as duplicadas lado a lado.
     */
    internal fun duplicatesOf(rows: List<TrackRow>): List<TrackRow> {
        fun norm(x: String) = java.text.Normalizer.normalize(x.lowercase(), java.text.Normalizer.Form.NFD)
            .replace(Regex("\\p{M}+"), "").replace(Regex("[^a-z0-9]+"), " ").trim()
        val out = ArrayList<TrackRow>()
        for ((_, group) in rows.groupBy { norm(it.title) + "|" + norm(it.artist) }) {
            if (group.size < 2) continue
            val g = group.sortedBy { it.durationMs }
            val keep = g.filterIndexed { i, r ->
                (i > 0 && kotlin.math.abs(r.durationMs - g[i - 1].durationMs) <= 3000) ||
                    (i + 1 < g.size && kotlin.math.abs(g[i + 1].durationMs - r.durationMs) <= 3000)
            }
            out.addAll(keep)
        }
        return out
    }

    private val decodeJobs = arrayOfNulls<Job>(DECKS)

    private var foreground = true

    /** Controladoras MIDI USB (Numark etc.). Os controles aprendidos chegam em [onMidi]. */
    val midi = MidiHub(app, onPreset = {
        jog.setTicksPerRev(Dj2go2Touch.TICKS_PER_REV)
        say("Mapa de fábrica da Numark DJ2GO2 Touch aplicado: prato, play, cue, sync, pads e faders.")
    }) { id, v -> onMidi(id, v) }.also { h ->
        h.onConnected = { h.resetLeds() }
        h.onUnknownDevice = { n -> say("Controladora nova: $n. Abra CONTROLADORA › MAPEAR e toque em ASSISTENTE ESSENCIAL para ensinar os controles.") }
        h.onPresetApplied = { n, c -> say("Mapa pronto aplicado: $n ($c controles). Ajuste o que precisar em CONTROLADORA › MAPEAR.") }
    }

    private fun onMidi(id: String, v: Float) {
        val tg = app.djfusion.midi.MidiTargets.get(id)
        if (tg != null && tg.continuous && !tg.relative && !takeover(id, v)) return
        if (id == "xfade") { setCrossfader(v); return }
        if (id == "master") { setMaster(v); return }
        if (id == "autodj") { autoDj.toggle(); return }
        if (id == "automixnow") { autoDj.mixNow(); return }
        if (id.startsWith("pad")) { padPress(id.substring(3).toInt() - 1); return }
        if (id == "hpvol") { setHeadphoneLevel(v); return }
        if (id == "hpmix") { setHeadphoneMix(v); return }
        if (id == "browse") { browse(v.toInt()); return }
        if (id == "browsepush") { browsePush(); return }
        val deck = layerDeck(id[1].digitToInt())   // o prato 1 comanda o deck A ou C; o 2, o B ou D
        val k = id.substring(3)
        when {
            k == "play" -> togglePlay(deck)
            k == "cue" -> if (v > 0.5f) cueDown(deck) else cueUp(deck)
            k == "sync" -> syncButton(deck)
            k == "vol" -> if (_levelAsFilter.value) setFilter(deck, v) else setVolume(deck, v)
            k == "eqhi" -> setEq(deck, 2, v)
            k == "eqmid" -> setEq(deck, 1, v)
            k == "eqlo" -> setEq(deck, 0, v)
            k == "filter" -> setFilter(deck, v)
            k == "tempo" -> setPitchFader(deck, v)
            k == "fxamt" -> setFxAmount(deck, v)
            k == "jog" -> jog.tick(deck, v.toInt())
            k == "jogtouch" -> jog.touch(deck, v > 0.5f)
            k == "keylock" -> toggleKeyLock(deck)
            k == "pfl" -> toggleHeadphoneCue(deck)
            k == "fxeco" -> setFx(deck, 1)
            k == "fxflg" -> setFx(deck, 2)
            k == "fxrev" -> setFx(deck, 3)
            k.startsWith("hotdel") -> clearHotcue(deck, k.substring(6).toInt() - 1)
            k == "loopin" -> loopIn(deck)
            k == "loopout" -> loopOut(deck)
            k == "reloop" -> reloop(deck)
            k == "loopstart" -> loopToStart(deck)
            k == "load" -> loadSelected(deck)
            // modo PERFORMANCE: os pads de hot cue viram stems e os de loop automático viram manobras
            _padPerf.value && k.matches(Regex("hot[1-4]")) -> toggleStem(deck, k.substring(3).toInt() - 1)
            _padPerf.value && k.matches(Regex("loop[1248]")) -> when (k.substring(4).toInt()) {
                1 -> toggleSlip(deck)
                2 -> toggleReverse(deck)
                4 -> censor(deck)
                else -> matchKey(deck)
            }
            k.matches(Regex("hot[1-8]")) -> hotcue(deck, k.substring(3).toInt() - 1)
            k == "search" -> jog.setSearch(deck, v > 0.5f)
            k == "jogshift" -> jog.tickSearch(deck, v.toInt())
            k == "jogmode" -> if (v > 0.5f) cycleJogMode(deck)
            k == "backspin" -> if (v > 0.5f) jog.backspin(deck)
            k == "bendup" -> pitchBend(deck, 1, v > 0.5f)
            k == "benddown" -> pitchBend(deck, -1, v > 0.5f)
            k == "pitchreset" -> resetPitch(deck)
            k == "loophalf" -> loopResize(deck, 0.5)
            k == "loopdouble" -> loopResize(deck, 2.0)
            k == "fxslot" -> setFxSlot(deck, (_decks.value[deck].fxSel + 1) % 3)
            k == "fxoff" -> clearFx(deck)
            k == "cuesauto" -> prepareCues(deck)
            k == "echoout" -> echoOut(deck)
            k == "brake" -> brake(deck)
            k.matches(Regex("loop[1248]")) -> toggleLoop(deck, k.substring(4).toInt())
            k == "stemv" -> toggleStem(deck, 0)
            k == "stemd" -> toggleStem(deck, 1)
            k == "stemb" -> toggleStem(deck, 2)
            k == "stemm" -> toggleStem(deck, 3)
            k == "acapella" -> stemPreset(deck, 1)
            k == "instr" -> stemPreset(deck, 2)
            k == "stemall" -> stemPreset(deck, 0)
            k == "slip" -> toggleSlip(deck)
            k == "rev" -> toggleReverse(deck)
            k == "censor" -> censor(deck)
            k == "keyup" -> shiftKey(deck, 1)
            k == "keydown" -> shiftKey(deck, -1)
            k == "keymatch" -> matchKey(deck)
            k == "jumpf" -> beatJump(deck, 4)
            k == "jumpb" -> beatJump(deck, -4)
        }
    }

    // ------------------------------------------- SOFT TAKEOVER: o fader da controladora assume ao alcançar

    private val ctlPrefs = app.getSharedPreferences("controle", android.content.Context.MODE_PRIVATE)
    private val _takeover = MutableStateFlow(ctlPrefs.getBoolean("takeover", true))
    /**
     * Ligado: um fader/botão giratório da controladora só passa a mandar quando chega na posição que o app
     * está usando (o AUTO DJ, o SYNC ou a tela mudaram o valor). Evita pulos de volume e de pitch.
     */
    val takeoverOn: StateFlow<Boolean> = _takeover.asStateFlow()
    fun toggleTakeover() {
        _takeover.value = !_takeover.value
        ctlPrefs.edit().putBoolean("takeover", _takeover.value).apply()
        hwOwned.clear()
        say(
            if (_takeover.value) "Controladora: faders assumem ao alcançar a posição do app (sem pulos)."
            else "Controladora: faders mandam na hora (podem dar pulo de volume ou de pitch).",
        )
    }
    private val hwLast = HashMap<String, Float>()
    private val hwApplied = HashMap<String, Float>()
    private val hwOwned = HashSet<String>()
    private val hwHintAt = HashMap<String, Long>()
    private val _waiting = MutableStateFlow<Set<String>>(emptySet())
    /** Controles da controladora esperando chegar na posição do app. */
    val takeoverWaiting: StateFlow<Set<String>> = _waiting.asStateFlow()

    /** Valor atual no app de um controle contínuo, na mesma escala que chega da controladora (0 a 1). */
    private fun appValueOf(id: String): Float? = when {
        id == "xfade" -> _crossfader.value
        id == "master" -> _master.value
        id.length > 3 && id[0] == 'd' && id[2] == '.' -> {
            val d = layerDeck(id[1].digitToInt())
            val ui = _decks.value[d]
            when (id.substring(3)) {
                "vol" -> if (_levelAsFilter.value) ui.filter else _volumes.value[d]
                "eqhi" -> ui.eq[2]
                "eqmid" -> ui.eq[1]
                "eqlo" -> ui.eq[0]
                "filter" -> ui.filter
                "tempo" -> pitchFaderValue(ui)
                else -> null
            }
        }
        else -> null
    }

    /** true = a controladora comanda este controle agora; false = ainda não alcançou a posição do app. */
    private fun takeover(id: String, v: Float): Boolean {
        if (!_takeover.value) return true
        val c = appValueOf(id) ?: return true
        val h = hwLast.put(id, v)
        // o app mudou o valor sozinho (AUTO DJ, SYNC, tela): a controladora volta a esperar
        val applied = hwApplied[id]
        if (id in hwOwned && applied != null && kotlin.math.abs(c - applied) > 0.04f) hwOwned.remove(id)
        if (id !in hwOwned) {
            val near = kotlin.math.abs(v - c) <= 0.05f
            val crossed = h != null && (h - c) * (v - c) <= 0f
            if (!near && !crossed) {
                _waiting.update { it + id }
                val now = android.os.SystemClock.uptimeMillis()
                if (now - (hwHintAt[id] ?: 0L) > 8000) {
                    hwHintAt[id] = now
                    val label = app.djfusion.midi.MidiTargets.get(id)?.label ?: id
                    say("$label: leve o controle até ${Math.round(c * 100)}% (onde o app está) para ele assumir sem pulo.")
                }
                return false
            }
            hwOwned.add(id)
            _waiting.update { it - id }
        }
        hwApplied[id] = v
        return true
    }

    // ------------------------------------------------- VERIFICAR: problemas achados sozinhos, com correção

    /** Um problema achado pelo app, em português simples, com a correção quando dá para corrigir sozinho. */
    class Problem(val title: String, val detail: String, val fixLabel: String? = null, val fix: (() -> Unit)? = null)
    private val _problems = MutableStateFlow<List<Problem>>(emptyList())
    val problems: StateFlow<List<Problem>> = _problems.asStateFlow()
    private val _gotoMidi = MutableStateFlow(0)
    /** Pedido para abrir a aba CONTROLADORA (conta quantas vezes foi pedido). */
    val gotoMidi: StateFlow<Int> = _gotoMidi.asStateFlow()
    fun openMidiScreen() { _gotoMidi.update { it + 1 } }

    /** Confere de novo agora (ao abrir VERIFICAR e depois de cada correção). */
    fun refreshProblemsNow() { _problems.value = checkProblems() }

    private fun refreshProblems() {
        val list = checkProblems()
        if (list.map { it.title } != _problems.value.map { it.title }) _problems.value = list
    }

    /** Confere o que pode estar errado agora (som, controladora, músicas, aparelho). */
    fun checkProblems(): List<Problem> {
        val out = ArrayList<Problem>()
        val decks = _decks.value
        val anyPlaying = decks.any { it.playing }
        val xf = _crossfader.value
        for (d in 0 until DECKS) {
            val ui = decks[d]
            val n = deckName(d)
            if (ui.playing && _volumes.value[d] < 0.05f) {
                out.add(Problem("Deck $n tocando sem volume", "O volume do deck $n está em ${Math.round(_volumes.value[d] * 100)}%. A música toca, mas não sai som.", "SUBIR O VOLUME") { setVolume(d, 0.8f); hwOwned.remove("d${d % 2}.vol") })
            }
            val other = decks[(d xor 1)]
            val closed = if (d % 2 == 0) xf > 0.97f else xf < 0.03f
            if (ui.playing && !other.playing && closed && !autoDj.state.value.active) {
                out.add(Problem("Crossfader do lado errado", "Só o deck $n está tocando, mas o crossfader está todo do outro lado: não sai som.", "CENTRALIZAR") { setCrossfader(0.5f); hwOwned.remove("xfade") })
            }
            if (ui.loaded && ui.playing && kotlin.math.abs(ui.rate - 1f) >= 0.10f && !ui.syncLock) {
                out.add(Problem(
                    "Pitch do deck $n em ${String.format(java.util.Locale.ROOT, "%+.1f%%", (ui.rate - 1f) * 100f)}",
                    "A música está bem mais ${if (ui.rate > 1f) "rápida" else "lenta"} que o normal. Se foi o fader da controladora no sentido contrário, use INVERTER TEMPO em CONTROLADORA.",
                    "PITCH A 0%",
                ) { resetPitch(d) })
            }
            if (ui.loaded && !ui.analyzing && ui.bpm > 0 && ui.bpmConfidence < 0.45f) {
                out.add(Problem("Batida incerta no deck $n", "${ui.title}: o app não tem certeza da grade (${Math.round(ui.bpmConfidence * 100)}%). O AUTO DJ usa transição segura com eco; para mixar à mão, confira a grade com TAP."))
            }
        }
        if (anyPlaying && _master.value < 0.05f) out.add(Problem("Volume geral no zero", "O MASTER está em ${Math.round(_master.value * 100)}%.", "SUBIR O MASTER") { setMaster(0.8f); hwOwned.remove("master") })
        if (splitOnSpeaker) out.add(Problem("Pré-escuta sem fone", "Você escolheu pré-escuta separada, mas só há o alto-falante do celular: o app toca normal até você ligar fone, caixa ou controladora."))
        midi.suggestPreset.value?.let { (name, why) ->
            out.add(Problem("Controladora parece: $name", why, "USAR ESTE MAPA") { midi.applySuggestedPreset() })
        }
        val unk = midi.unknownTotal()
        if (midi.devices.value.isNotEmpty() && unk >= 3) {
            val top = midi.unknownStats().take(3).joinToString(", ") { it.first }
            out.add(Problem("Botões da controladora sem função", "Você usou $unk vez(es) controles que ainda não fazem nada ($top). Toque neles e escolha a função no aviso, ou use o assistente.", "ENSINAR") { openMidiScreen() })
        }
        if (midi.devices.value.isNotEmpty() && midi.mapped.value.size < 8) {
            out.add(Problem("Controladora quase sem mapa", "Só ${midi.mapped.value.size} controles mapeados. O assistente ensina os essenciais em 2 minutos.", "ASSISTENTE") { openMidiScreen(); midi.startWizard(essentialOnly = true) })
        }
        if (audioRestarts > 0) out.add(Problem("Som reiniciado $audioRestarts vez(es)", "A saída de áudio parou e o app religou sozinho. Se acontecer de novo, use latência SEGURA em AJUSTES › SOM.", "LATÊNCIA SEGURA") { setLatency(2) })
        val crashes = ErrorLog.crashes(getApplication<Application>())
        if (crashes.isNotEmpty()) {
            out.add(Problem("O app fechou sozinho ${crashes.size} vez(es)", crashes.last().lines().take(3).joinToString(" · ").take(220) + " — o detalhe está no RELATÓRIO.", "APAGAR AVISO") { ErrorLog.clearCrashes(getApplication<Application>()) })
        }
        val free = runCatching { getApplication<Application>().filesDir.usableSpace }.getOrDefault(Long.MAX_VALUE)
        if (free < 300L * 1024 * 1024) out.add(Problem("Pouco espaço no celular", "Livre: ${free / (1024 * 1024)} MB. Gravações e stems podem falhar."))
        protectionProblem()?.let { out.add(it) }
        return out
    }

    // ------------------------------------------------------------------ ATUALIZAÇÕES (Play Store)

    private val _updateStatus = MutableStateFlow("")
    /** Situação da atualização pela Play Store ("" = nada a dizer). */
    val updateStatus: StateFlow<String> = _updateStatus.asStateFlow()
    private val _updateReady = MutableStateFlow(false)
    /** Versão nova já baixada, esperando o DJ mandar instalar (nunca no meio do set sem pedir). */
    val updateReady: StateFlow<Boolean> = _updateReady.asStateFlow()
    /** Ligados pela tela principal (a Play Store precisa da Activity). */
    var updateChecker: (() -> Unit)? = null
    var updateInstaller: (() -> Unit)? = null
    fun setUpdateStatus(text: String, ready: Boolean = _updateReady.value) {
        _updateStatus.value = text
        _updateReady.value = ready
    }
    fun checkUpdateNow() {
        val c = updateChecker
        if (c == null) { setUpdateStatus("Atualização automática só funciona com o app instalado pela Play Store."); return }
        setUpdateStatus("Procurando versão nova…")
        c()
    }
    fun installUpdateNow() {
        if (decks.value.any { it.playing }) { say("Pare a música antes de instalar: o app reinicia para atualizar."); return }
        updateInstaller?.invoke()
    }

    // ------------------------------------------------------------------ PROTEÇÃO (assinatura e origem)

    /** SHA-256 do certificado com que este APK foi assinado. */
    fun signingCertSha256(): String = runCatching {
        val ctx = getApplication<Application>()
        val pm = ctx.packageManager
        val certs: Array<android.content.pm.Signature> = if (android.os.Build.VERSION.SDK_INT >= 28) {
            val info = pm.getPackageInfo(ctx.packageName, android.content.pm.PackageManager.GET_SIGNING_CERTIFICATES)
            info.signingInfo?.apkContentsSigners ?: emptyArray()
        } else {
            @Suppress("DEPRECATION")
            pm.getPackageInfo(ctx.packageName, android.content.pm.PackageManager.GET_SIGNATURES).signatures ?: emptyArray()
        }
        val md = java.security.MessageDigest.getInstance("SHA-256")
        certs.firstOrNull()?.let { md.digest(it.toByteArray()).joinToString("") { b -> "%02x".format(b) } } ?: "?"
    }.getOrDefault("?")

    /** Quem instalou o app ("com.android.vending" = Play Store; vazio = arquivo APK). */
    fun installerName(): String = runCatching {
        val ctx = getApplication<Application>()
        if (android.os.Build.VERSION.SDK_INT >= 30) ctx.packageManager.getInstallSourceInfo(ctx.packageName).installingPackageName
        else @Suppress("DEPRECATION") ctx.packageManager.getInstallerPackageName(ctx.packageName)
    }.getOrNull().orEmpty()

    private fun protectionProblem(): Problem? {
        val sha = signingCertSha256()
        val fromPlay = installerName() == "com.android.vending"
        // instalado pela Play Store: a Google assina com a chave dela (Play App Signing), então vale qualquer uma
        if (fromPlay || sha == "?" || sha in OFFICIAL_CERTS) return null
        return Problem("Cópia não original", "Este app não foi assinado pela chave oficial do Edgard Guarda DJ Studio (${sha.take(12)}…). Pode ter sido modificado. Instale pela Play Store.")
    }

    // ------------------------------------------------------------------ LOOP MANUAL (in / out)

    private val loopInAt = LongArray(DECKS) { -1L }
    private val loopOutAt = LongArray(DECKS) { -1L }
    private val _manualLoop = MutableStateFlow(List(DECKS) { -1L to -1L })
    /** Pontos do loop manual de cada deck (in, out), -1 = não marcado. */
    val manualLoop: StateFlow<List<Pair<Long, Long>>> = _manualLoop.asStateFlow()
    private fun pubLoop() { _manualLoop.value = List(DECKS) { loopInAt[it] to loopOutAt[it] } }

    private fun posOf(deck: Int): Long { val st = LongArray(4); NativeEngine.nativeDeckState(deck, st); return st[1] }

    /** LOOP IN: marca o início do loop onde a música está (no meio de um loop, só muda o início). */
    fun loopIn(deck: Int) {
        val d = _decks.value[deck]
        if (!d.loaded || d.loading) { say("Carregue uma música no deck ${deckName(deck)} primeiro."); return }
        loopInAt[deck] = snapToBeat(d, posOf(deck))
        if (d.loopBeats == -1 && loopOutAt[deck] > loopInAt[deck]) {
            setLoopNative(deck, loopInAt[deck], loopOutAt[deck])
        } else {
            loopOutAt[deck] = -1
        }
        pubLoop()
        say("LOOP IN marcado no deck ${deckName(deck)}. Toque em LOOP OUT para fechar o loop.")
    }

    /** LOOP OUT: fecha o loop entre o LOOP IN e onde a música está, e liga. */
    fun loopOut(deck: Int) {
        val d = _decks.value[deck]
        val a = loopInAt[deck]
        if (a < 0) { say("Marque o LOOP IN primeiro."); return }
        var b = snapToBeat(d, posOf(deck))
        // com QUANTIZE o loop tem pelo menos 1 batida
        if (_quantize.value && d.hasBpm && b <= a) b = a + (60.0 * NativeEngine.SAMPLE_RATE / d.bpm).toLong()
        if (b <= a + NativeEngine.SAMPLE_RATE / 20) { say("O LOOP OUT precisa vir depois do LOOP IN."); return }
        loopOutAt[deck] = b
        if (d.loopBeats == 0) slipBegin(deck)
        setLoopNative(deck, a, b)
        setDeck(deck) { it.copy(loopBeats = -1) }
        pubLoop()
    }

    /** RELOOP: liga ou desliga o loop manual guardado. */
    fun reloop(deck: Int) {
        val d = _decks.value[deck]
        if (d.loopBeats != 0) {
            clearLoopNative(deck)
            setDeck(deck) { it.copy(loopBeats = 0) }
            slipEnd(deck)
            return
        }
        val a = loopInAt[deck]; val b = loopOutAt[deck]
        if (a < 0 || b <= a) { say("Sem loop guardado: use LOOP IN e LOOP OUT."); return }
        slipBegin(deck)
        val p = posOf(deck)
        if (p < a || p >= b) NativeEngine.nativeSeek(deck, a)
        setLoopNative(deck, a, b)
        setDeck(deck) { it.copy(loopBeats = -1) }
    }

    /** Volta ao início do loop manual (e liga o loop, se tiver fim marcado). */
    fun loopToStart(deck: Int) {
        val a = loopInAt[deck]
        if (a < 0) { say("Marque o LOOP IN primeiro."); return }
        NativeEngine.nativeSeek(deck, a)
        val b = loopOutAt[deck]
        if (b > a) { setLoopNative(deck, a, b); setDeck(deck) { it.copy(loopBeats = -1) } }
        if (!_decks.value[deck].playing) NativeEngine.nativePlay(deck)
    }

    // ------------------------------------------------------------------ BROWSE e LOAD da controladora

    private val _browseIndex = MutableStateFlow(0)
    /** Música selecionada pelo botão BROWSE da controladora (posição na lista mostrada). */
    val browseIndex: StateFlow<Int> = _browseIndex.asStateFlow()
    /** Ordem da lista que está na tela (o navegador rápido ordena pelo assistente). */
    private var browseIds: List<Long> = emptyList()
    fun setBrowseList(ids: List<Long>) {
        browseIds = ids
        if (_browseIndex.value >= ids.size) _browseIndex.value = (ids.size - 1).coerceAtLeast(0)
    }
    private fun browseList(): List<TrackRow> {
        val all = tracks.value
        if (browseIds.isEmpty() || (browserDeck.value == null && !_browserDock.value)) return all
        val byId = all.associateBy { it.id }
        return browseIds.mapNotNull { byId[it] }
    }

    fun browse(delta: Int) {
        val list = browseList()
        if (list.isEmpty()) { say("Biblioteca vazia: importe músicas."); return }
        val i = (_browseIndex.value + delta).coerceIn(0, list.size - 1)
        _browseIndex.value = i
        if (browserDeck.value == null && !_browserDock.value) say("▶ ${list[i].title}  (LOAD A ou LOAD B para carregar)")
    }

    fun browsePush() {
        if (browserDeck.value != null) closeBrowser()
        else {
            val a = layerDeck(0); val b = layerDeck(1)
            openBrowser(if (_decks.value[a].playing && !_decks.value[b].playing) b else a)
        }
    }

    /** LOAD da controladora: carrega a música selecionada no deck. */
    fun loadSelected(deck: Int) {
        val list = browseList()
        val row = list.getOrNull(_browseIndex.value) ?: run { say("Gire o BROWSE para escolher uma música."); return }
        if (browserDeck.value != null) closeBrowser()
        loadTrack(deck, row)
    }

    // ------------------------------------------------------------------ LEDs da controladora

    private fun syncLeds() {
        val ds = _decks.value
        val pads = _pads.value
        for (side in 0..1) {
            val d = layerDeck(side)
            val x = ds[d]
            midi.led("d$side.play", x.playing)
            midi.led("d$side.cue", x.loaded && !x.playing)
            midi.led("d$side.pfl", x.cueOn)
            midi.led("d$side.sync", false)
            for (sl in 0..3) midi.led("d$side.hot${sl + 1}", x.hotcues[sl] >= 0)
            for (b in intArrayOf(1, 2, 4, 8)) midi.led("d$side.loop$b", x.loopBeats == b)
            midi.led("d$side.loopin", loopInAt[d] >= 0)
            midi.led("d$side.loopout", loopOutAt[d] >= 0)
            midi.led("d$side.reloop", x.loopBeats == -1)
            midi.led("d$side.loopstart", loopInAt[d] >= 0)
        }
        for (i in 0..7) midi.led("pad${i + 1}", pads[i].ready)
    }

    /** Knob LEVEL de cada deck da controladora: false = volume do deck, true = filtro (como no Mixxx). */
    private val _levelAsFilter = MutableStateFlow(outPrefs.getBoolean("levelFilter", false))
    val levelAsFilter: StateFlow<Boolean> = _levelAsFilter.asStateFlow()
    fun toggleLevelAsFilter() {
        _levelAsFilter.value = !_levelAsFilter.value
        outPrefs.edit().putBoolean("levelFilter", _levelAsFilter.value).apply()
        say(if (_levelAsFilter.value) "Knob LEVEL da controladora agora controla o FILTRO de cada deck." else "Knob LEVEL da controladora agora controla o VOLUME de cada deck.")
    }

    // ------------------------------------------------------------------ RELATÓRIO DE DIAGNÓSTICO

    /** Texto com tudo que ajuda a achar um problema: aparelho, saídas de áudio, controladora e erros de leitura. */
    fun diagnosticsText(): String {
        val info = IntArray(8)
        NativeEngine.nativeStreamInfo(info)
        val ctx = getApplication<Application>()
        val ver = runCatching { ctx.packageManager.getPackageInfo(ctx.packageName, 0).versionName }.getOrNull()
        return buildString {
            appendLine("EDGARD GUARDA DJ STUDIO — RELATÓRIO DE DIAGNÓSTICO")
            appendLine("versão $ver · Android ${android.os.Build.VERSION.RELEASE} (API ${android.os.Build.VERSION.SDK_INT}) · ${android.os.Build.MANUFACTURER} ${android.os.Build.MODEL}")
            appendLine("data ${java.text.SimpleDateFormat("yyyy-MM-dd HH:mm:ss", java.util.Locale.ROOT).format(java.util.Date())}")
            appendLine()
            appendLine("ÁUDIO: ${_audioStatus.value}")
            appendLine("  fluxo: taxa=${info[0]} rajada=${info[1]} buffer=${info[2]} exclusivo=${info[3]} canais=${info[4]} modo=${info[5]} aparelho=${info[6]} segunda=${info[7]}")
            appendLine("  escolhido: principal=${_outDevice.value} modo=${_outMode.value} (pref ${_outModePref.value}) segunda=${_mirrorDevice.value}/${_mirrorWhat.value}")
            appendLine("  ${_outNote.value}")
            appendLine("SAÍDAS DO ANDROID:")
            appendLine(router.describeAll())
            appendLine()
            appendLine("CONTROLADORA (MIDI):")
            appendLine(midi.describeDevices())
            appendLine("  passos do jog por volta: ${jog.ticksPerRev} · ajuste fino x${jog.bendGain} · LEVEL=${if (_levelAsFilter.value) "filtro" else "volume"} · pads performance=${_padPerf.value}")
            appendLine("MAPA:")
            appendLine(midi.describeMap())
            appendLine("ÚLTIMAS MENSAGENS (mais recente primeiro):")
            for (l in midi.diag.take(150)) appendLine("  $l")
            appendLine()
            appendLine("DECKS:")
            for ((i, d) in _decks.value.withIndex()) {
                appendLine(
                    "  ${deckName(i)}: ${if (d.loaded) d.title else "vazio"} · tocando=${d.playing} · " +
                        String.format(java.util.Locale.ROOT, "bpm=%.2f (confiança %.2f) · pitch=%+.2f%%", d.bpm, d.bpmConfidence, (d.rate - 1f) * 100f) +
                        " · tom=${d.key?.code ?: (d.keyGuess?.code?.let { "$it? (incerto)" } ?: "?")} · sync=${d.syncLock}" +
                        (if (d.tempoVariable) " · andamento variável: ${d.tempoSections.joinToString(" → ") { String.format(java.util.Locale.ROOT, "%.1f", it.bpm) }}" else "") +
                        " · stems=${d.stemProgress} · ganho=${d.trim}",
                )
            }
            appendLine("STEMS POR IA: modelo ${if (_neural.value.ready) "baixado" else "NÃO baixado"} · ${if (!_neural.value.on) "desligada" else if (_neural.value.ready) "ligada" else "ligada, mas sem o modelo: usa o separador comum"}" +
                " · último separador: deck A ${if (NeuralStems.lastUsedAi(0)) "IA" else "comum"}, deck B ${if (NeuralStems.lastUsedAi(1)) "IA" else "comum"}" +
                (NeuralStems.lastError?.let { " · último erro: $it" } ?: ""))
            appendLine("AUTO DJ: ${if (autoDj.state.value.active) "ligado" else "desligado"} · ${autoDj.state.value.status}")
            autoDj.traceText().takeIf { it.isNotBlank() }?.let { appendLine("  diário do AUTO DJ (mais antigo primeiro):"); appendLine(it) }
            appendLine("MENSAGENS DO APP (mais recente primeiro):")
            val sl = synchronized(sayLog) { sayLog.toList() }
            if (sl.isEmpty()) appendLine("  nenhuma")
            for (l in sl.take(40)) appendLine("  $l")
            appendLine("BIBLIOTECA: ${tracks.value.size} faixa(s) na lista")
            appendLine("ERROS DE LEITURA DE MÚSICA:")
            if (TrackDecoder.recentErrors.isEmpty()) appendLine("  nenhum")
            for (e in TrackDecoder.recentErrors) appendLine("  $e")
            appendLine()
            appendLine("PROBLEMAS DETECTADOS (verificação automática):")
            val probs = checkProblems()
            if (probs.isEmpty()) appendLine("  nenhum")
            for (p in probs) appendLine("  • ${p.title}: ${p.detail}" + (p.fixLabel?.let { " [correção: $it]" } ?: ""))
            appendLine("CONTROLES DA CONTROLADORA SEM FUNÇÃO (vezes usados):")
            val unk = midi.unknownStats()
            if (unk.isEmpty()) appendLine("  nenhum")
            for ((k, n) in unk) appendLine("  $k: $n×")
            appendLine("  soft takeover: ${if (_takeover.value) "ligado" else "desligado"} · esperando: ${_waiting.value.joinToString().ifEmpty { "nenhum" }}")
            appendLine("ERROS RECENTES (o app continuou):")
            val errs = ErrorLog.recent()
            if (errs.isEmpty()) appendLine("  nenhum")
            for (e in errs.take(40)) appendLine("  $e")
            appendLine("FECHAMENTOS INESPERADOS:")
            val cr = ErrorLog.crashes(ctx)
            if (cr.isEmpty()) appendLine("  nenhum")
            for (c in cr.takeLast(3)) appendLine(c.prependIndent("  "))
            appendLine("SOM REINICIADO PELO VIGIA: $audioRestarts vez(es)")
            appendLine("PROTEÇÃO: certificado ${signingCertSha256().take(16)}… (${if (signingCertSha256() in OFFICIAL_CERTS) "oficial" else "outro"}) · instalado por: ${installerName().ifEmpty { "arquivo APK" }}")
        }
    }

    /** Copia o relatório para a área de transferência e salva em Download/Edgard Guarda DJ Studio. */
    fun exportDiagnostics() {
        val text = diagnosticsText()
        val ctx = getApplication<Application>()
        val cm = ctx.getSystemService(android.content.Context.CLIPBOARD_SERVICE) as android.content.ClipboardManager
        cm.setPrimaryClip(android.content.ClipData.newPlainText("Relatório DJ Studio", text))
        viewModelScope.launch(Dispatchers.IO) {
            val where = try {
                if (android.os.Build.VERSION.SDK_INT >= 29) {
                    val r = ctx.contentResolver
                    val name = "diagnostico_" + java.text.SimpleDateFormat("yyyy-MM-dd_HH-mm", java.util.Locale.ROOT).format(java.util.Date()) + ".txt"
                    val v = android.content.ContentValues().apply {
                        put(android.provider.MediaStore.Downloads.DISPLAY_NAME, name)
                        put(android.provider.MediaStore.Downloads.MIME_TYPE, "text/plain")
                        put(android.provider.MediaStore.Downloads.RELATIVE_PATH, "Download/Edgard Guarda DJ Studio")
                    }
                    val uri = r.insert(android.provider.MediaStore.Downloads.EXTERNAL_CONTENT_URI, v)
                    if (uri != null) { r.openOutputStream(uri)?.use { it.write(text.toByteArray()) }; "Download/Edgard Guarda DJ Studio/$name" } else "área de transferência"
                } else "área de transferência"
            } catch (_: Exception) { "área de transferência" }
            say("Relatório copiado (cole numa mensagem) e salvo em $where.")
        }
    }

    /** Pads da controladora em modo PERFORMANCE (hot cue = stems, loop = SLIP/REV/CENS/TOM). */
    private val _padPerf = MutableStateFlow(false)
    val padPerf: StateFlow<Boolean> = _padPerf.asStateFlow()

    fun togglePadPerf() {
        _padPerf.value = !_padPerf.value
        say(
            if (_padPerf.value) "Pads da controladora em PERFORMANCE: pads de hot cue = VOZ, BATERIA, BAIXO, MELODIA; pads de loop = SLIP, REVERSO, CENSURA, TOM."
            else "Pads da controladora de volta ao normal: hot cue e loop.",
        )
    }
    private var stopJob: Job? = null

    /** AUTO DJ: o app escolhe as músicas e faz as mixagens sozinho. */
    val autoDj = AutoDj(this, viewModelScope, app.getSharedPreferences("autodj", android.content.Context.MODE_PRIVATE))

    /** Jog wheel das controladoras (scratch e ajuste fino). */
    val jog = JogController(app.getSharedPreferences("jog", android.content.Context.MODE_PRIVATE), this, viewModelScope)

    // ---------------------------------------------------------------- sampler

    private val _pads = MutableStateFlow(List(8) { PadUi() })
    val pads: StateFlow<List<PadUi>> = _pads.asStateFlow()
    private val _samplerVol = MutableStateFlow(0.8f)
    val samplerVol: StateFlow<Float> = _samplerVol.asStateFlow()

    /** Escolhe sozinho os melhores trechos das músicas dos decks e os coloca nos pads (4 por deck). */
    /** Pads "inteligentes": depois de gerar uma vez, cada música nova no deck troca as amostras daquele deck. */
    private val autoSamples = BooleanArray(DECKS)

    fun buildSamples() {
        val decks = _decks.value
        if (decks.none { it.loaded && !it.loading }) {
            say("Carregue uma música em pelo menos um deck para gerar as amostras.")
            return
        }
        viewModelScope.launch(Dispatchers.Default) {
            var total = 0
            for (deck in 0 until DECKS) {
                if (!decks[deck].loaded || decks[deck].loading) continue
                autoSamples[deck] = true
                total += buildSamplesNow(deck)
            }
            NativeEngine.nativeSetSamplerVolume(_samplerVol.value)
            say(if (total > 0) "$total amostras prontas nos pads. Elas acompanham as próximas músicas de cada deck." else "Não achei trechos bons nessas faixas.")
        }
    }

    /** Gera os 4 pads do deck (1–4 = A, 5–8 = B) a partir da música dele. Devolve quantos ficaram prontos. */
    private fun buildSamplesNow(deck: Int): Int {
        val d = _decks.value[deck]
        if (!d.loaded || d.loading) return 0
        android.os.Process.setThreadPriority(android.os.Process.THREAD_PRIORITY_BACKGROUND)
        val base = (deck % 2) * 4
        for (k in base until base + 4) { sentSpeed[k] = 1f; NativeEngine.nativeSetSampleSpeed(k, 1f) }
        val info = LongArray(12)
        val n = NativeEngine.nativeBuildSamples(deck, if (d.hasBpm) d.bpm else 0.0, d.firstBeatFrame, base, info)
        val short = d.title.take(14)
        _pads.update { old ->
            old.mapIndexed { i, p ->
                if (i !in base until base + 4) return@mapIndexed p
                val k = i - base
                if (k >= n) return@mapIndexed PadUi()
                val kind = info[3 * k].toInt()
                val loop = info[3 * k + 2] == 1L
                val what = when (kind) {
                    0 -> "BUMBO"
                    1 -> "GOLPE"
                    2 -> if (loop) "LOOP 1 COMPASSO" else "TRECHO FORTE"
                    else -> "LOOP 2 COMPASSOS"
                }
                PadUi("${deckName(deck)} · $what · $short", loop, true, false, if (d.hasBpm) d.bpm else 0.0)
            }
        }
        return n
    }

    /** CAPTURA: o compasso que está tocando agora (4 batidas, a partir da batida) vira um loop num pad do deck. */
    fun captureLoop(deck: Int) {
        val d = _decks.value[deck]
        if (!d.loaded || d.loading) { say("Carregue uma música no deck ${deckName(deck)} primeiro."); return }
        val beat = if (d.hasBpm) 60.0 * NativeEngine.SAMPLE_RATE / d.bpm else NativeEngine.SAMPLE_RATE * 0.5
        val pos = posOf(deck)
        val start = if (d.hasBpm) (d.firstBeatFrame + Math.floor((pos - d.firstBeatFrame) / beat) * beat).toLong() else pos
        val base = (deck % 2) * 4
        val slot = (base until base + 4).firstOrNull { !_pads.value[it].ready } ?: (base + 3)
        viewModelScope.launch(Dispatchers.Default) {
            if (!NativeEngine.nativeCaptureSample(deck, slot, start.coerceAtLeast(0L), (4 * beat).toLong())) { say("Não consegui capturar."); return@launch }
            sentSpeed[slot] = 1f; NativeEngine.nativeSetSampleSpeed(slot, 1f)
            _pads.update { l -> l.mapIndexed { i, p -> if (i == slot) PadUi("${deckName(deck)} · CAPTURA · ${d.title.take(12)}", true, true, false, if (d.hasBpm) d.bpm else 0.0) else p } }
            say("Compasso capturado no pad ${slot + 1}: toque para repetir em loop no ritmo.")
        }
    }

    /** INSTANT DOUBLE: a mesma música do outro deck, no mesmo ponto e andamento (para scratch e manobras). */
    fun instantDouble(deck: Int) {
        val other = (deck xor 1)
        val o = _decks.value[other]
        if (!o.loaded || o.trackId < 0) { say("O deck ${deckName(other)} está vazio."); return }
        viewModelScope.launch {
            val row = allTracks().firstOrNull { it.id == o.trackId } ?: return@launch
            if (!loadTrackAndWait(deck, row)) return@launch
            val now = _decks.value[other]
            setRateExact(deck, now.rate)
            NativeEngine.nativeSeek(deck, posOf(other))
            if (now.playing) NativeEngine.nativePlay(deck)
            say("Deck ${deckName(deck)} dobrou o ${deckName(other)}: mesma música, mesmo ponto.")
        }
    }

    /** Chamado quando a análise de uma música nova termina: renova os pads do deck se o modo automático estiver ligado. */
    private fun refreshAutoSamples(deck: Int) {
        if (!autoSamples[deck]) return
        viewModelScope.launch(Dispatchers.Default) {
            val n = buildSamplesNow(deck)
            if (n > 0) say("Pads ${if (deck % 2 == 0) "1–4" else "5–8"}: $n amostras novas de ${_decks.value[deck].title}.")
        }
    }

    fun clearSamples() {
        autoSamples.fill(false)
        sentSpeed.fill(1f)
        NativeEngine.nativeClearSamples()
        _pads.value = List(8) { PadUi() }
    }

    /** Deck que manda no andamento: o que está tocando (se os dois, o do lado do crossfader). */
    private fun leadDeck(): Int? {
        val d = _decks.value
        val p = (0 until DECKS).filter { d[it].playing && d[it].hasBpm }
        if (p.isEmpty()) return null
        if (p.size == 1) return p[0]
        val side = if (_crossfader.value <= 0.5f) 0 else 1
        return p.firstOrNull { it % 2 == side } ?: p[0]
    }

    /** Velocidade para o trecho seguir o andamento do deck que está tocando (1, ou o múltiplo mais perto). */
    private fun padSpeed(pad: PadUi): Float {
        val lead = leadDeck() ?: return 1f
        if (pad.bpm <= 0.0) return 1f
        val target = _decks.value[lead].playedBpm
        var best = 1.0
        var err = Double.MAX_VALUE
        for (k in doubleArrayOf(1.0, 2.0, 0.5)) {
            val s = target / (pad.bpm * k)
            if (kotlin.math.abs(s - 1.0) < err) { err = kotlin.math.abs(s - 1.0); best = s }
        }
        return best.toFloat().coerceIn(0.5f, 2f)
    }

    /** Quadros até a próxima batida do deck que está tocando (0 se acabou de passar uma, ou se nada toca). */
    private fun framesToNextBeat(): Long {
        val lead = leadDeck() ?: return 0L
        val d = _decks.value[lead]
        val beat = 60.0 * NativeEngine.SAMPLE_RATE / d.bpm
        val pos = _live.value.decks[lead].positionFrames.toDouble()
        val phase = posMod(pos - d.firstBeatFrame, beat)
        val rate = d.rate.toDouble().coerceAtLeast(0.1)
        if (phase / rate < 0.03 * NativeEngine.SAMPLE_RATE) return 0L      // tocou logo depois da batida: entra já
        return ((beat - phase) / rate).toLong()
    }

    private val sentSpeed = FloatArray(8) { 1f }

    /** Mantém os pads no andamento do deck que está tocando (chamado pela leitura periódica). */
    private fun syncPadSpeeds() {
        val pads = _pads.value
        for (i in pads.indices) {
            if (!pads[i].ready) continue
            val s = padSpeed(pads[i])
            if (kotlin.math.abs(s - sentSpeed[i]) > 0.0005f) {
                sentSpeed[i] = s
                NativeEngine.nativeSetSampleSpeed(i, s)
            }
        }
    }

    /** Pad de golpe toca uma vez; pad de loop liga e desliga o loop. Entra na próxima batida, no andamento do deck. */
    fun padPress(slot: Int) {
        val pad = _pads.value.getOrNull(slot) ?: return
        if (!pad.ready) { say("Pad vazio. Toque em AMOSTRAR para gerar os trechos das músicas dos decks."); return }
        if (pad.loop && pad.playing) { NativeEngine.nativeStopSample(slot); return }
        syncPadSpeeds()
        // sons prontos (sem andamento) tocam na hora; trechos das músicas entram na próxima batida
        NativeEngine.nativeTriggerSampleAt(slot, pad.loop, if (pad.bpm > 0.0 || pad.loop) framesToNextBeat() else 0L)
    }

    // ------------------------------------------------------------------ MICROFONE E TALKOVER

    /** A tela principal coloca aqui o que abre o pedido de permissão do microfone do Android. */
    var micPermissionRequester: (() -> Unit)? = null

    fun toggleMic() {
        if (_mic.value.on) { stopMic(); return }
        val ctx = getApplication<Application>()
        val granted = androidx.core.content.ContextCompat.checkSelfPermission(ctx, android.Manifest.permission.RECORD_AUDIO) ==
            android.content.pm.PackageManager.PERMISSION_GRANTED
        if (granted) { startMic(); return }
        val ask = micPermissionRequester
        if (ask == null) say("O Android precisa liberar o microfone para este app.") else { say("Libere o microfone na janela do Android."); ask() }
    }

    /** Resposta do pedido de permissão do Android. */
    fun onMicPermission(granted: Boolean) {
        if (granted) startMic() else say("Sem a permissão o microfone não liga. Libere em Configurações do Android › Apps › Edgard Guarda DJ Studio › Permissões.")
    }

    private fun startMic() {
        viewModelScope.launch(Dispatchers.Default) {
            if (!NativeEngine.nativeMicStart(0)) { say("Não consegui abrir o microfone. Outro app pode estar usando."); return@launch }
            applyMic(true)
            _mic.update { it.copy(on = true) }
            say("Microfone ligado. Use fone ou deixe o celular longe das caixas para não dar microfonia.")
        }
    }

    private fun stopMic() {
        NativeEngine.nativeMicStop()
        _mic.update { it.copy(on = false) }
        say("Microfone desligado.")
    }

    private fun applyMic(on: Boolean) {
        val m = _mic.value
        NativeEngine.nativeSetMicOn(on)
        NativeEngine.nativeSetMicGain(m.gain)
        NativeEngine.nativeSetTalkover(if (m.talkover) m.talkAmount else 0f)
    }

    fun setMicGain(g: Float) {
        val v = g.coerceIn(0f, 2f)
        _mic.update { it.copy(gain = v) }
        NativeEngine.nativeSetMicGain(v)
        outPrefs.edit().putFloat("micGain", v).apply()
    }

    fun setTalkAmount(a: Float) {
        val v = a.coerceIn(0f, 0.9f)
        _mic.update { it.copy(talkAmount = v) }
        if (_mic.value.talkover) NativeEngine.nativeSetTalkover(v)
        outPrefs.edit().putFloat("talkAmount", v).apply()
    }

    fun toggleTalkover() {
        val on = !_mic.value.talkover
        _mic.update { it.copy(talkover = on) }
        NativeEngine.nativeSetTalkover(if (on) _mic.value.talkAmount else 0f)
        outPrefs.edit().putBoolean("talkover", on).apply()
        say(if (on) "TALKOVER ligado: a música abaixa quando você fala no microfone." else "TALKOVER desligado: a música não abaixa.")
    }

    fun setSamplerVolume(v: Float) {
        _samplerVol.value = v
        NativeEngine.nativeSetSamplerVolume(v)
    }

    // ------------------------------------------------- análise da biblioteca

    private val _analysisProgress = MutableStateFlow<String?>(null)
    /** Texto de andamento da análise em lote ("3 de 20"), ou null quando parada. */
    val analysisProgress: StateFlow<String?> = _analysisProgress.asStateFlow()
    private var analyzeJob: Job? = null

    /** Analisa andamento e tom de todas as faixas da biblioteca que ainda não foram analisadas. */
    fun analyzeLibrary() {
        if (analyzeJob?.isActive == true) {
            analyzeJob?.cancel()
            _analysisProgress.value = null
            return
        }
        analyzeJob = viewModelScope.launch {
            try {
                val n = analyzeMissing { done, total -> _analysisProgress.value = "$done de $total" }
                say(if (n == 0) "Todas as faixas já foram analisadas." else "Análise concluída: $n faixa(s).")
            } finally {
                _analysisProgress.value = null
            }
        }
    }

    /** Analisa (andamento e tom) as faixas que faltam. Devolve quantas analisou. Usado também pelo AUTO DJ. */
    suspend fun analyzeMissing(progress: (Int, Int) -> Unit): Int {
        val todo = withContext(Dispatchers.IO) { db.unanalyzed() }
        val done = java.util.concurrent.atomic.AtomicInteger(0)
        // duas músicas ao mesmo tempo: a leitura do arquivo e a análise usam núcleos diferentes
        val gate = kotlinx.coroutines.sync.Semaphore(2)
        coroutineScope {
            for (row in todo) {
                launch {
                    gate.acquire()
                    try {
                        progress(done.get() + 1, todo.size)
                        analyzeOne(row)
                        done.incrementAndGet()
                        libraryVersion.update { it + 1 }
                    } finally {
                        gate.release()
                    }
                }
            }
        }
        return done.get()
    }

    private suspend fun analyzeOne(row: TrackRow) {
        val r = TrackDecoder.decode(getApplication(), Uri.parse(row.uri), 4) { }
        if (r is DecodeResult.Ready) {
            try {
                withContext(Dispatchers.Default) {
                    NeuralStems.workPriority()
                    var a = db.analysis(row.id)
                    if (a == null) {
                        val out = DoubleArray(3)
                        NativeEngine.nativeAnalyze(r.trackHandle, out)
                        a = withDownbeat(Analysis(out[0], out[1].toLong(), out[2].toFloat()), r.trackHandle)
                    }
                    if (a.keyTonic < 0) {
                        val k = IntArray(4)
                        NativeEngine.nativeAnalyzeKey(r.trackHandle, k)
                        a = if (k[0] == 1) a.copy(keyTonic = k[1], keyMinor = k[2] == 1, keyConf = k[3] / 1000f)
                        else a.copy(keyTonic = 0, keyMinor = false, keyConf = 0f)
                    }
                    if (a.energy < 0f) a = a.copy(energy = NativeEngine.nativeAnalyzeEnergy(r.trackHandle).coerceAtLeast(0f))
                    db.saveAnalysis(row.id, a)
                }
            } finally {
                NativeEngine.nativeFreeTrack(r.trackHandle)
            }
        } else {
            // arquivo ilegível: marca como analisado sem andamento, para não tentar de novo para sempre
            withContext(Dispatchers.IO) { db.saveAnalysis(row.id, Analysis(0.0, 0L, 0f, keyTonic = 0, keyMinor = false, keyConf = 0f, energy = 0f)) }
        }
    }

    /** Todas as faixas da biblioteca, com o que já foi analisado (para o AUTO DJ). */
    suspend fun allTracks(): List<TrackRow> = withContext(Dispatchers.IO) { db.query("", SortOrder.RECENT) }

    /** Carrega a faixa no deck e espera terminar. Devolve false se falhou. */
    suspend fun loadTrackAndWait(deck: Int, row: TrackRow): Boolean {
        loadTrack(deck, row)
        var waited = 0
        while (waited < 1200) {                      // até 120 s (com os stems da IA no outro deck a carga pode demorar)
            delay(100)
            waited++
            val d = _decks.value[deck]
            if (!d.loading && !d.analyzing) return d.loaded && d.trackId == row.id
        }
        return false
    }

    init {
        NeuralStems.deckPlaying = { _decks.value.any { it.playing } }
        midi.start()
        router.start()
        // O motor C++ vive no processo, não na Activity: se a tela foi fechada e reaberta sem o processo
        // morrer, ele ainda guarda as faixas e o estado de tocar da vez anterior. Começamos do zero.
        for (d in 0 until DECKS) {
            NativeEngine.nativeUnload(d)
            NativeEngine.nativeSetRate(d, 1f)
            NativeEngine.nativeSetFilter(d, 0.5f)
            NativeEngine.nativeSetFx(d, 0, 0.5f, 0.5f)
            NativeEngine.nativeClearLoop(d)
            NativeEngine.nativeSetKeyLock(d, false)
            NativeEngine.nativeSetHeadphoneCue(d, false)
            for (b in 0..2) NativeEngine.nativeSetEq(d, b, 0.5f)
        }
        startPolling()
        loadBuiltinPads(quiet = true)
        backfillGenres()
    }

    /** Coloca nos 8 pads os sons prontos de DJ (buzina, sirene, laser, 808, palma, subida, descida, explosão). */
    fun loadBuiltinPads(quiet: Boolean = false) {
        viewModelScope.launch(Dispatchers.Default) {
            autoSamples.fill(false)
            val n = NativeEngine.nativeLoadBuiltinSamples()
            sentSpeed.fill(1f)
            for (i in 0 until 8) NativeEngine.nativeSetSampleSpeed(i, 1f)
            _pads.value = List(8) { i -> if (i < n) PadUi(label = BUILTIN_NAMES[i], loop = false, ready = true) else PadUi() }
            if (!quiet) say("Sons prontos nos pads: ${BUILTIN_NAMES.joinToString(", ")}.")
        }
    }

    /**
     * Chamado pela Activity em onStart (true) e onStop (false). Sem serviço em primeiro plano o Android
     * não garante áudio em segundo plano, então ao sair o app pausa os decks e fecha a saída de áudio.
     */
    private var lastCallbacks = -1
    private var stalledChecks = 0
    private var audioStartedAt = 0L

    /**
     * Vigia da saída de áudio (cerca de 1 vez por segundo): se o som parou de ser pedido (controladora USB tirada,
     * fone trocado, Android fechou a saída) e não voltou sozinho em 2 segundos, reabre a saída.
     */
    /** Quantas vezes o vigia religou o som nesta sessão. */
    private var audioRestarts = 0

    private fun audioWatchdog() {
        if (!foreground || android.os.SystemClock.uptimeMillis() - audioStartedAt < 3000) return
        val c = NativeEngine.nativeAudioCallbacks()
        if (c == lastCallbacks) stalledChecks++ else stalledChecks = 0
        lastCallbacks = c
        if (stalledChecks >= 2) {
            stalledChecks = 0
            audioStartedAt = android.os.SystemClock.uptimeMillis()
            viewModelScope.launch(Dispatchers.Default) {
                NativeEngine.nativeRestartAudio()
                refreshAudioStatus()
            }
            audioRestarts++
            ErrorLog.add("som", "saída de áudio parou; religada pelo vigia")
            say("A saída de som tinha parado (controladora ou fone desconectado). Som religado.")
        }
    }

    fun onForeground(on: Boolean) {
        foreground = on
        stopJob?.cancel()
        if (on) {
            startAudio()
        } else {
            NativeEngine.nativePause(0)
            NativeEngine.nativePause(1)
            stopJob = viewModelScope.launch(Dispatchers.Default) {
                delay(150) // deixa a rampa de 4 ms da pausa terminar antes de fechar o fluxo
                if (!foreground) NativeEngine.nativeStop()
            }
        }
    }

    private fun startAudio() {
        audioStartedAt = android.os.SystemClock.uptimeMillis()
        // Abrir o fluxo exclusivo do Oboe pode demorar: fora da thread principal.
        viewModelScope.launch(Dispatchers.Default) {
            NativeEngine.nativeSetLatency(_latency.value)
            NativeEngine.nativeSetStemStrength(_stemStrength.value * 0.5f)
            configureOutputNow()
            val ok = NativeEngine.nativeStart()
            if (ok) {
                NativeEngine.nativeSetHeadphoneLevel(_hpLevel.value)
                NativeEngine.nativeSetHeadphoneMix(_hpMix.value)
                NativeEngine.nativeSetMaster(_master.value)
                NativeEngine.nativeSetCrossfader(_crossfader.value)
                NativeEngine.nativeSetCrossfaderCurve(_xfCurve.value)
                for (d in 0 until DECKS) NativeEngine.nativeSetVolume(d, _volumes.value[d])
                // o microfone fecha junto com o som (app em segundo plano): ao voltar, reabre se estava ligado
                if (_mic.value.on) { if (NativeEngine.nativeMicStart(0)) applyMic(true) else _mic.update { it.copy(on = false) } }
                refreshAudioStatus()
            } else {
                _audioStatus.value = "Sem áudio"
                say("Não consegui abrir a saída de áudio do aparelho.")
            }
        }
    }

    private fun refreshAudioStatus() {
        val info = IntArray(8)
        NativeEngine.nativeStreamInfo(info)
        val bufferMs = if (info[0] > 0) info[2] * 1000f / info[0] else 0f
        val outs = router.devices.value
        val mainName = outs.firstOrNull { it.id == info[6] }?.label ?: "saída padrão do Android"
        _audioStatus.value = "%d Hz · buffer %.0f ms · %s".format(java.util.Locale.ROOT, info[0], bufferMs, mainName)
        val want = _outMode.value
        val got = info[5]
        val fone = when {
            want == 0 && splitOnSpeaker -> "Pré-escuta separada escolhida (dividido ou 4 canais), mas o som está saindo pelo alto-falante do celular: tocando normal nos dois lados. A pré-escuta separada volta sozinha quando você ligar um fone, caixa ou controladora."
            want == 0 -> "Sem fone de pré-escuta na saída principal."
            got == 2 -> "Fone da controladora ativo: canais 1-2 som geral, 3-4 fone."
            got == 1 && want == 2 -> "A saída não abriu 4 canais; usando o modo dividido (esquerdo = fone, direito = som geral)."
            got == 1 -> "Modo dividido: o lado esquerdo leva o fone e o direito o som geral (mono)."
            else -> "Não consegui abrir a saída escolhida; voltei à saída padrão."
        }
        val mirror = when {
            _mirrorDevice.value == 0 -> ""
            info[7] == 1 -> " Segunda saída tocando (${if (_mirrorWhat.value == 1) "fone" else "som geral"}): ${outs.firstOrNull { it.id == _mirrorDevice.value }?.label ?: ""}."
            else -> " A segunda saída não abriu (ou é a mesma da principal)."
        }
        _outNote.value = fone + mirror
    }

    /** Saída principal: a escolhida; no automático, a controladora (USB) se estiver ligada, senão a do celular. */
    private fun resolveDevice(): Int {
        val list = router.devices.value
        val pick = _outDevice.value
        return list.firstOrNull { it.id == pick }?.id ?: list.firstOrNull { it.isUsb }?.id ?: 0
    }

    /** Modo do fone: o escolhido; no automático, 4 canais se a saída principal tiver 4 (DJ2GO2), senão sem fone. */
    private fun resolveMode(dev: Int): Int {
        val p = _outModePref.value
        val list = router.devices.value
        val o = list.firstOrNull { it.id == dev }
        // modo dividido no alto-falante do celular não faz sentido (um lado tocaria a pré-escuta para todo mundo):
        // sem fone, caixa ou controladora ligados, toca normal; o modo dividido volta sozinho quando ligar um
        val speakerOnly = if (o != null) o.kind == app.djfusion.audio.AudioOut.Kind.SPEAKER else list.none { it.kind != app.djfusion.audio.AudioOut.Kind.SPEAKER }
        // vale também para o modo 4 CANAIS: sem placa de som externa ele cairia no dividido no alto-falante
        splitOnSpeaker = (p == 1 || p == 2) && speakerOnly
        if (splitOnSpeaker) return 0
        if (p >= 0) return p
        return if (o != null && o.isUsb && o.channels >= 4) 2 else 0
    }

    /** O DJ escolheu o modo dividido, mas o som está saindo só pelo alto-falante do celular. */
    @Volatile private var splitOnSpeaker = false

    private fun configureOutputNow() {
        val dev = resolveDevice()
        val mode = resolveMode(dev)
        _outMode.value = mode
        val mirror = _mirrorDevice.value.takeIf { m -> router.devices.value.any { it.id == m } } ?: 0
        NativeEngine.nativeConfigureOutput(mode, dev, mirror, _mirrorWhat.value)
    }

    /** Reaplica a saída (modo ou aparelho mudou, ou um aparelho entrou ou saiu). */
    private fun applyOutput() {
        viewModelScope.launch(Dispatchers.Default) {
            configureOutputNow()
            delay(300)
            if (foreground) refreshAudioStatus()
        }
    }

    fun setOutputMode(mode: Int) {
        _outModePref.value = mode.coerceIn(0, 2)
        outPrefs.edit().putInt("mode2", _outModePref.value).apply()
        applyOutput()
    }

    fun setOutputDevice(id: Int) {
        _outDevice.value = id
        outPrefs.edit().putInt("device2", id).apply()
        applyOutput()
    }

    /** Segunda saída tocando junto ([id] 0 = desligada); [what] 0 = som geral, 1 = fone (pré-escuta). */
    fun setMirror(id: Int, what: Int = _mirrorWhat.value) {
        _mirrorDevice.value = id
        _mirrorWhat.value = what
        outPrefs.edit().putInt("mirror", id).putInt("mirrorWhat", what).apply()
        applyOutput()
    }

    fun toggleKeyLock(deck: Int) {
        val on = !_decks.value[deck].keyLock
        setDeck(deck) { it.copy(keyLock = on) }
        NativeEngine.nativeSetKeyLock(deck, on)
    }

    fun setPadMode(deck: Int, mode: Int) {
        setDeck(deck) { it.copy(padMode = mode.coerceIn(0, 7), padsOpen = true, stemsOpen = false) }
    }

    fun togglePads(deck: Int) {
        setDeck(deck) { it.copy(padsOpen = !it.padsOpen, stemsOpen = false) }
    }

    fun toggleHeadphoneCue(deck: Int) {
        val on = !_decks.value[deck].cueOn
        setDeck(deck) { it.copy(cueOn = on) }
        NativeEngine.nativeSetHeadphoneCue(deck, on)
    }

    fun setHeadphoneLevel(v: Float) {
        _hpLevel.value = v
        NativeEngine.nativeSetHeadphoneLevel(v)
    }

    fun setHeadphoneMix(v: Float) {
        _hpMix.value = v
        NativeEngine.nativeSetHeadphoneMix(v)
    }

    /** Prato tocado: [velocity] em múltiplos da velocidade normal. */
    /** O prato da controladora pegou o disco (SLIP começa a contar). */
    fun jogScratchBegin(deck: Int) = slipBegin(deck)

    /** O prato da controladora soltou o disco. */
    fun jogScratchEnd(deck: Int) {
        NativeEngine.nativeScratch(deck, false, 0f)
        slipEnd(deck)
    }

    /**
     * Prato da tela por posição: [revs] voltas giradas (+ frente). No meio do disco é scratch exato;
     * na borda com a música tocando ([rim]) empurra/segura a batida.
     */
    fun platterMove(deck: Int, revs: Float, rim: Boolean) {
        val d = _decks.value[deck]
        if (!d.loaded || d.loading) return
        if (rim) { NativeEngine.nativeNudge(deck, revs * 0.3 * NativeEngine.SAMPLE_RATE * jog.bendGain); return }
        if (revs == 0f) { jog.stopCoast(deck); slipBegin(deck) }
        NativeEngine.nativeScratchMove(deck, revs * 1.8 * NativeEngine.SAMPLE_RATE)
    }

    /** O dedo soltou o prato da tela girando: para trás e rápido vira BACKSPIN (devolve true se tratou). */
    fun platterFling(deck: Int, speed: Float): Boolean = jog.fling(deck, speed)

    /** Empurra (+) ou segura (-) a música [frames] quadros com ela tocando (arrastar a onda, jog). */
    fun nudge(deck: Int, frames: Double) = NativeEngine.nativeNudge(deck, frames)

    /** Arrastar a onda com a música parada: anda [frames] quadros (procura o ponto exato). */
    fun scrubBy(deck: Int, frames: Long) {
        val d = _decks.value[deck]
        if (!d.loaded || d.loading) return
        // a busca no motor só vale no próximo bloco de áudio: somamos ao alvo anterior para não perder passos do arrasto
        val now = android.os.SystemClock.uptimeMillis()
        val base = if (now - scrubAt[deck] < 250) scrubTarget[deck] else posOf(deck)
        val target = (base + frames).coerceIn(0L, (d.lengthFrames - 1).coerceAtLeast(0L))
        scrubTarget[deck] = target; scrubAt[deck] = now
        NativeEngine.nativeSeek(deck, target)
    }
    private val scrubTarget = LongArray(DECKS)
    private val scrubAt = LongArray(DECKS)

    /** Muda o que o prato faz neste deck (PRATO, BUSCA, GRADE, LOOP saída/entrada, FX, LISTA) e avisa. */
    fun cycleJogMode(deck: Int) {
        val m = jog.cycleMode(deck)
        say("Prato do deck ${deckName(deck)}: ${JogController.MODE_NAMES[m]}. ${JogController.MODE_HELP[m]}")
    }

    /** Ajuste fino do loop pelo prato: move a saída ([edge] = 1) ou a entrada (0) em [frames] quadros. */
    fun loopAdjust(deck: Int, frames: Long, edge: Int) {
        val reg = _loopRegion.value[deck]
        if (reg == null) { say("Ligue um loop primeiro para ajustar."); return }
        val d = _decks.value[deck]
        val minLen = (NativeEngine.SAMPLE_RATE / 50).toLong()
        var a = reg.first
        var b = reg.second
        if (edge == 1) b = (b + frames).coerceIn(a + minLen, maxOf(a + minLen, d.lengthFrames - 1))
        else a = (a + frames).coerceIn(0L, b - minLen)
        setLoopNative(deck, a, b)
        loopInAt[deck] = a
        loopOutAt[deck] = b
        setDeck(deck) { it.copy(loopBeats = -1) }
        pubLoop()
    }

    /** Loop pela metade ou em dobro, mantendo o início (½ e ×2). */
    fun loopResize(deck: Int, factor: Double) {
        val d = _decks.value[deck]
        val reg = _loopRegion.value[deck]
        if (!d.hasBpm || reg == null || d.loopBeats <= 0) { say("Ligue um loop primeiro."); return }
        val beat = 60.0 * NativeEngine.SAMPLE_RATE / d.bpm
        val nb = (d.loopBeats * factor)
        if (nb < 0.25 || nb > 32) return
        val end = reg.first + nb * beat
        if (end > d.lengthFrames) { say("Perto demais do fim para dobrar o loop."); return }
        if (nb < 1.0) {   // menos de 1 batida vira loop fracionado (ROLL); aqui fica no mínimo 1
            return
        }
        setLoopNative(deck, reg.first, end.toLong())
        setDeck(deck) { it.copy(loopBeats = nb.toInt()) }
        say("Loop de ${nb.toInt()} batida(s) no deck ${deckName(deck)}.")
    }

    fun scratch(deck: Int, active: Boolean, velocity: Float) {
        if (active && slipFrom[deck] == null) slipBegin(deck)
        NativeEngine.nativeScratch(deck, active, velocity)
        if (!active) slipEnd(deck)
    }

    // ------------------------------------------------------------------ SLIP, REVERSO e CENSURA

    /** Onde a música estaria: posição e hora em que o desvio começou (só com SLIP ligado e tocando). */
    private val slipFrom = arrayOfNulls<Pair<Long, Long>>(DECKS)

    private fun slipBegin(deck: Int) {
        val d = _decks.value[deck]
        if (!d.slip || !d.playing || slipFrom[deck] != null) return
        val st = LongArray(4)
        NativeEngine.nativeDeckState(deck, st)
        slipFrom[deck] = st[1] to android.os.SystemClock.elapsedRealtime()
    }

    private fun slipEnd(deck: Int) {
        val from = slipFrom[deck] ?: return
        slipFrom[deck] = null
        val d = _decks.value[deck]
        val elapsed = android.os.SystemClock.elapsedRealtime() - from.second
        val target = from.first + (elapsed / 1000.0 * NativeEngine.SAMPLE_RATE * d.rate).toLong()
        if (target in 0 until d.lengthFrames) NativeEngine.nativeSeek(deck, target)
    }


    // ---- SLICER: 8 fatias de 1 batida; toque numa fatia para saltar; SOLTAR volta onde a música estaria ----
    private val sliceStart = LongArray(4) { -1L }
    private val sliceFrom = arrayOfNulls<Pair<Long, Long>>(4)

    /** Fixa a janela de 8 batidas a partir da batida mais próxima atrás da posição atual. */
    fun sliceSet(deck: Int) {
        val d = _decks.value[deck]
        if (!d.loaded || d.loading) { say("Carregue uma música no deck ${deckName(deck)} primeiro."); return }
        if (!d.hasBpm) { say("O slicer precisa do andamento detectado."); return }
        val beat = 60.0 * NativeEngine.SAMPLE_RATE / d.bpm
        val pos = _live.value.decks[deck].positionFrames
        val n = Math.floor((pos - d.firstBeatFrame) / beat)
        sliceStart[deck] = (d.firstBeatFrame + n * beat).toLong().coerceAtLeast(0L)
        say("SLICER do deck ${deckName(deck)}: 8 fatias a partir daqui.")
    }

    fun slicePress(deck: Int, i: Int) {
        val d = _decks.value[deck]
        if (!d.loaded || d.loading || !d.hasBpm) { say("O slicer precisa de música com andamento detectado."); return }
        if (sliceStart[deck] < 0) sliceSet(deck)
        if (sliceStart[deck] < 0) return
        if (sliceFrom[deck] == null && d.playing) {
            val st = LongArray(4); NativeEngine.nativeDeckState(deck, st)
            sliceFrom[deck] = st[1] to android.os.SystemClock.elapsedRealtime()
        }
        val beat = 60.0 * NativeEngine.SAMPLE_RATE / d.bpm
        val target = (sliceStart[deck] + i.coerceIn(0, 7) * beat).toLong().coerceIn(0L, (d.lengthFrames - 1).coerceAtLeast(0L))
        NativeEngine.nativeSeek(deck, target)
    }

    fun sliceRelease(deck: Int) {
        val from = sliceFrom[deck] ?: return
        sliceFrom[deck] = null
        val d = _decks.value[deck]
        val elapsed = android.os.SystemClock.elapsedRealtime() - from.second
        val target = from.first + (elapsed / 1000.0 * NativeEngine.SAMPLE_RATE * d.rate).toLong()
        if (target in 0 until d.lengthFrames) NativeEngine.nativeSeek(deck, target)
    }

    fun toggleSlip(deck: Int) {
        val on = !_decks.value[deck].slip
        if (!on) slipFrom[deck] = null
        setDeck(deck) { it.copy(slip = on) }
        say(if (on) "SLIP ligado no deck ${deckName(deck)}: depois de scratch, loop, reverso ou censura a música volta onde estaria."
            else "SLIP desligado no deck ${deckName(deck)}.")
    }

    /** REVERSO: toca ao contrário até tocar de novo. Com SLIP, volta ao ponto onde estaria. */
    fun toggleReverse(deck: Int) {
        val d = _decks.value[deck]
        if (!d.loaded || d.loading) { say("Carregue uma música no deck ${deckName(deck)} primeiro."); return }
        if (d.reverse) {
            NativeEngine.nativeScratch(deck, false, 0f)
            setDeck(deck) { it.copy(reverse = false) }
            slipEnd(deck)
        } else {
            if (!d.playing) { say("REVERSO precisa do deck ${deckName(deck)} tocando."); return }
            slipBegin(deck)
            NativeEngine.nativeScratch(deck, true, -d.rate)
            setDeck(deck) { it.copy(reverse = true) }
        }
    }

    /** CENSURA: 2 batidas ao contrário e volta exatamente onde a música estaria (SLIP automático). */
    fun censor(deck: Int) {
        val d = _decks.value[deck]
        if (!d.playing) { say("CENSURA precisa do deck ${deckName(deck)} tocando."); return }
        if (d.reverse) return
        val beatMs = if (d.hasBpm) (60000.0 / d.playedBpm).toLong() else 500L
        val st = LongArray(4)
        NativeEngine.nativeDeckState(deck, st)
        val from = st[1]
        val t0 = android.os.SystemClock.elapsedRealtime()
        runFx(deck) {
            setDeck(deck) { it.copy(reverse = true) }
            NativeEngine.nativeScratch(deck, true, -d.rate)
            delay(beatMs * 2)
            NativeEngine.nativeScratch(deck, false, 0f)
            val elapsed = android.os.SystemClock.elapsedRealtime() - t0
            NativeEngine.nativeSeek(deck, from + (elapsed / 1000.0 * NativeEngine.SAMPLE_RATE * d.rate).toLong())
            setDeck(deck) { it.copy(reverse = false) }
        }
    }

    // ------------------------------------------------------------------ STEMS

    private var neuralHintShown = false

    fun toggleStems(deck: Int) {
        val opening = !_decks.value[deck].stemsOpen
        setDeck(deck) { it.copy(stemsOpen = !it.stemsOpen, padsOpen = false) }
        if (opening && !_neural.value.ready && !neuralHintShown) {
            neuralHintShown = true
            say("Os stems estão usando o separador comum (som mais fraco). Para a IA, baixe o modelo em AJUSTES › STEMS COM IA (80 MB, uma vez) e recarregue a música.")
        }
    }

    /** Ganho de um stem (0 voz, 1 bateria, 2 baixo, 3 melodia). */
    fun setStemGain(deck: Int, stem: Int, gain: Float) {
        if (stem !in 0..3) return
        val d = _decks.value[deck]
        if (!d.stemsReady) {
            say(
                when {
                    d.stemProgress >= 0f -> "Stems ainda separando (${(d.stemProgress * 100).toInt()}%)."
                    d.stemProgress < -1.5f -> "Stems indisponíveis nesta música (longa demais ou pouca memória)."
                    else -> "Carregue uma música para separar os stems."
                },
            )
            return
        }
        val g = gain.coerceIn(0f, 1f)
        setDeck(deck) { it.copy(stemGains = it.stemGains.mapIndexed { i, old -> if (i == stem) g else old }) }
        NativeEngine.nativeSetStemGain(deck, stem, g)
    }

    fun toggleStem(deck: Int, stem: Int) {
        val g = _decks.value[deck].stemGains.getOrNull(stem) ?: return
        setStemGain(deck, stem, if (g > 0.5f) 0f else 1f)
    }

    /** ACAPELLA (só voz), INSTRUMENTAL (sem voz) ou tudo de volta. */
    fun stemPreset(deck: Int, preset: Int) {
        val gains = when (preset) {
            1 -> listOf(1f, 0f, 0f, 0f)
            2 -> listOf(0f, 1f, 1f, 1f)
            3 -> listOf(0f, 1f, 0f, 0f)
            else -> listOf(1f, 1f, 1f, 1f)
        }
        if (!_decks.value[deck].stemsReady) { setStemGain(deck, 0, 1f); return }
        gains.forEachIndexed { i, g -> NativeEngine.nativeSetStemGain(deck, i, g) }
        setDeck(deck) { it.copy(stemGains = gains) }
    }

    /** Um deck separa de cada vez: dois ao mesmo tempo disputam o processador com a interface. */
    private val stemLock = kotlinx.coroutines.sync.Mutex()

    /**
     * Os stems ocupam 6 bytes por quadro (uma música de 5 min = ~86 MB). Só separa se couber com folga:
     * até [STEM_MAX_MINUTES] e sobrando pelo menos 300 MB de memória livre no aparelho depois.
     */
    private fun stemsFit(frames: Long): String? {
        if (frames > STEM_MAX_MINUTES * 60L * NativeEngine.SAMPLE_RATE) return "música com mais de $STEM_MAX_MINUTES min"
        val am = getApplication<Application>().getSystemService(android.content.Context.ACTIVITY_SERVICE) as android.app.ActivityManager
        val mi = android.app.ActivityManager.MemoryInfo()
        am.getMemoryInfo(mi)
        val need = frames * 6L + if (_neural.value.ready && _neural.value.on) 450L * 1024 * 1024 else 0L   // a rede neural usa ~450 MB enquanto separa
        return if (mi.lowMemory || mi.availMem - need < 300L * 1024 * 1024) "pouca memória livre no aparelho" else null
    }

    private suspend fun separateStems(deck: Int, handle: Long) = stemLock.withLock {
        val why = stemsFit(_decks.value[deck].lengthFrames)
        if (why != null) {
            setDeck(deck) { it.copy(stemProgress = -2f) }
            say("Stems desligados no deck ${deckName(deck)}: $why.")
            return@withLock
        }
        setDeck(deck) { it.copy(stemProgress = 0f) }
        val ok = coroutineScope {
            val t0 = android.os.SystemClock.uptimeMillis()
            var lastTold = 0
            val poll = launch {
                while (isActive) {
                    delay(700)
                    // de 10 em 10%: menos redesenho da tela enquanto separa
                    val raw = NeuralStems.progress(deck).takeIf { it >= 0f } ?: NativeEngine.nativeStemProgress(deck)
                    val p = (Math.floor(raw * 10.0) / 10.0).toFloat().coerceIn(0f, 0.9f)
                    // avisa a cada 20% com o tempo que falta, para não parecer travado em 0%
                    val pct = (raw * 100).toInt()
                    if (pct >= 5 && pct / 20 > lastTold / 20 || (pct >= 5 && lastTold == 0)) {
                        lastTold = pct
                        val el = (android.os.SystemClock.uptimeMillis() - t0) / 1000.0
                        val left = (el * (1.0 - raw) / raw.coerceAtLeast(0.01f)).toInt()
                        say("Stems do deck ${deckName(deck)}: $pct%" + if (left > 5) " · faltam ~${if (left >= 90) "${(left + 30) / 60} min" else "$left s"}." else ".")
                    }
                    setDeck(deck) { if (it.stemProgress in 0f..0.999f && it.stemProgress != p) it.copy(stemProgress = p) else it }
                }
            }
            val r = withContext(Dispatchers.Default) {
                android.os.Process.setThreadPriority(android.os.Process.THREAD_PRIORITY_BACKGROUND)
                // rede neural (Spleeter) se o modelo está baixado e ligado; se falhar ou faltar, o separador comum
                val ai = _neural.value.ready && _neural.value.on && NeuralStems.separate(getApplication<Application>(), handle, deck)
                when {
                    ai -> true
                    NeuralStems.wasCancelled(deck) && _neural.value.ready && _neural.value.on -> false
                    else -> NativeEngine.nativeSeparateStems(handle, deck)
                }
            }
            poll.cancel()
            r
        }
        setDeck(deck) { it.copy(stemProgress = if (ok) 1f else -1f) }
        if (ok) say("Stems prontos no deck ${deckName(deck)} (${if (NeuralStems.lastUsedAi(deck)) "IA Spleeter" else "separador comum"}): voz, bateria, baixo e melodia.")
    }

    // ------------------------------------------------------------------ TOM, AUTO-GAIN e GRADE

    /** Muda o tom em semitons sem mudar o andamento (para casar o tom com o outro deck). */
    fun setKeyShift(deck: Int, semitones: Int, remember: Boolean = true) {
        val s = semitones.coerceIn(-12, 12)
        setDeck(deck) { it.copy(keyShift = s) }
        NativeEngine.nativeSetKeyShift(deck, s.toFloat())
        // lembra o tom escolhido para esta música (volta igual na próxima vez que carregar)
        val id = _decks.value[deck].trackId
        if (remember && id >= 0) keyPrefs.edit().apply { if (s == 0) remove("t$id") else putInt("t$id", s) }.apply()
    }

    private val keyPrefs = app.getSharedPreferences("tom_por_musica", android.content.Context.MODE_PRIVATE)

    fun shiftKey(deck: Int, delta: Int) = setKeyShift(deck, _decks.value[deck].keyShift + delta)

    /** Acerta o tom deste deck para combinar com o outro (menor deslocamento que deixa compatível na roda). */
    fun matchKey(deck: Int) {
        val d = _decks.value[deck]
        val other = _decks.value[(deck xor 1)]
        val base = d.key?.let { if (d.keyLock) it else it.shifted(Camelot.semitonesFor(d.rate)) }
        val ref = other.shownKey
        if (base == null || ref == null) { say("Os dois decks precisam do tom detectado."); return }
        var best = 0
        var bestScore = Double.MAX_VALUE
        for (s in -6..6) {
            val sc = MixAdvisor.keyRelation(ref, base.shifted(s)).keyScore + kotlin.math.abs(s) * 0.05
            if (sc < bestScore) { bestScore = sc; best = s }
        }
        setKeyShift(deck, best)
        say("Tom do deck ${deckName(deck)} ${if (best == 0) "já combina" else "ajustado em ${if (best > 0) "+" else ""}$best semitons"}.")
    }

    private val _autoGain = MutableStateFlow(outPrefs.getBoolean("autoGain", true))
    val autoGain: StateFlow<Boolean> = _autoGain.asStateFlow()

    fun toggleAutoGain() {
        val on = !_autoGain.value
        _autoGain.value = on
        outPrefs.edit().putBoolean("autoGain", on).apply()
        for (d in 0 until DECKS) applyTrim(d)
        say(if (on) "AUTO-GAIN ligado: as músicas tocam com o mesmo volume." else "AUTO-GAIN desligado.")
    }

    private fun applyTrim(deck: Int) {
        val d = _decks.value[deck]
        val t = if (_autoGain.value && d.loudness < -1f) Math.pow(10.0, (TARGET_DB - d.loudness) / 20.0).toFloat().coerceIn(0.25f, 2.5f) else 1f
        NativeEngine.nativeSetTrim(deck, t)
        setDeck(deck) { it.copy(trim = t) }
    }

    /** Move a grade de batidas [dir] passos de 5 ms (acerta onde cai a batida). Salva na biblioteca. */
    fun nudgeGrid(deck: Int, dir: Int) {
        val d = _decks.value[deck]
        if (!d.hasBpm || d.trackId < 0) { say("A grade precisa do andamento detectado."); return }
        val step = NativeEngine.SAMPLE_RATE / 200
        val beat = (60.0 * NativeEngine.SAMPLE_RATE / d.bpm).toLong().coerceAtLeast(1)
        val bar = beat * 4    // mantém o "1" do compasso no lugar
        val nf = ((d.firstBeatFrame + dir * step) % bar + bar) % bar
        setDeck(deck) { it.copy(firstBeatFrame = nf) }
        saveGrid(d.trackId, d.bpm, nf)
    }

    /** Ajusta a grade para que a batida 0 seja o "1" do compasso (detectado pelo bumbo e pelas entradas). */
    private fun withDownbeat(a: Analysis, h: Long): Analysis {
        if (a.bpm <= 0.0) return a
        return try {
            val beat = 60.0 * NativeEngine.SAMPLE_RATE / a.bpm
            val o = app.djfusion.harmony.TrackShape.downbeatOffset(NativeEngine.nativeTrackPeaks(h), a.firstBeatFrame, beat)
            if (o == 0) a else a.copy(firstBeatFrame = (a.firstBeatFrame + o * beat).toLong())
        } catch (_: Throwable) { a }
    }

    /** Marca o "1" (início do compasso e da frase de 16) exatamente onde a música está agora. */
    fun downbeatHere(deck: Int) {
        val d = _decks.value[deck]
        if (!d.hasBpm || d.trackId < 0) { say("A grade precisa do andamento detectado."); return }
        val pos = posOf(deck)
        val phrase = 16.0 * 60.0 * NativeEngine.SAMPLE_RATE / d.bpm
        val nf = (pos - Math.floor(pos / phrase) * phrase).toLong()
        setDeck(deck) { it.copy(firstBeatFrame = nf) }
        saveGrid(d.trackId, d.bpm, nf)
        say("Deck ${deckName(deck)}: o 1 do compasso agora está aqui.")
    }

    /** Ajuste fino do andamento da grade (BPM), mantendo a batida que está tocando no lugar. */
    fun adjustBpm(deck: Int, delta: Double) {
        val d = _decks.value[deck]
        if (!d.hasBpm || d.trackId < 0) { say("A grade precisa do andamento detectado."); return }
        val nb = (d.bpm + delta).coerceIn(40.0, 250.0)
        val pos = posOf(deck).toDouble()
        val oldBeat = 60.0 * NativeEngine.SAMPLE_RATE / d.bpm
        val k = Math.round((pos - d.firstBeatFrame) / oldBeat)
        val anchor = d.firstBeatFrame + k * oldBeat              // batida mais perto de agora fica parada
        val newBeat = 60.0 * NativeEngine.SAMPLE_RATE / nb
        val bar = newBeat * 4
        val nf = ((anchor - (k.mod(4L)) * newBeat) % bar + bar) % bar
        setDeck(deck) { it.copy(bpm = nb, firstBeatFrame = nf.toLong()) }
        saveGrid(d.trackId, nb, nf.toLong())
        pushFx(deck)
    }

    private val _jumpSize = MutableStateFlow(outPrefs.getInt("jump", 4).let { if (it in JUMP_SIZES) it else 4 })
    /** Tamanho do salto de batida (1 a 32). */
    val jumpSize: StateFlow<Int> = _jumpSize.asStateFlow()
    fun setJumpSize(n: Int) {
        if (n !in JUMP_SIZES) return
        _jumpSize.value = n
        outPrefs.edit().putInt("jump", n).apply()
    }

    /** Dobra ou corta pela metade o andamento detectado (erro comum de detecção). */
    fun scaleBpm(deck: Int, factor: Double) {
        val d = _decks.value[deck]
        if (d.bpm <= 0 || d.trackId < 0) return
        val nb = d.bpm * factor
        if (nb < 50 || nb > 220) { say("Andamento fora da faixa (50 a 220 BPM)."); return }
        setDeck(deck) { it.copy(bpm = nb, bpmConfidence = kotlin.math.max(it.bpmConfidence, 1f)) }
        saveGrid(d.trackId, nb, d.firstBeatFrame)
        pushFx(deck)
        say(String.format(java.util.Locale.ROOT, "Andamento do deck %s: %.1f BPM.", deckName(deck), nb))
    }

    private fun saveGrid(id: Long, bpm: Double, first: Long) {
        // grade corrigida à mão vale mais que a automática: a GRADE INTELIGENTE deixa de mexer nesta música
        tempoPrefs.edit().putString("tm$id", "m").apply()
        for (d in 0 until DECKS) if (_decks.value[d].trackId == id && _decks.value[d].tempoSections.isNotEmpty()) {
            setDeck(d) { it.copy(tempoSections = emptyList(), tempoIdx = -1) }
        }
        viewModelScope.launch(Dispatchers.IO) {
            val a = db.analysis(id) ?: return@launch
            db.saveAnalysis(id, a.copy(bpm = bpm, firstBeatFrame = first, confidence = kotlin.math.max(a.confidence, 1f)))
        }
    }

    private fun startPolling() {
        viewModelScope.launch {
            val buf = LongArray(4)
            var tick = 0
            while (isActive) {
                if (!foreground) {
                    delay(250)
                    continue
                }
                val states = ArrayList<LongArray>(DECKS)
                val lives = ArrayList<DeckLive>(DECKS)
                for (d in 0 until DECKS) {
                    NativeEngine.nativeDeckState(d, buf)
                    states.add(buf.copyOf())
                    lives.add(DeckLive(buf[1], buf[2], NativeEngine.nativeDeckPeak(d)))
                }
                _live.value = LiveUi(lives, NativeEngine.nativeMasterPeak(), if (_mic.value.on) NativeEngine.nativeMicPeak() else 0f)
                _decks.update { list ->
                    list.mapIndexed { i, d ->
                        val flags = states[i][0]
                        val playing = (flags and 2L) != 0L
                        val loaded = (flags and 1L) != 0L
                        if (d.playing == playing && d.loaded == loaded) d else d.copy(playing = playing, loaded = loaded)
                    }
                }
                val mask = NativeEngine.nativeSamplerMask()
                val padsNow = _pads.value
                if (padsNow.indices.any { ((mask shr it) and 1 == 1) != padsNow[it].playing }) {
                    _pads.value = padsNow.mapIndexed { i, p -> p.copy(playing = (mask shr i) and 1 == 1) }
                }
                if (tick % 6 == 0) syncPadSpeeds()
                if (tick > 2) smartGridTick()
                if (tick % 60 == 23) refreshProblems()   // depois do 1º ciclo: o polling começa ainda dentro do construtor
                phaseLock()
                if (tick % 15 == 7) checkOnAir()
                if (tick % 6 == 3) silenceGuardTick()
                if (tick % 30 == 11) audioWatchdog()
                if (tick > 10 && tick % 4 == 1) syncLeds()   // LEDs da controladora (depois de tudo iniciado)
                if (++tick % 30 == 0) launch(Dispatchers.Default) { NativeEngine.nativeCollectGarbage() }
                delay(33)
            }
        }
    }

    // ----------------------------------------------------------------- mensagens

    private val sayLog by lazy { java.util.ArrayDeque<String>() }   // lazy: say() pode ser chamado no init, antes desta linha
    fun say(text: String) {
        _message.value = text
        synchronized(sayLog) {
            sayLog.addFirst(java.text.SimpleDateFormat("HH:mm:ss", java.util.Locale.ROOT).format(java.util.Date()) + "  " + text)
            while (sayLog.size > 60) sayLog.pollLast()
        }
        val t = text.lowercase()
        if (ERROR_WORDS.any { it in t }) ErrorLog.add("aviso", text)
    }

    fun clearMessage(text: String) {
        _message.update { if (it == text) null else it }
    }

    // ------------------------------------------------------------------- decks

    fun togglePlay(deck: Int) {
        if (_decks.value[deck].loading) {
            say("Espere a música terminar de carregar no deck ${deckName(deck)}.")
            return
        }
        val st = LongArray(4)
        NativeEngine.nativeDeckState(deck, st)
        if ((st[0] and 1L) == 0L) {
            say("Deck ${deckName(deck)} sem música. Abra a Biblioteca e toque em ${deckName(deck)}.")
            return
        }
        // PLAY com o CUE apertado: a prévia vira reprodução normal (como no CDJ)
        if (cueHeld[deck]) { cueHeld[deck] = false; return }
        // um toque rápido no CUE ainda terminando (aparelho ocupado): espera ele voltar ao ponto antes do PLAY
        val pending = cueJob[deck]
        if (pending != null && pending.isActive) {
            viewModelScope.launch { pending.join(); delay(30); NativeEngine.nativePlay(deck) }
            return
        }
        if ((st[0] and 2L) != 0L) NativeEngine.nativePause(deck) else NativeEngine.nativePlay(deck)
    }

    /** Toque rápido no CUE ainda em andamento (marca e volta ao ponto). */
    private val cueJob = arrayOfNulls<kotlinx.coroutines.Job>(DECKS)

    /** CUE segurado com o deck parado (prévia): solta = volta ao ponto e para; PLAY durante a prévia continua tocando. */
    private val cueHeld = BooleanArray(DECKS)

    /**
     * CUE como no CDJ/Serato. Tocando: volta ao ponto de CUE e para. Parado: marca o CUE aqui (preso na batida
     * com QUANTIZE) e toca enquanto o botão estiver apertado.
     */
    fun cueDown(deck: Int) { cueKeyDown[deck] = true; cueDownNow(deck) }
    /** O botão CUE (tela ou controladora) está apertado agora. */
    private val cueKeyDown = BooleanArray(DECKS)

    private fun cueDownNow(deck: Int) {
        val d = _decks.value[deck]
        if (!d.loaded || d.loading) { say("Carregue uma música no deck ${deckName(deck)} primeiro."); return }
        val pending = cueJob[deck]
        if (pending != null && pending.isActive && !cueHeld[deck]) {
            // o CUE anterior ainda não terminou (aparelho ocupado): faz este depois dele, na ordem certa
            viewModelScope.launch { pending.join(); delay(30); cueDownNow(deck); if (!cueKeyDown[deck]) cueUpNow(deck) }
            return
        }
        val st = LongArray(4)
        NativeEngine.nativeDeckState(deck, st)
        val playing = (st[0] and 2L) != 0L
        if (playing && !cueHeld[deck]) { NativeEngine.nativeCue(deck); return }
        if (!playing) {
            val snapped = snapToBeat(d, st[1])
            if (snapped != st[1] && kotlin.math.abs(snapped - st[1]) < NativeEngine.SAMPLE_RATE / 4) {
                NativeEngine.nativeSeek(deck, snapped)
                cueJob[deck] = viewModelScope.launch { delay(25); NativeEngine.nativeCue(deck); NativeEngine.nativePlay(deck) }
                cueHeld[deck] = true
                cueDownAt[deck] = android.os.SystemClock.uptimeMillis() + 25
                return
            }
            NativeEngine.nativeCue(deck)
            NativeEngine.nativePlay(deck)
            cueHeld[deck] = true
            cueDownAt[deck] = android.os.SystemClock.uptimeMillis()
        }
    }

    /** Quando o CUE começou a ser segurado (para soltar na hora, sem esperar a fila da tela). */
    private val cueDownAt = LongArray(DECKS)

    fun cueUp(deck: Int) { cueKeyDown[deck] = false; cueUpNow(deck) }

    private fun cueUpNow(deck: Int) {
        if (!cueHeld[deck]) return
        cueHeld[deck] = false
        val held = android.os.SystemClock.uptimeMillis() - cueDownAt[deck]
        // segurou de verdade: volta ao ponto na hora; toque rápido: deixa a prévia começar antes (só marca o CUE)
        val prev = cueJob[deck]
        if (held >= 40 && (prev == null || !prev.isActive)) NativeEngine.nativeCue(deck)
        else cueJob[deck] = viewModelScope.launch {
            prev?.join()
            delay((40 - held).coerceAtLeast(1))
            NativeEngine.nativeCue(deck)
            delay(20)
        }
    }

    fun cue(deck: Int) {
        cueDown(deck)
        cueUp(deck)
    }

    fun seekFraction(deck: Int, fraction: Float) {
        val length = _decks.value[deck].lengthFrames
        if (length <= 0) return
        NativeEngine.nativeSeek(deck, (fraction.coerceIn(0f, 1f) * length).toLong())
    }

    fun setVolume(deck: Int, v: Float) {
        _volumes.update { list -> list.mapIndexed { i, old -> if (i == deck) v else old } }
        NativeEngine.nativeSetVolume(deck, v)
    }

    fun setCrossfader(x: Float) {
        _crossfader.value = x
        NativeEngine.nativeSetCrossfader(x)
        applyXfFx(x)
    }

    // ---------------- CROSSFADER FX (como no djay e no VirtualDJ): a música que sai some com filtro ou sem graves

    /** 0 NENHUM, 1 FILTRO (a que sai perde os graves aos poucos), 2 TROCA DE GRAVES (corta o grave da que sai). */
    val xfFx: StateFlow<Int> = _xfFx.asStateFlow()
    fun setXfFx(m: Int) {
        _xfFx.value = m.coerceIn(0, 2)
        outPrefs.edit().putInt("xf_fx", _xfFx.value).apply()
        applyXfFx(_crossfader.value)
        say(when (_xfFx.value) {
            1 -> "CROSSFADER FX: FILTRO. Ao passar o crossfader, a música que sai vai sumindo pelo filtro."
            2 -> "CROSSFADER FX: GRAVES. Ao passar o crossfader, a música que sai perde o grave (sem embolar os bumbos)."
            else -> "CROSSFADER FX desligado."
        })
    }

    // ---------------- STEMS COM REDE NEURAL (Spleeter, modelo baixado uma vez)

    data class NeuralUi(val ready: Boolean = false, val busy: Boolean = false, val pct: Float = 0f, val msg: String = "", val on: Boolean = true)

    private val _neural = MutableStateFlow(NeuralUi(ready = NeuralStems.isReady(app), on = outPrefs.getBoolean("neural_stems", true)))
    val neural: StateFlow<NeuralUi> = _neural.asStateFlow()

    fun setNeuralOn(on: Boolean) {
        outPrefs.edit().putBoolean("neural_stems", on).apply()
        _neural.update { it.copy(on = on) }
        say(if (on) "Stems por IA ligados: valem para as próximas músicas carregadas." else "Stems por IA desligados: os stems usam o separador comum.")
    }

    /** Baixa o modelo de IA (~80 MB) e confere. Funciona com internet; o progresso aparece em AJUSTES. */
    fun downloadNeural() {
        if (_neural.value.busy) return
        _neural.update { it.copy(busy = true, pct = 0f, msg = "Baixando o modelo de IA…") }
        viewModelScope.launch(Dispatchers.IO) {
            val err = NeuralStems.download(getApplication<Application>()) { p -> _neural.update { it.copy(pct = p) } }
            _neural.update {
                if (err == null) it.copy(busy = false, ready = true, pct = 1f, msg = "Modelo de IA pronto. Recarregue a música no deck para separar com IA.")
                else it.copy(busy = false, ready = false, msg = "Não deu para baixar: $err")
            }
            say(if (err == null) "Modelo de IA dos stems baixado. As próximas músicas carregadas serão separadas pela rede neural." else "Modelo de IA: $err")
            if (err == null) {
                // decks parados que foram separados pelo separador comum (mais fraco): recarrega para separar com a IA
                withContext(Dispatchers.Main) {
                    for (i in 0..3) {
                        val d = _decks.value[i]
                        if (!d.loaded || d.playing || d.loading || !d.stemsReady || d.trackId < 0) continue
                        if (NeuralStems.lastUsedAi(i)) continue
                        val row = tracks.value.firstOrNull { it.id == d.trackId } ?: continue
                        say("Deck ${deckName(i)}: refazendo os stems com a IA (a música é recarregada).")
                        loadTrack(i, row)
                    }
                }
            }
        }
    }

    fun deleteNeural() {
        if (_neural.value.busy) return
        NeuralStems.delete(getApplication<Application>())
        _neural.update { it.copy(ready = false, msg = "Modelo de IA apagado.") }
    }

    private fun applyXfFx(x: Float) {
        val mode = _xfFx.value
        // o AUTO DJ cuida do filtro e do EQ da transição sozinho
        val auto = autoDj.state.value.active
        for (d in 0 until DECKS) {
            val ui = _decks.value[d]
            val away = if (d % 2 == 0) x else 1f - x                 // 0 = crossfader todo do lado deste deck
            val amt = if (mode == 0 || auto) 0f else ((away - 0.5f) / 0.45f).coerceIn(0f, 1f)
            if (amt <= 0f) {
                if (xfFxOn[d]) {
                    xfFxOn[d] = false
                    NativeEngine.nativeSetFilter(d, ui.filter)
                    NativeEngine.nativeSetEq(d, 0, ui.eq[0])
                }
                continue
            }
            xfFxOn[d] = true
            if (mode == 1 && kotlin.math.abs(ui.filter - 0.5f) < 0.01f) NativeEngine.nativeSetFilter(d, 0.5f + 0.42f * amt)
            if (mode == 2) NativeEngine.nativeSetEq(d, 0, ui.eq[0] * (1f - amt))
        }
    }

    fun setMaster(v: Float) {
        _master.value = v
        NativeEngine.nativeSetMaster(v)
    }

    // ------------------------------------------------- equalizador, filtro e pitch

    private fun snapCenter(v: Float): Float = if (kotlin.math.abs(v - 0.5f) < 0.03f) 0.5f else v.coerceIn(0f, 1f)

    fun setEq(deck: Int, band: Int, v: Float) {
        val x = snapCenter(v)
        setDeck(deck) { d -> d.copy(eq = d.eq.mapIndexed { i, old -> if (i == band) x else old }) }
        NativeEngine.nativeSetEq(deck, band, x)
    }

    fun setFilter(deck: Int, v: Float) {
        val x = snapCenter(v)
        setDeck(deck) { it.copy(filter = x) }
        NativeEngine.nativeSetFilter(deck, x)
    }

    /** Posição do fader de pitch (0 a 1, 0,5 = velocidade normal) para a velocidade. */
    fun setPitchFader(deck: Int, fader: Float) {
        val f = if (kotlin.math.abs(fader - 0.5f) < 0.005f) 0.5f else fader.coerceIn(0f, 1f)
        val d = _decks.value[deck]
        if (d.syncLock) setDeck(deck) { it.copy(syncLock = false) }   // mexer no pitch solta o SYNC travado
        applyRate(deck, 1f + (f - 0.5f) * 2f * d.pitchRange / 100f)
    }

    /** Posição do fader (0..1) para a velocidade atual na faixa do deck. */
    fun pitchFaderValue(d: DeckUi): Float = ((d.rate - 1f) / (2f * d.pitchRange / 100f) + 0.5f).coerceIn(0f, 1f)

    /** Faixa padrão do pitch (AJUSTES): vale para os dois decks agora e nas próximas aberturas. */
    fun setDefaultPitch(pct: Int) {
        if (pct !in PITCH_RANGES) return
        _defaultPitch.value = pct
        outPrefs.edit().putInt("pitchRange", pct).apply()
        for (d in 0 until DECKS) setPitchRange(d, pct, quiet = true)
        say("Faixa do pitch: ±$pct% nos dois decks.")
    }

    /** Troca a faixa do pitch: ±8, ±10, ±12, ±16, ±25, ±50, ±100 % (WIDE). */
    fun cyclePitchRange(deck: Int) {
        val opts = PITCH_RANGES
        val cur = _decks.value[deck].pitchRange
        setPitchRange(deck, opts[(opts.indexOf(cur) + 1).mod(opts.size)])
    }

    fun setPitchRange(deck: Int, pct: Int, quiet: Boolean = false) {
        val r = pct.coerceIn(4, 100)
        setDeck(deck) { it.copy(pitchRange = r) }
        val d = _decks.value[deck]
        val lim = r / 100f
        if (kotlin.math.abs(d.rate - 1f) > lim) applyRate(deck, (d.rate).coerceIn(1f - lim, 1f + lim))
        if (!quiet) say("Pitch do deck ${deckName(deck)}: ±$r%" + if (r == 100) " (WIDE: até parar ou dobrar)." else ".")
    }

    fun resetPitch(deck: Int) {
        setDeck(deck) { it.copy(syncLock = false) }
        applyRate(deck, 1f)
    }

    private val bending = BooleanArray(DECKS)

    /** Empurra (dir +1) ou segura (dir -1) a música enquanto o botão está apertado, como no toca-discos. */
    /** Empurrar/segurar pela borda do prato: a velocidade do giro acelera ou freia a música só enquanto o dedo gira. */
    fun jogBend(deck: Int, active: Boolean, vel: Float) {
        bending[deck] = active
        val d = _decks.value[deck]
        val bend = if (active) (vel * 0.12f * jog.bendGain).coerceIn(-0.3f, 0.3f) else 0f
        NativeEngine.nativeSetRate(deck, d.rate * (1f + bend))
    }

    private val _waveZoom = MutableStateFlow(outPrefs.getInt("zoom", 2).coerceIn(0, WAVE_ZOOMS.size - 1))
    /** Zoom das ondas: índice em [WAVE_ZOOMS] (segundos visíveis). Toque duplo na onda troca. */
    val waveZoom: StateFlow<Int> = _waveZoom.asStateFlow()
    fun cycleWaveZoom() {
        _waveZoom.value = (_waveZoom.value + 1) % WAVE_ZOOMS.size
        outPrefs.edit().putInt("zoom", _waveZoom.value).apply()
        say("Zoom das ondas: ${WAVE_ZOOMS[_waveZoom.value].toInt()} s na tela.")
    }

    private val _portrait = MutableStateFlow(outPrefs.getBoolean("portrait", false))
    /** Permite usar o celular em pé (tela compacta de 2 decks). */
    val portrait: StateFlow<Boolean> = _portrait.asStateFlow()
    fun setPortrait(on: Boolean, activity: android.app.Activity?) {
        _portrait.value = on
        outPrefs.edit().putBoolean("portrait", on).apply()
        activity?.requestedOrientation = if (on) android.content.pm.ActivityInfo.SCREEN_ORIENTATION_FULL_USER
        else android.content.pm.ActivityInfo.SCREEN_ORIENTATION_SENSOR_LANDSCAPE
        say(if (on) "Modo retrato liberado: gire o celular para usar em pé." else "Tela sempre deitada (paisagem).")
    }

    private val _vinyl = MutableStateFlow(outPrefs.getBoolean("vinyl", true))
    /** Modo VINIL: tocar no disco faz scratch. Desligado, o prato só empurra/segura (como CDJ sem vinil). */
    val vinyl: StateFlow<Boolean> = _vinyl.asStateFlow()
    fun toggleVinyl() {
        _vinyl.value = !_vinyl.value
        outPrefs.edit().putBoolean("vinyl", _vinyl.value).apply()
        say(if (_vinyl.value) "Modo VINIL: tocar no disco faz scratch; a borda empurra." else "Modo VINIL desligado: o prato só empurra e segura a música.")
    }

    private val _xfCurve = MutableStateFlow(outPrefs.getInt("xf_curve", 0).coerceIn(0, 2))
    /** Curva do crossfader: 0 SUAVE (mixagem longa), 1 MIXAGEM (os dois cheios no meio), 2 CORTE (scratch). */
    val xfCurve: StateFlow<Int> = _xfCurve.asStateFlow()
    fun setXfCurve(c: Int) {
        _xfCurve.value = c.coerceIn(0, 2)
        outPrefs.edit().putInt("xf_curve", _xfCurve.value).apply()
        NativeEngine.nativeSetCrossfaderCurve(_xfCurve.value)
        say(when (_xfCurve.value) {
            0 -> "Crossfader SUAVE: transições longas, sem buraco no volume."
            1 -> "Crossfader MIXAGEM: as duas músicas cheias no meio."
            else -> "Crossfader CORTE: abre logo no começo do curso (scratch)."
        })
    }

    /** Duração máxima de faixa conforme a memória do aparelho (uma faixa de 1 minuto ocupa ~11 MB). */
    @Suppress("unused")
    private val trackLimitSet: Boolean = run {
        val am = app.getSystemService(android.content.Context.ACTIVITY_SERVICE) as android.app.ActivityManager
        val mi = android.app.ActivityManager.MemoryInfo().also { am.getMemoryInfo(it) }
        val perSec = NativeEngine.SAMPLE_RATE * 4L
        NativeEngine.MAX_TRACK_SECONDS = ((mi.totalMem * 0.08) / perSec).toInt().coerceIn(15 * 60, 120 * 60)
        NativeEngine.nativeSetMaxTrackSeconds(NativeEngine.MAX_TRACK_SECONDS)
        true
    }

    /** Preferências do visor (tom em letras, tempo restante, cor das ondas) guardadas entre as aberturas do app. */
    @Suppress("unused")
    private val displayPrefsLoaded: Boolean = run {
        DisplayPrefs.keyLetters = outPrefs.getBoolean("key_letters", false)
        DisplayPrefs.keyOpen = outPrefs.getBoolean("key_open", false)
        DisplayPrefs.remaining = outPrefs.getBoolean("remaining", false)
        DisplayPrefs.waveStyle = outPrefs.getInt("wave_style", 0).coerceIn(0, 4)
        DisplayPrefs.waveType = outPrefs.getInt("wave_type", 0).coerceIn(0, 5)
        viewModelScope.launch {
            androidx.compose.runtime.snapshotFlow { listOf(if (DisplayPrefs.keyLetters) 1 else 0, if (DisplayPrefs.remaining) 1 else 0, DisplayPrefs.waveStyle, DisplayPrefs.waveType, if (DisplayPrefs.keyOpen) 1 else 0) }
                .collect { (k, r, w, t, o) -> outPrefs.edit().putBoolean("key_open", o == 1).putBoolean("key_letters", k == 1).putBoolean("remaining", r == 1).putInt("wave_style", w).putInt("wave_type", t).apply() }
        }
        true
    }

    /** Tamanho do texto e vibração dos botões, guardados entre as aberturas do app. */
    @Suppress("unused")
    private val accessPrefsLoaded: Boolean = run {
        DisplayPrefs.textSize = outPrefs.getInt("text_size", 0).coerceIn(0, 2)
        DisplayPrefs.haptics = outPrefs.getBoolean("haptics", true)
        viewModelScope.launch {
            androidx.compose.runtime.snapshotFlow { DisplayPrefs.textSize * 2 + (if (DisplayPrefs.haptics) 1 else 0) }
                .collect { v -> outPrefs.edit().putInt("text_size", v / 2).putBoolean("haptics", v % 2 == 1).apply() }
        }
        true
    }

    private val _autoCues = MutableStateFlow(outPrefs.getBoolean("auto_cues", true))
    /** Marca sozinho INÍCIO, GROOVE, DROP e SAÍDA nas hot cues 1–4 de músicas sem cues. */
    val autoCues: StateFlow<Boolean> = _autoCues.asStateFlow()
    fun setAutoCues(on: Boolean) {
        _autoCues.value = on
        outPrefs.edit().putBoolean("auto_cues", on).apply()
        say(if (on) "Cues automáticas: músicas novas já chegam com INÍCIO, GROOVE, DROP e SAÍDA." else "Cues automáticas desligadas.")
    }

    private val _silenceGuard = MutableStateFlow(outPrefs.getBoolean("silence_guard", true))
    /** Proteção contra silêncio: se a música acabar sem outra tocando, o final entra em loop. */
    val silenceGuard: StateFlow<Boolean> = _silenceGuard.asStateFlow()
    fun setSilenceGuard(on: Boolean) {
        _silenceGuard.value = on
        outPrefs.edit().putBoolean("silence_guard", on).apply()
        say(if (on) "Proteção contra silêncio ligada." else "Proteção contra silêncio desligada.")
    }

    /** Fim musical de cada deck (id da faixa, quadro) e a última faixa já protegida. */
    private val guardEnd = Array(DECKS) { -1L to 0L }
    private val guardDone = LongArray(DECKS) { -1L }

    /**
     * Proteção contra silêncio: a música do ar chegando ao fim e nada mais tocando (sem AUTO DJ) →
     * liga um loop de 1 compasso no final, no tempo, até o DJ soltar ou a próxima entrar.
     */
    private fun silenceGuardTick() {
        if (!_silenceGuard.value || autoDj.state.value.active) return
        val ds = _decks.value
        for (d in 0 until DECKS) {
            val u = ds[d]
            if (!u.playing || u.loopBeats != 0 || !u.hasBpm || u.trackId < 0 || guardDone[d] == u.trackId) continue
            if (ds[(d xor 1)].playing) continue
            if (guardEnd[d].first != u.trackId) guardEnd[d] = u.trackId to app.djfusion.harmony.TrackShape.musicalEnd(u.wave, u.lengthFrames)
            val beat = 60.0 * NativeEngine.SAMPLE_RATE / u.bpm
            val left = (guardEnd[d].second - posOf(d)) / beat
            if (left in 5.0..10.0) {
                guardDone[d] = u.trackId
                toggleLoop(d, 4)
                if (_decks.value[d].loopBeats == 4) say("PROTEÇÃO: o final do deck ${deckName(d)} entrou em loop para o som não parar. Solte o loop quando a próxima entrar.")
            }
        }
    }

    // ------------------------------------------------------- hot cues: nomes e cues automáticas

    private val _cueEdit = MutableStateFlow<Pair<Int, Int>?>(null)
    /** Hot cue sendo editada (deck, posição) — abre o menu de nome/apagar. */
    val cueEdit: StateFlow<Pair<Int, Int>?> = _cueEdit.asStateFlow()
    fun openCueEdit(deck: Int, slot: Int) {
        if (_decks.value[deck].hotcues.getOrElse(slot) { -1L } < 0) return
        _cueEdit.value = deck to slot
    }
    fun closeCueEdit() { _cueEdit.value = null }

    fun renameHotcue(deck: Int, slot: Int, name: String) {
        val d = _decks.value[deck]
        if (d.trackId < 0 || slot !in 0..7 || d.hotcues[slot] < 0) return
        val n = name.trim().uppercase(java.util.Locale.ROOT).take(10)
        setDeck(deck) { it.copy(hotcueNames = it.hotcueNames.mapIndexed { i, old -> if (i == slot) n else old }) }
        val id = d.trackId
        viewModelScope.launch(Dispatchers.IO) { db.renameHotcue(id, slot, n) }
    }

    /**
     * Cues automáticas (como a preparação de um DJ): 1 INÍCIO (primeiro compasso com som), 2 GROOVE (a batida
     * completa entra), 3 DROP (volta forte depois do break) e 4 SAÍDA (onde começa o final). Só em faixas sem cues 1–4.
     */
    private fun applyAutoCues(deck: Int) { if (_autoCues.value) prepareCues(deck, force = false) }

    /** Marca as cues automáticas agora. Com [force], refaz as cues 1–4 mesmo se já existirem. */
    fun prepareCues(deck: Int, force: Boolean = true) {
        val d = _decks.value[deck]
        if (!d.hasBpm || d.trackId < 0 || d.wave == null) { if (force) say("Cues automáticas precisam do andamento detectado."); return }
        if (!force && (0..3).any { d.hotcues[it] >= 0 }) return
        val beat = 60.0 * NativeEngine.SAMPLE_RATE / d.bpm
        val shape = app.djfusion.harmony.TrackShape
        val bar = 4 * beat
        fun atBeat(b: Int): Long = (d.firstBeatFrame + b * beat).toLong()
        val startFrame = shape.musicalStart(d.wave)
        val startBeat = kotlin.math.max(0.0, Math.floor((startFrame - d.firstBeatFrame) / bar) * 4).toInt()
        val endFrame = shape.musicalEnd(d.wave, d.lengthFrames)
        val totalBeats = ((endFrame - d.firstBeatFrame) / beat).toInt()
        val groove = shape.grooveBeat(d.wave, d.firstBeatFrame, beat)
        // saída grudada no fim da música não serve para mixar: fica sem a cue 4
        val outro = shape.outroBeat(d.wave, d.firstBeatFrame, beat, totalBeats).let { if (it >= totalBeats - 16) -1 else it }
        val drop = shape.dropBeat(d.wave, d.firstBeatFrame, beat, groove + 32, if (outro > 0) outro - 16 else totalBeats - 32)
        val picks = listOf(startBeat to "INÍCIO", groove to "GROOVE", drop to "DROP", outro to "SAÍDA")
        val frames = MutableList(8) { if (force && it < 4) -1L else d.hotcues[it] }
        val names = MutableList(8) { if (force && it < 4) "" else d.hotcueNames[it] }
        val used = HashSet<Int>()
        for ((slot, p) in picks.withIndex()) {
            val (b, n) = p
            if (b < 0 || b >= totalBeats || !used.add(b)) continue
            val f = atBeat(b).coerceIn(0L, (d.lengthFrames - 1).coerceAtLeast(0L))
            frames[slot] = f; names[slot] = n
        }
        if ((0..3).none { frames[it] >= 0 }) return
        setDeck(deck) { if (it.trackId != d.trackId) it else it.copy(hotcues = frames, hotcueNames = names) }
        val id = d.trackId
        viewModelScope.launch(Dispatchers.IO) {
            for (slot in 0..3) if (frames[slot] >= 0) db.setHotcue(id, slot, frames[slot], names[slot]) else if (force) db.deleteHotcue(id, slot)
        }
        say("Cues automáticas no deck ${deckName(deck)}: " + (0..3).filter { frames[it] >= 0 }.joinToString(" · ") { "${it + 1} ${names[it]}" })
    }

    fun pitchBend(deck: Int, dir: Int, on: Boolean) {
        bending[deck] = on
        val d = _decks.value[deck]
        NativeEngine.nativeSetRate(deck, if (on) d.rate * (1f + 0.04f * dir) else d.rate)
    }

    // ------------------------------------------------------------- GRADE INTELIGENTE (andamento variável)

    private val skinPrefs = app.getSharedPreferences("aparencia", android.content.Context.MODE_PRIVATE)
    private val _skin = MutableStateFlow(skinPrefs.getInt("skin", 0).also { Metal.applySkin(it) })
    val skin: StateFlow<Int> = _skin.asStateFlow()
    fun setSkin(i: Int) {
        val v = i.coerceIn(0, Metal.SKIN_NAMES.lastIndex)
        _skin.value = v
        Metal.applySkin(v)
        skinPrefs.edit().putInt("skin", v).apply()
        say("Aparência: ${Metal.SKIN_NAMES[v]}.")
    }
    private val tempoPrefs = app.getSharedPreferences("andamento", android.content.Context.MODE_PRIVATE)
    private val _smartGrid = MutableStateFlow(tempoPrefs.getBoolean("ligada", true))
    /** Músicas que mudam de andamento (montagens, ao vivo): a grade acompanha cada trecho. */
    val smartGrid: StateFlow<Boolean> = _smartGrid.asStateFlow()
    fun toggleSmartGrid() {
        _smartGrid.value = !_smartGrid.value
        tempoPrefs.edit().putBoolean("ligada", _smartGrid.value).apply()
        if (!_smartGrid.value) {
            // desligada: os decks voltam à grade geral da música (a que está guardada)
            for (d in 0 until DECKS) {
                val ui = _decks.value[d]
                if (ui.tempoIdx < 0) continue
                viewModelScope.launch {
                    val a = withContext(Dispatchers.IO) { db.analysis(ui.trackId) } ?: return@launch
                    setDeck(d) { if (it.trackId != ui.trackId) it else it.copy(bpm = a.bpm, firstBeatFrame = a.firstBeatFrame, tempoIdx = -1) }
                    pushFx(d)
                }
            }
        }
        say(if (_smartGrid.value) "GRADE INTELIGENTE ligada: músicas com andamento variável seguem cada trecho." else "GRADE INTELIGENTE desligada: uma grade só por música.")
    }

    /** Mapa de andamento da faixa (guardado para não medir de novo). Roda em segundo plano. */
    private fun tempoMapOf(trackId: Long, handle: Long, a: Analysis): List<TempoSec> {
        if (a.bpm <= 0.0 || a.confidence < MIN_BPM_CONFIDENCE) return emptyList()
        val cached = tempoPrefs.getString("tm$trackId", null)
        val key = String.format(java.util.Locale.ROOT, "%.3f", a.bpm)
        if (cached == "m") return emptyList()
        if (cached != null && cached.startsWith("$key|")) return parseTempo(cached.substringAfter('|'))
        val out = DoubleArray(3 + 3 * 32)
        NativeEngine.nativeTempoMap(handle, a.bpm, a.firstBeatFrame, out)
        val n = out[2].toInt().coerceIn(0, 32)
        val list = if (out[0] < 0.5) emptyList() else (0 until n).map { i -> TempoSec(out[3 + 3 * i].toLong(), out[4 + 3 * i], out[5 + 3 * i].toLong()) }
        tempoPrefs.edit().putString("tm$trackId", "$key|" + list.joinToString(";") { "${it.start}:${it.bpm}:${it.beat}" }).apply()
        return list
    }

    private fun parseTempo(t: String): List<TempoSec> = if (t.isEmpty()) emptyList() else t.split(';').mapNotNull { p ->
        val f = p.split(':')
        if (f.size != 3) null else {
            val st = f[0].toLongOrNull(); val b = f[1].toDoubleOrNull(); val bt = f[2].toLongOrNull()
            if (st == null || b == null || bt == null) null else TempoSec(st, b, bt)
        }
    }

    /** Troca a grade do deck quando a música entra noutro trecho de andamento (sem salvar: a grade geral fica guardada). */
    private fun smartGridTick() {
        if (!_smartGrid.value) return
        for (d in 0 until DECKS) {
            val ui = _decks.value[d]
            if (ui.tempoSections.size < 2) continue
            val pos = _live.value.decks[d].positionFrames
            var idx = 0
            for (i in ui.tempoSections.indices) if (ui.tempoSections[i].start <= pos) idx = i
            if (idx == ui.tempoIdx) continue
            val sec = ui.tempoSections[idx]
            setDeck(d) { if (it.trackId != ui.trackId) it else it.copy(bpm = sec.bpm, firstBeatFrame = sec.beat, tempoIdx = idx) }
            pushFx(d)
        }
    }

    // ------------------------------------------------------------------ SYNC travado (trava de fase)

    private val lockSent = FloatArray(DECKS)

    /** Mantém os decks com SYNC travado no andamento e na fase do outro (chamado ~30 vezes por segundo). */
    private fun phaseLock() {
        val ds = _decks.value
        for (d in 0 until DECKS) {
            val me = ds[d]
            if (!me.syncLock) continue
            val o = ds[(d xor 1)]
            if (!me.playing || !o.playing || !me.hasBpm || !o.hasBpm || me.reverse || bending[d] || slipFrom[d] != null || me.rollBeats > 0f) continue
            // andamento: segue o outro (com dobro/metade)
            var k = 1.0
            var best = Double.MAX_VALUE
            for (m in doubleArrayOf(1.0, 2.0, 0.5)) {
                val e = kotlin.math.abs(o.playedBpm / (me.bpm * m) - 1.0)
                if (e < best) { best = e; k = m }
            }
            val target = (o.playedBpm / (me.bpm * k)).toFloat()
            if (target !in 0.5f..1.5f) continue
            if (kotlin.math.abs(target - me.rate) > 1e-4f) setDeck(d) { it.copy(rate = target) }
            // fase: diferença em batidas do outro deck, corrigida em ~1 s com um leve ajuste de velocidade
            val pm = _live.value.decks[d].positionFrames.toDouble()
            val po = _live.value.decks[(d xor 1)].positionFrames.toDouble()
            val sr = NativeEngine.SAMPLE_RATE.toDouble()
            val beatsMe = (pm - me.firstBeatFrame) / (60.0 * sr / me.bpm) * k
            val beatsO = (po - o.firstBeatFrame) / (60.0 * sr / o.bpm)
            var err = (beatsO - Math.floor(beatsO)) - (beatsMe - Math.floor(beatsMe))
            if (err > 0.5) err -= 1.0 else if (err < -0.5) err += 1.0
            val beatSec = 60.0 / o.playedBpm
            // ganho 1,2 por segundo (constante de tempo ~0,8 s); até 3,5% de empurrão para desvios grandes, como no Serato
            val adj = if (kotlin.math.abs(err) < 0.004) 0.0 else (err * beatSec * 1.2).coerceIn(-0.035, 0.035)
            val send = (target * (1.0 + adj)).toFloat()
            if (kotlin.math.abs(send - lockSent[d]) > 0.0002f) {
                lockSent[d] = send
                NativeEngine.nativeSetRate(d, send)
            }
        }
    }

    /** Define a grade de batidas do deck (andamento e posição da batida 1) e salva na biblioteca. */
    fun setBeatGrid(deck: Int, bpm: Double, firstBeat: Long) {
        val d = _decks.value[deck]
        if (d.trackId < 0 || bpm !in 30.0..300.0) return
        setDeck(deck) { it.copy(bpm = bpm, firstBeatFrame = firstBeat.coerceAtLeast(0L), bpmConfidence = kotlin.math.max(it.bpmConfidence, 1f)) }
        saveGrid(d.trackId, bpm, firstBeat.coerceAtLeast(0L))
        pushFx(deck)
    }

    // ------------------------------------------------------------------ TAP (andamento na mão)

    private val taps = Array(DECKS) { ArrayList<Long>() }

    /**
     * TAP: toque no ritmo da música. Com 4 toques ou mais, o andamento passa a ser a média dos intervalos e a
     * batida 1 fica no último toque (corrige faixas em que a detecção errou). Pausa de 2 s recomeça a contagem.
     */
    fun tapBpm(deck: Int) {
        val d = _decks.value[deck]
        if (!d.loaded || d.trackId < 0) return
        val now = android.os.SystemClock.elapsedRealtime()
        val t = taps[deck]
        if (t.isNotEmpty() && now - t.last() > 2000) t.clear()
        t.add(now)
        if (t.size > 12) t.removeAt(0)
        if (t.size < 4) { say("TAP: ${t.size} de 4 toques no ritmo…"); return }
        val avgMs = (t.last() - t.first()).toDouble() / (t.size - 1)
        val played = 60000.0 / avgMs
        val trackBpm = played / d.rate
        if (trackBpm !in 50.0..220.0) { say("TAP fora da faixa (50 a 220 BPM)."); return }
        val pos = posOf(deck)
        val beat = (60.0 * NativeEngine.SAMPLE_RATE / trackBpm).toLong().coerceAtLeast(1)
        val first = ((pos % beat) + beat) % beat
        setDeck(deck) { it.copy(bpm = trackBpm, firstBeatFrame = first, bpmConfidence = 1f) }
        saveGrid(d.trackId, trackBpm, first)
        pushFx(deck)
        say(String.format(java.util.Locale.ROOT, "TAP: %.2f BPM no deck %s (%d toques).", trackBpm, deckName(deck), t.size))
    }

    // ------------------------------------------------------------------ região do loop (para desenhar na onda)

    private val _loopRegion = MutableStateFlow<List<Pair<Long, Long>?>>(listOf(null, null))
    val loopRegion: StateFlow<List<Pair<Long, Long>?>> = _loopRegion.asStateFlow()

    private fun setLoopNative(deck: Int, a: Long, b: Long) {
        NativeEngine.nativeSetLoop(deck, a, b)
        _loopRegion.update { l -> l.mapIndexed { i, r -> if (i == deck) a to b else r } }
    }

    private fun clearLoopNative(deck: Int) {
        NativeEngine.nativeClearLoop(deck)
        _loopRegion.update { l -> l.mapIndexed { i, r -> if (i == deck) null else r } }
    }

    // ------------------------------------------------------------------ QUANTIZE, LATÊNCIA, LISTA FIXA

    private val _quantize = MutableStateFlow(outPrefs.getBoolean("quantize", true))
    /** QUANTIZE: hot cues e loops caem na batida; pulos mantêm o ritmo. */
    val quantize: StateFlow<Boolean> = _quantize.asStateFlow()
    fun toggleQuantize() {
        _quantize.value = !_quantize.value
        outPrefs.edit().putBoolean("quantize", _quantize.value).apply()
        say(if (_quantize.value) "QUANTIZE ligado: cues e loops caem na batida." else "QUANTIZE desligado: cues e loops exatamente onde tocar.")
    }

    /** Batida mais próxima (com QUANTIZE ligado e andamento detectado); senão a própria posição. */
    private fun snapToBeat(d: DeckUi, pos: Long): Long {
        if (!_quantize.value || !d.hasBpm) return pos
        val beat = 60.0 * NativeEngine.SAMPLE_RATE / d.bpm
        val k = Math.round((pos - d.firstBeatFrame) / beat)
        return (d.firstBeatFrame + k * beat).toLong().coerceIn(0L, (d.lengthFrames - 1).coerceAtLeast(0L))
    }

    private val _stemStrength = MutableStateFlow(outPrefs.getInt("stemStrength", 1).coerceIn(0, 2))
    /** Força da remoção dos stems: 0 suave, 1 normal, 2 forte. */
    val stemStrength: StateFlow<Int> = _stemStrength.asStateFlow()
    fun setStemStrength(m: Int) {
        _stemStrength.value = m.coerceIn(0, 2)
        outPrefs.edit().putInt("stemStrength", _stemStrength.value).apply()
        NativeEngine.nativeSetStemStrength(_stemStrength.value * 0.5f)
    }

    private val _latency = MutableStateFlow(outPrefs.getInt("latency", 1).coerceIn(0, 2))
    /** Latência da saída: 0 baixa, 1 normal, 2 segura. */
    val latency: StateFlow<Int> = _latency.asStateFlow()
    fun setLatency(m: Int) {
        _latency.value = m.coerceIn(0, 2)
        outPrefs.edit().putInt("latency", _latency.value).apply()
        viewModelScope.launch(Dispatchers.Default) {
            NativeEngine.nativeSetLatency(_latency.value)
            delay(300)
            refreshAudioStatus()
        }
    }

    private val _browserDock = MutableStateFlow(outPrefs.getBoolean("dock", false))
    /** Lista de músicas fixa embaixo dos decks (como no VirtualDJ). */
    val browserDock: StateFlow<Boolean> = _browserDock.asStateFlow()
    fun toggleBrowserDock() {
        _browserDock.value = !_browserDock.value
        outPrefs.edit().putBoolean("dock", _browserDock.value).apply()
    }

    /** Liga a trava de fase sem mensagem (usado pelo AUTO DJ durante a mixagem). */
    fun setSyncLock(deck: Int, on: Boolean) {
        setDeck(deck) { it.copy(syncLock = on) }
        lockSent[deck] = 0f
        if (!on) NativeEngine.nativeSetRate(deck, _decks.value[deck].rate)
    }

    /** Botão SYNC: alinha e trava; tocado de novo, destrava. */
    fun syncButton(deck: Int) {
        if (_decks.value[deck].syncLock) {
            setSyncLock(deck, false)
            say("SYNC destravado no deck ${deckName(deck)}.")
            return
        }
        // só um deck segue o outro: se o outro já seguia este, ele vira o mestre (senão os dois se perseguem)
        if (_decks.value[(deck xor 1)].syncLock) {
            setSyncLock((deck xor 1), false)
            say("Deck ${deckName((deck xor 1))} vira o mestre do SYNC.")
        }
        if (sync(deck)) {
            setSyncLock(deck, true)
            say("SYNC travado no deck ${deckName(deck)}: segue o andamento e a batida do outro deck. Toque de novo para soltar.")
        }
    }

    // ------------------------------------------------------------------ ROLL (repetição de batida)

    private val rollFrom = arrayOfNulls<Pair<Long, Long>>(DECKS)

    /** ROLL: repete o pedaço de [beats] batidas enquanto ligado; ao soltar, a música volta onde estaria. */
    fun roll(deck: Int, beats: Float) {
        val d = _decks.value[deck]
        if (!d.loaded || d.loading) { say("Carregue uma música no deck ${deckName(deck)} primeiro."); return }
        if (d.rollBeats == beats || (beats <= 0f && d.rollBeats > 0f)) {
            clearLoopNative(deck)
            val from = rollFrom[deck]
            rollFrom[deck] = null
            if (from != null) {
                val elapsed = android.os.SystemClock.elapsedRealtime() - from.second
                val target = from.first + (elapsed / 1000.0 * NativeEngine.SAMPLE_RATE * d.rate).toLong()
                if (target in 0 until d.lengthFrames) NativeEngine.nativeSeek(deck, target)
            }
            setDeck(deck) { it.copy(rollBeats = 0f, loopBeats = 0) }
            return
        }
        if (!d.hasBpm || !d.playing) { say("ROLL precisa do deck ${deckName(deck)} tocando com andamento detectado."); return }
        val pos = posOf(deck)
        if (rollFrom[deck] == null) rollFrom[deck] = pos to android.os.SystemClock.elapsedRealtime()
        val len = 60.0 * NativeEngine.SAMPLE_RATE / d.bpm * beats
        val first = d.firstBeatFrame.toDouble()
        val start = first + Math.floor((pos - first) / len) * len
        setLoopNative(deck, start.toLong().coerceAtLeast(0L), (start + len).toLong())
        setDeck(deck) { it.copy(rollBeats = beats, loopBeats = -2) }
    }

    /** Divisão de batida dos efeitos de ritmo. */
    fun setFxBeats(deck: Int, beats: Float) {
        setDeck(deck) { it.copy(fxBeats = beats.coerceIn(0.125f, 4f)) }
        pushFx(deck)
    }

    /** Velocidade exata do deck (usado pelo AUTO DJ). */
    fun setRateExact(deck: Int, rate: Float) = applyRate(deck, rate.coerceIn(0.5f, 2f))

    /** Liga ou desliga o key-lock sem alternar. */
    fun setKeyLock(deck: Int, on: Boolean) {
        if (_decks.value[deck].keyLock == on) return
        toggleKeyLock(deck)
    }

    private fun applyRate(deck: Int, rate: Float) {
        setDeck(deck) { it.copy(rate = rate) }
        NativeEngine.nativeSetRate(deck, rate)
        pushFx(deck)
    }

    /** Liga o efeito [type] (toque de novo no mesmo para desligar). */
    fun setFx(deck: Int, type: Int) {
        setDeck(deck) { d ->
            val sel = d.fxSel
            if (d.fxTypeAt(sel) == type) d.withFx(sel, type = 0)
            else {
                // o mesmo efeito não fica em dois encaixes: sai do outro e vem para o escolhido
                val other = d.fxSlotOf(type)
                (if (other >= 0) d.withFx(other, type = 0) else d).withFx(sel, type = type)
            }
        }
        pushFx(deck)
    }

    fun setFxAmount(deck: Int, v: Float) {
        setDeck(deck) { it.withFx(it.fxSel, amount = v.coerceIn(0f, 1f)) }
        pushFx(deck)
    }

    /** Escolhe qual dos 3 encaixes de efeito os botões e o botão giratório controlam. */
    fun setFxSlot(deck: Int, slot: Int) {
        setDeck(deck) { it.copy(fxSel = slot.coerceIn(0, 2)) }
    }

    /** Desliga os 3 efeitos do deck de uma vez. */
    fun clearFx(deck: Int) {
        setDeck(deck) { it.copy(fxType = 0, fx2Type = 0, fx3Type = 0) }
        pushFx(deck)
    }

    /** Reenvia ao motor o efeito escolhido na tela (depois que o AUTO DJ usou o eco na transição). */
    fun restoreFx(deck: Int) = pushFx(deck)

    /** Envia o efeito ao motor; o eco acompanha a batida do que está tocando. */
    private fun pushFx(deck: Int) {
        val d = _decks.value[deck]
        // o motor usa 3/4 do valor como atraso do eco: escala para o eco cair na divisão escolhida
        val beat = (if (d.hasBpm) (60.0 / d.playedBpm).toFloat() else 0.5f) * d.fxBeats / 0.75f
        for (slot in 0..2) NativeEngine.nativeSetFx(deck, d.fxTypeAt(slot) + 16 * slot, d.fxAmountAt(slot), beat.coerceIn(0.06f, 5f))
    }

    private fun posMod(a: Double, m: Double): Double = ((a % m) + m) % m

    /**
     * SYNC: iguala o andamento tocado deste deck ao do outro e, se o outro está tocando, alinha também a batida.
     * Só funciona com andamento detectado nos dois. Não é um SYNC contínuo: se o andamento oscilar, refaça.
     */
    fun sync(deck: Int): Boolean {
        val me = _decks.value[deck]
        val other = _decks.value[(deck xor 1)]
        val name = deckName(deck)
        if (!me.loaded || !other.loaded) { say("SYNC precisa de música nos dois decks."); return false }
        if (!me.hasBpm || !other.hasBpm) { say("SYNC precisa do andamento detectado nos dois decks."); return false }
        val targetBpm = other.playedBpm
        var factor = 1.0
        var best = Double.MAX_VALUE
        for (k in doubleArrayOf(1.0, 2.0, 0.5)) {
            val r = targetBpm / (me.bpm * k)
            if (r in 0.67..1.5 && kotlin.math.abs(r - 1.0) < best) {
                best = kotlin.math.abs(r - 1.0)
                factor = k
            }
        }
        if (best == Double.MAX_VALUE) {
            say("SYNC não aplicado: andamentos muito diferentes (%.1f e %.1f BPM, mais de 50%% de pitch)%s. Confira o BPM com TAP ou ÷2/×2.".format(
                java.util.Locale.ROOT, me.bpm, targetBpm,
                if (me.bpmConfidence < 0.45f || other.bpmConfidence < 0.45f) " e a batida está incerta" else ""))
            return false
        }
        val newRate = (targetBpm / (me.bpm * factor)).toFloat()
        // se passar da faixa do fader, abre a faixa até caber
        val need = kotlin.math.abs(newRate - 1f) * 100f
        if (need > me.pitchRange) PITCH_RANGES.firstOrNull { it >= need }?.let { r -> setDeck(deck) { it.copy(pitchRange = r) } }
        applyRate(deck, newRate)
        // mudança grande de velocidade: liga o KEY-LOCK para o tom não subir/descer junto (some com o efeito "esquilo")
        if (need > 3f && !me.keyLock) setKeyLock(deck, true)
        var aligned = false
        if (factor == 1.0 && other.playing) {
            val a = LongArray(4); val b = LongArray(4)
            NativeEngine.nativeDeckState(deck, a); NativeEngine.nativeDeckState((deck xor 1), b)
            val sr = NativeEngine.SAMPLE_RATE.toDouble()
            val otherBeat = 60.0 * sr / other.bpm
            val myBeat = 60.0 * sr / me.bpm
            val phase = posMod(b[1] - other.firstBeatFrame.toDouble(), otherBeat) / otherBeat
            val cur = posMod(a[1] - me.firstBeatFrame.toDouble(), myBeat)
            var delta = phase * myBeat - cur
            if (delta > myBeat / 2) delta -= myBeat else if (delta < -myBeat / 2) delta += myBeat
            val target = (a[1] + delta).toLong().coerceIn(0L, (me.lengthFrames - 1).coerceAtLeast(0L))
            NativeEngine.nativeSeek(deck, target)
            aligned = true
        }
        say("Deck $name em %.1f BPM%s.".format(java.util.Locale.ROOT, targetBpm, if (aligned) ", batida alinhada" else ""))
        return true
    }

    // ------------------------------------------------------------- loops e hot cues

    fun toggleLoop(deck: Int, beats: Int) {
        val d = _decks.value[deck]
        if (!d.loaded || d.loading) { say("Carregue uma música no deck ${deckName(deck)} primeiro."); return }
        if (d.loopBeats == beats) {
            clearLoopNative(deck)
            setDeck(deck) { it.copy(loopBeats = 0) }
            slipEnd(deck)
            return
        }
        if (!d.hasBpm) { say("Loop por batidas precisa do andamento detectado."); return }
        val st = LongArray(4)
        NativeEngine.nativeDeckState(deck, st)
        val beat = 60.0 * NativeEngine.SAMPLE_RATE / d.bpm
        val first = d.firstBeatFrame.toDouble()
        val start = kotlin.math.max(0.0, first + kotlin.math.floor((st[1] - first) / beat) * beat)
        val end = start + beats * beat
        if (end > d.lengthFrames) { say("Perto demais do fim da música para esse loop."); return }
        if (d.loopBeats == 0) slipBegin(deck)
        setLoopNative(deck, start.toLong(), end.toLong())
        setDeck(deck) { it.copy(loopBeats = beats) }
    }

    /** Toque numa hot cue vazia grava a posição atual. Numa gravada, vai até ela e toca. */
    fun hotcue(deck: Int, slot: Int) {
        val d = _decks.value[deck]
        if (slot !in 0..7) return
        if (!d.loaded || d.loading || d.trackId < 0) { say("Carregue uma música no deck ${deckName(deck)} primeiro."); return }
        val saved = d.hotcues[slot]
        if (saved < 0) {
            val st = LongArray(4)
            NativeEngine.nativeDeckState(deck, st)
            val frame = snapToBeat(d, st[1])           // QUANTIZE: a cue cai exatamente na batida
            setDeck(deck) {
                it.copy(
                    hotcues = it.hotcues.mapIndexed { i, old -> if (i == slot) frame else old },
                    hotcueNames = it.hotcueNames.mapIndexed { i, old -> if (i == slot) "" else old },
                )
            }
            val id = d.trackId
            viewModelScope.launch(Dispatchers.IO) { db.setHotcue(id, slot, frame) }
        } else {
            // QUANTIZE tocando: pula mantendo a posição dentro da batida (o ritmo não tropeça)
            val target = if (_quantize.value && d.playing && d.hasBpm) {
                val beat = 60.0 * NativeEngine.SAMPLE_RATE / d.bpm
                val ph = posMod(posOf(deck) - d.firstBeatFrame.toDouble(), beat)
                val cueBeat = Math.round((saved - d.firstBeatFrame) / beat)
                (d.firstBeatFrame + cueBeat * beat + ph).toLong().coerceIn(0L, (d.lengthFrames - 1).coerceAtLeast(0L))
            } else saved
            NativeEngine.nativeSeek(deck, target)
            if (!d.playing) NativeEngine.nativePlay(deck)
        }
    }

    fun clearHotcue(deck: Int, slot: Int) {
        val d = _decks.value[deck]
        if (d.trackId < 0 || slot !in 0..7 || d.hotcues[slot] < 0) return
        setDeck(deck) {
            it.copy(
                hotcues = it.hotcues.mapIndexed { i, old -> if (i == slot) -1L else old },
                hotcueNames = it.hotcueNames.mapIndexed { i, old -> if (i == slot) "" else old },
            )
        }
        val id = d.trackId
        viewModelScope.launch(Dispatchers.IO) { db.deleteHotcue(id, slot) }
        say("Hot cue ${slot + 1} apagada.")
    }

    // ------------------------------------------------------------ carregar faixa

    fun loadTrack(deck: Int, row: TrackRow) {
        val current = _decks.value[deck]
        if (current.playing) {
            say("Pause o deck ${deckName(deck)} antes de carregar outra música.")
            return
        }
        NativeEngine.nativeCancelStems(deck); NeuralStems.cancel(deck)
        loopInAt[deck] = -1; loopOutAt[deck] = -1; pubLoop()
        _loopRegion.update { l -> l.mapIndexed { i, r -> if (i == deck) null else r } }
        rollFrom[deck] = null; lockSent[deck] = 0f
        decodeJobs[deck]?.cancel()
        slipFrom[deck] = null
        setDeck(deck) {
            it.copy(loading = true, loadProgress = 0f, title = row.title, artist = row.artist, stemProgress = -1f,
                stemGains = listOf(1f, 1f, 1f, 1f), reverse = false, keyShift = 0, syncLock = false, rollBeats = 0f, analyzing = false)
        }
        say("Carregando no deck ${deckName(deck)}…")
        decodeJobs[deck] = viewModelScope.launch {
            val result = TrackDecoder.decode(getApplication(), Uri.parse(row.uri), deck) { p ->
                setDeck(deck) { it.copy(loadProgress = p) }
            }
            when (result) {
                is DecodeResult.Ready -> try {
                    val h = result.trackHandle
                    val frames = NativeEngine.nativeTrackFrames(h)
                    val wave = NativeEngine.nativeTrackPeaks(h)
                    val ok = NativeEngine.nativeLoad(deck, h)
                    if (!ok) {
                        setDeck(deck) { it.copy(loading = false, title = current.title, artist = current.artist) }
                        say("O motor de áudio recusou a faixa.")
                        return@launch
                    }
                    // 1) já tocável: usa a análise guardada (se houver) e libera o deck na hora
                    val cached = withContext(Dispatchers.IO) { db.analysis(row.id) }
                    val hot = withContext(Dispatchers.IO) { db.hotcues(row.id) }
                    val hotNames = withContext(Dispatchers.IO) { db.hotcueNames(row.id) }
                    val complete = cached != null && cached.keyTonic >= 0 && cached.energy >= 0f
                    val a0 = cached ?: Analysis(0.0, 0L, 0f)
                    NativeEngine.nativeSetRate(deck, 1f)
                    setDeck(deck) {
                        it.copy(
                            trackId = row.id, title = row.title, artist = row.artist, loading = false, analyzing = !complete,
                            loadProgress = 1f, lengthFrames = frames, wave = wave,
                            bpm = a0.bpm, firstBeatFrame = a0.firstBeatFrame,
                            bpmConfidence = a0.confidence, rate = 1f, loopBeats = 0, hotcues = hot, hotcueNames = hotNames,
                            keyTonic = a0.keyTonic, keyMinor = a0.keyMinor, keyConf = a0.keyConf,
                            energy = a0.energy, tempoSections = emptyList(), tempoIdx = -1,
                        )
                    }
                    setKeyShift(deck, keyPrefs.getInt("t${row.id}", 0))
                    say(if (complete) "${row.title} pronta no deck ${deckName(deck)}." else "${row.title} pronta no deck ${deckName(deck)} (analisando andamento e tom…).")
                    // 2) o que falta (andamento, tom, energia, volume) em segundo plano, sem segurar o deck
                    val result2 = withContext(Dispatchers.Default) {
                        NeuralStems.workPriority()
                        var a = cached
                        if (a == null) {
                            val out = DoubleArray(3)
                            NativeEngine.nativeAnalyze(h, out)
                            a = withDownbeat(Analysis(out[0], out[1].toLong(), out[2].toFloat()), h)
                        }
                        if (a.keyTonic < 0) {
                            val k = IntArray(4)
                            NativeEngine.nativeAnalyzeKey(h, k)
                            // sem tonalidade válida guarda confiança 0: não tenta de novo a cada carga
                            a = if (k[0] == 1) a.copy(keyTonic = k[1], keyMinor = k[2] == 1, keyConf = k[3] / 1000f)
                            else a.copy(keyTonic = 0, keyMinor = false, keyConf = 0f)
                        }
                        if (a.energy < 0f) a = a.copy(energy = NativeEngine.nativeAnalyzeEnergy(h).coerceAtLeast(0f))
                        val fin: Analysis = a
                        if (!complete) db.saveAnalysis(row.id, fin)
                        val tm = try { tempoMapOf(row.id, h, fin) } catch (_: Exception) { emptyList() }
                        Triple(fin, NativeEngine.nativeAnalyzeLoudness(h), tm)
                    }
                    val (a, loud, tempo) = result2
                    setDeck(deck) {
                        if (it.trackId != row.id) it else it.copy(
                            analyzing = false, bpm = a.bpm, firstBeatFrame = a.firstBeatFrame, bpmConfidence = a.confidence,
                            keyTonic = a.keyTonic, keyMinor = a.keyMinor, keyConf = a.keyConf, energy = a.energy, loudness = loud,
                            tempoSections = tempo, tempoIdx = -1,
                        )
                    }
                    if (tempo.size > 1) say(
                        "${row.title}: andamento variável (${tempo.size} trechos, " +
                            String.format(java.util.Locale.ROOT, "%.1f a %.1f BPM", tempo.minOf { it.bpm }, tempo.maxOf { it.bpm }) +
                            if (_smartGrid.value) "); a grade acompanha cada trecho." else "). Ligue a GRADE INTELIGENTE em AJUSTES para a grade acompanhar.",
                    )
                    applyTrim(deck)
                    pushFx(deck)
                    applyAutoCues(deck)
                    refreshAutoSamples(deck)
                    if (!complete) say("${row.title}: ${if (a.bpm > 0) String.format(java.util.Locale.ROOT, "%.1f BPM", a.bpm) else "sem andamento"}${_decks.value[deck].key?.let { k -> ", tom ${k.code}" } ?: ""}.")
                    // 3) stems por último (demora mais)
                    separateStems(deck, h)
                } finally {
                    // sempre solta a referência nativa, mesmo se a carga for cancelada no meio da análise
                    NativeEngine.nativeFreeTrack(result.trackHandle)
                }

                is DecodeResult.Failed -> {
                    setDeck(deck) { it.copy(loading = false, title = current.title, artist = current.artist) }
                    say(result.reason)
                }
            }
        }
    }

    private fun setDeck(deck: Int, change: (DeckUi) -> DeckUi) {
        _decks.update { list -> list.mapIndexed { i, d -> if (i == deck) change(d) else d } }
    }

    // ---------------------------------------------------------------- biblioteca

    fun setSearch(text: String) {
        search.value = text
    }

    fun setSort(order: SortOrder) {
        sort.value = order
    }

    fun removeFromLibrary(row: TrackRow) {
        viewModelScope.launch(Dispatchers.IO) {
            db.delete(row.id)
            libraryVersion.update { it + 1 }
        }
    }

    fun importUris(uris: List<Uri>) {
        if (uris.isEmpty()) return
        say("Importando ${uris.size} arquivo(s)…")
        viewModelScope.launch(Dispatchers.IO) { addUris(uris) }
    }

    /** Importa todas as músicas de uma pasta (e subpastas) escolhida no seletor do Android. */
    private val folderPrefs = app.getSharedPreferences("pastas", android.content.Context.MODE_PRIVATE)
    private val _folders = MutableStateFlow(folderPrefs.getStringSet("lista", emptySet())!!.toList().sorted())
    /** Pastas importadas: o app procura músicas novas nelas ao abrir e no botão ATUALIZAR PASTAS. */
    val folders: StateFlow<List<String>> = _folders.asStateFlow()

    /** Ao abrir o app, procura sozinho músicas novas nas pastas importadas. */
    @Suppress("unused")
    private val folderScanAtStart = viewModelScope.launch { delay(5000); rescanFolders(quiet = true) }

    /** Procura músicas novas em todas as pastas importadas (as que já estão na biblioteca são ignoradas). */
    fun rescanFolders(quiet: Boolean = false) {
        val list = _folders.value
        if (list.isEmpty()) { if (!quiet) say("Nenhuma pasta importada ainda. Toque em IMPORTAR PASTA."); return }
        viewModelScope.launch(Dispatchers.IO) {
            val found = ArrayList<Uri>()
            for (f in list) {
                val tree = Uri.parse(f)
                try { collectAudio(tree, android.provider.DocumentsContract.getTreeDocumentId(tree), found, 0) } catch (_: Exception) { }
            }
            val known = db.allUris()
            val fresh = found.filter { it.toString() !in known }
            if (fresh.isEmpty()) { if (!quiet) say("Pastas atualizadas: nenhuma música nova.") ; return@launch }
            say("Achei ${fresh.size} música(s) nova(s) nas pastas. Importando…")
            addUris(fresh)
        }
    }

    fun forgetFolder(uri: String) {
        _folders.value = _folders.value - uri
        folderPrefs.edit().putStringSet("lista", _folders.value.toSet()).apply()
    }

    /**
     * TOCAR PASTA: importa a pasta (e subpastas), analisa o que faltar e liga o AUTO DJ só com as músicas dela.
     * Não precisa de mais nenhum toque: ele escolhe a ordem, carrega, sincroniza e mixa sozinho.
     */
    fun autoDjFolder(tree: Uri) {
        say("TOCAR PASTA: procurando as músicas…")
        viewModelScope.launch(Dispatchers.IO) {
            try {
                getApplication<Application>().contentResolver.takePersistableUriPermission(tree, Intent.FLAG_GRANT_READ_URI_PERMISSION)
            } catch (_: Exception) { }
            if (tree.toString() !in _folders.value) {
                _folders.value = (_folders.value + tree.toString()).sorted()
                folderPrefs.edit().putStringSet("lista", _folders.value.toSet()).apply()
            }
            val found = ArrayList<Uri>()
            try { collectAudio(tree, android.provider.DocumentsContract.getTreeDocumentId(tree), found, 0) } catch (_: Exception) {
                say("Não consegui ler essa pasta."); return@launch
            }
            if (found.isEmpty()) { say("Nenhuma música encontrada nessa pasta."); return@launch }
            val known = db.allUris()
            val fresh = found.filter { it.toString() !in known }
            if (fresh.isNotEmpty()) addUris(fresh)
            val set = found.map { it.toString() }.toSet()
            val ids = allTracks().filter { it.uri in set }.map { it.id }.toSet()
            if (ids.size < 2) { say("A pasta precisa de pelo menos 2 músicas que o celular consiga abrir."); return@launch }
            val name = android.provider.DocumentsContract.getTreeDocumentId(tree).substringAfterLast(':').substringAfterLast('/').ifEmpty { "pasta" }
            withContext(Dispatchers.Main) {
                say("TOCAR PASTA \"$name\": ${ids.size} músicas. O AUTO DJ analisa, escolhe a ordem e mixa sozinho.")
                autoDj.startWithPool(ids, "pasta \"$name\" (${ids.size} músicas)")
            }
        }
    }

    fun importFolder(tree: Uri) {
        say("Procurando músicas na pasta…")
        viewModelScope.launch(Dispatchers.IO) {
            try {
                getApplication<Application>().contentResolver
                    .takePersistableUriPermission(tree, Intent.FLAG_GRANT_READ_URI_PERMISSION)
            } catch (_: Exception) {
            }
            if (tree.toString() !in _folders.value) {
                _folders.value = (_folders.value + tree.toString()).sorted()
                folderPrefs.edit().putStringSet("lista", _folders.value.toSet()).apply()
            }
            val found = ArrayList<Uri>()
            try {
                val rootId = android.provider.DocumentsContract.getTreeDocumentId(tree)
                collectAudio(tree, rootId, found, 0)
            } catch (e: Exception) {
                say("Não consegui ler essa pasta.")
                return@launch
            }
            if (found.isEmpty()) {
                say("Nenhuma música encontrada nessa pasta.")
                return@launch
            }
            say("Achei ${found.size} músicas. Importando…")
            addUris(found)
        }
    }

    private fun collectAudio(tree: Uri, docId: String, out: MutableList<Uri>, depth: Int) {
        // sem limite prático: até 50 níveis de subpastas e 100 mil arquivos por pasta escolhida
        if (depth > 50 || out.size > 100_000) return
        val resolver = getApplication<Application>().contentResolver
        val children = android.provider.DocumentsContract.buildChildDocumentsUriUsingTree(tree, docId)
        val cols = arrayOf(
            android.provider.DocumentsContract.Document.COLUMN_DOCUMENT_ID,
            android.provider.DocumentsContract.Document.COLUMN_DISPLAY_NAME,
            android.provider.DocumentsContract.Document.COLUMN_MIME_TYPE,
        )
        val dirs = ArrayList<String>()
        resolver.query(children, cols, null, null, null)?.use { c ->
            while (c.moveToNext()) {
                val id = c.getString(0) ?: continue
                val name = c.getString(1).orEmpty()
                val mime = c.getString(2).orEmpty()
                if (mime == android.provider.DocumentsContract.Document.MIME_TYPE_DIR) dirs.add(id)
                else if (mime.startsWith("audio/") || hasAudioExtension(name)) {
                    out.add(android.provider.DocumentsContract.buildDocumentUriUsingTree(tree, id))
                }
            }
        }
        for (id in dirs) collectAudio(tree, id, out, depth + 1)
    }

    private fun hasAudioExtension(name: String): Boolean {
        val ext = name.substringAfterLast('.', "").lowercase()
        return ext in setOf("mp3", "wav", "flac", "m4a", "aac", "ogg", "oga", "opus", "wma", "aif", "aiff", "mp4")
    }

    private suspend fun addUris(uris: List<Uri>) {
        var added = 0
        var duplicated = 0
        var invalid = 0
        for ((i, uri) in uris.withIndex()) {
            // música de pasta importada: a permissão da PASTA já vale para todas (o Android guarda no máximo
            // 512 permissões por app; pedir uma por arquivo fazia bibliotecas grandes perderem as músicas antigas)
            if (!uri.toString().contains("/tree/")) try {
                getApplication<Application>().contentResolver
                    .takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION)
            } catch (_: Exception) {
                // nem todo provedor oferece permissão persistente
            }
            if (uris.size > 40 && i % 25 == 0) say("Importando ${i + 1} de ${uris.size}…")
            val meta = readMetadata(uri)
            if (meta == null) {
                invalid++
            } else if (db.insert(uri.toString(), meta.title, meta.artist, meta.durationMs, meta.genre)) {
                added++
            } else {
                duplicated++
            }
        }
        libraryVersion.update { it + 1 }
        val parts = ArrayList<String>()
        if (added > 0) parts.add("$added adicionada(s)")
        if (duplicated > 0) parts.add("$duplicated já estava(m) na biblioteca")
        if (invalid > 0) parts.add("$invalid não é/são áudio")
        say(if (parts.isEmpty()) "Nada foi importado." else parts.joinToString(" · "))
    }

    private class Meta(val title: String, val artist: String, val durationMs: Long, val genre: String = "")

    private fun readMetadata(uri: Uri): Meta? {
        val ctx = getApplication<Application>()
        val r = MediaMetadataRetriever()
        try {
            r.setDataSource(ctx, uri)
            val duration = r.extractMetadata(MediaMetadataRetriever.METADATA_KEY_DURATION)?.toLongOrNull() ?: 0L
            val hasAudio = r.extractMetadata(MediaMetadataRetriever.METADATA_KEY_HAS_AUDIO)
            val name = fileName(uri)
            // alguns aparelhos não preenchem HAS_AUDIO em m4a/ogg: aceita se tem duração ou extensão de áudio
            if (hasAudio != "yes" && duration <= 0L && !hasAudioExtension(name)) return null
            val title = r.extractMetadata(MediaMetadataRetriever.METADATA_KEY_TITLE)?.trim().orEmpty()
            val artist = r.extractMetadata(MediaMetadataRetriever.METADATA_KEY_ARTIST)?.trim().orEmpty()
            val genre = cleanGenre(r.extractMetadata(MediaMetadataRetriever.METADATA_KEY_GENRE))
            return Meta(title.ifEmpty { displayName(uri) }, artist, duration, genre)
        } catch (_: Exception) {
            return if (hasAudioExtension(fileName(uri))) Meta(displayName(uri), "", 0L) else null
        } finally {
            try {
                r.release()
            } catch (_: Exception) {
            }
        }
    }

    /** Gênero da etiqueta do arquivo: "(13)" e "13" viram o nome do gênero ID3; vazio quando não há. */
    private fun cleanGenre(raw: String?): String {
        var g = raw?.trim().orEmpty()
        val num = Regex("^\\(?(\\d{1,3})\\)?").find(g)?.groupValues?.get(1)?.toIntOrNull()
        if (num != null && g.replace(Regex("[()\\s\\d]"), "").isEmpty()) g = ID3_GENRES.getOrElse(num) { "" }
        return g.take(40)
    }

    /** Lê o gênero das músicas importadas antes da versão 2.8 (uma vez, em segundo plano, sem pressa). */
    private fun backfillGenres() {
        viewModelScope.launch(Dispatchers.IO) {
            delay(5000)   // depois da abertura do app
            android.os.Process.setThreadPriority(android.os.Process.THREAD_PRIORITY_BACKGROUND)
            var changed = 0
            while (true) {
                val batch = db.withoutGenre(50)
                if (batch.isEmpty()) break
                for ((id, uri) in batch) {
                    val g = try { readMetadata(Uri.parse(uri))?.genre.orEmpty() } catch (_: Exception) { "" }
                    db.setGenre(id, g)
                    if (g.isNotEmpty()) changed++
                }
                delay(200)
            }
            if (changed > 0) libraryVersion.update { it + 1 }
        }
    }

    /** Nome do arquivo com a extensão ("faixa.mp3"), ou "" se o provedor não informar. */
    private fun fileName(uri: Uri): String {
        try {
            getApplication<Application>().contentResolver
                .query(uri, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)?.use { c ->
                    if (c.moveToFirst()) return c.getString(0).orEmpty()
                }
        } catch (_: Exception) {
        }
        return uri.lastPathSegment.orEmpty()
    }

    private fun displayName(uri: Uri): String {
        try {
            getApplication<Application>().contentResolver
                .query(uri, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)?.use { c ->
                    if (c.moveToFirst()) {
                        val name = c.getString(0)
                        if (!name.isNullOrBlank()) return name.substringBeforeLast('.')
                    }
                }
        } catch (_: Exception) {
        }
        return "Faixa sem título"
    }


    // ------------------------------------------------------- gravar o set (exportar a mixagem)

    private val _recStart = MutableStateFlow<Long?>(null)
    /** Momento em que a gravação começou (null = não gravando). */
    val recordingSince: StateFlow<Long?> = _recStart.asStateFlow()
    private var recFile: java.io.File? = null

    /** GRAVAR: grava tudo o que sai no som geral num WAV e, ao parar, salva em Música/Edgard Guarda DJ Studio. */
    fun toggleRecording() {
        if (_recStart.value != null) { stopRecording(); return }
        val app = getApplication<Application>()
        val dir = app.getExternalFilesDir(android.os.Environment.DIRECTORY_MUSIC) ?: app.filesDir
        dir.mkdirs()
        val stamp = java.text.SimpleDateFormat("yyyy-MM-dd_HH-mm", java.util.Locale.ROOT).format(java.util.Date())
        val f = java.io.File(dir, "set_$stamp.wav")
        if (!NativeEngine.nativeRecordStart(f.absolutePath)) { say("Não consegui começar a gravar."); return }
        recFile = f
        _recStart.value = System.currentTimeMillis()
        say("Gravando o set. Toque em GRAVAR de novo para parar e salvar.")
    }

    private fun stopRecording() {
        val f = recFile
        val startedAt = _recStart.value
        _recStart.value = null
        recFile = null
        viewModelScope.launch(Dispatchers.IO) {
            val frames = NativeEngine.nativeRecordStop()
            if (f == null || frames <= 0) { say("Nada foi gravado (o som estava parado?)."); return@launch }
            val secs = frames / NativeEngine.SAMPLE_RATE
            say("Set gravado (${secs / 60} min). Compactando para M4A…")
            val m4a = wavToM4a(f)
            val final = if (m4a != null && m4a.length() > 0) { f.delete(); m4a } else f
            val where = publishRecording(final)
            val list = tracklistText(startedAt, "Edgard Guarda DJ Studio · ${final.nameWithoutExtension}")
            if (_history.value.any { it.atMs >= (startedAt ?: 0L) - 60_000 }) saveText(final.nameWithoutExtension + "_musicas.txt", list)
            say("Set gravado: ${final.name} (${secs / 60}:${String.format(java.util.Locale.ROOT, "%02d", secs % 60)}) em $where, com a lista das músicas em Documentos.")
        }
    }

    // --------------------------------------------------------- histórico da noite

    /** Uma música que foi ao ar: hora (ms do relógio), título, artista, andamento e tom. */
    data class Played(val atMs: Long, val trackId: Long, val title: String, val artist: String, val bpm: Double, val key: String?)

    private val _history = MutableStateFlow<List<Played>>(emptyList())
    /** Músicas que tocaram no som geral desde que o app abriu (ordem em que entraram). */
    val history: StateFlow<List<Played>> = _history.asStateFlow()
    private val onAir = LongArray(DECKS) { -1L }
    /** Faixas que já foram ao ar nesta noite (marcadas com ✓ na biblioteca para não repetir). */
    val playedIds: StateFlow<Set<Long>> = _history.map { h -> h.map { it.trackId }.toSet() }
        .stateIn(viewModelScope, SharingStarted.Eagerly, emptySet())

    /** Uma música "vai ao ar" quando toca com volume e com o crossfader do lado dela. */
    private fun checkOnAir() {
        val ds = _decks.value
        val xf = _crossfader.value
        val vols = _volumes.value
        for (d in 0 until DECKS) {
            val u = ds[d]
            val side = if (d % 2 == 0) xf < 0.8f else xf > 0.2f
            val audible = u.loaded && u.playing && vols[d] > 0.15f && side && u.trackId >= 0
            if (audible && onAir[d] != u.trackId) {
                onAir[d] = u.trackId
                if (_history.value.lastOrNull()?.trackId != u.trackId) {
                    _history.update { it + Played(System.currentTimeMillis(), u.trackId, u.title, u.artist, u.playedBpm, u.key?.code) }
                }
            }
        }
    }

    /** Texto da lista de músicas (a partir de [since] ms; tempos relativos a ele). */
    private fun tracklistText(since: Long?, title: String): String {
        val list = if (since == null) _history.value else _history.value.filter { it.atMs >= since - 60_000 }
        val t0 = since ?: list.firstOrNull()?.atMs ?: 0L
        val sb = StringBuilder("$title\n\n")
        for ((i, p) in list.withIndex()) {
            val sec = ((p.atMs - t0) / 1000).coerceAtLeast(0)
            val tm = String.format(java.util.Locale.ROOT, "%d:%02d:%02d", sec / 3600, (sec / 60) % 60, sec % 60)
            sb.append(String.format(java.util.Locale.ROOT, "%02d. [%s] %s%s  (%.0f BPM%s)\n", i + 1, tm, p.title,
                if (p.artist.isNotEmpty()) " — ${p.artist}" else "", p.bpm, p.key?.let { ", $it" } ?: ""))
        }
        return sb.toString()
    }

    /** Salva a lista da noite em Documentos/Edgard Guarda DJ Studio. */
    fun saveHistory() {
        if (_history.value.isEmpty()) { say("Nenhuma música foi ao ar ainda."); return }
        viewModelScope.launch(Dispatchers.IO) {
            val stamp = java.text.SimpleDateFormat("yyyy-MM-dd_HH-mm", java.util.Locale.ROOT).format(java.util.Date())
            val where = saveText("historico_$stamp.txt", tracklistText(null, "Edgard Guarda DJ Studio · músicas da noite ($stamp)"))
            say("Lista da noite salva em $where.")
        }
    }

    fun clearHistory() { _history.value = emptyList(); onAir.fill(-1L) }

    private fun saveText(name: String, text: String): String {
        val app = getApplication<Application>()
        if (android.os.Build.VERSION.SDK_INT >= 29) {
            try {
                val r = app.contentResolver
                val values = android.content.ContentValues().apply {
                    put(android.provider.MediaStore.MediaColumns.DISPLAY_NAME, name)
                    put(android.provider.MediaStore.MediaColumns.MIME_TYPE, "text/plain")
                    put(android.provider.MediaStore.MediaColumns.RELATIVE_PATH, "Documents/Edgard Guarda DJ Studio")
                }
                val uri = r.insert(android.provider.MediaStore.Files.getContentUri("external"), values)
                if (uri != null) {
                    r.openOutputStream(uri)?.use { it.write(text.toByteArray()) }
                    return "Documentos/Edgard Guarda DJ Studio"
                }
            } catch (_: Exception) { }
        }
        val dir = app.getExternalFilesDir(android.os.Environment.DIRECTORY_DOCUMENTS) ?: app.filesDir
        dir.mkdirs()
        java.io.File(dir, name).writeText(text)
        return dir.absolutePath
    }

    // ------------------------------------------------------------------ backup

    private val backupPrefs = listOf("output", "set", "autodj", "jog", "tom_por_musica", "playlists", "midi", "pastas", "andamento")

    /** Salva biblioteca (análises, grades, hot cues), playlists e ajustes num arquivo .zip em Documentos. */
    /** Biblioteca (análises, grades, cues, playlists) e ajustes num .zip. */
    private fun backupBytes(): ByteArray {
        val app = getApplication<Application>()
        val bytes = java.io.ByteArrayOutputStream()
        java.util.zip.ZipOutputStream(bytes).use { z ->
            db.writableDatabase.rawQuery("PRAGMA wal_checkpoint(FULL)", null).use { it.moveToFirst() }
            val dbFile = app.getDatabasePath("library.db")
            z.putNextEntry(java.util.zip.ZipEntry("library.db")); dbFile.inputStream().use { it.copyTo(z) }; z.closeEntry()
            for (pn in backupPrefs) {
                val f = java.io.File(app.applicationInfo.dataDir, "shared_prefs/$pn.xml")
                if (f.exists()) { z.putNextEntry(java.util.zip.ZipEntry("prefs/$pn.xml")); f.inputStream().use { it.copyTo(z) }; z.closeEntry() }
            }
        }
        return bytes.toByteArray()
    }

    private val _autoBackups = MutableStateFlow<List<java.io.File>>(emptyList())
    /** Backups automáticos guardados no app (os 5 últimos, mais novo primeiro). */
    val autoBackups: StateFlow<List<java.io.File>> = _autoBackups.asStateFlow()
    private fun autoBackupDir() = java.io.File(getApplication<Application>().filesDir, "backups").also { it.mkdirs() }
    private fun refreshAutoBackups() {
        _autoBackups.value = autoBackupDir().listFiles { f -> f.name.endsWith(".zip") }?.sortedByDescending { it.name }.orEmpty()
    }

    /**
     * Backup automático ao abrir o app (no máximo um a cada 12 horas): guarda os 5 últimos dentro do app e
     * uma cópia do dia em Documentos/Edgard Guarda DJ Studio/backups. Nada da biblioteca é alterado.
     */
    @Suppress("unused")
    private val autoBackupJob = viewModelScope.launch(Dispatchers.IO) {
        delay(8000)
        try {
            refreshAutoBackups()
            val newest = _autoBackups.value.firstOrNull()
            if (newest == null || System.currentTimeMillis() - newest.lastModified() > 12 * 3600_000L) {
                val stamp = java.text.SimpleDateFormat("yyyy-MM-dd_HH-mm", java.util.Locale.ROOT).format(java.util.Date())
                val data = backupBytes()
                java.io.File(autoBackupDir(), "backup_auto_$stamp.zip").writeBytes(data)
                autoBackupDir().listFiles { f -> f.name.endsWith(".zip") }?.sortedByDescending { it.name }?.drop(5)?.forEach { it.delete() }
                saveBytes("backup_auto_$stamp.zip", "application/zip", data, sub = "backups")
                refreshAutoBackups()
            }
        } catch (_: Exception) { }
    }

    fun exportBackup() {
        viewModelScope.launch(Dispatchers.IO) {
            val stamp = java.text.SimpleDateFormat("yyyy-MM-dd_HH-mm", java.util.Locale.ROOT).format(java.util.Date())
            val name = "backup_edgard_guarda_$stamp.zip"
            try {
                val where = saveBytes(name, "application/zip", backupBytes())
                say("Backup salvo: $name em $where.")
            } catch (e: Exception) {
                say("Não consegui salvar o backup: ${e.message}")
            }
        }
    }

    /** Restaura um backup .zip escolhido pelo usuário. O app precisa ser reaberto depois. */
    fun importBackup(uri: Uri) {
        viewModelScope.launch(Dispatchers.IO) {
            val app = getApplication<Application>()
            try {
                var gotDb = false
                app.contentResolver.openInputStream(uri)?.use { input ->
                    java.util.zip.ZipInputStream(input).use { z ->
                        while (true) {
                            val e = z.nextEntry ?: break
                            when {
                                e.name == "library.db" -> {
                                    db.close()
                                    val dbFile = app.getDatabasePath("library.db")
                                    java.io.File(dbFile.path + "-wal").delete(); java.io.File(dbFile.path + "-shm").delete()
                                    dbFile.outputStream().use { z.copyTo(it) }
                                    gotDb = true
                                }
                                e.name.startsWith("prefs/") && e.name.endsWith(".xml") -> {
                                    val pn = e.name.removePrefix("prefs/").removeSuffix(".xml")
                                    if (pn in backupPrefs) java.io.File(app.applicationInfo.dataDir, "shared_prefs/$pn.xml").outputStream().use { z.copyTo(it) }
                                }
                            }
                        }
                    }
                }
                if (!gotDb) { say("Esse arquivo não é um backup do Edgard Guarda DJ Studio."); return@launch }
                say("Backup restaurado. Feche e abra o app para carregar tudo.")
            } catch (e: Exception) {
                say("Não consegui restaurar: ${e.message}")
            }
        }
    }

    private fun saveBytes(name: String, mime: String, data: ByteArray, sub: String = ""): String {
        val app = getApplication<Application>()
        if (android.os.Build.VERSION.SDK_INT >= 29) {
            try {
                val r = app.contentResolver
                val values = android.content.ContentValues().apply {
                    put(android.provider.MediaStore.MediaColumns.DISPLAY_NAME, name)
                    put(android.provider.MediaStore.MediaColumns.MIME_TYPE, mime)
                    put(android.provider.MediaStore.MediaColumns.RELATIVE_PATH, "Documents/Edgard Guarda DJ Studio" + if (sub.isNotEmpty()) "/$sub" else "")
                }
                val uri = r.insert(android.provider.MediaStore.Files.getContentUri("external"), values)
                if (uri != null) {
                    r.openOutputStream(uri)?.use { it.write(data) }
                    return "Documentos/Edgard Guarda DJ Studio" + if (sub.isNotEmpty()) "/$sub" else ""
                }
            } catch (_: Exception) { }
        }
        val dir = app.getExternalFilesDir(android.os.Environment.DIRECTORY_DOCUMENTS) ?: app.filesDir
        dir.mkdirs()
        java.io.File(dir, name).writeBytes(data)
        return dir.absolutePath
    }

    /**
     * Converte o WAV gravado para M4A (AAC 256 kbps, ~10 vezes menor, toca em qualquer celular, computador e
     * nas redes). Devolve o arquivo novo ou null se o aparelho não tiver o codificador.
     */
    private fun wavToM4a(wav: java.io.File): java.io.File? {
        val out = java.io.File(wav.parentFile, wav.nameWithoutExtension + ".m4a")
        var codec: android.media.MediaCodec? = null
        var muxer: android.media.MediaMuxer? = null
        try {
            val input = java.io.RandomAccessFile(wav, "r")
            input.use { raf ->
                // procura o bloco "data" do WAV
                val hdr = ByteArray(12); raf.readFully(hdr)
                var dataLen = 0L
                var rate = NativeEngine.SAMPLE_RATE
                var ch = 2
                while (raf.filePointer < raf.length()) {
                    val id = ByteArray(4); raf.readFully(id)
                    val len = Integer.reverseBytes(raf.readInt()).toLong() and 0xFFFFFFFFL
                    val name = String(id)
                    if (name == "fmt ") {
                        val f = ByteArray(len.toInt()); raf.readFully(f)
                        ch = (f[2].toInt() and 0xFF) or ((f[3].toInt() and 0xFF) shl 8)
                        rate = (f[4].toInt() and 0xFF) or ((f[5].toInt() and 0xFF) shl 8) or ((f[6].toInt() and 0xFF) shl 16) or ((f[7].toInt() and 0xFF) shl 24)
                    } else if (name == "data") { dataLen = len; break } else raf.seek(raf.filePointer + len)
                }
                if (dataLen <= 0) return null
                dataLen = minOf(dataLen, raf.length() - raf.filePointer)
                val fmt = android.media.MediaFormat.createAudioFormat(android.media.MediaFormat.MIMETYPE_AUDIO_AAC, rate, ch)
                fmt.setInteger(android.media.MediaFormat.KEY_AAC_PROFILE, android.media.MediaCodecInfo.CodecProfileLevel.AACObjectLC)
                fmt.setInteger(android.media.MediaFormat.KEY_BIT_RATE, 256_000)
                fmt.setInteger(android.media.MediaFormat.KEY_MAX_INPUT_SIZE, 16384)
                val c = android.media.MediaCodec.createEncoderByType(android.media.MediaFormat.MIMETYPE_AUDIO_AAC)
                codec = c
                c.configure(fmt, null, null, android.media.MediaCodec.CONFIGURE_FLAG_ENCODE)
                c.start()
                val m = android.media.MediaMuxer(out.absolutePath, android.media.MediaMuxer.OutputFormat.MUXER_OUTPUT_MPEG_4)
                muxer = m
                var track = -1
                var muxing = false
                val info = android.media.MediaCodec.BufferInfo()
                var readTotal = 0L
                var inputDone = false
                val bytesPerFrame = 2 * ch
                val buf = ByteArray(8192)
                while (true) {
                    if (!inputDone) {
                        val ii = c.dequeueInputBuffer(10_000)
                        if (ii >= 0) {
                            val ib = c.getInputBuffer(ii)!!
                            ib.clear()
                            val want = minOf(minOf(ib.remaining(), buf.size).toLong(), dataLen - readTotal).toInt() / bytesPerFrame * bytesPerFrame
                            if (want <= 0) {
                                c.queueInputBuffer(ii, 0, 0, readTotal / bytesPerFrame * 1_000_000L / rate, android.media.MediaCodec.BUFFER_FLAG_END_OF_STREAM)
                                inputDone = true
                            } else {
                                raf.readFully(buf, 0, want)
                                ib.put(buf, 0, want)
                                c.queueInputBuffer(ii, 0, want, readTotal / bytesPerFrame * 1_000_000L / rate, 0)
                                readTotal += want
                            }
                        }
                    }
                    val oi = c.dequeueOutputBuffer(info, 10_000)
                    if (oi == android.media.MediaCodec.INFO_OUTPUT_FORMAT_CHANGED) {
                        track = m.addTrack(c.outputFormat); m.start(); muxing = true
                    } else if (oi >= 0) {
                        val ob = c.getOutputBuffer(oi)!!
                        if ((info.flags and android.media.MediaCodec.BUFFER_FLAG_CODEC_CONFIG) != 0) info.size = 0
                        if (info.size > 0 && muxing) {
                            ob.position(info.offset); ob.limit(info.offset + info.size)
                            m.writeSampleData(track, ob, info)
                        }
                        c.releaseOutputBuffer(oi, false)
                        if ((info.flags and android.media.MediaCodec.BUFFER_FLAG_END_OF_STREAM) != 0) break
                    }
                }
            }
            return out
        } catch (e: Throwable) {
            android.util.Log.w("DJFusion", "M4A falhou", e)
            out.delete()
            return null
        } finally {
            runCatching { codec?.stop() }; runCatching { codec?.release() }
            runCatching { muxer?.stop() }; runCatching { muxer?.release() }
        }
    }

    /** Copia o WAV para a pasta Música do aparelho (aparece nos apps de música e no gerenciador de arquivos). */
    private fun publishRecording(f: java.io.File): String {
        if (android.os.Build.VERSION.SDK_INT < 29) return f.parent ?: "pasta do app"
        return try {
            val r = getApplication<Application>().contentResolver
            val values = android.content.ContentValues().apply {
                put(android.provider.MediaStore.Audio.Media.DISPLAY_NAME, f.name)
                put(android.provider.MediaStore.Audio.Media.MIME_TYPE, if (f.extension == "m4a") "audio/mp4" else "audio/x-wav")
                put(android.provider.MediaStore.Audio.Media.RELATIVE_PATH, "Music/Edgard Guarda DJ Studio")
                put(android.provider.MediaStore.Audio.Media.IS_PENDING, 1)
            }
            val uri = r.insert(android.provider.MediaStore.Audio.Media.EXTERNAL_CONTENT_URI, values) ?: return f.parent ?: ""
            r.openOutputStream(uri)?.use { out -> f.inputStream().use { it.copyTo(out) } }
            values.clear()
            values.put(android.provider.MediaStore.Audio.Media.IS_PENDING, 0)
            r.update(uri, values, null, null)
            f.delete()
            lastRecording = uri
            "Música/Edgard Guarda DJ Studio"
        } catch (_: Exception) {
            f.parent ?: "pasta do app"
        }
    }

    /** Último set gravado (para importar de volta ou conferir). */
    var lastRecording: Uri? = null
        private set

    // ------------------------------------------------------- efeitos de performance

    private val fxJobs = arrayOfNulls<Job>(DECKS)

    private fun runFx(deck: Int, block: suspend () -> Unit) {
        fxJobs[deck]?.cancel()
        fxJobs[deck] = viewModelScope.launch { block() }
    }

    private fun beatSec(deck: Int): Double {
        val d = _decks.value[deck]
        return if (d.hasBpm) 60.0 / d.playedBpm else 0.5
    }

    /** ECHO OUT: eco forte no ritmo e o som do deck some em 2 compassos (sai de cena sem corte seco). */
    fun echoOut(deck: Int) {
        val d = _decks.value[deck]
        if (!d.playing) { say("ECHO OUT precisa do deck ${deckName(deck)} tocando."); return }
        runFx(deck) {
            val vol0 = _volumes.value[deck]
            setDeck(deck) { it.copy(fxType = 1, fxAmount = 0.85f) }
            pushFx(deck)
            val total = beatSec(deck) * 8
            val t0 = System.nanoTime()
            while (true) {
                val t = ((System.nanoTime() - t0) / 1e9 / total).coerceIn(0.0, 1.0)
                if (t >= 0.25) NativeEngine.nativeSetVolume(deck, (vol0 * (1.0 - (t - 0.25) / 0.75)).toFloat().coerceAtLeast(0f))
                if (t >= 1.0) break
                delay(30)
            }
            NativeEngine.nativePause(deck)
            delay(beatSec(deck).times(4000).toLong())   // deixa o eco morrer
            setDeck(deck) { it.copy(fxType = 0) }
            pushFx(deck)
            setVolume(deck, vol0)
        }
    }

    /** FILTRO AUTO: o filtro sobe (tira os graves) por 4 compassos e volta, para criar tensão antes da virada. */
    fun filterSweep(deck: Int) {
        runFx(deck) {
            val total = beatSec(deck) * 16
            val t0 = System.nanoTime()
            while (true) {
                val t = ((System.nanoTime() - t0) / 1e9 / total).coerceIn(0.0, 1.0)
                val x = if (t < 0.75) 0.5 + 0.42 * (t / 0.75) else 0.92 - 0.42 * ((t - 0.75) / 0.25)
                setFilter(deck, x.toFloat())
                if (t >= 1.0) break
                delay(30)
            }
            setFilter(deck, 0.5f)
        }
    }

    /** FREIO: o disco desacelera até parar, como desligar o toca-discos. */
    fun brake(deck: Int) {
        val d = _decks.value[deck]
        if (!d.playing) { say("FREIO precisa do deck ${deckName(deck)} tocando."); return }
        runFx(deck) {
            val r0 = d.rate
            val steps = 30
            for (i in 1..steps) {
                NativeEngine.nativeSetRate(deck, (r0 * (1f - i.toFloat() / steps)).coerceAtLeast(0.02f))
                delay(25)
            }
            NativeEngine.nativePause(deck)
            NativeEngine.nativeSetRate(deck, r0)
        }
    }

    /** VOLTA (spinback): o disco gira rápido para trás e para. */
    fun spinback(deck: Int) {
        val d = _decks.value[deck]
        if (!d.playing) { say("VOLTA precisa do deck ${deckName(deck)} tocando."); return }
        runFx(deck) {
            for (i in 0 until 20) {
                val v = -4f * (1f - i / 20f)
                NativeEngine.nativeScratch(deck, true, v)
                delay(30)
            }
            NativeEngine.nativeScratch(deck, true, 0f)
            NativeEngine.nativePause(deck)
            NativeEngine.nativeScratch(deck, false, 0f)
        }
    }

    // ------------------------------------------------------- HARMONIZAR (ordem do set)


    private fun saveSet(ids: List<Long>) {
        _set.value = ids
        setPrefs.edit().putString("ids", ids.joinToString(",")).apply()
    }

    fun clearSet() { saveSet(emptyList()); _activePlaylist.value = null; say("Ordem do set apagada.") }

    // ------------------------------------------------------------------ PLAYLISTS
    // A ordem do set é a playlist ativa (a que o AUTO DJ segue). Playlists salvas ficam guardadas pelo nome.

    private val plPrefs = app.getSharedPreferences("playlists", android.content.Context.MODE_PRIVATE)
    private val _playlists = MutableStateFlow(readPlaylists())
    val playlists: StateFlow<Map<String, List<Long>>> = _playlists.asStateFlow()
    private val _activePlaylist = MutableStateFlow<String?>(plPrefs.getString("_ativa", null))
    val activePlaylist: StateFlow<String?> = _activePlaylist.asStateFlow()

    private fun readPlaylists(): Map<String, List<Long>> {
        val raw = plPrefs.getString("todas", null) ?: return emptyMap()
        return try {
            val o = org.json.JSONObject(raw)
            o.keys().asSequence().associateWith { k ->
                val a = o.getJSONArray(k)
                List(a.length()) { a.getLong(it) }
            }.toSortedMap(String.CASE_INSENSITIVE_ORDER)
        } catch (e: org.json.JSONException) {
            emptyMap()
        }
    }

    private fun writePlaylists(m: Map<String, List<Long>>) {
        val o = org.json.JSONObject()
        for ((k, v) in m) o.put(k, org.json.JSONArray(v))
        plPrefs.edit().putString("todas", o.toString()).apply()
        _playlists.value = m.toSortedMap(String.CASE_INSENSITIVE_ORDER)
    }

    private fun setActive(name: String?) {
        _activePlaylist.value = name
        plPrefs.edit().putString("_ativa", name).apply()
    }

    /** Põe ou tira a música da playlist ativa (no fim da lista). */
    fun toggleInSet(row: TrackRow) {
        val ids = _set.value
        if (row.id in ids) {
            saveSet(ids - row.id)
            say("${row.title} saiu da playlist.")
        } else {
            saveSet(ids + row.id)
            say("${row.title} entrou na playlist (posição ${ids.size + 1}).")
        }
        pendingRule = null
        _activePlaylist.value?.let { name ->
            writePlaylists(_playlists.value + (name to _set.value))
            // mexida à mão: deixa de ser lista inteligente (senão a música voltaria sozinha ao abrir)
            if (name in _smartLists.value) { writeRules(_smartLists.value - name); say("\"$name\" agora é uma playlist comum (você mexeu nela à mão).") }
        }
    }

    /** Salva a playlist ativa com um nome (substitui se já existir). */
    fun savePlaylist(name: String) {
        val n = name.trim().take(40)
        if (n.isEmpty()) { say("Dê um nome para a playlist."); return }
        if (_set.value.isEmpty()) { say("A playlist está vazia. Use + nas músicas ou HARMONIZAR."); return }
        writePlaylists(_playlists.value + (n to _set.value))
        val rule = pendingRule
        if (rule != null && !rule.isEmpty) writeRules(_smartLists.value + (n to rule)) else if (n in _smartLists.value && n != _activePlaylist.value) writeRules(_smartLists.value - n)
        setActive(n)
        say(if (rule != null && !rule.isEmpty) "Lista inteligente \"$n\" salva (${rule.describe()}): ${_set.value.size} música(s). Ao abrir, as novas que combinam entram sozinhas." else "Playlist \"$n\" salva com ${_set.value.size} música(s).")
    }

    /** Abre uma playlist salva: vira a ordem do set (o AUTO DJ passa a seguir ela). */
    fun openPlaylist(name: String) {
        val ids = _playlists.value[name] ?: return
        viewModelScope.launch {
            val all = allTracks()
            val existing = all.map { it.id }.toSet()
            var valid = ids.filter { it in existing }     // músicas removidas da biblioteca saem da lista
            val rule = _smartLists.value[name]
            var extra = 0
            if (rule != null) {
                // lista inteligente: as que ainda combinam ficam na ordem salva; as novas que combinam entram no fim
                val match = smartMatches(rule, all, if (rule.unplayed) playedIds.value else emptySet()).map { it.id }
                val keep = valid.filter { it in match }
                val added = match.filter { it !in keep }
                extra = added.size
                valid = keep + added
                writePlaylists(_playlists.value + (name to valid))
            }
            pendingRule = rule
            saveSet(valid)
            setActive(name)
            sort.value = SortOrder.SET
            say(
                if (rule != null) "Lista inteligente \"$name\": ${valid.size} música(s)" + (if (extra > 0) ", $extra nova(s)" else "") + ". O AUTO DJ segue esta ordem."
                else "Playlist \"$name\": ${valid.size} música(s). O AUTO DJ segue esta ordem.",
            )
        }
    }

    fun deletePlaylist(name: String) {
        writePlaylists(_playlists.value - name)
        if (name in _smartLists.value) writeRules(_smartLists.value - name)
        if (_activePlaylist.value == name) setActive(null)
        say("Playlist \"$name\" apagada (as músicas continuam na biblioteca).")
    }

    /** Começa uma playlist nova, vazia. */
    fun newPlaylist() {
        saveSet(emptyList())
        setActive(null)
        pendingRule = null
        say("Playlist nova: toque em + nas músicas para montar e depois em SALVAR.")
    }

    // ------------------------------------------------------------------ LISTAS INTELIGENTES (por regras)

    private fun readRules(): Map<String, SmartRule> {
        val raw = plPrefs.getString("regras", null) ?: return emptyMap()
        return try {
            val o = org.json.JSONObject(raw)
            o.keys().asSequence().mapNotNull { k -> SmartRule.decode(o.getString(k))?.let { k to it } }.toMap()
        } catch (e: org.json.JSONException) {
            emptyMap()
        }
    }
    private val _smartLists = MutableStateFlow(readRules())
    /** Playlists que são LISTAS INTELIGENTES (nome -> regra): ao abrir, entram sozinhas as músicas novas que combinam. */
    val smartLists: StateFlow<Map<String, SmartRule>> = _smartLists.asStateFlow()
    private fun writeRules(m: Map<String, SmartRule>) {
        val o = org.json.JSONObject()
        for ((k, v) in m) o.put(k, v.encode())
        plPrefs.edit().putString("regras", o.toString()).apply()
        _smartLists.value = m
    }
    /** Regra da lista montada agora e ainda não salva (SALVAR guarda a regra junto). */
    private var pendingRule: SmartRule? = null

    /** Músicas que obedecem à regra, do andamento mais lento ao mais rápido. */
    internal fun smartMatches(rule: SmartRule, rows: List<TrackRow>, played: Set<Long>): List<TrackRow> {
        fun norm(x: String) = java.text.Normalizer.normalize(x.lowercase(), java.text.Normalizer.Form.NFD).replace(Regex("\\p{M}+"), "").trim()
        val g = norm(rule.genre)
        return rows.filter { r ->
            val bpmOk = when (rule.bpm) {
                1 -> r.bpm > 0 && r.bpm < 100
                2 -> r.bpm >= 100 && r.bpm < 115
                3 -> r.bpm >= 115 && r.bpm < 128
                4 -> r.bpm >= 128 && r.bpm < 140
                5 -> r.bpm >= 140
                else -> true
            }
            val e = r.energyLevel
            val energyOk = when (rule.energy) {
                1 -> e in 1..4
                2 -> e in 4..7
                3 -> e >= 7
                else -> true
            }
            bpmOk && energyOk && (g.isEmpty() || norm(r.genre).contains(g)) && (!rule.fav || r.favorite) && (!rule.unplayed || r.id !in played)
        }.sortedWith(compareBy({ it.bpm <= 0 }, { it.bpm }))
    }

    /** Monta a playlist atual com todas as músicas que obedecem à regra. SALVAR guarda como LISTA INTELIGENTE. */
    fun buildSmartList(rule: SmartRule) {
        viewModelScope.launch {
            val found = smartMatches(rule, allTracks(), playedIds.value)
            if (found.isEmpty()) { say("Nenhuma música combina com: ${rule.describe()}."); return@launch }
            saveSet(found.map { it.id })
            setActive(null)
            pendingRule = rule
            sort.value = SortOrder.SET
            say("Lista inteligente: ${found.size} música(s) (${rule.describe()}). Dê um nome e toque em SALVAR para ela se atualizar sozinha.")
        }
    }

    /**
     * HARMONIZAR: ordena a biblioteca num caminho de mixagem: cada próxima faixa com tom compatível na Roda de
     * Camelot, andamento perto e energia subindo aos poucos até o pico (perto de 70% do set) e descendo no fim.
     * Analisa sozinho o que faltar.
     */
    fun harmonize() {
        viewModelScope.launch {
            _analysisProgress.value = "preparando"
            try {
                analyzeMissing { done, total -> _analysisProgress.value = "$done de $total" }
            } finally {
                _analysisProgress.value = null
            }
            val inSet = _set.value.toSet()
            val onlyPlaylist = _activePlaylist.value != null && inSet.size >= 2
            val all = allTracks().filter { it.bpm > 0 && (!onlyPlaylist || it.id in inSet) }
            if (all.size < 2) { say("HARMONIZAR precisa de pelo menos 2 músicas com andamento detectado."); return@launch }
            val start = _decks.value.firstOrNull { it.playing }?.trackId
            val order = withContext(Dispatchers.Default) {
                Harmonizer.order(
                    all.map { SetTrack(it.id, it.bpm, it.key, it.energy) }, start,
                )
            }
            saveSet(order.map { it.id })
            _activePlaylist.value?.let { name -> if (onlyPlaylist) writePlaylists(_playlists.value + (name to _set.value)) else setActive(null) }
            sort.value = SortOrder.SET
            say("Set harmonizado: ${order.size} músicas em ordem de tom, andamento e energia. O AUTO DJ segue esta ordem.")
        }
    }

    /** Próxima faixa do set depois de [afterId] que não esteja nos decks nem em [skip]. */
    fun nextInSet(afterId: Long, skip: Collection<Long>): Long? {
        val ids = _set.value
        if (ids.isEmpty()) return null
        val loaded = _decks.value.map { it.trackId }
        val start = ids.indexOf(afterId)
        for (k in 1..ids.size) {
            val id = ids[(start + k).mod(ids.size)]
            if (id !in loaded && id !in skip) return id
        }
        return null
    }


    // ------------------------------------------------------- navegador rápido e assistente de mixagem

    private val _browser = MutableStateFlow<Int?>(null)
    /** Deck para o qual o navegador rápido (carregar música sem sair da tela DJ) está aberto. */
    val browserDeck: StateFlow<Int?> = _browser.asStateFlow()
    fun openBrowser(deck: Int) { _browser.value = deck }
    fun closeBrowser() { _browser.value = null }

    /** Carrega pelo navegador rápido e fecha. */
    fun loadFromBrowser(deck: Int, row: TrackRow) {
        loadTrack(deck, row)
        if (!_decks.value[deck].playing) closeBrowser()
    }

    /** A faixa de referência para sugerir a próxima: a do outro deck (a que está tocando, de preferência). */
    fun referenceFor(deck: Int): SetTrack? {
        val d = _decks.value
        val other = d[(deck xor 1)]
        val src = if (other.loaded) other else if (d[deck].loaded) d[deck] else return null
        if (!src.hasBpm) return null
        return SetTrack(src.trackId, src.playedBpm, src.shownKey, src.energy)
    }

    /** PULO DE BATIDA: avança ou volta [beats] batidas sem perder o ritmo. */
    fun beatJump(deck: Int, beats: Int) {
        val d = _decks.value[deck]
        if (!d.loaded || d.loading) { say("Carregue uma música no deck ${deckName(deck)} primeiro."); return }
        if (!d.hasBpm) { say("Pulo de batida precisa do andamento detectado."); return }
        val beat = 60.0 * NativeEngine.SAMPLE_RATE / d.bpm
        val pos = _live.value.decks[deck].positionFrames
        val target = (pos + beats * beat).toLong().coerceIn(0L, (d.lengthFrames - 1).coerceAtLeast(0L))
        NativeEngine.nativeSeek(deck, target)
    }

    override fun onCleared() {
        for (d in 0..3) { NativeEngine.nativeCancelStems(d); NeuralStems.cancel(d) }
        decodeJobs.forEach { it?.cancel() }
        if (_recStart.value != null) NativeEngine.nativeRecordStop()
        midi.stop()
        router.stop()
        NativeEngine.nativeStop()
    }

    companion object {
        val BUILTIN_NAMES = listOf("BUZINA", "SIRENE", "LASER", "BUMBO 808", "PALMA", "SUBIDA", "DESCIDA", "EXPLOSÃO")
        /** Stems só para músicas até este tamanho (memória). */
        const val STEM_MAX_MINUTES = 30
        /** Volume alvo do auto-gain (dBFS RMS). */
        const val TARGET_DB = -12.0
        /** Faixas do fader de pitch (em %). */
        val PITCH_RANGES = listOf(8, 10, 12, 16, 25, 50, 100)
        val WAVE_ZOOMS = listOf(3f, 5f, 8f, 12f, 20f)
        val JUMP_SIZES = listOf(1, 2, 4, 8, 16, 32)
        /** Abaixo disto o andamento detectado é tratado como "não detectado". */
        const val MIN_BPM_CONFIDENCE = 0.3f

        fun deckName(deck: Int) = when (deck) { 0 -> "A"; 1 -> "B"; 2 -> "C"; else -> "D" }
        /** Quantidade de decks (A, B, C, D). C fica no lado do A no crossfader e D no lado do B. */
        const val DECKS = 4

        /**
         * Certificados oficiais (SHA-256). O primeiro é a chave atual do app. Ao publicar na Play Store, acrescente
         * aqui o "certificado da chave de assinatura do app" que a Play Console mostra (Integridade do app).
         */
        /** Palavras que marcam um aviso como erro (vai para o registro de erros do relatório). */
        private val ERROR_WORDS = listOf("erro", "falhou", "falha", "não consegui", "não abriu", "não foi possível", "parou:", "não deu")

        val OFFICIAL_CERTS = setOf(
            "70a69a678541f2edef10a671a9a5bf947296041b0874a88d7e3e7f9cbbf4af0e",
        )

        /** Gêneros numerados das etiquetas ID3 antigas (0 a 79), para MP3 que guardam só o número. */
        val ID3_GENRES = listOf(
            "Blues", "Classic Rock", "Country", "Dance", "Disco", "Funk", "Grunge", "Hip-Hop", "Jazz", "Metal",
            "New Age", "Oldies", "Other", "Pop", "R&B", "Rap", "Reggae", "Rock", "Techno", "Industrial",
            "Alternative", "Ska", "Death Metal", "Pranks", "Soundtrack", "Euro-Techno", "Ambient", "Trip-Hop", "Vocal", "Jazz+Funk",
            "Fusion", "Trance", "Classical", "Instrumental", "Acid", "House", "Game", "Sound Clip", "Gospel", "Noise",
            "AlternRock", "Bass", "Soul", "Punk", "Space", "Meditative", "Instrumental Pop", "Instrumental Rock", "Ethnic", "Gothic",
            "Darkwave", "Techno-Industrial", "Electronic", "Pop-Folk", "Eurodance", "Dream", "Southern Rock", "Comedy", "Cult", "Gangsta",
            "Top 40", "Christian Rap", "Pop/Funk", "Jungle", "Native American", "Cabaret", "New Wave", "Psychadelic", "Rave", "Showtunes",
            "Trailer", "Lo-Fi", "Tribal", "Acid Punk", "Acid Jazz", "Polka", "Retro", "Musical", "Rock & Roll", "Hard Rock",
        )
    }
}
