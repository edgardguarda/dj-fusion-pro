package app.djfusion.ui

import android.app.Application
import android.content.Intent
import android.media.MediaMetadataRetriever
import android.net.Uri
import android.provider.OpenableColumns
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import app.djfusion.audio.DecodeResult
import app.djfusion.audio.NativeEngine
import app.djfusion.audio.TrackDecoder
import app.djfusion.audio.OutputRouter
import app.djfusion.audio.UsbOut
import app.djfusion.harmony.Camelot
import app.djfusion.harmony.MusicalKey
import app.djfusion.midi.MidiHub
import app.djfusion.data.Analysis
import app.djfusion.data.LibraryDb
import app.djfusion.data.SortOrder
import app.djfusion.data.TrackRow
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

/** Parte do deck que muda pouco (carregar, tocar, parar). */
data class DeckUi(
    val trackId: Long = -1,
    val title: String = "",
    val artist: String = "",
    val loaded: Boolean = false,
    val playing: Boolean = false,
    val loading: Boolean = false,
    val loadProgress: Float = 0f,
    val lengthFrames: Long = 0,
    val wave: ByteArray? = null,
    /** Andamento da faixa original (0 = não detectado) e onde cai a primeira batida. */
    val bpm: Double = 0.0,
    val firstBeatFrame: Long = 0,
    val bpmConfidence: Float = 0f,
    /** Velocidade de reprodução (1 = normal). O andamento tocado é bpm x rate. */
    val rate: Float = 1f,
    /** 0 = sem loop, senão o tamanho do loop em batidas. */
    val loopBeats: Int = 0,
    /** Hot cues: quadro de cada uma das 4 posições, -1 quando vazia. */
    val hotcues: List<Long> = listOf(-1L, -1L, -1L, -1L),
    /** Equalizador graves, médios, agudos (0,5 = neutro) e filtro (0,5 = desligado). */
    val eq: List<Float> = listOf(0.5f, 0.5f, 0.5f),
    val filter: Float = 0.5f,
    /** Efeito do deck: 0 desligado, 1 eco, 2 flanger, 3 reverb, e a mistura de 0 a 1. */
    val fxType: Int = 0,
    val fxAmount: Float = 0.5f,
    /** Key-lock: o andamento muda sem mudar o tom. */
    val keyLock: Boolean = false,
    /** Pré-escuta no fone (PFL). */
    val cueOn: Boolean = false,
    /** Tonalidade detectada da faixa (nota 0..11, -1 = desconhecida), modo e confiança. */
    val keyTonic: Int = -1,
    val keyMinor: Boolean = false,
    val keyConf: Float = 0f,
) {
    /** Tonalidade original, se detectada com confiança. */
    val key: MusicalKey?
        get() = if (keyTonic in 0..11 && keyConf >= Camelot.MIN_CONFIDENCE) MusicalKey.of(keyTonic, keyMinor) else null
    /** Tonalidade que se ouve agora: sem key-lock, mudar a velocidade desloca o tom. */
    val shownKey: MusicalKey? get() = if (keyLock) key else key?.shifted(Camelot.semitonesFor(rate))
    val hasBpm: Boolean get() = bpm > 0.0 && bpmConfidence >= AppViewModel.MIN_BPM_CONFIDENCE
    val playedBpm: Double get() = bpm * rate
}

/** Um pad do sampler. */
data class PadUi(val label: String = "", val loop: Boolean = false, val ready: Boolean = false, val playing: Boolean = false)

/** Parte que muda ~30 vezes por segundo (posição e nível). Fica separada para não redesenhar tudo. */
data class DeckLive(
    val positionFrames: Long = 0,
    val cueFrames: Long = 0,
    val peak: Float = 0f,
)

data class LiveUi(
    val decks: List<DeckLive> = listOf(DeckLive(), DeckLive()),
    val masterPeak: Float = 0f,
)

class AppViewModel(app: Application) : AndroidViewModel(app) {
    private val db = LibraryDb(app)
    private val outPrefs = app.getSharedPreferences("output", android.content.Context.MODE_PRIVATE)

    /** Saída do fone: 0 só som geral, 1 dividido (E fone, D geral), 2 quatro canais (1-2 geral, 3-4 fone). */
    private val _outMode = MutableStateFlow(outPrefs.getInt("mode", 0).coerceIn(0, 2))
    val outputMode: StateFlow<Int> = _outMode.asStateFlow()
    /** Aparelho de saída escolhido: -1 = automático (a primeira placa USB). */
    private val _outDevice = MutableStateFlow(outPrefs.getInt("device", -1))
    val outputDevice: StateFlow<Int> = _outDevice.asStateFlow()
    private val _outNote = MutableStateFlow("")
    val outputNote: StateFlow<String> = _outNote.asStateFlow()
    private val _hpLevel = MutableStateFlow(0.7f)
    val hpLevel: StateFlow<Float> = _hpLevel.asStateFlow()
    private val _hpMix = MutableStateFlow(0f)
    val hpMix: StateFlow<Float> = _hpMix.asStateFlow()
    val router = OutputRouter(app) { applyOutput() }
    val usbOutputs: StateFlow<List<UsbOut>> get() = router.devices

    private val _decks = MutableStateFlow(listOf(DeckUi(), DeckUi()))
    val decks: StateFlow<List<DeckUi>> = _decks.asStateFlow()

    private val _live = MutableStateFlow(LiveUi())
    val live: StateFlow<LiveUi> = _live.asStateFlow()

    private val _volumes = MutableStateFlow(listOf(1f, 1f))
    val volumes: StateFlow<List<Float>> = _volumes.asStateFlow()
    private val _crossfader = MutableStateFlow(0.5f)
    val crossfader: StateFlow<Float> = _crossfader.asStateFlow()
    private val _master = MutableStateFlow(0.8f)
    val master: StateFlow<Float> = _master.asStateFlow()

    private val _message = MutableStateFlow<String?>(null)
    val message: StateFlow<String?> = _message.asStateFlow()

    private val _audioStatus = MutableStateFlow("Áudio desligado")
    val audioStatus: StateFlow<String> = _audioStatus.asStateFlow()

    val search = MutableStateFlow("")
    val sort = MutableStateFlow(SortOrder.RECENT)
    private val libraryVersion = MutableStateFlow(0)

    val tracks: StateFlow<List<TrackRow>> =
        combine(search, sort, libraryVersion) { s, o, _ -> s to o }
            .map { (s, o) -> withContext(Dispatchers.IO) { db.query(s, o) } }
            .stateIn(viewModelScope, SharingStarted.Eagerly, emptyList())

    private val decodeJobs = arrayOfNulls<Job>(2)

    private var foreground = true

    /** Controladoras MIDI USB (Numark etc.). Os controles aprendidos chegam em [onMidi]. */
    val midi = MidiHub(app) { id, v -> onMidi(id, v) }

    private fun onMidi(id: String, v: Float) {
        if (id == "xfade") { setCrossfader(v); return }
        if (id == "master") { setMaster(v); return }
        if (id == "autodj") { autoDj.toggle(); return }
        if (id.startsWith("pad")) { padPress(id.substring(3).toInt() - 1); return }
        if (id == "hpvol") { setHeadphoneLevel(v); return }
        if (id == "hpmix") { setHeadphoneMix(v); return }
        val deck = id[1].digitToInt()
        val k = id.substring(3)
        when {
            k == "play" -> togglePlay(deck)
            k == "cue" -> cue(deck)
            k == "sync" -> sync(deck)
            k == "vol" -> setVolume(deck, v)
            k == "eqhi" -> setEq(deck, 2, v)
            k == "eqmid" -> setEq(deck, 1, v)
            k == "eqlo" -> setEq(deck, 0, v)
            k == "filter" -> setFilter(deck, v)
            k == "tempo" -> setPitchFader(deck, v)
            k == "fxamt" -> setFxAmount(deck, v)
            k == "jog" -> jog.tick(deck, v.toInt())
            k == "jogtouch" -> jog.touch(deck, v > 0.5f)
            k == "keylock" -> toggleKeyLock(deck)
            k == "pfl" -> toggleHeadphoneCue(deck)
            k == "fxeco" -> setFx(deck, 1)
            k == "fxflg" -> setFx(deck, 2)
            k == "fxrev" -> setFx(deck, 3)
            k.startsWith("hot") -> hotcue(deck, k.substring(3).toInt() - 1)
            k.startsWith("loop") -> toggleLoop(deck, k.substring(4).toInt())
        }
    }
    private var stopJob: Job? = null

    /** AUTO DJ: o app escolhe as músicas e faz as mixagens sozinho. */
    val autoDj = AutoDj(this, viewModelScope)

    /** Jog wheel das controladoras (scratch e ajuste fino). */
    val jog = JogController(app.getSharedPreferences("jog", android.content.Context.MODE_PRIVATE), this, viewModelScope)

    // ---------------------------------------------------------------- sampler

    private val _pads = MutableStateFlow(List(8) { PadUi() })
    val pads: StateFlow<List<PadUi>> = _pads.asStateFlow()
    private val _samplerVol = MutableStateFlow(0.8f)
    val samplerVol: StateFlow<Float> = _samplerVol.asStateFlow()

    /** Escolhe sozinho os melhores trechos das músicas dos decks e os coloca nos pads (4 por deck). */
    fun buildSamples() {
        val decks = _decks.value
        if (decks.none { it.loaded && !it.loading }) {
            say("Carregue uma música em pelo menos um deck para gerar as amostras.")
            return
        }
        viewModelScope.launch(Dispatchers.Default) {
            android.os.Process.setThreadPriority(android.os.Process.THREAD_PRIORITY_BACKGROUND)
            NativeEngine.nativeClearSamples()
            val list = MutableList(8) { PadUi() }
            val info = LongArray(12)
            var total = 0
            for (deck in 0..1) {
                val d = decks[deck]
                if (!d.loaded || d.loading) continue
                val n = NativeEngine.nativeBuildSamples(deck, if (d.hasBpm) d.bpm else 0.0, d.firstBeatFrame, deck * 4, info)
                for (k in 0 until n) {
                    val kind = info[3 * k].toInt()
                    val loop = info[3 * k + 2] == 1L
                    val what = when (kind) {
                        0 -> "BUMBO"
                        1 -> "GOLPE"
                        2 -> if (loop) "LOOP 1 COMPASSO" else "TRECHO FORTE"
                        else -> "LOOP 2 COMPASSOS"
                    }
                    list[deck * 4 + k] = PadUi("${deckName(deck)} · $what", loop, true, false)
                }
                total += n
            }
            _pads.value = list
            NativeEngine.nativeSetSamplerVolume(_samplerVol.value)
            say(if (total > 0) "$total amostras prontas nos pads." else "Não achei trechos bons nessas faixas.")
        }
    }

    fun clearSamples() {
        NativeEngine.nativeClearSamples()
        _pads.value = List(8) { PadUi() }
    }

    /** Pad de golpe toca uma vez; pad de loop liga e desliga o loop. */
    fun padPress(slot: Int) {
        val pad = _pads.value.getOrNull(slot) ?: return
        if (!pad.ready) return
        if (pad.loop) {
            if (pad.playing) NativeEngine.nativeStopSample(slot) else NativeEngine.nativeTriggerSample(slot, true)
        } else {
            NativeEngine.nativeTriggerSample(slot, false)
        }
    }

    fun setSamplerVolume(v: Float) {
        _samplerVol.value = v
        NativeEngine.nativeSetSamplerVolume(v)
    }

    // ------------------------------------------------- análise da biblioteca

    private val _analysisProgress = MutableStateFlow<String?>(null)
    /** Texto de andamento da análise em lote ("3 de 20"), ou null quando parada. */
    val analysisProgress: StateFlow<String?> = _analysisProgress.asStateFlow()
    private var analyzeJob: Job? = null

    /** Analisa andamento e tom de todas as faixas da biblioteca que ainda não foram analisadas. */
    fun analyzeLibrary() {
        if (analyzeJob?.isActive == true) {
            analyzeJob?.cancel()
            _analysisProgress.value = null
            return
        }
        analyzeJob = viewModelScope.launch {
            val todo = withContext(Dispatchers.IO) { db.unanalyzed() }
            if (todo.isEmpty()) {
                say("Todas as faixas já foram analisadas.")
                return@launch
            }
            var done = 0
            try {
                for (row in todo) {
                    _analysisProgress.value = "${done + 1} de ${todo.size}"
                    val r = TrackDecoder.decode(getApplication(), Uri.parse(row.uri)) { }
                    if (r is DecodeResult.Ready) {
                        try {
                            withContext(Dispatchers.Default) {
                                android.os.Process.setThreadPriority(android.os.Process.THREAD_PRIORITY_BACKGROUND)
                                var a = db.analysis(row.id)
                                if (a == null) {
                                    val out = DoubleArray(3)
                                    NativeEngine.nativeAnalyze(r.trackHandle, out)
                                    a = Analysis(out[0], out[1].toLong(), out[2].toFloat())
                                }
                                if (a.keyTonic < 0) {
                                    val k = IntArray(4)
                                    NativeEngine.nativeAnalyzeKey(r.trackHandle, k)
                                    a = if (k[0] == 1) a.copy(keyTonic = k[1], keyMinor = k[2] == 1, keyConf = k[3] / 1000f)
                                    else a.copy(keyTonic = 0, keyMinor = false, keyConf = 0f)
                                }
                                db.saveAnalysis(row.id, a)
                            }
                        } finally {
                            NativeEngine.nativeFreeTrack(r.trackHandle)
                        }
                    }
                    done++
                    libraryVersion.update { it + 1 }
                }
                say("Análise concluída: $done faixa(s).")
            } finally {
                _analysisProgress.value = null
            }
        }
    }

    /** Todas as faixas da biblioteca, com o que já foi analisado (para o AUTO DJ). */
    suspend fun allTracks(): List<TrackRow> = withContext(Dispatchers.IO) { db.query("", SortOrder.RECENT) }

    /** Carrega a faixa no deck e espera terminar. Devolve false se falhou. */
    suspend fun loadTrackAndWait(deck: Int, row: TrackRow): Boolean {
        loadTrack(deck, row)
        var waited = 0
        while (waited < 600) {                       // até 60 s
            delay(100)
            waited++
            val d = _decks.value[deck]
            if (!d.loading) return d.loaded && d.trackId == row.id
        }
        return false
    }

    init {
        midi.start()
        router.start()
        // O motor C++ vive no processo, não na Activity: se a tela foi fechada e reaberta sem o processo
        // morrer, ele ainda guarda as faixas e o estado de tocar da vez anterior. Começamos do zero.
        for (d in 0..1) {
            NativeEngine.nativeUnload(d)
            NativeEngine.nativeSetRate(d, 1f)
            NativeEngine.nativeSetFilter(d, 0.5f)
            NativeEngine.nativeSetFx(d, 0, 0.5f, 0.5f)
            NativeEngine.nativeClearLoop(d)
            NativeEngine.nativeSetKeyLock(d, false)
            NativeEngine.nativeSetHeadphoneCue(d, false)
            for (b in 0..2) NativeEngine.nativeSetEq(d, b, 0.5f)
        }
        startPolling()
    }

    /**
     * Chamado pela Activity em onStart (true) e onStop (false). Sem serviço em primeiro plano o Android
     * não garante áudio em segundo plano, então ao sair o app pausa os decks e fecha a saída de áudio.
     */
    fun onForeground(on: Boolean) {
        foreground = on
        stopJob?.cancel()
        if (on) {
            startAudio()
        } else {
            NativeEngine.nativePause(0)
            NativeEngine.nativePause(1)
            stopJob = viewModelScope.launch(Dispatchers.Default) {
                delay(150) // deixa a rampa de 4 ms da pausa terminar antes de fechar o fluxo
                if (!foreground) NativeEngine.nativeStop()
            }
        }
    }

    private fun startAudio() {
        // Abrir o fluxo exclusivo do Oboe pode demorar: fora da thread principal.
        viewModelScope.launch(Dispatchers.Default) {
            NativeEngine.nativeConfigureOutput(_outMode.value, resolveDevice())
            val ok = NativeEngine.nativeStart()
            if (ok) {
                NativeEngine.nativeSetHeadphoneLevel(_hpLevel.value)
                NativeEngine.nativeSetHeadphoneMix(_hpMix.value)
                NativeEngine.nativeSetMaster(_master.value)
                NativeEngine.nativeSetCrossfader(_crossfader.value)
                NativeEngine.nativeSetVolume(0, _volumes.value[0])
                NativeEngine.nativeSetVolume(1, _volumes.value[1])
                refreshAudioStatus()
            } else {
                _audioStatus.value = "Sem áudio"
                say("Não consegui abrir a saída de áudio do aparelho.")
            }
        }
    }

    private fun refreshAudioStatus() {
        val info = IntArray(6)
        NativeEngine.nativeStreamInfo(info)
        val bufferMs = if (info[0] > 0) info[2] * 1000f / info[0] else 0f
        _audioStatus.value = "%d Hz · buffer %.0f ms".format(java.util.Locale.ROOT, info[0], bufferMs)
        val want = _outMode.value
        val got = info[5]
        _outNote.value = when {
            want == 0 -> "Saída normal: o som geral sai em estéreo. O fone usa só o do próprio aparelho."
            got == 2 -> "Fone em 4 canais ativo: canais 1-2 som geral, canais 3-4 fone (${info[4]} canais abertos)."
            got == 1 && want == 2 -> "Este aparelho não abriu 4 canais; usando o modo dividido (esquerdo = fone, direito = som geral)."
            got == 1 -> "Modo dividido ativo: o lado esquerdo da saída leva o fone e o direito leva o som geral (ambos em mono)."
            else -> "Não consegui abrir a saída escolhida; voltei à saída normal."
        }
    }

    private fun resolveDevice(): Int {
        if (_outMode.value == 0) return 0
        val list = router.devices.value
        val pick = _outDevice.value
        return list.firstOrNull { it.id == pick }?.id ?: list.firstOrNull()?.id ?: 0
    }

    /** Reaplica a saída (modo ou aparelho mudou, ou uma placa USB entrou ou saiu). */
    private fun applyOutput() {
        viewModelScope.launch(Dispatchers.Default) {
            NativeEngine.nativeConfigureOutput(_outMode.value, resolveDevice())
            if (foreground) refreshAudioStatus()
        }
    }

    fun setOutputMode(mode: Int) {
        _outMode.value = mode.coerceIn(0, 2)
        outPrefs.edit().putInt("mode", _outMode.value).apply()
        applyOutput()
    }

    fun setOutputDevice(id: Int) {
        _outDevice.value = id
        outPrefs.edit().putInt("device", id).apply()
        applyOutput()
    }

    fun toggleKeyLock(deck: Int) {
        val on = !_decks.value[deck].keyLock
        setDeck(deck) { it.copy(keyLock = on) }
        NativeEngine.nativeSetKeyLock(deck, on)
    }

    fun toggleHeadphoneCue(deck: Int) {
        val on = !_decks.value[deck].cueOn
        setDeck(deck) { it.copy(cueOn = on) }
        NativeEngine.nativeSetHeadphoneCue(deck, on)
    }

    fun setHeadphoneLevel(v: Float) {
        _hpLevel.value = v
        NativeEngine.nativeSetHeadphoneLevel(v)
    }

    fun setHeadphoneMix(v: Float) {
        _hpMix.value = v
        NativeEngine.nativeSetHeadphoneMix(v)
    }

    /** Prato tocado: [velocity] em múltiplos da velocidade normal. */
    fun scratch(deck: Int, active: Boolean, velocity: Float) {
        NativeEngine.nativeScratch(deck, active, velocity)
    }

    private fun startPolling() {
        viewModelScope.launch {
            val buf = LongArray(4)
            var tick = 0
            while (isActive) {
                if (!foreground) {
                    delay(250)
                    continue
                }
                val states = ArrayList<LongArray>(2)
                val lives = ArrayList<DeckLive>(2)
                for (d in 0..1) {
                    NativeEngine.nativeDeckState(d, buf)
                    states.add(buf.copyOf())
                    lives.add(DeckLive(buf[1], buf[2], NativeEngine.nativeDeckPeak(d)))
                }
                _live.value = LiveUi(lives, NativeEngine.nativeMasterPeak())
                _decks.update { list ->
                    list.mapIndexed { i, d ->
                        val flags = states[i][0]
                        val playing = (flags and 2L) != 0L
                        val loaded = (flags and 1L) != 0L
                        if (d.playing == playing && d.loaded == loaded) d else d.copy(playing = playing, loaded = loaded)
                    }
                }
                val mask = NativeEngine.nativeSamplerMask()
                val padsNow = _pads.value
                if (padsNow.indices.any { ((mask shr it) and 1 == 1) != padsNow[it].playing }) {
                    _pads.value = padsNow.mapIndexed { i, p -> p.copy(playing = (mask shr i) and 1 == 1) }
                }
                if (++tick % 30 == 0) launch(Dispatchers.Default) { NativeEngine.nativeCollectGarbage() }
                delay(33)
            }
        }
    }

    // ----------------------------------------------------------------- mensagens

    fun say(text: String) {
        _message.value = text
    }

    fun clearMessage(text: String) {
        _message.update { if (it == text) null else it }
    }

    // ------------------------------------------------------------------- decks

    fun togglePlay(deck: Int) {
        if (_decks.value[deck].loading) {
            say("Espere a música terminar de carregar no deck ${deckName(deck)}.")
            return
        }
        val st = LongArray(4)
        NativeEngine.nativeDeckState(deck, st)
        if ((st[0] and 1L) == 0L) {
            say("Deck ${deckName(deck)} sem música. Abra a Biblioteca e toque em ${deckName(deck)}.")
            return
        }
        if ((st[0] and 2L) != 0L) NativeEngine.nativePause(deck) else NativeEngine.nativePlay(deck)
    }

    fun cue(deck: Int) = NativeEngine.nativeCue(deck)

    fun seekFraction(deck: Int, fraction: Float) {
        val length = _decks.value[deck].lengthFrames
        if (length <= 0) return
        NativeEngine.nativeSeek(deck, (fraction.coerceIn(0f, 1f) * length).toLong())
    }

    fun setVolume(deck: Int, v: Float) {
        _volumes.update { list -> list.mapIndexed { i, old -> if (i == deck) v else old } }
        NativeEngine.nativeSetVolume(deck, v)
    }

    fun setCrossfader(x: Float) {
        _crossfader.value = x
        NativeEngine.nativeSetCrossfader(x)
    }

    fun setMaster(v: Float) {
        _master.value = v
        NativeEngine.nativeSetMaster(v)
    }

    // ------------------------------------------------- equalizador, filtro e pitch

    private fun snapCenter(v: Float): Float = if (kotlin.math.abs(v - 0.5f) < 0.03f) 0.5f else v.coerceIn(0f, 1f)

    fun setEq(deck: Int, band: Int, v: Float) {
        val x = snapCenter(v)
        setDeck(deck) { d -> d.copy(eq = d.eq.mapIndexed { i, old -> if (i == band) x else old }) }
        NativeEngine.nativeSetEq(deck, band, x)
    }

    fun setFilter(deck: Int, v: Float) {
        val x = snapCenter(v)
        setDeck(deck) { it.copy(filter = x) }
        NativeEngine.nativeSetFilter(deck, x)
    }

    /** Posição do fader de pitch (0 a 1, 0,5 = velocidade normal) para a velocidade. */
    fun setPitchFader(deck: Int, fader: Float) {
        val f = if (kotlin.math.abs(fader - 0.5f) < 0.015f) 0.5f else fader.coerceIn(0f, 1f)
        applyRate(deck, PITCH_MIN + (PITCH_MAX - PITCH_MIN) * f)
    }

    /** Velocidade exata do deck (usado pelo AUTO DJ). */
    fun setRateExact(deck: Int, rate: Float) = applyRate(deck, rate.coerceIn(0.5f, 2f))

    /** Liga ou desliga o key-lock sem alternar. */
    fun setKeyLock(deck: Int, on: Boolean) {
        if (_decks.value[deck].keyLock == on) return
        toggleKeyLock(deck)
    }

    private fun applyRate(deck: Int, rate: Float) {
        setDeck(deck) { it.copy(rate = rate) }
        NativeEngine.nativeSetRate(deck, rate)
        pushFx(deck)
    }

    /** Liga o efeito [type] (toque de novo no mesmo para desligar). */
    fun setFx(deck: Int, type: Int) {
        val cur = _decks.value[deck].fxType
        setDeck(deck) { it.copy(fxType = if (cur == type) 0 else type) }
        pushFx(deck)
    }

    fun setFxAmount(deck: Int, v: Float) {
        setDeck(deck) { it.copy(fxAmount = v.coerceIn(0f, 1f)) }
        pushFx(deck)
    }

    /** Envia o efeito ao motor; o eco acompanha a batida do que está tocando. */
    private fun pushFx(deck: Int) {
        val d = _decks.value[deck]
        val beat = if (d.hasBpm) (60.0 / d.playedBpm).toFloat() else 0.5f
        NativeEngine.nativeSetFx(deck, d.fxType, d.fxAmount, beat)
    }

    /** Dobra ou divide por 2 o andamento detectado (a detecção pode errar por uma oitava). */
    fun scaleBpm(deck: Int, factor: Double) {
        setDeck(deck) { it.copy(bpm = (it.bpm * factor).coerceIn(30.0, 300.0)) }
        pushFx(deck)
        val d = _decks.value[deck]
        if (d.trackId >= 0 && d.bpm > 0) {
            viewModelScope.launch(Dispatchers.IO) { db.saveAnalysis(d.trackId, Analysis(d.bpm, d.firstBeatFrame, d.bpmConfidence)) }
        }
    }

    private fun posMod(a: Double, m: Double): Double = ((a % m) + m) % m

    /**
     * SYNC: iguala o andamento tocado deste deck ao do outro e, se o outro está tocando, alinha também a batida.
     * Só funciona com andamento detectado nos dois. Não é um SYNC contínuo: se o andamento oscilar, refaça.
     */
    fun sync(deck: Int) {
        val me = _decks.value[deck]
        val other = _decks.value[1 - deck]
        val name = deckName(deck)
        if (!me.loaded || !other.loaded) { say("SYNC precisa de música nos dois decks."); return }
        if (!me.hasBpm || !other.hasBpm) { say("SYNC precisa do andamento detectado nos dois decks."); return }
        val targetBpm = other.playedBpm
        var factor = 1.0
        var best = Double.MAX_VALUE
        for (k in doubleArrayOf(1.0, 2.0, 0.5)) {
            val r = targetBpm / (me.bpm * k)
            if (r in PITCH_MIN.toDouble()..PITCH_MAX.toDouble() && kotlin.math.abs(r - 1.0) < best) {
                best = kotlin.math.abs(r - 1.0)
                factor = k
            }
        }
        if (best == Double.MAX_VALUE) {
            say("Andamentos muito diferentes (%.1f e %.1f BPM). Ajuste o pitch à mão.".format(java.util.Locale.ROOT, me.bpm, targetBpm))
            return
        }
        applyRate(deck, (targetBpm / (me.bpm * factor)).toFloat())
        var aligned = false
        if (factor == 1.0 && other.playing) {
            val a = LongArray(4); val b = LongArray(4)
            NativeEngine.nativeDeckState(deck, a); NativeEngine.nativeDeckState(1 - deck, b)
            val sr = NativeEngine.SAMPLE_RATE.toDouble()
            val otherBeat = 60.0 * sr / other.bpm
            val myBeat = 60.0 * sr / me.bpm
            val phase = posMod(b[1] - other.firstBeatFrame.toDouble(), otherBeat) / otherBeat
            val cur = posMod(a[1] - me.firstBeatFrame.toDouble(), myBeat)
            var delta = phase * myBeat - cur
            if (delta > myBeat / 2) delta -= myBeat else if (delta < -myBeat / 2) delta += myBeat
            val target = (a[1] + delta).toLong().coerceIn(0L, (me.lengthFrames - 1).coerceAtLeast(0L))
            NativeEngine.nativeSeek(deck, target)
            aligned = true
        }
        say("Deck $name em %.1f BPM%s.".format(java.util.Locale.ROOT, targetBpm, if (aligned) ", batida alinhada" else ""))
    }

    // ------------------------------------------------------------- loops e hot cues

    fun toggleLoop(deck: Int, beats: Int) {
        val d = _decks.value[deck]
        if (!d.loaded) return
        if (d.loopBeats == beats) {
            NativeEngine.nativeClearLoop(deck)
            setDeck(deck) { it.copy(loopBeats = 0) }
            return
        }
        if (!d.hasBpm) { say("Loop por batidas precisa do andamento detectado."); return }
        val st = LongArray(4)
        NativeEngine.nativeDeckState(deck, st)
        val beat = 60.0 * NativeEngine.SAMPLE_RATE / d.bpm
        val first = d.firstBeatFrame.toDouble()
        val start = kotlin.math.max(0.0, first + kotlin.math.floor((st[1] - first) / beat) * beat)
        val end = start + beats * beat
        if (end > d.lengthFrames) { say("Perto demais do fim da música para esse loop."); return }
        NativeEngine.nativeSetLoop(deck, start.toLong(), end.toLong())
        setDeck(deck) { it.copy(loopBeats = beats) }
    }

    /** Toque numa hot cue vazia grava a posição atual. Numa gravada, vai até ela e toca. */
    fun hotcue(deck: Int, slot: Int) {
        val d = _decks.value[deck]
        if (!d.loaded || d.loading || d.trackId < 0 || slot !in 0..3) return
        val saved = d.hotcues[slot]
        if (saved < 0) {
            val st = LongArray(4)
            NativeEngine.nativeDeckState(deck, st)
            val frame = st[1]
            setDeck(deck) { it.copy(hotcues = it.hotcues.mapIndexed { i, old -> if (i == slot) frame else old }) }
            val id = d.trackId
            viewModelScope.launch(Dispatchers.IO) { db.setHotcue(id, slot, frame) }
        } else {
            NativeEngine.nativeSeek(deck, saved)
            if (!d.playing) NativeEngine.nativePlay(deck)
        }
    }

    fun clearHotcue(deck: Int, slot: Int) {
        val d = _decks.value[deck]
        if (d.trackId < 0 || slot !in 0..3 || d.hotcues[slot] < 0) return
        setDeck(deck) { it.copy(hotcues = it.hotcues.mapIndexed { i, old -> if (i == slot) -1L else old }) }
        val id = d.trackId
        viewModelScope.launch(Dispatchers.IO) { db.deleteHotcue(id, slot) }
        say("Hot cue ${slot + 1} apagada.")
    }

    // ------------------------------------------------------------ carregar faixa

    fun loadTrack(deck: Int, row: TrackRow) {
        val current = _decks.value[deck]
        if (current.playing) {
            say("Pause o deck ${deckName(deck)} antes de carregar outra música.")
            return
        }
        decodeJobs[deck]?.cancel()
        setDeck(deck) { it.copy(loading = true, loadProgress = 0f, title = row.title, artist = row.artist) }
        say("Carregando no deck ${deckName(deck)}…")
        decodeJobs[deck] = viewModelScope.launch {
            val result = TrackDecoder.decode(getApplication(), Uri.parse(row.uri)) { p ->
                setDeck(deck) { it.copy(loadProgress = p) }
            }
            when (result) {
                is DecodeResult.Ready -> try {
                    val frames = NativeEngine.nativeTrackFrames(result.trackHandle)
                    val wave = NativeEngine.nativeTrackPeaks(result.trackHandle)
                    val ok = NativeEngine.nativeLoad(deck, result.trackHandle)
                    var analysis = Analysis(0.0, 0L, 0f)
                    var hot = listOf(-1L, -1L, -1L, -1L)
                    if (ok) {
                        say("Analisando andamento e tom…")
                        withContext(Dispatchers.Default) {
                            android.os.Process.setThreadPriority(android.os.Process.THREAD_PRIORITY_BACKGROUND)
                            var a = db.analysis(row.id)
                            if (a == null) {
                                val out = DoubleArray(3)
                                NativeEngine.nativeAnalyze(result.trackHandle, out)
                                a = Analysis(out[0], out[1].toLong(), out[2].toFloat())
                            }
                            if (a.keyTonic < 0) {
                                val k = IntArray(4)
                                NativeEngine.nativeAnalyzeKey(result.trackHandle, k)
                                // sem tonalidade válida guarda confiança 0: não tenta de novo a cada carga
                                a = if (k[0] == 1) a.copy(keyTonic = k[1], keyMinor = k[2] == 1, keyConf = k[3] / 1000f)
                                else a.copy(keyTonic = 0, keyMinor = false, keyConf = 0f)
                                db.saveAnalysis(row.id, a)
                            }
                            analysis = a
                            hot = db.hotcues(row.id)
                        }
                    }
                    if (ok) {
                        NativeEngine.nativeSetRate(deck, 1f)
                        setDeck(deck) {
                            it.copy(
                                trackId = row.id, title = row.title, artist = row.artist, loading = false,
                                loadProgress = 1f, lengthFrames = frames, wave = wave,
                                bpm = analysis.bpm, firstBeatFrame = analysis.firstBeatFrame,
                                bpmConfidence = analysis.confidence, rate = 1f, loopBeats = 0, hotcues = hot,
                                keyTonic = analysis.keyTonic, keyMinor = analysis.keyMinor, keyConf = analysis.keyConf,
                            )
                        }
                        say("${row.title} pronta no deck ${deckName(deck)}.")
                    } else {
                        setDeck(deck) { it.copy(loading = false, title = current.title, artist = current.artist) }
                        say("O motor de áudio recusou a faixa.")
                    }
                } finally {
                    // sempre solta a referência nativa, mesmo se a carga for cancelada no meio da análise
                    NativeEngine.nativeFreeTrack(result.trackHandle)
                }

                is DecodeResult.Failed -> {
                    setDeck(deck) { it.copy(loading = false, title = current.title, artist = current.artist) }
                    say(result.reason)
                }
            }
        }
    }

    private fun setDeck(deck: Int, change: (DeckUi) -> DeckUi) {
        _decks.update { list -> list.mapIndexed { i, d -> if (i == deck) change(d) else d } }
    }

    // ---------------------------------------------------------------- biblioteca

    fun setSearch(text: String) {
        search.value = text
    }

    fun setSort(order: SortOrder) {
        sort.value = order
    }

    fun removeFromLibrary(row: TrackRow) {
        viewModelScope.launch(Dispatchers.IO) {
            db.delete(row.id)
            libraryVersion.update { it + 1 }
        }
    }

    fun importUris(uris: List<Uri>) {
        if (uris.isEmpty()) return
        viewModelScope.launch(Dispatchers.IO) {
            var added = 0
            var duplicated = 0
            var invalid = 0
            for (uri in uris) {
                try {
                    getApplication<Application>().contentResolver
                        .takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION)
                } catch (_: Exception) {
                    // nem todo provedor oferece permissão persistente
                }
                val meta = readMetadata(uri)
                if (meta == null) {
                    invalid++
                } else if (db.insert(uri.toString(), meta.title, meta.artist, meta.durationMs)) {
                    added++
                } else {
                    duplicated++
                }
            }
            libraryVersion.update { it + 1 }
            val parts = ArrayList<String>()
            if (added > 0) parts.add("$added adicionada(s)")
            if (duplicated > 0) parts.add("$duplicated já estava(m) na biblioteca")
            if (invalid > 0) parts.add("$invalid não é/são áudio")
            say(parts.joinToString(" · "))
        }
    }

    private class Meta(val title: String, val artist: String, val durationMs: Long)

    private fun readMetadata(uri: Uri): Meta? {
        val ctx = getApplication<Application>()
        val r = MediaMetadataRetriever()
        try {
            r.setDataSource(ctx, uri)
            if (r.extractMetadata(MediaMetadataRetriever.METADATA_KEY_HAS_AUDIO) != "yes") return null
            val duration = r.extractMetadata(MediaMetadataRetriever.METADATA_KEY_DURATION)?.toLongOrNull() ?: 0L
            val title = r.extractMetadata(MediaMetadataRetriever.METADATA_KEY_TITLE)?.trim().orEmpty()
            val artist = r.extractMetadata(MediaMetadataRetriever.METADATA_KEY_ARTIST)?.trim().orEmpty()
            return Meta(title.ifEmpty { displayName(uri) }, artist, duration)
        } catch (_: Exception) {
            return null
        } finally {
            try {
                r.release()
            } catch (_: Exception) {
            }
        }
    }

    private fun displayName(uri: Uri): String {
        try {
            getApplication<Application>().contentResolver
                .query(uri, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)?.use { c ->
                    if (c.moveToFirst()) {
                        val name = c.getString(0)
                        if (!name.isNullOrBlank()) return name.substringBeforeLast('.')
                    }
                }
        } catch (_: Exception) {
        }
        return "Faixa sem título"
    }

    override fun onCleared() {
        decodeJobs.forEach { it?.cancel() }
        midi.stop()
        router.stop()
        NativeEngine.nativeStop()
    }

    companion object {
        /** Faixa de velocidade do fader de pitch: -10% a +10%. */
        const val PITCH_MIN = 0.9f
        const val PITCH_MAX = 1.1f
        /** Abaixo disto o andamento detectado é tratado como "não detectado". */
        const val MIN_BPM_CONFIDENCE = 0.3f

        fun deckName(deck: Int) = if (deck == 0) "A" else "B"
    }
}
