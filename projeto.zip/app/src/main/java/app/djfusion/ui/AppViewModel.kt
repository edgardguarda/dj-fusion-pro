package app.djfusion.ui

import android.app.Application
import android.content.Intent
import android.media.MediaMetadataRetriever
import android.net.Uri
import android.provider.OpenableColumns
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import app.djfusion.audio.DecodeResult
import app.djfusion.audio.NativeEngine
import app.djfusion.audio.TrackDecoder
import app.djfusion.audio.OutputRouter
import app.djfusion.audio.UsbOut
import app.djfusion.harmony.Camelot
import app.djfusion.harmony.Harmonizer
import app.djfusion.harmony.MixAdvisor
import app.djfusion.harmony.MusicalKey
import app.djfusion.harmony.SetTrack
import app.djfusion.midi.Dj2go2Touch
import app.djfusion.midi.MidiHub
import app.djfusion.data.Analysis
import app.djfusion.data.LibraryDb
import app.djfusion.data.SortOrder
import app.djfusion.data.TrackRow
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

/** Parte do deck que muda pouco (carregar, tocar, parar). */
data class DeckUi(
    val trackId: Long = -1,
    val title: String = "",
    val artist: String = "",
    val loaded: Boolean = false,
    val playing: Boolean = false,
    val loading: Boolean = false,
    val loadProgress: Float = 0f,
    val lengthFrames: Long = 0,
    val wave: ByteArray? = null,
    /** Andamento da faixa original (0 = não detectado) e onde cai a primeira batida. */
    val bpm: Double = 0.0,
    val firstBeatFrame: Long = 0,
    val bpmConfidence: Float = 0f,
    /** Velocidade de reprodução (1 = normal). O andamento tocado é bpm x rate. */
    val rate: Float = 1f,
    /** 0 = sem loop, senão o tamanho do loop em batidas. */
    val loopBeats: Int = 0,
    /** Hot cues: quadro de cada uma das 4 posições, -1 quando vazia. */
    val hotcues: List<Long> = listOf(-1L, -1L, -1L, -1L),
    /** Equalizador graves, médios, agudos (0,5 = neutro) e filtro (0,5 = desligado). */
    val eq: List<Float> = listOf(0.5f, 0.5f, 0.5f),
    val filter: Float = 0.5f,
    /** Efeito do deck: 0 desligado, 1 eco, 2 flanger, 3 reverb, e a mistura de 0 a 1. */
    val fxType: Int = 0,
    val fxAmount: Float = 0.5f,
    /** Key-lock: o andamento muda sem mudar o tom. */
    val keyLock: Boolean = false,
    /** Pré-escuta no fone (PFL). */
    val cueOn: Boolean = false,
    /** Tonalidade detectada da faixa (nota 0..11, -1 = desconhecida), modo e confiança. */
    val keyTonic: Int = -1,
    val keyMinor: Boolean = false,
    val keyConf: Float = 0f,
    /** A área do prato mostra os pads (hot cue, loop, efeito) em vez do prato. */
    val padsOpen: Boolean = false,
    /** Energia da faixa de 0 a 1 (-1 = não medida). */
    val energy: Float = -1f,
    /** Stems: -1 = não separados, 0..1 = separando, 1 = prontos. */
    val stemProgress: Float = -1f,
    /** Ganho de voz, bateria, baixo e melodia (0..1). */
    val stemGains: List<Float> = listOf(1f, 1f, 1f, 1f),
    /** A área do prato mostra o painel de stems. */
    val stemsOpen: Boolean = false,
    /** Tom deslocado em semitons (-12..12), sem mudar o andamento. */
    val keyShift: Int = 0,
    /** SLIP: depois de scratch, loop, reverso ou censura, a música volta onde estaria. */
    val slip: Boolean = false,
    /** Tocando ao contrário (REVERSO). */
    val reverse: Boolean = false,
    /** Volume médio medido (dBFS, 0 = não medido) e ganho de entrada aplicado pelo auto-gain. */
    val loudness: Float = 0f,
    val trim: Float = 1f,
) {
    val stemsReady: Boolean get() = stemProgress >= 1f
    val energyLevel: Int get() = if (energy < 0f) 0 else (1 + Math.round(energy * 9f)).coerceIn(1, 10)
    /** Tonalidade original, se detectada com confiança. */
    val key: MusicalKey?
        get() = if (keyTonic in 0..11 && keyConf >= Camelot.MIN_CONFIDENCE) MusicalKey.of(keyTonic, keyMinor) else null
    /** Tonalidade que se ouve agora: sem key-lock, mudar a velocidade desloca o tom. */
    val shownKey: MusicalKey? get() = (if (keyLock) key else key?.shifted(Camelot.semitonesFor(rate)))?.shifted(keyShift)
    val hasBpm: Boolean get() = bpm > 0.0 && bpmConfidence >= AppViewModel.MIN_BPM_CONFIDENCE
    val playedBpm: Double get() = bpm * rate
}

/** Um pad do sampler. */
data class PadUi(
    val label: String = "", val loop: Boolean = false, val ready: Boolean = false, val playing: Boolean = false,
    /** Andamento original do trecho (0 = sem andamento): loops seguem o andamento do deck que está tocando. */
    val bpm: Double = 0.0,
)

/** Parte que muda ~30 vezes por segundo (posição e nível). Fica separada para não redesenhar tudo. */
data class DeckLive(
    val positionFrames: Long = 0,
    val cueFrames: Long = 0,
    val peak: Float = 0f,
)

data class LiveUi(
    val decks: List<DeckLive> = listOf(DeckLive(), DeckLive()),
    val masterPeak: Float = 0f,
)

class AppViewModel(app: Application) : AndroidViewModel(app) {
    private val db = LibraryDb(app)
    private val outPrefs = app.getSharedPreferences("output", android.content.Context.MODE_PRIVATE)

    /** Saída do fone: 0 só som geral, 1 dividido (E fone, D geral), 2 quatro canais (1-2 geral, 3-4 fone). */
    private val _outMode = MutableStateFlow(outPrefs.getInt("mode", 0).coerceIn(0, 2))
    val outputMode: StateFlow<Int> = _outMode.asStateFlow()
    /** Aparelho de saída escolhido: -1 = automático (a primeira placa USB). */
    private val _outDevice = MutableStateFlow(outPrefs.getInt("device", -1))
    val outputDevice: StateFlow<Int> = _outDevice.asStateFlow()
    private val _outNote = MutableStateFlow("")
    val outputNote: StateFlow<String> = _outNote.asStateFlow()
    private val _hpLevel = MutableStateFlow(0.7f)
    val hpLevel: StateFlow<Float> = _hpLevel.asStateFlow()
    private val _hpMix = MutableStateFlow(0f)
    val hpMix: StateFlow<Float> = _hpMix.asStateFlow()
    val router = OutputRouter(app) { applyOutput() }
    val usbOutputs: StateFlow<List<UsbOut>> get() = router.devices

    private val _decks = MutableStateFlow(listOf(DeckUi(), DeckUi()))
    val decks: StateFlow<List<DeckUi>> = _decks.asStateFlow()

    private val _live = MutableStateFlow(LiveUi())
    val live: StateFlow<LiveUi> = _live.asStateFlow()

    private val _volumes = MutableStateFlow(listOf(1f, 1f))
    val volumes: StateFlow<List<Float>> = _volumes.asStateFlow()
    private val _crossfader = MutableStateFlow(0.5f)
    val crossfader: StateFlow<Float> = _crossfader.asStateFlow()
    private val _master = MutableStateFlow(0.8f)
    val master: StateFlow<Float> = _master.asStateFlow()

    private val _message = MutableStateFlow<String?>(null)
    val message: StateFlow<String?> = _message.asStateFlow()

    private val _audioStatus = MutableStateFlow("Áudio desligado")
    val audioStatus: StateFlow<String> = _audioStatus.asStateFlow()

    val search = MutableStateFlow("")
    val sort = MutableStateFlow(SortOrder.RECENT)
    private val libraryVersion = MutableStateFlow(0)

    private val setPrefs = app.getSharedPreferences("set", android.content.Context.MODE_PRIVATE)
    private val _set = MutableStateFlow(
        setPrefs.getString("ids", "").orEmpty().split(',').mapNotNull { it.toLongOrNull() },
    )
    /** Ordem do set montada pelo HARMONIZAR (ids das faixas). O AUTO DJ segue esta ordem. */
    val setOrder: StateFlow<List<Long>> = _set.asStateFlow()

    val tracks: StateFlow<List<TrackRow>> =
        combine(search, sort, libraryVersion, _set) { s, o, _, _ -> s to o }
            .map { (s, o) ->
                val rows = withContext(Dispatchers.IO) { db.query(s, o) }
                if (o == SortOrder.SET) {
                    val pos = _set.value.withIndex().associate { it.value to it.index }
                    rows.sortedBy { pos[it.id] ?: Int.MAX_VALUE }
                } else rows
            }
            .stateIn(viewModelScope, SharingStarted.Eagerly, emptyList())

    private val decodeJobs = arrayOfNulls<Job>(2)

    private var foreground = true

    /** Controladoras MIDI USB (Numark etc.). Os controles aprendidos chegam em [onMidi]. */
    val midi = MidiHub(app, onPreset = {
        jog.setTicksPerRev(Dj2go2Touch.TICKS_PER_REV)
        say("Mapa de fábrica da Numark DJ2GO2 Touch aplicado: prato, play, cue, sync, pads e faders.")
    }) { id, v -> onMidi(id, v) }

    private fun onMidi(id: String, v: Float) {
        if (id == "xfade") { setCrossfader(v); return }
        if (id == "master") { setMaster(v); return }
        if (id == "autodj") { autoDj.toggle(); return }
        if (id.startsWith("pad")) { padPress(id.substring(3).toInt() - 1); return }
        if (id == "hpvol") { setHeadphoneLevel(v); return }
        if (id == "hpmix") { setHeadphoneMix(v); return }
        val deck = id[1].digitToInt()
        val k = id.substring(3)
        when {
            k == "play" -> togglePlay(deck)
            k == "cue" -> cue(deck)
            k == "sync" -> sync(deck)
            k == "vol" -> setVolume(deck, v)
            k == "eqhi" -> setEq(deck, 2, v)
            k == "eqmid" -> setEq(deck, 1, v)
            k == "eqlo" -> setEq(deck, 0, v)
            k == "filter" -> setFilter(deck, v)
            k == "tempo" -> setPitchFader(deck, v)
            k == "fxamt" -> setFxAmount(deck, v)
            k == "jog" -> jog.tick(deck, v.toInt())
            k == "jogtouch" -> jog.touch(deck, v > 0.5f)
            k == "keylock" -> toggleKeyLock(deck)
            k == "pfl" -> toggleHeadphoneCue(deck)
            k == "fxeco" -> setFx(deck, 1)
            k == "fxflg" -> setFx(deck, 2)
            k == "fxrev" -> setFx(deck, 3)
            k.startsWith("hot") -> hotcue(deck, k.substring(3).toInt() - 1)
            k.startsWith("loop") -> toggleLoop(deck, k.substring(4).toInt())
        }
    }
    private var stopJob: Job? = null

    /** AUTO DJ: o app escolhe as músicas e faz as mixagens sozinho. */
    val autoDj = AutoDj(this, viewModelScope)

    /** Jog wheel das controladoras (scratch e ajuste fino). */
    val jog = JogController(app.getSharedPreferences("jog", android.content.Context.MODE_PRIVATE), this, viewModelScope)

    // ---------------------------------------------------------------- sampler

    private val _pads = MutableStateFlow(List(8) { PadUi() })
    val pads: StateFlow<List<PadUi>> = _pads.asStateFlow()
    private val _samplerVol = MutableStateFlow(0.8f)
    val samplerVol: StateFlow<Float> = _samplerVol.asStateFlow()

    /** Escolhe sozinho os melhores trechos das músicas dos decks e os coloca nos pads (4 por deck). */
    fun buildSamples() {
        val decks = _decks.value
        if (decks.none { it.loaded && !it.loading }) {
            say("Carregue uma música em pelo menos um deck para gerar as amostras.")
            return
        }
        viewModelScope.launch(Dispatchers.Default) {
            android.os.Process.setThreadPriority(android.os.Process.THREAD_PRIORITY_BACKGROUND)
            NativeEngine.nativeClearSamples()
            sentSpeed.fill(1f)
            for (i in 0 until 8) NativeEngine.nativeSetSampleSpeed(i, 1f)
            val list = MutableList(8) { PadUi() }
            val info = LongArray(12)
            var total = 0
            for (deck in 0..1) {
                val d = decks[deck]
                if (!d.loaded || d.loading) continue
                val n = NativeEngine.nativeBuildSamples(deck, if (d.hasBpm) d.bpm else 0.0, d.firstBeatFrame, deck * 4, info)
                for (k in 0 until n) {
                    val kind = info[3 * k].toInt()
                    val loop = info[3 * k + 2] == 1L
                    val what = when (kind) {
                        0 -> "BUMBO"
                        1 -> "GOLPE"
                        2 -> if (loop) "LOOP 1 COMPASSO" else "TRECHO FORTE"
                        else -> "LOOP 2 COMPASSOS"
                    }
                    list[deck * 4 + k] = PadUi("${deckName(deck)} · $what", loop, true, false, if (d.hasBpm) d.bpm else 0.0)
                }
                total += n
            }
            _pads.value = list
            NativeEngine.nativeSetSamplerVolume(_samplerVol.value)
            say(if (total > 0) "$total amostras prontas nos pads." else "Não achei trechos bons nessas faixas.")
        }
    }

    fun clearSamples() {
        sentSpeed.fill(1f)
        NativeEngine.nativeClearSamples()
        _pads.value = List(8) { PadUi() }
    }

    /** Deck que manda no andamento: o que está tocando (se os dois, o do lado do crossfader). */
    private fun leadDeck(): Int? {
        val d = _decks.value
        val p = (0..1).filter { d[it].playing && d[it].hasBpm }
        if (p.isEmpty()) return null
        if (p.size == 1) return p[0]
        return if (_crossfader.value <= 0.5f) 0 else 1
    }

    /** Velocidade para o trecho seguir o andamento do deck que está tocando (1, ou o múltiplo mais perto). */
    private fun padSpeed(pad: PadUi): Float {
        val lead = leadDeck() ?: return 1f
        if (pad.bpm <= 0.0) return 1f
        val target = _decks.value[lead].playedBpm
        var best = 1.0
        var err = Double.MAX_VALUE
        for (k in doubleArrayOf(1.0, 2.0, 0.5)) {
            val s = target / (pad.bpm * k)
            if (kotlin.math.abs(s - 1.0) < err) { err = kotlin.math.abs(s - 1.0); best = s }
        }
        return best.toFloat().coerceIn(0.5f, 2f)
    }

    /** Quadros até a próxima batida do deck que está tocando (0 se acabou de passar uma, ou se nada toca). */
    private fun framesToNextBeat(): Long {
        val lead = leadDeck() ?: return 0L
        val d = _decks.value[lead]
        val beat = 60.0 * NativeEngine.SAMPLE_RATE / d.bpm
        val pos = _live.value.decks[lead].positionFrames.toDouble()
        val phase = posMod(pos - d.firstBeatFrame, beat)
        val rate = d.rate.toDouble().coerceAtLeast(0.1)
        if (phase / rate < 0.03 * NativeEngine.SAMPLE_RATE) return 0L      // tocou logo depois da batida: entra já
        return ((beat - phase) / rate).toLong()
    }

    private val sentSpeed = FloatArray(8) { 1f }

    /** Mantém os pads no andamento do deck que está tocando (chamado pela leitura periódica). */
    private fun syncPadSpeeds() {
        val pads = _pads.value
        for (i in pads.indices) {
            if (!pads[i].ready) continue
            val s = padSpeed(pads[i])
            if (kotlin.math.abs(s - sentSpeed[i]) > 0.0005f) {
                sentSpeed[i] = s
                NativeEngine.nativeSetSampleSpeed(i, s)
            }
        }
    }

    /** Pad de golpe toca uma vez; pad de loop liga e desliga o loop. Entra na próxima batida, no andamento do deck. */
    fun padPress(slot: Int) {
        val pad = _pads.value.getOrNull(slot) ?: return
        if (!pad.ready) { say("Pad vazio. Toque em AMOSTRAR para gerar os trechos das músicas dos decks."); return }
        if (pad.loop && pad.playing) { NativeEngine.nativeStopSample(slot); return }
        syncPadSpeeds()
        NativeEngine.nativeTriggerSampleAt(slot, pad.loop, framesToNextBeat())
    }

    fun setSamplerVolume(v: Float) {
        _samplerVol.value = v
        NativeEngine.nativeSetSamplerVolume(v)
    }

    // ------------------------------------------------- análise da biblioteca

    private val _analysisProgress = MutableStateFlow<String?>(null)
    /** Texto de andamento da análise em lote ("3 de 20"), ou null quando parada. */
    val analysisProgress: StateFlow<String?> = _analysisProgress.asStateFlow()
    private var analyzeJob: Job? = null

    /** Analisa andamento e tom de todas as faixas da biblioteca que ainda não foram analisadas. */
    fun analyzeLibrary() {
        if (analyzeJob?.isActive == true) {
            analyzeJob?.cancel()
            _analysisProgress.value = null
            return
        }
        analyzeJob = viewModelScope.launch {
            try {
                val n = analyzeMissing { done, total -> _analysisProgress.value = "$done de $total" }
                say(if (n == 0) "Todas as faixas já foram analisadas." else "Análise concluída: $n faixa(s).")
            } finally {
                _analysisProgress.value = null
            }
        }
    }

    /** Analisa (andamento e tom) as faixas que faltam. Devolve quantas analisou. Usado também pelo AUTO DJ. */
    suspend fun analyzeMissing(progress: (Int, Int) -> Unit): Int {
        val todo = withContext(Dispatchers.IO) { db.unanalyzed() }
        var done = 0
        for (row in todo) {
            progress(done + 1, todo.size)
            val r = TrackDecoder.decode(getApplication(), Uri.parse(row.uri)) { }
            if (r is DecodeResult.Ready) {
                try {
                    withContext(Dispatchers.Default) {
                        android.os.Process.setThreadPriority(android.os.Process.THREAD_PRIORITY_BACKGROUND)
                        var a = db.analysis(row.id)
                        if (a == null) {
                            val out = DoubleArray(3)
                            NativeEngine.nativeAnalyze(r.trackHandle, out)
                            a = Analysis(out[0], out[1].toLong(), out[2].toFloat())
                        }
                        if (a.keyTonic < 0) {
                            val k = IntArray(4)
                            NativeEngine.nativeAnalyzeKey(r.trackHandle, k)
                            a = if (k[0] == 1) a.copy(keyTonic = k[1], keyMinor = k[2] == 1, keyConf = k[3] / 1000f)
                            else a.copy(keyTonic = 0, keyMinor = false, keyConf = 0f)
                        }
                        if (a.energy < 0f) a = a.copy(energy = NativeEngine.nativeAnalyzeEnergy(r.trackHandle).coerceAtLeast(0f))
                        db.saveAnalysis(row.id, a)
                    }
                } finally {
                    NativeEngine.nativeFreeTrack(r.trackHandle)
                }
            } else {
                // arquivo ilegível: marca como analisado sem andamento, para não tentar de novo para sempre
                withContext(Dispatchers.IO) { db.saveAnalysis(row.id, Analysis(0.0, 0L, 0f, keyTonic = 0, keyMinor = false, keyConf = 0f, energy = 0f)) }
            }
            done++
            libraryVersion.update { it + 1 }
        }
        return done
    }

    /** Todas as faixas da biblioteca, com o que já foi analisado (para o AUTO DJ). */
    suspend fun allTracks(): List<TrackRow> = withContext(Dispatchers.IO) { db.query("", SortOrder.RECENT) }

    /** Carrega a faixa no deck e espera terminar. Devolve false se falhou. */
    suspend fun loadTrackAndWait(deck: Int, row: TrackRow): Boolean {
        loadTrack(deck, row)
        var waited = 0
        while (waited < 600) {                       // até 60 s
            delay(100)
            waited++
            val d = _decks.value[deck]
            if (!d.loading) return d.loaded && d.trackId == row.id
        }
        return false
    }

    init {
        midi.start()
        router.start()
        // O motor C++ vive no processo, não na Activity: se a tela foi fechada e reaberta sem o processo
        // morrer, ele ainda guarda as faixas e o estado de tocar da vez anterior. Começamos do zero.
        for (d in 0..1) {
            NativeEngine.nativeUnload(d)
            NativeEngine.nativeSetRate(d, 1f)
            NativeEngine.nativeSetFilter(d, 0.5f)
            NativeEngine.nativeSetFx(d, 0, 0.5f, 0.5f)
            NativeEngine.nativeClearLoop(d)
            NativeEngine.nativeSetKeyLock(d, false)
            NativeEngine.nativeSetHeadphoneCue(d, false)
            for (b in 0..2) NativeEngine.nativeSetEq(d, b, 0.5f)
        }
        startPolling()
    }

    /**
     * Chamado pela Activity em onStart (true) e onStop (false). Sem serviço em primeiro plano o Android
     * não garante áudio em segundo plano, então ao sair o app pausa os decks e fecha a saída de áudio.
     */
    fun onForeground(on: Boolean) {
        foreground = on
        stopJob?.cancel()
        if (on) {
            startAudio()
        } else {
            NativeEngine.nativePause(0)
            NativeEngine.nativePause(1)
            stopJob = viewModelScope.launch(Dispatchers.Default) {
                delay(150) // deixa a rampa de 4 ms da pausa terminar antes de fechar o fluxo
                if (!foreground) NativeEngine.nativeStop()
            }
        }
    }

    private fun startAudio() {
        // Abrir o fluxo exclusivo do Oboe pode demorar: fora da thread principal.
        viewModelScope.launch(Dispatchers.Default) {
            NativeEngine.nativeConfigureOutput(_outMode.value, resolveDevice())
            val ok = NativeEngine.nativeStart()
            if (ok) {
                NativeEngine.nativeSetHeadphoneLevel(_hpLevel.value)
                NativeEngine.nativeSetHeadphoneMix(_hpMix.value)
                NativeEngine.nativeSetMaster(_master.value)
                NativeEngine.nativeSetCrossfader(_crossfader.value)
                NativeEngine.nativeSetVolume(0, _volumes.value[0])
                NativeEngine.nativeSetVolume(1, _volumes.value[1])
                refreshAudioStatus()
            } else {
                _audioStatus.value = "Sem áudio"
                say("Não consegui abrir a saída de áudio do aparelho.")
            }
        }
    }

    private fun refreshAudioStatus() {
        val info = IntArray(6)
        NativeEngine.nativeStreamInfo(info)
        val bufferMs = if (info[0] > 0) info[2] * 1000f / info[0] else 0f
        _audioStatus.value = "%d Hz · buffer %.0f ms".format(java.util.Locale.ROOT, info[0], bufferMs)
        val want = _outMode.value
        val got = info[5]
        _outNote.value = when {
            want == 0 -> "Saída normal: o som geral sai em estéreo. O fone usa só o do próprio aparelho."
            got == 2 -> "Fone em 4 canais ativo: canais 1-2 som geral, canais 3-4 fone (${info[4]} canais abertos)."
            got == 1 && want == 2 -> "Este aparelho não abriu 4 canais; usando o modo dividido (esquerdo = fone, direito = som geral)."
            got == 1 -> "Modo dividido ativo: o lado esquerdo da saída leva o fone e o direito leva o som geral (ambos em mono)."
            else -> "Não consegui abrir a saída escolhida; voltei à saída normal."
        }
    }

    private fun resolveDevice(): Int {
        if (_outMode.value == 0) return 0
        val list = router.devices.value
        val pick = _outDevice.value
        return list.firstOrNull { it.id == pick }?.id ?: list.firstOrNull()?.id ?: 0
    }

    /** Reaplica a saída (modo ou aparelho mudou, ou uma placa USB entrou ou saiu). */
    private fun applyOutput() {
        viewModelScope.launch(Dispatchers.Default) {
            NativeEngine.nativeConfigureOutput(_outMode.value, resolveDevice())
            if (foreground) refreshAudioStatus()
        }
    }

    fun setOutputMode(mode: Int) {
        _outMode.value = mode.coerceIn(0, 2)
        outPrefs.edit().putInt("mode", _outMode.value).apply()
        applyOutput()
    }

    fun setOutputDevice(id: Int) {
        _outDevice.value = id
        outPrefs.edit().putInt("device", id).apply()
        applyOutput()
    }

    fun toggleKeyLock(deck: Int) {
        val on = !_decks.value[deck].keyLock
        setDeck(deck) { it.copy(keyLock = on) }
        NativeEngine.nativeSetKeyLock(deck, on)
    }

    fun togglePads(deck: Int) {
        setDeck(deck) { it.copy(padsOpen = !it.padsOpen, stemsOpen = false) }
    }

    fun toggleHeadphoneCue(deck: Int) {
        val on = !_decks.value[deck].cueOn
        setDeck(deck) { it.copy(cueOn = on) }
        NativeEngine.nativeSetHeadphoneCue(deck, on)
    }

    fun setHeadphoneLevel(v: Float) {
        _hpLevel.value = v
        NativeEngine.nativeSetHeadphoneLevel(v)
    }

    fun setHeadphoneMix(v: Float) {
        _hpMix.value = v
        NativeEngine.nativeSetHeadphoneMix(v)
    }

    /** Prato tocado: [velocity] em múltiplos da velocidade normal. */
    fun scratch(deck: Int, active: Boolean, velocity: Float) {
        if (active && slipFrom[deck] == null) slipBegin(deck)
        NativeEngine.nativeScratch(deck, active, velocity)
        if (!active) slipEnd(deck)
    }

    // ------------------------------------------------------------------ SLIP, REVERSO e CENSURA

    /** Onde a música estaria: posição e hora em que o desvio começou (só com SLIP ligado e tocando). */
    private val slipFrom = arrayOfNulls<Pair<Long, Long>>(2)

    private fun slipBegin(deck: Int) {
        val d = _decks.value[deck]
        if (!d.slip || !d.playing || slipFrom[deck] != null) return
        val st = LongArray(4)
        NativeEngine.nativeDeckState(deck, st)
        slipFrom[deck] = st[1] to android.os.SystemClock.elapsedRealtime()
    }

    private fun slipEnd(deck: Int) {
        val from = slipFrom[deck] ?: return
        slipFrom[deck] = null
        val d = _decks.value[deck]
        val elapsed = android.os.SystemClock.elapsedRealtime() - from.second
        val target = from.first + (elapsed / 1000.0 * NativeEngine.SAMPLE_RATE * d.rate).toLong()
        if (target in 0 until d.lengthFrames) NativeEngine.nativeSeek(deck, target)
    }

    fun toggleSlip(deck: Int) {
        val on = !_decks.value[deck].slip
        if (!on) slipFrom[deck] = null
        setDeck(deck) { it.copy(slip = on) }
        say(if (on) "SLIP ligado no deck ${deckName(deck)}: depois de scratch, loop, reverso ou censura a música volta onde estaria."
            else "SLIP desligado no deck ${deckName(deck)}.")
    }

    /** REVERSO: toca ao contrário até tocar de novo. Com SLIP, volta ao ponto onde estaria. */
    fun toggleReverse(deck: Int) {
        val d = _decks.value[deck]
        if (!d.loaded || d.loading) { say("Carregue uma música no deck ${deckName(deck)} primeiro."); return }
        if (d.reverse) {
            NativeEngine.nativeScratch(deck, false, 0f)
            setDeck(deck) { it.copy(reverse = false) }
            slipEnd(deck)
        } else {
            if (!d.playing) { say("REVERSO precisa do deck ${deckName(deck)} tocando."); return }
            slipBegin(deck)
            NativeEngine.nativeScratch(deck, true, -d.rate)
            setDeck(deck) { it.copy(reverse = true) }
        }
    }

    /** CENSURA: 2 batidas ao contrário e volta exatamente onde a música estaria (SLIP automático). */
    fun censor(deck: Int) {
        val d = _decks.value[deck]
        if (!d.playing) { say("CENSURA precisa do deck ${deckName(deck)} tocando."); return }
        if (d.reverse) return
        val beatMs = if (d.hasBpm) (60000.0 / d.playedBpm).toLong() else 500L
        val st = LongArray(4)
        NativeEngine.nativeDeckState(deck, st)
        val from = st[1]
        val t0 = android.os.SystemClock.elapsedRealtime()
        runFx(deck) {
            setDeck(deck) { it.copy(reverse = true) }
            NativeEngine.nativeScratch(deck, true, -d.rate)
            delay(beatMs * 2)
            NativeEngine.nativeScratch(deck, false, 0f)
            val elapsed = android.os.SystemClock.elapsedRealtime() - t0
            NativeEngine.nativeSeek(deck, from + (elapsed / 1000.0 * NativeEngine.SAMPLE_RATE * d.rate).toLong())
            setDeck(deck) { it.copy(reverse = false) }
        }
    }

    // ------------------------------------------------------------------ STEMS

    fun toggleStems(deck: Int) {
        setDeck(deck) { it.copy(stemsOpen = !it.stemsOpen, padsOpen = false) }
    }

    /** Ganho de um stem (0 voz, 1 bateria, 2 baixo, 3 melodia). */
    fun setStemGain(deck: Int, stem: Int, gain: Float) {
        if (stem !in 0..3) return
        val d = _decks.value[deck]
        if (!d.stemsReady) {
            say(if (d.stemProgress >= 0f) "Stems ainda separando (${(d.stemProgress * 100).toInt()}%)." else "Carregue uma música para separar os stems.")
            return
        }
        val g = gain.coerceIn(0f, 1f)
        setDeck(deck) { it.copy(stemGains = it.stemGains.mapIndexed { i, old -> if (i == stem) g else old }) }
        NativeEngine.nativeSetStemGain(deck, stem, g)
    }

    fun toggleStem(deck: Int, stem: Int) {
        val g = _decks.value[deck].stemGains.getOrNull(stem) ?: return
        setStemGain(deck, stem, if (g > 0.5f) 0f else 1f)
    }

    /** ACAPELLA (só voz), INSTRUMENTAL (sem voz) ou tudo de volta. */
    fun stemPreset(deck: Int, preset: Int) {
        val gains = when (preset) {
            1 -> listOf(1f, 0f, 0f, 0f)
            2 -> listOf(0f, 1f, 1f, 1f)
            3 -> listOf(0f, 1f, 0f, 0f)
            else -> listOf(1f, 1f, 1f, 1f)
        }
        if (!_decks.value[deck].stemsReady) { setStemGain(deck, 0, 1f); return }
        gains.forEachIndexed { i, g -> NativeEngine.nativeSetStemGain(deck, i, g) }
        setDeck(deck) { it.copy(stemGains = gains) }
    }

    private suspend fun separateStems(deck: Int, handle: Long) {
        setDeck(deck) { it.copy(stemProgress = 0f) }
        val ok = coroutineScope {
            val poll = launch {
                while (isActive) {
                    delay(250)
                    val p = NativeEngine.nativeStemProgress(deck).coerceIn(0f, 0.99f)
                    setDeck(deck) { if (it.stemProgress in 0f..0.999f) it.copy(stemProgress = p) else it }
                }
            }
            val r = withContext(Dispatchers.Default) {
                android.os.Process.setThreadPriority(android.os.Process.THREAD_PRIORITY_BACKGROUND)
                NativeEngine.nativeSeparateStems(handle, deck)
            }
            poll.cancel()
            r
        }
        setDeck(deck) { it.copy(stemProgress = if (ok) 1f else -1f) }
        if (ok) say("Stems prontos no deck ${deckName(deck)}: voz, bateria, baixo e melodia.")
    }

    // ------------------------------------------------------------------ TOM, AUTO-GAIN e GRADE

    /** Muda o tom em semitons sem mudar o andamento (para casar o tom com o outro deck). */
    fun setKeyShift(deck: Int, semitones: Int) {
        val s = semitones.coerceIn(-12, 12)
        setDeck(deck) { it.copy(keyShift = s) }
        NativeEngine.nativeSetKeyShift(deck, s.toFloat())
    }

    fun shiftKey(deck: Int, delta: Int) = setKeyShift(deck, _decks.value[deck].keyShift + delta)

    /** Acerta o tom deste deck para combinar com o outro (menor deslocamento que deixa compatível na roda). */
    fun matchKey(deck: Int) {
        val d = _decks.value[deck]
        val other = _decks.value[1 - deck]
        val base = d.key?.let { if (d.keyLock) it else it.shifted(Camelot.semitonesFor(d.rate)) }
        val ref = other.shownKey
        if (base == null || ref == null) { say("Os dois decks precisam do tom detectado."); return }
        var best = 0
        var bestScore = Double.MAX_VALUE
        for (s in -6..6) {
            val sc = MixAdvisor.keyRelation(ref, base.shifted(s)).keyScore + kotlin.math.abs(s) * 0.05
            if (sc < bestScore) { bestScore = sc; best = s }
        }
        setKeyShift(deck, best)
        say("Tom do deck ${deckName(deck)} ${if (best == 0) "já combina" else "ajustado em ${if (best > 0) "+" else ""}$best semitons"}.")
    }

    private val _autoGain = MutableStateFlow(outPrefs.getBoolean("autoGain", true))
    val autoGain: StateFlow<Boolean> = _autoGain.asStateFlow()

    fun toggleAutoGain() {
        val on = !_autoGain.value
        _autoGain.value = on
        outPrefs.edit().putBoolean("autoGain", on).apply()
        for (d in 0..1) applyTrim(d)
        say(if (on) "AUTO-GAIN ligado: as músicas tocam com o mesmo volume." else "AUTO-GAIN desligado.")
    }

    private fun applyTrim(deck: Int) {
        val d = _decks.value[deck]
        val t = if (_autoGain.value && d.loudness < -1f) Math.pow(10.0, (TARGET_DB - d.loudness) / 20.0).toFloat().coerceIn(0.25f, 2.5f) else 1f
        NativeEngine.nativeSetTrim(deck, t)
        setDeck(deck) { it.copy(trim = t) }
    }

    /** Move a grade de batidas [dir] passos de 5 ms (acerta onde cai a batida). Salva na biblioteca. */
    fun nudgeGrid(deck: Int, dir: Int) {
        val d = _decks.value[deck]
        if (!d.hasBpm || d.trackId < 0) { say("A grade precisa do andamento detectado."); return }
        val step = NativeEngine.SAMPLE_RATE / 200
        val beat = (60.0 * NativeEngine.SAMPLE_RATE / d.bpm).toLong().coerceAtLeast(1)
        val nf = ((d.firstBeatFrame + dir * step) % beat + beat) % beat
        setDeck(deck) { it.copy(firstBeatFrame = nf) }
        saveGrid(d.trackId, d.bpm, nf)
    }

    /** Dobra ou corta pela metade o andamento detectado (erro comum de detecção). */
    fun scaleBpm(deck: Int, factor: Double) {
        val d = _decks.value[deck]
        if (d.bpm <= 0 || d.trackId < 0) return
        val nb = d.bpm * factor
        if (nb < 50 || nb > 220) { say("Andamento fora da faixa (50 a 220 BPM)."); return }
        setDeck(deck) { it.copy(bpm = nb, bpmConfidence = kotlin.math.max(it.bpmConfidence, 1f)) }
        saveGrid(d.trackId, nb, d.firstBeatFrame)
        pushFx(deck)
        say(String.format(java.util.Locale.ROOT, "Andamento do deck %s: %.1f BPM.", deckName(deck), nb))
    }

    private fun saveGrid(id: Long, bpm: Double, first: Long) {
        viewModelScope.launch(Dispatchers.IO) {
            val a = db.analysis(id) ?: return@launch
            db.saveAnalysis(id, a.copy(bpm = bpm, firstBeatFrame = first, confidence = kotlin.math.max(a.confidence, 1f)))
        }
    }

    private fun startPolling() {
        viewModelScope.launch {
            val buf = LongArray(4)
            var tick = 0
            while (isActive) {
                if (!foreground) {
                    delay(250)
                    continue
                }
                val states = ArrayList<LongArray>(2)
                val lives = ArrayList<DeckLive>(2)
                for (d in 0..1) {
                    NativeEngine.nativeDeckState(d, buf)
                    states.add(buf.copyOf())
                    lives.add(DeckLive(buf[1], buf[2], NativeEngine.nativeDeckPeak(d)))
                }
                _live.value = LiveUi(lives, NativeEngine.nativeMasterPeak())
                _decks.update { list ->
                    list.mapIndexed { i, d ->
                        val flags = states[i][0]
                        val playing = (flags and 2L) != 0L
                        val loaded = (flags and 1L) != 0L
                        if (d.playing == playing && d.loaded == loaded) d else d.copy(playing = playing, loaded = loaded)
                    }
                }
                val mask = NativeEngine.nativeSamplerMask()
                val padsNow = _pads.value
                if (padsNow.indices.any { ((mask shr it) and 1 == 1) != padsNow[it].playing }) {
                    _pads.value = padsNow.mapIndexed { i, p -> p.copy(playing = (mask shr i) and 1 == 1) }
                }
                if (tick % 6 == 0) syncPadSpeeds()
                if (++tick % 30 == 0) launch(Dispatchers.Default) { NativeEngine.nativeCollectGarbage() }
                delay(33)
            }
        }
    }

    // ----------------------------------------------------------------- mensagens

    fun say(text: String) {
        _message.value = text
    }

    fun clearMessage(text: String) {
        _message.update { if (it == text) null else it }
    }

    // ------------------------------------------------------------------- decks

    fun togglePlay(deck: Int) {
        if (_decks.value[deck].loading) {
            say("Espere a música terminar de carregar no deck ${deckName(deck)}.")
            return
        }
        val st = LongArray(4)
        NativeEngine.nativeDeckState(deck, st)
        if ((st[0] and 1L) == 0L) {
            say("Deck ${deckName(deck)} sem música. Abra a Biblioteca e toque em ${deckName(deck)}.")
            return
        }
        if ((st[0] and 2L) != 0L) NativeEngine.nativePause(deck) else NativeEngine.nativePlay(deck)
    }

    fun cue(deck: Int) {
        val d = _decks.value[deck]
        if (!d.loaded || d.loading) { say("Carregue uma música no deck ${deckName(deck)} primeiro."); return }
        NativeEngine.nativeCue(deck)
    }

    fun seekFraction(deck: Int, fraction: Float) {
        val length = _decks.value[deck].lengthFrames
        if (length <= 0) return
        NativeEngine.nativeSeek(deck, (fraction.coerceIn(0f, 1f) * length).toLong())
    }

    fun setVolume(deck: Int, v: Float) {
        _volumes.update { list -> list.mapIndexed { i, old -> if (i == deck) v else old } }
        NativeEngine.nativeSetVolume(deck, v)
    }

    fun setCrossfader(x: Float) {
        _crossfader.value = x
        NativeEngine.nativeSetCrossfader(x)
    }

    fun setMaster(v: Float) {
        _master.value = v
        NativeEngine.nativeSetMaster(v)
    }

    // ------------------------------------------------- equalizador, filtro e pitch

    private fun snapCenter(v: Float): Float = if (kotlin.math.abs(v - 0.5f) < 0.03f) 0.5f else v.coerceIn(0f, 1f)

    fun setEq(deck: Int, band: Int, v: Float) {
        val x = snapCenter(v)
        setDeck(deck) { d -> d.copy(eq = d.eq.mapIndexed { i, old -> if (i == band) x else old }) }
        NativeEngine.nativeSetEq(deck, band, x)
    }

    fun setFilter(deck: Int, v: Float) {
        val x = snapCenter(v)
        setDeck(deck) { it.copy(filter = x) }
        NativeEngine.nativeSetFilter(deck, x)
    }

    /** Posição do fader de pitch (0 a 1, 0,5 = velocidade normal) para a velocidade. */
    fun setPitchFader(deck: Int, fader: Float) {
        val f = if (kotlin.math.abs(fader - 0.5f) < 0.015f) 0.5f else fader.coerceIn(0f, 1f)
        applyRate(deck, PITCH_MIN + (PITCH_MAX - PITCH_MIN) * f)
    }

    /** Velocidade exata do deck (usado pelo AUTO DJ). */
    fun setRateExact(deck: Int, rate: Float) = applyRate(deck, rate.coerceIn(0.5f, 2f))

    /** Liga ou desliga o key-lock sem alternar. */
    fun setKeyLock(deck: Int, on: Boolean) {
        if (_decks.value[deck].keyLock == on) return
        toggleKeyLock(deck)
    }

    private fun applyRate(deck: Int, rate: Float) {
        setDeck(deck) { it.copy(rate = rate) }
        NativeEngine.nativeSetRate(deck, rate)
        pushFx(deck)
    }

    /** Liga o efeito [type] (toque de novo no mesmo para desligar). */
    fun setFx(deck: Int, type: Int) {
        val cur = _decks.value[deck].fxType
        setDeck(deck) { it.copy(fxType = if (cur == type) 0 else type) }
        pushFx(deck)
    }

    fun setFxAmount(deck: Int, v: Float) {
        setDeck(deck) { it.copy(fxAmount = v.coerceIn(0f, 1f)) }
        pushFx(deck)
    }

    /** Reenvia ao motor o efeito escolhido na tela (depois que o AUTO DJ usou o eco na transição). */
    fun restoreFx(deck: Int) = pushFx(deck)

    /** Envia o efeito ao motor; o eco acompanha a batida do que está tocando. */
    private fun pushFx(deck: Int) {
        val d = _decks.value[deck]
        val beat = if (d.hasBpm) (60.0 / d.playedBpm).toFloat() else 0.5f
        NativeEngine.nativeSetFx(deck, d.fxType, d.fxAmount, beat)
    }

    private fun posMod(a: Double, m: Double): Double = ((a % m) + m) % m

    /**
     * SYNC: iguala o andamento tocado deste deck ao do outro e, se o outro está tocando, alinha também a batida.
     * Só funciona com andamento detectado nos dois. Não é um SYNC contínuo: se o andamento oscilar, refaça.
     */
    fun sync(deck: Int) {
        val me = _decks.value[deck]
        val other = _decks.value[1 - deck]
        val name = deckName(deck)
        if (!me.loaded || !other.loaded) { say("SYNC precisa de música nos dois decks."); return }
        if (!me.hasBpm || !other.hasBpm) { say("SYNC precisa do andamento detectado nos dois decks."); return }
        val targetBpm = other.playedBpm
        var factor = 1.0
        var best = Double.MAX_VALUE
        for (k in doubleArrayOf(1.0, 2.0, 0.5)) {
            val r = targetBpm / (me.bpm * k)
            if (r in PITCH_MIN.toDouble()..PITCH_MAX.toDouble() && kotlin.math.abs(r - 1.0) < best) {
                best = kotlin.math.abs(r - 1.0)
                factor = k
            }
        }
        if (best == Double.MAX_VALUE) {
            say("Andamentos muito diferentes (%.1f e %.1f BPM). Ajuste o pitch à mão.".format(java.util.Locale.ROOT, me.bpm, targetBpm))
            return
        }
        applyRate(deck, (targetBpm / (me.bpm * factor)).toFloat())
        var aligned = false
        if (factor == 1.0 && other.playing) {
            val a = LongArray(4); val b = LongArray(4)
            NativeEngine.nativeDeckState(deck, a); NativeEngine.nativeDeckState(1 - deck, b)
            val sr = NativeEngine.SAMPLE_RATE.toDouble()
            val otherBeat = 60.0 * sr / other.bpm
            val myBeat = 60.0 * sr / me.bpm
            val phase = posMod(b[1] - other.firstBeatFrame.toDouble(), otherBeat) / otherBeat
            val cur = posMod(a[1] - me.firstBeatFrame.toDouble(), myBeat)
            var delta = phase * myBeat - cur
            if (delta > myBeat / 2) delta -= myBeat else if (delta < -myBeat / 2) delta += myBeat
            val target = (a[1] + delta).toLong().coerceIn(0L, (me.lengthFrames - 1).coerceAtLeast(0L))
            NativeEngine.nativeSeek(deck, target)
            aligned = true
        }
        say("Deck $name em %.1f BPM%s.".format(java.util.Locale.ROOT, targetBpm, if (aligned) ", batida alinhada" else ""))
    }

    // ------------------------------------------------------------- loops e hot cues

    fun toggleLoop(deck: Int, beats: Int) {
        val d = _decks.value[deck]
        if (!d.loaded || d.loading) { say("Carregue uma música no deck ${deckName(deck)} primeiro."); return }
        if (d.loopBeats == beats) {
            NativeEngine.nativeClearLoop(deck)
            setDeck(deck) { it.copy(loopBeats = 0) }
            slipEnd(deck)
            return
        }
        if (!d.hasBpm) { say("Loop por batidas precisa do andamento detectado."); return }
        val st = LongArray(4)
        NativeEngine.nativeDeckState(deck, st)
        val beat = 60.0 * NativeEngine.SAMPLE_RATE / d.bpm
        val first = d.firstBeatFrame.toDouble()
        val start = kotlin.math.max(0.0, first + kotlin.math.floor((st[1] - first) / beat) * beat)
        val end = start + beats * beat
        if (end > d.lengthFrames) { say("Perto demais do fim da música para esse loop."); return }
        if (d.loopBeats == 0) slipBegin(deck)
        NativeEngine.nativeSetLoop(deck, start.toLong(), end.toLong())
        setDeck(deck) { it.copy(loopBeats = beats) }
    }

    /** Toque numa hot cue vazia grava a posição atual. Numa gravada, vai até ela e toca. */
    fun hotcue(deck: Int, slot: Int) {
        val d = _decks.value[deck]
        if (slot !in 0..3) return
        if (!d.loaded || d.loading || d.trackId < 0) { say("Carregue uma música no deck ${deckName(deck)} primeiro."); return }
        val saved = d.hotcues[slot]
        if (saved < 0) {
            val st = LongArray(4)
            NativeEngine.nativeDeckState(deck, st)
            val frame = st[1]
            setDeck(deck) { it.copy(hotcues = it.hotcues.mapIndexed { i, old -> if (i == slot) frame else old }) }
            val id = d.trackId
            viewModelScope.launch(Dispatchers.IO) { db.setHotcue(id, slot, frame) }
        } else {
            NativeEngine.nativeSeek(deck, saved)
            if (!d.playing) NativeEngine.nativePlay(deck)
        }
    }

    fun clearHotcue(deck: Int, slot: Int) {
        val d = _decks.value[deck]
        if (d.trackId < 0 || slot !in 0..3 || d.hotcues[slot] < 0) return
        setDeck(deck) { it.copy(hotcues = it.hotcues.mapIndexed { i, old -> if (i == slot) -1L else old }) }
        val id = d.trackId
        viewModelScope.launch(Dispatchers.IO) { db.deleteHotcue(id, slot) }
        say("Hot cue ${slot + 1} apagada.")
    }

    // ------------------------------------------------------------ carregar faixa

    fun loadTrack(deck: Int, row: TrackRow) {
        val current = _decks.value[deck]
        if (current.playing) {
            say("Pause o deck ${deckName(deck)} antes de carregar outra música.")
            return
        }
        NativeEngine.nativeCancelStems(deck)
        decodeJobs[deck]?.cancel()
        slipFrom[deck] = null
        setDeck(deck) {
            it.copy(loading = true, loadProgress = 0f, title = row.title, artist = row.artist, stemProgress = -1f,
                stemGains = listOf(1f, 1f, 1f, 1f), reverse = false, keyShift = 0)
        }
        say("Carregando no deck ${deckName(deck)}…")
        decodeJobs[deck] = viewModelScope.launch {
            val result = TrackDecoder.decode(getApplication(), Uri.parse(row.uri)) { p ->
                setDeck(deck) { it.copy(loadProgress = p) }
            }
            when (result) {
                is DecodeResult.Ready -> try {
                    val frames = NativeEngine.nativeTrackFrames(result.trackHandle)
                    val wave = NativeEngine.nativeTrackPeaks(result.trackHandle)
                    val ok = NativeEngine.nativeLoad(deck, result.trackHandle)
                    var analysis = Analysis(0.0, 0L, 0f)
                    var hot = listOf(-1L, -1L, -1L, -1L)
                    var loud = 0f
                    if (ok) {
                        say("Analisando andamento e tom…")
                        withContext(Dispatchers.Default) {
                            android.os.Process.setThreadPriority(android.os.Process.THREAD_PRIORITY_BACKGROUND)
                            var a = db.analysis(row.id)
                            if (a == null) {
                                val out = DoubleArray(3)
                                NativeEngine.nativeAnalyze(result.trackHandle, out)
                                a = Analysis(out[0], out[1].toLong(), out[2].toFloat())
                            }
                            if (a.keyTonic < 0) {
                                val k = IntArray(4)
                                NativeEngine.nativeAnalyzeKey(result.trackHandle, k)
                                // sem tonalidade válida guarda confiança 0: não tenta de novo a cada carga
                                a = if (k[0] == 1) a.copy(keyTonic = k[1], keyMinor = k[2] == 1, keyConf = k[3] / 1000f)
                                else a.copy(keyTonic = 0, keyMinor = false, keyConf = 0f)
                                db.saveAnalysis(row.id, a)
                            }
                            if (a.energy < 0f) {
                                a = a.copy(energy = NativeEngine.nativeAnalyzeEnergy(result.trackHandle).coerceAtLeast(0f))
                                db.saveAnalysis(row.id, a)
                            }
                            analysis = a
                            hot = db.hotcues(row.id)
                            loud = NativeEngine.nativeAnalyzeLoudness(result.trackHandle)
                        }
                    }
                    if (ok) {
                        NativeEngine.nativeSetRate(deck, 1f)
                        setDeck(deck) {
                            it.copy(
                                trackId = row.id, title = row.title, artist = row.artist, loading = false,
                                loadProgress = 1f, lengthFrames = frames, wave = wave,
                                bpm = analysis.bpm, firstBeatFrame = analysis.firstBeatFrame,
                                bpmConfidence = analysis.confidence, rate = 1f, loopBeats = 0, hotcues = hot,
                                keyTonic = analysis.keyTonic, keyMinor = analysis.keyMinor, keyConf = analysis.keyConf,
                                energy = analysis.energy, loudness = loud,
                            )
                        }
                        applyTrim(deck)
                        NativeEngine.nativeSetKeyShift(deck, _decks.value[deck].keyShift.toFloat())
                        say("${row.title} pronta no deck ${deckName(deck)}.")
                        separateStems(deck, result.trackHandle)
                    } else {
                        setDeck(deck) { it.copy(loading = false, title = current.title, artist = current.artist) }
                        say("O motor de áudio recusou a faixa.")
                    }
                } finally {
                    // sempre solta a referência nativa, mesmo se a carga for cancelada no meio da análise
                    NativeEngine.nativeFreeTrack(result.trackHandle)
                }

                is DecodeResult.Failed -> {
                    setDeck(deck) { it.copy(loading = false, title = current.title, artist = current.artist) }
                    say(result.reason)
                }
            }
        }
    }

    private fun setDeck(deck: Int, change: (DeckUi) -> DeckUi) {
        _decks.update { list -> list.mapIndexed { i, d -> if (i == deck) change(d) else d } }
    }

    // ---------------------------------------------------------------- biblioteca

    fun setSearch(text: String) {
        search.value = text
    }

    fun setSort(order: SortOrder) {
        sort.value = order
    }

    fun removeFromLibrary(row: TrackRow) {
        viewModelScope.launch(Dispatchers.IO) {
            db.delete(row.id)
            libraryVersion.update { it + 1 }
        }
    }

    fun importUris(uris: List<Uri>) {
        if (uris.isEmpty()) return
        say("Importando ${uris.size} arquivo(s)…")
        viewModelScope.launch(Dispatchers.IO) { addUris(uris) }
    }

    /** Importa todas as músicas de uma pasta (e subpastas) escolhida no seletor do Android. */
    fun importFolder(tree: Uri) {
        say("Procurando músicas na pasta…")
        viewModelScope.launch(Dispatchers.IO) {
            try {
                getApplication<Application>().contentResolver
                    .takePersistableUriPermission(tree, Intent.FLAG_GRANT_READ_URI_PERMISSION)
            } catch (_: Exception) {
            }
            val found = ArrayList<Uri>()
            try {
                val rootId = android.provider.DocumentsContract.getTreeDocumentId(tree)
                collectAudio(tree, rootId, found, 0)
            } catch (e: Exception) {
                say("Não consegui ler essa pasta.")
                return@launch
            }
            if (found.isEmpty()) {
                say("Nenhuma música encontrada nessa pasta.")
                return@launch
            }
            say("Achei ${found.size} músicas. Importando…")
            addUris(found)
        }
    }

    private fun collectAudio(tree: Uri, docId: String, out: MutableList<Uri>, depth: Int) {
        if (depth > 8 || out.size > 5000) return
        val resolver = getApplication<Application>().contentResolver
        val children = android.provider.DocumentsContract.buildChildDocumentsUriUsingTree(tree, docId)
        val cols = arrayOf(
            android.provider.DocumentsContract.Document.COLUMN_DOCUMENT_ID,
            android.provider.DocumentsContract.Document.COLUMN_DISPLAY_NAME,
            android.provider.DocumentsContract.Document.COLUMN_MIME_TYPE,
        )
        val dirs = ArrayList<String>()
        resolver.query(children, cols, null, null, null)?.use { c ->
            while (c.moveToNext()) {
                val id = c.getString(0) ?: continue
                val name = c.getString(1).orEmpty()
                val mime = c.getString(2).orEmpty()
                if (mime == android.provider.DocumentsContract.Document.MIME_TYPE_DIR) dirs.add(id)
                else if (mime.startsWith("audio/") || hasAudioExtension(name)) {
                    out.add(android.provider.DocumentsContract.buildDocumentUriUsingTree(tree, id))
                }
            }
        }
        for (id in dirs) collectAudio(tree, id, out, depth + 1)
    }

    private fun hasAudioExtension(name: String): Boolean {
        val ext = name.substringAfterLast('.', "").lowercase()
        return ext in setOf("mp3", "wav", "flac", "m4a", "aac", "ogg", "oga", "opus", "wma", "aif", "aiff", "mp4")
    }

    private suspend fun addUris(uris: List<Uri>) {
        var added = 0
        var duplicated = 0
        var invalid = 0
        for (uri in uris) {
            try {
                getApplication<Application>().contentResolver
                    .takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION)
            } catch (_: Exception) {
                // nem todo provedor oferece permissão persistente
            }
            val meta = readMetadata(uri)
            if (meta == null) {
                invalid++
            } else if (db.insert(uri.toString(), meta.title, meta.artist, meta.durationMs)) {
                added++
            } else {
                duplicated++
            }
        }
        libraryVersion.update { it + 1 }
        val parts = ArrayList<String>()
        if (added > 0) parts.add("$added adicionada(s)")
        if (duplicated > 0) parts.add("$duplicated já estava(m) na biblioteca")
        if (invalid > 0) parts.add("$invalid não é/são áudio")
        say(if (parts.isEmpty()) "Nada foi importado." else parts.joinToString(" · "))
    }

    private class Meta(val title: String, val artist: String, val durationMs: Long)

    private fun readMetadata(uri: Uri): Meta? {
        val ctx = getApplication<Application>()
        val r = MediaMetadataRetriever()
        try {
            r.setDataSource(ctx, uri)
            val duration = r.extractMetadata(MediaMetadataRetriever.METADATA_KEY_DURATION)?.toLongOrNull() ?: 0L
            val hasAudio = r.extractMetadata(MediaMetadataRetriever.METADATA_KEY_HAS_AUDIO)
            val name = fileName(uri)
            // alguns aparelhos não preenchem HAS_AUDIO em m4a/ogg: aceita se tem duração ou extensão de áudio
            if (hasAudio != "yes" && duration <= 0L && !hasAudioExtension(name)) return null
            val title = r.extractMetadata(MediaMetadataRetriever.METADATA_KEY_TITLE)?.trim().orEmpty()
            val artist = r.extractMetadata(MediaMetadataRetriever.METADATA_KEY_ARTIST)?.trim().orEmpty()
            return Meta(title.ifEmpty { displayName(uri) }, artist, duration)
        } catch (_: Exception) {
            return if (hasAudioExtension(fileName(uri))) Meta(displayName(uri), "", 0L) else null
        } finally {
            try {
                r.release()
            } catch (_: Exception) {
            }
        }
    }

    /** Nome do arquivo com a extensão ("faixa.mp3"), ou "" se o provedor não informar. */
    private fun fileName(uri: Uri): String {
        try {
            getApplication<Application>().contentResolver
                .query(uri, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)?.use { c ->
                    if (c.moveToFirst()) return c.getString(0).orEmpty()
                }
        } catch (_: Exception) {
        }
        return uri.lastPathSegment.orEmpty()
    }

    private fun displayName(uri: Uri): String {
        try {
            getApplication<Application>().contentResolver
                .query(uri, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)?.use { c ->
                    if (c.moveToFirst()) {
                        val name = c.getString(0)
                        if (!name.isNullOrBlank()) return name.substringBeforeLast('.')
                    }
                }
        } catch (_: Exception) {
        }
        return "Faixa sem título"
    }


    // ------------------------------------------------------- gravar o set (exportar a mixagem)

    private val _recStart = MutableStateFlow<Long?>(null)
    /** Momento em que a gravação começou (null = não gravando). */
    val recordingSince: StateFlow<Long?> = _recStart.asStateFlow()
    private var recFile: java.io.File? = null

    /** GRAVAR: grava tudo o que sai no som geral num WAV e, ao parar, salva em Música/Edgard Guarda DJ Studio. */
    fun toggleRecording() {
        if (_recStart.value != null) { stopRecording(); return }
        val app = getApplication<Application>()
        val dir = app.getExternalFilesDir(android.os.Environment.DIRECTORY_MUSIC) ?: app.filesDir
        dir.mkdirs()
        val stamp = java.text.SimpleDateFormat("yyyy-MM-dd_HH-mm", java.util.Locale.ROOT).format(java.util.Date())
        val f = java.io.File(dir, "set_$stamp.wav")
        if (!NativeEngine.nativeRecordStart(f.absolutePath)) { say("Não consegui começar a gravar."); return }
        recFile = f
        _recStart.value = System.currentTimeMillis()
        say("Gravando o set. Toque em GRAVAR de novo para parar e salvar.")
    }

    private fun stopRecording() {
        val f = recFile
        _recStart.value = null
        recFile = null
        viewModelScope.launch(Dispatchers.IO) {
            val frames = NativeEngine.nativeRecordStop()
            if (f == null || frames <= 0) { say("Nada foi gravado (o som estava parado?)."); return@launch }
            val secs = frames / NativeEngine.SAMPLE_RATE
            val where = publishRecording(f)
            say("Set gravado: ${f.name} (${secs / 60}:${String.format(java.util.Locale.ROOT, "%02d", secs % 60)}) em $where.")
        }
    }

    /** Copia o WAV para a pasta Música do aparelho (aparece nos apps de música e no gerenciador de arquivos). */
    private fun publishRecording(f: java.io.File): String {
        if (android.os.Build.VERSION.SDK_INT < 29) return f.parent ?: "pasta do app"
        return try {
            val r = getApplication<Application>().contentResolver
            val values = android.content.ContentValues().apply {
                put(android.provider.MediaStore.Audio.Media.DISPLAY_NAME, f.name)
                put(android.provider.MediaStore.Audio.Media.MIME_TYPE, "audio/x-wav")
                put(android.provider.MediaStore.Audio.Media.RELATIVE_PATH, "Music/Edgard Guarda DJ Studio")
                put(android.provider.MediaStore.Audio.Media.IS_PENDING, 1)
            }
            val uri = r.insert(android.provider.MediaStore.Audio.Media.EXTERNAL_CONTENT_URI, values) ?: return f.parent ?: ""
            r.openOutputStream(uri)?.use { out -> f.inputStream().use { it.copyTo(out) } }
            values.clear()
            values.put(android.provider.MediaStore.Audio.Media.IS_PENDING, 0)
            r.update(uri, values, null, null)
            f.delete()
            lastRecording = uri
            "Música/Edgard Guarda DJ Studio"
        } catch (_: Exception) {
            f.parent ?: "pasta do app"
        }
    }

    /** Último set gravado (para importar de volta ou conferir). */
    var lastRecording: Uri? = null
        private set

    // ------------------------------------------------------- efeitos de performance

    private val fxJobs = arrayOfNulls<Job>(2)

    private fun runFx(deck: Int, block: suspend () -> Unit) {
        fxJobs[deck]?.cancel()
        fxJobs[deck] = viewModelScope.launch { block() }
    }

    private fun beatSec(deck: Int): Double {
        val d = _decks.value[deck]
        return if (d.hasBpm) 60.0 / d.playedBpm else 0.5
    }

    /** ECHO OUT: eco forte no ritmo e o som do deck some em 2 compassos (sai de cena sem corte seco). */
    fun echoOut(deck: Int) {
        val d = _decks.value[deck]
        if (!d.playing) { say("ECHO OUT precisa do deck ${deckName(deck)} tocando."); return }
        runFx(deck) {
            val vol0 = _volumes.value[deck]
            setDeck(deck) { it.copy(fxType = 1, fxAmount = 0.85f) }
            pushFx(deck)
            val total = beatSec(deck) * 8
            val t0 = System.nanoTime()
            while (true) {
                val t = ((System.nanoTime() - t0) / 1e9 / total).coerceIn(0.0, 1.0)
                if (t >= 0.25) NativeEngine.nativeSetVolume(deck, (vol0 * (1.0 - (t - 0.25) / 0.75)).toFloat().coerceAtLeast(0f))
                if (t >= 1.0) break
                delay(30)
            }
            NativeEngine.nativePause(deck)
            delay(beatSec(deck).times(4000).toLong())   // deixa o eco morrer
            setDeck(deck) { it.copy(fxType = 0) }
            pushFx(deck)
            setVolume(deck, vol0)
        }
    }

    /** FILTRO AUTO: o filtro sobe (tira os graves) por 4 compassos e volta, para criar tensão antes da virada. */
    fun filterSweep(deck: Int) {
        runFx(deck) {
            val total = beatSec(deck) * 16
            val t0 = System.nanoTime()
            while (true) {
                val t = ((System.nanoTime() - t0) / 1e9 / total).coerceIn(0.0, 1.0)
                val x = if (t < 0.75) 0.5 + 0.42 * (t / 0.75) else 0.92 - 0.42 * ((t - 0.75) / 0.25)
                setFilter(deck, x.toFloat())
                if (t >= 1.0) break
                delay(30)
            }
            setFilter(deck, 0.5f)
        }
    }

    /** FREIO: o disco desacelera até parar, como desligar o toca-discos. */
    fun brake(deck: Int) {
        val d = _decks.value[deck]
        if (!d.playing) { say("FREIO precisa do deck ${deckName(deck)} tocando."); return }
        runFx(deck) {
            val r0 = d.rate
            val steps = 30
            for (i in 1..steps) {
                NativeEngine.nativeSetRate(deck, (r0 * (1f - i.toFloat() / steps)).coerceAtLeast(0.02f))
                delay(25)
            }
            NativeEngine.nativePause(deck)
            NativeEngine.nativeSetRate(deck, r0)
        }
    }

    /** VOLTA (spinback): o disco gira rápido para trás e para. */
    fun spinback(deck: Int) {
        val d = _decks.value[deck]
        if (!d.playing) { say("VOLTA precisa do deck ${deckName(deck)} tocando."); return }
        runFx(deck) {
            for (i in 0 until 20) {
                val v = -4f * (1f - i / 20f)
                NativeEngine.nativeScratch(deck, true, v)
                delay(30)
            }
            NativeEngine.nativeScratch(deck, true, 0f)
            NativeEngine.nativePause(deck)
            NativeEngine.nativeScratch(deck, false, 0f)
        }
    }

    // ------------------------------------------------------- HARMONIZAR (ordem do set)


    private fun saveSet(ids: List<Long>) {
        _set.value = ids
        setPrefs.edit().putString("ids", ids.joinToString(",")).apply()
    }

    fun clearSet() { saveSet(emptyList()); say("Ordem do set apagada.") }

    /**
     * HARMONIZAR: ordena a biblioteca num caminho de mixagem: cada próxima faixa com tom compatível na Roda de
     * Camelot, andamento perto e energia subindo aos poucos até o pico (perto de 70% do set) e descendo no fim.
     * Analisa sozinho o que faltar.
     */
    fun harmonize() {
        viewModelScope.launch {
            _analysisProgress.value = "preparando"
            try {
                analyzeMissing { done, total -> _analysisProgress.value = "$done de $total" }
            } finally {
                _analysisProgress.value = null
            }
            val all = allTracks().filter { it.bpm > 0 }
            if (all.size < 2) { say("HARMONIZAR precisa de pelo menos 2 músicas com andamento detectado."); return@launch }
            val start = _decks.value.firstOrNull { it.playing }?.trackId
            val order = withContext(Dispatchers.Default) {
                Harmonizer.order(
                    all.map { SetTrack(it.id, it.bpm, it.key, it.energy) }, start,
                )
            }
            saveSet(order.map { it.id })
            sort.value = SortOrder.SET
            say("Set harmonizado: ${order.size} músicas em ordem de tom, andamento e energia. O AUTO DJ segue esta ordem.")
        }
    }

    /** Próxima faixa do set depois de [afterId] que não esteja nos decks nem em [skip]. */
    fun nextInSet(afterId: Long, skip: Collection<Long>): Long? {
        val ids = _set.value
        if (ids.isEmpty()) return null
        val loaded = _decks.value.map { it.trackId }
        val start = ids.indexOf(afterId)
        for (k in 1..ids.size) {
            val id = ids[(start + k).mod(ids.size)]
            if (id !in loaded && id !in skip) return id
        }
        return null
    }


    // ------------------------------------------------------- navegador rápido e assistente de mixagem

    private val _browser = MutableStateFlow<Int?>(null)
    /** Deck para o qual o navegador rápido (carregar música sem sair da tela DJ) está aberto. */
    val browserDeck: StateFlow<Int?> = _browser.asStateFlow()
    fun openBrowser(deck: Int) { _browser.value = deck }
    fun closeBrowser() { _browser.value = null }

    /** Carrega pelo navegador rápido e fecha. */
    fun loadFromBrowser(deck: Int, row: TrackRow) {
        loadTrack(deck, row)
        if (!_decks.value[deck].playing) closeBrowser()
    }

    /** A faixa de referência para sugerir a próxima: a do outro deck (a que está tocando, de preferência). */
    fun referenceFor(deck: Int): SetTrack? {
        val d = _decks.value
        val other = d[1 - deck]
        val src = if (other.loaded) other else if (d[deck].loaded) d[deck] else return null
        if (!src.hasBpm) return null
        return SetTrack(src.trackId, src.playedBpm, src.shownKey, src.energy)
    }

    /** PULO DE BATIDA: avança ou volta [beats] batidas sem perder o ritmo. */
    fun beatJump(deck: Int, beats: Int) {
        val d = _decks.value[deck]
        if (!d.loaded || d.loading) { say("Carregue uma música no deck ${deckName(deck)} primeiro."); return }
        if (!d.hasBpm) { say("Pulo de batida precisa do andamento detectado."); return }
        val beat = 60.0 * NativeEngine.SAMPLE_RATE / d.bpm
        val pos = _live.value.decks[deck].positionFrames
        val target = (pos + beats * beat).toLong().coerceIn(0L, (d.lengthFrames - 1).coerceAtLeast(0L))
        NativeEngine.nativeSeek(deck, target)
    }

    override fun onCleared() {
        for (d in 0..1) NativeEngine.nativeCancelStems(d)
        decodeJobs.forEach { it?.cancel() }
        if (_recStart.value != null) NativeEngine.nativeRecordStop()
        midi.stop()
        router.stop()
        NativeEngine.nativeStop()
    }

    companion object {
        /** Volume alvo do auto-gain (dBFS RMS). */
        const val TARGET_DB = -12.0
        /** Faixa de velocidade do fader de pitch: -10% a +10%. */
        const val PITCH_MIN = 0.9f
        const val PITCH_MAX = 1.1f
        /** Abaixo disto o andamento detectado é tratado como "não detectado". */
        const val MIN_BPM_CONFIDENCE = 0.3f

        fun deckName(deck: Int) = if (deck == 0) "A" else "B"
    }
}
