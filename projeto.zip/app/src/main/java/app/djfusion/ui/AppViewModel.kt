package app.djfusion.ui

import android.app.Application
import android.content.Intent
import android.media.MediaMetadataRetriever
import android.net.Uri
import android.provider.OpenableColumns
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import app.djfusion.audio.DecodeResult
import app.djfusion.audio.NativeEngine
import app.djfusion.audio.TrackDecoder
import app.djfusion.audio.OutputRouter
import app.djfusion.audio.AudioOut
import app.djfusion.harmony.Camelot
import app.djfusion.harmony.Harmonizer
import app.djfusion.harmony.MixAdvisor
import app.djfusion.harmony.MusicalKey
import app.djfusion.harmony.SetTrack
import app.djfusion.midi.Dj2go2Touch
import app.djfusion.midi.MidiHub
import app.djfusion.data.Analysis
import app.djfusion.data.LibraryDb
import app.djfusion.data.SortOrder
import app.djfusion.data.TrackRow
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import kotlinx.coroutines.sync.withLock

/** Parte do deck que muda pouco (carregar, tocar, parar). */
data class DeckUi(
    val trackId: Long = -1,
    val title: String = "",
    val artist: String = "",
    val loaded: Boolean = false,
    val playing: Boolean = false,
    val loading: Boolean = false,
    val loadProgress: Float = 0f,
    val lengthFrames: Long = 0,
    val wave: ByteArray? = null,
    /** Andamento da faixa original (0 = não detectado) e onde cai a primeira batida. */
    val bpm: Double = 0.0,
    val firstBeatFrame: Long = 0,
    val bpmConfidence: Float = 0f,
    /** Velocidade de reprodução (1 = normal). O andamento tocado é bpm x rate. */
    val rate: Float = 1f,
    /** 0 = sem loop, senão o tamanho do loop em batidas. */
    val loopBeats: Int = 0,
    /** Hot cues: quadro de cada uma das 4 posições, -1 quando vazia. */
    val hotcues: List<Long> = List(8) { -1L },
    /** Equalizador graves, médios, agudos (0,5 = neutro) e filtro (0,5 = desligado). */
    val eq: List<Float> = listOf(0.5f, 0.5f, 0.5f),
    val filter: Float = 0.5f,
    /** Efeito do deck: 0 desligado, 1 eco, 2 flanger, 3 reverb, e a mistura de 0 a 1. */
    val fxType: Int = 0,
    val fxAmount: Float = 0.5f,
    /** Key-lock: o andamento muda sem mudar o tom. */
    val keyLock: Boolean = false,
    /** Pré-escuta no fone (PFL). */
    val cueOn: Boolean = false,
    /** Tonalidade detectada da faixa (nota 0..11, -1 = desconhecida), modo e confiança. */
    val keyTonic: Int = -1,
    val keyMinor: Boolean = false,
    val keyConf: Float = 0f,
    /** A área do prato mostra os pads (hot cue, loop, efeito) em vez do prato. */
    val padsOpen: Boolean = false,
    /** Modo dos pads na tela: 0 CUES, 1 LOOP, 2 SAMPLER, 3 MANOBRAS, 4 ROLL (como o PAD MODE da controladora). */
    val padMode: Int = 0,
    /** Música já tocável, mas o andamento/tom/energia ainda estão sendo analisados em segundo plano. */
    val analyzing: Boolean = false,
    /** Faixa do fader de pitch em % (±6 a ±50). */
    val pitchRange: Int = 16,
    /** SYNC travado: segue o andamento e corrige a fase da batida o tempo todo. */
    val syncLock: Boolean = false,
    /** Divisão de batida dos efeitos (eco, trans, phaser): 0,25 a 2 batidas. */
    val fxBeats: Float = 0.75f,
    /** ROLL ativo (tamanho em batidas, 0 = desligado). */
    val rollBeats: Float = 0f,
    /** Energia da faixa de 0 a 1 (-1 = não medida). */
    val energy: Float = -1f,
    /** Stems: -2 = indisponíveis (música longa/pouca memória), -1 = não separados, 0..1 = separando, 1 = prontos. */
    val stemProgress: Float = -1f,
    /** Ganho de voz, bateria, baixo e melodia (0..1). */
    val stemGains: List<Float> = listOf(1f, 1f, 1f, 1f),
    /** A área do prato mostra o painel de stems. */
    val stemsOpen: Boolean = false,
    /** Tom deslocado em semitons (-12..12), sem mudar o andamento. */
    val keyShift: Int = 0,
    /** SLIP: depois de scratch, loop, reverso ou censura, a música volta onde estaria. */
    val slip: Boolean = false,
    /** Tocando ao contrário (REVERSO). */
    val reverse: Boolean = false,
    /** Volume médio medido (dBFS, 0 = não medido) e ganho de entrada aplicado pelo auto-gain. */
    val loudness: Float = 0f,
    val trim: Float = 1f,
) {
    val stemsReady: Boolean get() = stemProgress >= 1f
    val energyLevel: Int get() = if (energy < 0f) 0 else (1 + Math.round(energy * 9f)).coerceIn(1, 10)
    /** Tonalidade original, se detectada com confiança. */
    val key: MusicalKey?
        get() = if (keyTonic in 0..11 && keyConf >= Camelot.MIN_CONFIDENCE) MusicalKey.of(keyTonic, keyMinor) else null
    /** Tonalidade que se ouve agora: sem key-lock, mudar a velocidade desloca o tom. */
    val shownKey: MusicalKey? get() = (if (keyLock) key else key?.shifted(Camelot.semitonesFor(rate)))?.shifted(keyShift)
    val hasBpm: Boolean get() = bpm > 0.0 && bpmConfidence >= AppViewModel.MIN_BPM_CONFIDENCE
    val playedBpm: Double get() = bpm * rate
}

/** Um pad do sampler. */
data class PadUi(
    val label: String = "", val loop: Boolean = false, val ready: Boolean = false, val playing: Boolean = false,
    /** Andamento original do trecho (0 = sem andamento): loops seguem o andamento do deck que está tocando. */
    val bpm: Double = 0.0,
)

/** Parte que muda ~30 vezes por segundo (posição e nível). Fica separada para não redesenhar tudo. */
data class DeckLive(
    val positionFrames: Long = 0,
    val cueFrames: Long = 0,
    val peak: Float = 0f,
)

data class LiveUi(
    val decks: List<DeckLive> = listOf(DeckLive(), DeckLive()),
    val masterPeak: Float = 0f,
)

class AppViewModel(app: Application) : AndroidViewModel(app) {
    private val db = LibraryDb(app)
    private val outPrefs = app.getSharedPreferences("output", android.content.Context.MODE_PRIVATE)

    /** Saída do fone: 0 só som geral, 1 dividido (E fone, D geral), 2 quatro canais (1-2 geral, 3-4 fone). */
    /** Modo do fone: 0 sem fone, 1 dividido, 2 quatro canais. -1 nas preferências = automático. */
    private val _outModePref = MutableStateFlow(outPrefs.getInt("mode2", -1).coerceIn(-1, 2))
    private val _outMode = MutableStateFlow(0)
    val outputMode: StateFlow<Int> = _outMode.asStateFlow()
    /** Segunda saída que toca junto (0 = nenhuma) e o que ela toca (0 = som geral, 1 = fone). */
    private val _mirrorDevice = MutableStateFlow(outPrefs.getInt("mirror", 0))
    val mirrorDevice: StateFlow<Int> = _mirrorDevice.asStateFlow()
    private val _mirrorWhat = MutableStateFlow(outPrefs.getInt("mirrorWhat", 0))
    val mirrorWhat: StateFlow<Int> = _mirrorWhat.asStateFlow()
    /** Aparelho de saída escolhido: -1 = automático (a primeira placa USB). */
    private val _outDevice = MutableStateFlow(outPrefs.getInt("device2", -1))
    val outputDevice: StateFlow<Int> = _outDevice.asStateFlow()
    private val _outNote = MutableStateFlow("")
    val outputNote: StateFlow<String> = _outNote.asStateFlow()
    private val _hpLevel = MutableStateFlow(0.7f)
    val hpLevel: StateFlow<Float> = _hpLevel.asStateFlow()
    private val _hpMix = MutableStateFlow(0f)
    val hpMix: StateFlow<Float> = _hpMix.asStateFlow()
    val router = OutputRouter(app) { applyOutput() }
    val outputs: StateFlow<List<AudioOut>> get() = router.devices

    private val _defaultPitch = MutableStateFlow(outPrefs.getInt("pitchRange", 16).let { if (it in PITCH_RANGES) it else 16 })
    /** Faixa do pitch com que os decks começam (AJUSTES). */
    val defaultPitch: StateFlow<Int> = _defaultPitch.asStateFlow()
    private val _decks = MutableStateFlow(List(2) { DeckUi(pitchRange = _defaultPitch.value) })
    val decks: StateFlow<List<DeckUi>> = _decks.asStateFlow()

    private val _live = MutableStateFlow(LiveUi())
    val live: StateFlow<LiveUi> = _live.asStateFlow()

    private val _volumes = MutableStateFlow(listOf(1f, 1f))
    val volumes: StateFlow<List<Float>> = _volumes.asStateFlow()
    private val _crossfader = MutableStateFlow(0.5f)
    val crossfader: StateFlow<Float> = _crossfader.asStateFlow()
    private val _master = MutableStateFlow(0.8f)
    val master: StateFlow<Float> = _master.asStateFlow()

    private val _message = MutableStateFlow<String?>(null)
    val message: StateFlow<String?> = _message.asStateFlow()

    private val _audioStatus = MutableStateFlow("Áudio desligado")
    val audioStatus: StateFlow<String> = _audioStatus.asStateFlow()

    val search = MutableStateFlow("")
    val sort = MutableStateFlow(SortOrder.RECENT)
    private val libraryVersion = MutableStateFlow(0)

    private val setPrefs = app.getSharedPreferences("set", android.content.Context.MODE_PRIVATE)
    private val _set = MutableStateFlow(
        setPrefs.getString("ids", "").orEmpty().split(',').mapNotNull { it.toLongOrNull() },
    )
    /** Ordem do set montada pelo HARMONIZAR (ids das faixas). O AUTO DJ segue esta ordem. */
    val setOrder: StateFlow<List<Long>> = _set.asStateFlow()

    val tracks: StateFlow<List<TrackRow>> =
        combine(search, sort, libraryVersion, _set) { s, o, _, _ -> s to o }
            .map { (s, o) ->
                val rows = withContext(Dispatchers.IO) { db.query(s, o) }
                if (o == SortOrder.SET) {
                    val pos = _set.value.withIndex().associate { it.value to it.index }
                    rows.sortedBy { pos[it.id] ?: Int.MAX_VALUE }
                } else rows
            }
            .stateIn(viewModelScope, SharingStarted.Eagerly, emptyList())

    private val decodeJobs = arrayOfNulls<Job>(2)

    private var foreground = true

    /** Controladoras MIDI USB (Numark etc.). Os controles aprendidos chegam em [onMidi]. */
    val midi = MidiHub(app, onPreset = {
        jog.setTicksPerRev(Dj2go2Touch.TICKS_PER_REV)
        say("Mapa de fábrica da Numark DJ2GO2 Touch aplicado: prato, play, cue, sync, pads e faders.")
    }) { id, v -> onMidi(id, v) }.also { h -> h.onConnected = { h.resetLeds() } }

    private fun onMidi(id: String, v: Float) {
        if (id == "xfade") { setCrossfader(v); return }
        if (id == "master") { setMaster(v); return }
        if (id == "autodj") { autoDj.toggle(); return }
        if (id == "automixnow") { autoDj.mixNow(); return }
        if (id.startsWith("pad")) { padPress(id.substring(3).toInt() - 1); return }
        if (id == "hpvol") { setHeadphoneLevel(v); return }
        if (id == "hpmix") { setHeadphoneMix(v); return }
        if (id == "browse") { browse(v.toInt()); return }
        if (id == "browsepush") { browsePush(); return }
        val deck = id[1].digitToInt()
        val k = id.substring(3)
        when {
            k == "play" -> togglePlay(deck)
            k == "cue" -> if (v > 0.5f) cueDown(deck) else cueUp(deck)
            k == "sync" -> syncButton(deck)
            k == "vol" -> if (_levelAsFilter.value) setFilter(deck, v) else setVolume(deck, v)
            k == "eqhi" -> setEq(deck, 2, v)
            k == "eqmid" -> setEq(deck, 1, v)
            k == "eqlo" -> setEq(deck, 0, v)
            k == "filter" -> setFilter(deck, v)
            k == "tempo" -> setPitchFader(deck, v)
            k == "fxamt" -> setFxAmount(deck, v)
            k == "jog" -> jog.tick(deck, v.toInt())
            k == "jogtouch" -> jog.touch(deck, v > 0.5f)
            k == "keylock" -> toggleKeyLock(deck)
            k == "pfl" -> toggleHeadphoneCue(deck)
            k == "fxeco" -> setFx(deck, 1)
            k == "fxflg" -> setFx(deck, 2)
            k == "fxrev" -> setFx(deck, 3)
            k.startsWith("hotdel") -> clearHotcue(deck, k.substring(6).toInt() - 1)
            k == "loopin" -> loopIn(deck)
            k == "loopout" -> loopOut(deck)
            k == "reloop" -> reloop(deck)
            k == "loopstart" -> loopToStart(deck)
            k == "load" -> loadSelected(deck)
            // modo PERFORMANCE: os pads de hot cue viram stems e os de loop automático viram manobras
            _padPerf.value && k.matches(Regex("hot[1-4]")) -> toggleStem(deck, k.substring(3).toInt() - 1)
            _padPerf.value && k.matches(Regex("loop[1248]")) -> when (k.substring(4).toInt()) {
                1 -> toggleSlip(deck)
                2 -> toggleReverse(deck)
                4 -> censor(deck)
                else -> matchKey(deck)
            }
            k.matches(Regex("hot[1-4]")) -> hotcue(deck, k.substring(3).toInt() - 1)
            k.matches(Regex("loop[1248]")) -> toggleLoop(deck, k.substring(4).toInt())
            k == "stemv" -> toggleStem(deck, 0)
            k == "stemd" -> toggleStem(deck, 1)
            k == "stemb" -> toggleStem(deck, 2)
            k == "stemm" -> toggleStem(deck, 3)
            k == "acapella" -> stemPreset(deck, 1)
            k == "instr" -> stemPreset(deck, 2)
            k == "stemall" -> stemPreset(deck, 0)
            k == "slip" -> toggleSlip(deck)
            k == "rev" -> toggleReverse(deck)
            k == "censor" -> censor(deck)
            k == "keyup" -> shiftKey(deck, 1)
            k == "keydown" -> shiftKey(deck, -1)
            k == "keymatch" -> matchKey(deck)
            k == "jumpf" -> beatJump(deck, 4)
            k == "jumpb" -> beatJump(deck, -4)
        }
    }

    // ------------------------------------------------------------------ LOOP MANUAL (in / out)

    private val loopInAt = longArrayOf(-1, -1)
    private val loopOutAt = longArrayOf(-1, -1)
    private val _manualLoop = MutableStateFlow(listOf(-1L to -1L, -1L to -1L))
    /** Pontos do loop manual de cada deck (in, out), -1 = não marcado. */
    val manualLoop: StateFlow<List<Pair<Long, Long>>> = _manualLoop.asStateFlow()
    private fun pubLoop() { _manualLoop.value = listOf(loopInAt[0] to loopOutAt[0], loopInAt[1] to loopOutAt[1]) }

    private fun posOf(deck: Int): Long { val st = LongArray(4); NativeEngine.nativeDeckState(deck, st); return st[1] }

    /** LOOP IN: marca o início do loop onde a música está (no meio de um loop, só muda o início). */
    fun loopIn(deck: Int) {
        val d = _decks.value[deck]
        if (!d.loaded || d.loading) { say("Carregue uma música no deck ${deckName(deck)} primeiro."); return }
        loopInAt[deck] = snapToBeat(d, posOf(deck))
        if (d.loopBeats == -1 && loopOutAt[deck] > loopInAt[deck]) {
            setLoopNative(deck, loopInAt[deck], loopOutAt[deck])
        } else {
            loopOutAt[deck] = -1
        }
        pubLoop()
        say("LOOP IN marcado no deck ${deckName(deck)}. Toque em LOOP OUT para fechar o loop.")
    }

    /** LOOP OUT: fecha o loop entre o LOOP IN e onde a música está, e liga. */
    fun loopOut(deck: Int) {
        val d = _decks.value[deck]
        val a = loopInAt[deck]
        if (a < 0) { say("Marque o LOOP IN primeiro."); return }
        var b = snapToBeat(d, posOf(deck))
        // com QUANTIZE o loop tem pelo menos 1 batida
        if (_quantize.value && d.hasBpm && b <= a) b = a + (60.0 * NativeEngine.SAMPLE_RATE / d.bpm).toLong()
        if (b <= a + NativeEngine.SAMPLE_RATE / 20) { say("O LOOP OUT precisa vir depois do LOOP IN."); return }
        loopOutAt[deck] = b
        if (d.loopBeats == 0) slipBegin(deck)
        setLoopNative(deck, a, b)
        setDeck(deck) { it.copy(loopBeats = -1) }
        pubLoop()
    }

    /** RELOOP: liga ou desliga o loop manual guardado. */
    fun reloop(deck: Int) {
        val d = _decks.value[deck]
        if (d.loopBeats != 0) {
            clearLoopNative(deck)
            setDeck(deck) { it.copy(loopBeats = 0) }
            slipEnd(deck)
            return
        }
        val a = loopInAt[deck]; val b = loopOutAt[deck]
        if (a < 0 || b <= a) { say("Sem loop guardado: use LOOP IN e LOOP OUT."); return }
        slipBegin(deck)
        val p = posOf(deck)
        if (p < a || p >= b) NativeEngine.nativeSeek(deck, a)
        setLoopNative(deck, a, b)
        setDeck(deck) { it.copy(loopBeats = -1) }
    }

    /** Volta ao início do loop manual (e liga o loop, se tiver fim marcado). */
    fun loopToStart(deck: Int) {
        val a = loopInAt[deck]
        if (a < 0) { say("Marque o LOOP IN primeiro."); return }
        NativeEngine.nativeSeek(deck, a)
        val b = loopOutAt[deck]
        if (b > a) { setLoopNative(deck, a, b); setDeck(deck) { it.copy(loopBeats = -1) } }
        if (!_decks.value[deck].playing) NativeEngine.nativePlay(deck)
    }

    // ------------------------------------------------------------------ BROWSE e LOAD da controladora

    private val _browseIndex = MutableStateFlow(0)
    /** Música selecionada pelo botão BROWSE da controladora (posição na lista mostrada). */
    val browseIndex: StateFlow<Int> = _browseIndex.asStateFlow()
    /** Ordem da lista que está na tela (o navegador rápido ordena pelo assistente). */
    private var browseIds: List<Long> = emptyList()
    fun setBrowseList(ids: List<Long>) {
        browseIds = ids
        if (_browseIndex.value >= ids.size) _browseIndex.value = (ids.size - 1).coerceAtLeast(0)
    }
    private fun browseList(): List<TrackRow> {
        val all = tracks.value
        if (browseIds.isEmpty() || (browserDeck.value == null && !_browserDock.value)) return all
        val byId = all.associateBy { it.id }
        return browseIds.mapNotNull { byId[it] }
    }

    fun browse(delta: Int) {
        val list = browseList()
        if (list.isEmpty()) { say("Biblioteca vazia: importe músicas."); return }
        val i = (_browseIndex.value + delta).coerceIn(0, list.size - 1)
        _browseIndex.value = i
        if (browserDeck.value == null && !_browserDock.value) say("▶ ${list[i].title}  (LOAD A ou LOAD B para carregar)")
    }

    fun browsePush() {
        if (browserDeck.value != null) closeBrowser()
        else openBrowser(if (_decks.value[0].playing && !_decks.value[1].playing) 1 else 0)
    }

    /** LOAD da controladora: carrega a música selecionada no deck. */
    fun loadSelected(deck: Int) {
        val list = browseList()
        val row = list.getOrNull(_browseIndex.value) ?: run { say("Gire o BROWSE para escolher uma música."); return }
        if (browserDeck.value != null) closeBrowser()
        loadTrack(deck, row)
    }

    // ------------------------------------------------------------------ LEDs da controladora

    private fun syncLeds() {
        val ds = _decks.value
        val pads = _pads.value
        for (d in 0..1) {
            val x = ds[d]
            midi.led("d$d.play", x.playing)
            midi.led("d$d.cue", x.loaded && !x.playing)
            midi.led("d$d.pfl", x.cueOn)
            midi.led("d$d.sync", false)
            for (sl in 0..3) midi.led("d$d.hot${sl + 1}", x.hotcues[sl] >= 0)
            for (b in intArrayOf(1, 2, 4, 8)) midi.led("d$d.loop$b", x.loopBeats == b)
            midi.led("d$d.loopin", loopInAt[d] >= 0)
            midi.led("d$d.loopout", loopOutAt[d] >= 0)
            midi.led("d$d.reloop", x.loopBeats == -1)
            midi.led("d$d.loopstart", loopInAt[d] >= 0)
        }
        for (i in 0..7) midi.led("pad${i + 1}", pads[i].ready)
    }

    /** Knob LEVEL de cada deck da controladora: false = volume do deck, true = filtro (como no Mixxx). */
    private val _levelAsFilter = MutableStateFlow(outPrefs.getBoolean("levelFilter", false))
    val levelAsFilter: StateFlow<Boolean> = _levelAsFilter.asStateFlow()
    fun toggleLevelAsFilter() {
        _levelAsFilter.value = !_levelAsFilter.value
        outPrefs.edit().putBoolean("levelFilter", _levelAsFilter.value).apply()
        say(if (_levelAsFilter.value) "Knob LEVEL da controladora agora controla o FILTRO de cada deck." else "Knob LEVEL da controladora agora controla o VOLUME de cada deck.")
    }

    // ------------------------------------------------------------------ RELATÓRIO DE DIAGNÓSTICO

    /** Texto com tudo que ajuda a achar um problema: aparelho, saídas de áudio, controladora e erros de leitura. */
    fun diagnosticsText(): String {
        val info = IntArray(8)
        NativeEngine.nativeStreamInfo(info)
        val ctx = getApplication<Application>()
        val ver = runCatching { ctx.packageManager.getPackageInfo(ctx.packageName, 0).versionName }.getOrNull()
        return buildString {
            appendLine("EDGARD GUARDA DJ STUDIO — RELATÓRIO DE DIAGNÓSTICO")
            appendLine("versão $ver · Android ${android.os.Build.VERSION.RELEASE} (API ${android.os.Build.VERSION.SDK_INT}) · ${android.os.Build.MANUFACTURER} ${android.os.Build.MODEL}")
            appendLine("data ${java.text.SimpleDateFormat("yyyy-MM-dd HH:mm:ss", java.util.Locale.ROOT).format(java.util.Date())}")
            appendLine()
            appendLine("ÁUDIO: ${_audioStatus.value}")
            appendLine("  fluxo: taxa=${info[0]} rajada=${info[1]} buffer=${info[2]} exclusivo=${info[3]} canais=${info[4]} modo=${info[5]} aparelho=${info[6]} segunda=${info[7]}")
            appendLine("  escolhido: principal=${_outDevice.value} modo=${_outMode.value} (pref ${_outModePref.value}) segunda=${_mirrorDevice.value}/${_mirrorWhat.value}")
            appendLine("  ${_outNote.value}")
            appendLine("SAÍDAS DO ANDROID:")
            appendLine(router.describeAll())
            appendLine()
            appendLine("CONTROLADORA (MIDI):")
            appendLine(midi.describeDevices())
            appendLine("  passos do jog por volta: ${jog.ticksPerRev} · ajuste fino x${jog.bendGain} · LEVEL=${if (_levelAsFilter.value) "filtro" else "volume"} · pads performance=${_padPerf.value}")
            appendLine("MAPA:")
            appendLine(midi.describeMap())
            appendLine("ÚLTIMAS MENSAGENS (mais recente primeiro):")
            for (l in midi.diag.take(150)) appendLine("  $l")
            appendLine()
            appendLine("DECKS:")
            for ((i, d) in _decks.value.withIndex()) {
                appendLine("  ${deckName(i)}: ${if (d.loaded) d.title else "vazio"} · tocando=${d.playing} · bpm=${d.bpm} · tom=${d.key?.code} · stems=${d.stemProgress} · ganho=${d.trim}")
            }
            appendLine("BIBLIOTECA: ${tracks.value.size} faixa(s) na lista")
            appendLine("ERROS DE LEITURA DE MÚSICA:")
            if (TrackDecoder.recentErrors.isEmpty()) appendLine("  nenhum")
            for (e in TrackDecoder.recentErrors) appendLine("  $e")
        }
    }

    /** Copia o relatório para a área de transferência e salva em Download/Edgard Guarda DJ Studio. */
    fun exportDiagnostics() {
        val text = diagnosticsText()
        val ctx = getApplication<Application>()
        val cm = ctx.getSystemService(android.content.Context.CLIPBOARD_SERVICE) as android.content.ClipboardManager
        cm.setPrimaryClip(android.content.ClipData.newPlainText("Relatório DJ Studio", text))
        viewModelScope.launch(Dispatchers.IO) {
            val where = try {
                if (android.os.Build.VERSION.SDK_INT >= 29) {
                    val r = ctx.contentResolver
                    val name = "diagnostico_" + java.text.SimpleDateFormat("yyyy-MM-dd_HH-mm", java.util.Locale.ROOT).format(java.util.Date()) + ".txt"
                    val v = android.content.ContentValues().apply {
                        put(android.provider.MediaStore.Downloads.DISPLAY_NAME, name)
                        put(android.provider.MediaStore.Downloads.MIME_TYPE, "text/plain")
                        put(android.provider.MediaStore.Downloads.RELATIVE_PATH, "Download/Edgard Guarda DJ Studio")
                    }
                    val uri = r.insert(android.provider.MediaStore.Downloads.EXTERNAL_CONTENT_URI, v)
                    if (uri != null) { r.openOutputStream(uri)?.use { it.write(text.toByteArray()) }; "Download/Edgard Guarda DJ Studio/$name" } else "área de transferência"
                } else "área de transferência"
            } catch (_: Exception) { "área de transferência" }
            say("Relatório copiado (cole numa mensagem) e salvo em $where.")
        }
    }

    /** Pads da controladora em modo PERFORMANCE (hot cue = stems, loop = SLIP/REV/CENS/TOM). */
    private val _padPerf = MutableStateFlow(false)
    val padPerf: StateFlow<Boolean> = _padPerf.asStateFlow()

    fun togglePadPerf() {
        _padPerf.value = !_padPerf.value
        say(
            if (_padPerf.value) "Pads da controladora em PERFORMANCE: pads de hot cue = VOZ, BATERIA, BAIXO, MELODIA; pads de loop = SLIP, REVERSO, CENSURA, TOM."
            else "Pads da controladora de volta ao normal: hot cue e loop.",
        )
    }
    private var stopJob: Job? = null

    /** AUTO DJ: o app escolhe as músicas e faz as mixagens sozinho. */
    val autoDj = AutoDj(this, viewModelScope, app.getSharedPreferences("autodj", android.content.Context.MODE_PRIVATE))

    /** Jog wheel das controladoras (scratch e ajuste fino). */
    val jog = JogController(app.getSharedPreferences("jog", android.content.Context.MODE_PRIVATE), this, viewModelScope)

    // ---------------------------------------------------------------- sampler

    private val _pads = MutableStateFlow(List(8) { PadUi() })
    val pads: StateFlow<List<PadUi>> = _pads.asStateFlow()
    private val _samplerVol = MutableStateFlow(0.8f)
    val samplerVol: StateFlow<Float> = _samplerVol.asStateFlow()

    /** Escolhe sozinho os melhores trechos das músicas dos decks e os coloca nos pads (4 por deck). */
    /** Pads "inteligentes": depois de gerar uma vez, cada música nova no deck troca as amostras daquele deck. */
    private val autoSamples = booleanArrayOf(false, false)

    fun buildSamples() {
        val decks = _decks.value
        if (decks.none { it.loaded && !it.loading }) {
            say("Carregue uma música em pelo menos um deck para gerar as amostras.")
            return
        }
        viewModelScope.launch(Dispatchers.Default) {
            var total = 0
            for (deck in 0..1) {
                if (!decks[deck].loaded || decks[deck].loading) continue
                autoSamples[deck] = true
                total += buildSamplesNow(deck)
            }
            NativeEngine.nativeSetSamplerVolume(_samplerVol.value)
            say(if (total > 0) "$total amostras prontas nos pads. Elas acompanham as próximas músicas de cada deck." else "Não achei trechos bons nessas faixas.")
        }
    }

    /** Gera os 4 pads do deck (1–4 = A, 5–8 = B) a partir da música dele. Devolve quantos ficaram prontos. */
    private fun buildSamplesNow(deck: Int): Int {
        val d = _decks.value[deck]
        if (!d.loaded || d.loading) return 0
        android.os.Process.setThreadPriority(android.os.Process.THREAD_PRIORITY_BACKGROUND)
        val base = deck * 4
        for (k in base until base + 4) { sentSpeed[k] = 1f; NativeEngine.nativeSetSampleSpeed(k, 1f) }
        val info = LongArray(12)
        val n = NativeEngine.nativeBuildSamples(deck, if (d.hasBpm) d.bpm else 0.0, d.firstBeatFrame, base, info)
        val short = d.title.take(14)
        _pads.update { old ->
            old.mapIndexed { i, p ->
                if (i !in base until base + 4) return@mapIndexed p
                val k = i - base
                if (k >= n) return@mapIndexed PadUi()
                val kind = info[3 * k].toInt()
                val loop = info[3 * k + 2] == 1L
                val what = when (kind) {
                    0 -> "BUMBO"
                    1 -> "GOLPE"
                    2 -> if (loop) "LOOP 1 COMPASSO" else "TRECHO FORTE"
                    else -> "LOOP 2 COMPASSOS"
                }
                PadUi("${deckName(deck)} · $what · $short", loop, true, false, if (d.hasBpm) d.bpm else 0.0)
            }
        }
        return n
    }

    /** CAPTURA: o compasso que está tocando agora (4 batidas, a partir da batida) vira um loop num pad do deck. */
    fun captureLoop(deck: Int) {
        val d = _decks.value[deck]
        if (!d.loaded || d.loading) { say("Carregue uma música no deck ${deckName(deck)} primeiro."); return }
        val beat = if (d.hasBpm) 60.0 * NativeEngine.SAMPLE_RATE / d.bpm else NativeEngine.SAMPLE_RATE * 0.5
        val pos = posOf(deck)
        val start = if (d.hasBpm) (d.firstBeatFrame + Math.floor((pos - d.firstBeatFrame) / beat) * beat).toLong() else pos
        val base = deck * 4
        val slot = (base until base + 4).firstOrNull { !_pads.value[it].ready } ?: (base + 3)
        viewModelScope.launch(Dispatchers.Default) {
            if (!NativeEngine.nativeCaptureSample(deck, slot, start.coerceAtLeast(0L), (4 * beat).toLong())) { say("Não consegui capturar."); return@launch }
            sentSpeed[slot] = 1f; NativeEngine.nativeSetSampleSpeed(slot, 1f)
            _pads.update { l -> l.mapIndexed { i, p -> if (i == slot) PadUi("${deckName(deck)} · CAPTURA · ${d.title.take(12)}", true, true, false, if (d.hasBpm) d.bpm else 0.0) else p } }
            say("Compasso capturado no pad ${slot + 1}: toque para repetir em loop no ritmo.")
        }
    }

    /** INSTANT DOUBLE: a mesma música do outro deck, no mesmo ponto e andamento (para scratch e manobras). */
    fun instantDouble(deck: Int) {
        val other = 1 - deck
        val o = _decks.value[other]
        if (!o.loaded || o.trackId < 0) { say("O deck ${deckName(other)} está vazio."); return }
        viewModelScope.launch {
            val row = allTracks().firstOrNull { it.id == o.trackId } ?: return@launch
            if (!loadTrackAndWait(deck, row)) return@launch
            val now = _decks.value[other]
            setRateExact(deck, now.rate)
            NativeEngine.nativeSeek(deck, posOf(other))
            if (now.playing) NativeEngine.nativePlay(deck)
            say("Deck ${deckName(deck)} dobrou o ${deckName(other)}: mesma música, mesmo ponto.")
        }
    }

    /** Chamado quando a análise de uma música nova termina: renova os pads do deck se o modo automático estiver ligado. */
    private fun refreshAutoSamples(deck: Int) {
        if (!autoSamples[deck]) return
        viewModelScope.launch(Dispatchers.Default) {
            val n = buildSamplesNow(deck)
            if (n > 0) say("Pads ${if (deck == 0) "1–4" else "5–8"}: $n amostras novas de ${_decks.value[deck].title}.")
        }
    }

    fun clearSamples() {
        autoSamples.fill(false)
        sentSpeed.fill(1f)
        NativeEngine.nativeClearSamples()
        _pads.value = List(8) { PadUi() }
    }

    /** Deck que manda no andamento: o que está tocando (se os dois, o do lado do crossfader). */
    private fun leadDeck(): Int? {
        val d = _decks.value
        val p = (0..1).filter { d[it].playing && d[it].hasBpm }
        if (p.isEmpty()) return null
        if (p.size == 1) return p[0]
        return if (_crossfader.value <= 0.5f) 0 else 1
    }

    /** Velocidade para o trecho seguir o andamento do deck que está tocando (1, ou o múltiplo mais perto). */
    private fun padSpeed(pad: PadUi): Float {
        val lead = leadDeck() ?: return 1f
        if (pad.bpm <= 0.0) return 1f
        val target = _decks.value[lead].playedBpm
        var best = 1.0
        var err = Double.MAX_VALUE
        for (k in doubleArrayOf(1.0, 2.0, 0.5)) {
            val s = target / (pad.bpm * k)
            if (kotlin.math.abs(s - 1.0) < err) { err = kotlin.math.abs(s - 1.0); best = s }
        }
        return best.toFloat().coerceIn(0.5f, 2f)
    }

    /** Quadros até a próxima batida do deck que está tocando (0 se acabou de passar uma, ou se nada toca). */
    private fun framesToNextBeat(): Long {
        val lead = leadDeck() ?: return 0L
        val d = _decks.value[lead]
        val beat = 60.0 * NativeEngine.SAMPLE_RATE / d.bpm
        val pos = _live.value.decks[lead].positionFrames.toDouble()
        val phase = posMod(pos - d.firstBeatFrame, beat)
        val rate = d.rate.toDouble().coerceAtLeast(0.1)
        if (phase / rate < 0.03 * NativeEngine.SAMPLE_RATE) return 0L      // tocou logo depois da batida: entra já
        return ((beat - phase) / rate).toLong()
    }

    private val sentSpeed = FloatArray(8) { 1f }

    /** Mantém os pads no andamento do deck que está tocando (chamado pela leitura periódica). */
    private fun syncPadSpeeds() {
        val pads = _pads.value
        for (i in pads.indices) {
            if (!pads[i].ready) continue
            val s = padSpeed(pads[i])
            if (kotlin.math.abs(s - sentSpeed[i]) > 0.0005f) {
                sentSpeed[i] = s
                NativeEngine.nativeSetSampleSpeed(i, s)
            }
        }
    }

    /** Pad de golpe toca uma vez; pad de loop liga e desliga o loop. Entra na próxima batida, no andamento do deck. */
    fun padPress(slot: Int) {
        val pad = _pads.value.getOrNull(slot) ?: return
        if (!pad.ready) { say("Pad vazio. Toque em AMOSTRAR para gerar os trechos das músicas dos decks."); return }
        if (pad.loop && pad.playing) { NativeEngine.nativeStopSample(slot); return }
        syncPadSpeeds()
        // sons prontos (sem andamento) tocam na hora; trechos das músicas entram na próxima batida
        NativeEngine.nativeTriggerSampleAt(slot, pad.loop, if (pad.bpm > 0.0 || pad.loop) framesToNextBeat() else 0L)
    }

    fun setSamplerVolume(v: Float) {
        _samplerVol.value = v
        NativeEngine.nativeSetSamplerVolume(v)
    }

    // ------------------------------------------------- análise da biblioteca

    private val _analysisProgress = MutableStateFlow<String?>(null)
    /** Texto de andamento da análise em lote ("3 de 20"), ou null quando parada. */
    val analysisProgress: StateFlow<String?> = _analysisProgress.asStateFlow()
    private var analyzeJob: Job? = null

    /** Analisa andamento e tom de todas as faixas da biblioteca que ainda não foram analisadas. */
    fun analyzeLibrary() {
        if (analyzeJob?.isActive == true) {
            analyzeJob?.cancel()
            _analysisProgress.value = null
            return
        }
        analyzeJob = viewModelScope.launch {
            try {
                val n = analyzeMissing { done, total -> _analysisProgress.value = "$done de $total" }
                say(if (n == 0) "Todas as faixas já foram analisadas." else "Análise concluída: $n faixa(s).")
            } finally {
                _analysisProgress.value = null
            }
        }
    }

    /** Analisa (andamento e tom) as faixas que faltam. Devolve quantas analisou. Usado também pelo AUTO DJ. */
    suspend fun analyzeMissing(progress: (Int, Int) -> Unit): Int {
        val todo = withContext(Dispatchers.IO) { db.unanalyzed() }
        var done = 0
        for (row in todo) {
            progress(done + 1, todo.size)
            val r = TrackDecoder.decode(getApplication(), Uri.parse(row.uri)) { }
            if (r is DecodeResult.Ready) {
                try {
                    withContext(Dispatchers.Default) {
                        android.os.Process.setThreadPriority(android.os.Process.THREAD_PRIORITY_BACKGROUND)
                        var a = db.analysis(row.id)
                        if (a == null) {
                            val out = DoubleArray(3)
                            NativeEngine.nativeAnalyze(r.trackHandle, out)
                            a = withDownbeat(Analysis(out[0], out[1].toLong(), out[2].toFloat()), r.trackHandle)
                        }
                        if (a.keyTonic < 0) {
                            val k = IntArray(4)
                            NativeEngine.nativeAnalyzeKey(r.trackHandle, k)
                            a = if (k[0] == 1) a.copy(keyTonic = k[1], keyMinor = k[2] == 1, keyConf = k[3] / 1000f)
                            else a.copy(keyTonic = 0, keyMinor = false, keyConf = 0f)
                        }
                        if (a.energy < 0f) a = a.copy(energy = NativeEngine.nativeAnalyzeEnergy(r.trackHandle).coerceAtLeast(0f))
                        db.saveAnalysis(row.id, a)
                    }
                } finally {
                    NativeEngine.nativeFreeTrack(r.trackHandle)
                }
            } else {
                // arquivo ilegível: marca como analisado sem andamento, para não tentar de novo para sempre
                withContext(Dispatchers.IO) { db.saveAnalysis(row.id, Analysis(0.0, 0L, 0f, keyTonic = 0, keyMinor = false, keyConf = 0f, energy = 0f)) }
            }
            done++
            libraryVersion.update { it + 1 }
        }
        return done
    }

    /** Todas as faixas da biblioteca, com o que já foi analisado (para o AUTO DJ). */
    suspend fun allTracks(): List<TrackRow> = withContext(Dispatchers.IO) { db.query("", SortOrder.RECENT) }

    /** Carrega a faixa no deck e espera terminar. Devolve false se falhou. */
    suspend fun loadTrackAndWait(deck: Int, row: TrackRow): Boolean {
        loadTrack(deck, row)
        var waited = 0
        while (waited < 600) {                       // até 60 s
            delay(100)
            waited++
            val d = _decks.value[deck]
            if (!d.loading && !d.analyzing) return d.loaded && d.trackId == row.id
        }
        return false
    }

    init {
        midi.start()
        router.start()
        // O motor C++ vive no processo, não na Activity: se a tela foi fechada e reaberta sem o processo
        // morrer, ele ainda guarda as faixas e o estado de tocar da vez anterior. Começamos do zero.
        for (d in 0..1) {
            NativeEngine.nativeUnload(d)
            NativeEngine.nativeSetRate(d, 1f)
            NativeEngine.nativeSetFilter(d, 0.5f)
            NativeEngine.nativeSetFx(d, 0, 0.5f, 0.5f)
            NativeEngine.nativeClearLoop(d)
            NativeEngine.nativeSetKeyLock(d, false)
            NativeEngine.nativeSetHeadphoneCue(d, false)
            for (b in 0..2) NativeEngine.nativeSetEq(d, b, 0.5f)
        }
        startPolling()
        loadBuiltinPads(quiet = true)
    }

    /** Coloca nos 8 pads os sons prontos de DJ (buzina, sirene, laser, 808, palma, subida, descida, explosão). */
    fun loadBuiltinPads(quiet: Boolean = false) {
        viewModelScope.launch(Dispatchers.Default) {
            autoSamples.fill(false)
            val n = NativeEngine.nativeLoadBuiltinSamples()
            sentSpeed.fill(1f)
            for (i in 0 until 8) NativeEngine.nativeSetSampleSpeed(i, 1f)
            _pads.value = List(8) { i -> if (i < n) PadUi(label = BUILTIN_NAMES[i], loop = false, ready = true) else PadUi() }
            if (!quiet) say("Sons prontos nos pads: ${BUILTIN_NAMES.joinToString(", ")}.")
        }
    }

    /**
     * Chamado pela Activity em onStart (true) e onStop (false). Sem serviço em primeiro plano o Android
     * não garante áudio em segundo plano, então ao sair o app pausa os decks e fecha a saída de áudio.
     */
    fun onForeground(on: Boolean) {
        foreground = on
        stopJob?.cancel()
        if (on) {
            startAudio()
        } else {
            NativeEngine.nativePause(0)
            NativeEngine.nativePause(1)
            stopJob = viewModelScope.launch(Dispatchers.Default) {
                delay(150) // deixa a rampa de 4 ms da pausa terminar antes de fechar o fluxo
                if (!foreground) NativeEngine.nativeStop()
            }
        }
    }

    private fun startAudio() {
        // Abrir o fluxo exclusivo do Oboe pode demorar: fora da thread principal.
        viewModelScope.launch(Dispatchers.Default) {
            NativeEngine.nativeSetLatency(_latency.value)
            configureOutputNow()
            val ok = NativeEngine.nativeStart()
            if (ok) {
                NativeEngine.nativeSetHeadphoneLevel(_hpLevel.value)
                NativeEngine.nativeSetHeadphoneMix(_hpMix.value)
                NativeEngine.nativeSetMaster(_master.value)
                NativeEngine.nativeSetCrossfader(_crossfader.value)
                NativeEngine.nativeSetVolume(0, _volumes.value[0])
                NativeEngine.nativeSetVolume(1, _volumes.value[1])
                refreshAudioStatus()
            } else {
                _audioStatus.value = "Sem áudio"
                say("Não consegui abrir a saída de áudio do aparelho.")
            }
        }
    }

    private fun refreshAudioStatus() {
        val info = IntArray(8)
        NativeEngine.nativeStreamInfo(info)
        val bufferMs = if (info[0] > 0) info[2] * 1000f / info[0] else 0f
        val outs = router.devices.value
        val mainName = outs.firstOrNull { it.id == info[6] }?.label ?: "saída padrão do Android"
        _audioStatus.value = "%d Hz · buffer %.0f ms · %s".format(java.util.Locale.ROOT, info[0], bufferMs, mainName)
        val want = _outMode.value
        val got = info[5]
        val fone = when {
            want == 0 -> "Sem fone de pré-escuta na saída principal."
            got == 2 -> "Fone da controladora ativo: canais 1-2 som geral, 3-4 fone."
            got == 1 && want == 2 -> "A saída não abriu 4 canais; usando o modo dividido (esquerdo = fone, direito = som geral)."
            got == 1 -> "Modo dividido: o lado esquerdo leva o fone e o direito o som geral (mono)."
            else -> "Não consegui abrir a saída escolhida; voltei à saída padrão."
        }
        val mirror = when {
            _mirrorDevice.value == 0 -> ""
            info[7] == 1 -> " Segunda saída tocando (${if (_mirrorWhat.value == 1) "fone" else "som geral"}): ${outs.firstOrNull { it.id == _mirrorDevice.value }?.label ?: ""}."
            else -> " A segunda saída não abriu (ou é a mesma da principal)."
        }
        _outNote.value = fone + mirror
    }

    /** Saída principal: a escolhida; no automático, a controladora (USB) se estiver ligada, senão a do celular. */
    private fun resolveDevice(): Int {
        val list = router.devices.value
        val pick = _outDevice.value
        return list.firstOrNull { it.id == pick }?.id ?: list.firstOrNull { it.isUsb }?.id ?: 0
    }

    /** Modo do fone: o escolhido; no automático, 4 canais se a saída principal tiver 4 (DJ2GO2), senão sem fone. */
    private fun resolveMode(dev: Int): Int {
        val p = _outModePref.value
        if (p >= 0) return p
        val o = router.devices.value.firstOrNull { it.id == dev }
        return if (o != null && o.isUsb && o.channels >= 4) 2 else 0
    }

    private fun configureOutputNow() {
        val dev = resolveDevice()
        val mode = resolveMode(dev)
        _outMode.value = mode
        val mirror = _mirrorDevice.value.takeIf { m -> router.devices.value.any { it.id == m } } ?: 0
        NativeEngine.nativeConfigureOutput(mode, dev, mirror, _mirrorWhat.value)
    }

    /** Reaplica a saída (modo ou aparelho mudou, ou um aparelho entrou ou saiu). */
    private fun applyOutput() {
        viewModelScope.launch(Dispatchers.Default) {
            configureOutputNow()
            delay(300)
            if (foreground) refreshAudioStatus()
        }
    }

    fun setOutputMode(mode: Int) {
        _outModePref.value = mode.coerceIn(0, 2)
        outPrefs.edit().putInt("mode2", _outModePref.value).apply()
        applyOutput()
    }

    fun setOutputDevice(id: Int) {
        _outDevice.value = id
        outPrefs.edit().putInt("device2", id).apply()
        applyOutput()
    }

    /** Segunda saída tocando junto ([id] 0 = desligada); [what] 0 = som geral, 1 = fone (pré-escuta). */
    fun setMirror(id: Int, what: Int = _mirrorWhat.value) {
        _mirrorDevice.value = id
        _mirrorWhat.value = what
        outPrefs.edit().putInt("mirror", id).putInt("mirrorWhat", what).apply()
        applyOutput()
    }

    fun toggleKeyLock(deck: Int) {
        val on = !_decks.value[deck].keyLock
        setDeck(deck) { it.copy(keyLock = on) }
        NativeEngine.nativeSetKeyLock(deck, on)
    }

    fun setPadMode(deck: Int, mode: Int) {
        setDeck(deck) { it.copy(padMode = mode.coerceIn(0, 6), padsOpen = true, stemsOpen = false) }
    }

    fun togglePads(deck: Int) {
        setDeck(deck) { it.copy(padsOpen = !it.padsOpen, stemsOpen = false) }
    }

    fun toggleHeadphoneCue(deck: Int) {
        val on = !_decks.value[deck].cueOn
        setDeck(deck) { it.copy(cueOn = on) }
        NativeEngine.nativeSetHeadphoneCue(deck, on)
    }

    fun setHeadphoneLevel(v: Float) {
        _hpLevel.value = v
        NativeEngine.nativeSetHeadphoneLevel(v)
    }

    fun setHeadphoneMix(v: Float) {
        _hpMix.value = v
        NativeEngine.nativeSetHeadphoneMix(v)
    }

    /** Prato tocado: [velocity] em múltiplos da velocidade normal. */
    fun scratch(deck: Int, active: Boolean, velocity: Float) {
        if (active && slipFrom[deck] == null) slipBegin(deck)
        NativeEngine.nativeScratch(deck, active, velocity)
        if (!active) slipEnd(deck)
    }

    // ------------------------------------------------------------------ SLIP, REVERSO e CENSURA

    /** Onde a música estaria: posição e hora em que o desvio começou (só com SLIP ligado e tocando). */
    private val slipFrom = arrayOfNulls<Pair<Long, Long>>(2)

    private fun slipBegin(deck: Int) {
        val d = _decks.value[deck]
        if (!d.slip || !d.playing || slipFrom[deck] != null) return
        val st = LongArray(4)
        NativeEngine.nativeDeckState(deck, st)
        slipFrom[deck] = st[1] to android.os.SystemClock.elapsedRealtime()
    }

    private fun slipEnd(deck: Int) {
        val from = slipFrom[deck] ?: return
        slipFrom[deck] = null
        val d = _decks.value[deck]
        val elapsed = android.os.SystemClock.elapsedRealtime() - from.second
        val target = from.first + (elapsed / 1000.0 * NativeEngine.SAMPLE_RATE * d.rate).toLong()
        if (target in 0 until d.lengthFrames) NativeEngine.nativeSeek(deck, target)
    }

    fun toggleSlip(deck: Int) {
        val on = !_decks.value[deck].slip
        if (!on) slipFrom[deck] = null
        setDeck(deck) { it.copy(slip = on) }
        say(if (on) "SLIP ligado no deck ${deckName(deck)}: depois de scratch, loop, reverso ou censura a música volta onde estaria."
            else "SLIP desligado no deck ${deckName(deck)}.")
    }

    /** REVERSO: toca ao contrário até tocar de novo. Com SLIP, volta ao ponto onde estaria. */
    fun toggleReverse(deck: Int) {
        val d = _decks.value[deck]
        if (!d.loaded || d.loading) { say("Carregue uma música no deck ${deckName(deck)} primeiro."); return }
        if (d.reverse) {
            NativeEngine.nativeScratch(deck, false, 0f)
            setDeck(deck) { it.copy(reverse = false) }
            slipEnd(deck)
        } else {
            if (!d.playing) { say("REVERSO precisa do deck ${deckName(deck)} tocando."); return }
            slipBegin(deck)
            NativeEngine.nativeScratch(deck, true, -d.rate)
            setDeck(deck) { it.copy(reverse = true) }
        }
    }

    /** CENSURA: 2 batidas ao contrário e volta exatamente onde a música estaria (SLIP automático). */
    fun censor(deck: Int) {
        val d = _decks.value[deck]
        if (!d.playing) { say("CENSURA precisa do deck ${deckName(deck)} tocando."); return }
        if (d.reverse) return
        val beatMs = if (d.hasBpm) (60000.0 / d.playedBpm).toLong() else 500L
        val st = LongArray(4)
        NativeEngine.nativeDeckState(deck, st)
        val from = st[1]
        val t0 = android.os.SystemClock.elapsedRealtime()
        runFx(deck) {
            setDeck(deck) { it.copy(reverse = true) }
            NativeEngine.nativeScratch(deck, true, -d.rate)
            delay(beatMs * 2)
            NativeEngine.nativeScratch(deck, false, 0f)
            val elapsed = android.os.SystemClock.elapsedRealtime() - t0
            NativeEngine.nativeSeek(deck, from + (elapsed / 1000.0 * NativeEngine.SAMPLE_RATE * d.rate).toLong())
            setDeck(deck) { it.copy(reverse = false) }
        }
    }

    // ------------------------------------------------------------------ STEMS

    fun toggleStems(deck: Int) {
        setDeck(deck) { it.copy(stemsOpen = !it.stemsOpen, padsOpen = false) }
    }

    /** Ganho de um stem (0 voz, 1 bateria, 2 baixo, 3 melodia). */
    fun setStemGain(deck: Int, stem: Int, gain: Float) {
        if (stem !in 0..3) return
        val d = _decks.value[deck]
        if (!d.stemsReady) {
            say(
                when {
                    d.stemProgress >= 0f -> "Stems ainda separando (${(d.stemProgress * 100).toInt()}%)."
                    d.stemProgress < -1.5f -> "Stems indisponíveis nesta música (longa demais ou pouca memória)."
                    else -> "Carregue uma música para separar os stems."
                },
            )
            return
        }
        val g = gain.coerceIn(0f, 1f)
        setDeck(deck) { it.copy(stemGains = it.stemGains.mapIndexed { i, old -> if (i == stem) g else old }) }
        NativeEngine.nativeSetStemGain(deck, stem, g)
    }

    fun toggleStem(deck: Int, stem: Int) {
        val g = _decks.value[deck].stemGains.getOrNull(stem) ?: return
        setStemGain(deck, stem, if (g > 0.5f) 0f else 1f)
    }

    /** ACAPELLA (só voz), INSTRUMENTAL (sem voz) ou tudo de volta. */
    fun stemPreset(deck: Int, preset: Int) {
        val gains = when (preset) {
            1 -> listOf(1f, 0f, 0f, 0f)
            2 -> listOf(0f, 1f, 1f, 1f)
            3 -> listOf(0f, 1f, 0f, 0f)
            else -> listOf(1f, 1f, 1f, 1f)
        }
        if (!_decks.value[deck].stemsReady) { setStemGain(deck, 0, 1f); return }
        gains.forEachIndexed { i, g -> NativeEngine.nativeSetStemGain(deck, i, g) }
        setDeck(deck) { it.copy(stemGains = gains) }
    }

    /** Um deck separa de cada vez: dois ao mesmo tempo disputam o processador com a interface. */
    private val stemLock = kotlinx.coroutines.sync.Mutex()

    /**
     * Os stems ocupam 6 bytes por quadro (uma música de 5 min = ~86 MB). Só separa se couber com folga:
     * até [STEM_MAX_MINUTES] e sobrando pelo menos 300 MB de memória livre no aparelho depois.
     */
    private fun stemsFit(frames: Long): String? {
        if (frames > STEM_MAX_MINUTES * 60L * NativeEngine.SAMPLE_RATE) return "música com mais de $STEM_MAX_MINUTES min"
        val am = getApplication<Application>().getSystemService(android.content.Context.ACTIVITY_SERVICE) as android.app.ActivityManager
        val mi = android.app.ActivityManager.MemoryInfo()
        am.getMemoryInfo(mi)
        val need = frames * 6L
        return if (mi.lowMemory || mi.availMem - need < 300L * 1024 * 1024) "pouca memória livre no aparelho" else null
    }

    private suspend fun separateStems(deck: Int, handle: Long) = stemLock.withLock {
        val why = stemsFit(_decks.value[deck].lengthFrames)
        if (why != null) {
            setDeck(deck) { it.copy(stemProgress = -2f) }
            say("Stems desligados no deck ${deckName(deck)}: $why.")
            return@withLock
        }
        setDeck(deck) { it.copy(stemProgress = 0f) }
        val ok = coroutineScope {
            val poll = launch {
                while (isActive) {
                    delay(700)
                    // de 10 em 10%: menos redesenho da tela enquanto separa
                    val p = (Math.floor(NativeEngine.nativeStemProgress(deck) * 10.0) / 10.0).toFloat().coerceIn(0f, 0.9f)
                    setDeck(deck) { if (it.stemProgress in 0f..0.999f && it.stemProgress != p) it.copy(stemProgress = p) else it }
                }
            }
            val r = withContext(Dispatchers.Default) {
                android.os.Process.setThreadPriority(android.os.Process.THREAD_PRIORITY_BACKGROUND)
                NativeEngine.nativeSeparateStems(handle, deck)
            }
            poll.cancel()
            r
        }
        setDeck(deck) { it.copy(stemProgress = if (ok) 1f else -1f) }
        if (ok) say("Stems prontos no deck ${deckName(deck)}: voz, bateria, baixo e melodia.")
    }

    // ------------------------------------------------------------------ TOM, AUTO-GAIN e GRADE

    /** Muda o tom em semitons sem mudar o andamento (para casar o tom com o outro deck). */
    fun setKeyShift(deck: Int, semitones: Int, remember: Boolean = true) {
        val s = semitones.coerceIn(-12, 12)
        setDeck(deck) { it.copy(keyShift = s) }
        NativeEngine.nativeSetKeyShift(deck, s.toFloat())
        // lembra o tom escolhido para esta música (volta igual na próxima vez que carregar)
        val id = _decks.value[deck].trackId
        if (remember && id >= 0) keyPrefs.edit().apply { if (s == 0) remove("t$id") else putInt("t$id", s) }.apply()
    }

    private val keyPrefs = app.getSharedPreferences("tom_por_musica", android.content.Context.MODE_PRIVATE)

    fun shiftKey(deck: Int, delta: Int) = setKeyShift(deck, _decks.value[deck].keyShift + delta)

    /** Acerta o tom deste deck para combinar com o outro (menor deslocamento que deixa compatível na roda). */
    fun matchKey(deck: Int) {
        val d = _decks.value[deck]
        val other = _decks.value[1 - deck]
        val base = d.key?.let { if (d.keyLock) it else it.shifted(Camelot.semitonesFor(d.rate)) }
        val ref = other.shownKey
        if (base == null || ref == null) { say("Os dois decks precisam do tom detectado."); return }
        var best = 0
        var bestScore = Double.MAX_VALUE
        for (s in -6..6) {
            val sc = MixAdvisor.keyRelation(ref, base.shifted(s)).keyScore + kotlin.math.abs(s) * 0.05
            if (sc < bestScore) { bestScore = sc; best = s }
        }
        setKeyShift(deck, best)
        say("Tom do deck ${deckName(deck)} ${if (best == 0) "já combina" else "ajustado em ${if (best > 0) "+" else ""}$best semitons"}.")
    }

    private val _autoGain = MutableStateFlow(outPrefs.getBoolean("autoGain", true))
    val autoGain: StateFlow<Boolean> = _autoGain.asStateFlow()

    fun toggleAutoGain() {
        val on = !_autoGain.value
        _autoGain.value = on
        outPrefs.edit().putBoolean("autoGain", on).apply()
        for (d in 0..1) applyTrim(d)
        say(if (on) "AUTO-GAIN ligado: as músicas tocam com o mesmo volume." else "AUTO-GAIN desligado.")
    }

    private fun applyTrim(deck: Int) {
        val d = _decks.value[deck]
        val t = if (_autoGain.value && d.loudness < -1f) Math.pow(10.0, (TARGET_DB - d.loudness) / 20.0).toFloat().coerceIn(0.25f, 2.5f) else 1f
        NativeEngine.nativeSetTrim(deck, t)
        setDeck(deck) { it.copy(trim = t) }
    }

    /** Move a grade de batidas [dir] passos de 5 ms (acerta onde cai a batida). Salva na biblioteca. */
    fun nudgeGrid(deck: Int, dir: Int) {
        val d = _decks.value[deck]
        if (!d.hasBpm || d.trackId < 0) { say("A grade precisa do andamento detectado."); return }
        val step = NativeEngine.SAMPLE_RATE / 200
        val beat = (60.0 * NativeEngine.SAMPLE_RATE / d.bpm).toLong().coerceAtLeast(1)
        val bar = beat * 4    // mantém o "1" do compasso no lugar
        val nf = ((d.firstBeatFrame + dir * step) % bar + bar) % bar
        setDeck(deck) { it.copy(firstBeatFrame = nf) }
        saveGrid(d.trackId, d.bpm, nf)
    }

    /** Ajusta a grade para que a batida 0 seja o "1" do compasso (detectado pelo bumbo e pelas entradas). */
    private fun withDownbeat(a: Analysis, h: Long): Analysis {
        if (a.bpm <= 0.0) return a
        return try {
            val beat = 60.0 * NativeEngine.SAMPLE_RATE / a.bpm
            val o = app.djfusion.harmony.TrackShape.downbeatOffset(NativeEngine.nativeTrackPeaks(h), a.firstBeatFrame, beat)
            if (o == 0) a else a.copy(firstBeatFrame = (a.firstBeatFrame + o * beat).toLong())
        } catch (_: Throwable) { a }
    }

    /** Marca o "1" (início do compasso e da frase de 16) exatamente onde a música está agora. */
    fun downbeatHere(deck: Int) {
        val d = _decks.value[deck]
        if (!d.hasBpm || d.trackId < 0) { say("A grade precisa do andamento detectado."); return }
        val pos = posOf(deck)
        val phrase = 16.0 * 60.0 * NativeEngine.SAMPLE_RATE / d.bpm
        val nf = (pos - Math.floor(pos / phrase) * phrase).toLong()
        setDeck(deck) { it.copy(firstBeatFrame = nf) }
        saveGrid(d.trackId, d.bpm, nf)
        say("Deck ${deckName(deck)}: o 1 do compasso agora está aqui.")
    }

    /** Ajuste fino do andamento da grade (BPM), mantendo a batida que está tocando no lugar. */
    fun adjustBpm(deck: Int, delta: Double) {
        val d = _decks.value[deck]
        if (!d.hasBpm || d.trackId < 0) { say("A grade precisa do andamento detectado."); return }
        val nb = (d.bpm + delta).coerceIn(40.0, 250.0)
        val pos = posOf(deck).toDouble()
        val oldBeat = 60.0 * NativeEngine.SAMPLE_RATE / d.bpm
        val k = Math.round((pos - d.firstBeatFrame) / oldBeat)
        val anchor = d.firstBeatFrame + k * oldBeat              // batida mais perto de agora fica parada
        val newBeat = 60.0 * NativeEngine.SAMPLE_RATE / nb
        val bar = newBeat * 4
        val nf = ((anchor - (k.mod(4L)) * newBeat) % bar + bar) % bar
        setDeck(deck) { it.copy(bpm = nb, firstBeatFrame = nf.toLong()) }
        saveGrid(d.trackId, nb, nf.toLong())
        pushFx(deck)
    }

    private val _jumpSize = MutableStateFlow(outPrefs.getInt("jump", 4).let { if (it in JUMP_SIZES) it else 4 })
    /** Tamanho do salto de batida (1 a 32). */
    val jumpSize: StateFlow<Int> = _jumpSize.asStateFlow()
    fun setJumpSize(n: Int) {
        if (n !in JUMP_SIZES) return
        _jumpSize.value = n
        outPrefs.edit().putInt("jump", n).apply()
    }

    /** Dobra ou corta pela metade o andamento detectado (erro comum de detecção). */
    fun scaleBpm(deck: Int, factor: Double) {
        val d = _decks.value[deck]
        if (d.bpm <= 0 || d.trackId < 0) return
        val nb = d.bpm * factor
        if (nb < 50 || nb > 220) { say("Andamento fora da faixa (50 a 220 BPM)."); return }
        setDeck(deck) { it.copy(bpm = nb, bpmConfidence = kotlin.math.max(it.bpmConfidence, 1f)) }
        saveGrid(d.trackId, nb, d.firstBeatFrame)
        pushFx(deck)
        say(String.format(java.util.Locale.ROOT, "Andamento do deck %s: %.1f BPM.", deckName(deck), nb))
    }

    private fun saveGrid(id: Long, bpm: Double, first: Long) {
        viewModelScope.launch(Dispatchers.IO) {
            val a = db.analysis(id) ?: return@launch
            db.saveAnalysis(id, a.copy(bpm = bpm, firstBeatFrame = first, confidence = kotlin.math.max(a.confidence, 1f)))
        }
    }

    private fun startPolling() {
        viewModelScope.launch {
            val buf = LongArray(4)
            var tick = 0
            while (isActive) {
                if (!foreground) {
                    delay(250)
                    continue
                }
                val states = ArrayList<LongArray>(2)
                val lives = ArrayList<DeckLive>(2)
                for (d in 0..1) {
                    NativeEngine.nativeDeckState(d, buf)
                    states.add(buf.copyOf())
                    lives.add(DeckLive(buf[1], buf[2], NativeEngine.nativeDeckPeak(d)))
                }
                _live.value = LiveUi(lives, NativeEngine.nativeMasterPeak())
                _decks.update { list ->
                    list.mapIndexed { i, d ->
                        val flags = states[i][0]
                        val playing = (flags and 2L) != 0L
                        val loaded = (flags and 1L) != 0L
                        if (d.playing == playing && d.loaded == loaded) d else d.copy(playing = playing, loaded = loaded)
                    }
                }
                val mask = NativeEngine.nativeSamplerMask()
                val padsNow = _pads.value
                if (padsNow.indices.any { ((mask shr it) and 1 == 1) != padsNow[it].playing }) {
                    _pads.value = padsNow.mapIndexed { i, p -> p.copy(playing = (mask shr i) and 1 == 1) }
                }
                if (tick % 6 == 0) syncPadSpeeds()
                phaseLock()
                if (tick % 15 == 7) checkOnAir()
                if (tick > 10 && tick % 4 == 1) syncLeds()   // LEDs da controladora (depois de tudo iniciado)
                if (++tick % 30 == 0) launch(Dispatchers.Default) { NativeEngine.nativeCollectGarbage() }
                delay(33)
            }
        }
    }

    // ----------------------------------------------------------------- mensagens

    fun say(text: String) {
        _message.value = text
    }

    fun clearMessage(text: String) {
        _message.update { if (it == text) null else it }
    }

    // ------------------------------------------------------------------- decks

    fun togglePlay(deck: Int) {
        if (_decks.value[deck].loading) {
            say("Espere a música terminar de carregar no deck ${deckName(deck)}.")
            return
        }
        val st = LongArray(4)
        NativeEngine.nativeDeckState(deck, st)
        if ((st[0] and 1L) == 0L) {
            say("Deck ${deckName(deck)} sem música. Abra a Biblioteca e toque em ${deckName(deck)}.")
            return
        }
        // PLAY com o CUE apertado: a prévia vira reprodução normal (como no CDJ)
        if (cueHeld[deck]) { cueHeld[deck] = false; return }
        if ((st[0] and 2L) != 0L) NativeEngine.nativePause(deck) else NativeEngine.nativePlay(deck)
    }

    /** CUE segurado com o deck parado (prévia): solta = volta ao ponto e para; PLAY durante a prévia continua tocando. */
    private val cueHeld = BooleanArray(2)

    /**
     * CUE como no CDJ/Serato. Tocando: volta ao ponto de CUE e para. Parado: marca o CUE aqui (preso na batida
     * com QUANTIZE) e toca enquanto o botão estiver apertado.
     */
    fun cueDown(deck: Int) {
        val d = _decks.value[deck]
        if (!d.loaded || d.loading) { say("Carregue uma música no deck ${deckName(deck)} primeiro."); return }
        val st = LongArray(4)
        NativeEngine.nativeDeckState(deck, st)
        val playing = (st[0] and 2L) != 0L
        if (playing && !cueHeld[deck]) { NativeEngine.nativeCue(deck); return }
        if (!playing) {
            val snapped = snapToBeat(d, st[1])
            if (snapped != st[1] && kotlin.math.abs(snapped - st[1]) < NativeEngine.SAMPLE_RATE / 4) {
                NativeEngine.nativeSeek(deck, snapped)
                viewModelScope.launch { delay(25); NativeEngine.nativeCue(deck); NativeEngine.nativePlay(deck) }
                cueHeld[deck] = true
                return
            }
            NativeEngine.nativeCue(deck)
            NativeEngine.nativePlay(deck)
            cueHeld[deck] = true
        }
    }

    fun cueUp(deck: Int) {
        if (!cueHeld[deck]) return
        cueHeld[deck] = false
        viewModelScope.launch {
            delay(30)   // deixa a prévia começar antes de voltar (toque rápido = só marca o CUE)
            NativeEngine.nativeCue(deck)
        }
    }

    fun cue(deck: Int) {
        cueDown(deck)
        cueUp(deck)
    }

    fun seekFraction(deck: Int, fraction: Float) {
        val length = _decks.value[deck].lengthFrames
        if (length <= 0) return
        NativeEngine.nativeSeek(deck, (fraction.coerceIn(0f, 1f) * length).toLong())
    }

    fun setVolume(deck: Int, v: Float) {
        _volumes.update { list -> list.mapIndexed { i, old -> if (i == deck) v else old } }
        NativeEngine.nativeSetVolume(deck, v)
    }

    fun setCrossfader(x: Float) {
        _crossfader.value = x
        NativeEngine.nativeSetCrossfader(x)
    }

    fun setMaster(v: Float) {
        _master.value = v
        NativeEngine.nativeSetMaster(v)
    }

    // ------------------------------------------------- equalizador, filtro e pitch

    private fun snapCenter(v: Float): Float = if (kotlin.math.abs(v - 0.5f) < 0.03f) 0.5f else v.coerceIn(0f, 1f)

    fun setEq(deck: Int, band: Int, v: Float) {
        val x = snapCenter(v)
        setDeck(deck) { d -> d.copy(eq = d.eq.mapIndexed { i, old -> if (i == band) x else old }) }
        NativeEngine.nativeSetEq(deck, band, x)
    }

    fun setFilter(deck: Int, v: Float) {
        val x = snapCenter(v)
        setDeck(deck) { it.copy(filter = x) }
        NativeEngine.nativeSetFilter(deck, x)
    }

    /** Posição do fader de pitch (0 a 1, 0,5 = velocidade normal) para a velocidade. */
    fun setPitchFader(deck: Int, fader: Float) {
        val f = if (kotlin.math.abs(fader - 0.5f) < 0.012f) 0.5f else fader.coerceIn(0f, 1f)
        val d = _decks.value[deck]
        if (d.syncLock) setDeck(deck) { it.copy(syncLock = false) }   // mexer no pitch solta o SYNC travado
        applyRate(deck, 1f + (f - 0.5f) * 2f * d.pitchRange / 100f)
    }

    /** Posição do fader (0..1) para a velocidade atual na faixa do deck. */
    fun pitchFaderValue(d: DeckUi): Float = ((d.rate - 1f) / (2f * d.pitchRange / 100f) + 0.5f).coerceIn(0f, 1f)

    /** Faixa padrão do pitch (AJUSTES): vale para os dois decks agora e nas próximas aberturas. */
    fun setDefaultPitch(pct: Int) {
        if (pct !in PITCH_RANGES) return
        _defaultPitch.value = pct
        outPrefs.edit().putInt("pitchRange", pct).apply()
        for (d in 0..1) setPitchRange(d, pct, quiet = true)
        say("Faixa do pitch: ±$pct% nos dois decks.")
    }

    /** Troca a faixa do pitch: ±8, ±16, ±25, ±50, ±100 % (WIDE). */
    fun cyclePitchRange(deck: Int) {
        val opts = PITCH_RANGES
        val cur = _decks.value[deck].pitchRange
        setPitchRange(deck, opts[(opts.indexOf(cur) + 1).mod(opts.size)])
    }

    fun setPitchRange(deck: Int, pct: Int, quiet: Boolean = false) {
        val r = pct.coerceIn(4, 100)
        setDeck(deck) { it.copy(pitchRange = r) }
        val d = _decks.value[deck]
        val lim = r / 100f
        if (kotlin.math.abs(d.rate - 1f) > lim) applyRate(deck, (d.rate).coerceIn(1f - lim, 1f + lim))
        if (!quiet) say("Pitch do deck ${deckName(deck)}: ±$r%" + if (r == 100) " (WIDE: até parar ou dobrar)." else ".")
    }

    fun resetPitch(deck: Int) {
        setDeck(deck) { it.copy(syncLock = false) }
        applyRate(deck, 1f)
    }

    private val bending = booleanArrayOf(false, false)

    /** Empurra (dir +1) ou segura (dir -1) a música enquanto o botão está apertado, como no toca-discos. */
    /** Empurrar/segurar pela borda do prato: a velocidade do giro acelera ou freia a música só enquanto o dedo gira. */
    fun jogBend(deck: Int, active: Boolean, vel: Float) {
        bending[deck] = active
        val d = _decks.value[deck]
        val bend = if (active) (vel * 0.12f * jog.bendGain).coerceIn(-0.3f, 0.3f) else 0f
        NativeEngine.nativeSetRate(deck, d.rate * (1f + bend))
    }

    private val _waveZoom = MutableStateFlow(outPrefs.getInt("zoom", 2).coerceIn(0, WAVE_ZOOMS.size - 1))
    /** Zoom das ondas: índice em [WAVE_ZOOMS] (segundos visíveis). Toque duplo na onda troca. */
    val waveZoom: StateFlow<Int> = _waveZoom.asStateFlow()
    fun cycleWaveZoom() {
        _waveZoom.value = (_waveZoom.value + 1) % WAVE_ZOOMS.size
        outPrefs.edit().putInt("zoom", _waveZoom.value).apply()
        say("Zoom das ondas: ${WAVE_ZOOMS[_waveZoom.value].toInt()} s na tela.")
    }

    private val _portrait = MutableStateFlow(outPrefs.getBoolean("portrait", false))
    /** Permite usar o celular em pé (tela compacta de 2 decks). */
    val portrait: StateFlow<Boolean> = _portrait.asStateFlow()
    fun setPortrait(on: Boolean, activity: android.app.Activity?) {
        _portrait.value = on
        outPrefs.edit().putBoolean("portrait", on).apply()
        activity?.requestedOrientation = if (on) android.content.pm.ActivityInfo.SCREEN_ORIENTATION_FULL_USER
        else android.content.pm.ActivityInfo.SCREEN_ORIENTATION_SENSOR_LANDSCAPE
        say(if (on) "Modo retrato liberado: gire o celular para usar em pé." else "Tela sempre deitada (paisagem).")
    }

    private val _vinyl = MutableStateFlow(outPrefs.getBoolean("vinyl", true))
    /** Modo VINIL: tocar no disco faz scratch. Desligado, o prato só empurra/segura (como CDJ sem vinil). */
    val vinyl: StateFlow<Boolean> = _vinyl.asStateFlow()
    fun toggleVinyl() {
        _vinyl.value = !_vinyl.value
        outPrefs.edit().putBoolean("vinyl", _vinyl.value).apply()
        say(if (_vinyl.value) "Modo VINIL: tocar no disco faz scratch; a borda empurra." else "Modo VINIL desligado: o prato só empurra e segura a música.")
    }

    fun pitchBend(deck: Int, dir: Int, on: Boolean) {
        bending[deck] = on
        val d = _decks.value[deck]
        NativeEngine.nativeSetRate(deck, if (on) d.rate * (1f + 0.04f * dir) else d.rate)
    }

    // ------------------------------------------------------------------ SYNC travado (trava de fase)

    private val lockSent = floatArrayOf(0f, 0f)

    /** Mantém os decks com SYNC travado no andamento e na fase do outro (chamado ~30 vezes por segundo). */
    private fun phaseLock() {
        val ds = _decks.value
        for (d in 0..1) {
            val me = ds[d]
            if (!me.syncLock) continue
            val o = ds[1 - d]
            if (!me.playing || !o.playing || !me.hasBpm || !o.hasBpm || me.reverse || bending[d] || slipFrom[d] != null || me.rollBeats > 0f) continue
            // andamento: segue o outro (com dobro/metade)
            var k = 1.0
            var best = Double.MAX_VALUE
            for (m in doubleArrayOf(1.0, 2.0, 0.5)) {
                val e = kotlin.math.abs(o.playedBpm / (me.bpm * m) - 1.0)
                if (e < best) { best = e; k = m }
            }
            val target = (o.playedBpm / (me.bpm * k)).toFloat()
            if (target !in 0.5f..1.5f) continue
            if (kotlin.math.abs(target - me.rate) > 1e-4f) setDeck(d) { it.copy(rate = target) }
            // fase: diferença em batidas do outro deck, corrigida em ~1 s com um leve ajuste de velocidade
            val pm = _live.value.decks[d].positionFrames.toDouble()
            val po = _live.value.decks[1 - d].positionFrames.toDouble()
            val sr = NativeEngine.SAMPLE_RATE.toDouble()
            val beatsMe = (pm - me.firstBeatFrame) / (60.0 * sr / me.bpm) * k
            val beatsO = (po - o.firstBeatFrame) / (60.0 * sr / o.bpm)
            var err = (beatsO - Math.floor(beatsO)) - (beatsMe - Math.floor(beatsMe))
            if (err > 0.5) err -= 1.0 else if (err < -0.5) err += 1.0
            val beatSec = 60.0 / o.playedBpm
            // ganho 1,2 por segundo (constante de tempo ~0,8 s); até 3,5% de empurrão para desvios grandes, como no Serato
            val adj = if (kotlin.math.abs(err) < 0.004) 0.0 else (err * beatSec * 1.2).coerceIn(-0.035, 0.035)
            val send = (target * (1.0 + adj)).toFloat()
            if (kotlin.math.abs(send - lockSent[d]) > 0.0002f) {
                lockSent[d] = send
                NativeEngine.nativeSetRate(d, send)
            }
        }
    }

    /** Define a grade de batidas do deck (andamento e posição da batida 1) e salva na biblioteca. */
    fun setBeatGrid(deck: Int, bpm: Double, firstBeat: Long) {
        val d = _decks.value[deck]
        if (d.trackId < 0 || bpm !in 30.0..300.0) return
        setDeck(deck) { it.copy(bpm = bpm, firstBeatFrame = firstBeat.coerceAtLeast(0L), bpmConfidence = kotlin.math.max(it.bpmConfidence, 1f)) }
        saveGrid(d.trackId, bpm, firstBeat.coerceAtLeast(0L))
        pushFx(deck)
    }

    // ------------------------------------------------------------------ TAP (andamento na mão)

    private val taps = arrayOf(ArrayList<Long>(), ArrayList<Long>())

    /**
     * TAP: toque no ritmo da música. Com 4 toques ou mais, o andamento passa a ser a média dos intervalos e a
     * batida 1 fica no último toque (corrige faixas em que a detecção errou). Pausa de 2 s recomeça a contagem.
     */
    fun tapBpm(deck: Int) {
        val d = _decks.value[deck]
        if (!d.loaded || d.trackId < 0) return
        val now = android.os.SystemClock.elapsedRealtime()
        val t = taps[deck]
        if (t.isNotEmpty() && now - t.last() > 2000) t.clear()
        t.add(now)
        if (t.size > 12) t.removeAt(0)
        if (t.size < 4) { say("TAP: ${t.size} de 4 toques no ritmo…"); return }
        val avgMs = (t.last() - t.first()).toDouble() / (t.size - 1)
        val played = 60000.0 / avgMs
        val trackBpm = played / d.rate
        if (trackBpm !in 50.0..220.0) { say("TAP fora da faixa (50 a 220 BPM)."); return }
        val pos = posOf(deck)
        val beat = (60.0 * NativeEngine.SAMPLE_RATE / trackBpm).toLong().coerceAtLeast(1)
        val first = ((pos % beat) + beat) % beat
        setDeck(deck) { it.copy(bpm = trackBpm, firstBeatFrame = first, bpmConfidence = 1f) }
        saveGrid(d.trackId, trackBpm, first)
        pushFx(deck)
        say(String.format(java.util.Locale.ROOT, "TAP: %.2f BPM no deck %s (%d toques).", trackBpm, deckName(deck), t.size))
    }

    // ------------------------------------------------------------------ região do loop (para desenhar na onda)

    private val _loopRegion = MutableStateFlow<List<Pair<Long, Long>?>>(listOf(null, null))
    val loopRegion: StateFlow<List<Pair<Long, Long>?>> = _loopRegion.asStateFlow()

    private fun setLoopNative(deck: Int, a: Long, b: Long) {
        NativeEngine.nativeSetLoop(deck, a, b)
        _loopRegion.update { l -> l.mapIndexed { i, r -> if (i == deck) a to b else r } }
    }

    private fun clearLoopNative(deck: Int) {
        NativeEngine.nativeClearLoop(deck)
        _loopRegion.update { l -> l.mapIndexed { i, r -> if (i == deck) null else r } }
    }

    // ------------------------------------------------------------------ QUANTIZE, LATÊNCIA, LISTA FIXA

    private val _quantize = MutableStateFlow(outPrefs.getBoolean("quantize", true))
    /** QUANTIZE: hot cues e loops caem na batida; pulos mantêm o ritmo. */
    val quantize: StateFlow<Boolean> = _quantize.asStateFlow()
    fun toggleQuantize() {
        _quantize.value = !_quantize.value
        outPrefs.edit().putBoolean("quantize", _quantize.value).apply()
        say(if (_quantize.value) "QUANTIZE ligado: cues e loops caem na batida." else "QUANTIZE desligado: cues e loops exatamente onde tocar.")
    }

    /** Batida mais próxima (com QUANTIZE ligado e andamento detectado); senão a própria posição. */
    private fun snapToBeat(d: DeckUi, pos: Long): Long {
        if (!_quantize.value || !d.hasBpm) return pos
        val beat = 60.0 * NativeEngine.SAMPLE_RATE / d.bpm
        val k = Math.round((pos - d.firstBeatFrame) / beat)
        return (d.firstBeatFrame + k * beat).toLong().coerceIn(0L, (d.lengthFrames - 1).coerceAtLeast(0L))
    }

    private val _latency = MutableStateFlow(outPrefs.getInt("latency", 1).coerceIn(0, 2))
    /** Latência da saída: 0 baixa, 1 normal, 2 segura. */
    val latency: StateFlow<Int> = _latency.asStateFlow()
    fun setLatency(m: Int) {
        _latency.value = m.coerceIn(0, 2)
        outPrefs.edit().putInt("latency", _latency.value).apply()
        viewModelScope.launch(Dispatchers.Default) {
            NativeEngine.nativeSetLatency(_latency.value)
            delay(300)
            refreshAudioStatus()
        }
    }

    private val _browserDock = MutableStateFlow(outPrefs.getBoolean("dock", false))
    /** Lista de músicas fixa embaixo dos decks (como no VirtualDJ). */
    val browserDock: StateFlow<Boolean> = _browserDock.asStateFlow()
    fun toggleBrowserDock() {
        _browserDock.value = !_browserDock.value
        outPrefs.edit().putBoolean("dock", _browserDock.value).apply()
    }

    /** Liga a trava de fase sem mensagem (usado pelo AUTO DJ durante a mixagem). */
    fun setSyncLock(deck: Int, on: Boolean) {
        setDeck(deck) { it.copy(syncLock = on) }
        lockSent[deck] = 0f
        if (!on) NativeEngine.nativeSetRate(deck, _decks.value[deck].rate)
    }

    /** Botão SYNC: alinha e trava; tocado de novo, destrava. */
    fun syncButton(deck: Int) {
        if (_decks.value[deck].syncLock) {
            setSyncLock(deck, false)
            say("SYNC destravado no deck ${deckName(deck)}.")
            return
        }
        if (sync(deck)) {
            setSyncLock(deck, true)
            say("SYNC travado no deck ${deckName(deck)}: segue o andamento e a batida do outro deck. Toque de novo para soltar.")
        }
    }

    // ------------------------------------------------------------------ ROLL (repetição de batida)

    private val rollFrom = arrayOfNulls<Pair<Long, Long>>(2)

    /** ROLL: repete o pedaço de [beats] batidas enquanto ligado; ao soltar, a música volta onde estaria. */
    fun roll(deck: Int, beats: Float) {
        val d = _decks.value[deck]
        if (!d.loaded || d.loading) { say("Carregue uma música no deck ${deckName(deck)} primeiro."); return }
        if (d.rollBeats == beats || (beats <= 0f && d.rollBeats > 0f)) {
            clearLoopNative(deck)
            val from = rollFrom[deck]
            rollFrom[deck] = null
            if (from != null) {
                val elapsed = android.os.SystemClock.elapsedRealtime() - from.second
                val target = from.first + (elapsed / 1000.0 * NativeEngine.SAMPLE_RATE * d.rate).toLong()
                if (target in 0 until d.lengthFrames) NativeEngine.nativeSeek(deck, target)
            }
            setDeck(deck) { it.copy(rollBeats = 0f, loopBeats = 0) }
            return
        }
        if (!d.hasBpm || !d.playing) { say("ROLL precisa do deck ${deckName(deck)} tocando com andamento detectado."); return }
        val pos = posOf(deck)
        if (rollFrom[deck] == null) rollFrom[deck] = pos to android.os.SystemClock.elapsedRealtime()
        val len = 60.0 * NativeEngine.SAMPLE_RATE / d.bpm * beats
        val first = d.firstBeatFrame.toDouble()
        val start = first + Math.floor((pos - first) / len) * len
        setLoopNative(deck, start.toLong().coerceAtLeast(0L), (start + len).toLong())
        setDeck(deck) { it.copy(rollBeats = beats, loopBeats = -2) }
    }

    /** Divisão de batida dos efeitos de ritmo. */
    fun setFxBeats(deck: Int, beats: Float) {
        setDeck(deck) { it.copy(fxBeats = beats.coerceIn(0.125f, 4f)) }
        pushFx(deck)
    }

    /** Velocidade exata do deck (usado pelo AUTO DJ). */
    fun setRateExact(deck: Int, rate: Float) = applyRate(deck, rate.coerceIn(0.5f, 2f))

    /** Liga ou desliga o key-lock sem alternar. */
    fun setKeyLock(deck: Int, on: Boolean) {
        if (_decks.value[deck].keyLock == on) return
        toggleKeyLock(deck)
    }

    private fun applyRate(deck: Int, rate: Float) {
        setDeck(deck) { it.copy(rate = rate) }
        NativeEngine.nativeSetRate(deck, rate)
        pushFx(deck)
    }

    /** Liga o efeito [type] (toque de novo no mesmo para desligar). */
    fun setFx(deck: Int, type: Int) {
        val cur = _decks.value[deck].fxType
        setDeck(deck) { it.copy(fxType = if (cur == type) 0 else type) }
        pushFx(deck)
    }

    fun setFxAmount(deck: Int, v: Float) {
        setDeck(deck) { it.copy(fxAmount = v.coerceIn(0f, 1f)) }
        pushFx(deck)
    }

    /** Reenvia ao motor o efeito escolhido na tela (depois que o AUTO DJ usou o eco na transição). */
    fun restoreFx(deck: Int) = pushFx(deck)

    /** Envia o efeito ao motor; o eco acompanha a batida do que está tocando. */
    private fun pushFx(deck: Int) {
        val d = _decks.value[deck]
        // o motor usa 3/4 do valor como atraso do eco: escala para o eco cair na divisão escolhida
        val beat = (if (d.hasBpm) (60.0 / d.playedBpm).toFloat() else 0.5f) * d.fxBeats / 0.75f
        NativeEngine.nativeSetFx(deck, d.fxType, d.fxAmount, beat.coerceIn(0.06f, 5f))
    }

    private fun posMod(a: Double, m: Double): Double = ((a % m) + m) % m

    /**
     * SYNC: iguala o andamento tocado deste deck ao do outro e, se o outro está tocando, alinha também a batida.
     * Só funciona com andamento detectado nos dois. Não é um SYNC contínuo: se o andamento oscilar, refaça.
     */
    fun sync(deck: Int): Boolean {
        val me = _decks.value[deck]
        val other = _decks.value[1 - deck]
        val name = deckName(deck)
        if (!me.loaded || !other.loaded) { say("SYNC precisa de música nos dois decks."); return false }
        if (!me.hasBpm || !other.hasBpm) { say("SYNC precisa do andamento detectado nos dois decks."); return false }
        val targetBpm = other.playedBpm
        var factor = 1.0
        var best = Double.MAX_VALUE
        for (k in doubleArrayOf(1.0, 2.0, 0.5)) {
            val r = targetBpm / (me.bpm * k)
            if (r in 0.5..1.5 && kotlin.math.abs(r - 1.0) < best) {
                best = kotlin.math.abs(r - 1.0)
                factor = k
            }
        }
        if (best == Double.MAX_VALUE) {
            say("Andamentos muito diferentes (%.1f e %.1f BPM). Ajuste o pitch à mão.".format(java.util.Locale.ROOT, me.bpm, targetBpm))
            return false
        }
        val newRate = (targetBpm / (me.bpm * factor)).toFloat()
        // se passar da faixa do fader, abre a faixa até caber
        val need = kotlin.math.abs(newRate - 1f) * 100f
        if (need > me.pitchRange) PITCH_RANGES.firstOrNull { it >= need }?.let { r -> setDeck(deck) { it.copy(pitchRange = r) } }
        applyRate(deck, newRate)
        var aligned = false
        if (factor == 1.0 && other.playing) {
            val a = LongArray(4); val b = LongArray(4)
            NativeEngine.nativeDeckState(deck, a); NativeEngine.nativeDeckState(1 - deck, b)
            val sr = NativeEngine.SAMPLE_RATE.toDouble()
            val otherBeat = 60.0 * sr / other.bpm
            val myBeat = 60.0 * sr / me.bpm
            val phase = posMod(b[1] - other.firstBeatFrame.toDouble(), otherBeat) / otherBeat
            val cur = posMod(a[1] - me.firstBeatFrame.toDouble(), myBeat)
            var delta = phase * myBeat - cur
            if (delta > myBeat / 2) delta -= myBeat else if (delta < -myBeat / 2) delta += myBeat
            val target = (a[1] + delta).toLong().coerceIn(0L, (me.lengthFrames - 1).coerceAtLeast(0L))
            NativeEngine.nativeSeek(deck, target)
            aligned = true
        }
        say("Deck $name em %.1f BPM%s.".format(java.util.Locale.ROOT, targetBpm, if (aligned) ", batida alinhada" else ""))
        return true
    }

    // ------------------------------------------------------------- loops e hot cues

    fun toggleLoop(deck: Int, beats: Int) {
        val d = _decks.value[deck]
        if (!d.loaded || d.loading) { say("Carregue uma música no deck ${deckName(deck)} primeiro."); return }
        if (d.loopBeats == beats) {
            clearLoopNative(deck)
            setDeck(deck) { it.copy(loopBeats = 0) }
            slipEnd(deck)
            return
        }
        if (!d.hasBpm) { say("Loop por batidas precisa do andamento detectado."); return }
        val st = LongArray(4)
        NativeEngine.nativeDeckState(deck, st)
        val beat = 60.0 * NativeEngine.SAMPLE_RATE / d.bpm
        val first = d.firstBeatFrame.toDouble()
        val start = kotlin.math.max(0.0, first + kotlin.math.floor((st[1] - first) / beat) * beat)
        val end = start + beats * beat
        if (end > d.lengthFrames) { say("Perto demais do fim da música para esse loop."); return }
        if (d.loopBeats == 0) slipBegin(deck)
        setLoopNative(deck, start.toLong(), end.toLong())
        setDeck(deck) { it.copy(loopBeats = beats) }
    }

    /** Toque numa hot cue vazia grava a posição atual. Numa gravada, vai até ela e toca. */
    fun hotcue(deck: Int, slot: Int) {
        val d = _decks.value[deck]
        if (slot !in 0..7) return
        if (!d.loaded || d.loading || d.trackId < 0) { say("Carregue uma música no deck ${deckName(deck)} primeiro."); return }
        val saved = d.hotcues[slot]
        if (saved < 0) {
            val st = LongArray(4)
            NativeEngine.nativeDeckState(deck, st)
            val frame = snapToBeat(d, st[1])           // QUANTIZE: a cue cai exatamente na batida
            setDeck(deck) { it.copy(hotcues = it.hotcues.mapIndexed { i, old -> if (i == slot) frame else old }) }
            val id = d.trackId
            viewModelScope.launch(Dispatchers.IO) { db.setHotcue(id, slot, frame) }
        } else {
            // QUANTIZE tocando: pula mantendo a posição dentro da batida (o ritmo não tropeça)
            val target = if (_quantize.value && d.playing && d.hasBpm) {
                val beat = 60.0 * NativeEngine.SAMPLE_RATE / d.bpm
                val ph = posMod(posOf(deck) - d.firstBeatFrame.toDouble(), beat)
                val cueBeat = Math.round((saved - d.firstBeatFrame) / beat)
                (d.firstBeatFrame + cueBeat * beat + ph).toLong().coerceIn(0L, (d.lengthFrames - 1).coerceAtLeast(0L))
            } else saved
            NativeEngine.nativeSeek(deck, target)
            if (!d.playing) NativeEngine.nativePlay(deck)
        }
    }

    fun clearHotcue(deck: Int, slot: Int) {
        val d = _decks.value[deck]
        if (d.trackId < 0 || slot !in 0..7 || d.hotcues[slot] < 0) return
        setDeck(deck) { it.copy(hotcues = it.hotcues.mapIndexed { i, old -> if (i == slot) -1L else old }) }
        val id = d.trackId
        viewModelScope.launch(Dispatchers.IO) { db.deleteHotcue(id, slot) }
        say("Hot cue ${slot + 1} apagada.")
    }

    // ------------------------------------------------------------ carregar faixa

    fun loadTrack(deck: Int, row: TrackRow) {
        val current = _decks.value[deck]
        if (current.playing) {
            say("Pause o deck ${deckName(deck)} antes de carregar outra música.")
            return
        }
        NativeEngine.nativeCancelStems(deck)
        loopInAt[deck] = -1; loopOutAt[deck] = -1; pubLoop()
        _loopRegion.update { l -> l.mapIndexed { i, r -> if (i == deck) null else r } }
        rollFrom[deck] = null; lockSent[deck] = 0f
        decodeJobs[deck]?.cancel()
        slipFrom[deck] = null
        setDeck(deck) {
            it.copy(loading = true, loadProgress = 0f, title = row.title, artist = row.artist, stemProgress = -1f,
                stemGains = listOf(1f, 1f, 1f, 1f), reverse = false, keyShift = 0, syncLock = false, rollBeats = 0f, analyzing = false)
        }
        say("Carregando no deck ${deckName(deck)}…")
        decodeJobs[deck] = viewModelScope.launch {
            val result = TrackDecoder.decode(getApplication(), Uri.parse(row.uri), deck) { p ->
                setDeck(deck) { it.copy(loadProgress = p) }
            }
            when (result) {
                is DecodeResult.Ready -> try {
                    val h = result.trackHandle
                    val frames = NativeEngine.nativeTrackFrames(h)
                    val wave = NativeEngine.nativeTrackPeaks(h)
                    val ok = NativeEngine.nativeLoad(deck, h)
                    if (!ok) {
                        setDeck(deck) { it.copy(loading = false, title = current.title, artist = current.artist) }
                        say("O motor de áudio recusou a faixa.")
                        return@launch
                    }
                    // 1) já tocável: usa a análise guardada (se houver) e libera o deck na hora
                    val cached = withContext(Dispatchers.IO) { db.analysis(row.id) }
                    val hot = withContext(Dispatchers.IO) { db.hotcues(row.id) }
                    val complete = cached != null && cached.keyTonic >= 0 && cached.energy >= 0f
                    val a0 = cached ?: Analysis(0.0, 0L, 0f)
                    NativeEngine.nativeSetRate(deck, 1f)
                    setDeck(deck) {
                        it.copy(
                            trackId = row.id, title = row.title, artist = row.artist, loading = false, analyzing = !complete,
                            loadProgress = 1f, lengthFrames = frames, wave = wave,
                            bpm = a0.bpm, firstBeatFrame = a0.firstBeatFrame,
                            bpmConfidence = a0.confidence, rate = 1f, loopBeats = 0, hotcues = hot,
                            keyTonic = a0.keyTonic, keyMinor = a0.keyMinor, keyConf = a0.keyConf,
                            energy = a0.energy,
                        )
                    }
                    setKeyShift(deck, keyPrefs.getInt("t${row.id}", 0))
                    say(if (complete) "${row.title} pronta no deck ${deckName(deck)}." else "${row.title} pronta no deck ${deckName(deck)} (analisando andamento e tom…).")
                    // 2) o que falta (andamento, tom, energia, volume) em segundo plano, sem segurar o deck
                    val result2 = withContext(Dispatchers.Default) {
                        android.os.Process.setThreadPriority(android.os.Process.THREAD_PRIORITY_BACKGROUND)
                        var a = cached
                        if (a == null) {
                            val out = DoubleArray(3)
                            NativeEngine.nativeAnalyze(h, out)
                            a = withDownbeat(Analysis(out[0], out[1].toLong(), out[2].toFloat()), h)
                        }
                        if (a.keyTonic < 0) {
                            val k = IntArray(4)
                            NativeEngine.nativeAnalyzeKey(h, k)
                            // sem tonalidade válida guarda confiança 0: não tenta de novo a cada carga
                            a = if (k[0] == 1) a.copy(keyTonic = k[1], keyMinor = k[2] == 1, keyConf = k[3] / 1000f)
                            else a.copy(keyTonic = 0, keyMinor = false, keyConf = 0f)
                        }
                        if (a.energy < 0f) a = a.copy(energy = NativeEngine.nativeAnalyzeEnergy(h).coerceAtLeast(0f))
                        val fin: Analysis = a
                        if (!complete) db.saveAnalysis(row.id, fin)
                        fin to NativeEngine.nativeAnalyzeLoudness(h)
                    }
                    val (a, loud) = result2
                    setDeck(deck) {
                        if (it.trackId != row.id) it else it.copy(
                            analyzing = false, bpm = a.bpm, firstBeatFrame = a.firstBeatFrame, bpmConfidence = a.confidence,
                            keyTonic = a.keyTonic, keyMinor = a.keyMinor, keyConf = a.keyConf, energy = a.energy, loudness = loud,
                        )
                    }
                    applyTrim(deck)
                    pushFx(deck)
                    refreshAutoSamples(deck)
                    if (!complete) say("${row.title}: ${if (a.bpm > 0) String.format(java.util.Locale.ROOT, "%.1f BPM", a.bpm) else "sem andamento"}${_decks.value[deck].key?.let { k -> ", tom ${k.code}" } ?: ""}.")
                    // 3) stems por último (demora mais)
                    separateStems(deck, h)
                } finally {
                    // sempre solta a referência nativa, mesmo se a carga for cancelada no meio da análise
                    NativeEngine.nativeFreeTrack(result.trackHandle)
                }

                is DecodeResult.Failed -> {
                    setDeck(deck) { it.copy(loading = false, title = current.title, artist = current.artist) }
                    say(result.reason)
                }
            }
        }
    }

    private fun setDeck(deck: Int, change: (DeckUi) -> DeckUi) {
        _decks.update { list -> list.mapIndexed { i, d -> if (i == deck) change(d) else d } }
    }

    // ---------------------------------------------------------------- biblioteca

    fun setSearch(text: String) {
        search.value = text
    }

    fun setSort(order: SortOrder) {
        sort.value = order
    }

    fun removeFromLibrary(row: TrackRow) {
        viewModelScope.launch(Dispatchers.IO) {
            db.delete(row.id)
            libraryVersion.update { it + 1 }
        }
    }

    fun importUris(uris: List<Uri>) {
        if (uris.isEmpty()) return
        say("Importando ${uris.size} arquivo(s)…")
        viewModelScope.launch(Dispatchers.IO) { addUris(uris) }
    }

    /** Importa todas as músicas de uma pasta (e subpastas) escolhida no seletor do Android. */
    fun importFolder(tree: Uri) {
        say("Procurando músicas na pasta…")
        viewModelScope.launch(Dispatchers.IO) {
            try {
                getApplication<Application>().contentResolver
                    .takePersistableUriPermission(tree, Intent.FLAG_GRANT_READ_URI_PERMISSION)
            } catch (_: Exception) {
            }
            val found = ArrayList<Uri>()
            try {
                val rootId = android.provider.DocumentsContract.getTreeDocumentId(tree)
                collectAudio(tree, rootId, found, 0)
            } catch (e: Exception) {
                say("Não consegui ler essa pasta.")
                return@launch
            }
            if (found.isEmpty()) {
                say("Nenhuma música encontrada nessa pasta.")
                return@launch
            }
            say("Achei ${found.size} músicas. Importando…")
            addUris(found)
        }
    }

    private fun collectAudio(tree: Uri, docId: String, out: MutableList<Uri>, depth: Int) {
        if (depth > 8 || out.size > 5000) return
        val resolver = getApplication<Application>().contentResolver
        val children = android.provider.DocumentsContract.buildChildDocumentsUriUsingTree(tree, docId)
        val cols = arrayOf(
            android.provider.DocumentsContract.Document.COLUMN_DOCUMENT_ID,
            android.provider.DocumentsContract.Document.COLUMN_DISPLAY_NAME,
            android.provider.DocumentsContract.Document.COLUMN_MIME_TYPE,
        )
        val dirs = ArrayList<String>()
        resolver.query(children, cols, null, null, null)?.use { c ->
            while (c.moveToNext()) {
                val id = c.getString(0) ?: continue
                val name = c.getString(1).orEmpty()
                val mime = c.getString(2).orEmpty()
                if (mime == android.provider.DocumentsContract.Document.MIME_TYPE_DIR) dirs.add(id)
                else if (mime.startsWith("audio/") || hasAudioExtension(name)) {
                    out.add(android.provider.DocumentsContract.buildDocumentUriUsingTree(tree, id))
                }
            }
        }
        for (id in dirs) collectAudio(tree, id, out, depth + 1)
    }

    private fun hasAudioExtension(name: String): Boolean {
        val ext = name.substringAfterLast('.', "").lowercase()
        return ext in setOf("mp3", "wav", "flac", "m4a", "aac", "ogg", "oga", "opus", "wma", "aif", "aiff", "mp4")
    }

    private suspend fun addUris(uris: List<Uri>) {
        var added = 0
        var duplicated = 0
        var invalid = 0
        for (uri in uris) {
            try {
                getApplication<Application>().contentResolver
                    .takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION)
            } catch (_: Exception) {
                // nem todo provedor oferece permissão persistente
            }
            val meta = readMetadata(uri)
            if (meta == null) {
                invalid++
            } else if (db.insert(uri.toString(), meta.title, meta.artist, meta.durationMs)) {
                added++
            } else {
                duplicated++
            }
        }
        libraryVersion.update { it + 1 }
        val parts = ArrayList<String>()
        if (added > 0) parts.add("$added adicionada(s)")
        if (duplicated > 0) parts.add("$duplicated já estava(m) na biblioteca")
        if (invalid > 0) parts.add("$invalid não é/são áudio")
        say(if (parts.isEmpty()) "Nada foi importado." else parts.joinToString(" · "))
    }

    private class Meta(val title: String, val artist: String, val durationMs: Long)

    private fun readMetadata(uri: Uri): Meta? {
        val ctx = getApplication<Application>()
        val r = MediaMetadataRetriever()
        try {
            r.setDataSource(ctx, uri)
            val duration = r.extractMetadata(MediaMetadataRetriever.METADATA_KEY_DURATION)?.toLongOrNull() ?: 0L
            val hasAudio = r.extractMetadata(MediaMetadataRetriever.METADATA_KEY_HAS_AUDIO)
            val name = fileName(uri)
            // alguns aparelhos não preenchem HAS_AUDIO em m4a/ogg: aceita se tem duração ou extensão de áudio
            if (hasAudio != "yes" && duration <= 0L && !hasAudioExtension(name)) return null
            val title = r.extractMetadata(MediaMetadataRetriever.METADATA_KEY_TITLE)?.trim().orEmpty()
            val artist = r.extractMetadata(MediaMetadataRetriever.METADATA_KEY_ARTIST)?.trim().orEmpty()
            return Meta(title.ifEmpty { displayName(uri) }, artist, duration)
        } catch (_: Exception) {
            return if (hasAudioExtension(fileName(uri))) Meta(displayName(uri), "", 0L) else null
        } finally {
            try {
                r.release()
            } catch (_: Exception) {
            }
        }
    }

    /** Nome do arquivo com a extensão ("faixa.mp3"), ou "" se o provedor não informar. */
    private fun fileName(uri: Uri): String {
        try {
            getApplication<Application>().contentResolver
                .query(uri, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)?.use { c ->
                    if (c.moveToFirst()) return c.getString(0).orEmpty()
                }
        } catch (_: Exception) {
        }
        return uri.lastPathSegment.orEmpty()
    }

    private fun displayName(uri: Uri): String {
        try {
            getApplication<Application>().contentResolver
                .query(uri, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)?.use { c ->
                    if (c.moveToFirst()) {
                        val name = c.getString(0)
                        if (!name.isNullOrBlank()) return name.substringBeforeLast('.')
                    }
                }
        } catch (_: Exception) {
        }
        return "Faixa sem título"
    }


    // ------------------------------------------------------- gravar o set (exportar a mixagem)

    private val _recStart = MutableStateFlow<Long?>(null)
    /** Momento em que a gravação começou (null = não gravando). */
    val recordingSince: StateFlow<Long?> = _recStart.asStateFlow()
    private var recFile: java.io.File? = null

    /** GRAVAR: grava tudo o que sai no som geral num WAV e, ao parar, salva em Música/Edgard Guarda DJ Studio. */
    fun toggleRecording() {
        if (_recStart.value != null) { stopRecording(); return }
        val app = getApplication<Application>()
        val dir = app.getExternalFilesDir(android.os.Environment.DIRECTORY_MUSIC) ?: app.filesDir
        dir.mkdirs()
        val stamp = java.text.SimpleDateFormat("yyyy-MM-dd_HH-mm", java.util.Locale.ROOT).format(java.util.Date())
        val f = java.io.File(dir, "set_$stamp.wav")
        if (!NativeEngine.nativeRecordStart(f.absolutePath)) { say("Não consegui começar a gravar."); return }
        recFile = f
        _recStart.value = System.currentTimeMillis()
        say("Gravando o set. Toque em GRAVAR de novo para parar e salvar.")
    }

    private fun stopRecording() {
        val f = recFile
        val startedAt = _recStart.value
        _recStart.value = null
        recFile = null
        viewModelScope.launch(Dispatchers.IO) {
            val frames = NativeEngine.nativeRecordStop()
            if (f == null || frames <= 0) { say("Nada foi gravado (o som estava parado?)."); return@launch }
            val secs = frames / NativeEngine.SAMPLE_RATE
            say("Set gravado (${secs / 60} min). Compactando para M4A…")
            val m4a = wavToM4a(f)
            val final = if (m4a != null && m4a.length() > 0) { f.delete(); m4a } else f
            val where = publishRecording(final)
            val list = tracklistText(startedAt, "Edgard Guarda DJ Studio · ${final.nameWithoutExtension}")
            if (_history.value.any { it.atMs >= (startedAt ?: 0L) - 60_000 }) saveText(final.nameWithoutExtension + "_musicas.txt", list)
            say("Set gravado: ${final.name} (${secs / 60}:${String.format(java.util.Locale.ROOT, "%02d", secs % 60)}) em $where, com a lista das músicas em Documentos.")
        }
    }

    // --------------------------------------------------------- histórico da noite

    /** Uma música que foi ao ar: hora (ms do relógio), título, artista, andamento e tom. */
    data class Played(val atMs: Long, val trackId: Long, val title: String, val artist: String, val bpm: Double, val key: String?)

    private val _history = MutableStateFlow<List<Played>>(emptyList())
    /** Músicas que tocaram no som geral desde que o app abriu (ordem em que entraram). */
    val history: StateFlow<List<Played>> = _history.asStateFlow()
    private val onAir = longArrayOf(-1L, -1L)

    /** Uma música "vai ao ar" quando toca com volume e com o crossfader do lado dela. */
    private fun checkOnAir() {
        val ds = _decks.value
        val xf = _crossfader.value
        val vols = _volumes.value
        for (d in 0..1) {
            val u = ds[d]
            val side = if (d == 0) xf < 0.8f else xf > 0.2f
            val audible = u.loaded && u.playing && vols[d] > 0.15f && side && u.trackId >= 0
            if (audible && onAir[d] != u.trackId) {
                onAir[d] = u.trackId
                if (_history.value.lastOrNull()?.trackId != u.trackId) {
                    _history.update { it + Played(System.currentTimeMillis(), u.trackId, u.title, u.artist, u.playedBpm, u.key?.code) }
                }
            }
        }
    }

    /** Texto da lista de músicas (a partir de [since] ms; tempos relativos a ele). */
    private fun tracklistText(since: Long?, title: String): String {
        val list = if (since == null) _history.value else _history.value.filter { it.atMs >= since - 60_000 }
        val t0 = since ?: list.firstOrNull()?.atMs ?: 0L
        val sb = StringBuilder("$title\n\n")
        for ((i, p) in list.withIndex()) {
            val sec = ((p.atMs - t0) / 1000).coerceAtLeast(0)
            val tm = String.format(java.util.Locale.ROOT, "%d:%02d:%02d", sec / 3600, (sec / 60) % 60, sec % 60)
            sb.append(String.format(java.util.Locale.ROOT, "%02d. [%s] %s%s  (%.0f BPM%s)\n", i + 1, tm, p.title,
                if (p.artist.isNotEmpty()) " — ${p.artist}" else "", p.bpm, p.key?.let { ", $it" } ?: ""))
        }
        return sb.toString()
    }

    /** Salva a lista da noite em Documentos/Edgard Guarda DJ Studio. */
    fun saveHistory() {
        if (_history.value.isEmpty()) { say("Nenhuma música foi ao ar ainda."); return }
        viewModelScope.launch(Dispatchers.IO) {
            val stamp = java.text.SimpleDateFormat("yyyy-MM-dd_HH-mm", java.util.Locale.ROOT).format(java.util.Date())
            val where = saveText("historico_$stamp.txt", tracklistText(null, "Edgard Guarda DJ Studio · músicas da noite ($stamp)"))
            say("Lista da noite salva em $where.")
        }
    }

    fun clearHistory() { _history.value = emptyList(); onAir.fill(-1L) }

    private fun saveText(name: String, text: String): String {
        val app = getApplication<Application>()
        if (android.os.Build.VERSION.SDK_INT >= 29) {
            try {
                val r = app.contentResolver
                val values = android.content.ContentValues().apply {
                    put(android.provider.MediaStore.MediaColumns.DISPLAY_NAME, name)
                    put(android.provider.MediaStore.MediaColumns.MIME_TYPE, "text/plain")
                    put(android.provider.MediaStore.MediaColumns.RELATIVE_PATH, "Documents/Edgard Guarda DJ Studio")
                }
                val uri = r.insert(android.provider.MediaStore.Files.getContentUri("external"), values)
                if (uri != null) {
                    r.openOutputStream(uri)?.use { it.write(text.toByteArray()) }
                    return "Documentos/Edgard Guarda DJ Studio"
                }
            } catch (_: Exception) { }
        }
        val dir = app.getExternalFilesDir(android.os.Environment.DIRECTORY_DOCUMENTS) ?: app.filesDir
        dir.mkdirs()
        java.io.File(dir, name).writeText(text)
        return dir.absolutePath
    }

    // ------------------------------------------------------------------ backup

    private val backupPrefs = listOf("output", "set", "autodj", "jog", "tom_por_musica", "playlists")

    /** Salva biblioteca (análises, grades, hot cues), playlists e ajustes num arquivo .zip em Documentos. */
    fun exportBackup() {
        viewModelScope.launch(Dispatchers.IO) {
            val app = getApplication<Application>()
            val stamp = java.text.SimpleDateFormat("yyyy-MM-dd_HH-mm", java.util.Locale.ROOT).format(java.util.Date())
            val name = "backup_edgard_guarda_$stamp.zip"
            try {
                val bytes = java.io.ByteArrayOutputStream()
                java.util.zip.ZipOutputStream(bytes).use { z ->
                    db.writableDatabase.rawQuery("PRAGMA wal_checkpoint(FULL)", null).use { it.moveToFirst() }
                    val dbFile = app.getDatabasePath("library.db")
                    z.putNextEntry(java.util.zip.ZipEntry("library.db")); dbFile.inputStream().use { it.copyTo(z) }; z.closeEntry()
                    for (pn in backupPrefs) {
                        val f = java.io.File(app.applicationInfo.dataDir, "shared_prefs/$pn.xml")
                        if (f.exists()) { z.putNextEntry(java.util.zip.ZipEntry("prefs/$pn.xml")); f.inputStream().use { it.copyTo(z) }; z.closeEntry() }
                    }
                }
                val where = saveBytes(name, "application/zip", bytes.toByteArray())
                say("Backup salvo: $name em $where.")
            } catch (e: Exception) {
                say("Não consegui salvar o backup: ${e.message}")
            }
        }
    }

    /** Restaura um backup .zip escolhido pelo usuário. O app precisa ser reaberto depois. */
    fun importBackup(uri: Uri) {
        viewModelScope.launch(Dispatchers.IO) {
            val app = getApplication<Application>()
            try {
                var gotDb = false
                app.contentResolver.openInputStream(uri)?.use { input ->
                    java.util.zip.ZipInputStream(input).use { z ->
                        while (true) {
                            val e = z.nextEntry ?: break
                            when {
                                e.name == "library.db" -> {
                                    db.close()
                                    val dbFile = app.getDatabasePath("library.db")
                                    java.io.File(dbFile.path + "-wal").delete(); java.io.File(dbFile.path + "-shm").delete()
                                    dbFile.outputStream().use { z.copyTo(it) }
                                    gotDb = true
                                }
                                e.name.startsWith("prefs/") && e.name.endsWith(".xml") -> {
                                    val pn = e.name.removePrefix("prefs/").removeSuffix(".xml")
                                    if (pn in backupPrefs) java.io.File(app.applicationInfo.dataDir, "shared_prefs/$pn.xml").outputStream().use { z.copyTo(it) }
                                }
                            }
                        }
                    }
                }
                if (!gotDb) { say("Esse arquivo não é um backup do Edgard Guarda DJ Studio."); return@launch }
                say("Backup restaurado. Feche e abra o app para carregar tudo.")
            } catch (e: Exception) {
                say("Não consegui restaurar: ${e.message}")
            }
        }
    }

    private fun saveBytes(name: String, mime: String, data: ByteArray): String {
        val app = getApplication<Application>()
        if (android.os.Build.VERSION.SDK_INT >= 29) {
            try {
                val r = app.contentResolver
                val values = android.content.ContentValues().apply {
                    put(android.provider.MediaStore.MediaColumns.DISPLAY_NAME, name)
                    put(android.provider.MediaStore.MediaColumns.MIME_TYPE, mime)
                    put(android.provider.MediaStore.MediaColumns.RELATIVE_PATH, "Documents/Edgard Guarda DJ Studio")
                }
                val uri = r.insert(android.provider.MediaStore.Files.getContentUri("external"), values)
                if (uri != null) {
                    r.openOutputStream(uri)?.use { it.write(data) }
                    return "Documentos/Edgard Guarda DJ Studio"
                }
            } catch (_: Exception) { }
        }
        val dir = app.getExternalFilesDir(android.os.Environment.DIRECTORY_DOCUMENTS) ?: app.filesDir
        dir.mkdirs()
        java.io.File(dir, name).writeBytes(data)
        return dir.absolutePath
    }

    /**
     * Converte o WAV gravado para M4A (AAC 256 kbps, ~10 vezes menor, toca em qualquer celular, computador e
     * nas redes). Devolve o arquivo novo ou null se o aparelho não tiver o codificador.
     */
    private fun wavToM4a(wav: java.io.File): java.io.File? {
        val out = java.io.File(wav.parentFile, wav.nameWithoutExtension + ".m4a")
        var codec: android.media.MediaCodec? = null
        var muxer: android.media.MediaMuxer? = null
        try {
            val input = java.io.RandomAccessFile(wav, "r")
            input.use { raf ->
                // procura o bloco "data" do WAV
                val hdr = ByteArray(12); raf.readFully(hdr)
                var dataLen = 0L
                var rate = NativeEngine.SAMPLE_RATE
                var ch = 2
                while (raf.filePointer < raf.length()) {
                    val id = ByteArray(4); raf.readFully(id)
                    val len = Integer.reverseBytes(raf.readInt()).toLong() and 0xFFFFFFFFL
                    val name = String(id)
                    if (name == "fmt ") {
                        val f = ByteArray(len.toInt()); raf.readFully(f)
                        ch = (f[2].toInt() and 0xFF) or ((f[3].toInt() and 0xFF) shl 8)
                        rate = (f[4].toInt() and 0xFF) or ((f[5].toInt() and 0xFF) shl 8) or ((f[6].toInt() and 0xFF) shl 16) or ((f[7].toInt() and 0xFF) shl 24)
                    } else if (name == "data") { dataLen = len; break } else raf.seek(raf.filePointer + len)
                }
                if (dataLen <= 0) return null
                dataLen = minOf(dataLen, raf.length() - raf.filePointer)
                val fmt = android.media.MediaFormat.createAudioFormat(android.media.MediaFormat.MIMETYPE_AUDIO_AAC, rate, ch)
                fmt.setInteger(android.media.MediaFormat.KEY_AAC_PROFILE, android.media.MediaCodecInfo.CodecProfileLevel.AACObjectLC)
                fmt.setInteger(android.media.MediaFormat.KEY_BIT_RATE, 256_000)
                fmt.setInteger(android.media.MediaFormat.KEY_MAX_INPUT_SIZE, 16384)
                val c = android.media.MediaCodec.createEncoderByType(android.media.MediaFormat.MIMETYPE_AUDIO_AAC)
                codec = c
                c.configure(fmt, null, null, android.media.MediaCodec.CONFIGURE_FLAG_ENCODE)
                c.start()
                val m = android.media.MediaMuxer(out.absolutePath, android.media.MediaMuxer.OutputFormat.MUXER_OUTPUT_MPEG_4)
                muxer = m
                var track = -1
                var muxing = false
                val info = android.media.MediaCodec.BufferInfo()
                var readTotal = 0L
                var inputDone = false
                val bytesPerFrame = 2 * ch
                val buf = ByteArray(8192)
                while (true) {
                    if (!inputDone) {
                        val ii = c.dequeueInputBuffer(10_000)
                        if (ii >= 0) {
                            val ib = c.getInputBuffer(ii)!!
                            ib.clear()
                            val want = minOf(minOf(ib.remaining(), buf.size).toLong(), dataLen - readTotal).toInt() / bytesPerFrame * bytesPerFrame
                            if (want <= 0) {
                                c.queueInputBuffer(ii, 0, 0, readTotal / bytesPerFrame * 1_000_000L / rate, android.media.MediaCodec.BUFFER_FLAG_END_OF_STREAM)
                                inputDone = true
                            } else {
                                raf.readFully(buf, 0, want)
                                ib.put(buf, 0, want)
                                c.queueInputBuffer(ii, 0, want, readTotal / bytesPerFrame * 1_000_000L / rate, 0)
                                readTotal += want
                            }
                        }
                    }
                    val oi = c.dequeueOutputBuffer(info, 10_000)
                    if (oi == android.media.MediaCodec.INFO_OUTPUT_FORMAT_CHANGED) {
                        track = m.addTrack(c.outputFormat); m.start(); muxing = true
                    } else if (oi >= 0) {
                        val ob = c.getOutputBuffer(oi)!!
                        if ((info.flags and android.media.MediaCodec.BUFFER_FLAG_CODEC_CONFIG) != 0) info.size = 0
                        if (info.size > 0 && muxing) {
                            ob.position(info.offset); ob.limit(info.offset + info.size)
                            m.writeSampleData(track, ob, info)
                        }
                        c.releaseOutputBuffer(oi, false)
                        if ((info.flags and android.media.MediaCodec.BUFFER_FLAG_END_OF_STREAM) != 0) break
                    }
                }
            }
            return out
        } catch (e: Throwable) {
            android.util.Log.w("DJFusion", "M4A falhou", e)
            out.delete()
            return null
        } finally {
            runCatching { codec?.stop() }; runCatching { codec?.release() }
            runCatching { muxer?.stop() }; runCatching { muxer?.release() }
        }
    }

    /** Copia o WAV para a pasta Música do aparelho (aparece nos apps de música e no gerenciador de arquivos). */
    private fun publishRecording(f: java.io.File): String {
        if (android.os.Build.VERSION.SDK_INT < 29) return f.parent ?: "pasta do app"
        return try {
            val r = getApplication<Application>().contentResolver
            val values = android.content.ContentValues().apply {
                put(android.provider.MediaStore.Audio.Media.DISPLAY_NAME, f.name)
                put(android.provider.MediaStore.Audio.Media.MIME_TYPE, if (f.extension == "m4a") "audio/mp4" else "audio/x-wav")
                put(android.provider.MediaStore.Audio.Media.RELATIVE_PATH, "Music/Edgard Guarda DJ Studio")
                put(android.provider.MediaStore.Audio.Media.IS_PENDING, 1)
            }
            val uri = r.insert(android.provider.MediaStore.Audio.Media.EXTERNAL_CONTENT_URI, values) ?: return f.parent ?: ""
            r.openOutputStream(uri)?.use { out -> f.inputStream().use { it.copyTo(out) } }
            values.clear()
            values.put(android.provider.MediaStore.Audio.Media.IS_PENDING, 0)
            r.update(uri, values, null, null)
            f.delete()
            lastRecording = uri
            "Música/Edgard Guarda DJ Studio"
        } catch (_: Exception) {
            f.parent ?: "pasta do app"
        }
    }

    /** Último set gravado (para importar de volta ou conferir). */
    var lastRecording: Uri? = null
        private set

    // ------------------------------------------------------- efeitos de performance

    private val fxJobs = arrayOfNulls<Job>(2)

    private fun runFx(deck: Int, block: suspend () -> Unit) {
        fxJobs[deck]?.cancel()
        fxJobs[deck] = viewModelScope.launch { block() }
    }

    private fun beatSec(deck: Int): Double {
        val d = _decks.value[deck]
        return if (d.hasBpm) 60.0 / d.playedBpm else 0.5
    }

    /** ECHO OUT: eco forte no ritmo e o som do deck some em 2 compassos (sai de cena sem corte seco). */
    fun echoOut(deck: Int) {
        val d = _decks.value[deck]
        if (!d.playing) { say("ECHO OUT precisa do deck ${deckName(deck)} tocando."); return }
        runFx(deck) {
            val vol0 = _volumes.value[deck]
            setDeck(deck) { it.copy(fxType = 1, fxAmount = 0.85f) }
            pushFx(deck)
            val total = beatSec(deck) * 8
            val t0 = System.nanoTime()
            while (true) {
                val t = ((System.nanoTime() - t0) / 1e9 / total).coerceIn(0.0, 1.0)
                if (t >= 0.25) NativeEngine.nativeSetVolume(deck, (vol0 * (1.0 - (t - 0.25) / 0.75)).toFloat().coerceAtLeast(0f))
                if (t >= 1.0) break
                delay(30)
            }
            NativeEngine.nativePause(deck)
            delay(beatSec(deck).times(4000).toLong())   // deixa o eco morrer
            setDeck(deck) { it.copy(fxType = 0) }
            pushFx(deck)
            setVolume(deck, vol0)
        }
    }

    /** FILTRO AUTO: o filtro sobe (tira os graves) por 4 compassos e volta, para criar tensão antes da virada. */
    fun filterSweep(deck: Int) {
        runFx(deck) {
            val total = beatSec(deck) * 16
            val t0 = System.nanoTime()
            while (true) {
                val t = ((System.nanoTime() - t0) / 1e9 / total).coerceIn(0.0, 1.0)
                val x = if (t < 0.75) 0.5 + 0.42 * (t / 0.75) else 0.92 - 0.42 * ((t - 0.75) / 0.25)
                setFilter(deck, x.toFloat())
                if (t >= 1.0) break
                delay(30)
            }
            setFilter(deck, 0.5f)
        }
    }

    /** FREIO: o disco desacelera até parar, como desligar o toca-discos. */
    fun brake(deck: Int) {
        val d = _decks.value[deck]
        if (!d.playing) { say("FREIO precisa do deck ${deckName(deck)} tocando."); return }
        runFx(deck) {
            val r0 = d.rate
            val steps = 30
            for (i in 1..steps) {
                NativeEngine.nativeSetRate(deck, (r0 * (1f - i.toFloat() / steps)).coerceAtLeast(0.02f))
                delay(25)
            }
            NativeEngine.nativePause(deck)
            NativeEngine.nativeSetRate(deck, r0)
        }
    }

    /** VOLTA (spinback): o disco gira rápido para trás e para. */
    fun spinback(deck: Int) {
        val d = _decks.value[deck]
        if (!d.playing) { say("VOLTA precisa do deck ${deckName(deck)} tocando."); return }
        runFx(deck) {
            for (i in 0 until 20) {
                val v = -4f * (1f - i / 20f)
                NativeEngine.nativeScratch(deck, true, v)
                delay(30)
            }
            NativeEngine.nativeScratch(deck, true, 0f)
            NativeEngine.nativePause(deck)
            NativeEngine.nativeScratch(deck, false, 0f)
        }
    }

    // ------------------------------------------------------- HARMONIZAR (ordem do set)


    private fun saveSet(ids: List<Long>) {
        _set.value = ids
        setPrefs.edit().putString("ids", ids.joinToString(",")).apply()
    }

    fun clearSet() { saveSet(emptyList()); _activePlaylist.value = null; say("Ordem do set apagada.") }

    // ------------------------------------------------------------------ PLAYLISTS
    // A ordem do set é a playlist ativa (a que o AUTO DJ segue). Playlists salvas ficam guardadas pelo nome.

    private val plPrefs = app.getSharedPreferences("playlists", android.content.Context.MODE_PRIVATE)
    private val _playlists = MutableStateFlow(readPlaylists())
    val playlists: StateFlow<Map<String, List<Long>>> = _playlists.asStateFlow()
    private val _activePlaylist = MutableStateFlow<String?>(plPrefs.getString("_ativa", null))
    val activePlaylist: StateFlow<String?> = _activePlaylist.asStateFlow()

    private fun readPlaylists(): Map<String, List<Long>> {
        val raw = plPrefs.getString("todas", null) ?: return emptyMap()
        return try {
            val o = org.json.JSONObject(raw)
            o.keys().asSequence().associateWith { k ->
                val a = o.getJSONArray(k)
                List(a.length()) { a.getLong(it) }
            }.toSortedMap(String.CASE_INSENSITIVE_ORDER)
        } catch (e: org.json.JSONException) {
            emptyMap()
        }
    }

    private fun writePlaylists(m: Map<String, List<Long>>) {
        val o = org.json.JSONObject()
        for ((k, v) in m) o.put(k, org.json.JSONArray(v))
        plPrefs.edit().putString("todas", o.toString()).apply()
        _playlists.value = m.toSortedMap(String.CASE_INSENSITIVE_ORDER)
    }

    private fun setActive(name: String?) {
        _activePlaylist.value = name
        plPrefs.edit().putString("_ativa", name).apply()
    }

    /** Põe ou tira a música da playlist ativa (no fim da lista). */
    fun toggleInSet(row: TrackRow) {
        val ids = _set.value
        if (row.id in ids) {
            saveSet(ids - row.id)
            say("${row.title} saiu da playlist.")
        } else {
            saveSet(ids + row.id)
            say("${row.title} entrou na playlist (posição ${ids.size + 1}).")
        }
        _activePlaylist.value?.let { name -> writePlaylists(_playlists.value + (name to _set.value)) }
    }

    /** Salva a playlist ativa com um nome (substitui se já existir). */
    fun savePlaylist(name: String) {
        val n = name.trim().take(40)
        if (n.isEmpty()) { say("Dê um nome para a playlist."); return }
        if (_set.value.isEmpty()) { say("A playlist está vazia. Use + nas músicas ou HARMONIZAR."); return }
        writePlaylists(_playlists.value + (n to _set.value))
        setActive(n)
        say("Playlist \"$n\" salva com ${_set.value.size} música(s).")
    }

    /** Abre uma playlist salva: vira a ordem do set (o AUTO DJ passa a seguir ela). */
    fun openPlaylist(name: String) {
        val ids = _playlists.value[name] ?: return
        viewModelScope.launch {
            val existing = allTracks().map { it.id }.toSet()
            val valid = ids.filter { it in existing }     // músicas removidas da biblioteca saem da lista
            saveSet(valid)
            setActive(name)
            sort.value = SortOrder.SET
            say("Playlist \"$name\": ${valid.size} música(s). O AUTO DJ segue esta ordem.")
        }
    }

    fun deletePlaylist(name: String) {
        writePlaylists(_playlists.value - name)
        if (_activePlaylist.value == name) setActive(null)
        say("Playlist \"$name\" apagada (as músicas continuam na biblioteca).")
    }

    /** Começa uma playlist nova, vazia. */
    fun newPlaylist() {
        saveSet(emptyList())
        setActive(null)
        say("Playlist nova: toque em + nas músicas para montar e depois em SALVAR.")
    }

    /**
     * HARMONIZAR: ordena a biblioteca num caminho de mixagem: cada próxima faixa com tom compatível na Roda de
     * Camelot, andamento perto e energia subindo aos poucos até o pico (perto de 70% do set) e descendo no fim.
     * Analisa sozinho o que faltar.
     */
    fun harmonize() {
        viewModelScope.launch {
            _analysisProgress.value = "preparando"
            try {
                analyzeMissing { done, total -> _analysisProgress.value = "$done de $total" }
            } finally {
                _analysisProgress.value = null
            }
            val inSet = _set.value.toSet()
            val onlyPlaylist = _activePlaylist.value != null && inSet.size >= 2
            val all = allTracks().filter { it.bpm > 0 && (!onlyPlaylist || it.id in inSet) }
            if (all.size < 2) { say("HARMONIZAR precisa de pelo menos 2 músicas com andamento detectado."); return@launch }
            val start = _decks.value.firstOrNull { it.playing }?.trackId
            val order = withContext(Dispatchers.Default) {
                Harmonizer.order(
                    all.map { SetTrack(it.id, it.bpm, it.key, it.energy) }, start,
                )
            }
            saveSet(order.map { it.id })
            _activePlaylist.value?.let { name -> if (onlyPlaylist) writePlaylists(_playlists.value + (name to _set.value)) else setActive(null) }
            sort.value = SortOrder.SET
            say("Set harmonizado: ${order.size} músicas em ordem de tom, andamento e energia. O AUTO DJ segue esta ordem.")
        }
    }

    /** Próxima faixa do set depois de [afterId] que não esteja nos decks nem em [skip]. */
    fun nextInSet(afterId: Long, skip: Collection<Long>): Long? {
        val ids = _set.value
        if (ids.isEmpty()) return null
        val loaded = _decks.value.map { it.trackId }
        val start = ids.indexOf(afterId)
        for (k in 1..ids.size) {
            val id = ids[(start + k).mod(ids.size)]
            if (id !in loaded && id !in skip) return id
        }
        return null
    }


    // ------------------------------------------------------- navegador rápido e assistente de mixagem

    private val _browser = MutableStateFlow<Int?>(null)
    /** Deck para o qual o navegador rápido (carregar música sem sair da tela DJ) está aberto. */
    val browserDeck: StateFlow<Int?> = _browser.asStateFlow()
    fun openBrowser(deck: Int) { _browser.value = deck }
    fun closeBrowser() { _browser.value = null }

    /** Carrega pelo navegador rápido e fecha. */
    fun loadFromBrowser(deck: Int, row: TrackRow) {
        loadTrack(deck, row)
        if (!_decks.value[deck].playing) closeBrowser()
    }

    /** A faixa de referência para sugerir a próxima: a do outro deck (a que está tocando, de preferência). */
    fun referenceFor(deck: Int): SetTrack? {
        val d = _decks.value
        val other = d[1 - deck]
        val src = if (other.loaded) other else if (d[deck].loaded) d[deck] else return null
        if (!src.hasBpm) return null
        return SetTrack(src.trackId, src.playedBpm, src.shownKey, src.energy)
    }

    /** PULO DE BATIDA: avança ou volta [beats] batidas sem perder o ritmo. */
    fun beatJump(deck: Int, beats: Int) {
        val d = _decks.value[deck]
        if (!d.loaded || d.loading) { say("Carregue uma música no deck ${deckName(deck)} primeiro."); return }
        if (!d.hasBpm) { say("Pulo de batida precisa do andamento detectado."); return }
        val beat = 60.0 * NativeEngine.SAMPLE_RATE / d.bpm
        val pos = _live.value.decks[deck].positionFrames
        val target = (pos + beats * beat).toLong().coerceIn(0L, (d.lengthFrames - 1).coerceAtLeast(0L))
        NativeEngine.nativeSeek(deck, target)
    }

    override fun onCleared() {
        for (d in 0..1) NativeEngine.nativeCancelStems(d)
        decodeJobs.forEach { it?.cancel() }
        if (_recStart.value != null) NativeEngine.nativeRecordStop()
        midi.stop()
        router.stop()
        NativeEngine.nativeStop()
    }

    companion object {
        val BUILTIN_NAMES = listOf("BUZINA", "SIRENE", "LASER", "BUMBO 808", "PALMA", "SUBIDA", "DESCIDA", "EXPLOSÃO")
        /** Stems só para músicas até este tamanho (memória). */
        const val STEM_MAX_MINUTES = 12
        /** Volume alvo do auto-gain (dBFS RMS). */
        const val TARGET_DB = -12.0
        /** Faixas do fader de pitch (em %). */
        val PITCH_RANGES = listOf(8, 16, 25, 50, 100)
        val WAVE_ZOOMS = listOf(3f, 5f, 8f, 12f, 20f)
        val JUMP_SIZES = listOf(1, 2, 4, 8, 16, 32)
        /** Abaixo disto o andamento detectado é tratado como "não detectado". */
        const val MIN_BPM_CONFIDENCE = 0.3f

        fun deckName(deck: Int) = if (deck == 0) "A" else "B"
    }
}
