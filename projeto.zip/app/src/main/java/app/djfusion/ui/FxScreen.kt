package app.djfusion.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import app.djfusion.ui.theme.Metal

/**
 * EFEITOS: tudo de efeito num lugar só, um painel por deck.
 * Em cima, os efeitos contínuos (eco no ritmo, flanger, reverb, filtro) com a quantidade;
 * embaixo, os efeitos de performance que agem sozinhos no tempo da música (echo out, filtro automático,
 * freio e volta do disco).
 */
@Composable
fun FxScreen(vm: AppViewModel) {
    val decks by vm.decks.collectAsStateWithLifecycle()
    Row(Modifier.fillMaxSize().background(Metal.Bg).padding(10.dp), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
        for (deck in 0..1) FxDeckPanel(vm, deck, decks[deck], Modifier.weight(1f).fillMaxHeight())
    }
}

@Composable
private fun FxDeckPanel(vm: AppViewModel, deck: Int, ui: DeckUi, modifier: Modifier) {
    val name = AppViewModel.deckName(deck)
    val color = deckColor(deck)
    Column(modifier.brushedSilver().padding(10.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text("DECK $name", color = color, fontSize = 18.sp, fontWeight = FontWeight.ExtraBold)
            Text(
                if (ui.loaded) "  ${ui.title}" else "  vazio",
                color = Color(0xFF30353B), fontSize = 12.sp, maxLines = 1, modifier = Modifier.weight(1f),
            )
            if (ui.hasBpm) Text(String.format(java.util.Locale.ROOT, "%.1f BPM", ui.playedBpm), color = Color(0xFF30353B), fontSize = 12.sp, fontWeight = FontWeight.Bold)
        }
        Text("EFEITO (no ritmo da música)", color = Color(0xFF30353B), fontSize = 10.sp, fontWeight = FontWeight.Bold, letterSpacing = 1.sp)
        Row(Modifier.fillMaxWidth().height(58.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            val names = listOf("ECO", "FLANGER", "REVERB")
            for (t in 1..3) {
                MetalButton(
                    description = "Efeito ${names[t - 1]} do deck $name (tela de efeitos). Toque de novo para desligar.",
                    onPress = { vm.setFx(deck, t) },
                    led = color, ledOn = ui.fxType == t,
                    modifier = Modifier.weight(1f).fillMaxHeight(),
                ) {
                    Text(names[t - 1], color = if (ui.fxType == t) color else Metal.OnMetal, fontSize = 13.sp, fontWeight = FontWeight.ExtraBold, maxLines = 1)
                }
            }
        }
        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            Column(Modifier.weight(1f)) {
                Text("QUANTIDADE", color = Color(0xFF30353B), fontSize = 10.sp, fontWeight = FontWeight.Bold)
                MetalFader(
                    value = ui.fxAmount, onChange = { vm.setFxAmount(deck, it) }, accent = color, fill = true,
                    description = "Quantidade do efeito do deck $name (tela de efeitos)",
                    modifier = Modifier.fillMaxWidth().height(40.dp), vertical = false,
                )
            }
            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                Knob(
                    value = ui.filter, onChange = { vm.setFilter(deck, it) }, accent = color,
                    description = "Filtro do deck $name (tela de efeitos). Esquerda corta os agudos, direita corta os graves. Toque duplo zera.",
                    modifier = Modifier.size(58.dp),
                )
                Text("FILTRO", color = Color(0xFF30353B), fontSize = 10.sp, fontWeight = FontWeight.Bold)
            }
        }
        Text("PERFORMANCE (age sozinho, no tempo da música)", color = Color(0xFF30353B), fontSize = 10.sp, fontWeight = FontWeight.Bold, letterSpacing = 1.sp)
        Row(Modifier.fillMaxWidth().weight(1f), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            PerfButton("ECHO OUT", "sai com eco em 2 compassos", "Echo out do deck $name: a música sai com eco no ritmo e para", color) { vm.echoOut(deck) }
            PerfButton("FILTRO AUTO", "sobe e volta em 4 compassos", "Filtro automático do deck $name: sobe e volta em 4 compassos", color) { vm.filterSweep(deck) }
        }
        Row(Modifier.fillMaxWidth().weight(1f), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            PerfButton("FREIO", "o disco para devagar", "Freio do deck $name: o disco desacelera até parar", color) { vm.brake(deck) }
            PerfButton("VOLTA", "o disco volta rápido", "Volta do deck $name: o disco gira para trás e para", color) { vm.spinback(deck) }
        }
    }
}

@Composable
private fun androidx.compose.foundation.layout.RowScope.PerfButton(
    label: String, hint: String, description: String, color: Color, onPress: () -> Unit,
) {
    MetalButton(
        description = description, onPress = onPress, led = color, ledOn = false,
        modifier = Modifier.weight(1f).fillMaxHeight(),
    ) {
        Column(horizontalAlignment = Alignment.CenterHorizontally, modifier = Modifier.align(Alignment.Center)) {
            Text(label, color = Metal.OnMetal, fontSize = 15.sp, fontWeight = FontWeight.ExtraBold, maxLines = 1)
            Text(hint, color = Color(0xFF30353B), fontSize = 10.sp, textAlign = TextAlign.Center, maxLines = 1)
        }
    }
}
