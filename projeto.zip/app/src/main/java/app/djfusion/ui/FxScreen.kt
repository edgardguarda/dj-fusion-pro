package app.djfusion.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import app.djfusion.ui.theme.Metal

/**
 * EFEITOS: tudo de efeito num lugar só, um painel por deck.
 * Em cima, os efeitos contínuos (eco no ritmo, flanger, reverb, filtro) com a quantidade;
 * embaixo, os efeitos de performance que agem sozinhos no tempo da música (echo out, filtro automático,
 * freio e volta do disco).
 */
@Composable
fun FxScreen(vm: AppViewModel) {
    val decks by vm.decks.collectAsStateWithLifecycle()
    val ly by vm.layers.collectAsStateWithLifecycle()
    Row(Modifier.fillMaxSize().background(Metal.Bg).padding(10.dp), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
        FxDeckPanel(vm, ly[0], decks[ly[0]], Modifier.weight(1f).fillMaxHeight())
        FxDeckPanel(vm, ly[1], decks[ly[1]], Modifier.weight(1f).fillMaxHeight())
    }
}

@Composable
private fun FxDeckPanel(vm: AppViewModel, deck: Int, ui: DeckUi, modifier: Modifier) {
    val name = AppViewModel.deckName(deck)
    val color = deckColor(deck)
    Column(modifier.brushedSilver().padding(10.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text("DECK $name", color = color, fontSize = 18.sp, fontWeight = FontWeight.ExtraBold)
            Text(
                if (ui.loaded) "  ${ui.title}" else "  vazio",
                color = Color(0xFF9AA4AE), fontSize = 12.sp, maxLines = 1, modifier = Modifier.weight(1f),
            )
            if (ui.hasBpm) Text(String.format(java.util.Locale.ROOT, "%.1f BPM", ui.playedBpm), color = Color(0xFF9AA4AE), fontSize = 12.sp, fontWeight = FontWeight.Bold)
        }
        Text("EFEITOS (no ritmo da música) · até 3 juntos: escolha o encaixe e depois o efeito", color = Color(0xFF9AA4AE), fontSize = 11.sp, fontWeight = FontWeight.Bold, letterSpacing = 1.sp)
        Row(Modifier.fillMaxWidth().height(34.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            for (slot in 0..2) {
                val t = ui.fxTypeAt(slot)
                MetalButton(
                    description = "Encaixe FX${slot + 1} do deck $name (tela de efeitos)",
                    onPress = { vm.setFxSlot(deck, slot) },
                    led = color, ledOn = ui.fxSel == slot,
                    modifier = Modifier.weight(1f).fillMaxHeight(),
                ) {
                    Text(
                        "FX${slot + 1}: " + (if (t > 0) FX_NAMES[t - 1] else "—") + (if (t > 0) " ${Math.round(ui.fxAmountAt(slot) * 100)}%" else ""),
                        color = if (ui.fxSel == slot) color else Metal.OnMetal, fontSize = 11.sp, fontWeight = FontWeight.ExtraBold, maxLines = 1, softWrap = false,
                    )
                }
            }
            MetalButton(
                description = "Desligar os 3 efeitos do deck $name",
                onPress = { vm.clearFx(deck) },
                modifier = Modifier.weight(0.7f).fillMaxHeight(),
            ) { Text("DESLIGA", color = Metal.OnMetal, fontSize = 11.sp, fontWeight = FontWeight.ExtraBold, maxLines = 1) }
        }
        for (row in 0..2) Row(Modifier.fillMaxWidth().height(32.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            val names = FX_NAMES
            for (t in (row * 4 + 1)..minOf(FX_NAMES.size, row * 4 + 4)) {
                MetalButton(
                    description = "Efeito ${names[t - 1]} do deck $name (tela de efeitos). Toque de novo para desligar.",
                    onPress = { vm.setFx(deck, t) },
                    led = color, ledOn = ui.fxSlotOf(t) >= 0,
                    modifier = Modifier.weight(1f).fillMaxHeight(),
                ) {
                    Text(names[t - 1], color = if (ui.fxSlotOf(t) == ui.fxSel) color else if (ui.fxSlotOf(t) >= 0) color.copy(alpha = 0.6f) else Metal.OnMetal, fontSize = 11.sp, fontWeight = FontWeight.ExtraBold, maxLines = 1, softWrap = false)
                }
            }
        }
        var xyLock by androidx.compose.runtime.remember { androidx.compose.runtime.mutableStateOf(false) }
        var xyHeld by androidx.compose.runtime.remember { androidx.compose.runtime.mutableStateOf(false) }
        var xyBeats by androidx.compose.runtime.remember { androidx.compose.runtime.mutableStateOf(0.75f) }
        Row(Modifier.fillMaxWidth().weight(2.2f).heightIn(min = 70.dp), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            // PAD XY: lado a lado = quantidade do efeito; de baixo para cima = divisão da batida (1/8 a 4 batidas)
            val yNow = (Math.log((ui.fxBeats / 0.125f).toDouble()) / Math.log(32.0)).toFloat().coerceIn(0f, 1f)
            XyPad(
                x = ui.selFxAmount, y = yNow, accent = color,
                description = "Pad XY do efeito do deck $name. Arraste: para a direita aumenta a quantidade, para cima encurta a divisão da batida. Solte para o efeito parar, ou use TRAVAR.",
                modifier = Modifier.weight(1f).fillMaxHeight(),
                onMove = { px, py ->
                    if (ui.selFxType > 0) {
                        if (!xyHeld) { xyHeld = true; xyBeats = ui.fxBeats }
                        vm.setFxAmount(deck, px)
                        vm.setFxBeats(deck, 0.125f * Math.pow(32.0, py.toDouble()).toFloat())
                    }
                },
                onRelease = {
                    if (ui.selFxType == 0) vm.say("Escolha um efeito nos botões e arraste no pad XY.")
                    else if (xyHeld && !xyLock) { vm.setFxAmount(deck, 0f); vm.setFxBeats(deck, xyBeats) }
                    xyHeld = false
                },
            )
            Column(Modifier.width(132.dp).fillMaxHeight(), verticalArrangement = Arrangement.SpaceBetween) {
                Column {
                    Text("QUANTIDADE", color = Color(0xFF9AA4AE), fontSize = 11.sp, fontWeight = FontWeight.Bold)
                    MetalFader(
                        value = ui.selFxAmount, onChange = { vm.setFxAmount(deck, it) }, accent = color, fill = true,
                        description = "Quantidade do efeito do deck $name (tela de efeitos)",
                        modifier = Modifier.fillMaxWidth().height(34.dp), vertical = false,
                    )
                }
                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Knob(
                        value = ui.filter, onChange = { vm.setFilter(deck, it) }, accent = color,
                        description = "Filtro do deck $name (tela de efeitos). Esquerda corta os agudos, direita corta os graves. Toque duplo zera.",
                        modifier = Modifier.size(46.dp),
                    )
                    Text("FILTRO", color = Color(0xFF9AA4AE), fontSize = 11.sp, fontWeight = FontWeight.Bold)
                }
                MetalButton(
                    description = "Travar o pad XY do deck $name (ligado: $xyLock). Travado, o efeito continua depois de soltar o dedo.",
                    onPress = { xyLock = !xyLock },
                    led = color, ledOn = xyLock,
                    modifier = Modifier.fillMaxWidth().height(34.dp),
                ) { Text(if (xyLock) "TRAVADO ✓" else "TRAVAR", color = if (xyLock) color else Metal.OnMetal, fontSize = 11.sp, fontWeight = FontWeight.ExtraBold, maxLines = 1) }
            }
        }
        Row(Modifier.fillMaxWidth().weight(0.8f).heightIn(min = 34.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            PerfButton("ECHO OUT", "sai com eco em 2 compassos", "Echo out do deck $name: a música sai com eco no ritmo e para", color) { vm.echoOut(deck) }
            PerfButton("FILTRO AUTO", "sobe e volta em 4 compassos", "Filtro automático do deck $name: sobe e volta em 4 compassos", color) { vm.filterSweep(deck) }
            PerfButton("FREIO", "o disco para devagar", "Freio do deck $name: o disco desacelera até parar", color) { vm.brake(deck) }
            PerfButton("VOLTA", "o disco volta rápido", "Volta do deck $name: o disco gira para trás e para", color) { vm.spinback(deck) }
        }
    }
}

@Composable
private fun androidx.compose.foundation.layout.RowScope.PerfButton(
    label: String, hint: String, description: String, color: Color, onPress: () -> Unit,
) {
    MetalButton(
        description = description, onPress = onPress, led = color, ledOn = false,
        modifier = Modifier.weight(1f).fillMaxHeight(),
    ) {
        Column(horizontalAlignment = Alignment.CenterHorizontally, modifier = Modifier.align(Alignment.Center)) {
            Text(label, color = Metal.OnMetal, fontSize = 13.sp, fontWeight = FontWeight.ExtraBold, maxLines = 1, softWrap = false)
        }
    }
}
