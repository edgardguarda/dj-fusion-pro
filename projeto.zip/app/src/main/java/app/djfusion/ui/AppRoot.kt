package app.djfusion.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.displayCutout
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.windowInsetsPadding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.draw.clip
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.IntrinsicSize
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.disabled
import androidx.compose.ui.semantics.role
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import app.djfusion.ui.theme.Metal
import kotlinx.coroutines.delay

private enum class Screen { LIVE, LIBRARY, FX, SAMPLER, MIDI, SETTINGS }

@Composable
fun AppRoot(vm: AppViewModel) {
    var screen by rememberSaveable { mutableStateOf(Screen.LIVE) }
    val message by vm.message.collectAsStateWithLifecycle()
    val auto by vm.autoDj.state.collectAsStateWithLifecycle()
    val recSince by vm.recordingSince.collectAsStateWithLifecycle()
    val browser by vm.browserDeck.collectAsStateWithLifecycle()

    Surface(
        Modifier.fillMaxSize(),
        color = MaterialTheme.colorScheme.background,
        contentColor = MaterialTheme.colorScheme.onBackground,
    ) {
        Column(Modifier.fillMaxSize().windowInsetsPadding(WindowInsets.displayCutout)) {
            Row(
                Modifier.fillMaxWidth().height(44.dp).background(Color(0xFF16191D)),
                verticalAlignment = Alignment.CenterVertically,
            ) {
                BrandTitle()
                Tab("DJ LIVE", selected = screen == Screen.LIVE, enabled = true) { screen = Screen.LIVE }
                Tab("BIBLIOTECA", selected = screen == Screen.LIBRARY, enabled = true) { screen = Screen.LIBRARY }
                Tab("EFEITOS", selected = screen == Screen.FX, enabled = true) { screen = Screen.FX }
                Tab("AMOSTRAS", selected = screen == Screen.SAMPLER, enabled = true) { screen = Screen.SAMPLER }
                Tab("CONTROLADORA", selected = screen == Screen.MIDI, enabled = true) { screen = Screen.MIDI }
                Tab("AJUSTES", selected = screen == Screen.SETTINGS, enabled = true) { screen = Screen.SETTINGS }
                Box(Modifier.weight(1f))
                MetalButton(
                    description = if (auto.active) "AUTO DJ ligado. Toque para parar" else "AUTO DJ: o programa escolhe e mixa as músicas sozinho",
                    onPress = { vm.autoDj.toggle() },
                    led = Metal.Success, ledOn = auto.active,
                    modifier = Modifier.width(124.dp).height(36.dp),
                ) {
                    Column(Modifier.align(Alignment.Center).padding(horizontal = 14.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                        Text("AUTO DJ", color = Metal.OnMetal, fontSize = 13.sp, fontWeight = FontWeight.ExtraBold)
                        if (auto.status.isNotEmpty()) Text(auto.status, color = Metal.OnMetal, fontSize = 8.sp, maxLines = 1)
                    }
                }
                Spacer(Modifier.width(6.dp))
                MetalButton(
                    description = "Gerar amostras automaticamente das músicas dos decks",
                    onPress = { vm.buildSamples(); screen = Screen.SAMPLER },
                    modifier = Modifier.width(92.dp).height(36.dp),
                ) { Text("AMOSTRAR", color = Metal.OnMetal, fontSize = 11.sp, fontWeight = FontWeight.ExtraBold, modifier = Modifier.align(Alignment.Center)) }
                Spacer(Modifier.width(6.dp))
                RecordButton(vm, recSince)
                Spacer(Modifier.width(8.dp))
            }
            // filete com degradê vermelho sob a barra (acabamento de console)
            Box(
                Modifier.fillMaxWidth().height(2.dp).background(
                    androidx.compose.ui.graphics.Brush.horizontalGradient(listOf(Color(0xFF16191D), Metal.DeckA.copy(alpha = 0.7f), Color(0xFF16191D))),
                ),
            )
            Box(Modifier.weight(1f).fillMaxWidth()) {
                when (screen) {
                    Screen.LIVE -> DjLiveScreen(vm)
                    Screen.LIBRARY -> LibraryScreen(vm)
                    Screen.MIDI -> MidiScreen(vm)
                    Screen.SAMPLER -> SamplerScreen(vm)
                    Screen.FX -> FxScreen(vm)
                    Screen.SETTINGS -> SettingsScreen(vm)
                }
                browser?.let { QuickBrowser(vm, it) }
                val text = message
                if (text != null) {
                    LaunchedEffect(text) {
                        delay(3500)
                        vm.clearMessage(text)
                    }
                }
                // tela DJ: aviso na metade esquerda da onda do deck B (parte já tocada), sem cobrir botões nem a agulha
                if (text != null && screen == Screen.LIVE) {
                    Box(Modifier.align(Alignment.TopStart).fillMaxWidth(0.5f).padding(start = 190.dp, end = 10.dp, top = 64.dp)) {
                        Row(
                            Modifier.clip(RoundedCornerShape(6.dp)).background(Color(0xEE1C2026)).height(IntrinsicSize.Min),
                            verticalAlignment = Alignment.CenterVertically,
                        ) {
                            Box(Modifier.width(3.dp).fillMaxHeight().background(Metal.DeckA))
                            Text(
                                text, color = Metal.Text, fontSize = 12.sp, fontWeight = FontWeight.SemiBold, maxLines = 2, lineHeight = 14.sp,
                                overflow = androidx.compose.ui.text.style.TextOverflow.Ellipsis,
                                modifier = Modifier.padding(horizontal = 8.dp, vertical = 3.dp),
                            )
                        }
                    }
                }
                // nas outras telas o aviso fica embaixo
                if (text != null && screen != Screen.LIVE) {
                    val live = false
                    Row(
                        Modifier.align(if (live) Alignment.TopCenter else Alignment.BottomCenter)
                            .padding(top = if (live) 6.dp else 0.dp, bottom = if (live) 0.dp else 10.dp)
                            .fillMaxWidth(0.6f)
                            .clip(RoundedCornerShape(8.dp))
                            .background(Color(0xEE1C2026))
                            .height(IntrinsicSize.Min),
                        verticalAlignment = Alignment.CenterVertically,
                    ) {
                        Box(Modifier.width(4.dp).fillMaxHeight().background(Metal.DeckA))
                        Text(
                            text,
                            color = Metal.Text, fontSize = 13.sp, fontWeight = FontWeight.SemiBold, maxLines = 2,
                            overflow = androidx.compose.ui.text.style.TextOverflow.Ellipsis,
                            modifier = Modifier.padding(horizontal = 12.dp, vertical = 7.dp),
                        )
                    }
                }
            }
        }
    }
}

@Composable
private fun Tab(label: String, selected: Boolean, enabled: Boolean, onClick: () -> Unit) {
    val color = when {
        !enabled -> Color(0xFF6B747D)
        selected -> Metal.DeckA
        else -> Metal.TextMuted
    }
    Box(
        Modifier.heightIn(min = 44.dp)
            .semantics {
                role = Role.Tab
                contentDescription = if (enabled) label else "Timeline, ainda não disponível"
                if (!enabled) disabled()
            }
            .clickable(enabled = enabled, onClick = onClick)
            .drawBehind {
                if (selected) drawRect(Metal.DeckA, Offset(0f, size.height - 3.dp.toPx()), Size(size.width, 3.dp.toPx()))
            }
            .padding(horizontal = 7.dp),
        contentAlignment = Alignment.Center,
    ) {
        Text(label, color = color, fontSize = 12.sp, fontWeight = FontWeight.Bold)
    }
}


/** GRAVAR: grava o set (o som geral) num arquivo WAV. Aceso em vermelho com o tempo enquanto grava. */
@Composable
private fun RecordButton(vm: AppViewModel, since: Long?) {
    var now by remember { mutableStateOf(System.currentTimeMillis()) }
    if (since != null) {
        LaunchedEffect(since) {
            while (true) { now = System.currentTimeMillis(); delay(500) }
        }
    }
    MetalButton(
        description = if (since != null) "Parar a gravação do set e salvar" else "Gravar o set: tudo o que sai no som geral vira um arquivo WAV",
        onPress = { vm.toggleRecording() },
        led = Metal.DeckA, ledOn = since != null,
        modifier = Modifier.width(96.dp).height(36.dp),
    ) {
        val label = if (since != null) {
            val s = ((now - since) / 1000).coerceAtLeast(0)
            "● " + String.format(java.util.Locale.ROOT, "%d:%02d", s / 60, s % 60)
        } else "GRAVAR"
        Text(label, color = if (since != null) Metal.DeckA else Metal.OnMetal, fontSize = 12.sp, fontWeight = FontWeight.ExtraBold, maxLines = 1, modifier = Modifier.align(Alignment.Center))
    }
}
