package app.djfusion.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import app.djfusion.ui.theme.Metal

/** Seções da tela AJUSTES: uma de cada vez, escolhida na coluna da esquerda. */
private val SETTINGS_SECTIONS = listOf(
    "SOM" to "Saída de áudio, fone e latência",
    "MIXAGEM" to "Crossfader, pitch, quantize, cues automáticas e proteção",
    "PRATOS" to "Vinil e como o prato da tela responde",
    "TELA" to "Cores das ondas, tom, tempo e modo em pé",
    "NOITE" to "Músicas que tocaram hoje",
    "BACKUP" to "Guardar e restaurar biblioteca e ajustes",
    "AJUDA" to "Guia rápido de cada tela",
    "SOBRE" to "Versão do app",
)

/** Tela AJUSTES organizada por assunto: à esquerda os assuntos, à direita só os ajustes do assunto escolhido. */
@Composable
fun SettingsScreen(vm: AppViewModel) {
    var section by androidx.compose.runtime.saveable.rememberSaveable { androidx.compose.runtime.mutableStateOf(0) }
    Row(Modifier.fillMaxSize().background(Metal.Bg).padding(12.dp), horizontalArrangement = Arrangement.spacedBy(14.dp)) {
        Column(Modifier.width(210.dp).fillMaxHeight().verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(6.dp)) {
            for ((i, sec) in SETTINGS_SECTIONS.withIndex()) {
                MetalButton(
                    description = "Seção de ajustes ${sec.first}: ${sec.second}",
                    onPress = { section = i },
                    led = Metal.DeckA, ledOn = section == i,
                    modifier = Modifier.fillMaxWidth().height(50.dp),
                ) {
                    Column(Modifier.align(Alignment.CenterStart).padding(horizontal = 12.dp)) {
                        Text(sec.first, color = if (section == i) Metal.DeckA else Metal.OnMetal, fontSize = 14.sp, fontWeight = FontWeight.ExtraBold, maxLines = 1)
                        Text(sec.second, color = Metal.TextMuted, fontSize = 11.sp, maxLines = 1)
                    }
                }
            }
        }
        Column(
            Modifier.weight(1f).fillMaxHeight().verticalScroll(rememberScrollState()),
            verticalArrangement = Arrangement.spacedBy(10.dp),
        ) {
            when (section) {
                0 -> { OutputPanel(vm); LatencyPanel(vm) }
                1 -> { MixPanel(vm); StemsAiPanel(vm); PitchPanel(vm); QuantizePanel(vm) }
                2 -> { PlattersPanel(vm); SkinPanel(vm) }
                3 -> { WavePanel(); DisplayPanel(vm); AccessPanel(); StemsPanel(vm); MacrosPanel(vm); ProfilesPanel(vm) }
                4 -> HistoryPanel(vm)
                5 -> BackupPanel(vm)
                6 -> { StartPanel(vm); HelpPanel() }
                else -> AboutPanel(vm)
            }
        }
    }
}

@Composable
private fun ChoiceRow(options: List<Pair<String, String>>, selected: Int, onPick: (Int) -> Unit) {
    // mais de 4 opções: em linhas de 3 (botões largos, fáceis de tocar)
    val perRow = if (options.size > 4) 3 else options.size.coerceAtLeast(1)
    for (start in options.indices step perRow) {
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.fillMaxWidth().height(44.dp)) {
            for (i in start until minOf(start + perRow, options.size)) {
                val o = options[i]
                MetalButton(
                    description = o.second,
                    onPress = { onPick(i) },
                    led = Metal.Success, ledOn = selected == i,
                    modifier = Modifier.weight(1f).fillMaxHeight(),
                ) {
                    Text(o.first, color = Metal.OnMetal, fontSize = 11.sp, fontWeight = FontWeight.ExtraBold, maxLines = 1, modifier = Modifier.align(Alignment.Center))
                }
            }
            for (k in options.size until start + perRow) Box(Modifier.weight(1f))
        }
    }
}

@Composable
private fun LatencyPanel(vm: AppViewModel) {
    val latency by vm.latency.collectAsStateWithLifecycle()
    val status by vm.audioStatus.collectAsStateWithLifecycle()
    Panel("LATÊNCIA DO SOM") {
        Text("Quanto menor, mais rápido o som responde ao jog, aos pads e aos botões.", color = Metal.TextMuted, fontSize = 12.sp)
        ChoiceRow(
            listOf(
                "BAIXA" to "Latência baixa: resposta mais rápida (pode falhar em aparelhos lentos)",
                "NORMAL" to "Latência normal: equilíbrio entre resposta e estabilidade",
                "SEGURA" to "Latência segura: mais estável, sem estalos, resposta um pouco mais lenta",
            ),
            latency,
        ) { vm.setLatency(it) }
        Text(
            when (latency) {
                0 -> "BAIXA: ideal para scratch. Se ouvir estalos, use NORMAL."
                1 -> "NORMAL: recomendado."
                else -> "SEGURA: use se o som picotar (Bluetooth ou aparelho ocupado)."
            },
            color = Metal.Text, fontSize = 12.sp,
        )
        Text("Agora: $status", color = Metal.TextMuted, fontSize = 11.sp)
        MetalButton(
            description = "Tocar um som de teste na saída principal",
            onPress = { vm.padPress(0) },
            modifier = Modifier.fillMaxWidth().height(44.dp),
        ) { Text("TESTAR SOM NA SAÍDA (BUZINA)", color = Metal.OnMetal, fontSize = 12.sp, fontWeight = FontWeight.ExtraBold, modifier = Modifier.align(Alignment.Center)) }
        Text("O som sai pela saída principal escolhida acima. Se não ouvir, confira o volume do celular, o cabo ou o Bluetooth e o MODO DE SAÍDA.", color = Metal.TextMuted, fontSize = 11.sp)
    }
}

@Composable
private fun StemsAiPanel(vm: AppViewModel) {
    val n by vm.neural.collectAsStateWithLifecycle()
    Panel("STEMS COM IA (REDE NEURAL)") {
        Text(
            "Spleeter, da Deezer: rede neural que separa voz, bateria, baixo e melodia com mais qualidade que o separador comum. " +
                "Roda no próprio celular. O modelo (cerca de 80 MB) é baixado uma vez pela internet e fica guardado. " +
                "Vale para as próximas músicas que você carregar; músicas longas demoram mais para ficar prontas.",
            color = Metal.TextMuted, fontSize = 12.sp,
        )
        Text(
            "Modelo: " + when {
                n.busy -> "baixando ${(n.pct * 100).toInt()}%"
                n.ready -> "baixado e pronto"
                else -> "ainda não baixado (os stems usam o separador comum)"
            },
            color = if (n.ready) Metal.Success else Metal.Text, fontSize = 13.sp, fontWeight = FontWeight.Bold,
        )
        if (n.msg.isNotEmpty() && !n.ready) Text(n.msg, color = Metal.Warning, fontSize = 12.sp)
        ChoiceRow(
            listOf(
                "IA LIGADA" to "Stems por IA ligados nas próximas músicas",
                "IA DESLIGADA" to "Stems por IA desligados, usar o separador comum",
            ),
            if (n.on) 0 else 1,
        ) { vm.setNeuralOn(it == 0) }
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.fillMaxWidth().height(44.dp)) {
            MetalButton(
                description = "Baixar o modelo de IA dos stems, cerca de 80 MB, precisa de internet",
                onPress = { vm.downloadNeural() },
                led = Metal.DeckA, ledOn = n.busy,
                modifier = Modifier.weight(1f).fillMaxHeight(),
            ) { Text(if (n.ready) "BAIXAR DE NOVO" else "BAIXAR MODELO DE IA (80 MB)", color = Metal.OnMetal, fontSize = 11.sp, fontWeight = FontWeight.ExtraBold, maxLines = 1, modifier = Modifier.align(Alignment.Center)) }
            MetalButton(
                description = "Apagar o modelo de IA e liberar espaço",
                onPress = { vm.deleteNeural() },
                led = Metal.Warning, ledOn = false,
                modifier = Modifier.weight(1f).fillMaxHeight(),
            ) { Text("APAGAR MODELO", color = Metal.OnMetal, fontSize = 11.sp, fontWeight = FontWeight.ExtraBold, maxLines = 1, modifier = Modifier.align(Alignment.Center)) }
        }
    }
}

@Composable
private fun PitchPanel(vm: AppViewModel) {
    val pr by vm.defaultPitch.collectAsStateWithLifecycle()
    Panel("PITCH (FAIXA DO FADER)") {
        val opts = AppViewModel.PITCH_RANGES
        ChoiceRow(
            opts.map { (if (it >= 100) "WIDE ±100" else "±$it%") to "Faixa padrão do pitch ±$it%" },
            opts.indexOf(pr),
        ) { vm.setDefaultPitch(opts[it]) }
        Text("±8 a ±16: ajuste fino para mixar. ±25 e ±50: efeitos e gêneros bem diferentes. WIDE: de parado até o dobro da velocidade. No deck, toque na etiqueta em cima do fader para trocar só aquele deck.", color = Metal.TextMuted, fontSize = 12.sp)
    }
}

@Composable
private fun SkinPanel(vm: AppViewModel) {
    val sk by vm.skin.collectAsStateWithLifecycle()
    Panel("APARÊNCIA (SKIN)") {
        ChoiceRow(Metal.SKIN_NAMES.map { it to "Aparência $it: cores dos decks A e B" }, sk) { vm.setSkin(it) }
    }
}

@Composable
private fun PlattersPanel(vm: AppViewModel) {
    val vinyl by vm.vinyl.collectAsStateWithLifecycle()
    Panel("PRATOS (JOG)") {
        ChoiceRow(
            listOf(
                "VINIL LIGADO" to "Modo vinil ligado: tocar no disco faz scratch, a borda empurra",
                "VINIL DESLIGADO" to "Modo vinil desligado: o prato só empurra e segura a música",
            ),
            if (vinyl) 0 else 1,
        ) { if ((it == 0) != vinyl) vm.toggleVinyl() }
        val ten = androidx.compose.runtime.remember { androidx.compose.runtime.mutableStateOf(vm.jog.tension) }
        ChoiceRow(
            listOf(
                "TENSÃO SOLTA" to "Tensão do prato solta: o disco para assim que você solta",
                "TENSÃO MÉDIA" to "Tensão do prato média: o disco continua girando um pouco depois de soltar",
                "TENSÃO PESADA" to "Tensão do prato pesada: o disco gira mais tempo depois de soltar, como um prato pesado",
            ),
            ten.value,
        ) { ten.value = it; vm.jog.setTension(it) }
        Text("Com a música parada, girar o prato procura o ponto exato. Tocando: o meio do disco faz scratch (com VINIL) e a borda adianta ou atrasa a batida.", color = Metal.TextMuted, fontSize = 12.sp)
        Text("Modos do prato (botão PRATO em cada deck): BUSCA, GRADE, LOOP saída/entrada, FX e LISTA. BACKSPIN: virar o prato rápido para trás e soltar. Prato da controladora: calibrar, codificação e BUSCA ficam na aba CONTROLADORA.", color = Metal.Text, fontSize = 12.sp)
    }
}

@Composable
private fun QuantizePanel(vm: AppViewModel) {
    val q by vm.quantize.collectAsStateWithLifecycle()
    Panel("TOQUE NA BATIDA (QUANTIZE)") {
        ChoiceRow(
            listOf(
                "QUANTIZE LIGADO" to "Quantize ligado: hot cues e loops presos na batida",
                "QUANTIZE DESLIGADO" to "Quantize desligado: hot cues e loops no ponto exato do toque",
            ),
            if (q) 0 else 1,
        ) { if ((it == 0) != q) vm.toggleQuantize() }
        Text("Com quantize, cues, loops e saltos caem sempre na batida mais próxima, sem atravessar o ritmo.", color = Metal.TextMuted, fontSize = 12.sp)
    }
    val smart by vm.smartGrid.collectAsStateWithLifecycle()
    Panel("GRADE INTELIGENTE (ANDAMENTO VARIÁVEL)") {
        ChoiceRow(
            listOf(
                "GRADE INTELIGENTE LIGADA" to "Grade inteligente ligada: em músicas que mudam de andamento, a grade segue cada trecho",
                "GRADE INTELIGENTE DESLIGADA" to "Grade inteligente desligada: uma grade só por música",
            ),
            if (smart) 0 else 1,
        ) { if ((it == 0) != smart) vm.toggleSmartGrid() }
        Text(
            "Montagens, medleys e gravações ao vivo mudam de velocidade. O app mede o andamento ao longo da música e, ligado, troca a grade " +
                "de cada trecho na hora certa (SYNC, loops, saltos e o AUTO DJ seguem o trecho). O deck mostra ANDAM. VARIÁVEL. " +
                "Se você corrigir a grade à mão (TAP, ÷2, ×2, 1 AQUI), a sua correção vale e a grade inteligente deixa essa música em paz.",
            color = Metal.TextMuted, fontSize = 12.sp,
        )
    }
}

@Composable
private fun WavePanel() {
    Panel("ONDAS: DESENHO") {
        ChoiceRow(
            listOf(
                "RGB" to "Onda RGB: cada trecho na cor do seu som (graves, médios ou agudos)",
                "3 BANDAS" to "Onda em 3 bandas: graves, médios e agudos em camadas, cada um com sua altura",
                "CONTORNO" to "Onda em contorno: corpo numa cor e borda clara, desenho mais limpo",
                "BARRAS" to "Onda em barras: blocos separados como medidor de LED",
                "PICO+RMS" to "Onda pico e média: fora o pico, dentro a força média do som",
                "UM LADO" to "Onda de um lado só: cresce da base para cima",
            ),
            DisplayPrefs.waveType,
        ) { DisplayPrefs.waveType = it }
        Text(
            "6 desenhos. RGB: o caráter de cada trecho. 3 BANDAS: bumbo, voz e pratos separados (bom para achar o break e o drop). " +
                "CONTORNO: visual limpo. BARRAS: blocos, fácil de ler de longe. PICO+RMS: mostra onde a música tem força de verdade. " +
                "UM LADO: picos maiores, ótimo em tela pequena.",
            color = Metal.TextMuted, fontSize = 12.sp,
        )
    }
    Panel("ONDAS: CORES") {
        ChoiceRow(
            listOf(
                "VERMELHO" to "Ondas em tons de vermelho: graves escuros, agudos claros",
                "CINZA" to "Ondas em tons de cinza: graves grafite, agudos prata",
                "ESPECTRO" to "Ondas coloridas pelo espectro: graves vermelhos, médios verdes, agudos azuis",
            ),
            if (DisplayPrefs.waveStyle <= 2) DisplayPrefs.waveStyle else -1,
        ) { DisplayPrefs.waveStyle = it }
        ChoiceRow(
            listOf(
                "AZUL GELO" to "Ondas em tons de azul: graves azul escuro, agudos quase brancos",
                "ÂMBAR" to "Ondas em tons de âmbar: graves laranja, agudos dourados",
            ),
            if (DisplayPrefs.waveStyle >= 3) DisplayPrefs.waveStyle - 3 else -1,
        ) { DisplayPrefs.waveStyle = 3 + it }
        Text("Em todas as cores: quanto mais claro, mais agudo (pratos, vozes); mais escuro e cheio, mais grave (bumbo, baixo).", color = Metal.TextMuted, fontSize = 12.sp)
    }
}

@Composable
private fun MixPanel(vm: AppViewModel) {
    val curve by vm.xfCurve.collectAsStateWithLifecycle()
    val autoCues by vm.autoCues.collectAsStateWithLifecycle()
    val guard by vm.silenceGuard.collectAsStateWithLifecycle()
    Panel("MIXAGEM") {
        Text("Curva do crossfader", color = Metal.Text, fontSize = 12.sp, fontWeight = FontWeight.Bold)
        ChoiceRow(
            listOf(
                "SUAVE" to "Crossfader suave: transições longas sem buraco no volume",
                "MIXAGEM" to "Crossfader mixagem: as duas músicas cheias no meio",
                "CORTE" to "Crossfader corte: abre logo no começo do curso, para scratch",
            ),
            curve,
        ) { vm.setXfCurve(it) }
        val xfx by vm.xfFx.collectAsStateWithLifecycle()
        Text("CROSSFADER FX: o que acontece com a música que sai ao passar o crossfader", color = Metal.Text, fontSize = 12.sp, fontWeight = FontWeight.Bold)
        ChoiceRow(
            listOf(
                "SEM FX" to "Crossfader FX desligado",
                "FILTRO" to "Crossfader FX filtro: a música que sai some pelo filtro",
                "GRAVES" to "Crossfader FX graves: a música que sai perde o grave",
            ),
            xfx,
        ) { vm.setXfFx(it) }
        ChoiceRow(
            listOf(
                "CUES AUTO LIGADAS" to "Cues automáticas ligadas: INÍCIO, GROOVE, DROP e SAÍDA em músicas sem cues",
                "CUES AUTO DESLIGADAS" to "Cues automáticas desligadas",
            ),
            if (autoCues) 0 else 1,
        ) { vm.setAutoCues(it == 0) }
        ChoiceRow(
            listOf(
                "PROTEÇÃO LIGADA" to "Proteção contra silêncio ligada: o final entra em loop se nada mais estiver tocando",
                "PROTEÇÃO DESLIGADA" to "Proteção contra silêncio desligada",
            ),
            if (guard) 0 else 1,
        ) { vm.setSilenceGuard(it == 0) }
        Text(
            "Cues automáticas: ao carregar uma música sem cues, as hot cues 1–4 marcam onde ela começa, onde entra a batida, o drop e a saída. " +
                "Proteção contra silêncio: se a música chegar ao fim e o outro deck estiver parado, o último compasso fica em loop no tempo até você soltar.",
            color = Metal.TextMuted, fontSize = 12.sp,
        )
    }
}

@Composable
private fun DisplayPanel(vm: AppViewModel) {
    Panel("VISOR") {
        ChoiceRow(
            listOf("CAMELOT (8A)" to "Mostrar tom em Camelot", "LETRAS (Am)" to "Mostrar tom em letras", "OPEN KEY (1m)" to "Mostrar tom em Open Key, o sistema do Traktor"),
            if (DisplayPrefs.keyLetters) 1 else if (DisplayPrefs.keyOpen) 2 else 0,
        ) { DisplayPrefs.keyLetters = it == 1; DisplayPrefs.keyOpen = it == 2 }
        ChoiceRow(
            listOf("TEMPO TOCADO" to "Visor mostra o tempo tocado", "TEMPO RESTANTE" to "Visor mostra o tempo que falta"),
            if (DisplayPrefs.remaining) 1 else 0,
        ) { DisplayPrefs.remaining = it == 1 }
        val portrait by vm.portrait.collectAsStateWithLifecycle()
        val ctx = androidx.compose.ui.platform.LocalContext.current
        ChoiceRow(
            listOf("SEMPRE DEITADO" to "Tela sempre deitada (paisagem)", "GIRA EM PÉ" to "Liberar modo retrato: tela compacta com o celular em pé"),
            if (portrait) 1 else 0,
        ) { vm.setPortrait(it == 1, ctx as? android.app.Activity) }
    }
}

@Composable
private fun AccessPanel() {
    Panel("TEXTO E TOQUE") {
        Text("Para ler melhor na cabine escura ou de longe, e para sentir o toque nos botões.", color = Metal.TextMuted, fontSize = 12.sp)
        ChoiceRow(
            listOf("TEXTO NORMAL" to "Tamanho normal do texto", "TEXTO GRANDE" to "Texto 15% maior", "TEXTO MUITO GRANDE" to "Texto 30% maior (alguns botões podem ficar apertados)"),
            DisplayPrefs.textSize,
        ) { DisplayPrefs.textSize = it }
        ChoiceRow(
            listOf("VIBRAR AO TOCAR" to "Vibração curta a cada toque em botão", "SEM VIBRAÇÃO" to "Sem vibração"),
            if (DisplayPrefs.haptics) 0 else 1,
        ) { DisplayPrefs.haptics = it == 0 }
        MetalButton(
            description = "Modo palco: texto muito grande e vibração ligada, para ler de longe",
            onPress = { DisplayPrefs.textSize = 2; DisplayPrefs.haptics = true },
            modifier = Modifier.fillMaxWidth().height(44.dp),
        ) { Text("MODO PALCO (texto muito grande + vibração)", color = Metal.OnMetal, fontSize = 12.sp, fontWeight = FontWeight.ExtraBold, maxLines = 1, modifier = Modifier.align(Alignment.Center)) }
    }
}

/** Força com que um stem desligado some: mais forte tira mais voz/bateria/baixo, mas leva um pouco do resto junto. */
@Composable
private fun StemsPanel(vm: AppViewModel) {
    val s by vm.stemStrength.collectAsStateWithLifecycle()
    Panel("STEMS: FORÇA DA REMOÇÃO") {
        Text("Nenhuma separação por IA é perfeita: sempre sobra um pouco. FORTE tira mais do que sobra (e pode afinar o resto); SUAVE preserva o som original.", color = Metal.TextMuted, fontSize = 12.sp)
        ChoiceRow(
            listOf("SUAVE" to "Remoção exata, preserva o som", "NORMAL" to "Remoção equilibrada", "FORTE" to "Remoção mais agressiva (some mais voz, pode afinar o resto)"),
            s,
        ) { vm.setStemStrength(it) }
    }
}

private val MACRO_ACTIONS: List<Pair<String, String>> = buildList {
    for (d in 0..1) {
        val n = if (d == 0) "A" else "B"
        add("ECO SAÍDA $n" to "d$d.echoout"); add("FREIO $n" to "d$d.brake"); add("BACKSPIN $n" to "d$d.backspin")
        add("ACAPELLA $n" to "d$d.acapella"); add("INSTRUMENTAL $n" to "d$d.instr"); add("STEMS TODOS $n" to "d$d.stemall")
        add("EFEITOS OFF $n" to "d$d.fxoff"); add("SYNC $n" to "d$d.sync"); add("LOOP ½ $n" to "d$d.loophalf")
        add("LOOP ×2 $n" to "d$d.loopdouble"); add("PITCH 0 $n" to "d$d.pitchreset"); add("PLAY/PAUSE $n" to "d$d.play")
    }
    add("AUTO DJ" to "autodj"); add("AUTO DJ: MIXAR AGORA" to "automixnow")
}

/** Três macros: escolha as ações que rodam juntas com um toque (ou num botão da controladora, em MAPEAR). */
@Composable
private fun MacrosPanel(vm: AppViewModel) {
    val macros by vm.macros.collectAsStateWithLifecycle()
    var slot by androidx.compose.runtime.remember { androidx.compose.runtime.mutableStateOf(0) }
    Panel("MACROS") {
        Text("Uma macro roda várias ações de uma vez, na ordem em que você as escolher (ex.: ECO SAÍDA A + PLAY B). Para usar numa controladora, ensine o botão em CONTROLADORA › MAPEAR (MACRO 1, 2 ou 3).", color = Metal.TextMuted, fontSize = 12.sp)
        ChoiceRow(
            listOf("MACRO 1" to "Editar a macro 1", "MACRO 2" to "Editar a macro 2", "MACRO 3" to "Editar a macro 3"),
            slot,
        ) { slot = it }
        val chosen = macros.getOrElse(slot) { emptyList() }
        Text(
            if (chosen.isEmpty()) "Nenhuma ação escolhida." else "Ordem: " + chosen.joinToString(" → ") { id -> MACRO_ACTIONS.firstOrNull { it.second == id }?.first ?: id },
            color = Metal.Text, fontSize = 12.sp,
        )
        for (row in MACRO_ACTIONS.chunked(2)) {
            Row(Modifier.fillMaxWidth().height(40.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                for ((label, id) in row) {
                    MetalButton(
                        description = "Liga ou desliga a ação $label na macro ${slot + 1}",
                        onPress = { vm.toggleMacroStep(slot, id) },
                        led = Metal.Success, ledOn = id in chosen,
                        modifier = Modifier.weight(1f).fillMaxHeight(),
                    ) { Text(label, color = Metal.OnMetal, fontSize = 11.sp, fontWeight = FontWeight.ExtraBold, maxLines = 1, modifier = Modifier.align(Alignment.Center)) }
                }
                if (row.size == 1) Box(Modifier.weight(1f))
            }
        }
        MetalButton(
            description = "Disparar a macro ${slot + 1} agora",
            onPress = { vm.runMacro(slot + 1) },
            enabled = chosen.isNotEmpty(),
            modifier = Modifier.fillMaxWidth().height(44.dp),
        ) { Text("TESTAR MACRO ${slot + 1} AGORA", color = Metal.OnMetal, fontSize = 12.sp, fontWeight = FontWeight.ExtraBold, modifier = Modifier.align(Alignment.Center)) }
    }
}

/** Três perfis de configuração (ex.: CASA, FESTA, RÁDIO): guardam cor, texto, vibração, visor, ondas e latência, e voltam com um toque. */
@Composable
private fun ProfilesPanel(vm: AppViewModel) {
    val ctx = androidx.compose.ui.platform.LocalContext.current
    val prefs = androidx.compose.runtime.remember { ctx.getSharedPreferences("perfis", android.content.Context.MODE_PRIVATE) }
    var tick by androidx.compose.runtime.remember { androidx.compose.runtime.mutableStateOf(0) }
    val skin by vm.skin.collectAsStateWithLifecycle()
    val latency by vm.latency.collectAsStateWithLifecycle()
    Panel("PERFIS DE CONFIGURAÇÃO") {
        Text("Guarde a configuração de cada ocasião e volte a ela com um toque (cor, texto, vibração, visor, ondas e latência).", color = Metal.TextMuted, fontSize = 12.sp)
        for (slot in 1..3) {
            val saved = tick >= 0 && prefs.contains("p$slot")
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                MetalButton(
                    description = "Salvar a configuração atual no perfil $slot",
                    onPress = {
                        prefs.edit().putString(
                            "p$slot",
                            listOf(skin, DisplayPrefs.textSize, if (DisplayPrefs.haptics) 1 else 0, if (DisplayPrefs.keyLetters) 1 else 0,
                                if (DisplayPrefs.keyOpen) 1 else 0, if (DisplayPrefs.remaining) 1 else 0, DisplayPrefs.waveStyle, DisplayPrefs.waveType, latency)
                                .joinToString(","),
                        ).apply()
                        tick++
                        vm.say("Perfil $slot salvo.")
                    },
                    modifier = Modifier.weight(1f).height(44.dp),
                ) { Text(if (saved) "PERFIL $slot · SALVAR POR CIMA" else "PERFIL $slot · SALVAR", color = Metal.OnMetal, fontSize = 12.sp, fontWeight = FontWeight.ExtraBold, maxLines = 1) }
                MetalButton(
                    description = "Carregar o perfil $slot",
                    enabled = saved,
                    onDisabledPress = { vm.say("O perfil $slot ainda está vazio. Toque em SALVAR para guardar a configuração atual.") },
                    onPress = {
                        val v = prefs.getString("p$slot", null)?.split(',')?.mapNotNull { it.toIntOrNull() }
                        if (v != null && v.size >= 9) {
                            vm.setSkin(v[0]); DisplayPrefs.textSize = v[1].coerceIn(0, 2); DisplayPrefs.haptics = v[2] == 1
                            DisplayPrefs.keyLetters = v[3] == 1; DisplayPrefs.keyOpen = v[4] == 1; DisplayPrefs.remaining = v[5] == 1
                            DisplayPrefs.waveStyle = v[6].coerceIn(0, 4); DisplayPrefs.waveType = v[7].coerceIn(0, 5); vm.setLatency(v[8].coerceIn(0, 2))
                            vm.say("Perfil $slot carregado.")
                        }
                    },
                    modifier = Modifier.weight(1f).height(44.dp),
                ) { Text("CARREGAR $slot", color = if (saved) Metal.OnMetal else Metal.TextMuted, fontSize = 12.sp, fontWeight = FontWeight.ExtraBold, maxLines = 1) }
            }
        }
    }
}

private val HELP_TOPICS = listOf(
    "DJ LIVE" to "Os quatro decks (A e B na frente, C e D atrás: o botão A⇄C ou B⇄D troca de camada). Toque na onda para andar pela música, " +
        "gire o prato para raspar (scratch), use os pads para cues, loops, rolls, samples e fatias (SLICE). SYNC iguala o andamento ao outro deck; " +
        "o crossfader e os faders de volume ficam no meio. A tecla de stems tira ou põe voz, bateria, baixo e melodia.",
    "BIBLIOTECA" to "Importe músicas do aparelho ou uma pasta inteira. O app analisa andamento (BPM) e tom (Camelot) em segundo plano. " +
        "Ordene por tom, andamento ou energia; toque numa música para carregar no deck, ou segure para ver as opções. Músicas com BPM incerto aparecem com '?'.",
    "AUTO DJ" to "Liga o programa para escolher e mixar as músicas sozinho. Você escolhe a origem (biblioteca, pasta, fila), o estilo de transição e " +
        "o perfil de energia. MIXAR AGORA antecipa a troca. Se a música parar, ele retoma sozinho. Se algo errar, gere o relatório em CONTROLADORA › DIAGNÓSTICO.",
    "STEMS" to "Em cada deck, abra STEMS: quatro faders (voz, bateria, baixo, melodia), um botão de corte em cada, SÓ VOZ/BAT/BAIXO/MEL (solo; apertar de novo volta tudo) " +
        "e ACAPELLA, INSTRUMENTAL, BATERIA e TUDO. Os faders e os solos também podem ser ensinados à controladora em MAPEAR. " +
        "Para remover mais, use AJUSTES › TELA › STEMS: FORÇA DA REMOÇÃO (FORTE). A separação por IA leva alguns minutos por música; só use os stems depois de chegar a 100%.",
    "REVERSO E PRATO" to "Com o dedo no prato (modo VINIL), girar para trás toca a música ao contrário, e soltar devolve a música. O botão REVERSO liga a música ao contrário; " +
        "ensine REVERSO (segurar) em MAPEAR para ouvi-la ao contrário só enquanto o botão está apertado: ao soltar, ela volta no ponto onde estaria.",
    "EFEITOS" to "Eco, reverb, filtro, flanger e outros por deck. O botão do efeito liga e desliga; o botão giratório ajusta a quantidade. " +
        "Use o filtro e o eco para entrar e sair de músicas com suavidade.",
    "AMOSTRAS" to "Sons curtos (sirenes, vozes, batidas) para disparar por cima da mixagem. Os sons prontos já estão nos pads; " +
        "você pode importar os seus.",
    "CONTROLADORA" to "Funciona com a maioria das controladoras DJ, inclusive antigas. Ligue por USB; o app reconhece o modelo e aplica o mapa certo. " +
        "No MONITOR você vê o que a controladora está enviando, e o TESTE RÁPIDO conta quantos controles diferentes ela já mexeu. " +
        "Se o botão não faz nada, use MAPEAR QUALQUER CONTROLADORA.",
    "AJUSTES" to "SOM: saída de áudio e latência (comece pela NORMAL; SEGURA se estalar). MIXAGEM: crossfader, pitch, quantize e stems. " +
        "PRATOS: sensação do vinil. TELA: cores, tom, texto grande, vibração e modo em pé. BACKUP: guarda e restaura sua biblioteca.",
    "DICAS" to "• Primeiro teste o som no fone antes de tocar para o público. • Se o som picotar, use latência SEGURA e feche outros apps. " +
        "• Mande sempre o relatório de diagnóstico ao reportar um problema. • O texto verde no canto superior (✓ OK) mostra o estado do app; toque nele para ver detalhes.",
)

/** Configuração em passos: cada linha mostra se já está pronta (✓) e tem o botão para resolver. */
@Composable
private fun StartPanel(vm: AppViewModel) {
    val status by vm.audioStatus.collectAsStateWithLifecycle()
    val neural by vm.neural.collectAsStateWithLifecycle()
    val devices by vm.midi.devices.collectAsStateWithLifecycle()
    val mapped by vm.midi.mapped.collectAsStateWithLifecycle()
    val tracks by vm.tracks.collectAsStateWithLifecycle()
    Panel("CONFIGURAÇÃO EM 5 PASSOS") {
        Text("Siga de cima para baixo. ✓ = pronto. Em qualquer dúvida, toque no botão do passo.", color = Metal.TextMuted, fontSize = 12.sp)
        Text((if (status.isNotEmpty()) "✓ " else "• ") + "1. SOM: $status", color = Metal.Text, fontSize = 12.sp)
        MetalButton(
            description = "Passo 1: tocar um som de teste na saída",
            onPress = { vm.padPress(0) },
            modifier = Modifier.fillMaxWidth().height(40.dp),
        ) { Text("TOCAR SOM DE TESTE", color = Metal.OnMetal, fontSize = 12.sp, fontWeight = FontWeight.ExtraBold, modifier = Modifier.align(Alignment.Center)) }
        Text((if (tracks.isNotEmpty()) "✓ " else "• ") + "2. MÚSICAS: ${tracks.size} na biblioteca" + if (tracks.isEmpty()) " (abra BIBLIOTECA e importe)" else "", color = Metal.Text, fontSize = 12.sp)
        Text((if (neural.ready) "✓ " else "• ") + "3. STEMS COM IA: " + if (neural.ready) "pronta (separação de qualidade)" else "ainda não baixada (usa o separador comum, mais fraco)", color = Metal.Text, fontSize = 12.sp)
        if (!neural.ready) {
            MetalButton(
                description = "Passo 3: baixar o modelo de IA dos stems, cerca de 80 MB",
                onPress = { vm.downloadNeural() }, led = Metal.Success, ledOn = neural.busy,
                modifier = Modifier.fillMaxWidth().height(40.dp),
            ) { Text(if (neural.busy) "BAIXANDO… ${(neural.pct * 100).toInt()}%" else "BAIXAR IA (80 MB, uma vez)", color = Metal.OnMetal, fontSize = 12.sp, fontWeight = FontWeight.ExtraBold, modifier = Modifier.align(Alignment.Center)) }
        }
        Text(
            (if (devices.isNotEmpty() && mapped.isNotEmpty()) "✓ " else "• ") + "4. CONTROLADORA: " +
                when {
                    devices.isEmpty() -> "nenhuma ligada (conecte por USB; sem controladora, use a tela)"
                    mapped.isEmpty() -> "${devices.size} ligada, sem mapa: abra CONTROLADORA › MAPEAR e toque em ASSISTENTE ESSENCIAL"
                    else -> "${devices.size} ligada, ${mapped.size} controles prontos"
                },
            color = Metal.Text, fontSize = 12.sp,
        )
        Text("• 5. BACKUP: em BACKUP, guarde uma cópia antes de uma festa. O app também guarda sozinho a cada 12 horas.", color = Metal.Text, fontSize = 12.sp)
    }
}

@Composable
private fun HelpPanel() {
    Panel("COMO USAR") {
        Text("Toque num assunto para ler.", color = Metal.TextMuted, fontSize = 12.sp)
    }
    var open by androidx.compose.runtime.saveable.rememberSaveable { androidx.compose.runtime.mutableStateOf(0) }
    for ((i, t) in HELP_TOPICS.withIndex()) {
        Panel(t.first) {
            if (open == i) Text(t.second, color = Metal.Text, fontSize = 13.sp, lineHeight = 18.sp)
            else Text(t.second.take(70).trimEnd() + "…", color = Metal.TextMuted, fontSize = 12.sp, maxLines = 1)
            ChoiceRow(listOf((if (open == i) "RECOLHER" else "LER") to "Mostrar ou esconder este assunto"), -1) { open = if (open == i) -1 else i }
        }
    }
}

@Composable
private fun AboutPanel(vm: AppViewModel) {
    val ctx = androidx.compose.ui.platform.LocalContext.current
    val ver = androidx.compose.runtime.remember {
        runCatching { ctx.packageManager.getPackageInfo(ctx.packageName, 0).versionName }.getOrNull() ?: ""
    }
    Panel("SOBRE") {
        EgFullLogo(Modifier.fillMaxWidth().height(150.dp))
        Text("$APP_NAME · versão $ver", color = Metal.Text, fontSize = 13.sp, fontWeight = FontWeight.Bold, modifier = Modifier.align(Alignment.CenterHorizontally))
    }
    val upd by vm.updateStatus.collectAsStateWithLifecycle()
    val ready by vm.updateReady.collectAsStateWithLifecycle()
    Panel("ATUALIZAÇÕES") {
        Text(
            upd.ifEmpty { "Instalado pela Play Store, o app confere sozinho se há versão nova ao abrir, baixa enquanto você toca e instala quando você mandar." },
            color = Metal.TextMuted, fontSize = 12.sp,
        )
        ChoiceRow(
            listOf(
                "PROCURAR VERSÃO NOVA" to "Procurar versão nova do app na Play Store",
                (if (ready) "INSTALAR AGORA" else "SEM DOWNLOAD PRONTO") to "Instalar a versão nova já baixada (o app reinicia)",
            ),
            if (ready) 1 else -1,
        ) { if (it == 0) vm.checkUpdateNow() else if (ready) vm.installUpdateNow() }
    }
    Panel("COMPATIBILIDADE") {
        Text(
            "Funciona com a maioria das controladoras DJ, inclusive algumas bem antigas. Esse foi o propósito deste programa: " +
                "dar vida nova a controladoras que os programas de hoje deixaram de apoiar.",
            color = Metal.Text, fontSize = 13.sp,
        )
    }
    val clip = androidx.compose.runtime.remember { ctx.getSystemService(android.content.Context.CLIPBOARD_SERVICE) as? android.content.ClipboardManager }
    fun copy(label: String, text: String) {
        runCatching { clip?.setPrimaryClip(android.content.ClipData.newPlainText(label, text)); vm.say("$label copiado: $text") }
    }
    Panel("CONTATO E APOIO") {
        Text("Site: www.edgardguarda.com.br", color = Metal.Text, fontSize = 14.sp, fontWeight = FontWeight.Bold)
        Text("E-mail e Pix: edgardguarda@gmail.com", color = Metal.Text, fontSize = 14.sp, fontWeight = FontWeight.Bold)
        Text(
            "Para qualquer dúvida, sugestão ou problema, e também para doações (Pix com a chave e-mail acima). Toda ajuda mantém o programa evoluindo.",
            color = Metal.TextMuted, fontSize = 12.sp,
        )
        ChoiceRow(
            listOf(
                "COPIAR SITE" to "Copiar o endereço do site",
                "COPIAR E-MAIL / PIX" to "Copiar o e-mail, que também é a chave Pix",
            ),
            -1,
        ) { if (it == 0) copy("Site", "www.edgardguarda.com.br") else copy("E-mail / Pix", "edgardguarda@gmail.com") }
    }
}

@Composable
private fun HistoryPanel(vm: AppViewModel) {
    val hist by vm.history.collectAsStateWithLifecycle()
    Panel("HISTÓRICO DA NOITE · ${hist.size} músicas") {
        if (hist.isEmpty()) Text("As músicas que forem ao ar aparecem aqui, na ordem. Ao parar a GRAVAÇÃO, a lista é salva junto com o set.", color = Metal.TextMuted, fontSize = 12.sp)
        val fmt = java.text.SimpleDateFormat("HH:mm", java.util.Locale.ROOT)
        for ((i, p) in hist.takeLast(30).withIndex()) {
            Text(
                "${fmt.format(java.util.Date(p.atMs))}  ${p.title}${if (p.artist.isNotEmpty()) " — ${p.artist}" else ""}",
                color = if (i == hist.takeLast(30).lastIndex) Metal.Text else Metal.TextMuted, fontSize = 12.sp, maxLines = 1,
            )
        }
        ChoiceRow(
            listOf("SALVAR LISTA" to "Salvar a lista da noite em Documentos", "LIMPAR" to "Limpar o histórico da noite"),
            -1,
        ) { if (it == 0) vm.saveHistory() else vm.clearHistory() }
    }
}

@Composable
private fun BackupPanel(vm: AppViewModel) {
    val pick = androidx.activity.compose.rememberLauncherForActivityResult(
        androidx.activity.result.contract.ActivityResultContracts.OpenDocument(),
    ) { uri -> if (uri != null) vm.importBackup(uri) }
    Panel("BACKUP") {
        Text("Guarda análises, grades, hot cues, playlists e ajustes num arquivo em Documentos. As músicas continuam onde estão.", color = Metal.TextMuted, fontSize = 12.sp)
        ChoiceRow(
            listOf("SALVAR BACKUP" to "Salvar backup da biblioteca e dos ajustes", "RESTAURAR" to "Restaurar um backup salvo"),
            -1,
        ) { if (it == 0) vm.exportBackup() else pick.launch(arrayOf("application/zip", "application/octet-stream", "*/*")) }
    }
    val autos by vm.autoBackups.collectAsStateWithLifecycle()
    Panel("BACKUPS AUTOMÁTICOS") {
        Text("O app guarda sozinho um backup ao abrir (no máximo a cada 12 h), os 5 últimos, e uma cópia em Documentos/Edgard Guarda DJ Studio/backups.", color = Metal.TextMuted, fontSize = 12.sp)
        if (autos.isEmpty()) Text("O primeiro backup automático é feito alguns segundos depois de abrir o app.", color = Metal.TextMuted, fontSize = 12.sp)
        val fmt = java.text.SimpleDateFormat("dd/MM HH:mm", java.util.Locale.ROOT)
        for (f in autos) {
            Row(Modifier.fillMaxWidth().height(44.dp), horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically) {
                Text("${fmt.format(java.util.Date(f.lastModified()))} · ${f.length() / 1024} KB", color = Metal.Text, fontSize = 13.sp, modifier = Modifier.weight(1f))
                MetalButton(
                    description = "Restaurar o backup automático de ${fmt.format(java.util.Date(f.lastModified()))}",
                    onPress = { vm.importBackup(android.net.Uri.fromFile(f)) },
                    modifier = Modifier.width(120.dp).fillMaxHeight().padding(vertical = 3.dp),
                ) { Text("RESTAURAR", color = Metal.OnMetal, fontSize = 11.sp, fontWeight = FontWeight.ExtraBold, modifier = Modifier.align(Alignment.Center)) }
            }
        }
    }
}
