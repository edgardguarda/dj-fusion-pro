package app.djfusion.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import app.djfusion.ui.theme.Metal

/** Tela AJUSTES: saída de áudio, latência, quantize e visor. */
@Composable
fun SettingsScreen(vm: AppViewModel) {
    Row(Modifier.fillMaxSize().background(Metal.Bg).padding(12.dp), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
        Column(
            Modifier.weight(1f).fillMaxHeight().verticalScroll(rememberScrollState()),
            verticalArrangement = Arrangement.spacedBy(10.dp),
        ) { OutputPanel(vm) }
        Column(
            Modifier.weight(1f).fillMaxHeight().verticalScroll(rememberScrollState()),
            verticalArrangement = Arrangement.spacedBy(10.dp),
        ) {
            LatencyPanel(vm)
            PlayPanel(vm)
            DisplayPanel()
            AboutPanel()
        }
    }
}

@Composable
private fun ChoiceRow(options: List<Pair<String, String>>, selected: Int, onPick: (Int) -> Unit) {
    Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.fillMaxWidth().height(44.dp)) {
        for ((i, o) in options.withIndex()) {
            MetalButton(
                description = o.second,
                onPress = { onPick(i) },
                led = Metal.Success, ledOn = selected == i,
                modifier = Modifier.weight(1f).fillMaxHeight(),
            ) {
                Text(o.first, color = Metal.OnMetal, fontSize = 11.sp, fontWeight = FontWeight.ExtraBold, maxLines = 1, modifier = Modifier.align(Alignment.Center))
            }
        }
    }
}

@Composable
private fun LatencyPanel(vm: AppViewModel) {
    val latency by vm.latency.collectAsStateWithLifecycle()
    val status by vm.audioStatus.collectAsStateWithLifecycle()
    Panel("LATÊNCIA DO SOM") {
        Text("Quanto menor, mais rápido o som responde ao jog, aos pads e aos botões.", color = Metal.TextMuted, fontSize = 12.sp)
        ChoiceRow(
            listOf(
                "BAIXA" to "Latência baixa: resposta mais rápida (pode falhar em aparelhos lentos)",
                "NORMAL" to "Latência normal: equilíbrio entre resposta e estabilidade",
                "SEGURA" to "Latência segura: mais estável, sem estalos, resposta um pouco mais lenta",
            ),
            latency,
        ) { vm.setLatency(it) }
        Text(
            when (latency) {
                0 -> "BAIXA: ideal para scratch. Se ouvir estalos, use NORMAL."
                1 -> "NORMAL: recomendado."
                else -> "SEGURA: use se o som picotar (Bluetooth ou aparelho ocupado)."
            },
            color = Metal.Text, fontSize = 12.sp,
        )
        Text("Agora: $status", color = Metal.TextMuted, fontSize = 11.sp)
    }
}

@Composable
private fun PlayPanel(vm: AppViewModel) {
    val q by vm.quantize.collectAsStateWithLifecycle()
    Panel("TOQUE") {
        ChoiceRow(
            listOf(
                "QUANTIZE LIGADO" to "Quantize ligado: hot cues e loops presos na batida",
                "QUANTIZE DESLIGADO" to "Quantize desligado: hot cues e loops no ponto exato do toque",
            ),
            if (q) 0 else 1,
        ) { if ((it == 0) != q) vm.toggleQuantize() }
        Text("Com quantize, cues, loops e saltos caem sempre na batida mais próxima, sem atravessar o ritmo.", color = Metal.TextMuted, fontSize = 12.sp)
    }
}

@Composable
private fun DisplayPanel() {
    Panel("VISOR") {
        ChoiceRow(
            listOf("TOM CAMELOT (8A)" to "Mostrar tom em Camelot", "TOM EM LETRAS (Am)" to "Mostrar tom em letras"),
            if (DisplayPrefs.keyLetters) 1 else 0,
        ) { DisplayPrefs.keyLetters = it == 1 }
        ChoiceRow(
            listOf("TEMPO TOCADO" to "Visor mostra o tempo tocado", "TEMPO RESTANTE" to "Visor mostra o tempo que falta"),
            if (DisplayPrefs.remaining) 1 else 0,
        ) { DisplayPrefs.remaining = it == 1 }
    }
}

@Composable
private fun AboutPanel() {
    val ctx = androidx.compose.ui.platform.LocalContext.current
    val ver = androidx.compose.runtime.remember {
        runCatching { ctx.packageManager.getPackageInfo(ctx.packageName, 0).versionName }.getOrNull() ?: ""
    }
    Panel("SOBRE") {
        EgFullLogo(Modifier.fillMaxWidth().height(150.dp))
        Text("$APP_NAME · versão $ver", color = Metal.Text, fontSize = 13.sp, fontWeight = FontWeight.Bold, modifier = Modifier.align(Alignment.CenterHorizontally))
    }
}
