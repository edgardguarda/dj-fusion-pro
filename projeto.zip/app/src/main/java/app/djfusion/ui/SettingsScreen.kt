package app.djfusion.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import app.djfusion.ui.theme.Metal

/** Seções da tela AJUSTES: uma de cada vez, escolhida na coluna da esquerda. */
private val SETTINGS_SECTIONS = listOf(
    "SOM" to "Saída de áudio, fone e latência",
    "MIXAGEM" to "Crossfader, pitch, quantize, cues automáticas e proteção",
    "PRATOS" to "Vinil e como o prato da tela responde",
    "TELA" to "Cores das ondas, tom, tempo e modo em pé",
    "NOITE" to "Músicas que tocaram hoje",
    "BACKUP" to "Guardar e restaurar biblioteca e ajustes",
    "SOBRE" to "Versão do app",
)

/** Tela AJUSTES organizada por assunto: à esquerda os assuntos, à direita só os ajustes do assunto escolhido. */
@Composable
fun SettingsScreen(vm: AppViewModel) {
    var section by androidx.compose.runtime.saveable.rememberSaveable { androidx.compose.runtime.mutableStateOf(0) }
    Row(Modifier.fillMaxSize().background(Metal.Bg).padding(12.dp), horizontalArrangement = Arrangement.spacedBy(14.dp)) {
        Column(Modifier.width(210.dp).fillMaxHeight().verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(6.dp)) {
            for ((i, sec) in SETTINGS_SECTIONS.withIndex()) {
                MetalButton(
                    description = "Seção de ajustes ${sec.first}: ${sec.second}",
                    onPress = { section = i },
                    led = Metal.DeckA, ledOn = section == i,
                    modifier = Modifier.fillMaxWidth().height(50.dp),
                ) {
                    Column(Modifier.align(Alignment.CenterStart).padding(horizontal = 12.dp)) {
                        Text(sec.first, color = if (section == i) Metal.DeckA else Metal.OnMetal, fontSize = 14.sp, fontWeight = FontWeight.ExtraBold, maxLines = 1)
                        Text(sec.second, color = Metal.TextMuted, fontSize = 9.sp, maxLines = 1)
                    }
                }
            }
        }
        Column(
            Modifier.weight(1f).fillMaxHeight().verticalScroll(rememberScrollState()),
            verticalArrangement = Arrangement.spacedBy(10.dp),
        ) {
            when (section) {
                0 -> { OutputPanel(vm); LatencyPanel(vm) }
                1 -> { MixPanel(vm); PitchPanel(vm); QuantizePanel(vm) }
                2 -> PlattersPanel(vm)
                3 -> { WavePanel(); DisplayPanel(vm) }
                4 -> HistoryPanel(vm)
                5 -> BackupPanel(vm)
                else -> AboutPanel()
            }
        }
    }
}

@Composable
private fun ChoiceRow(options: List<Pair<String, String>>, selected: Int, onPick: (Int) -> Unit) {
    Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.fillMaxWidth().height(44.dp)) {
        for ((i, o) in options.withIndex()) {
            MetalButton(
                description = o.second,
                onPress = { onPick(i) },
                led = Metal.Success, ledOn = selected == i,
                modifier = Modifier.weight(1f).fillMaxHeight(),
            ) {
                Text(o.first, color = Metal.OnMetal, fontSize = 11.sp, fontWeight = FontWeight.ExtraBold, maxLines = 1, modifier = Modifier.align(Alignment.Center))
            }
        }
    }
}

@Composable
private fun LatencyPanel(vm: AppViewModel) {
    val latency by vm.latency.collectAsStateWithLifecycle()
    val status by vm.audioStatus.collectAsStateWithLifecycle()
    Panel("LATÊNCIA DO SOM") {
        Text("Quanto menor, mais rápido o som responde ao jog, aos pads e aos botões.", color = Metal.TextMuted, fontSize = 12.sp)
        ChoiceRow(
            listOf(
                "BAIXA" to "Latência baixa: resposta mais rápida (pode falhar em aparelhos lentos)",
                "NORMAL" to "Latência normal: equilíbrio entre resposta e estabilidade",
                "SEGURA" to "Latência segura: mais estável, sem estalos, resposta um pouco mais lenta",
            ),
            latency,
        ) { vm.setLatency(it) }
        Text(
            when (latency) {
                0 -> "BAIXA: ideal para scratch. Se ouvir estalos, use NORMAL."
                1 -> "NORMAL: recomendado."
                else -> "SEGURA: use se o som picotar (Bluetooth ou aparelho ocupado)."
            },
            color = Metal.Text, fontSize = 12.sp,
        )
        Text("Agora: $status", color = Metal.TextMuted, fontSize = 11.sp)
    }
}

@Composable
private fun PitchPanel(vm: AppViewModel) {
    val pr by vm.defaultPitch.collectAsStateWithLifecycle()
    Panel("PITCH (FAIXA DO FADER)") {
        val opts = AppViewModel.PITCH_RANGES
        ChoiceRow(
            opts.map { (if (it >= 100) "WIDE ±100" else "±$it%") to "Faixa padrão do pitch ±$it%" },
            opts.indexOf(pr),
        ) { vm.setDefaultPitch(opts[it]) }
        Text("±8 e ±16: ajuste fino para mixar. ±25 e ±50: efeitos e gêneros bem diferentes. WIDE: de parado até o dobro da velocidade. No deck, toque na etiqueta em cima do fader para trocar só aquele deck.", color = Metal.TextMuted, fontSize = 12.sp)
    }
}

@Composable
private fun PlattersPanel(vm: AppViewModel) {
    val vinyl by vm.vinyl.collectAsStateWithLifecycle()
    Panel("PRATOS (JOG)") {
        ChoiceRow(
            listOf(
                "VINIL LIGADO" to "Modo vinil ligado: tocar no disco faz scratch, a borda empurra",
                "VINIL DESLIGADO" to "Modo vinil desligado: o prato só empurra e segura a música",
            ),
            if (vinyl) 0 else 1,
        ) { if ((it == 0) != vinyl) vm.toggleVinyl() }
        Text("Com a música parada, girar o prato procura o ponto exato. Tocando: o meio do disco faz scratch (com VINIL) e a borda adianta ou atrasa a batida.", color = Metal.TextMuted, fontSize = 12.sp)
        Text("Prato da controladora: calibrar, codificação e BUSCA ficam na aba CONTROLADORA.", color = Metal.Text, fontSize = 12.sp)
    }
}

@Composable
private fun QuantizePanel(vm: AppViewModel) {
    val q by vm.quantize.collectAsStateWithLifecycle()
    Panel("TOQUE NA BATIDA (QUANTIZE)") {
        ChoiceRow(
            listOf(
                "QUANTIZE LIGADO" to "Quantize ligado: hot cues e loops presos na batida",
                "QUANTIZE DESLIGADO" to "Quantize desligado: hot cues e loops no ponto exato do toque",
            ),
            if (q) 0 else 1,
        ) { if ((it == 0) != q) vm.toggleQuantize() }
        Text("Com quantize, cues, loops e saltos caem sempre na batida mais próxima, sem atravessar o ritmo.", color = Metal.TextMuted, fontSize = 12.sp)
    }
    val smart by vm.smartGrid.collectAsStateWithLifecycle()
    Panel("GRADE INTELIGENTE (ANDAMENTO VARIÁVEL)") {
        ChoiceRow(
            listOf(
                "GRADE INTELIGENTE LIGADA" to "Grade inteligente ligada: em músicas que mudam de andamento, a grade segue cada trecho",
                "GRADE INTELIGENTE DESLIGADA" to "Grade inteligente desligada: uma grade só por música",
            ),
            if (smart) 0 else 1,
        ) { if ((it == 0) != smart) vm.toggleSmartGrid() }
        Text(
            "Montagens, medleys e gravações ao vivo mudam de velocidade. O app mede o andamento ao longo da música e, ligado, troca a grade " +
                "de cada trecho na hora certa (SYNC, loops, saltos e o AUTO DJ seguem o trecho). O deck mostra ANDAM. VARIÁVEL. " +
                "Se você corrigir a grade à mão (TAP, ÷2, ×2, 1 AQUI), a sua correção vale e a grade inteligente deixa essa música em paz.",
            color = Metal.TextMuted, fontSize = 12.sp,
        )
    }
}

@Composable
private fun WavePanel() {
    Panel("ONDAS: DESENHO") {
        ChoiceRow(
            listOf(
                "RGB" to "Onda RGB: cada trecho na cor do seu som (graves, médios ou agudos)",
                "3 BANDAS" to "Onda em 3 bandas: graves, médios e agudos em camadas, cada um com sua altura",
                "CONTORNO" to "Onda em contorno: corpo numa cor e borda clara, desenho mais limpo",
            ),
            DisplayPrefs.waveType,
        ) { DisplayPrefs.waveType = it }
        Text("RGB: mostra o caráter de cada trecho. 3 BANDAS: vê bumbo, voz e pratos separados (bom para achar o break e o drop). CONTORNO: visual limpo.", color = Metal.TextMuted, fontSize = 12.sp)
    }
    Panel("ONDAS: CORES") {
        ChoiceRow(
            listOf(
                "VERMELHO" to "Ondas em tons de vermelho: graves escuros, agudos claros",
                "CINZA" to "Ondas em tons de cinza: graves grafite, agudos prata",
                "ESPECTRO" to "Ondas coloridas pelo espectro: graves vermelhos, médios verdes, agudos azuis",
            ),
            if (DisplayPrefs.waveStyle <= 2) DisplayPrefs.waveStyle else -1,
        ) { DisplayPrefs.waveStyle = it }
        ChoiceRow(
            listOf(
                "AZUL GELO" to "Ondas em tons de azul: graves azul escuro, agudos quase brancos",
                "ÂMBAR" to "Ondas em tons de âmbar: graves laranja, agudos dourados",
            ),
            if (DisplayPrefs.waveStyle >= 3) DisplayPrefs.waveStyle - 3 else -1,
        ) { DisplayPrefs.waveStyle = 3 + it }
        Text("Em todas as cores: quanto mais claro, mais agudo (pratos, vozes); mais escuro e cheio, mais grave (bumbo, baixo).", color = Metal.TextMuted, fontSize = 12.sp)
    }
}

@Composable
private fun MixPanel(vm: AppViewModel) {
    val curve by vm.xfCurve.collectAsStateWithLifecycle()
    val autoCues by vm.autoCues.collectAsStateWithLifecycle()
    val guard by vm.silenceGuard.collectAsStateWithLifecycle()
    Panel("MIXAGEM") {
        Text("Curva do crossfader", color = Metal.Text, fontSize = 12.sp, fontWeight = FontWeight.Bold)
        ChoiceRow(
            listOf(
                "SUAVE" to "Crossfader suave: transições longas sem buraco no volume",
                "MIXAGEM" to "Crossfader mixagem: as duas músicas cheias no meio",
                "CORTE" to "Crossfader corte: abre logo no começo do curso, para scratch",
            ),
            curve,
        ) { vm.setXfCurve(it) }
        ChoiceRow(
            listOf(
                "CUES AUTO LIGADAS" to "Cues automáticas ligadas: INÍCIO, GROOVE, DROP e SAÍDA em músicas sem cues",
                "CUES AUTO DESLIGADAS" to "Cues automáticas desligadas",
            ),
            if (autoCues) 0 else 1,
        ) { vm.setAutoCues(it == 0) }
        ChoiceRow(
            listOf(
                "PROTEÇÃO LIGADA" to "Proteção contra silêncio ligada: o final entra em loop se nada mais estiver tocando",
                "PROTEÇÃO DESLIGADA" to "Proteção contra silêncio desligada",
            ),
            if (guard) 0 else 1,
        ) { vm.setSilenceGuard(it == 0) }
        Text(
            "Cues automáticas: ao carregar uma música sem cues, as hot cues 1–4 marcam onde ela começa, onde entra a batida, o drop e a saída. " +
                "Proteção contra silêncio: se a música chegar ao fim e o outro deck estiver parado, o último compasso fica em loop no tempo até você soltar.",
            color = Metal.TextMuted, fontSize = 12.sp,
        )
    }
}

@Composable
private fun DisplayPanel(vm: AppViewModel) {
    Panel("VISOR") {
        ChoiceRow(
            listOf("TOM CAMELOT (8A)" to "Mostrar tom em Camelot", "TOM EM LETRAS (Am)" to "Mostrar tom em letras"),
            if (DisplayPrefs.keyLetters) 1 else 0,
        ) { DisplayPrefs.keyLetters = it == 1 }
        ChoiceRow(
            listOf("TEMPO TOCADO" to "Visor mostra o tempo tocado", "TEMPO RESTANTE" to "Visor mostra o tempo que falta"),
            if (DisplayPrefs.remaining) 1 else 0,
        ) { DisplayPrefs.remaining = it == 1 }
        val portrait by vm.portrait.collectAsStateWithLifecycle()
        val ctx = androidx.compose.ui.platform.LocalContext.current
        ChoiceRow(
            listOf("SEMPRE DEITADO" to "Tela sempre deitada (paisagem)", "GIRA EM PÉ" to "Liberar modo retrato: tela compacta com o celular em pé"),
            if (portrait) 1 else 0,
        ) { vm.setPortrait(it == 1, ctx as? android.app.Activity) }
    }
}

@Composable
private fun AboutPanel() {
    val ctx = androidx.compose.ui.platform.LocalContext.current
    val ver = androidx.compose.runtime.remember {
        runCatching { ctx.packageManager.getPackageInfo(ctx.packageName, 0).versionName }.getOrNull() ?: ""
    }
    Panel("SOBRE") {
        EgFullLogo(Modifier.fillMaxWidth().height(150.dp))
        Text("$APP_NAME · versão $ver", color = Metal.Text, fontSize = 13.sp, fontWeight = FontWeight.Bold, modifier = Modifier.align(Alignment.CenterHorizontally))
    }
}

@Composable
private fun HistoryPanel(vm: AppViewModel) {
    val hist by vm.history.collectAsStateWithLifecycle()
    Panel("HISTÓRICO DA NOITE · ${hist.size} músicas") {
        if (hist.isEmpty()) Text("As músicas que forem ao ar aparecem aqui, na ordem. Ao parar a GRAVAÇÃO, a lista é salva junto com o set.", color = Metal.TextMuted, fontSize = 12.sp)
        val fmt = java.text.SimpleDateFormat("HH:mm", java.util.Locale.ROOT)
        for ((i, p) in hist.takeLast(30).withIndex()) {
            Text(
                "${fmt.format(java.util.Date(p.atMs))}  ${p.title}${if (p.artist.isNotEmpty()) " — ${p.artist}" else ""}",
                color = if (i == hist.takeLast(30).lastIndex) Metal.Text else Metal.TextMuted, fontSize = 12.sp, maxLines = 1,
            )
        }
        ChoiceRow(
            listOf("SALVAR LISTA" to "Salvar a lista da noite em Documentos", "LIMPAR" to "Limpar o histórico da noite"),
            -1,
        ) { if (it == 0) vm.saveHistory() else vm.clearHistory() }
    }
}

@Composable
private fun BackupPanel(vm: AppViewModel) {
    val pick = androidx.activity.compose.rememberLauncherForActivityResult(
        androidx.activity.result.contract.ActivityResultContracts.OpenDocument(),
    ) { uri -> if (uri != null) vm.importBackup(uri) }
    Panel("BACKUP") {
        Text("Guarda análises, grades, hot cues, playlists e ajustes num arquivo em Documentos. As músicas continuam onde estão.", color = Metal.TextMuted, fontSize = 12.sp)
        ChoiceRow(
            listOf("SALVAR BACKUP" to "Salvar backup da biblioteca e dos ajustes", "RESTAURAR" to "Restaurar um backup salvo"),
            -1,
        ) { if (it == 0) vm.exportBackup() else pick.launch(arrayOf("application/zip", "application/octet-stream", "*/*")) }
    }
    val autos by vm.autoBackups.collectAsStateWithLifecycle()
    Panel("BACKUPS AUTOMÁTICOS") {
        Text("O app guarda sozinho um backup ao abrir (no máximo a cada 12 h), os 5 últimos, e uma cópia em Documentos/Edgard Guarda DJ Studio/backups.", color = Metal.TextMuted, fontSize = 12.sp)
        if (autos.isEmpty()) Text("O primeiro backup automático é feito alguns segundos depois de abrir o app.", color = Metal.TextMuted, fontSize = 12.sp)
        val fmt = java.text.SimpleDateFormat("dd/MM HH:mm", java.util.Locale.ROOT)
        for (f in autos) {
            Row(Modifier.fillMaxWidth().height(44.dp), horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically) {
                Text("${fmt.format(java.util.Date(f.lastModified()))} · ${f.length() / 1024} KB", color = Metal.Text, fontSize = 13.sp, modifier = Modifier.weight(1f))
                MetalButton(
                    description = "Restaurar o backup automático de ${fmt.format(java.util.Date(f.lastModified()))}",
                    onPress = { vm.importBackup(android.net.Uri.fromFile(f)) },
                    modifier = Modifier.width(120.dp).fillMaxHeight().padding(vertical = 3.dp),
                ) { Text("RESTAURAR", color = Metal.OnMetal, fontSize = 11.sp, fontWeight = FontWeight.ExtraBold, modifier = Modifier.align(Alignment.Center)) }
            }
        }
    }
}
