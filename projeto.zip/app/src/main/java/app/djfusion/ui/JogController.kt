package app.djfusion.ui

import android.content.SharedPreferences
import app.djfusion.audio.NativeEngine
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

/**
 * Jog wheel de controladoras. A cada passo girado o app calcula a velocidade do giro:
 * - com o dedo no prato (ou com o deck parado) vira scratch: a música anda para frente e para trás com a mão;
 * - com o deck tocando e sem tocar no prato vira ajuste fino: girar para frente acelera um pouco, para trás freia.
 * Quantos passos a controladora manda por volta varia por modelo, então é ajustável ([ticksPerRev]).
 */
class JogController(
    private val prefs: SharedPreferences,
    private val vm: AppViewModel,
    private val scope: CoroutineScope,
) {
    var ticksPerRev: Int = prefs.getInt("tpr", 128).coerceIn(32, 1024)
        private set

    /** Força do ajuste fino (girar a borda com a música tocando): 0,25 a 3 (1 = normal). */
    var bendGain: Float = prefs.getFloat("bend", 1f).coerceIn(0.25f, 3f)
        private set

    fun setBendGain(v: Float) {
        bendGain = v.coerceIn(0.25f, 3f)
        prefs.edit().putFloat("bend", bendGain).apply()
    }

    fun setTicksPerRev(v: Int) {
        ticksPerRev = v.coerceIn(32, 1024)
        prefs.edit().putInt("tpr", ticksPerRev).apply()
    }

    private class State {
        var touching = false
        var vel = 0f
        var lastNs = 0L
        var mode = 0               // 0 nada, 1 scratch, 2 ajuste fino
        var watchdog: Job? = null
    }

    private val st = arrayOf(State(), State())

    /** Passos girados (positivo = para frente). */
    fun tick(deck: Int, ticks: Int) {
        if (deck !in 0..1 || ticks == 0) return
        val s = st[deck]
        val now = System.nanoTime()
        val dt = ((now - s.lastNs) / 1e9f).coerceIn(0.002f, 0.1f)
        s.lastNs = now
        // uma volta do prato = 1,8 s de música (33⅓ rpm)
        val inst = ticks * (1.8f / ticksPerRev) / dt
        s.vel = (0.55f * s.vel + 0.45f * inst).coerceIn(-8f, 8f)
        val d = vm.decks.value[deck]
        if (!d.loaded) return
        // VINIL ligado: dedo em cima do prato = scratch. Desligado: tocando, o prato só empurra/segura
        if ((s.touching && vm.vinyl.value) || !d.playing) {
            s.mode = 1
            vm.scratch(deck, true, s.vel)
        } else {
            s.mode = 2
            val bend = (s.vel * 0.12f * bendGain).coerceIn(-0.3f, 0.3f)
            NativeEngine.nativeSetRate(deck, d.rate * (1f + bend))
        }
        s.watchdog?.cancel()
        s.watchdog = scope.launch {
            delay(90)
            s.vel = 0f
            when (s.mode) {
                1 -> if (s.touching) vm.scratch(deck, true, 0f) else vm.scratch(deck, false, 0f)
                2 -> NativeEngine.nativeSetRate(deck, vm.decks.value[deck].rate)
            }
            if (!s.touching) s.mode = 0
        }
    }

    /** Dedo encostou (true) ou saiu (false) do prato. */
    fun touch(deck: Int, on: Boolean) {
        if (deck !in 0..1) return
        val s = st[deck]
        s.touching = on
        s.vel = 0f
        s.lastNs = System.nanoTime()
        if (on) {
            val d = vm.decks.value[deck]
            if (d.loaded && (vm.vinyl.value || !d.playing)) {
                s.mode = 1
                vm.scratch(deck, true, 0f)
            }
        } else if (s.mode == 1) {
            s.watchdog?.cancel()
            vm.scratch(deck, false, 0f)
            s.mode = 0
        }
    }
}
