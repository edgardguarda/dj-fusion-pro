package app.djfusion.ui

import android.content.SharedPreferences
import android.os.Handler
import android.os.Looper
import app.djfusion.audio.NativeEngine
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

/**
 * Jog wheel de controladoras, sem atraso: cada passo girado vira deslocamento exato da música no motor
 * (o motor leva a agulha até lá em ~10 ms), em vez de estimar velocidade pelo tempo entre mensagens.
 * - dedo no prato (com VINIL) ou deck parado: scratch, a música vai e volta exatamente com a mão e para quando ela para;
 * - tocando sem encostar (ou VINIL desligado): empurrão, adianta/atrasa a batida proporcional ao giro;
 * - BUSCA: o prato corre a música 20 vezes mais rápido, sem som (achar um ponto numa música longa).
 * Chamado direto da linha de MIDI (não espera a tela): só usa o motor e valores lidos de StateFlow.
 */
class JogController(
    private val prefs: SharedPreferences,
    private val vm: AppViewModel,
    @Suppress("UNUSED_PARAMETER") scope: CoroutineScope,
) {
    @Volatile var ticksPerRev: Int = prefs.getInt("tpr", 128).coerceIn(32, 4096)
        private set

    /** Força do empurrão (girar a borda com a música tocando): 0,25 a 3 (1 = normal: uma volta = 0,3 s). */
    @Volatile var bendGain: Float = prefs.getFloat("bend", 1f).coerceIn(0.25f, 3f)
        private set

    fun setBendGain(v: Float) {
        bendGain = v.coerceIn(0.25f, 3f)
        prefs.edit().putFloat("bend", bendGain).apply()
    }

    fun setTicksPerRev(v: Int) {
        ticksPerRev = v.coerceIn(32, 4096)
        prefs.edit().putInt("tpr", ticksPerRev).apply()
    }

    private val main = Handler(Looper.getMainLooper())

    private class State {
        @Volatile var touching = false
        @Volatile var scratching = false
        @Volatile var searchTarget = -1L
        @Volatile var searchAt = 0L
        @Volatile var vel = 0.0          // velocidade do prato em quadros por ms (média dos últimos giros)
        @Volatile var velAt = 0L
        @Volatile var coasting = false   // prato "rodando solto" (BACKSPIN ou tensão) depois de soltar o disco
        @Volatile var coastV = 0.0
        @Volatile var acc = 0            // passos acumulados nos modos GRADE, LOOP, EFEITO e LISTA
        @Volatile var flushAt = 0L
        var releaser: Runnable? = null
    }

    private val st = Array(4) { State() }

    // ------------------------------------------------------------ BUSCA

    private val _search = MutableStateFlow(List(4) { false })
    /** Modo BUSCA de cada deck: o prato corre a música rápido, sem som. */
    val search: StateFlow<List<Boolean>> = _search.asStateFlow()
    fun setSearch(deck: Int, on: Boolean) {
        if (deck !in 0..3) return
        if (on) setMode(deck, MODE_SEARCH) else if (_mode.value[deck] == MODE_SEARCH) setMode(deck, MODE_NORMAL)
    }

    // ------------------------------------------------------------ modos do prato

    private val _mode = MutableStateFlow(List(4) { MODE_NORMAL })
    /** O que o giro do prato faz em cada deck: 0 NORMAL (scratch/empurrão), 1 BUSCA, 2 GRADE, 3 LOOP SAÍDA, 4 LOOP ENTRADA, 5 EFEITO, 6 LISTA. */
    val mode: StateFlow<List<Int>> = _mode.asStateFlow()

    fun setMode(deck: Int, m: Int) {
        if (deck !in 0..3) return
        val mm = m.coerceIn(0, MODE_NAMES.size - 1)
        _mode.value = _mode.value.mapIndexed { i, v -> if (i == deck) mm else v }
        _search.value = _search.value.mapIndexed { i, v -> if (i == deck) mm == MODE_SEARCH else v }
        st[deck].acc = 0
    }

    /** Próximo modo do prato do deck (volta ao NORMAL depois do último). */
    fun cycleMode(deck: Int): Int {
        val next = (_mode.value[deck] + 1) % MODE_NAMES.size
        setMode(deck, next)
        return next
    }

    /** Tensão do prato: 0 SOLTO (o disco para na hora), 1 MÉDIO, 2 PESADO (o disco continua girando um pouco depois de soltar). */
    @Volatile var tension: Int = prefs.getInt("tension", 0).coerceIn(0, 2)
        private set

    fun setTension(v: Int) {
        tension = v.coerceIn(0, 2)
        prefs.edit().putInt("tension", tension).apply()
    }

    private fun tensionTauMs(): Double = when (tension) { 1 -> 140.0; 2 -> 320.0; else -> 0.0 }

    // ------------------------------------------------------------ calibração (passos por volta)

    @Volatile private var calibDeck = -1
    @Volatile private var calibSum = 0
    private val _calib = MutableStateFlow(-1)
    /** Passos contados na calibração em andamento (-1 = sem calibração). */
    val calibration: StateFlow<Int> = _calib.asStateFlow()
    fun startCalibration(deck: Int) { calibSum = 0; calibDeck = deck; _calib.value = 0 }
    fun cancelCalibration() { calibDeck = -1; _calib.value = -1 }
    /** Termina a calibração: o total de passos de uma volta vira o novo valor. Retorna o valor ou -1. */
    fun finishCalibration(): Int {
        val n = calibSum
        calibDeck = -1
        _calib.value = -1
        if (n < 32) return -1
        setTicksPerRev(n)
        return n
    }

    // ------------------------------------------------------------ giro e toque

    /** Quadros da música por passo do prato (uma volta = 1,8 s, como um disco de 33⅓ rpm). */
    private fun framesPerTick(): Double = NativeEngine.SAMPLE_RATE * 1.8 / ticksPerRev

    /** Passos girados (positivo = para frente). Pode ser chamado de qualquer linha. */
    fun tick(deck: Int, ticks: Int) {
        if (deck !in 0..3 || ticks == 0) return
        if (calibDeck == deck) { calibSum += kotlin.math.abs(ticks); _calib.value = calibSum; return }
        val d = vm.decks.value[deck]
        if (!d.loaded || d.loading) return
        val s = st[deck]
        val frames = ticks * framesPerTick()
        trackVelocity(s, frames)
        val m = _mode.value[deck]
        if (m >= MODE_GRID) { modeTick(deck, m, ticks); return }
        when {
            m == MODE_SEARCH -> searchMove(deck, frames, d.lengthFrames)
            (s.touching && vm.vinyl.value) || !d.playing -> {
                s.coasting = false
                if (!s.scratching) {
                    s.scratching = true
                    main.post { vm.jogScratchBegin(deck) }
                }
                NativeEngine.nativeScratchMove(deck, frames)
                // controladora sem sensor de toque: solta o disco 120 ms depois do último passo
                if (!s.touching) scheduleRelease(deck, 90)
            }
            else -> NativeEngine.nativeNudge(deck, frames * (0.3 / 1.8) * bendGain)
        }
    }

    /** "Prato com SHIFT": gira em BUSCA (corre a música rápido, sem som) mesmo com o prato em outro modo. */
    fun tickSearch(deck: Int, ticks: Int) {
        if (deck !in 0..3 || ticks == 0) return
        val d = vm.decks.value[deck]
        if (!d.loaded || d.loading) return
        searchMove(deck, ticks * framesPerTick(), d.lengthFrames)
    }

    private fun searchMove(deck: Int, frames: Double, length: Long) {
        val s = st[deck]
        // giro contínuo soma no alvo anterior (o motor ainda pode não ter chegado lá); parado 200 ms, recomeça da posição
        val now = android.os.SystemClock.uptimeMillis()
        val base = if (now - s.searchAt < 200 && s.searchTarget >= 0) s.searchTarget else {
            val buf = LongArray(4)
            NativeEngine.nativeDeckState(deck, buf)
            buf[1]
        }
        val target = (base + frames * 20).toLong().coerceIn(0L, (length - 1).coerceAtLeast(0L))
        s.searchTarget = target
        s.searchAt = now
        NativeEngine.nativeSeek(deck, target)
    }

    /** Velocidade do giro (quadros por ms), suavizada: serve para o BACKSPIN e para o disco continuar girando ao soltar. */
    private fun trackVelocity(s: State, frames: Double) {
        val now = android.os.SystemClock.uptimeMillis()
        val gap = now - s.velAt
        val inst = frames / gap.coerceIn(3L, 40L).toDouble()
        s.vel = (if (gap > 80) inst * 0.5 else s.vel * 0.6 + inst * 0.4).coerceIn(-1500.0, 1500.0)
        s.velAt = now
    }

    /** GRADE, LOOP, EFEITO e LISTA: o giro vira ajuste fino, aplicado no máximo 20 vezes por segundo. */
    private fun modeTick(deck: Int, m: Int, ticks: Int) {
        val s = st[deck]
        s.acc += ticks
        val now = android.os.SystemClock.uptimeMillis()
        if (now - s.flushAt < 50) return
        val acc = s.acc
        when (m) {
            MODE_GRID -> {                 // 2 passos do prato = 5 ms de grade
                val steps = acc / 2
                if (steps == 0) return
                s.acc = acc - steps * 2
                main.post { vm.nudgeGrid(deck, steps) }
            }
            MODE_LOOP_OUT, MODE_LOOP_IN -> {   // 1 passo = 2 ms
                s.acc = 0
                val frames = acc.toLong() * NativeEngine.SAMPLE_RATE / 500
                main.post { vm.loopAdjust(deck, frames, if (m == MODE_LOOP_OUT) 1 else 0) }
            }
            MODE_FX -> {                   // uma volta inteira = 100% do efeito
                s.acc = 0
                val delta = acc.toFloat() / ticksPerRev
                main.post { vm.setFxAmount(deck, vm.decks.value[deck].selFxAmount + delta) }
            }
            MODE_LIST -> {                 // 6 passos = 1 música
                val steps = acc / 6
                if (steps == 0) return
                s.acc = acc - steps * 6
                main.post { vm.browse(steps) }
            }
        }
        s.flushAt = now
    }

    private fun scheduleRelease(deck: Int, ms: Long) {
        val s = st[deck]
        s.releaser?.let { main.removeCallbacks(it) }
        val r = Runnable { if (!s.touching && s.scratching && !s.coasting) releaseDisk(deck) }
        s.releaser = r
        main.postDelayed(r, ms)
    }

    /**
     * Solta o disco. Se o prato foi virado rápido para trás, é BACKSPIN (o disco gira para trás e vai freando);
     * com tensão MÉDIO/PESADO o disco continua girando um pouco, como num toca-discos, antes de voltar ao ritmo.
     */
    private fun releaseDisk(deck: Int) {
        val s = st[deck]
        s.releaser?.let { main.removeCallbacks(it) }
        val d = vm.decks.value[deck]
        val normal = NativeEngine.SAMPLE_RATE / 1000.0
        val fresh = android.os.SystemClock.uptimeMillis() - s.velAt < 300
        val tau = tensionTauMs()
        when {
            d.playing && fresh && s.vel < -normal * 6 -> startCoast(deck, s.vel, 380.0, 0.0)
            d.playing && fresh && tau > 0.0 && kotlin.math.abs(s.vel - normal) > normal * 0.3 -> startCoast(deck, s.vel, tau, normal)
            else -> endDisk(deck)
        }
    }

    private fun endDisk(deck: Int) {
        val s = st[deck]
        s.coasting = false
        s.scratching = false
        vm.jogScratchEnd(deck)
        NativeEngine.nativeScratch(deck, false, 0f)
    }

    /** O prato roda sozinho da velocidade [v0] (quadros/ms) até a velocidade [target], em ~[tauMs] ms, e então a música volta ao normal. */
    private fun startCoast(deck: Int, v0: Double, tauMs: Double, target: Double) {
        val s = st[deck]
        s.coasting = true
        s.coastV = v0
        val step = 10L
        val r = object : Runnable {
            override fun run() {
                if (!s.coasting) return
                val d = vm.decks.value[deck]
                s.coastV = target + (s.coastV - target) * kotlin.math.exp(-step / tauMs)
                if (kotlin.math.abs(s.coastV - target) < 6.0 || !d.loaded || s.touching) { endDisk(deck); return }
                NativeEngine.nativeScratchMove(deck, s.coastV * step)
                main.postDelayed(this, step)
            }
        }
        main.post(r)
    }

    /** BACKSPIN com um botão: o disco gira rápido para trás e vai freando, depois a música volta. */
    fun backspin(deck: Int) {
        if (deck !in 0..3) return
        val d = vm.decks.value[deck]
        if (!d.loaded || d.loading || !d.playing) return
        val s = st[deck]
        if (!s.scratching) {
            s.scratching = true
            vm.jogScratchBegin(deck)
        }
        NativeEngine.nativeScratchMove(deck, 0.0)
        startCoast(deck, -NativeEngine.SAMPLE_RATE / 1000.0 * 10, 380.0, 0.0)
    }

    /** Prato da tela solto girando: rápido para trás (mais de 4x) com a música tocando vira BACKSPIN. */
    fun fling(deck: Int, speed: Float): Boolean {
        if (deck !in 0..3 || speed > -4f) return false
        val d = vm.decks.value[deck]
        if (!d.loaded || d.loading || !d.playing) return false
        val s = st[deck]
        if (!s.scratching) { s.scratching = true; vm.jogScratchBegin(deck) }
        NativeEngine.nativeScratchMove(deck, 0.0)
        s.touching = false
        startCoast(deck, speed.toDouble() * NativeEngine.SAMPLE_RATE / 1000.0, 380.0, 0.0)
        return true
    }

    /** Dedo encostou de novo no prato da tela: a inércia do backspin para. */
    fun stopCoast(deck: Int) { if (deck in 0..3) st[deck].coasting = false }

    private val touchOff = arrayOfNulls<Runnable>(4)

    /** Dedo encostou (true) ou saiu (false) do prato. Pode ser chamado de qualquer linha. */
    fun touch(deck: Int, on: Boolean) {
        if (deck !in 0..3) return
        val s = st[deck]
        if (on) {
            // o sensor de toque dessas controladoras "treme" (solta e encosta várias vezes em 100 ms): encostar de novo cancela a soltura pendente
            touchOff[deck]?.let { main.removeCallbacks(it) }
            touchOff[deck] = null
            s.touching = true
            s.coasting = false
            val d = vm.decks.value[deck]
            if (d.loaded && !d.loading && _mode.value[deck] == MODE_NORMAL && (vm.vinyl.value || !d.playing)) {
                // segura o disco: a agulha para onde está (como a mão num vinil)
                if (!s.scratching) {
                    s.scratching = true
                    main.post { vm.jogScratchBegin(deck) }
                }
                NativeEngine.nativeScratchMove(deck, 0.0)
            }
        } else {
            // só vale soltar se ficar solto por 60 ms; senão era o tremor do sensor
            touchOff[deck]?.let { main.removeCallbacks(it) }
            val r = Runnable { touchOff[deck] = null; finishTouch(deck) }
            touchOff[deck] = r
            main.postDelayed(r, 60)
        }
    }

    private fun finishTouch(deck: Int) {
        val s = st[deck]
        s.touching = false
        if (s.scratching && !s.coasting) releaseDisk(deck)
    }

    companion object {
        const val MODE_NORMAL = 0
        const val MODE_SEARCH = 1
        const val MODE_GRID = 2
        const val MODE_LOOP_OUT = 3
        const val MODE_LOOP_IN = 4
        const val MODE_FX = 5
        const val MODE_LIST = 6
        val MODE_NAMES = listOf("PRATO", "BUSCA", "GRADE", "LOOP ▶", "LOOP ◀", "FX", "LISTA")
        val MODE_HELP = listOf(
            "Prato normal: scratch no meio do disco (modo VINIL), empurrão na borda.",
            "BUSCA: girar corre a música 20 vezes mais rápido, sem som.",
            "GRADE: girar move a grade de batidas da música, 5 ms por passo.",
            "LOOP SAÍDA: girar encurta ou alonga o fim do loop em passos de 2 ms.",
            "LOOP ENTRADA: girar move o início do loop em passos de 2 ms.",
            "FX: girar muda a intensidade do efeito do deck (uma volta = 100%).",
            "LISTA: girar rola pela biblioteca de músicas.",
        )
    }
}
