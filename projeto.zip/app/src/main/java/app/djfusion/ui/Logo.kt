package app.djfusion.ui

import androidx.compose.foundation.Image
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.res.painterResource
import app.djfusion.R
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import app.djfusion.ui.theme.Metal

const val APP_NAME = "Edgard Guarda DJ Studio"

/**
 * Logotipo oficial do Edgard Guarda DJ Studio (EG no disco com aro vermelho), versão para fundo escuro.
 * O parâmetro [ring] ficou por compatibilidade: o logotipo é sempre desenhado inteiro.
 */
@Suppress("UNUSED_PARAMETER")
@Composable
fun EgMark(modifier: Modifier = Modifier, ring: Boolean = true) {
    Image(
        painter = painterResource(R.drawable.logo_mark_dark),
        contentDescription = "Logotipo $APP_NAME",
        contentScale = ContentScale.Fit,
        modifier = modifier,
    )
}

/** Logotipo completo (marca + EDGARD GUARDA + DJ STUDIO), para a tela de ajustes / sobre. */
@Composable
fun EgFullLogo(modifier: Modifier = Modifier) {
    Image(
        painter = painterResource(R.drawable.logo_full_dark),
        contentDescription = "Logotipo $APP_NAME",
        contentScale = ContentScale.Fit,
        modifier = modifier,
    )
}

/** Marca + nome, para a barra de cima. */
@Composable
fun BrandTitle(markSize: Dp = 38.dp) {
    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp), modifier = Modifier.padding(horizontal = 8.dp)) {
        EgMark(Modifier.size(markSize))
        Column {
            Text("EDGARD GUARDA", color = Metal.Text, fontSize = 10.sp, fontWeight = FontWeight.ExtraBold, letterSpacing = 1.sp, maxLines = 1)
            Text("DJ STUDIO", color = Metal.DeckA, fontSize = 10.sp, fontWeight = FontWeight.ExtraBold, letterSpacing = 2.sp, maxLines = 1)
        }
    }
}
