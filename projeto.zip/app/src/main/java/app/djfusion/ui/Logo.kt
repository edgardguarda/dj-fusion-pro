package app.djfusion.ui

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.drawText
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.rememberTextMeasurer
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import app.djfusion.ui.theme.Metal
import kotlin.math.min

const val APP_NAME = "Edgard Guarda DJ Studio"

/**
 * Marca do Edgard Guarda DJ Studio: disco com aro prateado, sulcos, aro vermelho e selo vermelho com "EG".
 * O mesmo desenho do ícone do aplicativo. [ring] = false desenha só o selo (para o centro dos pratos).
 */
@Composable
fun EgMark(modifier: Modifier = Modifier, ring: Boolean = true) {
    val measurer = rememberTextMeasurer()
    Canvas(modifier.semantics { contentDescription = "Logotipo $APP_NAME" }) {
        val r = min(size.width, size.height) / 2f
        val c = Offset(size.width / 2f, size.height / 2f)
        val label: Float
        if (ring) {
            drawCircle(
                Brush.sweepGradient(listOf(Color(0xFFE9ECEE), Color(0xFF8E959C), Color(0xFFD5D9DC), Color(0xFF7D848A), Color(0xFFE9ECEE)), c),
                r, c,
            )
            drawCircle(Color(0xFF0A0A0B), r * 0.88f, c)
            for (k in 1..4) drawCircle(Color.White.copy(alpha = 0.07f), r * (0.40f + 0.11f * k), c, style = Stroke(1f))
            drawCircle(Metal.DeckA, r * 0.83f, c, style = Stroke(r * 0.05f))
            label = r * 0.46f
        } else {
            label = r
        }
        drawCircle(Brush.verticalGradient(listOf(Color(0xFFFF3B3B), Color(0xFFB80F0F)), c.y - label, c.y + label), label, c)
        drawCircle(Color.White.copy(alpha = 0.25f), label, c, style = Stroke(label * 0.06f))
        val layout = measurer.measure(
            "EG",
            TextStyle(color = Color.White, fontSize = (label * 0.82f).toSp(), fontWeight = FontWeight.Black, letterSpacing = (-0.5).sp),
        )
        drawText(layout, topLeft = Offset(c.x - layout.size.width / 2f, c.y - layout.size.height / 2f))
    }
}

/** Marca + nome, para a barra de cima. */
@Composable
fun BrandTitle(markSize: Dp = 30.dp) {
    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp), modifier = Modifier.padding(horizontal = 8.dp)) {
        EgMark(Modifier.size(markSize))
        Column {
            Text("EDGARD GUARDA", color = Metal.Text, fontSize = 10.sp, fontWeight = FontWeight.ExtraBold, letterSpacing = 1.sp, maxLines = 1)
            Text("DJ STUDIO", color = Metal.DeckA, fontSize = 10.sp, fontWeight = FontWeight.ExtraBold, letterSpacing = 2.sp, maxLines = 1)
        }
    }
}
