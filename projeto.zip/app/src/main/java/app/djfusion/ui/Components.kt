package app.djfusion.ui

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.gestures.awaitEachGesture
import androidx.compose.foundation.gestures.awaitFirstDown
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.gestures.detectVerticalDragGestures
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxScope
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Paint
import androidx.compose.ui.graphics.PaintingStyle
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.PointMode
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.clipRect
import androidx.compose.ui.graphics.drawscope.rotate
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.semantics.ProgressBarRangeInfo
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.onClick
import androidx.compose.ui.semantics.progressBarRangeInfo
import androidx.compose.ui.semantics.role
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.semantics.setProgress
import androidx.compose.ui.semantics.stateDescription
import androidx.compose.ui.unit.dp
import app.djfusion.ui.theme.Metal
import kotlin.math.PI
import kotlin.math.ceil
import kotlin.math.cos
import kotlin.math.log10
import kotlin.math.max
import kotlin.math.min
import kotlin.math.roundToInt
import kotlin.math.sin
import kotlin.math.sqrt

import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.sp
import kotlin.math.abs
import kotlin.math.atan2
// ------------------------------------------------------------------ botões

/** Prata escovada: degradê de alumínio com fios horizontais finos, como a chapa de um toca-discos. */
internal fun DrawScope.drawBrushed(
    colors: List<Color>, corner: Float = 0f, lineAlpha: Float = 0.16f, dark: Boolean = false,
) {
    drawRoundRect(Brush.verticalGradient(colors), cornerRadius = CornerRadius(corner))
    val inset = corner * 0.45f
    var y = 2f
    var k = 0
    while (y < size.height - 2f) {
        val c = if (k % 2 == 0) {
            if (dark) Color.White.copy(alpha = lineAlpha * 0.5f) else Color.White.copy(alpha = lineAlpha)
        } else {
            Color.Black.copy(alpha = lineAlpha * 0.45f)
        }
        drawLine(c, Offset(inset, y), Offset(size.width - inset, y), 1f)
        y += 2.5f
        k++
    }
}

private val SilverLight = listOf(Color(0xFFE4E7EA), Color(0xFFB3B9BF), Color(0xFFCBD0D5), Color(0xFFA2A9AF))
private val SilverPressed = listOf(Color(0xFF8D949B), Color(0xFFB0B6BC))
private val BlackBrushed = listOf(Color(0xFF232427), Color(0xFF131416), Color(0xFF1B1C1F))

/** Painel de prata escovada (laterais de cada deck). */
fun Modifier.brushedSilver(): Modifier = drawBehind { drawBrushed(SilverLight, 0f, 0.18f) }

/** Painel de metal preto escovado (mesa de mixagem). */
fun Modifier.brushedBlack(): Modifier = drawBehind { drawBrushed(BlackBrushed, 0f, 0.10f, dark = true) }

internal fun DrawScope.drawMetalPlate(pressed: Boolean, enabled: Boolean, corner: Float) {
    drawBrushed(if (pressed) SilverPressed else SilverLight, corner, if (pressed) 0.06f else 0.20f)
    drawRoundRect(Color(0xFF26292D), cornerRadius = CornerRadius(corner), style = Stroke(1.2f.dp.toPx()))
    if (!pressed) {
        drawLine(Color.White.copy(alpha = 0.7f), Offset(corner, 1.5f), Offset(size.width - corner, 1.5f), 1f)
    }
    if (!enabled) drawRoundRect(Color.Black.copy(alpha = 0.38f), cornerRadius = CornerRadius(corner))
}

/**
 * Botão. Por padrão dispara no instante do toque (não ao soltar), como um botão de equipamento de DJ.
 * Com [fireOnPress] falso só dispara no toque completo, para não agir quando o dedo começa uma rolagem.
 * Quando [ledOn] é verdadeiro o botão acende na cor [led].
 */
@Composable
fun MetalButton(
    description: String,
    onPress: () -> Unit,
    modifier: Modifier = Modifier,
    enabled: Boolean = true,
    led: Color? = null,
    ledOn: Boolean = false,
    fireOnPress: Boolean = true,
    /** Toque com o botão desligado: explica por que nada aconteceu (ex.: deck sem música). */
    onDisabledPress: (() -> Unit)? = null,
    content: @Composable BoxScope.() -> Unit,
) {
    var pressed by remember { mutableStateOf(false) }
    val latest = rememberUpdatedState(onPress)
    val disabledCb = rememberUpdatedState(onDisabledPress)
    val shape = RoundedCornerShape(10.dp)
    Box(
        modifier = modifier
            .semantics {
                contentDescription = description
                role = Role.Button
                onClick {
                    if (enabled) latest.value() else disabledCb.value?.invoke()
                    true
                }
            }
            .clip(shape)
            .drawBehind {
                val corner = 10.dp.toPx()
                drawMetalPlate(pressed, enabled, corner)
                if (led != null) {
                    if (ledOn && enabled) {
                        drawRoundRect(
                            Brush.verticalGradient(listOf(led.copy(alpha = 0.40f), led.copy(alpha = 0.10f))),
                            cornerRadius = CornerRadius(corner),
                        )
                        drawRoundRect(led, cornerRadius = CornerRadius(corner), style = Stroke(2.dp.toPx()))
                    }
                    // LED indicador no canto, como nos botões de equipamento: aceso brilha, apagado fica vinho
                    val c = Offset(size.width - 9.dp.toPx(), 9.dp.toPx())
                    if (ledOn && enabled) drawCircle(led.copy(alpha = 0.35f), 7.dp.toPx(), c)
                    drawCircle(if (ledOn && enabled) led else Color(0xFF5B1212), 3.5f.dp.toPx(), c)
                    drawCircle(Color.White.copy(alpha = if (ledOn && enabled) 0.7f else 0.15f), 1.3f.dp.toPx(), Offset(c.x - 1f, c.y - 1f))
                }
            }
            .pointerInput(enabled, fireOnPress) {
                detectTapGestures(
                    onPress = {
                        if (enabled) {
                            pressed = true
                            if (fireOnPress) latest.value()
                            tryAwaitRelease()
                            pressed = false
                        }
                    },
                    onTap = {
                        if (enabled && !fireOnPress) latest.value()
                        else if (!enabled) disabledCb.value?.invoke()
                    },
                )
            },
        contentAlignment = Alignment.Center,
    ) {
        content()
    }
}

/** Triângulo de play ou duas barras de pausa. */
@Composable
fun TransportGlyph(playing: Boolean, color: Color = Metal.OnMetal, modifier: Modifier = Modifier) {
    Canvas(modifier) {
        val c = color
        val w = size.width
        val h = size.height
        if (playing) {
            drawRoundRect(c, Offset(w * 0.22f, h * 0.15f), Size(w * 0.20f, h * 0.70f), CornerRadius(w * 0.03f))
            drawRoundRect(c, Offset(w * 0.58f, h * 0.15f), Size(w * 0.20f, h * 0.70f), CornerRadius(w * 0.03f))
        } else {
            val p = Path().apply {
                moveTo(w * 0.25f, h * 0.12f)
                lineTo(w * 0.25f, h * 0.88f)
                lineTo(w * 0.85f, h * 0.50f)
                close()
            }
            drawPath(p, c)
        }
    }
}

// ----------------------------------------------------------------- knob

/**
 * Knob giratório. Arraste para cima ou para baixo; toque duas vezes para voltar ao meio.
 * [centered]: o arco colorido parte do meio (equalizador, filtro).
 */
@Composable
fun Knob(
    value: Float,
    onChange: (Float) -> Unit,
    accent: Color,
    description: String,
    modifier: Modifier = Modifier,
    centered: Boolean = true,
) {
    val latest = rememberUpdatedState(onChange)
    val cur = rememberUpdatedState(value)
    Canvas(
        modifier
            .semantics {
                contentDescription = description
                stateDescription = "${(value * 100).roundToInt()} por cento"
                progressBarRangeInfo = ProgressBarRangeInfo(value, 0f..1f)
                setProgress { v ->
                    latest.value(v.coerceIn(0f, 1f))
                    true
                }
            }
            .pointerInput(Unit) { detectTapGestures(onDoubleTap = { latest.value(0.5f) }) }
            .pointerInput(Unit) {
                var acc = 0f
                detectVerticalDragGestures(
                    onDragStart = { acc = cur.value },
                    onVerticalDrag = { change, dy ->
                        change.consume()
                        acc = (acc - dy / 200.dp.toPx()).coerceIn(0f, 1f)
                        latest.value(acc)
                    },
                )
            },
    ) {
        val d = min(size.width, size.height)
        val c = Offset(size.width / 2f, size.height / 2f)
        val ring = 3.dp.toPx()
        val r = d / 2f - ring
        val v = value.coerceIn(0f, 1f)
        val tl = Offset(c.x - r, c.y - r)
        val sz = Size(r * 2, r * 2)
        drawArc(Color(0xFF2B2D31), 135f, 270f, false, tl, sz, style = Stroke(ring, cap = StrokeCap.Round))
        if (centered) {
            val sweep = (v - 0.5f) * 270f
            if (abs(sweep) > 0.5f) drawArc(accent, 270f, sweep, false, tl, sz, style = Stroke(ring, cap = StrokeCap.Round))
        } else if (v > 0.002f) {
            drawArc(accent, 135f, v * 270f, false, tl, sz, style = Stroke(ring, cap = StrokeCap.Round))
        }
        val br = r - ring * 1.4f
        drawCircle(Color.Black.copy(alpha = 0.5f), radius = br, center = Offset(c.x, c.y + 1.5f.dp.toPx()))
        drawCircle(
            Brush.verticalGradient(listOf(Color(0xFFF3F5F6), Color(0xFFA7AEB4), Color(0xFFD3D7DB)), c.y - br, c.y + br),
            radius = br, center = c,
        )
        // serrilha da borda
        for (i in 0 until 18) {
            val ang = Math.toRadians(i * 20.0)
            val cx = cos(ang).toFloat()
            val sx = sin(ang).toFloat()
            drawLine(
                Color.Black.copy(alpha = 0.22f), Offset(c.x + cx * br * 0.80f, c.y + sx * br * 0.80f),
                Offset(c.x + cx * br * 0.98f, c.y + sx * br * 0.98f), 1.2f.dp.toPx(),
            )
        }
        drawCircle(Color(0xFF26292D), radius = br, center = c, style = Stroke(1.dp.toPx()))
        val a = Math.toRadians((135f + v * 270f).toDouble())
        val ca = cos(a).toFloat()
        val sa = sin(a).toFloat()
        drawLine(
            Color(0xFFE01818), Offset(c.x + ca * br * 0.25f, c.y + sa * br * 0.25f),
            Offset(c.x + ca * br * 0.92f, c.y + sa * br * 0.92f), 3.dp.toPx(), StrokeCap.Round,
        )
    }
}

// ----------------------------------------------------------------- faders

/**
 * Fader. Vertical: 0 embaixo, 1 em cima. Horizontal: 0 à esquerda, 1 à direita.
 * Responde ao toque no ponto exato e ao arrasto. Também aceita ajuste por leitor de tela.
 * Com [fill] a trilha se enche de cor até a alça.
 */
@Composable
fun MetalFader(
    value: Float,
    onChange: (Float) -> Unit,
    accent: Color,
    description: String,
    modifier: Modifier = Modifier,
    vertical: Boolean = true,
    fill: Boolean = false,
) {
    val latest = rememberUpdatedState(onChange)
    Canvas(
        modifier
            .semantics {
                contentDescription = description
                stateDescription = "${(value * 100).roundToInt()} por cento"
                progressBarRangeInfo = ProgressBarRangeInfo(value, 0f..1f)
                setProgress { v ->
                    latest.value(v.coerceIn(0f, 1f))
                    true
                }
            }
            .pointerInput(vertical) {
                awaitEachGesture {
                    val handleLen = (if (vertical) 26.dp else 44.dp).toPx()
                    fun toValue(p: Offset): Float = if (vertical) {
                        1f - ((p.y - handleLen / 2f) / (size.height - handleLen)).coerceIn(0f, 1f)
                    } else {
                        ((p.x - handleLen / 2f) / (size.width - handleLen)).coerceIn(0f, 1f)
                    }
                    val down = awaitFirstDown()
                    down.consume()
                    latest.value(toValue(down.position))
                    do {
                        val event = awaitPointerEvent()
                        val change = event.changes.first()
                        if (change.pressed) {
                            latest.value(toValue(change.position))
                            change.consume()
                        }
                    } while (event.changes.any { it.pressed })
                }
            },
    ) {
        val track = 6.dp.toPx()
        val handleLong = (if (vertical) 26.dp else 44.dp).toPx()
        val handleShort = (if (vertical) 32.dp else 30.dp).toPx()
        val v = value.coerceIn(0f, 1f)
        if (vertical) {
            val x = size.width / 2f
            drawRoundRect(Color(0xFF050607), Offset(x - track / 2, 0f), Size(track, size.height), CornerRadius(track / 2))
            drawRoundRect(Color(0xFF2E343A), Offset(x - track / 2, 0f), Size(track, size.height), CornerRadius(track / 2), style = Stroke(1f))
            for (i in 0..10) {
                val ty = handleLong / 2 + (size.height - handleLong) * i / 10f
                val len = if (i % 5 == 0) track * 1.9f else track * 1.1f
                drawLine(Color(0xFF6A7178), Offset(x - track / 2 - len, ty), Offset(x - track / 2 - 2f, ty), 1f)
                drawLine(Color(0xFF6A7178), Offset(x + track / 2 + 2f, ty), Offset(x + track / 2 + len, ty), 1f)
            }
            val hy = (1f - v) * (size.height - handleLong)
            if (fill) {
                val top = hy + handleLong / 2
                drawRoundRect(accent.copy(alpha = 0.85f), Offset(x - track / 2, top), Size(track, size.height - top), CornerRadius(track / 2))
            }
            drawHandle(Offset(x - handleShort / 2, hy), Size(handleShort, handleLong), accent, vertical = true)
        } else {
            val y = size.height / 2f
            drawRoundRect(Color(0xFF050607), Offset(0f, y - track / 2), Size(size.width, track), CornerRadius(track / 2))
            drawRoundRect(Color(0xFF2E343A), Offset(0f, y - track / 2), Size(size.width, track), CornerRadius(track / 2), style = Stroke(1f))
            for (i in 0..10) {
                val tx = handleLong / 2 + (size.width - handleLong) * i / 10f
                val len = if (i % 5 == 0) track * 1.9f else track * 1.1f
                drawLine(Color(0xFF6A7178), Offset(tx, y - track / 2 - len), Offset(tx, y - track / 2 - 2f), 1f)
                drawLine(Color(0xFF6A7178), Offset(tx, y + track / 2 + 2f), Offset(tx, y + track / 2 + len), 1f)
            }
            val hx = v * (size.width - handleLong)
            drawHandle(Offset(hx, y - handleShort / 2), Size(handleLong, handleShort), accent, vertical = false)
        }
    }
}

private fun DrawScope.drawHandle(topLeft: Offset, size: Size, accent: Color, vertical: Boolean) {
    val corner = 3.dp.toPx()
    drawRoundRect(Color.Black.copy(alpha = 0.55f), Offset(topLeft.x + 1f, topLeft.y + 3f), size, CornerRadius(corner))
    drawRoundRect(
        brush = Brush.verticalGradient(
            listOf(Color(0xFFF4F6F7), Color(0xFFB8BEC3), Color(0xFFDDE0E3), Color(0xFF9CA3A9)),
            startY = topLeft.y, endY = topLeft.y + size.height,
        ),
        topLeft = topLeft, size = size, cornerRadius = CornerRadius(corner),
    )
    drawRoundRect(Color(0xFF1E2024), topLeft, size, CornerRadius(corner), style = Stroke(1.2f))
    if (vertical) {
        val cy = topLeft.y + size.height / 2
        for (k in -2..2) {
            if (k == 0) continue
            val yy = cy + k * 4.dp.toPx()
            drawLine(Color.Black.copy(alpha = 0.40f), Offset(topLeft.x + 3.dp.toPx(), yy), Offset(topLeft.x + size.width - 3.dp.toPx(), yy), 1.5f)
        }
        drawLine(accent, Offset(topLeft.x + 2.dp.toPx(), cy), Offset(topLeft.x + size.width - 2.dp.toPx(), cy), 3.dp.toPx())
    } else {
        val cx = topLeft.x + size.width / 2
        for (k in -2..2) {
            if (k == 0) continue
            val xx = cx + k * 5.dp.toPx()
            drawLine(Color.Black.copy(alpha = 0.40f), Offset(xx, topLeft.y + 3.dp.toPx()), Offset(xx, topLeft.y + size.height - 3.dp.toPx()), 1.5f)
        }
        drawLine(accent, Offset(cx, topLeft.y + 2.dp.toPx()), Offset(cx, topLeft.y + size.height - 2.dp.toPx()), 3.dp.toPx())
    }
}

// ----------------------------------------------------------------- medidor

/** Medidor de nível de segmentos: escala em decibéis, de -48 dB a 0 dB. Lê o nível só na hora de desenhar. */
@Composable
fun LevelMeter(peak: () -> Float, modifier: Modifier = Modifier, vertical: Boolean = true, segments: Int = 14) {
    Canvas(modifier) {
        val db = 20f * log10(max(peak(), 0.0001f))
        val lit = ceil(((db + 48f) / 48f).coerceIn(0f, 1f) * segments).toInt()
        val gap = 1.5f.dp.toPx()
        for (i in 0 until segments) {
            val f = (i + 1f) / segments
            val on = i < lit
            val base = when {
                f <= 0.62f -> Metal.Success
                f <= 0.82f -> Metal.Warning
                f <= 0.93f -> Color(0xFFFF8A3D)
                else -> Metal.Danger
            }
            val color = if (on) base else base.copy(alpha = 0.13f)
            if (vertical) {
                val h = (size.height - gap * (segments - 1)) / segments
                val y = size.height - (i + 1) * h - i * gap
                drawRoundRect(color, Offset(0f, y), Size(size.width, h), CornerRadius(1.5f.dp.toPx()))
            } else {
                val w = (size.width - gap * (segments - 1)) / segments
                drawRoundRect(color, Offset(i * (w + gap), 0f), Size(w, size.height), CornerRadius(1.5f.dp.toPx()))
            }
        }
    }
}

// --------------------------------------------------------------- ondas

private const val FRAMES_PER_BIN = 320      // 48000 / 150 picos por segundo
private const val VIEW_SECONDS = 8          // janela da onda rolante

private fun strokePaint(color: Color): Paint = Paint().apply {
    this.color = color
    style = PaintingStyle.Stroke
    isAntiAlias = false
}

private fun amp(v: Byte): Float = sqrt((v.toInt() and 0xFF) / 255f)

/**
 * Onda rolante colorida por frequência (graves laranja, médios amarelo, agudos azul claro), com a
 * agulha fixa no centro, a grade de batidas e as marcas de cue e hot cues. A posição é lida só
 * na hora de desenhar, então o resto da tela não é recomposto 30 vezes por segundo.
 */
@Composable
fun ScrollingWave(
    peaks: ByteArray?,
    position: () -> Long,
    bpm: Double,
    firstBeatFrame: Long,
    hotcues: List<Long>,
    cue: () -> Long,
    deckColor: Color,
    modifier: Modifier = Modifier,
) {
    val lowPaint = remember { strokePaint(Metal.WaveLow) }
    val midPaint = remember { strokePaint(Metal.WaveMid) }
    val highPaint = remember { strokePaint(Metal.WaveHigh) }
    val pts = remember { arrayOf(FloatArray(0), FloatArray(0), FloatArray(0)) }
    Canvas(modifier.background(Color(0xFF07090B))) {
        val w = size.width
        val h = size.height
        val mid = h / 2f
        val pos = position()
        val span = 48000.0 * VIEW_SECONDS
        val perPx = span / w
        val step = 2.dp.toPx().coerceAtLeast(2f)
        val cnt = (w / step).toInt() + 1
        if (pts[0].size != cnt * 4) for (q in 0..2) pts[q] = FloatArray(cnt * 4)
        val lo = pts[0]
        val md = pts[1]
        val hi = pts[2]
        val bins = (peaks?.size ?: 0) / 3
        val half = mid * 0.94f
        for (i in 0 until cnt) {
            val x = i * step
            val frame = pos + ((x - w / 2f) * perPx).toLong()
            val bin = if (frame < 0) -1 else (frame / FRAMES_PER_BIN).toInt()
            val o = i * 4
            if (peaks == null || bin < 0 || bin >= bins) {
                lo[o] = -10f; lo[o + 1] = -10f; lo[o + 2] = -10f; lo[o + 3] = -10f
                md[o] = -10f; md[o + 1] = -10f; md[o + 2] = -10f; md[o + 3] = -10f
                hi[o] = -10f; hi[o + 1] = -10f; hi[o + 2] = -10f; hi[o + 3] = -10f
            } else {
                val a0 = amp(peaks[bin * 3]) * half
                val a1 = amp(peaks[bin * 3 + 1]) * half
                val a2 = amp(peaks[bin * 3 + 2]) * half
                lo[o] = x; lo[o + 1] = mid - a0; lo[o + 2] = x; lo[o + 3] = mid + a0
                md[o] = x; md[o + 1] = mid - a1; md[o + 2] = x; md[o + 3] = mid + a1
                hi[o] = x; hi[o + 1] = mid - a2; hi[o + 2] = x; hi[o + 3] = mid + a2
            }
        }
        lowPaint.strokeWidth = step
        midPaint.strokeWidth = step
        highPaint.strokeWidth = step
        val canvas = drawContext.canvas
        if (peaks != null) {
            canvas.drawRawPoints(PointMode.Lines, lo, lowPaint)
            canvas.drawRawPoints(PointMode.Lines, md, midPaint)
            canvas.drawRawPoints(PointMode.Lines, hi, highPaint)
        } else {
            drawLine(Metal.Border, Offset(0f, mid), Offset(w, mid), 1.dp.toPx())
        }
        // parte já tocada, escurecida
        drawRect(Color.Black.copy(alpha = 0.45f), Offset(0f, 0f), Size(w / 2f, h))

        // grade de batidas
        if (bpm > 0.0) {
            val beat = 48000.0 * 60.0 / bpm
            val start = pos - span / 2
            var k = Math.ceil((start - firstBeatFrame) / beat).toLong()
            while (true) {
                val f = firstBeatFrame + k * beat
                if (f > pos + span / 2) break
                if (f >= 0) {
                    val x = ((f - pos) / perPx + w / 2f).toFloat()
                    val bar = k.mod(4L) == 0L
                    drawLine(
                        Color.White.copy(alpha = if (bar) 0.85f else 0.35f), Offset(x, 0f), Offset(x, if (bar) h else h * 0.22f),
                        if (bar) 1.5f.dp.toPx() else 1f,
                    )
                    if (!bar) drawLine(Color.White.copy(alpha = 0.35f), Offset(x, h), Offset(x, h * 0.78f), 1f)
                }
                k++
            }
        }
        // marcas: hot cues e cue
        val padCols = HOT_COLORS
        for (slot in hotcues.indices) {
            val f = hotcues[slot]
            if (f < 0) continue
            val x = ((f - pos) / perPx + w / 2f).toFloat()
            if (x < -10f || x > w + 10f) continue
            drawLine(padCols[slot], Offset(x, 0f), Offset(x, h), 2.dp.toPx())
            drawRect(padCols[slot], Offset(x, 0f), Size(14.dp.toPx(), 12.dp.toPx()))
        }
        val cf = cue()
        if (cf > 0) {
            val x = ((cf - pos) / perPx + w / 2f).toFloat()
            if (x in 0f..w) drawLine(Metal.Danger, Offset(x, 0f), Offset(x, h), 2.dp.toPx())
        }
        // agulha
        drawLine(Color.White, Offset(w / 2f, 0f), Offset(w / 2f, h), 2.dp.toPx())
        val tri = Path().apply {
            moveTo(w / 2f - 6.dp.toPx(), 0f)
            lineTo(w / 2f + 6.dp.toPx(), 0f)
            lineTo(w / 2f, 7.dp.toPx())
            close()
        }
        drawPath(tri, deckColor)
    }
}

internal val HOT_COLORS = listOf(Color(0xFFFF5A5F), Color(0xFFFFD166), Color(0xFF4CD08A), Color(0xFFB57BFF))

/** Visão geral da faixa inteira. Toque ou arraste para ir a outro ponto. */
@Composable
fun OverviewStrip(
    peaks: ByteArray?,
    position: () -> Long,
    lengthFrames: Long,
    deckColor: Color,
    description: String,
    onSeek: (Float) -> Unit,
    modifier: Modifier = Modifier,
) {
    val latest = rememberUpdatedState(onSeek)
    val dimPaint = remember { strokePaint(Color(0xFF55606A)) }
    val litPaint = remember { strokePaint(deckColor) }
    BoxWithConstraints(
        modifier
            .background(Color(0xFF07090B))
            .semantics { contentDescription = description }
            .pointerInput(Unit) {
                awaitEachGesture {
                    val down = awaitFirstDown()
                    down.consume()
                    latest.value(down.position.x / size.width)
                    do {
                        val event = awaitPointerEvent()
                        val change = event.changes.first()
                        if (change.pressed) {
                            latest.value(change.position.x / size.width)
                            change.consume()
                        }
                    } while (event.changes.any { it.pressed })
                }
            },
    ) {
        val widthPx = with(LocalDensity.current) { maxWidth.roundToPx() }
        val heightPx = with(LocalDensity.current) { maxHeight.roundToPx() }
        val lines = remember(peaks, widthPx, heightPx) { overviewLines(peaks, widthPx, heightPx) }
        Canvas(Modifier.fillMaxSize()) {
            val w = size.width
            val h = size.height
            if (lines.isEmpty() || lengthFrames <= 0) {
                drawLine(Metal.Border, Offset(0f, h / 2), Offset(w, h / 2), 1.dp.toPx())
                return@Canvas
            }
            val playedX = w * (position().toFloat() / lengthFrames).coerceIn(0f, 1f)
            dimPaint.strokeWidth = 1f
            litPaint.strokeWidth = 1f
            drawContext.canvas.drawRawPoints(PointMode.Lines, lines, dimPaint)
            clipRect(0f, 0f, playedX, h) {
                drawContext.canvas.drawRawPoints(PointMode.Lines, lines, litPaint)
            }
            drawLine(Color.White, Offset(playedX, 0f), Offset(playedX, h), 2.dp.toPx())
        }
    }
}

private fun overviewLines(peaks: ByteArray?, width: Int, height: Int): FloatArray {
    if (peaks == null || width <= 0) return FloatArray(0)
    val bins = peaks.size / 3
    if (bins == 0) return FloatArray(0)
    val out = FloatArray(width * 4)
    val mid = height / 2f
    for (x in 0 until width) {
        val from = (x.toLong() * bins / width).toInt()
        val to = max(from + 1, ((x + 1).toLong() * bins / width).toInt()).coerceAtMost(bins)
        var m = 0
        for (b in from until to) for (band in 0..2) {
            val v = peaks[b * 3 + band].toInt() and 0xFF
            if (v > m) m = v
        }
        val a = max(1f, sqrt(m / 255f) * mid * 0.95f)
        out[x * 4] = x + 0.5f; out[x * 4 + 1] = mid - a; out[x * 4 + 2] = x + 0.5f; out[x * 4 + 3] = mid + a
    }
    return out
}

// ------------------------------------------------------------------ vinil

/**
 * Prato no estilo de um toca-discos de DJ: chapa de prata escovada com a coroa de pontos estroboscópicos
 * na borda, tapete preto com o disco, selo prateado com aro vermelho. A base é desenhada uma vez; a coroa
 * de pontos e o selo giram numa camada de GPU (sem redesenhar nada); um anel vermelho mostra o progresso.
 * O ângulo vem da posição real: 33⅓ rpm em velocidade normal, parado quando pausado. Não responde ao toque (v1).
 */
@Composable
fun Platter(
    deckColor: Color,
    position: () -> Long,
    lengthFrames: () -> Long,
    modifier: Modifier = Modifier,
    /** Scratch: (ativo, velocidade em múltiplos da normal). Nulo = o prato não reage ao toque. */
    onScratch: ((Boolean, Float) -> Unit)? = null,
    center: @Composable BoxScope.() -> Unit = {},
) {
    val scratchCb = rememberUpdatedState(onScratch)
    Box(
        modifier.pointerInput(onScratch != null) {
            if (onScratch == null) return@pointerInput
            awaitEachGesture {
                val down = awaitFirstDown(requireUnconsumed = false)
                val cx = size.width / 2f
                val cy = size.height / 2f
                val radius = min(size.width, size.height) / 2f
                var lastAng = atan2(down.position.y - cy, down.position.x - cx)
                var lastT = down.uptimeMillis
                var vel = 0f
                scratchCb.value?.invoke(true, 0f)
                while (true) {
                    val ev = withTimeoutOrNull(30L) { awaitPointerEvent() }
                    if (ev == null) {                      // dedo parado: o disco fica preso na mão
                        vel = 0f
                        scratchCb.value?.invoke(true, 0f)
                        continue
                    }
                    val ch = ev.changes.firstOrNull() ?: break
                    if (!ch.pressed) break
                    val dx = ch.position.x - cx
                    val dy = ch.position.y - cy
                    if (dx * dx + dy * dy > 0.12f * radius * radius) {   // perto do centro o ângulo é instável
                        val ang = atan2(dy, dx)
                        var d = ang - lastAng
                        if (d > PI.toFloat()) d -= 2f * PI.toFloat()
                        if (d < -PI.toFloat()) d += 2f * PI.toFloat()
                        val dt = (ch.uptimeMillis - lastT) / 1000f
                        // eventos com o mesmo horário (telas de alta taxa): acumula o ângulo até o tempo andar
                        if (dt > 0.001f) {
                            // uma volta do prato = 1,8 s de música (33⅓ rpm)
                            val v = (d / (2f * PI.toFloat())) * 1.8f / dt
                            vel = 0.5f * vel + 0.5f * v.coerceIn(-8f, 8f)
                            scratchCb.value?.invoke(true, vel)
                            lastAng = ang
                            lastT = ch.uptimeMillis
                        }
                    }
                    ch.consume()
                }
                scratchCb.value?.invoke(false, 0f)
            }
        },
        contentAlignment = Alignment.Center,
    ) {
        Canvas(Modifier.fillMaxSize()) {
            val r = min(size.width, size.height) / 2f
            val c = Offset(size.width / 2f, size.height / 2f)
            drawCircle(Color.Black.copy(alpha = 0.55f), radius = r, center = Offset(c.x, c.y + 3.dp.toPx()))
            // chapa de prata escovada (reflexos em leque)
            drawCircle(
                brush = Brush.sweepGradient(
                    listOf(
                        Color(0xFFF1F3F4), Color(0xFF9AA1A7), Color(0xFFD8DCDF), Color(0xFF7F868C),
                        Color(0xFFEDEFF1), Color(0xFF9AA1A7), Color(0xFFD8DCDF), Color(0xFF7F868C), Color(0xFFF1F3F4),
                    ),
                    center = c,
                ),
                radius = r * 0.985f, center = c,
            )
            drawCircle(Color(0xFF22252A), radius = r * 0.985f, center = c, style = Stroke(1.5f.dp.toPx()))
            // fios radiais bem finos, para parecer escovado
            for (i in 0 until 90) {
                val ang = Math.toRadians(i * 4.0)
                val cx = cos(ang).toFloat()
                val sx = sin(ang).toFloat()
                drawLine(
                    Color.Black.copy(alpha = 0.07f), Offset(c.x + cx * r * 0.82f, c.y + sx * r * 0.82f),
                    Offset(c.x + cx * r * 0.975f, c.y + sx * r * 0.975f), 1f,
                )
            }
            // tapete preto e disco
            drawCircle(Color(0xFF060607), radius = r * 0.80f, center = c)
            var gr = r * 0.34f
            var n = 0
            while (gr < r * 0.78f) {
                drawCircle(Color.White.copy(alpha = if (n % 5 == 0) 0.09f else 0.035f), radius = gr, center = c, style = Stroke(1f))
                gr += r * 0.03f
                n++
            }
            // aro de luz vermelho em volta do tapete
            drawCircle(deckColor.copy(alpha = 0.22f), radius = r * 0.81f, center = c, style = Stroke(r * 0.05f))
            drawCircle(deckColor, radius = r * 0.80f, center = c, style = Stroke(1.5f.dp.toPx()))
        }
        Canvas(
            Modifier.fillMaxSize().graphicsLayer {
                rotationZ = (((position() / 48000.0) * (100.0 / 3.0 / 60.0) * 360.0) % 360.0).toFloat()
            },
        ) {
            val r = min(size.width, size.height) / 2f
            val c = Offset(size.width / 2f, size.height / 2f)
            // coroa estroboscópica
            for (i in 0 until 72) {
                val ang = Math.toRadians(i * 5.0)
                val big = i % 6 == 0
                val rad = r * 0.905f
                drawCircle(
                    Color(0xFF181A1D), radius = if (big) r * 0.018f else r * 0.010f,
                    center = Offset(c.x + cos(ang).toFloat() * rad, c.y + sin(ang).toFloat() * rad),
                )
            }
            // marca vermelha de referência: deixa a rotação visível
            drawCircle(deckColor, radius = r * 0.026f, center = Offset(c.x, c.y - r * 0.905f))
            // reflexos no disco
            val sheen = Path().apply {
                moveTo(c.x, c.y)
                lineTo(c.x - r * 0.76f, c.y - r * 0.36f)
                lineTo(c.x - r * 0.36f, c.y - r * 0.76f)
                close()
            }
            drawPath(sheen, Color.White.copy(alpha = 0.05f))
            val sheen2 = Path().apply {
                moveTo(c.x, c.y)
                lineTo(c.x + r * 0.76f, c.y + r * 0.36f)
                lineTo(c.x + r * 0.36f, c.y + r * 0.76f)
                close()
            }
            drawPath(sheen2, Color.White.copy(alpha = 0.05f))
            // selo prateado com aro vermelho
            drawCircle(
                brush = Brush.sweepGradient(
                    listOf(Color(0xFFF2F4F5), Color(0xFFA9B0B6), Color(0xFFE3E6E8), Color(0xFF90979D), Color(0xFFF2F4F5)),
                    center = c,
                ),
                radius = r * 0.30f, center = c,
            )
            drawCircle(deckColor, radius = r * 0.30f, center = c, style = Stroke(2.5f.dp.toPx()))
            drawCircle(Color(0xFF26292D), radius = r * 0.20f, center = c, style = Stroke(1f))
            drawLine(deckColor, Offset(c.x, c.y - r * 0.12f), Offset(c.x, c.y - r * 0.27f), 3.dp.toPx(), StrokeCap.Round)
        }
        Canvas(Modifier.fillMaxSize()) {
            val r = min(size.width, size.height) / 2f
            val len = lengthFrames()
            val p = if (len > 0) (position().toFloat() / len).coerceIn(0f, 1f) else 0f
            val sw = 3.dp.toPx()
            val rr = r - sw / 2f
            val tl = Offset(size.width / 2f - rr, size.height / 2f - rr)
            drawArc(Color(0xFF3A3F44), -90f, 360f, false, tl, Size(rr * 2, rr * 2), style = Stroke(sw))
            if (p > 0f) drawArc(deckColor, -90f, 360f * p, false, tl, Size(rr * 2, rr * 2), style = Stroke(sw, cap = StrokeCap.Round))
        }
        center()
    }
}
