package app.djfusion.ui

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.gestures.awaitEachGesture
import androidx.compose.foundation.gestures.awaitFirstDown
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.gestures.detectVerticalDragGestures
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxScope
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Paint
import androidx.compose.ui.graphics.PaintingStyle
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.PointMode
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.graphics.nativeCanvas
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.clipRect
import androidx.compose.ui.graphics.drawscope.rotate
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.semantics.ProgressBarRangeInfo
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.onClick
import androidx.compose.ui.semantics.progressBarRangeInfo
import androidx.compose.ui.semantics.role
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.semantics.setProgress
import androidx.compose.ui.semantics.stateDescription
import androidx.compose.ui.unit.dp
import app.djfusion.ui.theme.Metal
import kotlin.math.PI
import kotlin.math.ceil
import kotlin.math.cos
import kotlin.math.log10
import kotlin.math.max
import kotlin.math.min
import kotlin.math.roundToInt
import kotlin.math.sin
import kotlin.math.sqrt

import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.sp
import kotlin.math.abs
import kotlin.math.atan2
// ------------------------------------------------------------------ botões

/** Prata escovada: degradê de alumínio com fios horizontais finos, como a chapa de um toca-discos. */
internal fun DrawScope.drawBrushed(
    colors: List<Color>, corner: Float = 0f, lineAlpha: Float = 0.16f, dark: Boolean = false,
) {
    drawRoundRect(Brush.verticalGradient(colors), cornerRadius = CornerRadius(corner))
    val inset = corner * 0.45f
    var y = 2f
    var k = 0
    while (y < size.height - 2f) {
        val c = if (k % 2 == 0) {
            if (dark) Color.White.copy(alpha = lineAlpha * 0.5f) else Color.White.copy(alpha = lineAlpha)
        } else {
            Color.Black.copy(alpha = lineAlpha * 0.45f)
        }
        drawLine(c, Offset(inset, y), Offset(size.width - inset, y), 1f)
        y += 2.5f
        k++
    }
}

private val SilverLight = listOf(Color(0xFFE4E7EA), Color(0xFFB3B9BF), Color(0xFFCBD0D5), Color(0xFFA2A9AF))
private val SilverPressed = listOf(Color(0xFF8D949B), Color(0xFFB0B6BC))
private val BlackBrushed = listOf(Color(0xFF232427), Color(0xFF131416), Color(0xFF1B1C1F))

/** Painel do deck: grafite escuro e plano (estilo Serato), com filete claro no alto. */
fun Modifier.brushedSilver(): Modifier = drawBehind {
    drawRect(Brush.verticalGradient(listOf(Color(0xFF191C20), Color(0xFF121417))))
    drawLine(Color(0xFF2C3137), Offset(0f, 0.5f), Offset(size.width, 0.5f), 1f)
}

/** Painel do mixer: um tom mais escuro que os decks, com bordas laterais. */
fun Modifier.brushedBlack(): Modifier = drawBehind {
    drawRect(Brush.verticalGradient(listOf(Color(0xFF111316), Color(0xFF0C0D0F))))
    drawLine(Color(0xFF262A2F), Offset(0.5f, 0f), Offset(0.5f, size.height), 1f)
    drawLine(Color(0xFF262A2F), Offset(size.width - 0.5f, 0f), Offset(size.width - 0.5f, size.height), 1f)
}

internal fun DrawScope.drawMetalPlate(pressed: Boolean, enabled: Boolean, corner: Float) {
    // botão escuro e plano, como no Serato/VirtualDJ: degradê discreto, borda fina e brilho de 1 px no alto
    drawRoundRect(
        Brush.verticalGradient(if (pressed) listOf(Color(0xFF3B424A), Color(0xFF2D3339)) else listOf(Color(0xFF2A2F35), Color(0xFF1C2024))),
        cornerRadius = CornerRadius(corner),
    )
    drawRoundRect(if (pressed) Color(0xFF5A636D) else Color(0xFF3A4048), cornerRadius = CornerRadius(corner), style = Stroke(1.dp.toPx()))
    if (!pressed) drawLine(Color.White.copy(alpha = 0.08f), Offset(corner, 1.5f), Offset(size.width - corner, 1.5f), 1f)
    if (!enabled) drawRoundRect(Color.Black.copy(alpha = 0.45f), cornerRadius = CornerRadius(corner))
}

/**
 * Botão. Por padrão dispara no instante do toque (não ao soltar), como um botão de equipamento de DJ.
 * Com [fireOnPress] falso só dispara no toque completo, para não agir quando o dedo começa uma rolagem.
 * Quando [ledOn] é verdadeiro o botão acende na cor [led].
 */
@Composable
fun MetalButton(
    description: String,
    onPress: () -> Unit,
    modifier: Modifier = Modifier,
    enabled: Boolean = true,
    led: Color? = null,
    ledOn: Boolean = false,
    fireOnPress: Boolean = true,
    /** Toque com o botão desligado: explica por que nada aconteceu (ex.: deck sem música). */
    onDisabledPress: (() -> Unit)? = null,
    /** Chamado quando o dedo sai do botão (botões de segurar, como o CUE). */
    onRelease: (() -> Unit)? = null,
    content: @Composable BoxScope.() -> Unit,
) {
    var pressed by remember { mutableStateOf(false) }
    val latest = rememberUpdatedState(onPress)
    val releaseCb = rememberUpdatedState(onRelease)
    val disabledCb = rememberUpdatedState(onDisabledPress)
    val shape = RoundedCornerShape(10.dp)
    Box(
        modifier = modifier
            .semantics {
                contentDescription = description
                role = Role.Button
                onClick {
                    if (enabled) { latest.value(); releaseCb.value?.invoke() } else disabledCb.value?.invoke()
                    true
                }
            }
            .clip(shape)
            .drawBehind {
                val corner = 10.dp.toPx()
                drawMetalPlate(pressed, enabled, corner)
                if (led != null) {
                    if (ledOn && enabled) {
                        drawRoundRect(
                            Brush.verticalGradient(listOf(led.copy(alpha = 0.40f), led.copy(alpha = 0.10f))),
                            cornerRadius = CornerRadius(corner),
                        )
                        drawRoundRect(led, cornerRadius = CornerRadius(corner), style = Stroke(2.dp.toPx()))
                    }
                    // LED indicador no canto, como nos botões de equipamento: aceso brilha, apagado fica vinho
                    val c = Offset(size.width - 9.dp.toPx(), 9.dp.toPx())
                    if (ledOn && enabled) drawCircle(led.copy(alpha = 0.35f), 7.dp.toPx(), c)
                    drawCircle(if (ledOn && enabled) led else Color(0xFF3A2222), 3f.dp.toPx(), c)
                    drawCircle(Color.White.copy(alpha = if (ledOn && enabled) 0.7f else 0.15f), 1.3f.dp.toPx(), Offset(c.x - 1f, c.y - 1f))
                }
            }
            .pointerInput(enabled, fireOnPress) {
                detectTapGestures(
                    onPress = {
                        if (enabled) {
                            pressed = true
                            if (fireOnPress) latest.value()
                            tryAwaitRelease()
                            pressed = false
                            releaseCb.value?.invoke()
                        }
                    },
                    onTap = {
                        if (enabled && !fireOnPress) latest.value()
                        else if (!enabled) disabledCb.value?.invoke()
                    },
                )
            },
        contentAlignment = Alignment.Center,
    ) {
        content()
    }
}

/** Triângulo de play ou duas barras de pausa. */
@Composable
fun TransportGlyph(playing: Boolean, color: Color = Metal.OnMetal, modifier: Modifier = Modifier) {
    Canvas(modifier) {
        val c = color
        val w = size.width
        val h = size.height
        if (playing) {
            drawRoundRect(c, Offset(w * 0.22f, h * 0.15f), Size(w * 0.20f, h * 0.70f), CornerRadius(w * 0.03f))
            drawRoundRect(c, Offset(w * 0.58f, h * 0.15f), Size(w * 0.20f, h * 0.70f), CornerRadius(w * 0.03f))
        } else {
            val p = Path().apply {
                moveTo(w * 0.25f, h * 0.12f)
                lineTo(w * 0.25f, h * 0.88f)
                lineTo(w * 0.85f, h * 0.50f)
                close()
            }
            drawPath(p, c)
        }
    }
}

// ----------------------------------------------------------------- knob

/**
 * Knob giratório. Arraste para cima ou para baixo; toque duas vezes para voltar ao meio.
 * [centered]: o arco colorido parte do meio (equalizador, filtro).
 */
@Composable
fun Knob(
    value: Float,
    onChange: (Float) -> Unit,
    accent: Color,
    description: String,
    modifier: Modifier = Modifier,
    centered: Boolean = true,
) {
    val latest = rememberUpdatedState(onChange)
    val cur = rememberUpdatedState(value)
    Canvas(
        modifier
            .semantics {
                contentDescription = description
                stateDescription = "${(value * 100).roundToInt()} por cento"
                progressBarRangeInfo = ProgressBarRangeInfo(value, 0f..1f)
                setProgress { v ->
                    latest.value(v.coerceIn(0f, 1f))
                    true
                }
            }
            .pointerInput(Unit) { detectTapGestures(onDoubleTap = { latest.value(0.5f) }) }
            .pointerInput(Unit) {
                var acc = 0f
                detectVerticalDragGestures(
                    onDragStart = { acc = cur.value },
                    onVerticalDrag = { change, dy ->
                        change.consume()
                        acc = (acc - dy / 200.dp.toPx()).coerceIn(0f, 1f)
                        latest.value(acc)
                    },
                )
            },
    ) {
        val d = min(size.width, size.height)
        val c = Offset(size.width / 2f, size.height / 2f)
        val ring = 3.dp.toPx()
        val r = d / 2f - ring
        val v = value.coerceIn(0f, 1f)
        val tl = Offset(c.x - r, c.y - r)
        val sz = Size(r * 2, r * 2)
        drawArc(Color(0xFF2E3338), 135f, 270f, false, tl, sz, style = Stroke(ring, cap = StrokeCap.Round))
        if (centered) {
            val sweep = (v - 0.5f) * 270f
            if (abs(sweep) > 0.5f) drawArc(accent, 270f, sweep, false, tl, sz, style = Stroke(ring, cap = StrokeCap.Round))
        } else if (v > 0.002f) {
            drawArc(accent, 135f, v * 270f, false, tl, sz, style = Stroke(ring, cap = StrokeCap.Round))
        }
        val br = r - ring * 1.4f
        drawCircle(Color.Black.copy(alpha = 0.5f), radius = br, center = Offset(c.x, c.y + 1.5f.dp.toPx()))
        drawCircle(
            Brush.verticalGradient(listOf(Color(0xFF454B52), Color(0xFF24282D), Color(0xFF1A1D21)), c.y - br, c.y + br),
            radius = br, center = c,
        )
        drawCircle(Color(0xFF505860), radius = br, center = c, style = Stroke(1.dp.toPx()))
        val a = Math.toRadians((135f + v * 270f).toDouble())
        val ca = cos(a).toFloat()
        val sa = sin(a).toFloat()
        drawLine(
            Color.White, Offset(c.x + ca * br * 0.30f, c.y + sa * br * 0.30f),
            Offset(c.x + ca * br * 0.92f, c.y + sa * br * 0.92f), 2.5f.dp.toPx(), StrokeCap.Round,
        )
    }
}

// ----------------------------------------------------------------- faders

/**
 * Fader. Vertical: 0 embaixo, 1 em cima. Horizontal: 0 à esquerda, 1 à direita.
 * Responde ao toque no ponto exato e ao arrasto. Também aceita ajuste por leitor de tela.
 * Com [fill] a trilha se enche de cor até a alça.
 */
@Composable
fun MetalFader(
    value: Float,
    onChange: (Float) -> Unit,
    accent: Color,
    description: String,
    modifier: Modifier = Modifier,
    vertical: Boolean = true,
    fill: Boolean = false,
) {
    val latest = rememberUpdatedState(onChange)
    Canvas(
        modifier
            .semantics {
                contentDescription = description
                stateDescription = "${(value * 100).roundToInt()} por cento"
                progressBarRangeInfo = ProgressBarRangeInfo(value, 0f..1f)
                setProgress { v ->
                    latest.value(v.coerceIn(0f, 1f))
                    true
                }
            }
            .pointerInput(vertical) {
                awaitEachGesture {
                    val handleLen = (if (vertical) 26.dp else 44.dp).toPx()
                    fun toValue(p: Offset): Float = if (vertical) {
                        1f - ((p.y - handleLen / 2f) / (size.height - handleLen)).coerceIn(0f, 1f)
                    } else {
                        ((p.x - handleLen / 2f) / (size.width - handleLen)).coerceIn(0f, 1f)
                    }
                    val down = awaitFirstDown()
                    down.consume()
                    latest.value(toValue(down.position))
                    do {
                        val event = awaitPointerEvent()
                        val change = event.changes.first()
                        if (change.pressed) {
                            latest.value(toValue(change.position))
                            change.consume()
                        }
                    } while (event.changes.any { it.pressed })
                }
            },
    ) {
        val track = 6.dp.toPx()
        val handleLong = (if (vertical) 26.dp else 44.dp).toPx()
        val handleShort = (if (vertical) 32.dp else 30.dp).toPx()
        val v = value.coerceIn(0f, 1f)
        if (vertical) {
            val x = size.width / 2f
            drawRoundRect(Color(0xFF050607), Offset(x - track / 2, 0f), Size(track, size.height), CornerRadius(track / 2))
            drawRoundRect(Color(0xFF2E343A), Offset(x - track / 2, 0f), Size(track, size.height), CornerRadius(track / 2), style = Stroke(1f))
            for (i in 0..10) {
                val ty = handleLong / 2 + (size.height - handleLong) * i / 10f
                val len = if (i % 5 == 0) track * 1.9f else track * 1.1f
                drawLine(Color(0xFF6A7178), Offset(x - track / 2 - len, ty), Offset(x - track / 2 - 2f, ty), 1f)
                drawLine(Color(0xFF6A7178), Offset(x + track / 2 + 2f, ty), Offset(x + track / 2 + len, ty), 1f)
            }
            val hy = (1f - v) * (size.height - handleLong)
            if (fill) {
                val top = hy + handleLong / 2
                drawRoundRect(accent.copy(alpha = 0.85f), Offset(x - track / 2, top), Size(track, size.height - top), CornerRadius(track / 2))
            }
            drawHandle(Offset(x - handleShort / 2, hy), Size(handleShort, handleLong), accent, vertical = true)
        } else {
            val y = size.height / 2f
            drawRoundRect(Color(0xFF050607), Offset(0f, y - track / 2), Size(size.width, track), CornerRadius(track / 2))
            drawRoundRect(Color(0xFF2E343A), Offset(0f, y - track / 2), Size(size.width, track), CornerRadius(track / 2), style = Stroke(1f))
            for (i in 0..10) {
                val tx = handleLong / 2 + (size.width - handleLong) * i / 10f
                val len = if (i % 5 == 0) track * 1.9f else track * 1.1f
                drawLine(Color(0xFF6A7178), Offset(tx, y - track / 2 - len), Offset(tx, y - track / 2 - 2f), 1f)
                drawLine(Color(0xFF6A7178), Offset(tx, y + track / 2 + 2f), Offset(tx, y + track / 2 + len), 1f)
            }
            val hx = v * (size.width - handleLong)
            drawHandle(Offset(hx, y - handleShort / 2), Size(handleLong, handleShort), accent, vertical = false)
        }
    }
}

private fun DrawScope.drawHandle(topLeft: Offset, size: Size, accent: Color, vertical: Boolean) {
    val corner = 3.dp.toPx()
    drawRoundRect(Color.Black.copy(alpha = 0.55f), Offset(topLeft.x + 1f, topLeft.y + 3f), size, CornerRadius(corner))
    drawRoundRect(
        brush = Brush.verticalGradient(
            listOf(Color(0xFF4A5057), Color(0xFF2C3136), Color(0xFF23272B), Color(0xFF34393F)),
            startY = topLeft.y, endY = topLeft.y + size.height,
        ),
        topLeft = topLeft, size = size, cornerRadius = CornerRadius(corner),
    )
    drawRoundRect(Color(0xFF5C646D), topLeft, size, CornerRadius(corner), style = Stroke(1.2f))
    if (vertical) {
        val cy = topLeft.y + size.height / 2
        for (k in -2..2) {
            if (k == 0) continue
            val yy = cy + k * 4.dp.toPx()
            drawLine(Color.Black.copy(alpha = 0.55f), Offset(topLeft.x + 3.dp.toPx(), yy), Offset(topLeft.x + size.width - 3.dp.toPx(), yy), 1.5f)
        }
        drawLine(accent, Offset(topLeft.x + 2.dp.toPx(), cy), Offset(topLeft.x + size.width - 2.dp.toPx(), cy), 3.dp.toPx())
    } else {
        val cx = topLeft.x + size.width / 2
        for (k in -2..2) {
            if (k == 0) continue
            val xx = cx + k * 5.dp.toPx()
            drawLine(Color.Black.copy(alpha = 0.40f), Offset(xx, topLeft.y + 3.dp.toPx()), Offset(xx, topLeft.y + size.height - 3.dp.toPx()), 1.5f)
        }
        drawLine(accent, Offset(cx, topLeft.y + 2.dp.toPx()), Offset(cx, topLeft.y + size.height - 2.dp.toPx()), 3.dp.toPx())
    }
}

// ----------------------------------------------------------------- medidor

/** Medidor de nível de segmentos: escala em decibéis, de -48 dB a 0 dB. Lê o nível só na hora de desenhar. */
@Composable
fun LevelMeter(peak: () -> Float, modifier: Modifier = Modifier, vertical: Boolean = true, segments: Int = 14) {
    Canvas(modifier) {
        val db = 20f * log10(max(peak(), 0.0001f))
        val lit = ceil(((db + 48f) / 48f).coerceIn(0f, 1f) * segments).toInt()
        val gap = 1.5f.dp.toPx()
        for (i in 0 until segments) {
            val f = (i + 1f) / segments
            val on = i < lit
            val base = when {
                f <= 0.62f -> Metal.Success
                f <= 0.82f -> Metal.Warning
                f <= 0.93f -> Color(0xFFFF8A3D)
                else -> Metal.Danger
            }
            val color = if (on) base else base.copy(alpha = 0.13f)
            if (vertical) {
                val h = (size.height - gap * (segments - 1)) / segments
                val y = size.height - (i + 1) * h - i * gap
                drawRoundRect(color, Offset(0f, y), Size(size.width, h), CornerRadius(1.5f.dp.toPx()))
            } else {
                val w = (size.width - gap * (segments - 1)) / segments
                drawRoundRect(color, Offset(i * (w + gap), 0f), Size(w, size.height), CornerRadius(1.5f.dp.toPx()))
            }
        }
    }
}

// --------------------------------------------------------------- ondas

private const val FRAMES_PER_BIN = 320      // 48000 / 150 picos por segundo
private const val VIEW_SECONDS = 8          // janela da onda rolante

private fun strokePaint(color: Color): Paint = Paint().apply {
    this.color = color
    style = PaintingStyle.Stroke
    isAntiAlias = false
}

private fun amp(v: Byte): Float = sqrt((v.toInt() and 0xFF) / 255f)

/** Cores do espectro (como no Serato): graves vermelho/laranja, médios verde, agudos azul. */
private const val SPEC_N = 18
private val SPEC_COLORS: IntArray = IntArray(SPEC_N) { i ->
    val t = i / (SPEC_N - 1f)
    android.graphics.Color.HSVToColor(floatArrayOf(t * 225f, 0.88f - 0.18f * t, 1f))
}

/** Em qual cor do espectro cai um trecho, pelo peso de graves, médios e agudos. */
private fun specIndex(a0: Float, a1: Float, a2: Float): Int {
    val e1 = a1 * 1.25f
    val e2 = a2 * 1.7f
    val sum = a0 + e1 + e2
    if (sum <= 1e-4f) return 0
    val t = (0.5f * e1 + e2) / sum
    return (t * (SPEC_N - 1)).roundToInt().coerceIn(0, SPEC_N - 1)
}

private fun specPaints(): Array<android.graphics.Paint> = Array(SPEC_N) { i ->
    android.graphics.Paint().apply { color = SPEC_COLORS[i]; style = android.graphics.Paint.Style.STROKE; isAntiAlias = false }
}

/**
 * Onda rolante colorida pelo espectro (graves vermelho, médios verde, agudos azul, como no Serato), com a
 * agulha fixa no centro, grade de batidas (compasso mais forte, início de frase de 16 batidas destacado) e
 * as marcas de cue e hot cues. A posição é lida só na hora de desenhar. [viewSeconds] = zoom.
 */
@Composable
fun ScrollingWave(
    peaks: ByteArray?,
    position: () -> Long,
    bpm: Double,
    firstBeatFrame: Long,
    hotcues: List<Long>,
    cue: () -> Long,
    deckColor: Color,
    modifier: Modifier = Modifier,
    viewSeconds: Float = VIEW_SECONDS.toFloat(),
) {
    val paints = remember { specPaints() }
    val buf = remember { arrayOf(Array(SPEC_N) { FloatArray(0) }) }
    val counts = remember { IntArray(SPEC_N) }
    val corePaint = remember { android.graphics.Paint().apply { color = 0x55FFFFFF; style = android.graphics.Paint.Style.STROKE } }
    val coreBuf = remember { arrayOf(FloatArray(0)) }
    Canvas(modifier.background(Color(0xFF050608))) {
        val w = size.width
        val h = size.height
        val mid = h / 2f
        val pos = position()
        val span = 48000.0 * viewSeconds
        val perPx = span / w
        val step = 2.dp.toPx().coerceAtLeast(2f)
        val cnt = (w / step).toInt() + 1
        if (buf[0][0].size != cnt * 4) { for (q in 0 until SPEC_N) buf[0][q] = FloatArray(cnt * 4); coreBuf[0] = FloatArray(cnt * 4) }
        counts.fill(0)
        var coreN = 0
        val core = coreBuf[0]
        val bins = (peaks?.size ?: 0) / 3
        val half = mid * 0.96f
        // centro da linha média para referência
        drawLine(Color(0xFF1C2026), Offset(0f, mid), Offset(w, mid), 1f)
        if (peaks != null) {
            for (i in 0 until cnt) {
                val x = i * step
                val frame = pos + ((x - w / 2f) * perPx).toLong()
                if (frame < 0) continue
                // vários picos por coluna quando o zoom é largo: usa o maior de cada banda
                val b0 = (frame / FRAMES_PER_BIN).toInt()
                val b1 = ((frame + perPx * step) / FRAMES_PER_BIN).toInt().coerceAtLeast(b0 + 1)
                if (b0 >= bins) continue
                var m0 = 0; var m1 = 0; var m2 = 0
                for (b in b0 until minOf(b1, bins)) {
                    m0 = maxOf(m0, peaks[b * 3].toInt() and 0xFF)
                    m1 = maxOf(m1, peaks[b * 3 + 1].toInt() and 0xFF)
                    m2 = maxOf(m2, peaks[b * 3 + 2].toInt() and 0xFF)
                }
                val a0 = sqrt(m0 / 255f); val a1 = sqrt(m1 / 255f); val a2 = sqrt(m2 / 255f)
                val a = maxOf(a0, a1, a2) * half
                if (a < 0.5f) continue
                val k = specIndex(a0, a1, a2)
                val arr = buf[0][k]
                val o = counts[k]
                arr[o] = x; arr[o + 1] = mid - a; arr[o + 2] = x; arr[o + 3] = mid + a
                counts[k] = o + 4
                // núcleo claro proporcional aos agudos: dá o "brilho" dos pratos/chimbal
                val ca = a2 * half * 0.55f
                if (ca > 1f) { core[coreN] = x; core[coreN + 1] = mid - ca; core[coreN + 2] = x; core[coreN + 3] = mid + ca; coreN += 4 }
            }
            val nc = drawContext.canvas.nativeCanvas
            for (q in 0 until SPEC_N) {
                if (counts[q] == 0) continue
                paints[q].strokeWidth = step
                nc.drawLines(buf[0][q], 0, counts[q], paints[q])
            }
            corePaint.strokeWidth = step
            if (coreN > 0) nc.drawLines(core, 0, coreN, corePaint)
        }
        // parte já tocada, escurecida
        drawRect(Color.Black.copy(alpha = 0.42f), Offset(0f, 0f), Size(w / 2f, h))

        // grade de batidas: batida curta, compasso inteiro, frase (16) na cor do deck
        if (bpm > 0.0) {
            val beat = 48000.0 * 60.0 / bpm
            val start = pos - span / 2
            var k = Math.ceil((start - firstBeatFrame) / beat).toLong()
            while (true) {
                val f = firstBeatFrame + k * beat
                if (f > pos + span / 2) break
                if (f >= 0) {
                    val x = ((f - pos) / perPx + w / 2f).toFloat()
                    val phrase = k.mod(16L) == 0L
                    val bar = k.mod(4L) == 0L
                    when {
                        phrase -> drawLine(deckColor.copy(alpha = 0.9f), Offset(x, 0f), Offset(x, h), 2.dp.toPx())
                        bar -> drawLine(Color.White.copy(alpha = 0.7f), Offset(x, 0f), Offset(x, h), 1.2f.dp.toPx())
                        else -> {
                            drawLine(Color.White.copy(alpha = 0.4f), Offset(x, 0f), Offset(x, h * 0.18f), 1f)
                            drawLine(Color.White.copy(alpha = 0.4f), Offset(x, h), Offset(x, h * 0.82f), 1f)
                        }
                    }
                }
                k++
            }
        }
        // marcas: hot cues e cue
        val padCols = HOT_COLORS
        for (slot in hotcues.indices) {
            val f = hotcues[slot]
            if (f < 0) continue
            val x = ((f - pos) / perPx + w / 2f).toFloat()
            if (x < -10f || x > w + 10f) continue
            drawLine(padCols[slot], Offset(x, 0f), Offset(x, h), 2.dp.toPx())
            drawRect(padCols[slot], Offset(x, 0f), Size(14.dp.toPx(), 12.dp.toPx()))
        }
        val cf = cue()
        if (cf > 0) {
            val x = ((cf - pos) / perPx + w / 2f).toFloat()
            if (x in 0f..w) {
                drawLine(Color(0xFFFF8A3D), Offset(x, 0f), Offset(x, h), 2.dp.toPx())
                val t = Path().apply { moveTo(x, h); lineTo(x - 5.dp.toPx(), h - 7.dp.toPx()); lineTo(x + 5.dp.toPx(), h - 7.dp.toPx()); close() }
                drawPath(t, Color(0xFFFF8A3D))
            }
        }
        // agulha
        drawLine(Color.White, Offset(w / 2f, 0f), Offset(w / 2f, h), 2.dp.toPx())
        val tri = Path().apply {
            moveTo(w / 2f - 6.dp.toPx(), 0f)
            lineTo(w / 2f + 6.dp.toPx(), 0f)
            lineTo(w / 2f, 7.dp.toPx())
            close()
        }
        drawPath(tri, deckColor)
    }
}

internal val HOT_COLORS = listOf(Color(0xFFFF5A5F), Color(0xFFFFD166), Color(0xFF4CD08A), Color(0xFFB57BFF))

/** Visão geral da faixa inteira. Toque ou arraste para ir a outro ponto. */
@Composable
fun OverviewStrip(
    peaks: ByteArray?,
    position: () -> Long,
    lengthFrames: Long,
    deckColor: Color,
    description: String,
    onSeek: (Float) -> Unit,
    modifier: Modifier = Modifier,
    hotcues: List<Long> = emptyList(),
    loop: Pair<Long, Long>? = null,
) {
    val latest = rememberUpdatedState(onSeek)
    val paints = remember { specPaints() }
    BoxWithConstraints(
        modifier
            .background(Color(0xFF050608))
            .semantics { contentDescription = description }
            .pointerInput(Unit) {
                awaitEachGesture {
                    val down = awaitFirstDown()
                    down.consume()
                    latest.value(down.position.x / size.width)
                    do {
                        val event = awaitPointerEvent()
                        val change = event.changes.first()
                        if (change.pressed) {
                            latest.value(change.position.x / size.width)
                            change.consume()
                        }
                    } while (event.changes.any { it.pressed })
                }
            },
    ) {
        val widthPx = with(LocalDensity.current) { maxWidth.roundToPx() }
        val heightPx = with(LocalDensity.current) { maxHeight.roundToPx() }
        val lines = remember(peaks, widthPx, heightPx) { overviewLines(peaks, widthPx, heightPx) }
        Canvas(Modifier.fillMaxSize()) {
            val w = size.width
            val h = size.height
            if (lines.isEmpty() || lengthFrames <= 0) {
                drawLine(Metal.Border, Offset(0f, h / 2), Offset(w, h / 2), 1.dp.toPx())
                return@Canvas
            }
            val playedX = w * (position().toFloat() / lengthFrames).coerceIn(0f, 1f)
            val nc = drawContext.canvas.nativeCanvas
            for ((k, arr) in lines) {
                paints[k].strokeWidth = 1.2f
                nc.drawLines(arr, paints[k])
            }
            // parte já tocada escurecida (o que falta fica brilhante)
            drawRect(Color.Black.copy(alpha = 0.55f), Offset(0f, 0f), Size(playedX, h))
            // loop ativo (faixa clara) e hot cues (marcas coloridas no alto, como no VirtualDJ)
            if (loop != null && loop.second > loop.first) {
                val x0 = w * loop.first.toFloat() / lengthFrames
                val x1 = w * loop.second.toFloat() / lengthFrames
                drawRect(Color(0x5534C759), Offset(x0, 0f), Size((x1 - x0).coerceAtLeast(2f), h))
            }
            hotcues.forEachIndexed { i, f ->
                if (f >= 0) {
                    val x = w * f.toFloat() / lengthFrames
                    val c = HOT_COLORS[i % HOT_COLORS.size]
                    drawRect(c, Offset(x - 1f, 0f), Size(2f, h))
                    drawRect(c, Offset(x - 1f, 0f), Size(6.dp.toPx(), 4.dp.toPx()))
                }
            }
            drawLine(Color.White, Offset(playedX, 0f), Offset(playedX, h), 2.dp.toPx())
        }
    }
}

/** Linhas da visão geral agrupadas pela cor do espectro: (cor, pontos). */
private fun overviewLines(peaks: ByteArray?, width: Int, height: Int): List<Pair<Int, FloatArray>> {
    if (peaks == null || width <= 0) return emptyList()
    val bins = peaks.size / 3
    if (bins == 0) return emptyList()
    val per = Array(SPEC_N) { ArrayList<Float>() }
    val mid = height / 2f
    for (x in 0 until width) {
        val from = (x.toLong() * bins / width).toInt()
        val to = max(from + 1, ((x + 1).toLong() * bins / width).toInt()).coerceAtMost(bins)
        var m0 = 0; var m1 = 0; var m2 = 0
        for (b in from until to) {
            m0 = max(m0, peaks[b * 3].toInt() and 0xFF)
            m1 = max(m1, peaks[b * 3 + 1].toInt() and 0xFF)
            m2 = max(m2, peaks[b * 3 + 2].toInt() and 0xFF)
        }
        val a0 = sqrt(m0 / 255f); val a1 = sqrt(m1 / 255f); val a2 = sqrt(m2 / 255f)
        val a = max(1f, max(a0, max(a1, a2)) * mid * 0.95f)
        val l = per[specIndex(a0, a1, a2)]
        l.add(x + 0.5f); l.add(mid - a); l.add(x + 0.5f); l.add(mid + a)
    }
    return per.mapIndexedNotNull { k, l -> if (l.isEmpty()) null else k to l.toFloatArray() }
}

// ------------------------------------------------------------------ prato

/**
 * Prato virtual no estilo Serato/VirtualDJ: disco escuro com anel de progresso da faixa, marcador de posição
 * que gira (1 volta = 1,8 s, como 33⅓ rpm), ponto do CUE no anel e logotipo no centro.
 * Toque no meio do disco = scratch (modo vinil). Toque na borda com a música tocando = empurrar/segurar (pitch bend).
 * Nos últimos 30 s o anel pisca em vermelho, como aviso de fim de faixa.
 */
@Composable
fun Platter(
    deckColor: Color,
    position: () -> Long,
    lengthFrames: () -> Long,
    modifier: Modifier = Modifier,
    /** Scratch: (ativo, velocidade em múltiplos da normal). Nulo = o prato não reage ao toque. */
    onScratch: ((Boolean, Float) -> Unit)? = null,
    /** Borda do prato com a música tocando: (ativo, velocidade do giro). Nulo = a borda também faz scratch. */
    onBend: ((Boolean, Float) -> Unit)? = null,
    /** O prato só empurra (sem scratch) — modo vinil desligado. */
    vinyl: () -> Boolean = { true },
    playing: () -> Boolean = { false },
    cue: () -> Long = { -1L },
    center: @Composable BoxScope.() -> Unit = {},
) {
    val scratchCb = rememberUpdatedState(onScratch)
    val bendCb = rememberUpdatedState(onBend)
    var touched by remember { mutableStateOf(0) }     // 0 solto, 1 scratch, 2 empurrando
    Box(
        modifier.pointerInput(onScratch != null) {
            if (onScratch == null) return@pointerInput
            awaitEachGesture {
                val down = awaitFirstDown(requireUnconsumed = false)
                val cx = size.width / 2f
                val cy = size.height / 2f
                val radius = min(size.width, size.height) / 2f
                val dx0 = down.position.x - cx
                val dy0 = down.position.y - cy
                val onRim = dx0 * dx0 + dy0 * dy0 > 0.78f * 0.78f * radius * radius
                // borda (ou vinil desligado) com a música tocando: empurra/segura em vez de scratch
                val bend = bendCb.value != null && playing() && (onRim || !vinyl())
                val cb: ((Boolean, Float) -> Unit)? = if (bend) bendCb.value else scratchCb.value
                touched = if (bend) 2 else 1
                var lastAng = atan2(dy0, dx0)
                var lastT = down.uptimeMillis
                var vel = 0f
                cb?.invoke(true, 0f)
                while (true) {
                    val ev = withTimeoutOrNull(30L) { awaitPointerEvent() }
                    if (ev == null) {                      // dedo parado: o disco fica preso na mão
                        vel = 0f
                        cb?.invoke(true, 0f)
                        continue
                    }
                    val ch = ev.changes.firstOrNull() ?: break
                    if (!ch.pressed) break
                    val dx = ch.position.x - cx
                    val dy = ch.position.y - cy
                    if (dx * dx + dy * dy > 0.12f * radius * radius) {   // perto do centro o ângulo é instável
                        val ang = atan2(dy, dx)
                        var d = ang - lastAng
                        if (d > PI.toFloat()) d -= 2f * PI.toFloat()
                        if (d < -PI.toFloat()) d += 2f * PI.toFloat()
                        val dt = (ch.uptimeMillis - lastT) / 1000f
                        // eventos com o mesmo horário (telas de alta taxa): acumula o ângulo até o tempo andar
                        if (dt > 0.001f) {
                            // uma volta do prato = 1,8 s de música (33⅓ rpm)
                            val v = (d / (2f * PI.toFloat())) * 1.8f / dt
                            vel = 0.5f * vel + 0.5f * v.coerceIn(-8f, 8f)
                            cb?.invoke(true, vel)
                            lastAng = ang
                            lastT = ch.uptimeMillis
                        }
                    }
                    ch.consume()
                }
                cb?.invoke(false, 0f)
                touched = 0
            }
        },
        contentAlignment = Alignment.Center,
    ) {
        // base: disco escuro, sulcos e anel
        Canvas(Modifier.fillMaxSize()) {
            val r = min(size.width, size.height) / 2f
            val c = Offset(size.width / 2f, size.height / 2f)
            drawCircle(Color.Black.copy(alpha = 0.6f), radius = r, center = Offset(c.x, c.y + 2.dp.toPx()))
            drawCircle(Brush.radialGradient(listOf(Color(0xFF26292E), Color(0xFF14161A)), c, r), radius = r, center = c)
            drawCircle(Color(0xFF3A4048), radius = r - 0.5f, center = c, style = Stroke(1f))
            // disco (vinil) com sulcos
            drawCircle(Color(0xFF08090A), radius = r * 0.84f, center = c)
            var gr = r * 0.36f
            var n = 0
            while (gr < r * 0.82f) {
                drawCircle(Color.White.copy(alpha = if (n % 4 == 0) 0.07f else 0.028f), radius = gr, center = c, style = Stroke(1f))
                gr += r * 0.028f
                n++
            }
        }
        // camada que gira: marcador de posição e reflexo (GPU, sem redesenhar a base)
        Canvas(
            Modifier.fillMaxSize().graphicsLayer {
                rotationZ = (((position() / 48000.0) * (100.0 / 3.0 / 60.0) * 360.0) % 360.0).toFloat()
            },
        ) {
            val r = min(size.width, size.height) / 2f
            val c = Offset(size.width / 2f, size.height / 2f)
            val sheen = Path().apply {
                moveTo(c.x, c.y)
                lineTo(c.x - r * 0.80f, c.y - r * 0.30f)
                lineTo(c.x - r * 0.30f, c.y - r * 0.80f)
                close()
            }
            drawPath(sheen, Color.White.copy(alpha = 0.045f))
            // marcador de posição: traço claro da borda do disco até perto do selo
            drawLine(Color.White, Offset(c.x, c.y - r * 0.83f), Offset(c.x, c.y - r * 0.40f), 3.dp.toPx(), StrokeCap.Round)
            drawCircle(deckColor, radius = r * 0.035f, center = Offset(c.x, c.y - r * 0.83f))
        }
        // anel de progresso, CUE e destaque do toque
        Canvas(Modifier.fillMaxSize()) {
            val r = min(size.width, size.height) / 2f
            val c = Offset(size.width / 2f, size.height / 2f)
            val len = lengthFrames()
            val pos = position()
            val p = if (len > 0) (pos.toFloat() / len).coerceIn(0f, 1f) else 0f
            val remainSec = if (len > 0) (len - pos) / 48000.0 else 999.0
            val warn = len > 0 && remainSec < 30.0 && playing()
            val blink = warn && ((System.currentTimeMillis() / 400) % 2 == 0L)
            val sw = 5.dp.toPx()
            val rr = r * 0.92f
            val tl = Offset(c.x - rr, c.y - rr)
            val sz = Size(rr * 2, rr * 2)
            drawArc(Color(0xFF2A2F35), -90f, 360f, false, tl, sz, style = Stroke(sw))
            if (p > 0f) {
                val col = if (blink) Color(0xFFFF2A2A) else if (warn) Color(0xFF8A1A1A) else Color(0xFFE6E9EC)
                drawArc(col, -90f, 360f * p, false, tl, sz, style = Stroke(sw, cap = StrokeCap.Butt))
            }
            val cf = cue()
            if (len > 0 && cf >= 0) {
                val a = Math.toRadians(-90.0 + 360.0 * cf / len)
                drawCircle(Color(0xFFFF8A3D), radius = 3.5f.dp.toPx(), center = Offset(c.x + cos(a).toFloat() * rr, c.y + sin(a).toFloat() * rr))
            }
            when (touched) {
                1 -> drawCircle(deckColor.copy(alpha = 0.9f), radius = r * 0.84f, center = c, style = Stroke(2.5f.dp.toPx()))
                2 -> drawCircle(Color(0xFF4FC3F7), radius = r - 2.dp.toPx(), center = c, style = Stroke(3.dp.toPx()))
            }
        }
        center()
    }
}
