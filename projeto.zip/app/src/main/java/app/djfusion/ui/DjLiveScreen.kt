package app.djfusion.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.role
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import app.djfusion.ui.theme.Metal
import kotlin.math.min

internal fun deckColor(deck: Int): Color = if (deck == 0) Metal.DeckA else Metal.DeckB
private fun onDeckColor(deck: Int): Color = if (deck == 0) Metal.OnDeckA else Metal.OnDeckB

/**
 * Tela DJ Live da v1. Só aparece o que funciona: play, cue, volume, crossfader, master, busca pela
 * onda, vinil e medidores. EQ, pitch, sync, hot cues, loops e efeitos entram nos marcos seguintes.
 */
@Composable
fun DjLiveScreen(vm: AppViewModel) {
    val decks by vm.decks.collectAsStateWithLifecycle()
    Column(Modifier.fillMaxSize().background(Metal.Bg)) {
        WaveRow(vm, 0, decks[0])
        WaveRow(vm, 1, decks[1])
        Row(Modifier.fillMaxWidth().weight(1f)) {
            DeckPanel(vm, 0, decks[0], Modifier.weight(1f).fillMaxHeight())
            MixerPanel(vm, Modifier.width(316.dp).fillMaxHeight())
            DeckPanel(vm, 1, decks[1], Modifier.weight(1f).fillMaxHeight())
        }
    }
}

@Composable
private fun WaveRow(vm: AppViewModel, deck: Int, ui: DeckUi) {
    val live by vm.live.collectAsStateWithLifecycle()
    val l = live.decks[deck]
    val name = AppViewModel.deckName(deck)
    Box(Modifier.fillMaxWidth().height(36.dp)) {
        WaveformStrip(
            peaks = ui.wave,
            positionFrames = l.positionFrames,
            lengthFrames = ui.lengthFrames,
            cueFrames = l.cueFrames,
            deckColor = deckColor(deck),
            description = "Forma de onda do deck $name. Toque para ir a outro ponto da música.",
            onSeek = { vm.seekFraction(deck, it) },
            modifier = Modifier.fillMaxSize(),
        )
        val overlay = when {
            ui.loading -> "Carregando deck $name… ${(ui.loadProgress * 100).toInt()}%"
            !ui.loaded -> "Deck $name vazio"
            else -> null
        }
        if (overlay != null) {
            Text(
                overlay, color = Metal.TextMuted, fontSize = 12.sp, fontWeight = FontWeight.SemiBold,
                modifier = Modifier.align(Alignment.Center),
            )
        } else {
            Text(
                "-" + formatTimeTenths(framesToMs(ui.lengthFrames - l.positionFrames)),
                color = Metal.Text, fontSize = 12.sp, fontFamily = FontFamily.Monospace, fontWeight = FontWeight.Bold,
                modifier = Modifier.align(Alignment.TopEnd).padding(end = 8.dp, top = 2.dp)
                    .background(Color(0xCC0E1013), RoundedCornerShape(4.dp)).padding(horizontal = 4.dp),
            )
        }
    }
}

@Composable
private fun DeckPanel(vm: AppViewModel, deck: Int, ui: DeckUi, modifier: Modifier) {
    val live by vm.live.collectAsStateWithLifecycle()
    val l = live.decks[deck]
    val color = deckColor(deck)
    val name = AppViewModel.deckName(deck)
    Column(modifier.background(Metal.Surface)) {
        Box(Modifier.fillMaxWidth().height(2.dp).background(color))
        Row(
            Modifier.fillMaxWidth().padding(horizontal = 10.dp, vertical = 6.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            Box(
                Modifier.size(36.dp).clip(RoundedCornerShape(8.dp)).background(color),
                contentAlignment = Alignment.Center,
            ) {
                Text(name, color = onDeckColor(deck), fontSize = 20.sp, fontWeight = FontWeight.ExtraBold)
            }
            Column(Modifier.weight(1f).padding(horizontal = 10.dp)) {
                Text(
                    if (ui.title.isNotEmpty()) ui.title else "Sem música",
                    color = Metal.Text, fontSize = 14.sp, fontWeight = FontWeight.Bold, maxLines = 1,
                    overflow = TextOverflow.Ellipsis,
                )
                Text(
                    if (ui.loaded || ui.loading) ui.artist else "Abra a Biblioteca e toque em $name",
                    color = Metal.TextMuted, fontSize = 12.sp, maxLines = 1, overflow = TextOverflow.Ellipsis,
                )
            }
            Column(horizontalAlignment = Alignment.End) {
                Text(
                    if (ui.loaded) formatTimeTenths(framesToMs(l.positionFrames)) else "--:--.-",
                    color = color, fontSize = 20.sp, fontFamily = FontFamily.Monospace, fontWeight = FontWeight.Bold,
                )
                if (ui.loaded && !ui.loading) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        if (ui.hasBpm) {
                            SmallTextButton("÷2", "Dividir o andamento detectado por 2", enabled = true) { vm.scaleBpm(deck, 0.5) }
                            Text(
                                String.format(java.util.Locale.ROOT, "%.1f BPM", ui.playedBpm),
                                color = Metal.Text, fontSize = 12.sp, fontFamily = FontFamily.Monospace,
                                fontWeight = FontWeight.Bold, modifier = Modifier.padding(horizontal = 4.dp),
                            )
                            SmallTextButton("×2", "Dobrar o andamento detectado", enabled = true) { vm.scaleBpm(deck, 2.0) }
                        } else {
                            Text("sem BPM", color = Metal.TextMuted, fontSize = 12.sp)
                        }
                    }
                }
            }
        }
        Column(Modifier.weight(1f).fillMaxWidth().padding(horizontal = 10.dp, vertical = 4.dp)) {
            BoxWithConstraints(Modifier.weight(1f).fillMaxWidth()) {
                val buttonsWidth = 76.dp
                val pitchWidth = 44.dp
                val side = min(maxHeight.value, maxWidth.value - buttonsWidth.value - pitchWidth.value - 20f)
                    .coerceAtLeast(60f).dp
                Row(Modifier.fillMaxSize(), verticalAlignment = Alignment.CenterVertically) {
                    val platter = @Composable {
                        Platter(
                            deckColor = color,
                            positionFrames = l.positionFrames,
                            lengthFrames = ui.lengthFrames,
                            armOnRight = deck == 1,
                            modifier = Modifier.size(side),
                        )
                    }
                    val controls = @Composable {
                        Column(
                            Modifier.width(buttonsWidth).fillMaxHeight(),
                            verticalArrangement = Arrangement.spacedBy(6.dp),
                            horizontalAlignment = Alignment.CenterHorizontally,
                        ) {
                            MetalButton(
                                description = if (ui.playing) "Pausar deck $name" else "Tocar deck $name",
                                onPress = { vm.togglePlay(deck) },
                                enabled = ui.loaded && !ui.loading,
                                led = color, ledOn = ui.playing,
                                modifier = Modifier.fillMaxWidth().weight(1.3f),
                            ) {
                                TransportGlyph(ui.playing, Modifier.size(26.dp))
                            }
                            MetalButton(
                                description = "Cue do deck $name. Parado: marca o ponto. Tocando: volta ao ponto e para.",
                                onPress = { vm.cue(deck) },
                                enabled = ui.loaded && !ui.loading,
                                modifier = Modifier.fillMaxWidth().weight(1f),
                            ) {
                                Text("CUE", color = Metal.OnMetal, fontSize = 15.sp, fontWeight = FontWeight.ExtraBold)
                            }
                            MetalButton(
                                description = "Sync do deck $name. Iguala o andamento ao do outro deck e alinha a batida.",
                                onPress = { vm.sync(deck) },
                                enabled = ui.loaded && !ui.loading,
                                modifier = Modifier.fillMaxWidth().weight(0.9f),
                            ) {
                                Text("SYNC", color = Metal.OnMetal, fontSize = 13.sp, fontWeight = FontWeight.ExtraBold)
                            }
                        }
                    }
                    val pitch = @Composable {
                        Column(Modifier.width(pitchWidth).fillMaxHeight(), horizontalAlignment = Alignment.CenterHorizontally) {
                            Text(
                                String.format(java.util.Locale.ROOT, "%+.1f%%", (ui.rate - 1f) * 100f),
                                color = Metal.TextMuted, fontSize = 10.sp, fontFamily = FontFamily.Monospace,
                            )
                            MetalFader(
                                value = (ui.rate - AppViewModel.PITCH_MIN) / (AppViewModel.PITCH_MAX - AppViewModel.PITCH_MIN),
                                onChange = { vm.setPitchFader(deck, it) },
                                accent = color,
                                description = "Pitch do deck $name. Para cima acelera, para baixo desacelera. Meio é a velocidade normal.",
                                modifier = Modifier.fillMaxWidth().weight(1f),
                            )
                        }
                    }
                    if (deck == 0) {
                        platter()
                        Spacer(Modifier.width(8.dp))
                        controls()
                        Spacer(Modifier.width(4.dp))
                        pitch()
                    } else {
                        pitch()
                        Spacer(Modifier.width(4.dp))
                        controls()
                        Spacer(Modifier.width(8.dp))
                        platter()
                    }
                }
            }
            Spacer(Modifier.height(4.dp))
            Row(Modifier.fillMaxWidth().height(40.dp), horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                for (slot in 0..3) {
                    HotCuePad(
                        slot = slot, frame = ui.hotcues[slot], enabled = ui.loaded && !ui.loading,
                        deckName = name, onTap = { vm.hotcue(deck, slot) }, onLong = { vm.clearHotcue(deck, slot) },
                        modifier = Modifier.weight(1f).fillMaxHeight(),
                    )
                }
                Spacer(Modifier.width(6.dp))
                for (beats in intArrayOf(1, 2, 4, 8)) {
                    MetalButton(
                        description = "Loop de $beats batida(s) no deck $name. Toque de novo para soltar.",
                        onPress = { vm.toggleLoop(deck, beats) },
                        enabled = ui.loaded && !ui.loading,
                        led = color, ledOn = ui.loopBeats == beats,
                        modifier = Modifier.weight(1f).fillMaxHeight(),
                    ) {
                        Text("$beats", color = Metal.OnMetal, fontSize = 14.sp, fontWeight = FontWeight.ExtraBold)
                    }
                }
            }
        }
    }
}

private val padColors = listOf(Color(0xFFFF5A5F), Color(0xFFFFD166), Color(0xFF4CD08A), Color(0xFFB57BFF))

/** Pad de hot cue: vazio grava a posição atual, gravado vai até ela e toca, toque longo apaga. */
@Composable
private fun HotCuePad(
    slot: Int, frame: Long, enabled: Boolean, deckName: String,
    onTap: () -> Unit, onLong: () -> Unit, modifier: Modifier,
) {
    val set = frame >= 0
    val bg = when {
        !enabled -> Color(0xFF23282D)
        set -> padColors[slot]
        else -> Color(0xFF30363D)
    }
    Box(
        modifier
            .semantics {
                contentDescription = if (set) {
                    "Hot cue ${slot + 1} do deck $deckName. Toque para ir até ela. Segure para apagar."
                } else {
                    "Hot cue ${slot + 1} do deck $deckName, vazia. Toque para gravar a posição atual."
                }
                role = Role.Button
            }
            .clip(RoundedCornerShape(8.dp))
            .background(bg)
            .pointerInput(enabled, set) {
                detectTapGestures(
                    onTap = { if (enabled) onTap() },
                    onLongPress = { if (enabled && set) onLong() },
                )
            },
        contentAlignment = Alignment.Center,
    ) {
        Text(
            "${slot + 1}",
            color = if (set && enabled) Color(0xFF14171B) else Metal.TextMuted,
            fontSize = 14.sp, fontWeight = FontWeight.ExtraBold,
        )
    }
}

@Composable
private fun SmallTextButton(label: String, description: String, enabled: Boolean, onClick: () -> Unit) {
    Box(
        Modifier
            .semantics { contentDescription = description; role = Role.Button }
            .clip(RoundedCornerShape(6.dp))
            .background(Color(0xFF30363D))
            .pointerInput(enabled) { detectTapGestures(onTap = { if (enabled) onClick() }) }
            .padding(horizontal = 6.dp, vertical = 2.dp),
        contentAlignment = Alignment.Center,
    ) {
        Text(label, color = Metal.Text, fontSize = 11.sp, fontWeight = FontWeight.Bold)
    }
}

@Composable
private fun MixerPanel(vm: AppViewModel, modifier: Modifier) {
    val volumes by vm.volumes.collectAsStateWithLifecycle()
    val decks by vm.decks.collectAsStateWithLifecycle()
    val cross by vm.crossfader.collectAsStateWithLifecycle()
    val master by vm.master.collectAsStateWithLifecycle()
    val live by vm.live.collectAsStateWithLifecycle()
    val darkHandle = Color(0xFF14171B)
    Column(
        modifier.background(Color(0xFF13161A)).padding(horizontal = 10.dp, vertical = 6.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
    ) {
        Text("MASTER", color = Metal.TextMuted, fontSize = 11.sp, fontWeight = FontWeight.Bold, letterSpacing = 2.sp)
        MetalFader(
            value = master, onChange = vm::setMaster, accent = darkHandle, description = "Volume master",
            modifier = Modifier.fillMaxWidth().height(34.dp), vertical = false,
        )
        LevelMeter(live.masterPeak, Modifier.fillMaxWidth().height(8.dp), vertical = false, segments = 24)
        Row(
            Modifier.weight(1f).fillMaxWidth().padding(vertical = 2.dp),
            horizontalArrangement = Arrangement.SpaceEvenly,
        ) {
            ChannelStrip(vm, 0, decks[0], volumes[0], live.decks[0].peak, Modifier.weight(1f).fillMaxHeight())
            ChannelStrip(vm, 1, decks[1], volumes[1], live.decks[1].peak, Modifier.weight(1f).fillMaxHeight())
        }
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
            Text("A", color = Metal.DeckA, fontSize = 13.sp, fontWeight = FontWeight.ExtraBold)
            Text("CROSSFADER", color = Metal.TextMuted, fontSize = 10.sp, fontWeight = FontWeight.Bold, letterSpacing = 1.sp, textAlign = TextAlign.Center)
            Text("B", color = Metal.DeckB, fontSize = 13.sp, fontWeight = FontWeight.ExtraBold)
        }
        MetalFader(
            value = cross, onChange = vm::setCrossfader, accent = darkHandle,
            description = "Crossfader. Esquerda toca só o deck A, direita só o deck B.",
            modifier = Modifier.fillMaxWidth().height(40.dp), vertical = false,
        )
    }
}

@Composable
private fun ChannelStrip(vm: AppViewModel, deck: Int, d: DeckUi, volume: Float, peak: Float, modifier: Modifier) {
    val name = AppViewModel.deckName(deck)
    val color = deckColor(deck)
    Column(modifier.padding(horizontal = 2.dp), horizontalAlignment = Alignment.CenterHorizontally) {
        MetalFader(
            value = d.filter, onChange = { vm.setFilter(deck, it) }, accent = color,
            description = "Filtro do deck $name. Esquerda corta os agudos, direita corta os graves, meio desliga.",
            modifier = Modifier.fillMaxWidth().height(32.dp), vertical = false,
        )
        Row(Modifier.weight(1f), horizontalArrangement = Arrangement.spacedBy(2.dp)) {
            val labels = listOf("GRA", "MED", "AGU")
            for (band in 0..2) {
                Column(Modifier.width(30.dp).fillMaxHeight(), horizontalAlignment = Alignment.CenterHorizontally) {
                    MetalFader(
                        value = d.eq[band], onChange = { vm.setEq(deck, band, it) }, accent = color,
                        description = "Equalizador ${listOf("graves", "médios", "agudos")[band]} do deck $name. Meio é neutro, embaixo corta.",
                        modifier = Modifier.fillMaxWidth().weight(1f),
                    )
                    Text(labels[band], color = Metal.TextMuted, fontSize = 9.sp, fontWeight = FontWeight.Bold)
                }
            }
            Column(Modifier.width(36.dp).fillMaxHeight(), horizontalAlignment = Alignment.CenterHorizontally) {
                MetalFader(
                    value = volume, onChange = { vm.setVolume(deck, it) }, accent = color,
                    description = "Volume do deck $name", modifier = Modifier.fillMaxWidth().weight(1f),
                )
                Text(name, color = color, fontSize = 13.sp, fontWeight = FontWeight.ExtraBold)
            }
            LevelMeter(peak, Modifier.width(10.dp).fillMaxHeight().padding(top = 6.dp, bottom = 20.dp))
        }
    }
}
