package app.djfusion.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.State
import androidx.compose.foundation.layout.BoxScope
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.role
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import app.djfusion.ui.theme.Metal
import kotlin.math.min

internal fun deckColor(deck: Int): Color = if (deck == 0) Metal.DeckA else Metal.DeckB
private fun onDeckColor(deck: Int): Color = if (deck == 0) Metal.OnDeckA else Metal.OnDeckB

/**
 * Tela DJ Live. Duas ondas rolantes no alto, cada deck de um lado e a mesa de mixagem no meio.
 * A posição e o nível mudam 30 vezes por segundo e só são lidos nos pontos que os desenham (ondas,
 * vinil, medidores e tempos), para o resto da tela não ser recomposto e a interface não travar.
 */
@Composable
fun DjLiveScreen(vm: AppViewModel) {
    val decks by vm.decks.collectAsStateWithLifecycle()
    val live = vm.live.collectAsStateWithLifecycle()
    Column(Modifier.fillMaxSize().background(Metal.Bg)) {
        WaveBlock(vm, 0, decks[0], live)
        Spacer(Modifier.height(2.dp))
        WaveBlock(vm, 1, decks[1], live)
        Spacer(Modifier.height(2.dp))
        Row(Modifier.fillMaxWidth().weight(1f)) {
            DeckPanel(vm, 0, decks[0], live, Modifier.weight(1f).fillMaxHeight())
            MixerPanel(vm, live, Modifier.width(330.dp).fillMaxHeight())
            DeckPanel(vm, 1, decks[1], live, Modifier.weight(1f).fillMaxHeight())
        }
    }
}

@Composable
private fun WaveBlock(vm: AppViewModel, deck: Int, ui: DeckUi, live: State<LiveUi>) {
    val name = AppViewModel.deckName(deck)
    val color = deckColor(deck)
    Column(Modifier.fillMaxWidth().height(82.dp)) {
        Box(Modifier.fillMaxWidth().weight(1f)) {
            ScrollingWave(
                peaks = ui.wave,
                position = { live.value.decks[deck].positionFrames },
                bpm = if (ui.hasBpm) ui.bpm else 0.0,
                firstBeatFrame = ui.firstBeatFrame,
                hotcues = ui.hotcues,
                cue = { live.value.decks[deck].cueFrames },
                deckColor = color,
                modifier = Modifier.fillMaxSize(),
            )
            Row(
                Modifier.align(Alignment.TopStart).padding(6.dp),
                verticalAlignment = Alignment.CenterVertically,
            ) {
                Box(
                    Modifier.size(26.dp).clip(RoundedCornerShape(6.dp)).background(color),
                    contentAlignment = Alignment.Center,
                ) {
                    Text(name, color = onDeckColor(deck), fontSize = 16.sp, fontWeight = FontWeight.ExtraBold)
                }
                Column(
                    Modifier.padding(start = 8.dp)
                        .background(Color(0xAA000000), RoundedCornerShape(4.dp)).padding(horizontal = 6.dp, vertical = 1.dp),
                ) {
                    val overlay = when {
                        ui.loading -> "Carregando… ${(ui.loadProgress * 100).toInt()}%"
                        !ui.loaded -> "Deck $name vazio · abra a Biblioteca"
                        else -> null
                    }
                    Text(
                        overlay ?: ui.title, color = Metal.Text, fontSize = 13.sp, fontWeight = FontWeight.Bold,
                        maxLines = 1, overflow = TextOverflow.Ellipsis,
                    )
                    if (overlay == null && ui.artist.isNotEmpty()) {
                        Text(ui.artist, color = Metal.TextMuted, fontSize = 11.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
                    }
                }
            }
            if (ui.loaded && !ui.loading) {
                RemainingText(live, deck, ui.lengthFrames, Modifier.align(Alignment.TopEnd).padding(6.dp))
            }
        }
        OverviewStrip(
            peaks = ui.wave,
            position = { live.value.decks[deck].positionFrames },
            lengthFrames = ui.lengthFrames,
            deckColor = color,
            description = "Visão geral do deck $name. Toque para ir a outro ponto da música.",
            onSeek = { vm.seekFraction(deck, it) },
            modifier = Modifier.fillMaxWidth().height(16.dp),
        )
    }
}

@Composable
private fun RemainingText(live: State<LiveUi>, deck: Int, length: Long, modifier: Modifier) {
    val pos = live.value.decks[deck].positionFrames
    Text(
        "-" + formatTimeTenths(framesToMs(length - pos)),
        color = Metal.Text, fontSize = 14.sp, fontFamily = FontFamily.Monospace, fontWeight = FontWeight.Bold,
        modifier = modifier.background(Color(0xAA000000), RoundedCornerShape(4.dp)).padding(horizontal = 6.dp, vertical = 1.dp),
    )
}

@Composable
private fun ElapsedText(live: State<LiveUi>, deck: Int, loaded: Boolean, color: Color) {
    val pos = live.value.decks[deck].positionFrames
    Text(
        if (loaded) formatTimeTenths(framesToMs(pos)) else "--:--.-",
        color = color, fontSize = 24.sp, fontFamily = FontFamily.Monospace, fontWeight = FontWeight.Bold,
    )
}

@Composable
private fun DeckPanel(vm: AppViewModel, deck: Int, ui: DeckUi, live: State<LiveUi>, modifier: Modifier) {
    val color = deckColor(deck)
    val name = AppViewModel.deckName(deck)
    val ready = ui.loaded && !ui.loading
    Column(
        modifier.background(Brush.verticalGradient(listOf(Color(0xFF1B1F24), Color(0xFF111316)))),
    ) {
        Box(Modifier.fillMaxWidth().height(3.dp).background(color))
        Row(
            Modifier.fillMaxWidth().padding(horizontal = 10.dp, vertical = 4.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            ElapsedText(live, deck, ui.loaded, color)
            Spacer(Modifier.weight(1f))
            if (ready) {
                if (ui.hasBpm) {
                    SmallTextButton("÷2", "Dividir o andamento detectado por 2") { vm.scaleBpm(deck, 0.5) }
                    Column(Modifier.padding(horizontal = 8.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                        Text(
                            String.format(java.util.Locale.ROOT, "%.1f", ui.playedBpm),
                            color = Metal.Text, fontSize = 24.sp, fontFamily = FontFamily.Monospace, fontWeight = FontWeight.ExtraBold,
                        )
                        Text("BPM", color = Metal.TextMuted, fontSize = 9.sp, fontWeight = FontWeight.Bold, letterSpacing = 2.sp)
                    }
                    SmallTextButton("×2", "Dobrar o andamento detectado") { vm.scaleBpm(deck, 2.0) }
                } else {
                    Text("sem BPM", color = Metal.TextMuted, fontSize = 12.sp)
                }
                Text(
                    String.format(java.util.Locale.ROOT, "%+.1f%%", (ui.rate - 1f) * 100f),
                    color = if (ui.rate == 1f) Metal.TextMuted else color,
                    fontSize = 13.sp, fontFamily = FontFamily.Monospace, fontWeight = FontWeight.Bold,
                    modifier = Modifier.padding(start = 10.dp),
                )
            }
        }
        BoxWithConstraints(Modifier.weight(1f).fillMaxWidth().padding(horizontal = 10.dp, vertical = 2.dp)) {
            val buttonsWidth = 84.dp
            val pitchWidth = 46.dp
            val side = min(maxHeight.value, maxWidth.value - buttonsWidth.value - pitchWidth.value - 20f)
                .coerceAtLeast(60f).dp
            Row(Modifier.fillMaxSize(), verticalAlignment = Alignment.CenterVertically) {
                val platter = @Composable {
                    Platter(
                        deckColor = color,
                        position = { live.value.decks[deck].positionFrames },
                        lengthFrames = { ui.lengthFrames },
                        modifier = Modifier.size(side),
                    )
                }
                val controls = @Composable {
                    Column(
                        Modifier.width(buttonsWidth).fillMaxHeight().padding(vertical = 2.dp),
                        verticalArrangement = Arrangement.spacedBy(6.dp),
                        horizontalAlignment = Alignment.CenterHorizontally,
                    ) {
                        MetalButton(
                            description = if (ui.playing) "Pausar deck $name" else "Tocar deck $name",
                            onPress = { vm.togglePlay(deck) },
                            enabled = ready,
                            led = color, ledOn = ui.playing,
                            modifier = Modifier.fillMaxWidth().weight(1.4f),
                        ) {
                            TransportGlyph(ui.playing, if (ui.playing) color else Metal.OnMetal, Modifier.size(28.dp))
                        }
                        MetalButton(
                            description = "Cue do deck $name. Parado: marca o ponto. Tocando: volta ao ponto e para.",
                            onPress = { vm.cue(deck) },
                            enabled = ready,
                            modifier = Modifier.fillMaxWidth().weight(1f),
                        ) {
                            Text("CUE", color = Color(0xFFFF9F4A), fontSize = 15.sp, fontWeight = FontWeight.ExtraBold, letterSpacing = 1.sp)
                        }
                        MetalButton(
                            description = "Sync do deck $name. Iguala o andamento ao do outro deck e alinha a batida.",
                            onPress = { vm.sync(deck) },
                            enabled = ready,
                            modifier = Modifier.fillMaxWidth().weight(0.9f),
                        ) {
                            Text("SYNC", color = Metal.OnMetal, fontSize = 13.sp, fontWeight = FontWeight.ExtraBold, letterSpacing = 1.sp)
                        }
                    }
                }
                val pitch = @Composable {
                    Column(Modifier.width(pitchWidth).fillMaxHeight(), horizontalAlignment = Alignment.CenterHorizontally) {
                        Text("PITCH", color = Metal.TextMuted, fontSize = 9.sp, fontWeight = FontWeight.Bold, letterSpacing = 1.sp)
                        MetalFader(
                            value = (ui.rate - AppViewModel.PITCH_MIN) / (AppViewModel.PITCH_MAX - AppViewModel.PITCH_MIN),
                            onChange = { vm.setPitchFader(deck, it) },
                            accent = color,
                            description = "Pitch do deck $name. Para cima acelera, para baixo desacelera. Meio é a velocidade normal.",
                            modifier = Modifier.fillMaxWidth().weight(1f),
                        )
                    }
                }
                if (deck == 0) {
                    platter()
                    Spacer(Modifier.width(10.dp))
                    controls()
                    Spacer(Modifier.width(4.dp))
                    pitch()
                } else {
                    pitch()
                    Spacer(Modifier.width(4.dp))
                    controls()
                    Spacer(Modifier.width(10.dp))
                    platter()
                }
            }
        }
        Row(
            Modifier.fillMaxWidth().height(48.dp).padding(horizontal = 10.dp, vertical = 4.dp),
            horizontalArrangement = Arrangement.spacedBy(5.dp),
        ) {
            for (slot in 0..3) {
                HotCuePad(
                    slot = slot, frame = ui.hotcues[slot], enabled = ready,
                    deckName = name, onTap = { vm.hotcue(deck, slot) }, onLong = { vm.clearHotcue(deck, slot) },
                    modifier = Modifier.weight(1f).fillMaxHeight(),
                )
            }
            Spacer(Modifier.width(8.dp))
            for (beats in intArrayOf(1, 2, 4, 8)) {
                MetalButton(
                    description = "Loop de $beats batida(s) no deck $name. Toque de novo para soltar.",
                    onPress = { vm.toggleLoop(deck, beats) },
                    enabled = ready,
                    led = color, ledOn = ui.loopBeats == beats,
                    modifier = Modifier.weight(1f).fillMaxHeight(),
                ) {
                    Text("$beats", color = if (ui.loopBeats == beats) color else Metal.OnMetal, fontSize = 15.sp, fontWeight = FontWeight.ExtraBold)
                }
            }
        }
        Spacer(Modifier.height(2.dp))
    }
}

/** Pad de hot cue: vazio grava a posição atual, gravado vai até ela e toca, toque longo apaga. */
@Composable
private fun HotCuePad(
    slot: Int, frame: Long, enabled: Boolean, deckName: String,
    onTap: () -> Unit, onLong: () -> Unit, modifier: Modifier,
) {
    val set = frame >= 0
    val c = HOT_COLORS[slot]
    Box(
        modifier
            .semantics {
                contentDescription = if (set) {
                    "Hot cue ${slot + 1} do deck $deckName. Toque para ir até ela. Segure para apagar."
                } else {
                    "Hot cue ${slot + 1} do deck $deckName, vazia. Toque para gravar a posição atual."
                }
                role = Role.Button
            }
            .clip(RoundedCornerShape(8.dp))
            .drawBehind {
                val corner = CornerRadius(8.dp.toPx())
                if (!enabled) {
                    drawRoundRect(Color(0xFF1E2226), cornerRadius = corner)
                } else if (set) {
                    drawRoundRect(Brush.verticalGradient(listOf(c, c.copy(alpha = 0.62f))), cornerRadius = corner)
                    drawRoundRect(Color.White.copy(alpha = 0.35f), cornerRadius = corner, style = Stroke(1.dp.toPx()))
                } else {
                    drawRoundRect(Color(0xFF1B1E22), cornerRadius = corner)
                    drawRoundRect(c.copy(alpha = 0.45f), cornerRadius = corner, style = Stroke(1.5f.dp.toPx()))
                }
            }
            .pointerInput(enabled, set) {
                detectTapGestures(
                    onTap = { if (enabled) onTap() },
                    onLongPress = { if (enabled && set) onLong() },
                )
            },
        contentAlignment = Alignment.Center,
    ) {
        Text(
            "${slot + 1}",
            color = if (set && enabled) Color(0xFF14171B) else c.copy(alpha = if (enabled) 0.8f else 0.3f),
            fontSize = 16.sp, fontWeight = FontWeight.ExtraBold,
        )
    }
}

@Composable
private fun SmallTextButton(label: String, description: String, onClick: () -> Unit) {
    Box(
        Modifier
            .semantics { contentDescription = description; role = Role.Button }
            .clip(RoundedCornerShape(6.dp))
            .background(Color(0xFF2A2F35))
            .pointerInput(Unit) { detectTapGestures(onTap = { onClick() }) }
            .padding(horizontal = 8.dp, vertical = 5.dp),
        contentAlignment = Alignment.Center,
    ) {
        Text(label, color = Metal.Text, fontSize = 12.sp, fontWeight = FontWeight.Bold)
    }
}

@Composable
private fun MixerPanel(vm: AppViewModel, live: State<LiveUi>, modifier: Modifier) {
    val volumes by vm.volumes.collectAsStateWithLifecycle()
    val decks by vm.decks.collectAsStateWithLifecycle()
    val cross by vm.crossfader.collectAsStateWithLifecycle()
    val master by vm.master.collectAsStateWithLifecycle()
    val darkHandle = Color(0xFFE6E9EC)
    Column(
        modifier.background(Brush.verticalGradient(listOf(Color(0xFF181B1F), Color(0xFF0E1012))))
            .padding(horizontal = 10.dp, vertical = 6.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
    ) {
        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
            Text("MASTER", color = Metal.TextMuted, fontSize = 10.sp, fontWeight = FontWeight.Bold, letterSpacing = 1.5.sp)
            MetalFader(
                value = master, onChange = vm::setMaster, accent = darkHandle, description = "Volume master",
                modifier = Modifier.weight(1f).height(30.dp).padding(start = 8.dp), vertical = false,
            )
        }
        LevelMeter({ live.value.masterPeak }, Modifier.fillMaxWidth().height(7.dp), vertical = false, segments = 28)
        Row(
            Modifier.weight(1f).fillMaxWidth().padding(vertical = 4.dp),
            horizontalArrangement = Arrangement.SpaceEvenly,
        ) {
            ChannelStrip(vm, 0, decks[0], volumes[0], live, Modifier.weight(1f).fillMaxHeight())
            ChannelStrip(vm, 1, decks[1], volumes[1], live, Modifier.weight(1f).fillMaxHeight())
        }
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
            Text("A", color = Metal.DeckA, fontSize = 13.sp, fontWeight = FontWeight.ExtraBold)
            Text("CROSSFADER", color = Metal.TextMuted, fontSize = 10.sp, fontWeight = FontWeight.Bold, letterSpacing = 1.sp, textAlign = TextAlign.Center)
            Text("B", color = Metal.DeckB, fontSize = 13.sp, fontWeight = FontWeight.ExtraBold)
        }
        MetalFader(
            value = cross, onChange = vm::setCrossfader, accent = darkHandle,
            description = "Crossfader. Esquerda toca só o deck A, direita só o deck B.",
            modifier = Modifier.fillMaxWidth().height(40.dp), vertical = false,
        )
    }
}

@Composable
private fun ChannelStrip(
    vm: AppViewModel, deck: Int, d: DeckUi, volume: Float, live: State<LiveUi>, modifier: Modifier,
) {
    val name = AppViewModel.deckName(deck)
    val color = deckColor(deck)
    Row(modifier.padding(horizontal = 2.dp), horizontalArrangement = Arrangement.spacedBy(4.dp)) {
        Column(Modifier.width(82.dp).fillMaxHeight(), verticalArrangement = Arrangement.SpaceEvenly) {
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceEvenly) {
                KnobCell("AGU", d.eq[2], color, "Equalizador agudos do deck $name. Meio é neutro, embaixo corta. Toque duplo zera.") { vm.setEq(deck, 2, it) }
                KnobCell("MED", d.eq[1], color, "Equalizador médios do deck $name. Meio é neutro, embaixo corta. Toque duplo zera.") { vm.setEq(deck, 1, it) }
            }
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceEvenly) {
                KnobCell("GRA", d.eq[0], color, "Equalizador graves do deck $name. Meio é neutro, embaixo corta. Toque duplo zera.") { vm.setEq(deck, 0, it) }
                KnobCell("FILTRO", d.filter, color, "Filtro do deck $name. Esquerda corta os agudos, direita corta os graves, meio desliga. Toque duplo zera.") { vm.setFilter(deck, it) }
            }
        }
        Column(Modifier.width(38.dp).fillMaxHeight(), horizontalAlignment = Alignment.CenterHorizontally) {
            MetalFader(
                value = volume, onChange = { vm.setVolume(deck, it) }, accent = color, fill = true,
                description = "Volume do deck $name", modifier = Modifier.fillMaxWidth().weight(1f),
            )
            Text(name, color = color, fontSize = 13.sp, fontWeight = FontWeight.ExtraBold)
        }
        LevelMeter({ live.value.decks[deck].peak }, Modifier.width(9.dp).fillMaxHeight().padding(bottom = 18.dp))
    }
}

@Composable
private fun KnobCell(label: String, value: Float, color: Color, description: String, onChange: (Float) -> Unit) {
    Column(horizontalAlignment = Alignment.CenterHorizontally) {
        Knob(value = value, onChange = onChange, accent = color, description = description, modifier = Modifier.size(36.dp))
        Text(label, color = Metal.TextMuted, fontSize = 9.sp, fontWeight = FontWeight.Bold)
    }
}
