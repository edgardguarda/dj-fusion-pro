package app.djfusion.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.State
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.onClick
import androidx.compose.ui.semantics.role
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import app.djfusion.harmony.MusicalKey
import app.djfusion.ui.theme.Metal
import kotlin.math.min

internal fun deckColor(deck: Int): Color = if (deck == 0) Metal.DeckA else Metal.DeckB
private fun onDeckColor(deck: Int): Color = if (deck == 0) Metal.OnDeckA else Metal.OnDeckB

private val Engraving = Color(0xFF30353B)
private val TRANSPORT_HEIGHT = 52.dp

/**
 * Tela DJ Live. Duas ondas rolantes no alto e, embaixo, os dois decks grandes com a mesa no meio.
 * Cada deck: fader de tempo, prato (ou pads) e coluna de informação; a fileira de transporte fica embaixo,
 * alinhada com o crossfader. A posição e o nível mudam 30 vezes por segundo e só são lidos nos pontos
 * que os desenham, para o resto da tela não ser recomposto.
 */
@Composable
fun DjLiveScreen(vm: AppViewModel) {
    val decks by vm.decks.collectAsStateWithLifecycle()
    val live = vm.live.collectAsStateWithLifecycle()
    Column(Modifier.fillMaxSize().background(Metal.Bg)) {
        WaveBlock(vm, 0, decks[0], live)
        Spacer(Modifier.height(2.dp))
        WaveBlock(vm, 1, decks[1], live)
        Spacer(Modifier.height(2.dp))
        Row(Modifier.fillMaxWidth().weight(1f)) {
            DeckPanel(vm, 0, decks[0], decks[1].shownKey, live, Modifier.weight(1f).fillMaxHeight())
            MixerPanel(vm, live, Modifier.width(224.dp).fillMaxHeight())
            DeckPanel(vm, 1, decks[1], decks[0].shownKey, live, Modifier.weight(1f).fillMaxHeight())
        }
    }
}

private fun emptyHint(vm: AppViewModel, deck: Int): () -> Unit = {
    val n = AppViewModel.deckName(deck)
    if (vm.decks.value[deck].loading) vm.say("Espere a música terminar de carregar no deck $n.")
    else vm.say("Deck $n sem música. Abra a BIBLIOTECA e toque no botão $n de uma faixa.")
}

@Composable
private fun WaveBlock(vm: AppViewModel, deck: Int, ui: DeckUi, live: State<LiveUi>) {
    val name = AppViewModel.deckName(deck)
    val color = deckColor(deck)
    Column(Modifier.fillMaxWidth().height(50.dp)) {
        Box(Modifier.fillMaxWidth().weight(1f)) {
            ScrollingWave(
                peaks = ui.wave,
                position = { live.value.decks[deck].positionFrames },
                bpm = if (ui.hasBpm) ui.bpm else 0.0,
                firstBeatFrame = ui.firstBeatFrame,
                hotcues = ui.hotcues,
                cue = { live.value.decks[deck].cueFrames },
                deckColor = color,
                modifier = Modifier.fillMaxSize(),
            )
            Row(
                Modifier.align(Alignment.TopStart).padding(4.dp),
                verticalAlignment = Alignment.CenterVertically,
            ) {
                Box(
                    Modifier.size(22.dp).clip(RoundedCornerShape(5.dp)).background(color),
                    contentAlignment = Alignment.Center,
                ) {
                    Text(name, color = onDeckColor(deck), fontSize = 13.sp, fontWeight = FontWeight.ExtraBold)
                }
                val overlay = when {
                    ui.loading -> "Carregando… ${(ui.loadProgress * 100).toInt()}%"
                    !ui.loaded -> "Deck $name vazio · abra a BIBLIOTECA"
                    else -> null
                }
                Text(
                    (overlay ?: ui.title) + if (overlay == null && ui.artist.isNotEmpty()) "  ·  ${ui.artist}" else "",
                    color = Metal.Text, fontSize = 12.sp, fontWeight = FontWeight.Bold,
                    maxLines = 1, overflow = TextOverflow.Ellipsis,
                    modifier = Modifier.padding(start = 6.dp)
                        .background(Color(0xAA000000), RoundedCornerShape(4.dp)).padding(horizontal = 6.dp, vertical = 1.dp),
                )
            }
            if (ui.loaded && !ui.loading) {
                RemainingText(live, deck, ui.lengthFrames, Modifier.align(Alignment.TopEnd).padding(4.dp))
            }
        }
        OverviewStrip(
            peaks = ui.wave,
            position = { live.value.decks[deck].positionFrames },
            lengthFrames = ui.lengthFrames,
            deckColor = color,
            description = "Visão geral do deck $name. Toque para ir a outro ponto da música.",
            onSeek = { vm.seekFraction(deck, it) },
            modifier = Modifier.fillMaxWidth().height(10.dp),
        )
    }
}

@Composable
private fun RemainingText(live: State<LiveUi>, deck: Int, length: Long, modifier: Modifier) {
    val pos = live.value.decks[deck].positionFrames
    Text(
        "-" + formatTimeTenths(framesToMs(length - pos)),
        color = Metal.Text, fontSize = 13.sp, fontFamily = FontFamily.Monospace, fontWeight = FontWeight.Bold,
        modifier = modifier.background(Color(0xAA000000), RoundedCornerShape(4.dp)).padding(horizontal = 6.dp, vertical = 1.dp),
    )
}

@Composable
private fun ElapsedText(live: State<LiveUi>, deck: Int, loaded: Boolean, color: Color) {
    val pos = live.value.decks[deck].positionFrames
    Text(
        if (loaded) formatTimeTenths(framesToMs(pos)) else "-:--.-",
        color = color, fontSize = 15.sp, fontFamily = FontFamily.Monospace, fontWeight = FontWeight.Bold, maxLines = 1,
    )
}

// ------------------------------------------------------------------------------------- deck

@Composable
private fun DeckPanel(
    vm: AppViewModel, deck: Int, ui: DeckUi, otherKey: MusicalKey?, live: State<LiveUi>, modifier: Modifier,
) {
    val left = deck == 0
    Column(modifier.brushedSilver().padding(horizontal = 6.dp, vertical = 5.dp)) {
        Row(Modifier.fillMaxWidth().weight(1f), verticalAlignment = Alignment.CenterVertically) {
            if (left) {
                TempoColumn(vm, deck, ui)
                PlatterArea(vm, deck, ui, live, Modifier.weight(1f).fillMaxHeight())
                InfoColumn(vm, deck, ui, otherKey, live)
            } else {
                InfoColumn(vm, deck, ui, otherKey, live)
                PlatterArea(vm, deck, ui, live, Modifier.weight(1f).fillMaxHeight())
                TempoColumn(vm, deck, ui)
            }
        }
        Spacer(Modifier.height(5.dp))
        Transport(vm, deck, ui, Modifier.fillMaxWidth().height(TRANSPORT_HEIGHT))
    }
}

@Composable
private fun TempoColumn(vm: AppViewModel, deck: Int, ui: DeckUi) {
    val color = deckColor(deck)
    val name = AppViewModel.deckName(deck)
    Column(Modifier.width(42.dp).fillMaxHeight(), horizontalAlignment = Alignment.CenterHorizontally) {
        Text("TEMPO", color = Engraving, fontSize = 9.sp, fontWeight = FontWeight.Bold, letterSpacing = 1.sp)
        MetalFader(
            value = (ui.rate - AppViewModel.PITCH_MIN) / (AppViewModel.PITCH_MAX - AppViewModel.PITCH_MIN),
            onChange = { vm.setPitchFader(deck, it) },
            accent = color,
            description = "Tempo do deck $name. Para cima acelera, para baixo desacelera. Meio é a velocidade normal.",
            modifier = Modifier.fillMaxWidth().weight(1f).padding(vertical = 2.dp),
        )
        Text(
            String.format(java.util.Locale.ROOT, "%+.1f%%", (ui.rate - 1f) * 100f),
            color = if (ui.rate == 1f) Engraving else color,
            fontSize = 10.sp, fontFamily = FontFamily.Monospace, fontWeight = FontWeight.Bold, maxLines = 1,
        )
    }
}

@Composable
private fun InfoColumn(vm: AppViewModel, deck: Int, ui: DeckUi, otherKey: MusicalKey?, live: State<LiveUi>) {
    val color = deckColor(deck)
    val name = AppViewModel.deckName(deck)
    val ready = ui.loaded && !ui.loading
    val hint = emptyHint(vm, deck)
    Column(
        Modifier.width(92.dp).fillMaxHeight().padding(horizontal = 4.dp),
        verticalArrangement = Arrangement.spacedBy(5.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
    ) {
        // visor: tempo tocado, andamento e tom
        Column(
            Modifier.fillMaxWidth().clip(RoundedCornerShape(6.dp)).background(Color(0xFF0B0C0E))
                .padding(vertical = 4.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
        ) {
            ElapsedText(live, deck, ui.loaded, color)
            Text(
                if (ready && ui.hasBpm) String.format(java.util.Locale.ROOT, "%.1f", ui.playedBpm) else "---.-",
                color = if (ready && ui.hasBpm) Metal.Text else Color(0xFF4A5056),
                fontSize = 22.sp, fontFamily = FontFamily.Monospace, fontWeight = FontWeight.ExtraBold, maxLines = 1,
            )
            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                Text("BPM", color = Metal.TextMuted, fontSize = 9.sp, fontWeight = FontWeight.Bold)
                KeyChip(ui.shownKey, otherKey, small = true)
            }
        }
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(4.dp)) {
            SmallTextButton("÷2", "Dividir o andamento detectado do deck $name por 2", Modifier.weight(1f)) {
                if (ready) vm.scaleBpm(deck, 0.5) else hint()
            }
            SmallTextButton("×2", "Dobrar o andamento detectado do deck $name", Modifier.weight(1f)) {
                if (ready) vm.scaleBpm(deck, 2.0) else hint()
            }
        }
        Spacer(Modifier.weight(1f))
        DeckToggle("KEY", "Key-lock do deck $name. Ligado, mudar o tempo não muda o tom da música.", ui.keyLock, color) {
            vm.toggleKeyLock(deck)
        }
        DeckToggle(
            "PADS",
            if (ui.padsOpen) "Voltar ao prato do deck $name" else "Abrir pads de hot cue, loop e efeito do deck $name",
            ui.padsOpen, color,
        ) { vm.togglePads(deck) }
    }
}

@Composable
private fun DeckToggle(label: String, description: String, on: Boolean, color: Color, onPress: () -> Unit) {
    MetalButton(
        description = description, onPress = onPress, led = color, ledOn = on,
        modifier = Modifier.fillMaxWidth().height(40.dp),
    ) {
        Text(label, color = if (on) color else Metal.OnMetal, fontSize = 13.sp, fontWeight = FontWeight.ExtraBold, maxLines = 1)
    }
}

@Composable
private fun PlatterArea(vm: AppViewModel, deck: Int, ui: DeckUi, live: State<LiveUi>, modifier: Modifier) {
    val color = deckColor(deck)
    val name = AppViewModel.deckName(deck)
    val ready = ui.loaded && !ui.loading
    val hint = emptyHint(vm, deck)
    val scratchCb: ((Boolean, Float) -> Unit)? =
        if (ready) ({ active: Boolean, vel: Float -> vm.scratch(deck, active, vel) }) else null
    BoxWithConstraints(modifier, contentAlignment = Alignment.Center) {
        val side = min(maxHeight.value, maxWidth.value).dp
        if (!ui.padsOpen) {
            Platter(
                deckColor = color,
                position = { live.value.decks[deck].positionFrames },
                lengthFrames = { ui.lengthFrames },
                modifier = Modifier.size(side).semantics { contentDescription = "Prato do deck $name. Gire para fazer scratch." },
                onScratch = scratchCb,
            ) {
                Text(name, color = Metal.OnMetal, fontSize = (side.value / 7f).coerceIn(20f, 44f).sp, fontWeight = FontWeight.ExtraBold)
            }
        } else {
            val fxNames = listOf("ECO", "FLANGER", "REVERB")
            val fxShort = listOf("ECO", "FLG", "REV")
            Column(
                Modifier.width(maxWidth.coerceAtMost(side * 1.25f)).fillMaxHeight().padding(vertical = 2.dp),
                verticalArrangement = Arrangement.spacedBy(6.dp),
            ) {
                PadRowLabel("HOT CUE · segure para apagar")
                Row(Modifier.fillMaxWidth().weight(1f), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    for (slot in 0..3) {
                        HotCuePad(
                            slot = slot, frame = ui.hotcues[slot], enabled = ready, deckName = name,
                            onTap = { if (ready) vm.hotcue(deck, slot) else hint() },
                            onLong = { vm.clearHotcue(deck, slot) },
                            modifier = Modifier.weight(1f).fillMaxHeight(),
                        )
                    }
                }
                PadRowLabel("LOOP (batidas)")
                Row(Modifier.fillMaxWidth().weight(1f), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    for (beats in intArrayOf(1, 2, 4, 8)) {
                        MetalButton(
                            description = "Loop de $beats batida(s) no deck $name. Toque de novo para soltar.",
                            onPress = { vm.toggleLoop(deck, beats) },
                            enabled = ready, onDisabledPress = hint,
                            led = color, ledOn = ui.loopBeats == beats,
                            modifier = Modifier.weight(1f).fillMaxHeight(),
                        ) {
                            Text("$beats", color = if (ui.loopBeats == beats) color else Metal.OnMetal, fontSize = 18.sp, fontWeight = FontWeight.ExtraBold, maxLines = 1)
                        }
                    }
                }
                PadRowLabel("EFEITO · quantidade")
                Row(Modifier.fillMaxWidth().weight(1f), horizontalArrangement = Arrangement.spacedBy(6.dp), verticalAlignment = Alignment.CenterVertically) {
                    for (t in 1..3) {
                        MetalButton(
                            description = "Efeito ${fxNames[t - 1]} do deck $name. Toque de novo para desligar.",
                            onPress = { vm.setFx(deck, t) },
                            led = color, ledOn = ui.fxType == t,
                            modifier = Modifier.weight(1f).fillMaxHeight(),
                        ) {
                            Text(fxShort[t - 1], color = if (ui.fxType == t) color else Metal.OnMetal, fontSize = 12.sp, fontWeight = FontWeight.ExtraBold, maxLines = 1, softWrap = false)
                        }
                    }
                    MetalFader(
                        value = ui.fxAmount, onChange = { vm.setFxAmount(deck, it) }, accent = color, fill = true,
                        description = "Quantidade do efeito do deck $name",
                        modifier = Modifier.weight(1.4f).fillMaxHeight(), vertical = false,
                    )
                }
            }
        }
    }
}

@Composable
private fun PadRowLabel(text: String) {
    Text(text, color = Engraving, fontSize = 9.sp, fontWeight = FontWeight.Bold, letterSpacing = 1.sp, maxLines = 1)
}

@Composable
private fun Transport(vm: AppViewModel, deck: Int, ui: DeckUi, modifier: Modifier) {
    val color = deckColor(deck)
    val name = AppViewModel.deckName(deck)
    val ready = ui.loaded && !ui.loading
    val hint = emptyHint(vm, deck)
    Row(modifier, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
        val cue = @Composable {
            MetalButton(
                description = "Cue do deck $name. Parado: marca o ponto. Tocando: volta ao ponto e para.",
                onPress = { vm.cue(deck) }, enabled = ready, onDisabledPress = hint,
                modifier = Modifier.weight(1f).fillMaxHeight(),
            ) { Text("CUE", color = Color(0xFFC01818), fontSize = 16.sp, fontWeight = FontWeight.ExtraBold, letterSpacing = 1.sp, maxLines = 1) }
        }
        val play = @Composable {
            MetalButton(
                description = if (ui.playing) "Pausar deck $name" else "Tocar deck $name",
                onPress = { vm.togglePlay(deck) }, enabled = ready, onDisabledPress = hint,
                led = color, ledOn = ui.playing,
                modifier = Modifier.weight(1.4f).fillMaxHeight(),
            ) { TransportGlyph(ui.playing, if (ui.playing) color else Metal.OnMetal, Modifier.size(26.dp)) }
        }
        val sync = @Composable {
            MetalButton(
                description = "Sync do deck $name. Iguala o andamento ao do outro deck e alinha a batida.",
                onPress = { vm.sync(deck) }, enabled = ready, onDisabledPress = hint,
                modifier = Modifier.weight(1f).fillMaxHeight(),
            ) { Text("SYNC", color = Metal.OnMetal, fontSize = 13.sp, fontWeight = FontWeight.ExtraBold, maxLines = 1) }
        }
        val fone = @Composable {
            MetalButton(
                description = "Fone do deck $name. Ligado, você ouve este deck no fone antes de soltá-lo no som geral.",
                onPress = { vm.toggleHeadphoneCue(deck) },
                led = color, ledOn = ui.cueOn,
                modifier = Modifier.weight(1f).fillMaxHeight(),
            ) { Text("FONE", color = if (ui.cueOn) color else Metal.OnMetal, fontSize = 13.sp, fontWeight = FontWeight.ExtraBold, maxLines = 1) }
        }
        if (deck == 0) { cue(); play(); sync(); fone() } else { fone(); sync(); cue(); play() }
    }
}

/** Pad de hot cue: vazio grava a posição atual, gravado vai até ela e toca, toque longo apaga. */
@Composable
private fun HotCuePad(
    slot: Int, frame: Long, enabled: Boolean, deckName: String,
    onTap: () -> Unit, onLong: () -> Unit, modifier: Modifier,
) {
    val set = frame >= 0
    val c = HOT_COLORS[slot]
    Box(
        modifier
            .semantics {
                contentDescription = if (set) {
                    "Hot cue ${slot + 1} do deck $deckName. Toque para ir até ela. Segure para apagar."
                } else {
                    "Hot cue ${slot + 1} do deck $deckName, vazia. Toque para gravar a posição atual."
                }
                role = Role.Button
                onClick { onTap(); true }
            }
            .clip(RoundedCornerShape(8.dp))
            .drawBehind {
                val corner = CornerRadius(8.dp.toPx())
                if (!enabled) {
                    drawRoundRect(Color(0xFF1E2226), cornerRadius = corner)
                } else if (set) {
                    drawRoundRect(Brush.verticalGradient(listOf(c, c.copy(alpha = 0.62f))), cornerRadius = corner)
                    drawRoundRect(Color.White.copy(alpha = 0.35f), cornerRadius = corner, style = Stroke(1.dp.toPx()))
                } else {
                    drawRoundRect(Color(0xFF1B1E22), cornerRadius = corner)
                    drawRoundRect(c.copy(alpha = 0.55f), cornerRadius = corner, style = Stroke(1.5f.dp.toPx()))
                }
            }
            .pointerInput(enabled, set) {
                detectTapGestures(
                    onTap = { onTap() },
                    onLongPress = { if (enabled && set) onLong() else onTap() },
                )
            },
        contentAlignment = Alignment.Center,
    ) {
        Text(
            "${slot + 1}",
            color = if (set && enabled) Color(0xFF14171B) else c.copy(alpha = if (enabled) 0.9f else 0.35f),
            fontSize = 16.sp, fontWeight = FontWeight.ExtraBold,
        )
    }
}

@Composable
private fun SmallTextButton(label: String, description: String, modifier: Modifier = Modifier, onClick: () -> Unit) {
    Box(
        modifier
            .semantics { contentDescription = description; role = Role.Button; onClick { onClick(); true } }
            .clip(RoundedCornerShape(6.dp))
            .background(Color(0xFF2A2F35))
            .pointerInput(Unit) { detectTapGestures(onTap = { onClick() }) }
            .padding(vertical = 5.dp),
        contentAlignment = Alignment.Center,
    ) {
        Text(label, color = Metal.Text, fontSize = 12.sp, fontWeight = FontWeight.Bold, maxLines = 1)
    }
}

// ------------------------------------------------------------------------------------- mesa

@Composable
private fun MixerPanel(vm: AppViewModel, live: State<LiveUi>, modifier: Modifier) {
    val volumes by vm.volumes.collectAsStateWithLifecycle()
    val decks by vm.decks.collectAsStateWithLifecycle()
    val master by vm.master.collectAsStateWithLifecycle()
    val hpLevel by vm.hpLevel.collectAsStateWithLifecycle()
    val hpMix by vm.hpMix.collectAsStateWithLifecycle()
    val cross by vm.crossfader.collectAsStateWithLifecycle()
    Column(
        modifier.brushedBlack().padding(horizontal = 8.dp, vertical = 5.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
    ) {
        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
            Text("MASTER", color = Metal.TextMuted, fontSize = 9.sp, fontWeight = FontWeight.Bold, letterSpacing = 1.sp)
            MetalFader(
                value = master, onChange = vm::setMaster, accent = Color(0xFFE6E9EC), description = "Volume master",
                modifier = Modifier.weight(1f).height(26.dp).padding(start = 6.dp), vertical = false,
            )
        }
        LevelMeter({ live.value.masterPeak }, Modifier.fillMaxWidth().height(5.dp).padding(top = 1.dp), vertical = false, segments = 24)
        Row(
            Modifier.fillMaxWidth().padding(top = 4.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceEvenly,
        ) {
            KnobInline("FONE", hpLevel, "Volume do fone", centered = false, onChange = vm::setHeadphoneLevel)
            KnobInline("MIX FONE", hpMix, "Mistura do fone. Esquerda só o deck em pré-escuta, direita só o som geral.", centered = false, onChange = vm::setHeadphoneMix)
        }
        Row(Modifier.weight(1f).fillMaxWidth().padding(top = 4.dp)) {
            ChannelStrip(vm, 0, decks[0], volumes[0], live, Modifier.weight(1f).fillMaxHeight())
            ChannelStrip(vm, 1, decks[1], volumes[1], live, Modifier.weight(1f).fillMaxHeight())
        }
        Spacer(Modifier.height(5.dp))
        Column(Modifier.fillMaxWidth().height(TRANSPORT_HEIGHT)) {
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                Text("A", color = Metal.DeckA, fontSize = 11.sp, fontWeight = FontWeight.ExtraBold)
                Text("CROSSFADER", color = Metal.TextMuted, fontSize = 8.sp, fontWeight = FontWeight.Bold, letterSpacing = 1.sp)
                Text("B", color = Metal.DeckB, fontSize = 11.sp, fontWeight = FontWeight.ExtraBold)
            }
            MetalFader(
                value = cross, onChange = vm::setCrossfader, accent = Color(0xFFE6E9EC),
                description = "Crossfader. Esquerda toca só o deck A, direita só o deck B.",
                modifier = Modifier.fillMaxWidth().weight(1f), vertical = false,
            )
        }
    }
}

@Composable
private fun KnobInline(label: String, value: Float, description: String, centered: Boolean, onChange: (Float) -> Unit) {
    Row(verticalAlignment = Alignment.CenterVertically) {
        Text(label, color = Metal.TextMuted, fontSize = 8.sp, fontWeight = FontWeight.Bold)
        Knob(
            value = value, onChange = onChange, accent = Color(0xFFE6E9EC), centered = centered,
            description = description, modifier = Modifier.padding(start = 4.dp).size(28.dp),
        )
    }
}

@Composable
private fun ChannelStrip(
    vm: AppViewModel, deck: Int, d: DeckUi, volume: Float, live: State<LiveUi>, modifier: Modifier,
) {
    val name = AppViewModel.deckName(deck)
    val color = deckColor(deck)
    Row(modifier.padding(horizontal = 1.dp), horizontalArrangement = Arrangement.spacedBy(3.dp)) {
        val knobs = @Composable {
            Column(Modifier.width(42.dp).fillMaxHeight(), verticalArrangement = Arrangement.SpaceEvenly, horizontalAlignment = Alignment.CenterHorizontally) {
                KnobCell("AGUDO", d.eq[2], color, "Equalizador agudos do deck $name. Meio é neutro, embaixo corta. Toque duplo zera.") { vm.setEq(deck, 2, it) }
                KnobCell("MÉDIO", d.eq[1], color, "Equalizador médios do deck $name. Meio é neutro, embaixo corta. Toque duplo zera.") { vm.setEq(deck, 1, it) }
                KnobCell("GRAVE", d.eq[0], color, "Equalizador graves do deck $name. Meio é neutro, embaixo corta. Toque duplo zera.") { vm.setEq(deck, 0, it) }
                KnobCell("FILTRO", d.filter, color, "Filtro do deck $name. Esquerda corta os agudos, direita corta os graves, meio desliga. Toque duplo zera.") { vm.setFilter(deck, it) }
            }
        }
        val fader = @Composable {
            Column(Modifier.width(32.dp).fillMaxHeight(), horizontalAlignment = Alignment.CenterHorizontally) {
                MetalFader(
                    value = volume, onChange = { vm.setVolume(deck, it) }, accent = color, fill = true,
                    description = "Volume do deck $name", modifier = Modifier.fillMaxWidth().weight(1f),
                )
                Text(name, color = color, fontSize = 12.sp, fontWeight = FontWeight.ExtraBold)
            }
        }
        val meter = @Composable {
            LevelMeter({ live.value.decks[deck].peak }, Modifier.width(6.dp).fillMaxHeight().padding(bottom = 16.dp))
        }
        if (deck == 0) { knobs(); fader(); meter() } else { meter(); fader(); knobs() }
    }
}

@Composable
private fun KnobCell(label: String, value: Float, color: Color, description: String, onChange: (Float) -> Unit) {
    Column(horizontalAlignment = Alignment.CenterHorizontally) {
        Knob(value = value, onChange = onChange, accent = color, description = description, modifier = Modifier.size(26.dp))
        Text(label, color = Metal.TextMuted, fontSize = 7.sp, fontWeight = FontWeight.Bold, maxLines = 1)
    }
}
