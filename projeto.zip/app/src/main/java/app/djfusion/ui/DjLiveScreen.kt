package app.djfusion.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.State
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.BoxScope
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.role
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import app.djfusion.ui.theme.Metal
import kotlin.math.min

internal fun deckColor(deck: Int): Color = if (deck == 0) Metal.DeckA else Metal.DeckB
private fun onDeckColor(deck: Int): Color = if (deck == 0) Metal.OnDeckA else Metal.OnDeckB

/**
 * Tela DJ Live. Duas ondas rolantes no alto, cada deck de um lado e a mesa de mixagem no meio.
 * A posição e o nível mudam 30 vezes por segundo e só são lidos nos pontos que os desenham (ondas,
 * vinil, medidores e tempos), para o resto da tela não ser recomposto e a interface não travar.
 */
@Composable
fun DjLiveScreen(vm: AppViewModel) {
    val decks by vm.decks.collectAsStateWithLifecycle()
    val live = vm.live.collectAsStateWithLifecycle()
    Column(Modifier.fillMaxSize().background(Metal.Bg)) {
        WaveBlock(vm, 0, decks[0], live)
        Spacer(Modifier.height(2.dp))
        WaveBlock(vm, 1, decks[1], live)
        Row(Modifier.fillMaxWidth().weight(1f)) {
            DeckMain(vm, 0, decks[0], live, Modifier.weight(1f).fillMaxHeight())
            MixerPanel(vm, live, Modifier.width(236.dp).fillMaxHeight())
            DeckMain(vm, 1, decks[1], live, Modifier.weight(1f).fillMaxHeight())
        }
        BottomBar(vm, decks, Modifier.fillMaxWidth().height(62.dp))
    }
}

@Composable
private fun WaveBlock(vm: AppViewModel, deck: Int, ui: DeckUi, live: State<LiveUi>) {
    val name = AppViewModel.deckName(deck)
    val color = deckColor(deck)
    Column(Modifier.fillMaxWidth().height(66.dp)) {
        Box(Modifier.fillMaxWidth().weight(1f)) {
            ScrollingWave(
                peaks = ui.wave,
                position = { live.value.decks[deck].positionFrames },
                bpm = if (ui.hasBpm) ui.bpm else 0.0,
                firstBeatFrame = ui.firstBeatFrame,
                hotcues = ui.hotcues,
                cue = { live.value.decks[deck].cueFrames },
                deckColor = color,
                modifier = Modifier.fillMaxSize(),
            )
            Row(
                Modifier.align(Alignment.TopStart).padding(6.dp),
                verticalAlignment = Alignment.CenterVertically,
            ) {
                Box(
                    Modifier.size(26.dp).clip(RoundedCornerShape(6.dp)).background(color),
                    contentAlignment = Alignment.Center,
                ) {
                    Text(name, color = onDeckColor(deck), fontSize = 16.sp, fontWeight = FontWeight.ExtraBold)
                }
                Column(
                    Modifier.padding(start = 8.dp)
                        .background(Color(0xAA000000), RoundedCornerShape(4.dp)).padding(horizontal = 6.dp, vertical = 1.dp),
                ) {
                    val overlay = when {
                        ui.loading -> "Carregando… ${(ui.loadProgress * 100).toInt()}%"
                        !ui.loaded -> "Deck $name vazio · abra a Biblioteca"
                        else -> null
                    }
                    Text(
                        overlay ?: ui.title, color = Metal.Text, fontSize = 13.sp, fontWeight = FontWeight.Bold,
                        maxLines = 1, overflow = TextOverflow.Ellipsis,
                    )
                    if (overlay == null && ui.artist.isNotEmpty()) {
                        Text(ui.artist, color = Metal.TextMuted, fontSize = 11.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
                    }
                }
            }
            if (ui.loaded && !ui.loading) {
                RemainingText(live, deck, ui.lengthFrames, Modifier.align(Alignment.TopEnd).padding(6.dp))
            }
        }
        OverviewStrip(
            peaks = ui.wave,
            position = { live.value.decks[deck].positionFrames },
            lengthFrames = ui.lengthFrames,
            deckColor = color,
            description = "Visão geral do deck $name. Toque para ir a outro ponto da música.",
            onSeek = { vm.seekFraction(deck, it) },
            modifier = Modifier.fillMaxWidth().height(12.dp),
        )
    }
}

@Composable
private fun RemainingText(live: State<LiveUi>, deck: Int, length: Long, modifier: Modifier) {
    val pos = live.value.decks[deck].positionFrames
    Text(
        "-" + formatTimeTenths(framesToMs(length - pos)),
        color = Metal.Text, fontSize = 14.sp, fontFamily = FontFamily.Monospace, fontWeight = FontWeight.Bold,
        modifier = modifier.background(Color(0xAA000000), RoundedCornerShape(4.dp)).padding(horizontal = 6.dp, vertical = 1.dp),
    )
}

@Composable
private fun ElapsedText(live: State<LiveUi>, deck: Int, loaded: Boolean, color: Color) {
    val pos = live.value.decks[deck].positionFrames
    Text(
        if (loaded) formatTimeTenths(framesToMs(pos)) else "--:--.-",
        color = color, fontSize = 24.sp, fontFamily = FontFamily.Monospace, fontWeight = FontWeight.Bold,
    )
}

@Composable
private fun DeckMain(vm: AppViewModel, deck: Int, ui: DeckUi, live: State<LiveUi>, modifier: Modifier) {
    val color = deckColor(deck)
    val name = AppViewModel.deckName(deck)
    val ready = ui.loaded && !ui.loading
    var pads by remember { mutableStateOf(false) }
    Row(
        modifier.background(Brush.verticalGradient(listOf(Color(0xFF1A1D22), Color(0xFF0F1113))))
            .padding(horizontal = 8.dp, vertical = 6.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        val tempo = @Composable {
            Column(Modifier.width(44.dp).fillMaxHeight(), horizontalAlignment = Alignment.CenterHorizontally) {
                Text("TEMPO", color = Metal.TextMuted, fontSize = 9.sp, fontWeight = FontWeight.Bold, letterSpacing = 1.sp)
                MetalFader(
                    value = (ui.rate - AppViewModel.PITCH_MIN) / (AppViewModel.PITCH_MAX - AppViewModel.PITCH_MIN),
                    onChange = { vm.setPitchFader(deck, it) },
                    accent = color,
                    description = "Tempo do deck $name. Para cima acelera, para baixo desacelera. Meio é a velocidade normal.",
                    modifier = Modifier.fillMaxWidth().weight(1f),
                )
                Text(
                    String.format(java.util.Locale.ROOT, "%+.1f%%", (ui.rate - 1f) * 100f),
                    color = if (ui.rate == 1f) Metal.TextMuted else color,
                    fontSize = 11.sp, fontFamily = FontFamily.Monospace, fontWeight = FontWeight.Bold,
                )
            }
        }
        val info = @Composable {
            Column(
                Modifier.weight(1f).fillMaxHeight().padding(horizontal = 8.dp),
                verticalArrangement = Arrangement.SpaceEvenly,
                horizontalAlignment = Alignment.CenterHorizontally,
            ) {
                ElapsedText(live, deck, ui.loaded, color)
                if (ready && ui.hasBpm) {
                    Text(
                        String.format(java.util.Locale.ROOT, "%.1f", ui.playedBpm),
                        color = Metal.Text, fontSize = 30.sp, fontFamily = FontFamily.Monospace, fontWeight = FontWeight.ExtraBold,
                    )
                    Text("BPM", color = Metal.TextMuted, fontSize = 10.sp, fontWeight = FontWeight.Bold, letterSpacing = 2.sp)
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        SmallTextButton("÷2", "Dividir o andamento detectado por 2") { vm.scaleBpm(deck, 0.5) }
                        SmallTextButton("×2", "Dobrar o andamento detectado") { vm.scaleBpm(deck, 2.0) }
                    }
                } else {
                    Text(if (ready) "sem BPM" else "—", color = Metal.TextMuted, fontSize = 14.sp)
                }
                MetalButton(
                    description = if (pads) "Voltar ao disco do deck $name" else "Abrir pads de hot cue e loop do deck $name",
                    onPress = { pads = !pads },
                    led = color, ledOn = pads,
                    modifier = Modifier.fillMaxWidth().height(34.dp),
                ) {
                    Text("PADS", color = if (pads) color else Metal.OnMetal, fontSize = 12.sp, fontWeight = FontWeight.ExtraBold, letterSpacing = 1.sp)
                }
            }
        }
        val center = @Composable {
            BoxWithConstraints(Modifier.fillMaxHeight().weight(1.55f), contentAlignment = Alignment.Center) {
                val side = min(maxHeight.value, maxWidth.value).dp
                if (!pads) {
                    Platter(
                        deckColor = color,
                        position = { live.value.decks[deck].positionFrames },
                        lengthFrames = { ui.lengthFrames },
                        modifier = Modifier.size(side),
                    ) {
                        Text(
                            name, color = onDeckColor(deck), fontSize = 34.sp, fontWeight = FontWeight.ExtraBold,
                        )
                    }
                } else {
                    Column(Modifier.size(side), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        Row(Modifier.fillMaxWidth().weight(1f), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            for (slot in 0..3) {
                                HotCuePad(
                                    slot = slot, frame = ui.hotcues[slot], enabled = ready,
                                    deckName = name, onTap = { vm.hotcue(deck, slot) }, onLong = { vm.clearHotcue(deck, slot) },
                                    modifier = Modifier.weight(1f).fillMaxHeight(),
                                )
                            }
                        }
                        Row(Modifier.fillMaxWidth().weight(1f), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            for (beats in intArrayOf(1, 2, 4, 8)) {
                                MetalButton(
                                    description = "Loop de $beats batida(s) no deck $name. Toque de novo para soltar.",
                                    onPress = { vm.toggleLoop(deck, beats) },
                                    enabled = ready,
                                    led = color, ledOn = ui.loopBeats == beats,
                                    modifier = Modifier.weight(1f).fillMaxHeight(),
                                ) {
                                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                        Text("$beats", color = if (ui.loopBeats == beats) color else Metal.OnMetal, fontSize = 20.sp, fontWeight = FontWeight.ExtraBold)
                                        Text("LOOP", color = Metal.TextMuted, fontSize = 8.sp, fontWeight = FontWeight.Bold)
                                    }
                                }
                            }
                        }
                        Row(Modifier.fillMaxWidth().weight(1f), horizontalArrangement = Arrangement.spacedBy(6.dp), verticalAlignment = Alignment.CenterVertically) {
                            val fxNames = listOf("ECO", "FLANGER", "REVERB")
                            for (t in 1..3) {
                                MetalButton(
                                    description = "Efeito ${fxNames[t - 1]} do deck $name. Toque de novo para desligar.",
                                    onPress = { vm.setFx(deck, t) },
                                    enabled = ready,
                                    led = color, ledOn = ui.fxType == t,
                                    modifier = Modifier.weight(1f).fillMaxHeight(),
                                ) {
                                    Text(fxNames[t - 1], color = if (ui.fxType == t) color else Metal.OnMetal, fontSize = 9.sp, fontWeight = FontWeight.ExtraBold)
                                }
                            }
                            MetalFader(
                                value = ui.fxAmount, onChange = { vm.setFxAmount(deck, it) }, accent = color, fill = true,
                                description = "Quantidade do efeito do deck $name",
                                modifier = Modifier.weight(1.3f).fillMaxHeight(), vertical = false,
                            )
                        }
                    }
                }
            }
        }
        if (deck == 0) {
            tempo(); center(); info()
        } else {
            info(); center(); tempo()
        }
    }
}

@Composable
private fun BottomBar(vm: AppViewModel, decks: List<DeckUi>, modifier: Modifier) {
    val cross by vm.crossfader.collectAsStateWithLifecycle()
    Row(
        modifier.background(Color(0xFF0B0C0E)).padding(horizontal = 8.dp, vertical = 6.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        DeckButtons(vm, 0, decks[0], Modifier.weight(1f).fillMaxHeight())
        Column(Modifier.width(236.dp).fillMaxHeight().padding(horizontal = 10.dp)) {
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                Text("A", color = Metal.DeckA, fontSize = 12.sp, fontWeight = FontWeight.ExtraBold)
                Text("CROSSFADER", color = Metal.TextMuted, fontSize = 9.sp, fontWeight = FontWeight.Bold, letterSpacing = 1.sp)
                Text("B", color = Metal.DeckB, fontSize = 12.sp, fontWeight = FontWeight.ExtraBold)
            }
            MetalFader(
                value = cross, onChange = vm::setCrossfader, accent = Color(0xFFE6E9EC),
                description = "Crossfader. Esquerda toca só o deck A, direita só o deck B.",
                modifier = Modifier.fillMaxWidth().weight(1f), vertical = false,
            )
        }
        DeckButtons(vm, 1, decks[1], Modifier.weight(1f).fillMaxHeight())
    }
}

@Composable
private fun DeckButtons(vm: AppViewModel, deck: Int, ui: DeckUi, modifier: Modifier) {
    val color = deckColor(deck)
    val name = AppViewModel.deckName(deck)
    val ready = ui.loaded && !ui.loading
    Row(modifier, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        val cue = @Composable {
            MetalButton(
                description = "Cue do deck $name. Parado: marca o ponto. Tocando: volta ao ponto e para.",
                onPress = { vm.cue(deck) }, enabled = ready,
                modifier = Modifier.weight(1f).fillMaxHeight(),
            ) { Text("CUE", color = Color(0xFFFF9F4A), fontSize = 16.sp, fontWeight = FontWeight.ExtraBold, letterSpacing = 1.sp) }
        }
        val play = @Composable {
            MetalButton(
                description = if (ui.playing) "Pausar deck $name" else "Tocar deck $name",
                onPress = { vm.togglePlay(deck) }, enabled = ready,
                led = color, ledOn = ui.playing,
                modifier = Modifier.weight(1.4f).fillMaxHeight(),
            ) { TransportGlyph(ui.playing, if (ui.playing) color else Metal.OnMetal, Modifier.size(28.dp)) }
        }
        val sync = @Composable {
            MetalButton(
                description = "Sync do deck $name. Iguala o andamento ao do outro deck e alinha a batida.",
                onPress = { vm.sync(deck) }, enabled = ready,
                modifier = Modifier.weight(1f).fillMaxHeight(),
            ) { Text("SYNC", color = Metal.OnMetal, fontSize = 14.sp, fontWeight = FontWeight.ExtraBold, letterSpacing = 1.sp) }
        }
        if (deck == 0) { cue(); play(); sync() } else { sync(); cue(); play() }
    }
}

/** Pad de hot cue: vazio grava a posição atual, gravado vai até ela e toca, toque longo apaga. */
@Composable
private fun HotCuePad(
    slot: Int, frame: Long, enabled: Boolean, deckName: String,
    onTap: () -> Unit, onLong: () -> Unit, modifier: Modifier,
) {
    val set = frame >= 0
    val c = HOT_COLORS[slot]
    Box(
        modifier
            .semantics {
                contentDescription = if (set) {
                    "Hot cue ${slot + 1} do deck $deckName. Toque para ir até ela. Segure para apagar."
                } else {
                    "Hot cue ${slot + 1} do deck $deckName, vazia. Toque para gravar a posição atual."
                }
                role = Role.Button
            }
            .clip(RoundedCornerShape(8.dp))
            .drawBehind {
                val corner = CornerRadius(8.dp.toPx())
                if (!enabled) {
                    drawRoundRect(Color(0xFF1E2226), cornerRadius = corner)
                } else if (set) {
                    drawRoundRect(Brush.verticalGradient(listOf(c, c.copy(alpha = 0.62f))), cornerRadius = corner)
                    drawRoundRect(Color.White.copy(alpha = 0.35f), cornerRadius = corner, style = Stroke(1.dp.toPx()))
                } else {
                    drawRoundRect(Color(0xFF1B1E22), cornerRadius = corner)
                    drawRoundRect(c.copy(alpha = 0.45f), cornerRadius = corner, style = Stroke(1.5f.dp.toPx()))
                }
            }
            .pointerInput(enabled, set) {
                detectTapGestures(
                    onTap = { if (enabled) onTap() },
                    onLongPress = { if (enabled && set) onLong() },
                )
            },
        contentAlignment = Alignment.Center,
    ) {
        Text(
            "${slot + 1}",
            color = if (set && enabled) Color(0xFF14171B) else c.copy(alpha = if (enabled) 0.8f else 0.3f),
            fontSize = 16.sp, fontWeight = FontWeight.ExtraBold,
        )
    }
}

@Composable
private fun SmallTextButton(label: String, description: String, onClick: () -> Unit) {
    Box(
        Modifier
            .semantics { contentDescription = description; role = Role.Button }
            .clip(RoundedCornerShape(6.dp))
            .background(Color(0xFF2A2F35))
            .pointerInput(Unit) { detectTapGestures(onTap = { onClick() }) }
            .padding(horizontal = 8.dp, vertical = 5.dp),
        contentAlignment = Alignment.Center,
    ) {
        Text(label, color = Metal.Text, fontSize = 12.sp, fontWeight = FontWeight.Bold)
    }
}

@Composable
private fun MixerPanel(vm: AppViewModel, live: State<LiveUi>, modifier: Modifier) {
    val volumes by vm.volumes.collectAsStateWithLifecycle()
    val decks by vm.decks.collectAsStateWithLifecycle()
    val master by vm.master.collectAsStateWithLifecycle()
    Column(
        modifier.background(Brush.verticalGradient(listOf(Color(0xFF181B1F), Color(0xFF0E1012))))
            .padding(horizontal = 8.dp, vertical = 6.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
    ) {
        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
            Text("MASTER", color = Metal.TextMuted, fontSize = 9.sp, fontWeight = FontWeight.Bold, letterSpacing = 1.sp)
            MetalFader(
                value = master, onChange = vm::setMaster, accent = Color(0xFFE6E9EC), description = "Volume master",
                modifier = Modifier.weight(1f).height(28.dp).padding(start = 6.dp), vertical = false,
            )
        }
        LevelMeter({ live.value.masterPeak }, Modifier.fillMaxWidth().height(6.dp), vertical = false, segments = 24)
        Row(
            Modifier.weight(1f).fillMaxWidth().padding(top = 4.dp),
            horizontalArrangement = Arrangement.SpaceEvenly,
        ) {
            ChannelStrip(vm, 0, decks[0], volumes[0], live, Modifier.weight(1f).fillMaxHeight())
            ChannelStrip(vm, 1, decks[1], volumes[1], live, Modifier.weight(1f).fillMaxHeight())
        }
    }
}

@Composable
private fun ChannelStrip(
    vm: AppViewModel, deck: Int, d: DeckUi, volume: Float, live: State<LiveUi>, modifier: Modifier,
) {
    val name = AppViewModel.deckName(deck)
    val color = deckColor(deck)
    Row(modifier.padding(horizontal = 1.dp), horizontalArrangement = Arrangement.spacedBy(3.dp)) {
        Column(Modifier.width(40.dp).fillMaxHeight(), verticalArrangement = Arrangement.SpaceEvenly, horizontalAlignment = Alignment.CenterHorizontally) {
            KnobCell("AGU", d.eq[2], color, "Equalizador agudos do deck $name. Meio é neutro, embaixo corta. Toque duplo zera.") { vm.setEq(deck, 2, it) }
            KnobCell("MED", d.eq[1], color, "Equalizador médios do deck $name. Meio é neutro, embaixo corta. Toque duplo zera.") { vm.setEq(deck, 1, it) }
            KnobCell("GRA", d.eq[0], color, "Equalizador graves do deck $name. Meio é neutro, embaixo corta. Toque duplo zera.") { vm.setEq(deck, 0, it) }
            KnobCell("FILTRO", d.filter, color, "Filtro do deck $name. Esquerda corta os agudos, direita corta os graves, meio desliga. Toque duplo zera.") { vm.setFilter(deck, it) }
        }
        Column(Modifier.width(34.dp).fillMaxHeight(), horizontalAlignment = Alignment.CenterHorizontally) {
            MetalFader(
                value = volume, onChange = { vm.setVolume(deck, it) }, accent = color, fill = true,
                description = "Volume do deck $name", modifier = Modifier.fillMaxWidth().weight(1f),
            )
            Text(name, color = color, fontSize = 12.sp, fontWeight = FontWeight.ExtraBold)
        }
        LevelMeter({ live.value.decks[deck].peak }, Modifier.width(7.dp).fillMaxHeight().padding(bottom = 16.dp))
    }
}

@Composable
private fun KnobCell(label: String, value: Float, color: Color, description: String, onChange: (Float) -> Unit) {
    Column(horizontalAlignment = Alignment.CenterHorizontally) {
        Knob(value = value, onChange = onChange, accent = color, description = description, modifier = Modifier.size(28.dp))
        Text(label, color = Metal.TextMuted, fontSize = 8.sp, fontWeight = FontWeight.Bold)
    }
}
