package app.djfusion.ui

import app.djfusion.audio.NativeEngine
import app.djfusion.data.TrackRow
import app.djfusion.harmony.Camelot
import app.djfusion.harmony.TrackShape
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import kotlin.math.abs
import kotlin.math.floor
import kotlin.random.Random

/**
 * AUTO DJ: o app toca a biblioteca sozinho. É inteligência local (sem internet): usa o andamento e a tonalidade
 * analisados de cada faixa para escolher a próxima música (andamento parecido, tom compatível na Roda de Camelot),
 * ajusta o andamento dela ao da que está tocando (com key-lock, sem mudar o tom), entra com a batida alinhada
 * e faz a mixagem com crossfader e troca dos graves. Perto de um tom que choca, a mixagem é curta.
 */
class AutoDj(
    private val vm: AppViewModel,
    private val scope: CoroutineScope,
    private val prefs: android.content.SharedPreferences,
) {
    /**
     * Estilo escolhido: 0 automático, 1 graves (EQ), 2 filtro, 3 eco, 4 stems, 5 corte seco, 6 fade, 7 sem mixagem,
     * 8 reverb, 9 loop, 10 drop.
     */
    private val _styleChoice = MutableStateFlow(prefs.getInt("style", 0).coerceIn(0, 10))
    val styleChoice: StateFlow<Int> = _styleChoice.asStateFlow()
    /** Duração: 0 automática, ou 8, 16, 32 batidas. */
    private val _beatsChoice = MutableStateFlow(prefs.getInt("beats", 0))
    val beatsChoice: StateFlow<Int> = _beatsChoice.asStateFlow()
    /** Ajusta o tom da música que entra (até ±2 semitons) quando os tons chocam. */
    private val _autoKey = MutableStateFlow(prefs.getBoolean("autoKey", true))
    val autoKey: StateFlow<Boolean> = _autoKey.asStateFlow()

    fun setStyleChoice(v: Int) { _styleChoice.value = v.coerceIn(0, 10); prefs.edit().putInt("style", _styleChoice.value).apply() }

    // ------------------------------------------------------------------ modos (perfis)

    /**
     * Perfil do AUTO DJ: pesos da escolha (andamento, tom, energia), alvo de energia ao longo do set,
     * transições preferidas e duração. Os estilos/duração escolhidos à mão continuam valendo por cima do perfil.
     */
    data class Profile(
        val name: String, val desc: String,
        val wBpm: Double, val wKey: Double, val wEnergy: Double,
        val energy: ((Int) -> Float)?, val styles: List<Int>, val beats: Int,
        /** Peso do gênero musical (etiqueta do arquivo): 0 = não importa. */
        val wGenre: Double = 0.0,
    )

    val modes: List<Profile> = listOf(
        Profile("AUTOMÁTICO", "Equilíbrio entre tom, andamento e energia (curva de energia escolhida abaixo).", 1.0, 1.0, 1.0, null, emptyList(), 0),
        Profile("INTELIGENTE", "Como o automático, aprendendo com o que você troca, evitando vozes juntas e preferindo o mesmo gênero.", 1.2, 1.2, 1.0, null, emptyList(), 0, wGenre = 0.6),
        Profile("HARMÔNICO", "Prioriza tons compatíveis (Camelot); mixagens longas com troca de graves.", 0.8, 2.6, 0.7, null, listOf(1, 4), 32),
        Profile("POR BPM", "Prioriza andamento parecido: quase sem mexer no pitch.", 3.0, 0.6, 0.6, null, listOf(1), 16),
        Profile("ENERGIA", "Sobe a energia aos poucos, música a música.", 0.8, 0.8, 2.6, { n -> (0.35f + 0.05f * n).coerceAtMost(0.95f) }, emptyList(), 0),
        Profile("FESTA", "Músicas fortes, entradas decididas (filtro, eco, drop).", 1.0, 0.9, 2.0, { _ -> 0.85f }, listOf(2, 10, 3, 1), 16),
        Profile("LOUNGE", "Músicas calmas, mixagens longas e suaves.", 1.0, 1.4, 2.0, { _ -> 0.30f }, listOf(1, 6), 32),
        Profile("RÁDIO", "Uma depois da outra com fade curto, como rádio.", 0.6, 0.6, 0.8, null, listOf(6), 8),
        Profile("PROGRESSIVO", "Energia subindo bem devagar, mixagens longas de 32 batidas.", 1.2, 1.4, 2.0, { n -> (0.30f + 0.03f * n).coerceAtMost(0.9f) }, listOf(1, 2), 32),
        Profile("CRIATIVO", "Varia as transições (graves, filtro, eco, reverb, loop, stems, drop).", 1.0, 1.0, 1.0, null, listOf(1, 2, 3, 8, 9, 4, 10), 16),
        Profile("PERSONALIZADO", "Você escolhe o peso de cada critério.", 1.0, 1.0, 1.0, null, emptyList(), 0),
        // novo no fim da lista: o modo escolhido antes (guardado pelo número) continua o mesmo
        Profile("POR GÊNERO", "Fica no mesmo gênero musical (etiqueta do arquivo: Pop, Rock, House…); só troca de gênero se não houver outra boa.", 1.0, 1.0, 0.8, null, emptyList(), 0, wGenre = 3.0),
    )
    private val _mode = MutableStateFlow(prefs.getInt("mode", 0).coerceIn(0, modes.size - 1))
    val mode: StateFlow<Int> = _mode.asStateFlow()
    fun setMode(v: Int) { _mode.value = v.coerceIn(0, modes.size - 1); prefs.edit().putInt("mode", _mode.value).apply() }

    /** Pesos do modo PERSONALIZADO (0 a 3): andamento, tom, energia, gênero. */
    private val _weights = MutableStateFlow(listOf(prefs.getFloat("wBpm", 1f), prefs.getFloat("wKey", 1f), prefs.getFloat("wEnergy", 1f), prefs.getFloat("wGenre", 0f)))
    val weights: StateFlow<List<Float>> = _weights.asStateFlow()
    fun setWeight(i: Int, v: Float) {
        _weights.value = _weights.value.mapIndexed { k, old -> if (k == i) v.coerceIn(0f, 3f) else old }
        prefs.edit().putFloat("wBpm", _weights.value[0]).putFloat("wKey", _weights.value[1]).putFloat("wEnergy", _weights.value[2])
            .putFloat("wGenre", _weights.value[3]).apply()
    }
    private fun profile(): Profile {
        val p = modes[_mode.value]
        if (p.name != "PERSONALIZADO") return p
        val w = _weights.value
        return p.copy(wBpm = w[0].toDouble(), wKey = w[1].toDouble(), wEnergy = w[2].toDouble(), wGenre = w[3].toDouble())
    }

    /** Anti-choque de vozes: com stems prontos nas duas, só uma voz toca por vez na transição. */
    private val _antiClash = MutableStateFlow(prefs.getBoolean("antiClash", true))
    val antiClash: StateFlow<Boolean> = _antiClash.asStateFlow()
    fun toggleAntiClash() { _antiClash.value = !_antiClash.value; prefs.edit().putBoolean("antiClash", _antiClash.value).apply() }

    // ------------------------------------------------------------ próxima música (explicável)

    /** Uma candidata com a nota de compatibilidade (0–100) e o porquê. */
    data class Ranked(val row: TrackRow, val compat: Int, val why: String)

    /** O que o AUTO DJ vai fazer: próxima música, nota, motivo, transição e alternativas. */
    data class Plan(
        val next: Ranked? = null, val style: String = "", val beats: Int = 0, val incoming: Int = -1,
        val alternatives: List<Ranked> = emptyList(), val source: String = "biblioteca inteira",
    )
    private val _plan = MutableStateFlow(Plan())
    val plan: StateFlow<Plan> = _plan.asStateFlow()

    /** Trocar a próxima música por outra (o AUTO DJ aprende que não gostou da escolha anterior). */
    @Volatile private var replaceWith: Long? = null
    fun useAlternative(id: Long) {
        if (job?.isActive != true) { vm.say("Ligue o AUTO DJ primeiro."); return }
        val cur = _plan.value.next?.row?.id
        val playing = vm.decks.value.firstOrNull { it.playing }?.trackId
        if (cur != null && playing != null) rememberRejection(playing, cur)
        replaceWith = id
        vm.say("AUTO DJ: trocando a próxima música.")
    }
    /** Pula para a melhor alternativa. */
    fun skipNext() {
        val alt = _plan.value.alternatives.firstOrNull() ?: run { vm.say("Sem alternativa compatível agora."); return }
        useAlternative(alt.row.id)
    }

    /** Aprendizado: pares (tocando → próxima) que o DJ trocou ficam menos prováveis. */
    private val rejections: MutableSet<String> = HashSet(prefs.getStringSet("rejections", emptySet()) ?: emptySet())
    private val _learned = MutableStateFlow(rejections.size)
    val learned: StateFlow<Int> = _learned.asStateFlow()
    private fun rememberRejection(a: Long, b: Long) {
        rejections.add("$a>$b")
        while (rejections.size > 500) rejections.remove(rejections.first())
        prefs.edit().putStringSet("rejections", HashSet(rejections)).apply()
        _learned.value = rejections.size
    }
    fun forgetLearning() {
        rejections.clear()
        prefs.edit().remove("rejections").apply()
        _learned.value = 0
        vm.say("Aprendizado do AUTO DJ apagado (a biblioteca não foi mexida).")
    }

    /** Músicas que o AUTO DJ pode usar (null = biblioteca inteira; senão só estas, ex.: uma pasta). */
    @Volatile private var pool: Set<Long>? = null
    @Volatile private var poolName = "biblioteca inteira"

    /** Liga o AUTO DJ só com estas músicas (ex.: a pasta escolhida em TOCAR PASTA), sem nenhuma ajuda. */
    fun startWithPool(ids: Set<Long>, name: String) {
        pool = ids
        poolName = name
        if (job?.isActive == true) { vm.say("AUTO DJ agora toca só: $name (${ids.size} músicas)."); return }
        start()
    }
    fun clearPool() { pool = null; poolName = "biblioteca inteira" }

    /** Mantém o andamento entre as músicas (senão o pitch volta devagar a 0%, como no VirtualDJ). */
    private val _keepTempo = MutableStateFlow(prefs.getBoolean("keepTempo", false))
    val keepTempo: StateFlow<Boolean> = _keepTempo.asStateFlow()
    fun toggleKeepTempo() { _keepTempo.value = !_keepTempo.value; prefs.edit().putBoolean("keepTempo", _keepTempo.value).apply() }

    /** MIXAR AGORA: começa a transição no próximo compasso, sem esperar o fim da música. */
    @Volatile private var mixNowFlag = false
    fun mixNow() {
        if (job?.isActive != true) { vm.say("Ligue o AUTO DJ primeiro."); return }
        if (_state.value.mixing) { vm.say("AUTO DJ: já está mixando."); return }
        mixNowFlag = true
        vm.say("AUTO DJ: mixando agora, no próximo compasso.")
    }
    fun setBeatsChoice(v: Int) { _beatsChoice.value = v; prefs.edit().putInt("beats", v).apply() }
    private val _energyMode = MutableStateFlow(prefs.getInt("energyMode", 0).coerceIn(0, ENERGY_PROFILES.size - 1))
    /** Curva de energia da noite: 0 manter/subir pouco, 1 aquecer até o pico, 2 ondas (sobe e respira), 3 baixar (fim de noite). */
    val energyMode: StateFlow<Int> = _energyMode
    fun setEnergyMode(v: Int) { _energyMode.value = v.coerceIn(0, ENERGY_PROFILES.size - 1); prefs.edit().putInt("energyMode", _energyMode.value).apply() }
    /** Alvo de energia do perfil PERSONALIZADO (0 a 1). */
    private val _energyTarget = MutableStateFlow(prefs.getFloat("energyTarget", 0.6f))
    val energyTarget: StateFlow<Float> = _energyTarget.asStateFlow()
    fun setEnergyTarget(v: Float) { _energyTarget.value = v.coerceIn(0f, 1f); prefs.edit().putFloat("energyTarget", _energyTarget.value).apply() }

    /** Alvo de energia (0 a 1) para a [n]-ésima música do set, ou null (segue a música atual). */
    private fun energyTargetFor(n: Int): Float? = when (_energyMode.value) {
        1 -> (0.30f + 0.06f * n).coerceAtMost(0.95f)                // PROGRESSIVO: aquece até o pico
        2 -> 0.55f + 0.30f * kotlin.math.sin(n * 0.9f)              // ONDAS: sobe e respira
        3 -> (0.80f - 0.07f * n).coerceAtLeast(0.20f)               // FECHAR: desce para o fim da noite
        4 -> 0.20f                                                  // RELAXADO
        5 -> 0.38f                                                  // SUAVE
        6 -> 0.55f                                                  // EQUILIBRADO
        7 -> 0.72f                                                  // FESTA
        8 -> 0.85f                                                  // ALTA ENERGIA
        9 -> 0.95f                                                  // PICO DE PISTA
        10 -> _energyTarget.value                                   // PERSONALIZADO
        else -> null                                                // LIVRE
    }
    private var playedCount = 0

    fun toggleAutoKey() { _autoKey.value = !_autoKey.value; prefs.edit().putBoolean("autoKey", _autoKey.value).apply() }


    data class State(val active: Boolean = false, val status: String = "", val mixing: Boolean = false)

    private val _state = MutableStateFlow(State())
    val state: StateFlow<State> = _state.asStateFlow()
    private var job: Job? = null
    private val history = ArrayDeque<Long>()

    fun toggle() {
        if (job?.isActive == true) stop() else start()
    }

    fun stop() {
        job?.cancel()
        job = null
        mixNowFlag = false
        _state.value = State()
        _plan.value = Plan()
        vm.say("AUTO DJ desligado. Os decks continuam como estão.")
    }

    fun start() {
        if (job?.isActive == true) return
        _state.value = State(true, "Preparando…")
        playedCount = 0
        if (_mode.value == 1 || modes[_mode.value].name == "INTELIGENTE") _antiClash.value = true
        job = scope.launch {
            try {
                run()
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                vm.say("AUTO DJ parou: ${e.message ?: "erro inesperado"}")
            } finally {
                _state.update { it.copy(active = false, mixing = false, status = "") }
            }
        }
    }

    private fun status(text: String, mixing: Boolean = false) {
        _state.value = State(true, text, mixing)
    }

    // ----------------------------------------------------------------- laço principal

    private suspend fun libraryNow(): List<TrackRow> {
        val p = pool
        return vm.allTracks().filter { p == null || it.id in p }
    }

    private suspend fun run() {
        var library = libraryNow()
        if (library.size < 2) {
            vm.say("O AUTO DJ precisa de pelo menos 2 músicas na biblioteca. Toque em BIBLIOTECA e depois em IMPORTAR.")
            return
        }
        if (library.any { !it.analyzed }) {
            // analisa sozinho o que falta (andamento e tom), sem pedir nada ao DJ
            vm.analyzeMissing { done, total -> status("Analisando a biblioteca: $done de $total") }
            library = libraryNow()
        }
        if (library.count { it.bpm > 0 } < 2) {
            vm.say("O AUTO DJ não achou andamento em pelo menos 2 músicas.")
            return
        }
        var cur = firstDeck()
        val d0 = vm.decks.value[cur]
        val p0 = pool
        // TOCAR PASTA: começa por uma música da pasta (a que estava parada no deck não conta)
        if (!d0.loaded || (p0 != null && d0.trackId !in p0 && !d0.playing)) {
            status("Escolhendo a primeira música…")
            val first = library.filter { it.bpm > 0 }.random()
            if (!vm.loadTrackAndWait(cur, first)) {
                vm.say("Não consegui carregar a primeira música.")
                return
            }
        }
        if (!vm.decks.value[cur].hasBpm) {
            vm.say("A música do deck ${AppViewModel.deckName(cur)} não tem andamento detectado. Escolha outra ou use ANALISAR.")
            return
        }
        vm.setVolume(0, 1f)
        vm.setVolume(1, 1f)
        // volumes iguais entre as músicas: o AUTO DJ liga o AUTO-GAIN
        if (!vm.autoGain.value) vm.toggleAutoGain()
        vm.setCrossfader(if (cur == 0) 0f else 1f)
        vm.setEq(cur, 0, 0.5f)
        // key-lock só quando a velocidade muda de verdade (no 0% ele só pioraria o som)
        vm.setKeyLock(cur, abs(vm.decks.value[cur].rate - 1f) > 0.02f)
        if (!vm.decks.value[cur].playing) NativeEngine.nativePlay(cur)
        remember(vm.decks.value[cur].trackId)

        var failures = 0
        while (true) {
            val other = 1 - cur
            // volta o andamento da música atual ao original, devagar, para as próximas misturas não derivarem
            if (!_keepTempo.value) easeRateToNormal(cur)

            library = libraryNow()
            status("Escolhendo a próxima música…")
            // com set harmonizado, segue a ordem dele; senão escolhe a melhor agora
            val setId = vm.nextInSet(vm.decks.value[cur].trackId, history)
            val forced = replaceWith
            replaceWith = null
            var next = library.firstOrNull { it.id == forced } ?: library.firstOrNull { it.id == setId && it.bpm > 0 } ?: chooseNext(cur, library)
            if (next == null && history.size > 1) {
                // biblioteca pequena: libera as já tocadas (menos a atual) e tenta de novo
                val keep = vm.decks.value[cur].trackId
                history.clear()
                remember(keep)
                next = chooseNext(cur, library)
            }
            if (next == null) {
                status("Acabaram as músicas compatíveis. Deixando a atual terminar.")
                vm.say("AUTO DJ: não há mais músicas compatíveis na biblioteca.")
                return
            }
            if (vm.decks.value[other].playing) NativeEngine.nativePause(other)
            status("Carregando: ${next.title}")
            if (!vm.loadTrackAndWait(other, next)) {
                remember(next.id)
                if (++failures >= 3) {
                    vm.say("AUTO DJ: várias músicas não carregaram. Parando.")
                    return
                }
                continue
            }
            failures = 0
            remember(next.id)
            val dc = vm.decks.value[cur]
            val dn = vm.decks.value[other]
            if (!dn.hasBpm) continue
            val k = bestMultiple(dc.playedBpm, dn.bpm)
            // andamento longe demais: entra na velocidade original, com uma transição curta sem sincronizar
            val newRate = if (k != null) (dc.playedBpm / (dn.bpm * k)).toFloat() else 1f
            // key-lock só se a velocidade mudar mais de 2% (abaixo disso o tom quase não muda e o som fica mais puro)
            vm.setKeyLock(other, abs(newRate - 1f) > 0.02f)
            vm.setRateExact(other, newRate)
            vm.setEq(other, 0, 0f)               // entra sem graves: a troca dos graves é parte da mixagem
            vm.setVolume(other, 1f)

            val curKey = dc.shownKey
            var nextKey = dn.key
            // tons que chocam: muda o tom da que entra em até ±2 semitons (sem mudar o andamento)
            if (_autoKey.value && curKey != null && nextKey != null && k != null && Camelot.distance(curKey, nextKey) >= 2) {
                var bestS = 0
                var bestScore = app.djfusion.harmony.MixAdvisor.keyRelation(curKey, nextKey).keyScore
                for (sh in -2..2) {
                    val sc = app.djfusion.harmony.MixAdvisor.keyRelation(curKey, nextKey.shifted(sh)).keyScore + abs(sh) * 0.15
                    if (sc < bestScore - 0.3) { bestScore = sc; bestS = sh }
                }
                if (bestS != 0) {
                    vm.setKeyShift(other, bestS, remember = false)
                    nextKey = nextKey.shifted(bestS)
                }
            }
            val dist = if (curKey != null && nextKey != null) Camelot.distance(curKey, nextKey) else 2
            var beatsWanted = when {
                k == null -> 8
                dist == 0 -> 32
                dist == 1 -> 16
                dist == 2 -> 8
                else -> 8
            }
            // salto grande de energia: entrada mais curta e decidida
            if (dn.energy >= 0f && dc.energy >= 0f && abs(dn.energy - dc.energy) > 0.25f) beatsWanted = minOf(beatsWanted, 16)
            val prof = profile()
            if (prof.beats > 0 && k != null && dist <= 1) beatsWanted = prof.beats
            if (_beatsChoice.value > 0) beatsWanted = _beatsChoice.value
            // stems prontos nas duas: troca as vozes e os baixos no meio (nunca duas vozes juntas)
            val bothStems = dc.stemsReady && dn.stemsReady
            // grade de batidas pouco confiável numa das duas: transição curta com eco (não arrisca batidas atropeladas)
            val shaky = dc.bpmConfidence < 0.45f || dn.bpmConfidence < 0.45f
            if (shaky && _styleChoice.value == 0) beatsWanted = minOf(beatsWanted, 8)
            // música de andamento variável: a grade troca de trecho; transição mais curta para não atravessar a troca
            if ((dc.tempoVariable || dn.tempoVariable) && _beatsChoice.value == 0) beatsWanted = minOf(beatsWanted, 16)
            lastGenre = next.genre
            val style = when (_styleChoice.value) {
                1 -> Style.EQ
                2 -> Style.FILTER
                3 -> Style.ECHO
                4 -> if (bothStems) Style.STEMS else Style.EQ
                5 -> Style.CUT
                6 -> Style.FADE
                7 -> Style.NONE
                8 -> Style.REVERB
                9 -> Style.LOOP
                10 -> Style.DROP
                else -> when {
                    k == null || dist >= 3 || shaky -> Style.ECHO      // sem compatibilidade: transição segura
                    prof.styles.isNotEmpty() -> {
                        // estilos do modo: o CRIATIVO alterna; os outros usam o primeiro que serve para o par
                        val opts = prof.styles.map { styleOf(it) }.filter { it != Style.STEMS || bothStems }
                            .filter { it != Style.DROP || dropOf(dn, k) > 0 }
                        if (opts.isEmpty()) Style.EQ
                        else if (prof.name == "CRIATIVO") opts[playedCount % opts.size]
                        else if (dist == 2 && Style.FILTER in opts) Style.FILTER else opts.first()
                    }
                    dist == 2 -> Style.FILTER
                    bothStems -> Style.STEMS          // nunca duas vozes juntas
                    else -> Style.EQ
                }
            }.let { st -> if (k == null && st != Style.CUT && st != Style.FADE && st != Style.NONE) Style.ECHO else st }
            // o que vai acontecer, com o porquê (tela AUTO DJ)
            val nextRow: TrackRow = next
            val ranked = rank(cur, library)
            val mine = ranked.firstOrNull { it.row.id == nextRow.id } ?: Ranked(nextRow, 50, "escolhida pela ordem da lista")
            _plan.value = Plan(mine, styleName(style), beatsWanted, other, ranked.filter { it.row.id != nextRow.id }.take(3), poolName)

            // espera o início de uma frase musical (blocos de 16 batidas), como um DJ faria
            var plan = planStart(cur, beatsWanted)
            while (true) {
                val now = vm.decks.value[cur]
                plan = if (mixNowFlag) nextBar(cur, beatsWanted) else planStart(cur, beatsWanted)
                if (style == Style.NONE && !mixNowFlag) {
                    // sem mixagem: a próxima entra quando a atual acabar
                    val left = remainingSec(cur)
                    status("Próxima: ${next.title} · entra no fim (${left.toInt()} s)")
                    if (!now.playing || left < 0.03) { plan = vm.live.value.decks[cur].positionFrames to 4; break }
                    delay(if (left < 1.0) 5 else 200)
                    continue
                }
                val pos = vm.live.value.decks[cur].positionFrames
                val waitSec = (plan.first - pos) / (NativeEngine.SAMPLE_RATE * now.rate.coerceAtLeast(0.1f).toDouble())
                val ended = !now.playing && remainingSec(cur) < 0.5
                status(
                    "Próxima: ${next.title} · ${_plan.value.next?.compat ?: 50}% compatível (${keyText(dn)}, ${bpmText(dn)}, ${styleName(style)}) · entra em ${waitSec.coerceAtLeast(0.0).toInt()} s",
                )
                if (ended || waitSec <= 0.012) break
                if (replaceWith != null && waitSec > 4.0) break
                delay(if (waitSec < 1.0) 10 else 200)
            }
            if (replaceWith != null && vm.decks.value[cur].playing && remainingSec(cur) > 8.0) {
                // o DJ trocou a próxima: carrega a nova no lugar, sem mexer no que está tocando
                if (vm.decks.value[other].playing) NativeEngine.nativePause(other)
                continue
            }
            val beats = plan.second
            lastArtist = vm.decks.value[cur].artist
            mix(cur, other, k, beats, style)
            mixNowFlag = false   // MIXAR AGORA vale para uma transição (mesmo se apertado enquanto a próxima carregava)
            playedCount++
            cur = other
        }
    }

    // ------------------------------------------------------------------- mixagem

    private enum class Style { EQ, FILTER, ECHO, STEMS, CUT, FADE, NONE, REVERB, LOOP, DROP }

    private fun styleOf(i: Int): Style = when (i) {
        1 -> Style.EQ; 2 -> Style.FILTER; 3 -> Style.ECHO; 4 -> Style.STEMS; 5 -> Style.CUT; 6 -> Style.FADE
        7 -> Style.NONE; 8 -> Style.REVERB; 9 -> Style.LOOP; 10 -> Style.DROP; else -> Style.EQ
    }

    /** Batida do drop da música (para a transição DROP), ou -1. */
    private fun dropOf(d: DeckUi, k: Double?): Int {
        if (!d.hasBpm || d.wave == null) return -1
        val nBeat = 60.0 * NativeEngine.SAMPLE_RATE / (d.bpm * (k ?: 1.0))
        val groove = TrackShape.grooveBeat(d.wave, d.firstBeatFrame, nBeat)
        val total = ((d.lengthFrames - d.firstBeatFrame) / nBeat).toInt()
        return TrackShape.dropBeat(d.wave, d.firstBeatFrame, nBeat, groove + 16, total - 48)
    }

    private fun styleName(s: Style) = when (s) {
        Style.STEMS -> "troca de vozes e baixos (stems)"
        Style.CUT -> "corte seco no compasso"
        Style.FADE -> "fade (sem silêncio)"
        Style.NONE -> "sem mixagem (uma depois da outra)"
        Style.EQ -> "troca de graves"
        Style.FILTER -> "filtro"
        Style.ECHO -> "eco"
        Style.REVERB -> "reverb (a que sai some no espaço)"
        Style.LOOP -> "loop (a que sai repete o último compasso)"
        Style.DROP -> "drop (a que entra cai direto no drop)"
    }

    /**
     * Onde começar a mixagem: no início da última frase (múltiplo de 16 batidas) que ainda deixa espaço para a
     * transição inteira. Se essa frase já passou, no próximo compasso. Devolve (quadro de início, batidas).
     */
    private fun planStart(cur: Int, beatsWanted: Int): Pair<Long, Int> {
        val d = vm.decks.value[cur]
        val beat = 60.0 * NativeEngine.SAMPLE_RATE / d.bpm
        val first = d.firstBeatFrame.toDouble()
        val pos = vm.live.value.decks[cur].positionFrames.toDouble()
        // fim musical (antes do fade-out/silêncio do arquivo): a transição termina ali
        val end = TrackShape.musicalEnd(d.wave, d.lengthFrames)
        val totalBeats = floor((end - first) / beat).toInt()
        val posBeat = kotlin.math.ceil((pos - first) / beat).toInt().coerceAtLeast(0)
        // ponto de SAÍDA marcado pelo DJ (hot cue 8): a mixagem começa exatamente ali
        val manualOut = d.hotcues.getOrElse(7) { -1L }
        if (manualOut > 0) {
            val mb = Math.round((manualOut - first) / beat).toInt()
            if (mb >= posBeat) {
                val b = minOf(beatsWanted.coerceAtLeast(8), totalBeats - mb - 1).coerceAtLeast(4)
                return (first + mb * beat).toLong() to b
            }
        }
        // saída da música (os graves somem): o DJ mixa por cima dela, começando no início da frase da saída
        val outro = TrackShape.outroBeat(d.wave, d.firstBeatFrame, beat, totalBeats)
        val userBeats = _beatsChoice.value > 0
        if (outro < totalBeats - 8 && outro >= posBeat) {
            val len = totalBeats - outro - 1
            var b = if (userBeats) minOf(beatsWanted, len) else minOf(maxOf(beatsWanted, minOf(32, len)), len)
            b = if (b >= 16) (b / 16) * 16 else (b / 4) * 4
            if (b >= 8) return (first + outro * beat).toLong() to b
        }
        val phrase = ((totalBeats - beatsWanted - 2) / 16) * 16
        val start = if (phrase >= posBeat) phrase else ((posBeat + 3) / 4) * 4
        val beats = minOf(beatsWanted, totalBeats - start - 1).coerceAtLeast(4)
        return (first + start * beat).toLong() to beats
    }

    /** Próximo tempo forte de compasso a partir de agora (MIXAR AGORA). */
    private fun nextBar(cur: Int, beatsWanted: Int): Pair<Long, Int> {
        val d = vm.decks.value[cur]
        if (!d.hasBpm) return vm.live.value.decks[cur].positionFrames to beatsWanted
        val beat = 60.0 * NativeEngine.SAMPLE_RATE / d.bpm
        val first = d.firstBeatFrame.toDouble()
        val pos = vm.live.value.decks[cur].positionFrames.toDouble()
        val posBeat = kotlin.math.ceil((pos - first) / beat).toInt().coerceAtLeast(0)
        val start = ((posBeat + 3) / 4) * 4
        val totalBeats = floor((d.lengthFrames - first) / beat).toInt()
        return (first + start * beat).toLong() to minOf(beatsWanted, (totalBeats - start - 1).coerceAtLeast(4))
    }

    private suspend fun mix(cur: Int, other: Int, k: Double?, beats: Int, style: Style) {
        val dc = vm.decks.value[cur]
        val dn = vm.decks.value[other]
        val sr = NativeEngine.SAMPLE_RATE.toDouble()
        val refBeat = 60.0 * sr / dc.bpm
        val nBeat = 60.0 * sr / (dn.bpm * (k ?: 1.0))
        val sec = when (style) {
            Style.CUT, Style.NONE -> 0.06
            else -> beats * 60.0 / dc.playedBpm
        }
        val curSide = if (cur == 0) 0f else 1f
        val nextSide = 1f - curSide
        vm.setCrossfader(curSide)
        status("Mixando: ${dc.title} → ${dn.title} ($beats batidas, tom ${keyText(dc)} → ${keyText(dn)})", true)
        if (k == null) {
            NativeEngine.nativePlay(other)
        } else if (dc.playing) {
            // a entrada começa na mesma posição do compasso em que a música atual está (alinha compassos)
            val refPos = vm.live.value.decks[cur].positionFrames
            val refIdx = floor((refPos - dc.firstBeatFrame) / refBeat).toLong()
            // a que entra começa depois da introdução silenciosa, num compasso, na mesma posição do compasso
            val introBeats = kotlin.math.max(0.0, kotlin.math.ceil((TrackShape.musicalStart(dn.wave) - dn.firstBeatFrame) / nBeat / 4.0) * 4.0)
            // a parte "cheia" da que entra (bumbo + baixo) chega exatamente quando a mixagem termina:
            // a energia não cai depois da troca, como faz um DJ que conhece a música
            val groove = TrackShape.grooveBeat(dn.wave, dn.firstBeatFrame, nBeat).toDouble()
            // ponto de ENTRADA marcado pelo DJ (hot cue 7) tem prioridade sobre a análise
            val manualIn = dn.hotcues.getOrElse(6) { -1L }
            val drop = if (style == Style.DROP) dropOf(dn, k) else -1
            val base = if (manualIn >= 0) {
                kotlin.math.max(0.0, Math.round((manualIn - dn.firstBeatFrame) / nBeat).toDouble())
            } else if (drop > beats) {
                (drop - beats).toDouble()                    // o drop da que entra cai exatamente no fim da mixagem
            } else kotlin.math.max(introBeats, floor((groove - beats) / 4.0) * 4.0)
            val startBeat = base + (if (manualIn >= 0) 0.0 else (((refIdx % 4) + 4) % 4).toDouble())
            NativeEngine.nativePlaySynced(
                other, cur, dc.firstBeatFrame.toDouble(), refBeat, dn.firstBeatFrame.toDouble(), nBeat, startBeat,
            )
        } else {
            NativeEngine.nativePlaySynced(other, cur, 0.0, refBeat, dn.firstBeatFrame.toDouble(), nBeat, 0.0)
        }
        // trava de fase: durante toda a mixagem a batida da que entra fica colada na da que sai
        if (k != null) vm.setSyncLock(other, true)
        val t0 = System.nanoTime()
        // o andamento da mixagem segue a MÚSICA, não o relógio: o progresso vem da posição da que entra
        // (cada compasso da automação cai no compasso da música, mesmo se o aparelho engasgar)
        var inStart = -1L
        // fim musical da que sai: se ela acabaria antes da mixagem terminar, o último compasso entra em loop
        val outEnd = TrackShape.musicalEnd(dc.wave, dc.lengthFrames)
        var outLooped = false
        if (style == Style.ECHO) {
            // a que sai ganha eco no ritmo e some; a que entra sobe rápido
            NativeEngine.nativeSetFx(cur, 1, 0.8f, (60.0 / dc.playedBpm).toFloat())
        }
        if (style == Style.STEMS) {
            // a que entra começa só com bateria e melodia (sem voz e sem baixo), graves do EQ normais
            vm.setEq(other, 0, 0.5f)
            vm.setStemGain(other, 0, 0f)
            vm.setStemGain(other, 2, 0f)
        }
        // anti-choque de vozes: com stems prontos nas duas, a voz da que entra só aparece quando a da que sai some
        val guardVoice = _antiClash.value && style != Style.STEMS && style != Style.CUT && style != Style.NONE &&
            dc.stemsReady && dn.stemsReady
        if (guardVoice) vm.setStemGain(other, 0, 0f)
        if (style == Style.LOOP && dc.playing && dc.hasBpm && vm.decks.value[cur].loopBeats == 0) vm.toggleLoop(cur, 4)
        if (style == Style.REVERB) NativeEngine.nativeSetFx(cur, 3, 0.3f, (60.0 / dc.playedBpm).toFloat())
        while (true) {
            val tClock = ((System.nanoTime() - t0) / 1e9 / sec).coerceIn(0.0, 1.0)
            val inPos = vm.live.value.decks[other].positionFrames
            if (inStart < 0 && System.nanoTime() - t0 > 60_000_000L && vm.decks.value[other].playing) inStart = inPos
            val t = if (k != null && inStart >= 0 && style != Style.CUT && style != Style.NONE) {
                ((inPos - inStart) / (beats * nBeat)).coerceIn(0.0, 1.0).let { tp ->
                    // segurança: se a posição não andar (pausa, erro), o relógio termina a mixagem
                    if (tClock >= 1.0 && tClock - tp > 0.5) tClock else tp
                }
            } else tClock
            if (!outLooped && k != null && dc.hasBpm && t < 0.9) {
                val beatsLeft = (outEnd - vm.live.value.decks[cur].positionFrames) / refBeat
                if (beatsLeft in 0.5..5.0 && vm.decks.value[cur].loopBeats == 0) {
                    outLooped = true
                    vm.toggleLoop(cur, 4)
                }
            }
            val s = (t * t * (3 - 2 * t)).toFloat()
            when (style) {
                Style.EQ -> {
                    // 1ª metade: a que entra sobe sem graves; no compasso do meio os graves trocam em 1 batida
                    // (como o DJ gira os dois botões de grave juntos); 2ª metade: a que sai desce, com médios mais baixos
                    val tb = t * beats
                    val swapBeat = (Math.round(beats / 8.0).toInt() * 4).coerceIn(4, maxOf(4, beats - 4)).toDouble()
                    val swap = (tb - swapBeat).coerceIn(0.0, 1.0).toFloat()
                    val up = (tb / swapBeat).coerceIn(0.0, 1.0)
                    val down = ((tb - swapBeat) / (beats - swapBeat).coerceAtLeast(1.0)).coerceIn(0.0, 1.0)
                    val xf = 0.5 * (up * up * (3 - 2 * up)) + 0.5 * (down * down * (3 - 2 * down))
                    vm.setCrossfader(curSide + (nextSide - curSide) * xf.toFloat())
                    vm.setEq(cur, 0, 0.5f - 0.5f * swap)
                    vm.setEq(cur, 1, 0.5f - 0.12f * swap)
                    vm.setEq(other, 0, 0.5f * swap)
                }
                Style.FILTER -> {
                    vm.setCrossfader(curSide + (nextSide - curSide) * s)
                    vm.setFilter(cur, (0.5 + 0.42 * t).toFloat())          // a que sai vai perdendo os graves pelo filtro
                    vm.setEq(other, 0, (0.5 * ((t - 0.4) / 0.3).coerceIn(0.0, 1.0)).toFloat())
                }
                Style.STEMS -> {
                    // a que entra sobe na primeira metade; no meio a voz e o baixo passam de uma para a outra
                    val up = (t / 0.45).coerceIn(0.0, 1.0).toFloat()
                    val swap = ((t - 0.5) / 0.08).coerceIn(0.0, 1.0).toFloat()
                    val out = ((t - 0.6) / 0.4).coerceIn(0.0, 1.0).toFloat()
                    val xf = 0.5f * up + 0.5f * out
                    vm.setCrossfader(curSide + (nextSide - curSide) * xf)
                    vm.setStemGain(cur, 0, 1f - swap)
                    vm.setStemGain(cur, 2, 1f - swap)
                    vm.setStemGain(other, 0, swap)
                    vm.setStemGain(other, 2, swap)
                }
                Style.FADE -> {
                    vm.setCrossfader(curSide + (nextSide - curSide) * t.toFloat())
                    vm.setEq(other, 0, 0.5f)
                }
                Style.NONE -> {
                    vm.setCrossfader(nextSide)
                    vm.setEq(other, 0, 0.5f)
                }
                Style.CUT -> {
                    // corte seco exatamente no tempo forte do compasso
                    vm.setCrossfader(nextSide)
                    vm.setEq(other, 0, 0.5f)
                }
                Style.ECHO -> {
                    val fast = (t / 0.35).coerceIn(0.0, 1.0)
                    vm.setCrossfader(curSide + (nextSide - curSide) * (fast * fast * (3 - 2 * fast)).toFloat())
                    vm.setEq(other, 0, 0.5f)
                }
                Style.REVERB -> {
                    // a que sai vai ganhando reverb e se afasta; a que entra sobe na segunda metade
                    NativeEngine.nativeSetFx(cur, 3, (0.3 + 0.7 * t).toFloat(), (60.0 / dc.playedBpm).toFloat())
                    val up = ((t - 0.35) / 0.65).coerceIn(0.0, 1.0)
                    vm.setCrossfader(curSide + (nextSide - curSide) * (up * up * (3 - 2 * up)).toFloat())
                    vm.setEq(other, 0, (0.5 * up).toFloat())
                }
                Style.LOOP -> {
                    // a que sai repete o compasso enquanto a que entra sobe sem graves; graves trocam no fim
                    vm.setCrossfader(curSide + (nextSide - curSide) * s)
                    val swap = ((t - 0.75) / 0.1).coerceIn(0.0, 1.0).toFloat()
                    vm.setEq(cur, 0, 0.5f - 0.5f * swap)
                    vm.setEq(other, 0, 0.5f * swap)
                }
                Style.DROP -> {
                    // filtro subindo na que sai e a que entra baixinha (sem graves); no fim, corte seco no drop
                    vm.setFilter(cur, (0.5 + 0.45 * t).toFloat())
                    vm.setCrossfader(if (t < 0.98) curSide + (nextSide - curSide) * (0.35f * s) else nextSide)
                    vm.setEq(other, 0, if (t < 0.98) 0f else 0.5f)
                }
            }
            if (guardVoice) {
                // troca das vozes no meio da transição (em ~1 batida)
                val v = ((t - 0.5) * beats).coerceIn(0.0, 1.0).toFloat()
                vm.setStemGain(cur, 0, 1f - v)
                vm.setStemGain(other, 0, v)
            }
            if (t >= 1.0) break
            delay(30)
        }
        if (outLooped && vm.decks.value[cur].loopBeats == 4) vm.toggleLoop(cur, 4)
        if (style == Style.ECHO || style == Style.REVERB) vm.restoreFx(cur)   // volta o efeito que o DJ tinha escolhido
        if (style == Style.FILTER || style == Style.DROP) vm.setFilter(cur, 0.5f)
        if (style == Style.LOOP && vm.decks.value[cur].loopBeats == 4) vm.toggleLoop(cur, 4)
        if (guardVoice) { vm.setStemGain(other, 0, 1f); vm.stemPreset(cur, 0) }
        vm.setCrossfader(nextSide)
        NativeEngine.nativePause(cur)
        vm.setSyncLock(other, false)
        if (style == Style.STEMS) vm.stemPreset(cur, 0)   // o deck que saiu volta com todos os stems
        vm.setEq(cur, 0, 0.5f)
        vm.setEq(cur, 1, 0.5f)
        vm.setEq(other, 0, 0.5f)
        delay(400)   // deixa o deck que saiu parar de verdade antes de carregar a próxima faixa nele
        status("Tocando: ${dn.title}")
    }

    /** O andamento volta devagar a 100% (0,5% por segundo), com key-lock ligado (o tom não muda). */
    private suspend fun easeRateToNormal(deck: Int) {
        var guard = 0
        while (guard++ < 400) {
            val d = vm.decks.value[deck]
            val diff = 1f - d.rate
            if (abs(diff) < 0.0015f) {
                if (d.rate != 1f) vm.setRateExact(deck, 1f)
                if (d.keyShift == 0) vm.setKeyLock(deck, false)   // no 0% o key-lock só pioraria o som
                return
            }
            if (!d.playing || remainingSec(deck) < 40.0) return
            vm.setRateExact(deck, d.rate + diff.coerceIn(-0.0005f, 0.0005f))
            delay(100)
        }
    }

    // ---------------------------------------------------------------- escolha

    private fun firstDeck(): Int {
        val d = vm.decks.value
        return when {
            d[0].playing -> 0
            d[1].playing -> 1
            d[0].loaded -> 0
            d[1].loaded -> 1
            else -> 0
        }
    }

    private fun remainingSec(deck: Int): Double {
        val d = vm.decks.value[deck]
        val pos = vm.live.value.decks[deck].positionFrames
        return (d.lengthFrames - pos).coerceAtLeast(0L) / (NativeEngine.SAMPLE_RATE.toDouble() * d.rate.coerceAtLeast(0.1f))
    }

    /** Artista da música anterior à atual (para não repetir artista). */
    private var lastArtist = ""

    private fun remember(id: Long) {
        history.addLast(id)
        while (history.size > 12) history.removeFirst()
    }

    /** O fator (1, 2 ou 1/2) que deixa o andamento da faixa mais perto do alvo, se ficar a menos de 12%. */
    private fun bestMultiple(targetBpm: Double, trackBpm: Double): Double? {
        var best: Double? = null
        var bestErr = 0.12
        for (k in doubleArrayOf(1.0, 2.0, 0.5)) {
            val err = abs(targetBpm / (trackBpm * k) - 1.0)
            if (err < bestErr) { bestErr = err; best = k }
        }
        return best
    }

    private fun chooseNext(cur: Int, library: List<TrackRow>): TrackRow? = rank(cur, library).firstOrNull()?.row

    /**
     * Notas de compatibilidade (0–100) de todas as candidatas, da melhor para a pior, com o porquê:
     * andamento, tom (Roda de Camelot), energia (pelo modo/curva), artista repetido e o que o DJ já trocou.
     */
    private fun rank(cur: Int, library: List<TrackRow>): List<Ranked> {
        val dc = vm.decks.value[cur]
        val loaded = vm.decks.value.map { it.trackId }
        val curKey = dc.shownKey
        val prof = profile()
        val curGenre = normGenre(library.firstOrNull { it.id == dc.trackId }?.genre ?: lastGenre)
        val out = ArrayList<Ranked>()
        for (c in library) {
            if (c.bpm <= 0.0 || c.id in history || c.id in loaded) continue
            val k = bestMultiple(dc.playedBpm, c.bpm)
            val err = if (k == null) 1.0 else abs(dc.playedBpm / (c.bpm * k) - 1.0)
            val bpmFit = if (k == null) 0.0 else (1.0 - err / 0.08).coerceIn(0.0, 1.0)
            val ck = c.key
            val rel = app.djfusion.harmony.MixAdvisor.keyRelation(curKey, ck)
            val keyFit = (1.0 - rel.keyScore / 5.0).coerceIn(0.0, 1.0)
            val target: Float? = prof.energy?.invoke(playedCount) ?: energyTargetFor(playedCount)
            val eDiff = when {
                c.energy < 0f -> 0.25
                target != null -> abs(c.energy - target).toDouble()
                dc.energy >= 0f -> (c.energy - dc.energy).let { if (it < -0.15f) -it * 1.5 else abs(it - 0.05f) }.toDouble()
                else -> 0.25
            }
            val energyFit = (1.0 - eDiff / 0.5).coerceIn(0.0, 1.0)
            val g = normGenre(c.genre)
            val genreFit = when {
                curGenre.isEmpty() || g.isEmpty() -> 0.5                       // sem etiqueta: neutro
                g == curGenre -> 1.0
                g.split(' ').any { it.length > 2 && it in curGenre.split(' ') } -> 0.7   // "pop" e "pop rock"
                else -> 0.0
            }
            val wSum = prof.wBpm + prof.wKey + prof.wEnergy + prof.wGenre
            var score = if (wSum <= 0.0) 0.5 else (prof.wBpm * bpmFit + prof.wKey * keyFit + prof.wEnergy * energyFit + prof.wGenre * genreFit) / wSum
            val sameArtist = c.artist.isNotBlank() && (c.artist.equals(dc.artist, true) || c.artist.equals(lastArtist, true))
            if (sameArtist) score *= 0.7
            val rejected = "${dc.trackId}>${c.id}" in rejections
            if (rejected) score *= 0.5
            val compat = (score * 100).toInt().coerceIn(0, 100)
            val why = buildString {
                append(if (k == null) "andamento longe" else String.format(java.util.Locale.ROOT, "BPM %+.1f%%", (dc.playedBpm / (c.bpm * k) - 1.0) * 100))
                append(" · ").append(if (curKey != null && ck != null) "${curKey.code}→${ck.code} ${rel.name}" else "tom ?")
                if (c.energy >= 0f) append(" · energia ${c.energyLevel}")
                if (prof.wGenre > 0.0 && c.genre.isNotEmpty()) append(" · ").append(c.genre).append(if (genreFit >= 1.0) " (mesmo gênero)" else "")
                if (sameArtist) append(" · mesmo artista")
                if (rejected) append(" · você já trocou")
            }
            out.add(Ranked(c, compat, why))
        }
        return out.sortedByDescending { it.compat + Random.nextDouble() * 2 }
    }

    private fun normGenre(x: String?): String = java.text.Normalizer.normalize(x.orEmpty().lowercase(), java.text.Normalizer.Form.NFD)
        .replace(Regex("\\p{M}+"), "").replace(Regex("[^a-z0-9]+"), " ").trim()

    /** Gênero da música que tocou por último (quando a atual não está na lista). */
    @Volatile private var lastGenre: String = ""

    private fun keyText(d: DeckUi): String = d.key?.code ?: "tom ?"
    private fun bpmText(d: DeckUi): String = String.format(java.util.Locale.ROOT, "%.0f BPM", d.bpm)

    companion object {
        /** Perfis de energia da noite (o número é guardado: os 4 primeiros são os de antes). */
        val ENERGY_PROFILES = listOf(
            "LIVRE", "PROGRESSIVO", "ONDAS", "FECHAR", "RELAXADO", "SUAVE", "EQUILIBRADO", "FESTA", "ALTA ENERGIA", "PICO DE PISTA", "PERSONALIZADO",
        )
    }
}
