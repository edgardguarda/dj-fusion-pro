package app.djfusion.ui

import app.djfusion.audio.NativeEngine
import app.djfusion.data.TrackRow
import app.djfusion.harmony.Camelot
import app.djfusion.harmony.TrackShape
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import kotlin.math.abs
import kotlin.math.floor
import kotlin.random.Random

/**
 * AUTO DJ: o app toca a biblioteca sozinho. É inteligência local (sem internet): usa o andamento e a tonalidade
 * analisados de cada faixa para escolher a próxima música (andamento parecido, tom compatível na Roda de Camelot),
 * ajusta o andamento dela ao da que está tocando (com key-lock, sem mudar o tom), entra com a batida alinhada
 * e faz a mixagem com crossfader e troca dos graves. Perto de um tom que choca, a mixagem é curta.
 */
class AutoDj(
    private val vm: AppViewModel,
    private val scope: CoroutineScope,
    private val prefs: android.content.SharedPreferences,
) {
    /** Estilo escolhido: 0 automático, 1 graves (EQ), 2 filtro, 3 eco, 4 stems, 5 corte seco, 6 fade, 7 sem mixagem. */
    private val _styleChoice = MutableStateFlow(prefs.getInt("style", 0).coerceIn(0, 7))
    val styleChoice: StateFlow<Int> = _styleChoice.asStateFlow()
    /** Duração: 0 automática, ou 8, 16, 32 batidas. */
    private val _beatsChoice = MutableStateFlow(prefs.getInt("beats", 0))
    val beatsChoice: StateFlow<Int> = _beatsChoice.asStateFlow()
    /** Ajusta o tom da música que entra (até ±2 semitons) quando os tons chocam. */
    private val _autoKey = MutableStateFlow(prefs.getBoolean("autoKey", true))
    val autoKey: StateFlow<Boolean> = _autoKey.asStateFlow()

    fun setStyleChoice(v: Int) { _styleChoice.value = v.coerceIn(0, 7); prefs.edit().putInt("style", _styleChoice.value).apply() }

    /** Mantém o andamento entre as músicas (senão o pitch volta devagar a 0%, como no VirtualDJ). */
    private val _keepTempo = MutableStateFlow(prefs.getBoolean("keepTempo", false))
    val keepTempo: StateFlow<Boolean> = _keepTempo.asStateFlow()
    fun toggleKeepTempo() { _keepTempo.value = !_keepTempo.value; prefs.edit().putBoolean("keepTempo", _keepTempo.value).apply() }

    /** MIXAR AGORA: começa a transição no próximo compasso, sem esperar o fim da música. */
    @Volatile private var mixNowFlag = false
    fun mixNow() {
        if (job?.isActive != true) { vm.say("Ligue o AUTO DJ primeiro."); return }
        mixNowFlag = true
        vm.say("AUTO DJ: mixando agora, no próximo compasso.")
    }
    fun setBeatsChoice(v: Int) { _beatsChoice.value = v; prefs.edit().putInt("beats", v).apply() }
    private val _energyMode = MutableStateFlow(prefs.getInt("energyMode", 0).coerceIn(0, 3))
    /** Curva de energia da noite: 0 manter/subir pouco, 1 aquecer até o pico, 2 ondas (sobe e respira), 3 baixar (fim de noite). */
    val energyMode: StateFlow<Int> = _energyMode
    fun setEnergyMode(v: Int) { _energyMode.value = v.coerceIn(0, 3); prefs.edit().putInt("energyMode", _energyMode.value).apply() }
    private var playedCount = 0

    fun toggleAutoKey() { _autoKey.value = !_autoKey.value; prefs.edit().putBoolean("autoKey", _autoKey.value).apply() }


    data class State(val active: Boolean = false, val status: String = "", val mixing: Boolean = false)

    private val _state = MutableStateFlow(State())
    val state: StateFlow<State> = _state.asStateFlow()
    private var job: Job? = null
    private val history = ArrayDeque<Long>()

    fun toggle() {
        if (job?.isActive == true) stop() else start()
    }

    fun stop() {
        job?.cancel()
        job = null
        _state.value = State()
        vm.say("AUTO DJ desligado. Os decks continuam como estão.")
    }

    fun start() {
        if (job?.isActive == true) return
        _state.value = State(true, "Preparando…")
        playedCount = 0
        job = scope.launch {
            try {
                run()
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                vm.say("AUTO DJ parou: ${e.message ?: "erro inesperado"}")
            } finally {
                _state.update { it.copy(active = false, mixing = false, status = "") }
            }
        }
    }

    private fun status(text: String, mixing: Boolean = false) {
        _state.value = State(true, text, mixing)
    }

    // ----------------------------------------------------------------- laço principal

    private suspend fun run() {
        var library = vm.allTracks()
        if (library.size < 2) {
            vm.say("O AUTO DJ precisa de pelo menos 2 músicas na biblioteca. Toque em BIBLIOTECA e depois em IMPORTAR.")
            return
        }
        if (library.any { !it.analyzed }) {
            // analisa sozinho o que falta (andamento e tom), sem pedir nada ao DJ
            vm.analyzeMissing { done, total -> status("Analisando a biblioteca: $done de $total") }
            library = vm.allTracks()
        }
        if (library.count { it.bpm > 0 } < 2) {
            vm.say("O AUTO DJ não achou andamento em pelo menos 2 músicas.")
            return
        }
        var cur = firstDeck()
        val d0 = vm.decks.value[cur]
        if (!d0.loaded) {
            status("Escolhendo a primeira música…")
            val first = library.filter { it.bpm > 0 }.random()
            if (!vm.loadTrackAndWait(cur, first)) {
                vm.say("Não consegui carregar a primeira música.")
                return
            }
        }
        if (!vm.decks.value[cur].hasBpm) {
            vm.say("A música do deck ${AppViewModel.deckName(cur)} não tem andamento detectado. Escolha outra ou use ANALISAR.")
            return
        }
        vm.setVolume(0, 1f)
        vm.setVolume(1, 1f)
        vm.setCrossfader(if (cur == 0) 0f else 1f)
        vm.setEq(cur, 0, 0.5f)
        vm.setKeyLock(cur, true)
        if (!vm.decks.value[cur].playing) NativeEngine.nativePlay(cur)
        remember(vm.decks.value[cur].trackId)

        var failures = 0
        while (true) {
            val other = 1 - cur
            // volta o andamento da música atual ao original, devagar, para as próximas misturas não derivarem
            if (!_keepTempo.value) easeRateToNormal(cur)

            library = vm.allTracks()
            status("Escolhendo a próxima música…")
            // com set harmonizado, segue a ordem dele; senão escolhe a melhor agora
            val setId = vm.nextInSet(vm.decks.value[cur].trackId, history)
            var next = library.firstOrNull { it.id == setId && it.bpm > 0 } ?: chooseNext(cur, library)
            if (next == null && history.size > 1) {
                // biblioteca pequena: libera as já tocadas (menos a atual) e tenta de novo
                val keep = vm.decks.value[cur].trackId
                history.clear()
                remember(keep)
                next = chooseNext(cur, library)
            }
            if (next == null) {
                status("Acabaram as músicas compatíveis. Deixando a atual terminar.")
                vm.say("AUTO DJ: não há mais músicas compatíveis na biblioteca.")
                return
            }
            if (vm.decks.value[other].playing) NativeEngine.nativePause(other)
            status("Carregando: ${next.title}")
            if (!vm.loadTrackAndWait(other, next)) {
                remember(next.id)
                if (++failures >= 3) {
                    vm.say("AUTO DJ: várias músicas não carregaram. Parando.")
                    return
                }
                continue
            }
            failures = 0
            remember(next.id)
            val dc = vm.decks.value[cur]
            val dn = vm.decks.value[other]
            if (!dn.hasBpm) continue
            val k = bestMultiple(dc.playedBpm, dn.bpm)
            vm.setKeyLock(other, true)
            // andamento longe demais: entra na velocidade original, com uma transição curta sem sincronizar
            vm.setRateExact(other, if (k != null) (dc.playedBpm / (dn.bpm * k)).toFloat() else 1f)
            vm.setEq(other, 0, 0f)               // entra sem graves: a troca dos graves é parte da mixagem
            vm.setVolume(other, 1f)

            val curKey = dc.shownKey
            var nextKey = dn.key
            // tons que chocam: muda o tom da que entra em até ±2 semitons (sem mudar o andamento)
            if (_autoKey.value && curKey != null && nextKey != null && k != null && Camelot.distance(curKey, nextKey) >= 2) {
                var bestS = 0
                var bestScore = app.djfusion.harmony.MixAdvisor.keyRelation(curKey, nextKey).keyScore
                for (sh in -2..2) {
                    val sc = app.djfusion.harmony.MixAdvisor.keyRelation(curKey, nextKey.shifted(sh)).keyScore + abs(sh) * 0.15
                    if (sc < bestScore - 0.3) { bestScore = sc; bestS = sh }
                }
                if (bestS != 0) {
                    vm.setKeyShift(other, bestS, remember = false)
                    nextKey = nextKey.shifted(bestS)
                }
            }
            val dist = if (curKey != null && nextKey != null) Camelot.distance(curKey, nextKey) else 2
            var beatsWanted = when {
                k == null -> 8
                dist == 0 -> 32
                dist == 1 -> 16
                dist == 2 -> 8
                else -> 8
            }
            // salto grande de energia: entrada mais curta e decidida
            if (dn.energy >= 0f && dc.energy >= 0f && abs(dn.energy - dc.energy) > 0.25f) beatsWanted = minOf(beatsWanted, 16)
            if (_beatsChoice.value > 0) beatsWanted = _beatsChoice.value
            // stems prontos nas duas: troca as vozes e os baixos no meio (nunca duas vozes juntas)
            val bothStems = dc.stemsReady && dn.stemsReady
            // grade de batidas pouco confiável numa das duas: transição curta com eco (não arrisca batidas atropeladas)
            val shaky = dc.bpmConfidence < 0.45f || dn.bpmConfidence < 0.45f
            if (shaky && _styleChoice.value == 0) beatsWanted = minOf(beatsWanted, 8)
            val style = when (_styleChoice.value) {
                1 -> Style.EQ
                2 -> Style.FILTER
                3 -> Style.ECHO
                4 -> if (bothStems) Style.STEMS else Style.EQ
                5 -> Style.CUT
                6 -> Style.FADE
                7 -> Style.NONE
                else -> when {
                    k == null || dist >= 3 || shaky -> Style.ECHO
                    dist == 2 -> Style.FILTER
                    bothStems -> Style.STEMS          // nunca duas vozes juntas
                    else -> Style.EQ
                }
            }.let { st -> if (k == null && st != Style.CUT && st != Style.FADE && st != Style.NONE) Style.ECHO else st }

            // espera o início de uma frase musical (blocos de 16 batidas), como um DJ faria
            var plan = planStart(cur, beatsWanted)
            mixNowFlag = false
            while (true) {
                val now = vm.decks.value[cur]
                plan = if (mixNowFlag) nextBar(cur, beatsWanted) else planStart(cur, beatsWanted)
                if (style == Style.NONE && !mixNowFlag) {
                    // sem mixagem: a próxima entra quando a atual acabar
                    val left = remainingSec(cur)
                    status("Próxima: ${next.title} · entra no fim (${left.toInt()} s)")
                    if (!now.playing || left < 0.03) { plan = vm.live.value.decks[cur].positionFrames to 4; break }
                    delay(if (left < 1.0) 5 else 200)
                    continue
                }
                val pos = vm.live.value.decks[cur].positionFrames
                val waitSec = (plan.first - pos) / (NativeEngine.SAMPLE_RATE * now.rate.coerceAtLeast(0.1f).toDouble())
                val ended = !now.playing && remainingSec(cur) < 0.5
                status(
                    "Próxima: ${next.title} (${keyText(dn)}, ${bpmText(dn)}, ${styleName(style)}) · entra em ${waitSec.coerceAtLeast(0.0).toInt()} s",
                )
                if (ended || waitSec <= 0.012) break
                delay(if (waitSec < 1.0) 10 else 200)
            }
            val beats = plan.second
            mix(cur, other, k, beats, style)
            playedCount++
            cur = other
        }
    }

    // ------------------------------------------------------------------- mixagem

    private enum class Style { EQ, FILTER, ECHO, STEMS, CUT, FADE, NONE }

    private fun styleName(s: Style) = when (s) {
        Style.STEMS -> "troca de vozes e baixos (stems)"
        Style.CUT -> "corte seco no compasso"
        Style.FADE -> "fade (sem silêncio)"
        Style.NONE -> "sem mixagem (uma depois da outra)"
        Style.EQ -> "troca de graves"
        Style.FILTER -> "filtro"
        Style.ECHO -> "eco"
    }

    /**
     * Onde começar a mixagem: no início da última frase (múltiplo de 16 batidas) que ainda deixa espaço para a
     * transição inteira. Se essa frase já passou, no próximo compasso. Devolve (quadro de início, batidas).
     */
    private fun planStart(cur: Int, beatsWanted: Int): Pair<Long, Int> {
        val d = vm.decks.value[cur]
        val beat = 60.0 * NativeEngine.SAMPLE_RATE / d.bpm
        val first = d.firstBeatFrame.toDouble()
        val pos = vm.live.value.decks[cur].positionFrames.toDouble()
        // fim musical (antes do fade-out/silêncio do arquivo): a transição termina ali
        val end = TrackShape.musicalEnd(d.wave, d.lengthFrames)
        val totalBeats = floor((end - first) / beat).toInt()
        val posBeat = kotlin.math.ceil((pos - first) / beat).toInt().coerceAtLeast(0)
        // ponto de SAÍDA marcado pelo DJ (hot cue 8): a mixagem começa exatamente ali
        val manualOut = d.hotcues.getOrElse(7) { -1L }
        if (manualOut > 0) {
            val mb = Math.round((manualOut - first) / beat).toInt()
            if (mb >= posBeat) {
                val b = minOf(beatsWanted.coerceAtLeast(8), totalBeats - mb - 1).coerceAtLeast(4)
                return (first + mb * beat).toLong() to b
            }
        }
        // saída da música (os graves somem): o DJ mixa por cima dela, começando no início da frase da saída
        val outro = TrackShape.outroBeat(d.wave, d.firstBeatFrame, beat, totalBeats)
        val userBeats = _beatsChoice.value > 0
        if (outro < totalBeats - 8 && outro >= posBeat) {
            val len = totalBeats - outro - 1
            var b = if (userBeats) minOf(beatsWanted, len) else minOf(maxOf(beatsWanted, minOf(32, len)), len)
            b = if (b >= 16) (b / 16) * 16 else (b / 4) * 4
            if (b >= 8) return (first + outro * beat).toLong() to b
        }
        val phrase = ((totalBeats - beatsWanted - 2) / 16) * 16
        val start = if (phrase >= posBeat) phrase else ((posBeat + 3) / 4) * 4
        val beats = minOf(beatsWanted, totalBeats - start - 1).coerceAtLeast(4)
        return (first + start * beat).toLong() to beats
    }

    /** Próximo tempo forte de compasso a partir de agora (MIXAR AGORA). */
    private fun nextBar(cur: Int, beatsWanted: Int): Pair<Long, Int> {
        val d = vm.decks.value[cur]
        if (!d.hasBpm) return vm.live.value.decks[cur].positionFrames to beatsWanted
        val beat = 60.0 * NativeEngine.SAMPLE_RATE / d.bpm
        val first = d.firstBeatFrame.toDouble()
        val pos = vm.live.value.decks[cur].positionFrames.toDouble()
        val posBeat = kotlin.math.ceil((pos - first) / beat).toInt().coerceAtLeast(0)
        val start = ((posBeat + 3) / 4) * 4
        val totalBeats = floor((d.lengthFrames - first) / beat).toInt()
        return (first + start * beat).toLong() to minOf(beatsWanted, (totalBeats - start - 1).coerceAtLeast(4))
    }

    private suspend fun mix(cur: Int, other: Int, k: Double?, beats: Int, style: Style) {
        val dc = vm.decks.value[cur]
        val dn = vm.decks.value[other]
        val sr = NativeEngine.SAMPLE_RATE.toDouble()
        val refBeat = 60.0 * sr / dc.bpm
        val nBeat = 60.0 * sr / (dn.bpm * (k ?: 1.0))
        val sec = when (style) {
            Style.CUT, Style.NONE -> 0.06
            else -> beats * 60.0 / dc.playedBpm
        }
        val curSide = if (cur == 0) 0f else 1f
        val nextSide = 1f - curSide
        vm.setCrossfader(curSide)
        status("Mixando: ${dc.title} → ${dn.title} ($beats batidas, tom ${keyText(dc)} → ${keyText(dn)})", true)
        if (k == null) {
            NativeEngine.nativePlay(other)
        } else if (dc.playing) {
            // a entrada começa na mesma posição do compasso em que a música atual está (alinha compassos)
            val refPos = vm.live.value.decks[cur].positionFrames
            val refIdx = floor((refPos - dc.firstBeatFrame) / refBeat).toLong()
            // a que entra começa depois da introdução silenciosa, num compasso, na mesma posição do compasso
            val introBeats = kotlin.math.max(0.0, kotlin.math.ceil((TrackShape.musicalStart(dn.wave) - dn.firstBeatFrame) / nBeat / 4.0) * 4.0)
            // a parte "cheia" da que entra (bumbo + baixo) chega exatamente quando a mixagem termina:
            // a energia não cai depois da troca, como faz um DJ que conhece a música
            val groove = TrackShape.grooveBeat(dn.wave, dn.firstBeatFrame, nBeat).toDouble()
            // ponto de ENTRADA marcado pelo DJ (hot cue 7) tem prioridade sobre a análise
            val manualIn = dn.hotcues.getOrElse(6) { -1L }
            val base = if (manualIn >= 0) {
                kotlin.math.max(0.0, Math.round((manualIn - dn.firstBeatFrame) / nBeat).toDouble())
            } else kotlin.math.max(introBeats, floor((groove - beats) / 4.0) * 4.0)
            val startBeat = base + (if (manualIn >= 0) 0.0 else (((refIdx % 4) + 4) % 4).toDouble())
            NativeEngine.nativePlaySynced(
                other, cur, dc.firstBeatFrame.toDouble(), refBeat, dn.firstBeatFrame.toDouble(), nBeat, startBeat,
            )
        } else {
            NativeEngine.nativePlaySynced(other, cur, 0.0, refBeat, dn.firstBeatFrame.toDouble(), nBeat, 0.0)
        }
        // trava de fase: durante toda a mixagem a batida da que entra fica colada na da que sai
        if (k != null) vm.setSyncLock(other, true)
        val t0 = System.nanoTime()
        if (style == Style.ECHO) {
            // a que sai ganha eco no ritmo e some; a que entra sobe rápido
            NativeEngine.nativeSetFx(cur, 1, 0.8f, (60.0 / dc.playedBpm).toFloat())
        }
        if (style == Style.STEMS) {
            // a que entra começa só com bateria e melodia (sem voz e sem baixo), graves do EQ normais
            vm.setEq(other, 0, 0.5f)
            vm.setStemGain(other, 0, 0f)
            vm.setStemGain(other, 2, 0f)
        }
        while (true) {
            val t = ((System.nanoTime() - t0) / 1e9 / sec).coerceIn(0.0, 1.0)
            val s = (t * t * (3 - 2 * t)).toFloat()
            when (style) {
                Style.EQ -> {
                    // 1ª metade: a que entra sobe sem graves; no compasso do meio os graves trocam em 1 batida
                    // (como o DJ gira os dois botões de grave juntos); 2ª metade: a que sai desce, com médios mais baixos
                    val tb = t * beats
                    val swapBeat = (Math.round(beats / 8.0).toInt() * 4).coerceIn(4, maxOf(4, beats - 4)).toDouble()
                    val swap = (tb - swapBeat).coerceIn(0.0, 1.0).toFloat()
                    val up = (tb / swapBeat).coerceIn(0.0, 1.0)
                    val down = ((tb - swapBeat) / (beats - swapBeat).coerceAtLeast(1.0)).coerceIn(0.0, 1.0)
                    val xf = 0.5 * (up * up * (3 - 2 * up)) + 0.5 * (down * down * (3 - 2 * down))
                    vm.setCrossfader(curSide + (nextSide - curSide) * xf.toFloat())
                    vm.setEq(cur, 0, 0.5f - 0.5f * swap)
                    vm.setEq(cur, 1, 0.5f - 0.12f * swap)
                    vm.setEq(other, 0, 0.5f * swap)
                }
                Style.FILTER -> {
                    vm.setCrossfader(curSide + (nextSide - curSide) * s)
                    vm.setFilter(cur, (0.5 + 0.42 * t).toFloat())          // a que sai vai perdendo os graves pelo filtro
                    vm.setEq(other, 0, (0.5 * ((t - 0.4) / 0.3).coerceIn(0.0, 1.0)).toFloat())
                }
                Style.STEMS -> {
                    // a que entra sobe na primeira metade; no meio a voz e o baixo passam de uma para a outra
                    val up = (t / 0.45).coerceIn(0.0, 1.0).toFloat()
                    val swap = ((t - 0.5) / 0.08).coerceIn(0.0, 1.0).toFloat()
                    val out = ((t - 0.6) / 0.4).coerceIn(0.0, 1.0).toFloat()
                    val xf = 0.5f * up + 0.5f * out
                    vm.setCrossfader(curSide + (nextSide - curSide) * xf)
                    vm.setStemGain(cur, 0, 1f - swap)
                    vm.setStemGain(cur, 2, 1f - swap)
                    vm.setStemGain(other, 0, swap)
                    vm.setStemGain(other, 2, swap)
                }
                Style.FADE -> {
                    vm.setCrossfader(curSide + (nextSide - curSide) * t.toFloat())
                    vm.setEq(other, 0, 0.5f)
                }
                Style.NONE -> {
                    vm.setCrossfader(nextSide)
                    vm.setEq(other, 0, 0.5f)
                }
                Style.CUT -> {
                    // corte seco exatamente no tempo forte do compasso
                    vm.setCrossfader(nextSide)
                    vm.setEq(other, 0, 0.5f)
                }
                Style.ECHO -> {
                    val fast = (t / 0.35).coerceIn(0.0, 1.0)
                    vm.setCrossfader(curSide + (nextSide - curSide) * (fast * fast * (3 - 2 * fast)).toFloat())
                    vm.setEq(other, 0, 0.5f)
                }
            }
            if (t >= 1.0) break
            delay(30)
        }
        if (style == Style.ECHO) vm.restoreFx(cur)          // volta o efeito que o DJ tinha escolhido
        if (style == Style.FILTER) vm.setFilter(cur, 0.5f)
        vm.setCrossfader(nextSide)
        NativeEngine.nativePause(cur)
        vm.setSyncLock(other, false)
        if (style == Style.STEMS) vm.stemPreset(cur, 0)   // o deck que saiu volta com todos os stems
        vm.setEq(cur, 0, 0.5f)
        vm.setEq(cur, 1, 0.5f)
        vm.setEq(other, 0, 0.5f)
        delay(400)   // deixa o deck que saiu parar de verdade antes de carregar a próxima faixa nele
        status("Tocando: ${dn.title}")
    }

    /** O andamento volta devagar a 100% (0,5% por segundo), com key-lock ligado (o tom não muda). */
    private suspend fun easeRateToNormal(deck: Int) {
        var guard = 0
        while (guard++ < 400) {
            val d = vm.decks.value[deck]
            val diff = 1f - d.rate
            if (abs(diff) < 0.0015f) {
                if (d.rate != 1f) vm.setRateExact(deck, 1f)
                return
            }
            if (!d.playing || remainingSec(deck) < 40.0) return
            vm.setRateExact(deck, d.rate + diff.coerceIn(-0.0005f, 0.0005f))
            delay(100)
        }
    }

    // ---------------------------------------------------------------- escolha

    private fun firstDeck(): Int {
        val d = vm.decks.value
        return when {
            d[0].playing -> 0
            d[1].playing -> 1
            d[0].loaded -> 0
            d[1].loaded -> 1
            else -> 0
        }
    }

    private fun remainingSec(deck: Int): Double {
        val d = vm.decks.value[deck]
        val pos = vm.live.value.decks[deck].positionFrames
        return (d.lengthFrames - pos).coerceAtLeast(0L) / (NativeEngine.SAMPLE_RATE.toDouble() * d.rate.coerceAtLeast(0.1f))
    }

    private fun remember(id: Long) {
        history.addLast(id)
        while (history.size > 12) history.removeFirst()
    }

    /** O fator (1, 2 ou 1/2) que deixa o andamento da faixa mais perto do alvo, se ficar a menos de 12%. */
    private fun bestMultiple(targetBpm: Double, trackBpm: Double): Double? {
        var best: Double? = null
        var bestErr = 0.12
        for (k in doubleArrayOf(1.0, 2.0, 0.5)) {
            val err = abs(targetBpm / (trackBpm * k) - 1.0)
            if (err < bestErr) { bestErr = err; best = k }
        }
        return best
    }

    private fun chooseNext(cur: Int, library: List<TrackRow>): TrackRow? {
        val dc = vm.decks.value[cur]
        val loaded = vm.decks.value.map { it.trackId }
        val curKey = dc.shownKey
        var best: TrackRow? = null
        var bestScore = Double.MAX_VALUE
        for (c in library) {
            if (c.bpm <= 0.0 || c.id in history || c.id in loaded) continue
            val k = bestMultiple(dc.playedBpm, c.bpm)
            val err = if (k == null) 1.0 else abs(dc.playedBpm / (c.bpm * k) - 1.0)
            // até 6% de diferença o ouvido não estranha; acima disso a música soa esticada
            val bpmPen = if (k == null) 20.0 else err * 30.0 + maxOf(0.0, err - 0.06) * 120.0 + (if (k != 1.0) 1.0 else 0.0)
            val ck = c.key
            val keyPen = if (curKey == null || ck == null) 2.5 else Camelot.distance(curKey, ck) * 2.0
            val target: Float? = when (_energyMode.value) {
                1 -> (0.30f + 0.06f * playedCount).coerceAtMost(0.95f)                            // aquece até o pico
                2 -> 0.55f + 0.30f * kotlin.math.sin(playedCount * 0.9f)                          // ondas: sobe e respira
                3 -> (0.80f - 0.07f * playedCount).coerceAtLeast(0.20f)                           // fim de noite
                else -> null
            }
            val ePen = if (c.energy < 0f) 0.5 else if (target != null) {
                2.0 * abs(c.energy - target)
            } else if (dc.energy >= 0f) {
                val diff = c.energy - dc.energy
                if (diff < -0.15f) 2.0 * -diff else 1.0 * abs(diff - 0.05f)   // prefere manter ou subir um pouco
            } else 0.5
            val score = bpmPen + keyPen + 4.0 * ePen + Random.nextDouble() * 0.5
            if (score < bestScore) { bestScore = score; best = c }
        }
        return best
    }

    private fun keyText(d: DeckUi): String = d.key?.code ?: "tom ?"
    private fun bpmText(d: DeckUi): String = String.format(java.util.Locale.ROOT, "%.0f BPM", d.bpm)
}
