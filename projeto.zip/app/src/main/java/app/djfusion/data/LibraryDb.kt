package app.djfusion.data

import android.content.ContentValues
import android.content.Context
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper
import app.djfusion.harmony.Camelot
import app.djfusion.harmony.MusicalKey

data class TrackRow(
    val id: Long,
    val uri: String,
    val title: String,
    val artist: String,
    val durationMs: Long,
    /** Andamento já detectado (0 = faixa ainda não analisada ou sem andamento claro). */
    val bpm: Double = 0.0,
    /** Tonalidade detectada: nota 0..11 (-1 = desconhecida), modo e confiança. */
    val keyTonic: Int = -1,
    val keyMinor: Boolean = false,
    val keyConf: Float = 0f,
    /** Andamento e tom já foram analisados (mesmo que sem resultado). */
    val analyzed: Boolean = false,
) {
    val key: MusicalKey? get() = if (keyTonic in 0..11 && keyConf >= Camelot.MIN_CONFIDENCE) MusicalKey.of(keyTonic, keyMinor) else null
}

/** Andamento detectado (bpm 0 = não detectado) e posição da primeira batida em quadros. */
data class Analysis(
    val bpm: Double, val firstBeatFrame: Long, val confidence: Float,
    val keyTonic: Int = -1, val keyMinor: Boolean = false, val keyConf: Float = 0f,
)

enum class SortOrder { TITLE, ARTIST, RECENT, BPM, KEY }

/**
 * Biblioteca local da v1: uma tabela com as faixas que o usuário importou.
 * Só guarda o endereço (content://) de arquivos que o usuário escolheu, nunca cópias dos arquivos.
 * Guarda também o andamento detectado e as hot cues de cada faixa. Playlists e tom entram depois, com migração.
 */
class LibraryDb(context: Context) : SQLiteOpenHelper(context, "library.db", null, 3) {

    override fun onCreate(db: SQLiteDatabase) {
        db.execSQL(
            "CREATE TABLE tracks (" +
                "id INTEGER PRIMARY KEY AUTOINCREMENT, " +
                "uri TEXT NOT NULL UNIQUE, " +
                "title TEXT NOT NULL, " +
                "artist TEXT NOT NULL DEFAULT '', " +
                "duration_ms INTEGER NOT NULL, " +
                "created_at INTEGER NOT NULL, " +
                "bpm REAL, first_beat INTEGER, bpm_conf REAL, " +
                "key_tonic INTEGER, key_minor INTEGER, key_conf REAL)",
        )
        db.execSQL("CREATE INDEX idx_tracks_title ON tracks (title)")
        db.execSQL("CREATE INDEX idx_tracks_artist ON tracks (artist)")
        createHotcues(db)
    }

    private fun createHotcues(db: SQLiteDatabase) {
        db.execSQL(
            "CREATE TABLE IF NOT EXISTS hotcues (" +
                "track_id INTEGER NOT NULL, slot INTEGER NOT NULL, frame INTEGER NOT NULL, " +
                "PRIMARY KEY (track_id, slot))",
        )
    }

    override fun onUpgrade(db: SQLiteDatabase, oldVersion: Int, newVersion: Int) {
        if (oldVersion < 2) {
            db.execSQL("ALTER TABLE tracks ADD COLUMN bpm REAL")
            db.execSQL("ALTER TABLE tracks ADD COLUMN first_beat INTEGER")
            db.execSQL("ALTER TABLE tracks ADD COLUMN bpm_conf REAL")
            createHotcues(db)
        }
        if (oldVersion < 3) {
            db.execSQL("ALTER TABLE tracks ADD COLUMN key_tonic INTEGER")
            db.execSQL("ALTER TABLE tracks ADD COLUMN key_minor INTEGER")
            db.execSQL("ALTER TABLE tracks ADD COLUMN key_conf REAL")
        }
    }

    /** Análise já feita desta faixa, ou null se o andamento ainda não foi analisado. A tonalidade pode faltar (-1). */
    fun analysis(trackId: Long): Analysis? {
        readableDatabase.query(
            "tracks", arrayOf("bpm", "first_beat", "bpm_conf", "key_tonic", "key_minor", "key_conf"),
            "id = ? AND bpm IS NOT NULL", arrayOf(trackId.toString()), null, null, null,
        ).use { c ->
            if (c.moveToFirst()) {
                val tonic = if (c.isNull(3)) -1 else c.getInt(3)
                return Analysis(c.getDouble(0), c.getLong(1), c.getFloat(2), tonic, !c.isNull(4) && c.getInt(4) == 1, if (c.isNull(5)) 0f else c.getFloat(5))
            }
        }
        return null
    }

    fun saveAnalysis(trackId: Long, a: Analysis) {
        val values = ContentValues().apply {
            put("bpm", a.bpm)
            put("first_beat", a.firstBeatFrame)
            put("bpm_conf", a.confidence.toDouble())
            if (a.keyTonic >= 0) {
                put("key_tonic", a.keyTonic)
                put("key_minor", if (a.keyMinor) 1 else 0)
                put("key_conf", a.keyConf.toDouble())
            }
        }
        writableDatabase.update("tracks", values, "id = ?", arrayOf(trackId.toString()))
    }

    /** Faixas que ainda não têm andamento ou tonalidade. */
    fun unanalyzed(): List<TrackRow> {
        val out = ArrayList<TrackRow>()
        readableDatabase.query(
            "tracks", arrayOf("id", "uri", "title", "artist", "duration_ms"), "bpm IS NULL OR key_tonic IS NULL",
            null, null, null, "created_at DESC",
        ).use { c ->
            while (c.moveToNext()) out.add(TrackRow(c.getLong(0), c.getString(1), c.getString(2), c.getString(3), c.getLong(4)))
        }
        return out
    }

    /** Dados de análise de uma faixa da biblioteca, para escolher a próxima do AUTO DJ. */
    fun trackInfo(trackId: Long): TrackRow? {
        readableDatabase.query(
            "tracks", arrayOf("id", "uri", "title", "artist", "duration_ms", "bpm", "bpm_conf", "key_tonic", "key_minor", "key_conf"),
            "id = ?", arrayOf(trackId.toString()), null, null, null,
        ).use { c -> if (c.moveToFirst()) return rowOf(c) }
        return null
    }

    private fun rowOf(c: android.database.Cursor): TrackRow {
        val bpm = if (!c.isNull(6) && c.getFloat(6) >= 0.3f) c.getDouble(5) else 0.0
        val tonic = if (c.isNull(7)) -1 else c.getInt(7)
        return TrackRow(
            c.getLong(0), c.getString(1), c.getString(2), c.getString(3), c.getLong(4), bpm,
            tonic, !c.isNull(8) && c.getInt(8) == 1, if (c.isNull(9)) 0f else c.getFloat(9),
            analyzed = !c.isNull(5) && !c.isNull(7),
        )
    }

    /** Hot cues da faixa: posição em quadros de cada uma das 4 posições, -1 quando vazia. */
    fun hotcues(trackId: Long): List<Long> {
        val out = MutableList(4) { -1L }
        readableDatabase.query(
            "hotcues", arrayOf("slot", "frame"), "track_id = ?", arrayOf(trackId.toString()), null, null, null,
        ).use { c ->
            while (c.moveToNext()) {
                val slot = c.getInt(0)
                if (slot in 0..3) out[slot] = c.getLong(1)
            }
        }
        return out
    }

    fun setHotcue(trackId: Long, slot: Int, frame: Long) {
        val values = ContentValues().apply {
            put("track_id", trackId)
            put("slot", slot)
            put("frame", frame)
        }
        writableDatabase.insertWithOnConflict("hotcues", null, values, SQLiteDatabase.CONFLICT_REPLACE)
    }

    fun deleteHotcue(trackId: Long, slot: Int) {
        writableDatabase.delete("hotcues", "track_id = ? AND slot = ?", arrayOf(trackId.toString(), slot.toString()))
    }

    /** Retorna true se a faixa é nova (false se o mesmo arquivo já estava na biblioteca). */
    fun insert(uri: String, title: String, artist: String, durationMs: Long): Boolean {
        // o mesmo arquivo aberto por outro caminho (arquivo solto e depois a pasta) não entra duas vezes
        if (durationMs > 0) {
            readableDatabase.query(
                "tracks", arrayOf("id"), "title = ? AND artist = ? AND ABS(duration_ms - ?) < 1000",
                arrayOf(title, artist, durationMs.toString()), null, null, null,
            ).use { if (it.moveToFirst()) return false }
        }
        val values = ContentValues().apply {
            put("uri", uri)
            put("title", title)
            put("artist", artist)
            put("duration_ms", durationMs)
            put("created_at", System.currentTimeMillis())
        }
        return writableDatabase.insertWithOnConflict("tracks", null, values, SQLiteDatabase.CONFLICT_IGNORE) != -1L
    }

    fun delete(id: Long) {
        writableDatabase.delete("hotcues", "track_id = ?", arrayOf(id.toString()))
        writableDatabase.delete("tracks", "id = ?", arrayOf(id.toString()))
    }

    fun query(search: String, sort: SortOrder): List<TrackRow> {
        val q = search.trim()
        val where: String?
        val args: Array<String>?
        if (q.isEmpty()) {
            where = null
            args = null
        } else {
            val like = "%" + q.replace("\\", "\\\\").replace("%", "\\%").replace("_", "\\_") + "%"
            where = "title LIKE ? ESCAPE '\\' OR artist LIKE ? ESCAPE '\\'"
            args = arrayOf(like, like)
        }
        val order = when (sort) {
            SortOrder.TITLE -> "title COLLATE NOCASE ASC, id ASC"
            SortOrder.ARTIST -> "artist COLLATE NOCASE ASC, title COLLATE NOCASE ASC, id ASC"
            SortOrder.RECENT -> "created_at DESC, id DESC"
            SortOrder.BPM -> "(IFNULL(bpm, 0) <= 0 OR IFNULL(bpm_conf, 0) < 0.3) ASC, IFNULL(bpm, 0) ASC, title COLLATE NOCASE ASC"
            SortOrder.KEY -> "created_at DESC, id DESC"   // a ordem pela Roda de Camelot é feita abaixo
        }
        val out = ArrayList<TrackRow>()
        readableDatabase.query(
            "tracks", arrayOf("id", "uri", "title", "artist", "duration_ms", "bpm", "bpm_conf", "key_tonic", "key_minor", "key_conf"),
            where, args, null, null, order,
        ).use { c ->
            while (c.moveToNext()) out.add(rowOf(c))
        }
        if (sort == SortOrder.KEY) {
            // pela roda: 1A, 1B, 2A, 2B ... ; sem tom por último
            return out.sortedWith(
                compareBy<TrackRow> { it.key == null }
                    .thenBy { it.key?.number ?: 0 }
                    .thenBy { it.key?.minor == false }
                    .thenBy { it.bpm },
            )
        }
        return out
    }
}
