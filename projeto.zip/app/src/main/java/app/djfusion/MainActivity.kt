package app.djfusion

import android.os.Bundle
import android.view.WindowManager
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.displayCutout
import androidx.compose.foundation.layout.mandatorySystemGestures
import androidx.activity.viewModels
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.WindowInsetsControllerCompat
import app.djfusion.ui.AppRoot
import app.djfusion.ui.AppViewModel
import app.djfusion.ui.theme.DjFusionTheme
import com.google.android.play.core.appupdate.AppUpdateManagerFactory
import com.google.android.play.core.appupdate.AppUpdateOptions
import com.google.android.play.core.install.InstallStateUpdatedListener
import com.google.android.play.core.install.model.AppUpdateType
import com.google.android.play.core.install.model.InstallStatus
import com.google.android.play.core.install.model.UpdateAvailability

/** Tamanho de referência do console (dp). */
private const val DESIGN_W = 986f
private const val DESIGN_H = 443f
/** Margem embaixo (dp) livre da faixa de gestos do sistema. */
private const val BOTTOM_SAFE = 22f

class MainActivity : ComponentActivity() {
    private val viewModel: AppViewModel by viewModels()

    /** Janela do Android que pede a permissão do microfone (só quando o usuário liga o MIC). */
    private val micPermission = registerForActivityResult(androidx.activity.result.contract.ActivityResultContracts.RequestPermission()) { granted ->
        viewModel.onMicPermission(granted)
    }

    /** Atualização pela Play Store (só funciona quando o app foi instalado por ela). */
    private val updates by lazy { AppUpdateManagerFactory.create(this) }
    private val updateListener = InstallStateUpdatedListener { st ->
        when (st.installStatus()) {
            InstallStatus.DOWNLOADING -> viewModel.setUpdateStatus("Baixando a versão nova…")
            InstallStatus.DOWNLOADED -> {
                viewModel.setUpdateStatus("Versão nova baixada. Instale em AJUSTES › SOBRE quando a música estiver parada.", ready = true)
                viewModel.say("Versão nova do app baixada: instale em AJUSTES › SOBRE quando parar de tocar.")
            }
            InstallStatus.FAILED -> viewModel.setUpdateStatus("A atualização falhou; tente de novo mais tarde.", ready = false)
            else -> {}
        }
    }

    private fun checkPlayUpdate(manual: Boolean) {
        runCatching {
            updates.appUpdateInfo.addOnSuccessListener { info ->
                when {
                    info.installStatus() == InstallStatus.DOWNLOADED ->
                        viewModel.setUpdateStatus("Versão nova baixada. Instale quando a música estiver parada.", ready = true)
                    info.updateAvailability() == UpdateAvailability.UPDATE_AVAILABLE && info.isUpdateTypeAllowed(AppUpdateType.FLEXIBLE) -> {
                        viewModel.setUpdateStatus("Versão nova disponível (${info.availableVersionCode()}): baixando…")
                        runCatching {
                            updates.startUpdateFlowForResult(info, this, AppUpdateOptions.newBuilder(AppUpdateType.FLEXIBLE).build(), 4242)
                        }.onFailure { ErrorLog.add("atualização", "não abriu a tela da Play Store", it) }
                    }
                    manual -> viewModel.setUpdateStatus("Você já tem a versão mais nova.")
                }
            }.addOnFailureListener { e ->
                // instalado fora da Play Store (APK), sem conta Google ou sem internet: segue normal
                if (manual) viewModel.setUpdateStatus("Não deu para consultar a Play Store (app instalado por arquivo ou sem internet).")
                ErrorLog.add("atualização", "consulta à Play Store", e)
            }
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        ErrorLog.installCrashHandler(this)
        super.onCreate(savedInstanceState)
        runCatching { updates.registerListener(updateListener) }
        viewModel.updateChecker = { checkPlayUpdate(manual = true) }
        viewModel.micPermissionRequester = { micPermission.launch(android.Manifest.permission.RECORD_AUDIO) }
        viewModel.updateInstaller = { runCatching { updates.completeUpdate() } }
        if (savedInstanceState == null) checkPlayUpdate(manual = false)
        // Tela cheia: barras do sistema escondidas (aparecem com um deslize na borda).
        WindowCompat.setDecorFitsSystemWindows(window, false)
        WindowInsetsControllerCompat(window, window.decorView).apply {
            hide(WindowInsetsCompat.Type.systemBars())
            systemBarsBehavior = WindowInsetsControllerCompat.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
        }
        // Modo retrato (AJUSTES): a tela gira com o celular; senão fica deitada.
        requestedOrientation = if (getSharedPreferences("output", MODE_PRIVATE).getBoolean("portrait", false))
            android.content.pm.ActivityInfo.SCREEN_ORIENTATION_FULL_USER else android.content.pm.ActivityInfo.SCREEN_ORIENTATION_SENSOR_LANDSCAPE
        // Em cabine de DJ a tela não pode apagar no meio de um set.
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)

        setContent {
            DjFusionTheme {
                // A tela é um console de tamanho fixo (986 × 443 dp, como no celular com tamanho de tela padrão).
                // Se o usuário aumentar "Tamanho da exibição" ou a fonte do sistema, o layout cortaria botões:
                // aqui a escala é ajustada para o console caber inteiro em qualquer tela, sem cortar nada.
                androidx.compose.foundation.layout.BoxWithConstraints(androidx.compose.ui.Modifier.fillMaxSize()) {
                    val sys = androidx.compose.ui.platform.LocalDensity.current
                    val cut = WindowInsets.displayCutout
                    val cutPx = cut.getLeft(sys, androidx.compose.ui.unit.LayoutDirection.Ltr) + cut.getRight(sys, androidx.compose.ui.unit.LayoutDirection.Ltr)
                    val wPx = (constraints.maxWidth - cutPx).toFloat()
                    val hPx = constraints.maxHeight.toFloat()
                    // faixa de gestos do sistema embaixo (navegação por gestos): o app não desenha botões ali,
                    // senão um toque demorado no CUE/PLAY pode abrir "apps recentes"
                    val cutV = cut.getTop(sys) + cut.getBottom(sys)
                    // em pé (retrato) o console de referência gira: 443 × 986 dp
                    val portrait = hPx > wPx
                    val fit = when {
                        wPx <= 0f || hPx <= 0f -> sys.density
                        portrait -> minOf(wPx / DESIGN_H, (hPx - cutV) / (DESIGN_W + BOTTOM_SAFE))
                        else -> minOf(wPx / DESIGN_W, hPx / (DESIGN_H + BOTTOM_SAFE))
                    }
                    androidx.compose.runtime.CompositionLocalProvider(
                        androidx.compose.ui.platform.LocalDensity provides androidx.compose.ui.unit.Density(fit, 1f),
                    ) {
                        AppRoot(viewModel)
                    }
                }
            }
        }
    }

    /** Atalhos de teclado (teclado Bluetooth/USB). Teclas F não atrapalham quem está digitando na busca. */
    override fun dispatchKeyEvent(event: android.view.KeyEvent): Boolean {
        if (viewModel.keyShortcut(event.keyCode, event.action == android.view.KeyEvent.ACTION_DOWN, event.repeatCount)) return true
        return super.dispatchKeyEvent(event)
    }

    override fun onStart() {
        super.onStart()
        viewModel.onForeground(true)
    }

    override fun onStop() {
        viewModel.onForeground(false)
        super.onStop()
    }

    override fun onDestroy() {
        runCatching { updates.unregisterListener(updateListener) }
        viewModel.updateChecker = null
        viewModel.updateInstaller = null
        super.onDestroy()
    }
}
