package app.djfusion.audio

import ai.onnxruntime.OnnxTensor
import ai.onnxruntime.OrtEnvironment
import ai.onnxruntime.OrtSession
import android.content.Context
import java.io.File
import java.net.HttpURLConnection
import java.net.URL
import java.nio.FloatBuffer
import java.util.concurrent.atomic.AtomicBoolean

/**
 * Stems com rede neural: Spleeter de 4 stems (Deezer), uma rede U-Net por stem, em formato ONNX, rodando no próprio
 * aparelho (ONNX Runtime). O modelo (~80 MB) é baixado uma vez, dentro do app, e fica guardado; sem ele (ou se algo
 * falhar) o app usa o separador por processamento de sinal. A parte de sinal está em [SpleeterCore].
 */
object NeuralStems {
    private val NAMES = listOf("vocals", "drums", "bass", "other")
    private const val BASE = "https://huggingface.co/Best-Practice/spleeter-4stems-onnx/resolve/main/"
    private const val MIN_BYTES = 15_000_000L
    private const val MAX_BYTES = 60_000_000L

    fun modelDir(ctx: Context) = File(ctx.filesDir, "modelos/spleeter4")
    private fun file(ctx: Context, name: String) = File(modelDir(ctx), "$name.fp16.onnx")

    fun isReady(ctx: Context): Boolean = NAMES.all { file(ctx, it).let { f -> f.isFile && f.length() in MIN_BYTES..MAX_BYTES } }

    fun modelBytes(ctx: Context): Long = NAMES.sumOf { file(ctx, it).let { f -> if (f.isFile) f.length() else 0L } }

    fun delete(ctx: Context) {
        modelDir(ctx).deleteRecursively()
    }

    /** Baixa e confere os 4 arquivos. Devolve null se deu certo, ou o motivo da falha. Bloqueia: chame fora da thread principal. */
    fun download(ctx: Context, onProgress: (Float) -> Unit): String? {
        val dir = modelDir(ctx)
        try {
            dir.mkdirs()
            for ((i, name) in NAMES.withIndex()) {
                val dest = file(ctx, name)
                if (dest.isFile && dest.length() in MIN_BYTES..MAX_BYTES) { onProgress((i + 1f) / NAMES.size); continue }
                val part = File(dir, "$name.fp16.onnx.part")
                val c = URL("$BASE$name.fp16.onnx").openConnection() as HttpURLConnection
                c.connectTimeout = 20_000
                c.readTimeout = 30_000
                c.instanceFollowRedirects = true
                c.setRequestProperty("User-Agent", "EdgardGuardaDJStudio")
                if (c.responseCode != 200) return "servidor respondeu ${c.responseCode} ao baixar $name"
                val total = c.contentLengthLong.takeIf { it > 0 } ?: 20_000_000L
                var done = 0L
                c.inputStream.use { ins ->
                    part.outputStream().use { outs ->
                        val buf = ByteArray(64 * 1024)
                        while (true) {
                            val n = ins.read(buf)
                            if (n < 0) break
                            outs.write(buf, 0, n)
                            done += n
                            onProgress((i + (done.toFloat() / total).coerceAtMost(1f)) / NAMES.size)
                        }
                    }
                }
                c.disconnect()
                if (part.length() !in MIN_BYTES..MAX_BYTES) { part.delete(); return "arquivo $name veio incompleto (${part.length()} bytes)" }
                if (!part.renameTo(dest)) { part.delete(); return "não consegui gravar $name" }
            }
            // confere que o Android consegue abrir os quatro modelos
            val env = OrtEnvironment.getEnvironment()
            for (name in NAMES) env.createSession(file(ctx, name).absolutePath).close()
            return null
        } catch (t: Throwable) {
            delete(ctx)
            return "falha ao baixar ou abrir o modelo: ${t.javaClass.simpleName} ${t.message ?: ""}".trim()
        }
    }

    // ------------------------------------------------------------------ separar uma faixa

    private val progressDeck = FloatArray(2) { -1f }
    private val cancelDeck = arrayOf(AtomicBoolean(false), AtomicBoolean(false))
    private val usedAi = BooleanArray(2)
    @Volatile var lastError: String? = null
        private set

    /** Preenchido pelo app: verdadeiro quando algum deck está tocando (a separação então usa menos processador, para o som não falhar). */
    @Volatile var deckPlaying: () -> Boolean = { false }

    /** Progresso de 0 a 1 da separação por IA neste deck, ou -1 se não está separando por IA. */
    fun progress(deck: Int): Float = if (deck in 0..1) progressDeck[deck] else -1f
    fun cancel(deck: Int) { if (deck in 0..1) cancelDeck[deck].set(true) }
    fun wasCancelled(deck: Int): Boolean = deck in 0..1 && cancelDeck[deck].get()
    /** A última separação deste deck foi feita pela rede neural? */
    fun lastUsedAi(deck: Int): Boolean = deck in 0..1 && usedAi[deck]

    private class OrtNet(files: List<File>) : SpleeterCore.Net, AutoCloseable {
        private val env = OrtEnvironment.getEnvironment()
        private val opts = OrtSession.SessionOptions().apply {
            // tocando ao vivo: só 2 fios, para sobrar processador ao som e ao carregamento do outro deck
            setIntraOpNumThreads(if (deckPlaying()) 2 else Runtime.getRuntime().availableProcessors().coerceIn(2, 4))
            // devolve a memória depois de cada passo (quatro redes ao mesmo tempo); por reflexão para não depender da versão da biblioteca
            runCatching { javaClass.getMethod("setCPUArenaAllocator", java.lang.Boolean.TYPE).invoke(this, false) }
        }
        private val sessions = files.map { env.createSession(it.absolutePath, opts) }
        private val inputNames = sessions.map { it.inputNames.first() }

        override fun run(input: FloatArray, out: Array<FloatArray>) {
            val t0 = android.os.SystemClock.uptimeMillis()
            runOnce(input, out)
            // tocando ao vivo: respira entre os blocos (a separação fica ~40% mais lenta, mas não disputa o processador com o áudio)
            if (deckPlaying()) { val dt = android.os.SystemClock.uptimeMillis() - t0; if (dt > 0) Thread.sleep((dt * 4 / 10).coerceAtMost(500)) }
        }

        private fun runOnce(input: FloatArray, out: Array<FloatArray>) {
            OnnxTensor.createTensor(env, FloatBuffer.wrap(input), longArrayOf(2, 1, SpleeterCore.FR.toLong(), SpleeterCore.BINS.toLong())).use { t ->
                for (k in sessions.indices) {
                    sessions[k].run(mapOf(inputNames[k] to t)).use { r ->
                        (r[0] as OnnxTensor).floatBuffer.get(out[k], 0, out[k].size)
                    }
                }
            }
        }

        override fun close() {
            sessions.forEach { runCatching { it.close() } }
            runCatching { opts.close() }
        }
    }

    /** Separa um trecho de áudio estéreo que está na memória (usado no teste). Devolve voz, bateria, baixo mono, 3 valores por quadro. */
    fun separatePcm(ctx: Context, pcm: ShortArray, rate: Int): ShortArray? {
        if (!isReady(ctx)) return null
        val frames = pcm.size / 2L
        val out = ShortArray((frames * 3).toInt())
        OrtNet(NAMES.map { file(ctx, it) }).use { net ->
            val ok = SpleeterCore.separate(
                SpleeterCore.Source { start, count, o ->
                    for (i in 0 until count) {
                        val p = start + i
                        for (c in 0..1) o[2 * i + c] = if (p in 0 until frames) pcm[(2 * p + c).toInt()] else 0
                    }
                },
                frames, rate, net,
                SpleeterCore.Sink { start, count, d -> System.arraycopy(d, 0, out, (start * 3).toInt(), count * 3) },
                null,
            )
            return if (ok) out else null
        }
    }

    /**
     * Separa a faixa com a rede neural e grava os stems no motor (mono: voz, bateria, baixo; a melodia é o que sobra).
     * Bloqueia. Devolve false se não deu (sem modelo, cancelado ou erro: veja [lastError]); o chamador usa então o outro separador.
     */
    fun separate(ctx: Context, handle: Long, deck: Int): Boolean {
        if (deck !in 0..1 || !isReady(ctx)) return false
        cancelDeck[deck].set(false)
        usedAi[deck] = false
        lastError = null
        progressDeck[deck] = 0f
        var net: OrtNet? = null
        try {
            val frames = NativeEngine.nativeTrackFrames(handle)
            if (frames <= 0 || !NativeEngine.nativeStemBegin(handle)) return false
            net = OrtNet(NAMES.map { file(ctx, it) })
            val ctl = object : SpleeterCore.Control {
                override fun cancelled() = cancelDeck[deck].get()
                override fun progress(p: Float) { progressDeck[deck] = p.coerceIn(0f, 1f) }
            }
            val ok = SpleeterCore.separate(
                SpleeterCore.Source { start, count, out -> NativeEngine.nativeTrackPcm(handle, start, count, out) },
                frames, NativeEngine.SAMPLE_RATE, net,
                SpleeterCore.Sink { start, count, data -> NativeEngine.nativeStemWrite(handle, start, count, data) },
                ctl,
            )
            if (ok) { NativeEngine.nativeStemEnd(handle); usedAi[deck] = true }
            return ok
        } catch (t: Throwable) {
            lastError = "${t.javaClass.simpleName} ${t.message ?: ""}".trim()
            app.djfusion.ErrorLog.add("Stems IA", "Stems por IA falharam: $lastError")
            return false
        } finally {
            runCatching { net?.close() }
            progressDeck[deck] = -1f
        }
    }
}
