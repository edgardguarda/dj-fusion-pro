package app.djfusion.audio

import android.content.Context
import android.media.AudioDeviceCallback
import android.media.AudioDeviceInfo
import android.media.AudioManager
import android.os.Handler
import android.os.Looper
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow

/** Uma saída de áudio USB (por exemplo, a placa de som da DJ2GO2). */
data class UsbOut(val id: Int, val name: String, val channels: Int)

/** Acompanha as saídas de áudio USB conectadas e avisa quando uma entra ou sai. */
class OutputRouter(ctx: Context, private val onChange: () -> Unit) {
    private val am = ctx.getSystemService(Context.AUDIO_SERVICE) as AudioManager
    private val _devices = MutableStateFlow<List<UsbOut>>(emptyList())
    val devices: StateFlow<List<UsbOut>> = _devices

    private val callback = object : AudioDeviceCallback() {
        override fun onAudioDevicesAdded(addedDevices: Array<out AudioDeviceInfo>?) = refresh()
        override fun onAudioDevicesRemoved(removedDevices: Array<out AudioDeviceInfo>?) = refresh()
    }

    fun start() {
        refresh()
        am.registerAudioDeviceCallback(callback, Handler(Looper.getMainLooper()))
    }

    fun stop() {
        am.unregisterAudioDeviceCallback(callback)
    }

    private fun refresh() {
        val list = am.getDevices(AudioManager.GET_DEVICES_OUTPUTS)
            .filter { it.type == AudioDeviceInfo.TYPE_USB_DEVICE || it.type == AudioDeviceInfo.TYPE_USB_HEADSET }
            .map { UsbOut(it.id, it.productName?.toString().orEmpty().ifBlank { "Placa de som USB" }, it.channelCounts.maxOrNull() ?: 2) }
        if (list != _devices.value) {
            _devices.value = list
            onChange()
        }
    }
}
