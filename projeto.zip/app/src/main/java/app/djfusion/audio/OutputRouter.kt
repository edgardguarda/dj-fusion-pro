package app.djfusion.audio

import android.content.Context
import android.media.AudioDeviceCallback
import android.media.AudioDeviceInfo
import android.media.AudioManager
import android.os.Handler
import android.os.Looper
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow

/** Uma saída de áudio: a controladora (USB) ou do próprio celular (alto-falante, fone com fio, Bluetooth). */
data class AudioOut(val id: Int, val name: String, val kind: Kind, val channels: Int) {
    enum class Kind { USB, SPEAKER, WIRED, BLUETOOTH }
    val isUsb: Boolean get() = kind == Kind.USB
    val label: String get() = when (kind) {
        Kind.USB -> "CONTROLADORA · $name"
        Kind.SPEAKER -> "ALTO-FALANTE DO CELULAR"
        Kind.WIRED -> "FONE COM FIO DO CELULAR"
        Kind.BLUETOOTH -> "BLUETOOTH · $name"
    }
}

/** Acompanha as saídas de áudio do aparelho e avisa quando uma entra ou sai. */
class OutputRouter(ctx: Context, private val onChange: () -> Unit) {
    private val am = ctx.getSystemService(Context.AUDIO_SERVICE) as AudioManager
    private val _devices = MutableStateFlow<List<AudioOut>>(emptyList())
    val devices: StateFlow<List<AudioOut>> = _devices

    private val callback = object : AudioDeviceCallback() {
        override fun onAudioDevicesAdded(addedDevices: Array<out AudioDeviceInfo>?) = refresh()
        override fun onAudioDevicesRemoved(removedDevices: Array<out AudioDeviceInfo>?) = refresh()
    }

    fun start() {
        refresh()
        am.registerAudioDeviceCallback(callback, Handler(Looper.getMainLooper()))
    }

    fun stop() {
        am.unregisterAudioDeviceCallback(callback)
    }

    /** Lista para o relatório de diagnóstico: todas as saídas que o Android informa. */
    fun describeAll(): String = am.getDevices(AudioManager.GET_DEVICES_OUTPUTS).joinToString("\n") {
        "  id=${it.id} tipo=${it.type} nome=${it.productName} canais=${it.channelCounts.joinToString("/")} taxas=${it.sampleRates.joinToString("/")}"
    }

    private fun kindOf(t: Int): AudioOut.Kind? = when (t) {
        AudioDeviceInfo.TYPE_USB_DEVICE, AudioDeviceInfo.TYPE_USB_HEADSET -> AudioOut.Kind.USB
        AudioDeviceInfo.TYPE_BUILTIN_SPEAKER -> AudioOut.Kind.SPEAKER
        AudioDeviceInfo.TYPE_WIRED_HEADSET, AudioDeviceInfo.TYPE_WIRED_HEADPHONES -> AudioOut.Kind.WIRED
        AudioDeviceInfo.TYPE_BLUETOOTH_A2DP -> AudioOut.Kind.BLUETOOTH
        else -> null
    }

    private fun refresh() {
        val list = am.getDevices(AudioManager.GET_DEVICES_OUTPUTS)
            .mapNotNull { d ->
                val k = kindOf(d.type) ?: return@mapNotNull null
                AudioOut(d.id, d.productName?.toString().orEmpty().ifBlank { if (k == AudioOut.Kind.USB) "Placa USB" else "" }, k, d.channelCounts.maxOrNull() ?: 2)
            }
            .distinctBy { it.id }
            .sortedBy { it.kind.ordinal }
        if (list != _devices.value) {
            _devices.value = list
            onChange()
        }
    }
}
