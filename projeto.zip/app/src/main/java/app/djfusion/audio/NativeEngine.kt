package app.djfusion.audio

import java.nio.ByteBuffer

/**
 * Ponte para o motor C++ (libdjfusion.so). Os nomes e tipos daqui precisam ser idênticos aos de
 * app/src/main/cpp/native_bridge.cpp. O teste tests/jni/JniSmoke.java confere essa ponte.
 */
object NativeEngine {
    init {
        System.loadLibrary("djfusion")
    }

    /** Todas as faixas são decodificadas nesta taxa. */
    const val SAMPLE_RATE = 48_000
    const val PEAKS_PER_SECOND = 150
    const val MAX_TRACK_SECONDS = 15 * 60

    // saída de áudio
    @JvmStatic external fun nativeStart(): Boolean
    @JvmStatic external fun nativeStop()
    /** [taxa real, quadros por rajada, tamanho do buffer em quadros, 1 se exclusivo, canais, modo efetivo do fone] */
    @JvmStatic external fun nativeStreamInfo(out: IntArray)
    /** mode: 0 só geral, 1 dividido (E fone / D geral), 2 quatro canais. deviceId: 0 = padrão do Android. */
    @JvmStatic external fun nativeConfigureOutput(mode: Int, deviceId: Int)

    // construção de faixas
    @JvmStatic external fun nativeBeginTrack(srcRate: Int, maxFrames: Long): Long
    @JvmStatic external fun nativeAppend(
        handle: Long, buffer: ByteBuffer, offset: Int, size: Int, channels: Int, isFloat: Boolean,
    )
    @JvmStatic external fun nativeBuilderTooLong(handle: Long): Boolean
    /** 0 = vazia, -1 = longa demais, senão o identificador da faixa pronta. */
    @JvmStatic external fun nativeFinishTrack(handle: Long): Long
    @JvmStatic external fun nativeAbortTrack(handle: Long)
    @JvmStatic external fun nativeTrackFrames(track: Long): Long
    @JvmStatic external fun nativeTrackPeaks(track: Long): ByteArray
    @JvmStatic external fun nativeFreeTrack(track: Long)

    // decks
    @JvmStatic external fun nativeLoad(deck: Int, track: Long): Boolean
    @JvmStatic external fun nativeUnload(deck: Int)
    @JvmStatic external fun nativePlay(deck: Int)
    @JvmStatic external fun nativePause(deck: Int)
    @JvmStatic external fun nativeCue(deck: Int)
    @JvmStatic external fun nativeSeek(deck: Int, frame: Long)
    @JvmStatic external fun nativeSetVolume(deck: Int, volume: Float)
    @JvmStatic external fun nativeSetCrossfader(x: Float)
    @JvmStatic external fun nativeSetMaster(volume: Float)
    /** Velocidade de reprodução, 1 = normal (muda o tom junto). */
    @JvmStatic external fun nativeSetRate(deck: Int, rate: Float)
    /** band: 0 graves, 1 médios, 2 agudos. 0,5 = neutro. */
    @JvmStatic external fun nativeSetEq(deck: Int, band: Int, value: Float)
    /** 0,5 = desligado, abaixo = passa-baixas, acima = passa-altas. */
    @JvmStatic external fun nativeSetKeyLock(deck: Int, on: Boolean)
    /** Prato tocado: `velocity` em múltiplos da velocidade normal (negativo = para trás). */
    @JvmStatic external fun nativeScratch(deck: Int, active: Boolean, velocity: Float)
    @JvmStatic external fun nativeSetHeadphoneCue(deck: Int, on: Boolean)
    @JvmStatic external fun nativeSetHeadphoneLevel(value: Float)
    @JvmStatic external fun nativeSetHeadphoneMix(value: Float)
    @JvmStatic external fun nativeSetFilter(deck: Int, value: Float)
    @JvmStatic external fun nativeSetFx(deck: Int, type: Int, amount: Float, beatSeconds: Float)
    @JvmStatic external fun nativeSetLoop(deck: Int, start: Long, end: Long)
    @JvmStatic external fun nativeClearLoop(deck: Int)
    /** out = [bpm (0 = não detectado), primeira batida em quadros, confiança 0 a 1]. */
    @JvmStatic external fun nativeAnalyze(track: Long, out: DoubleArray)

    /** out = [válida 0/1, nota 0..11 (0 = Dó), 1 se menor, confiança x 1000]. */
    @JvmStatic external fun nativeAnalyzeKey(track: Long, out: IntArray)
    /** Carrega até 4 trechos da faixa do deck nos pads slotBase.. e devolve quantos. info = 4 x [tipo, quadros, loop 0/1]. */
    @JvmStatic external fun nativeBuildSamples(deck: Int, bpm: Double, firstBeat: Long, slotBase: Int, info: LongArray): Int
    @JvmStatic external fun nativeClearSamples()
    @JvmStatic external fun nativeTriggerSample(slot: Int, loop: Boolean)
    @JvmStatic external fun nativeStopSample(slot: Int)
    @JvmStatic external fun nativeSetSamplerVolume(value: Float)
    /** Bits dos pads que estão soando. */
    @JvmStatic external fun nativeSamplerMask(): Int
    /** Toca com a batida alinhada à do deck de referência (alinha na thread de áudio). */
    @JvmStatic external fun nativePlaySynced(
        deck: Int, refDeck: Int, refFirstBeat: Double, refBeatFrames: Double,
        firstBeat: Double, beatFrames: Double, startBeat: Double,
    )

    /** [bit0 carregada | bit1 tocando, posição, cue, tamanho], em quadros. */
    @JvmStatic external fun nativeDeckState(deck: Int, out: LongArray)
    @JvmStatic external fun nativeDeckPeak(deck: Int): Float
    @JvmStatic external fun nativeMasterPeak(): Float
    @JvmStatic external fun nativeCollectGarbage()
}
