package app.djfusion.audio

import java.nio.ByteBuffer

/**
 * Ponte para o motor C++ (libdjfusion.so). Os nomes e tipos daqui precisam ser idênticos aos de
 * app/src/main/cpp/native_bridge.cpp. O teste tests/jni/JniSmoke.java confere essa ponte.
 */
object NativeEngine {
    init {
        System.loadLibrary("djfusion")
    }

    /** Todas as faixas são decodificadas nesta taxa. */
    const val SAMPLE_RATE = 48_000
    const val PEAKS_PER_SECOND = 150
    /**
     * Duração máxima de uma faixa, em segundos. Definida ao abrir o app conforme a memória do aparelho
     * (cerca de 8% da memória total por faixa; 15 a 120 minutos). Faixas curtas não reservam nada a mais.
     */
    @JvmStatic @Volatile var MAX_TRACK_SECONDS: Int = 15 * 60

    // saída de áudio
    @JvmStatic external fun nativeStart(): Boolean
    @JvmStatic external fun nativeStop()
    /** Contador de pedidos de som da saída (parado = saída travada/sumiu). */
    @JvmStatic external fun nativeAudioCallbacks(): Int
    @JvmStatic external fun nativeSetMaxTrackSeconds(seconds: Int)
    /** Fecha e reabre a saída de áudio. */
    @JvmStatic external fun nativeRestartAudio()
    /** Só para o teste automático: derruba a saída como se a controladora USB fosse tirada. */
    @JvmStatic external fun nativeDebugKillStream()
    /** Latência da saída: 0 baixa, 1 normal, 2 segura. */
    @JvmStatic external fun nativeSetLatency(mode: Int)
    /** [taxa real, quadros por rajada, tamanho do buffer em quadros, 1 se exclusivo, canais, modo efetivo do fone] */
    @JvmStatic external fun nativeStreamInfo(out: IntArray)
    /** mode: 0 só geral, 1 dividido (E fone / D geral), 2 quatro canais. deviceId: 0 = padrão do Android. */
    @JvmStatic external fun nativeConfigureOutput(mode: Int, deviceId: Int, mirrorDevice: Int, mirrorWhat: Int)

    // construção de faixas
    @JvmStatic external fun nativeBeginTrack(srcRate: Int, maxFrames: Long): Long
    @JvmStatic external fun nativeAppend(
        handle: Long, buffer: ByteBuffer, offset: Int, size: Int, channels: Int, isFloat: Boolean,
    )
    @JvmStatic external fun nativeBuilderTooLong(handle: Long): Boolean
    /** 0 = vazia, -1 = longa demais, senão o identificador da faixa pronta. */
    @JvmStatic external fun nativeFinishTrack(handle: Long): Long
    /** Decodificador próprio (MP3=1, FLAC=2, WAV=3) lendo do descritor [fd]. > 0 faixa, 0 falhou, -1 longa demais. */
    @JvmStatic external fun nativeDecodeFd(fd: Int, kind: Int, fileSize: Long, slot: Int): Long
    @JvmStatic external fun nativeDecodeError(slot: Int): String
    @JvmStatic external fun nativeDecodeProgress(slot: Int): Float
    @JvmStatic external fun nativeAbortTrack(handle: Long)
    @JvmStatic external fun nativeTrackFrames(track: Long): Long
    @JvmStatic external fun nativeTrackPeaks(track: Long): ByteArray
    @JvmStatic external fun nativeFreeTrack(track: Long)

    // decks
    @JvmStatic external fun nativeLoad(deck: Int, track: Long): Boolean
    @JvmStatic external fun nativeUnload(deck: Int)
    @JvmStatic external fun nativePlay(deck: Int)
    @JvmStatic external fun nativePause(deck: Int)
    @JvmStatic external fun nativeCue(deck: Int)
    @JvmStatic external fun nativeSeek(deck: Int, frame: Long)
    @JvmStatic external fun nativeSetVolume(deck: Int, volume: Float)
    @JvmStatic external fun nativeSetCrossfader(x: Float)
    @JvmStatic external fun nativeSetMaster(volume: Float)
    /** Velocidade de reprodução, 1 = normal (muda o tom junto). */
    @JvmStatic external fun nativeSetRate(deck: Int, rate: Float)
    /** band: 0 graves, 1 médios, 2 agudos. 0,5 = neutro. */
    @JvmStatic external fun nativeSetEq(deck: Int, band: Int, value: Float)
    /** 0,5 = desligado, abaixo = passa-baixas, acima = passa-altas. */
    @JvmStatic external fun nativeSetKeyLock(deck: Int, on: Boolean)
    /** Prato tocado: `velocity` em múltiplos da velocidade normal (negativo = para trás). */
    @JvmStatic external fun nativeScratch(deck: Int, active: Boolean, velocity: Float)
    @JvmStatic external fun nativeSetHeadphoneCue(deck: Int, on: Boolean)
    @JvmStatic external fun nativeSetHeadphoneLevel(value: Float)
    @JvmStatic external fun nativeSetHeadphoneMix(value: Float)
    @JvmStatic external fun nativeSetFilter(deck: Int, value: Float)
    /** [type] = efeito + 16 × encaixe (0..2): até 3 efeitos ao mesmo tempo por deck. */
    @JvmStatic external fun nativeSetFx(deck: Int, type: Int, amount: Float, beatSeconds: Float)
    @JvmStatic external fun nativeSetCrossfaderCurve(curve: Int)
    /** Scratch por posição: o prato da controladora girou [frames] quadros (+ frente, - trás). */
    @JvmStatic external fun nativeScratchMove(deck: Int, frames: Double)
    /** Empurrão do prato com a música tocando: adianta (+) ou atrasa (-) [frames] quadros. */
    @JvmStatic external fun nativeNudge(deck: Int, frames: Double)
    @JvmStatic external fun nativeSetLoop(deck: Int, start: Long, end: Long)
    @JvmStatic external fun nativeClearLoop(deck: Int)
    /** out = [bpm (0 = não detectado), primeira batida em quadros, confiança 0 a 1]. */
    @JvmStatic external fun nativeAnalyze(track: Long, out: DoubleArray)
    /** Mapa de andamento: [variável 0/1, desvio %, n, depois n x (início em quadros, bpm, uma batida)]. */
    @JvmStatic external fun nativeTempoMap(track: Long, bpm: Double, firstBeat: Long, out: DoubleArray)

    /** out = [válida 0/1, nota 0..11 (0 = Dó), 1 se menor, confiança x 1000]. */
    @JvmStatic external fun nativeAnalyzeKey(track: Long, out: IntArray)
    /** Carrega até 4 trechos da faixa do deck nos pads slotBase.. e devolve quantos. info = 4 x [tipo, quadros, loop 0/1]. */
    @JvmStatic external fun nativeBuildSamples(deck: Int, bpm: Double, firstBeat: Long, slotBase: Int, info: LongArray): Int
    @JvmStatic external fun nativeClearSamples()
    /** Copia [length] quadros da música do deck a partir de [start] para o pad [slot], como loop. */
    @JvmStatic external fun nativeCaptureSample(deck: Int, slot: Int, start: Long, length: Long): Boolean
    /** Carrega os 8 sons prontos de DJ nos pads (buzina, sirene, laser, 808, palma, subida, descida, explosão). */
    @JvmStatic external fun nativeLoadBuiltinSamples(): Int
    /** Energia da faixa de 0 a 1 (-1 = não medida). */
    @JvmStatic external fun nativeAnalyzeEnergy(track: Long): Float
    /** Toca o pad depois de [delayFrames] quadros (para cair na batida). */
    @JvmStatic external fun nativeTriggerSampleAt(slot: Int, loop: Boolean, delayFrames: Long)
    /** Velocidade do pad (1 = original), para seguir o andamento do deck. */
    @JvmStatic external fun nativeSetSampleSpeed(slot: Int, speed: Float)
    /** Separa voz, bateria e baixo da faixa (demora: chame fora da thread principal). */
    @JvmStatic external fun nativeSeparateStems(track: Long, deck: Int): Boolean
    @JvmStatic external fun nativeCancelStems(deck: Int)
    @JvmStatic external fun nativeStemProgress(deck: Int): Float
    /** stem: 0 voz, 1 bateria, 2 baixo, 3 resto (melodia). Ganho 0..1. */
    @JvmStatic external fun nativeSetStemGain(deck: Int, stem: Int, gain: Float)
    /** Ganho de entrada do deck (auto-gain), 0..4, 1 = sem mudança. */
    @JvmStatic external fun nativeSetTrim(deck: Int, gain: Float)
    /** Volume médio da faixa em dBFS (0 = não medido). */
    @JvmStatic external fun nativeAnalyzeLoudness(track: Long): Float
    /** Muda o tom em semitons (-12..12) sem mudar o andamento. */
    @JvmStatic external fun nativeSetKeyShift(deck: Int, semitones: Float)
    /** Grava o som geral num WAV em [path]. */
    @JvmStatic external fun nativeRecordStart(path: String): Boolean
    /** Fecha o WAV e devolve os quadros gravados (-1 se não estava gravando). */
    @JvmStatic external fun nativeRecordStop(): Long
    @JvmStatic external fun nativeRecordFrames(): Long
    @JvmStatic external fun nativeTriggerSample(slot: Int, loop: Boolean)
    @JvmStatic external fun nativeStopSample(slot: Int)
    @JvmStatic external fun nativeSetSamplerVolume(value: Float)
    /** Bits dos pads que estão soando. */
    @JvmStatic external fun nativeSamplerMask(): Int
    /** Toca com a batida alinhada à do deck de referência (alinha na thread de áudio). */
    @JvmStatic external fun nativePlaySynced(
        deck: Int, refDeck: Int, refFirstBeat: Double, refBeatFrames: Double,
        firstBeat: Double, beatFrames: Double, startBeat: Double,
    )

    /** [bit0 carregada | bit1 tocando, posição, cue, tamanho], em quadros. */
    @JvmStatic external fun nativeDeckState(deck: Int, out: LongArray)
    @JvmStatic external fun nativeDeckPeak(deck: Int): Float
    @JvmStatic external fun nativeMasterPeak(): Float
    @JvmStatic external fun nativeCollectGarbage()
}
