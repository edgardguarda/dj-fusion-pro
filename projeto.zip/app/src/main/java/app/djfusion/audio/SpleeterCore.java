package app.djfusion.audio;

/**
 * Separação de stems com rede neural (Spleeter, 4 stems), parte de processamento de sinal.
 * A rede (ONNX, uma por stem) recebe o espectrograma de magnitude e devolve a magnitude estimada de cada stem;
 * aqui ficam: reamostragem para 44,1 kHz, STFT (4096 pontos, salto 1024, janela de Hann periódica), máscaras suaves
 * (as quatro somam 1), reconstrução com a fase original e devolução ao ritmo da faixa. Sem dependência do Android,
 * para poder ser testado no computador com uma rede de mentira.
 *
 * Sai mono (voz, bateria, baixo): é o formato dos stems do motor de áudio; a "melodia" é o que sobra do original.
 * Processa em blocos de 512 quadros (~11,9 s) e só mantém um bloco na memória.
 */
public final class SpleeterCore {
    public static final int N = 4096, H = 1024, BINS = 1024, FR = 512, K = N / 2 + 1;
    private static final int PAD = N - H, CARRY = 8, SPAN = FR * H, LEN = (FR - 1) * H + N;
    private static final float EPS = 1e-10f;

    /** Quadros (estéreo intercalado, 16 bits) de [start, start+count) da faixa; fora da faixa devolve zeros. */
    public interface Source { void read(long start, int count, short[] out); }
    /** Recebe stems prontos: count quadros a partir de start, três valores por quadro (voz, bateria, baixo). */
    public interface Sink { void write(long start, int count, short[] out3); }
    /** Rede: in = [2][512][1024] achatado (magnitudes); out[k] (k = voz, bateria, baixo, resto) com o mesmo formato. */
    public interface Net { void run(float[] in, float[][] out) throws Exception; }
    public interface Control { boolean cancelled(); void progress(float p); }

    private SpleeterCore() {}

    static final class Fft {
        final int n; final int[] rev; final float[] cos, sin;
        Fft(int n) {
            this.n = n; rev = new int[n]; cos = new float[n / 2]; sin = new float[n / 2];
            int bits = Integer.numberOfTrailingZeros(n);
            for (int i = 0; i < n; i++) rev[i] = Integer.reverse(i) >>> (32 - bits);
            for (int k = 0; k < n / 2; k++) { cos[k] = (float) Math.cos(2 * Math.PI * k / n); sin[k] = (float) Math.sin(2 * Math.PI * k / n); }
        }
        void transform(float[] re, float[] im, boolean inverse) {
            for (int i = 0; i < n; i++) {
                int j = rev[i];
                if (j > i) { float t = re[i]; re[i] = re[j]; re[j] = t; t = im[i]; im[i] = im[j]; im[j] = t; }
            }
            for (int len = 2; len <= n; len <<= 1) {
                int half = len >> 1, step = n / len;
                for (int i = 0; i < n; i += len) {
                    for (int j = 0, k = 0; j < half; j++, k += step) {
                        float wr = cos[k], wi = inverse ? sin[k] : -sin[k];
                        int a = i + j, b = a + half;
                        float tr = re[b] * wr - im[b] * wi, ti = re[b] * wi + im[b] * wr;
                        re[b] = re[a] - tr; im[b] = im[a] - ti;
                        re[a] += tr; im[a] += ti;
                    }
                }
            }
        }
    }

    /** Separa a faixa inteira. Devolve false se cancelado. Lança exceção se a rede falhar. */
    public static boolean separate(Source src, long frames, int srcRate, Net net, Sink sink, Control ctl) throws Exception {
        if (frames < 1 || srcRate < 8000) return false;
        final double ratio = srcRate / 44100.0;                       // quadros da faixa por amostra de 44,1 kHz
        final long total44 = (long) Math.ceil(frames / ratio);
        final long nFrames = (PAD + total44 + H - 1) / H;
        final int splits = (int) ((nFrames + FR - 1) / FR);
        final float[] win = new float[N];
        for (int i = 0; i < N; i++) win[i] = (float) (0.5 - 0.5 * Math.cos(2 * Math.PI * i / N));
        final Fft fft = new Fft(N);

        final float[] xL = new float[LEN], xR = new float[LEN];
        final float[] lre = new float[FR * K], lim = new float[FR * K], rre = new float[FR * K], rim = new float[FR * K];
        final float[] in = new float[2 * FR * BINS];
        final float[][] out = new float[4][2 * FR * BINS];
        final float[][] acc = new float[3][LEN], tail = new float[3][LEN - SPAN], carry = new float[3][CARRY];
        final float[][] fin = new float[3][CARRY + SPAN];
        final float[] zr = new float[N], zi = new float[N];
        final float[][] yr = new float[3][K], yi = new float[3][K];
        final float[] mL = new float[4], mR = new float[4], meanL = new float[4], meanR = new float[4];
        final int outCap = (int) (SPAN * ratio) + 32;
        final short[] chunk = new short[outCap * 3];
        long next48 = 0;

        for (int s = 0; s < splits; s++) {
            if (ctl != null && ctl.cancelled()) return false;
            final long start44 = (long) s * SPAN - PAD;

            // 1) entrada em 44,1 kHz (interpolação cúbica)
            final long a0 = (long) Math.floor(start44 * ratio) - 2;
            final long a1 = (long) Math.ceil((start44 + LEN - 1) * ratio) + 3;
            final int cnt = (int) (a1 - a0 + 1);
            final short[] raw = new short[cnt * 2];
            src.read(a0, cnt, raw);
            for (int j = 0; j < LEN; j++) {
                final double pos = (start44 + j) * ratio;
                final long i = (long) Math.floor(pos);
                final float t = (float) (pos - i);
                final int b = (int) (i - 1 - a0);
                xL[j] = cubic(raw[2 * b], raw[2 * (b + 1)], raw[2 * (b + 2)], raw[2 * (b + 3)], t) / 32768f;
                xR[j] = cubic(raw[2 * b + 1], raw[2 * (b + 1) + 1], raw[2 * (b + 2) + 1], raw[2 * (b + 3) + 1], t) / 32768f;
            }

            // 2) STFT dos dois canais com uma FFT só (L na parte real, R na imaginária)
            for (int f = 0; f < FR; f++) {
                final int o = f * H;
                for (int i = 0; i < N; i++) { zr[i] = xL[o + i] * win[i]; zi[i] = xR[o + i] * win[i]; }
                fft.transform(zr, zi, false);
                for (int k = 0; k < K; k++) {
                    final int j = (N - k) & (N - 1);
                    final float a = (zr[k] + zr[j]) * 0.5f, b = (zi[k] - zi[j]) * 0.5f;
                    final float c = (zi[k] + zi[j]) * 0.5f, d = (zr[j] - zr[k]) * 0.5f;
                    final int q = f * K + k;
                    lre[q] = a; lim[q] = b; rre[q] = c; rim[q] = d;
                    if (k < BINS) {
                        in[f * BINS + k] = (float) Math.sqrt(a * a + b * b);
                        in[(FR + f) * BINS + k] = (float) Math.sqrt(c * c + d * d);
                    }
                }
            }

            // 3) a rede
            net.run(in, out);

            // 4) máscaras, mistura dos canais e volta ao tempo
            for (int k = 0; k < 3; k++) {
                System.arraycopy(tail[k], 0, acc[k], 0, LEN - SPAN);
                java.util.Arrays.fill(acc[k], LEN - SPAN, LEN, 0f);
            }
            for (int f = 0; f < FR; f++) {
                // média das máscaras nas BINS de baixo: vale para as frequências acima do que a rede enxerga
                for (int k = 0; k < 4; k++) { meanL[k] = 0; meanR[k] = 0; }
                for (int b = 0; b < BINS; b++) {
                    masks(out, f * BINS + b, mL);
                    masks(out, (FR + f) * BINS + b, mR);
                    for (int k = 0; k < 4; k++) { meanL[k] += mL[k]; meanR[k] += mR[k]; }
                }
                for (int k = 0; k < 4; k++) { meanL[k] /= BINS; meanR[k] /= BINS; }
                for (int b = 0; b < K; b++) {
                    final float[] ml, mr;
                    if (b < BINS) { masks(out, f * BINS + b, mL); masks(out, (FR + f) * BINS + b, mR); ml = mL; mr = mR; }
                    else { ml = meanL; mr = meanR; }
                    final int q = f * K + b;
                    for (int k = 0; k < 3; k++) {
                        yr[k][b] = 0.5f * (ml[k] * lre[q] + mr[k] * rre[q]);
                        yi[k][b] = 0.5f * (ml[k] * lim[q] + mr[k] * rim[q]);
                    }
                }
                final int o = f * H;
                for (int k = 0; k < 3; k++) {
                    for (int b = 0; b < K; b++) { zr[b] = yr[k][b]; zi[b] = yi[k][b]; }
                    for (int b = 1; b < K - 1; b++) { zr[N - b] = yr[k][b]; zi[N - b] = -yi[k][b]; }
                    zi[0] = 0; zi[K - 1] = 0;
                    fft.transform(zr, zi, true);
                    final float[] ak = acc[k];
                    for (int i = 0; i < N; i++) ak[o + i] += zr[i] * win[i] * (1f / (1.5f * N));
                }
            }

            // 5) o miolo do bloco está completo; as últimas N-H amostras esperam o próximo bloco
            final long fs = start44;                                  // índice (44,1 kHz) da primeira amostra completa
            for (int k = 0; k < 3; k++) {
                System.arraycopy(carry[k], 0, fin[k], 0, CARRY);
                System.arraycopy(acc[k], 0, fin[k], CARRY, SPAN);
                System.arraycopy(acc[k], SPAN, tail[k], 0, LEN - SPAN);
            }
            final long fEnd = fs + SPAN;
            final boolean last = s == splits - 1;
            final long base = fs - CARRY;
            final long chunkStart = next48;
            int n = 0;
            while (next48 < frames) {
                final double x = next48 * 44100.0 / srcRate;
                final long i0 = (long) Math.floor(x);
                if (!last && i0 + 2 >= fEnd) break;
                final float t = (float) (x - i0);
                for (int k = 0; k < 3; k++) {
                    final float p0 = at(fin[k], i0 - 1 - base), p1 = at(fin[k], i0 - base),
                        p2 = at(fin[k], i0 + 1 - base), p3 = at(fin[k], i0 + 2 - base);
                    final float v = cubic(p0, p1, p2, p3, t);
                    chunk[n * 3 + k] = (short) Math.round(Math.max(-1f, Math.min(1f, v)) * 32767f);
                }
                n++; next48++;
            }
            if (n > 0) sink.write(chunkStart, n, chunk);
            for (int k = 0; k < 3; k++) System.arraycopy(fin[k], SPAN, carry[k], 0, CARRY);
            if (ctl != null) ctl.progress((s + 1f) / splits);
        }
        return true;
    }

    private static float at(float[] a, long i) { return i >= 0 && i < a.length ? a[(int) i] : 0f; }

    /** Catmull-Rom entre p1 e p2 (t de 0 a 1). */
    private static float cubic(float p0, float p1, float p2, float p3, float t) {
        return p1 + 0.5f * t * (p2 - p0 + t * (2f * p0 - 5f * p1 + 4f * p2 - p3 + t * (3f * (p1 - p2) + p3 - p0)));
    }

    /** m[k] = (e_k² + eps/4) / (Σ e² + eps): as quatro máscaras somam 1. */
    private static void masks(float[][] out, int idx, float[] m) {
        final float e0 = out[0][idx], e1 = out[1][idx], e2 = out[2][idx], e3 = out[3][idx];
        final float s0 = e0 * e0, s1 = e1 * e1, s2 = e2 * e2, s3 = e3 * e3;
        final float inv = 1f / (s0 + s1 + s2 + s3 + EPS);
        final float q = EPS * 0.25f;
        m[0] = (s0 + q) * inv; m[1] = (s1 + q) * inv; m[2] = (s2 + q) * inv; m[3] = (s3 + q) * inv;
    }
}
