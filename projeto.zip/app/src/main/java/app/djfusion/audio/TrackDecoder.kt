package app.djfusion.audio

import android.content.Context
import android.media.AudioFormat
import android.media.MediaCodec
import android.media.MediaExtractor
import android.media.MediaFormat
import android.net.Uri
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.ensureActive
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

sealed interface DecodeResult {
    /** [trackHandle] precisa ser liberado com NativeEngine.nativeFreeTrack depois de carregar no deck. */
    data class Ready(val trackHandle: Long) : DecodeResult

    data class Failed(val reason: String) : DecodeResult
}

/** Decodifica um arquivo de áudio com os decodificadores do próprio Android (MP3, AAC, FLAC, WAV, OGG...). */
object TrackDecoder {
    private const val TIMEOUT_US = 10_000L

    /** Últimos erros de leitura com o motivo técnico (vai para o relatório de diagnóstico). */
    val recentErrors: java.util.concurrent.ConcurrentLinkedDeque<String> = java.util.concurrent.ConcurrentLinkedDeque()

    private fun note(text: String) {
        android.util.Log.w("DJF", text)
        recentErrors.addFirst(java.text.SimpleDateFormat("HH:mm:ss", java.util.Locale.ROOT).format(java.util.Date()) + " " + text)
        while (recentErrors.size > 40) recentErrors.pollLast()
    }

    /** Falha "de decodificador": vale tentar o próximo decodificador da lista. */
    private class CodecFailure(msg: String) : Exception(msg)

    /**
     * Decodificadores para [mime], na ordem de tentativa: primeiro os de software do Android (iguais em todo
     * celular), depois os do fabricante. Se um falhar, o próximo é tentado.
     */
    private fun decodersFor(format: MediaFormat, mime: String): List<String> {
        val all = android.media.MediaCodecList(android.media.MediaCodecList.ALL_CODECS).codecInfos
            .filter { !it.isEncoder && it.supportedTypes.any { t -> t.equals(mime, ignoreCase = true) } }
            .map { it.name }
        val soft = all.filter { it.startsWith("c2.android.") || it.startsWith("OMX.google.") }
        val rest = all - soft.toSet()
        val list = (soft + rest).distinct()
        return list.ifEmpty { listOfNotNull(android.media.MediaCodecList(android.media.MediaCodecList.ALL_CODECS).findDecoderForFormat(format)) }
    }

    /** Abre o arquivo: pelo endereço e, se o provedor recusar, pelo descritor do arquivo. */
    private fun openExtractor(context: Context, uri: Uri): Pair<MediaExtractor, android.os.ParcelFileDescriptor?> {
        val ex = MediaExtractor()
        try {
            ex.setDataSource(context, uri, null)
            return ex to null
        } catch (e: Exception) {
            note("abrir pelo endereço falhou (${e.javaClass.simpleName}: ${e.message}); tentando pelo descritor")
        }
        ex.release()
        val pfd = context.contentResolver.openFileDescriptor(uri, "r")
            ?: throw java.io.FileNotFoundException("o Android não deu acesso ao arquivo")
        val ex2 = MediaExtractor()
        try {
            ex2.setDataSource(pfd.fileDescriptor)
        } catch (e: Exception) {
            ex2.release()
            pfd.close()
            throw e
        }
        return ex2 to pfd
    }

    /** Pelo começo do arquivo: 1 MP3, 2 FLAC, 3 WAV, 0 outro (AAC, OGG... ficam com o decodificador do Android). */
    private fun sniff(context: Context, uri: Uri): Int = try {
        context.contentResolver.openInputStream(uri)?.use { ins ->
            val b = ByteArray(12)
            var n = 0
            while (n < 12) { val r = ins.read(b, n, 12 - n); if (r <= 0) break; n += r }
            fun at(i: Int) = b[i].toInt() and 0xFF
            when {
                n >= 4 && b[0] == 'f'.code.toByte() && b[1] == 'L'.code.toByte() && b[2] == 'a'.code.toByte() && b[3] == 'C'.code.toByte() -> 2
                n >= 12 && (String(b, 0, 4, Charsets.ISO_8859_1) == "RIFF" || String(b, 0, 4, Charsets.ISO_8859_1) == "RF64") &&
                    String(b, 8, 4, Charsets.ISO_8859_1) == "WAVE" -> 3
                n >= 3 && String(b, 0, 3, Charsets.ISO_8859_1) == "ID3" -> 1
                n >= 2 && at(0) == 0xFF && (at(1) and 0xE0) == 0xE0 && (at(1) and 0x06) != 0 -> 1   // quadro MPEG camada I/II/III
                else -> 0
            }
        } ?: 0
    } catch (e: Exception) {
        0
    }

    /** Decodificador próprio (igual em todo celular). Devolve o identificador ou null (motivo anotado). */
    private suspend fun decodeOwn(context: Context, uri: Uri, kind: Int, name: String, slot: Int, onProgress: (Float) -> Unit): Long? =
        kotlinx.coroutines.coroutineScope {
            val pfd = try { context.contentResolver.openFileDescriptor(uri, "r") } catch (e: Exception) { null } ?: return@coroutineScope null
            val poll = launch {
                while (isActive) { kotlinx.coroutines.delay(150); onProgress(NativeEngine.nativeDecodeProgress(slot)) }
            }
            try {
                val h = withContext(Dispatchers.Default) {
                    android.os.Process.setThreadPriority(android.os.Process.THREAD_PRIORITY_BACKGROUND)
                    NativeEngine.nativeDecodeFd(pfd.fd, kind, pfd.statSize.coerceAtLeast(0L), slot)
                }
                when {
                    h > 0L -> h
                    h == -1L -> throw TooLong()
                    else -> { note("$name: decodificador próprio falhou -> ${NativeEngine.nativeDecodeError(slot)}"); null }
                }
            } finally {
                poll.cancel()
                try { pfd.close() } catch (_: Exception) {}
            }
        }

    suspend fun decode(context: Context, uri: Uri, slot: Int = 2, onProgress: (Float) -> Unit): DecodeResult {
        // Se o job for cancelado depois de a faixa ficar pronta, withContext descarta o resultado.
        // Guardamos o identificador aqui para liberar a memória nativa nesse caso.
        var pending = 0L
        try {
            return withContext(Dispatchers.Default) {
                // Decodificar não pode roubar CPU do áudio que está tocando.
                android.os.Process.setThreadPriority(android.os.Process.THREAD_PRIORITY_BACKGROUND)
                val name = uri.lastPathSegment?.substringAfterLast('/') ?: uri.toString()
                // 0) MP3, FLAC e WAV: decodificador próprio primeiro (o do aparelho pode entregar formatos estranhos)
                val kind = sniff(context, uri)
                if (kind != 0) {
                    try {
                        val h = decodeOwn(context, uri, kind, name, slot, onProgress)
                        if (h != null) {
                            pending = h
                            android.util.Log.i("DJF", "decodificado pelo decodificador próprio: tipo $kind")
                            return@withContext DecodeResult.Ready(h)
                        }
                    } catch (e: TooLong) {
                        return@withContext DecodeResult.Failed("Faixa maior que 15 minutos. O limite é 15 minutos.")
                    }
                }
                // 1) abre e acha a trilha de áudio
                val probe = try {
                    openExtractor(context, uri)
                } catch (e: SecurityException) {
                    note("$name: sem permissão (${e.message})")
                    return@withContext DecodeResult.Failed(
                        "O Android não deixa mais ler este arquivo. Remova da biblioteca e importe de novo (de preferência com PASTA).",
                    )
                } catch (e: java.io.FileNotFoundException) {
                    note("$name: não encontrado (${e.message})")
                    return@withContext DecodeResult.Failed("Arquivo não encontrado. Ele foi movido ou apagado? Importe de novo.")
                } catch (e: Exception) {
                    note("$name: não abriu (${e.javaClass.simpleName}: ${e.message})")
                    return@withContext DecodeResult.Failed("Não consegui abrir este arquivo (${e.javaClass.simpleName}). Tente importar de novo.")
                }
                val (ex0, pfd0) = probe
                var audioIndex = -1
                var fmt: MediaFormat? = null
                for (i in 0 until ex0.trackCount) {
                    val f = ex0.getTrackFormat(i)
                    if (f.getString(MediaFormat.KEY_MIME)?.startsWith("audio/") == true) { audioIndex = i; fmt = f; break }
                }
                ex0.release(); pfd0?.close()
                if (audioIndex < 0 || fmt == null) {
                    note("$name: sem trilha de áudio")
                    return@withContext DecodeResult.Failed("Este arquivo não tem áudio.")
                }
                val mime = fmt.getString(MediaFormat.KEY_MIME) ?: "audio/?"
                val durationUs = if (fmt.containsKey(MediaFormat.KEY_DURATION)) fmt.getLong(MediaFormat.KEY_DURATION) else 0L
                if (durationUs > NativeEngine.MAX_TRACK_SECONDS * 1_000_000L) {
                    return@withContext DecodeResult.Failed("Faixa maior que 15 minutos. O limite é 15 minutos.")
                }
                // 2) tenta cada decodificador até um funcionar
                val decoders = decodersFor(fmt, mime)
                if (decoders.isEmpty()) {
                    note("$name: nenhum decodificador para $mime")
                    return@withContext DecodeResult.Failed("Este celular não tem decodificador para $mime.")
                }
                var lastWhy = ""
                for (dec in decoders) {
                    ensureActive()
                    try {
                        val h = runDecoder(context, uri, audioIndex, mime, durationUs, dec, onProgress)
                        pending = h
                        android.util.Log.i("DJF", "decodificado com $dec: $mime")
                        return@withContext DecodeResult.Ready(h)
                    } catch (e: CancellationException) {
                        throw e
                    } catch (e: TooLong) {
                        return@withContext DecodeResult.Failed("Faixa maior que 15 minutos. O limite é 15 minutos.")
                    } catch (e: Exception) {
                        lastWhy = "${e.javaClass.simpleName}: ${e.message}"
                        note("$name: $dec falhou ($mime) -> $lastWhy")
                    }
                }
                DecodeResult.Failed("O celular não conseguiu decodificar este arquivo ($mime). Detalhe: ${lastWhy.take(80)}")
            }
        } catch (e: CancellationException) {
            if (pending != 0L) NativeEngine.nativeFreeTrack(pending)
            throw e
        }
    }

    private class TooLong : Exception("longa demais")

    /** Decodifica com o decodificador [codecName]. Devolve o identificador da faixa ou lança exceção. */
    private suspend fun runDecoder(
        context: Context, uri: Uri, audioIndex: Int, mime: String, durationUs: Long, codecName: String,
        onProgress: (Float) -> Unit,
    ): Long = withContext(Dispatchers.Default) {
        val (extractor, pfd) = openExtractor(context, uri)
        var codec: MediaCodec? = null
        var builder = 0L
        try {
            extractor.selectTrack(audioIndex)
            val inFormat = extractor.getTrackFormat(audioIndex)
            val c = MediaCodec.createByCodecName(codecName)
            codec = c
            c.configure(inFormat, null, null, 0)
            c.start()

            val info = MediaCodec.BufferInfo()
            var inputDone = false
            var outputDone = false
            var channels = 2
            var encoding = AudioFormat.ENCODING_PCM_16BIT
            var idleOutputs = 0
            var scratch = java.nio.ByteBuffer.allocateDirect(64 * 1024)
            var conv = java.nio.ByteBuffer.allocateDirect(64 * 1024).order(java.nio.ByteOrder.nativeOrder())
            var appended = 0L

            while (!outputDone) {
                ensureActive()
                if (!inputDone) {
                    val inIndex = c.dequeueInputBuffer(TIMEOUT_US)
                    if (inIndex >= 0) {
                        val inBuf = c.getInputBuffer(inIndex)!!
                        val n = extractor.readSampleData(inBuf, 0)
                        if (n < 0) {
                            c.queueInputBuffer(inIndex, 0, 0, 0, MediaCodec.BUFFER_FLAG_END_OF_STREAM)
                            inputDone = true
                        } else {
                            c.queueInputBuffer(inIndex, 0, n, extractor.sampleTime, 0)
                            extractor.advance()
                        }
                    }
                }
                val outIndex = c.dequeueOutputBuffer(info, TIMEOUT_US)
                if (outIndex == MediaCodec.INFO_OUTPUT_FORMAT_CHANGED && builder != 0L) {
                    val of = c.outputFormat
                    if (of.containsKey(MediaFormat.KEY_CHANNEL_COUNT) && of.getInteger(MediaFormat.KEY_CHANNEL_COUNT) > 0) channels = of.getInteger(MediaFormat.KEY_CHANNEL_COUNT)
                }
                if (outIndex < 0 && inputDone) {
                    if (++idleOutputs > 500) break   // ~5 s sem nada: o decodificador travou
                } else {
                    idleOutputs = 0
                }
                if (outIndex >= 0) {
                    if (info.size > 0) {
                        if (builder == 0L) {
                            // O formato de saída só é confiável depois do primeiro bloco decodificado
                            // (AAC com SBR, por exemplo, sai com o dobro da taxa de entrada).
                            val of = c.outputFormat
                            val rate = of.getInteger(MediaFormat.KEY_SAMPLE_RATE)
                            channels = if (of.containsKey(MediaFormat.KEY_CHANNEL_COUNT)) of.getInteger(MediaFormat.KEY_CHANNEL_COUNT) else 0
                            // alguns decodificadores informam 0 canais: usa o do arquivo (ou estéreo)
                            if (channels < 1) channels = if (inFormat.containsKey(MediaFormat.KEY_CHANNEL_COUNT)) inFormat.getInteger(MediaFormat.KEY_CHANNEL_COUNT) else 2
                            if (channels < 1) channels = 2
                            encoding = if (of.containsKey(MediaFormat.KEY_PCM_ENCODING)) of.getInteger(MediaFormat.KEY_PCM_ENCODING) else AudioFormat.ENCODING_PCM_16BIT
                            if (encoding !in SUPPORTED_ENCODINGS) {
                                c.releaseOutputBuffer(outIndex, false)
                                throw CodecFailure("saída em formato $encoding")
                            }
                            builder = NativeEngine.nativeBeginTrack(rate, NativeEngine.SAMPLE_RATE.toLong() * NativeEngine.MAX_TRACK_SECONDS)
                            if (builder == 0L) {
                                c.releaseOutputBuffer(outIndex, false)
                                throw CodecFailure("taxa de amostragem $rate Hz")
                            }
                        }
                        val outBuf = c.getOutputBuffer(outIndex)
                        if (outBuf != null) {
                            // Copia para um buffer nosso (direto): alguns decodificadores (Codec2 em vários celulares)
                            // entregam o buffer já recortado no início dos dados, ou um buffer que não é direto.
                            val src = outBuf.duplicate()
                            if (src.remaining() != info.size) {
                                if (info.offset + info.size <= src.capacity()) {
                                    src.limit(info.offset + info.size); src.position(info.offset)
                                } else {
                                    src.position(0); src.limit(minOf(info.size, src.capacity()))
                                }
                            }
                            val n = src.remaining()
                            if (scratch.capacity() < n) scratch = java.nio.ByteBuffer.allocateDirect(n * 2)
                            scratch.clear()
                            scratch.put(src)
                            appended += n
                            when (encoding) {
                                AudioFormat.ENCODING_PCM_16BIT -> NativeEngine.nativeAppend(builder, scratch, 0, n, channels, false)
                                AudioFormat.ENCODING_PCM_FLOAT -> NativeEngine.nativeAppend(builder, scratch, 0, n, channels, true)
                                else -> {
                                    // 8, 24 e 32 bits inteiros: converte para float antes de entregar ao motor
                                    val bytes = when (encoding) { AudioFormat.ENCODING_PCM_8BIT -> 1; PCM_24 -> 3; else -> 4 }
                                    val samples = n / bytes
                                    if (conv.capacity() < samples * 4) conv = java.nio.ByteBuffer.allocateDirect(samples * 8).order(java.nio.ByteOrder.nativeOrder())
                                    conv.clear()
                                    val fb = conv.asFloatBuffer()
                                    scratch.flip()
                                    scratch.order(java.nio.ByteOrder.LITTLE_ENDIAN)
                                    for (k in 0 until samples) {
                                        val v = when (bytes) {
                                            1 -> ((scratch.get().toInt() and 0xFF) - 128) / 128f
                                            3 -> {
                                                val b0 = scratch.get().toInt() and 0xFF
                                                val b1 = scratch.get().toInt() and 0xFF
                                                val b2 = scratch.get().toInt()          // com sinal
                                                ((b2 shl 16) or (b1 shl 8) or b0) / 8388608f
                                            }
                                            else -> scratch.getInt() / 2147483648f
                                        }
                                        fb.put(v)
                                    }
                                    NativeEngine.nativeAppend(builder, conv, 0, samples * 4, channels, true)
                                }
                            }
                        }
                        if (durationUs > 0) onProgress((info.presentationTimeUs.toFloat() / durationUs).coerceIn(0f, 1f))
                    }
                    c.releaseOutputBuffer(outIndex, false)
                    if ((info.flags and MediaCodec.BUFFER_FLAG_END_OF_STREAM) != 0) outputDone = true
                }
                if (builder != 0L && NativeEngine.nativeBuilderTooLong(builder)) throw TooLong()
            }
            if (builder == 0L) throw CodecFailure("o decodificador não entregou áudio")
            val handle = NativeEngine.nativeFinishTrack(builder)
            builder = 0L
            when {
                handle == -1L -> throw TooLong()
                handle <= 0L -> throw CodecFailure("áudio vazio ($appended bytes, codificação $encoding, $channels canais)")
                else -> handle
            }
        } finally {
            if (builder != 0L) NativeEngine.nativeAbortTrack(builder)
            try { codec?.stop() } catch (_: Exception) {}
            try { codec?.release() } catch (_: Exception) {}
            extractor.release()
            try { pfd?.close() } catch (_: Exception) {}
        }
    }

    private const val PCM_24 = 21     // AudioFormat.ENCODING_PCM_24BIT_PACKED (API 31)
    private const val PCM_32 = 22     // AudioFormat.ENCODING_PCM_32BIT (API 31)
    private val SUPPORTED_ENCODINGS = setOf(
        AudioFormat.ENCODING_PCM_16BIT, AudioFormat.ENCODING_PCM_FLOAT, AudioFormat.ENCODING_PCM_8BIT, PCM_24, PCM_32,
    )
}
