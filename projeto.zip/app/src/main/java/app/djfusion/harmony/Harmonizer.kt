package app.djfusion.harmony

import kotlin.math.abs

/** O que o HARMONIZAR precisa saber de cada faixa. [energy] de 0 a 1 (-1 = desconhecida). */
data class SetTrack(val id: Long, val bpm: Double, val key: MusicalKey?, val energy: Float)

/**
 * HARMONIZAR: monta a ordem de um set como um DJ faria. Cada próxima faixa:
 *  - tem tom compatível na Roda de Camelot (mesmo número, ±1, ou relativa maior/menor);
 *  - tem andamento perto (até ~6% para ajustar sem esforço; aceita metade/dobro);
 *  - segue uma curva de energia: sobe aos poucos até o pico (~70% do set) e desce um pouco no fim.
 * Escolha gulosa com um passo de antecipação (olha a faixa seguinte para não se encurralar).
 */
object Harmonizer {

    /** Custo de mixar [a] e depois [b]. Quanto menor, melhor a transição. */
    fun transitionCost(a: SetTrack, b: SetTrack): Double {
        val keyCost = if (a.key == null || b.key == null) 2.5 else Camelot.distance(a.key, b.key) * 2.0
        var bpmErr = Double.MAX_VALUE
        for (k in doubleArrayOf(1.0, 2.0, 0.5)) bpmErr = minOf(bpmErr, abs(a.bpm / (b.bpm * k) - 1.0))
        val bpmCost = if (bpmErr > 0.12) 6.0 + bpmErr * 10 else bpmErr * 25.0
        return keyCost + bpmCost
    }

    /** Energia alvo na posição [p] do set (0 = início, 1 = fim), na escala de 0 a 1. */
    fun targetEnergy(p: Double): Double =
        if (p <= 0.7) 0.25 + 0.7 * (p / 0.7) else 0.95 - 0.35 * ((p - 0.7) / 0.3)

    fun order(tracks: List<SetTrack>, startId: Long? = null): List<SetTrack> {
        if (tracks.size <= 1) return tracks
        // energia por posição relativa (percentil): funciona mesmo se a biblioteca toda for "alta" ou "baixa"
        val sortedE = tracks.map { if (it.energy < 0f) 0.5f else it.energy }.sorted()
        fun rank(t: SetTrack): Double {
            val e = if (t.energy < 0f) 0.5f else t.energy
            val idx = sortedE.indexOfFirst { it >= e }.coerceAtLeast(0)
            return if (sortedE.size == 1) 0.5 else idx.toDouble() / (sortedE.size - 1)
        }
        val ranks = tracks.associate { it.id to rank(it) }
        val n = tracks.size
        val remaining = tracks.toMutableList()
        val first = remaining.firstOrNull { it.id == startId } ?: remaining.minByOrNull { ranks.getValue(it.id) }!!
        remaining.remove(first)
        val out = mutableListOf(first)
        val lookahead = n <= 200
        while (remaining.isNotEmpty()) {
            val cur = out.last()
            val p = out.size.toDouble() / (n - 1)
            fun stepCost(a: SetTrack, b: SetTrack, pos: Double) =
                transitionCost(a, b) + 3.0 * abs(ranks.getValue(b.id) - targetEnergy(pos))
            var best = remaining[0]
            var bestCost = Double.MAX_VALUE
            for (c in remaining) {
                var cost = stepCost(cur, c, p)
                if (lookahead && remaining.size > 1) {
                    val p2 = (out.size + 1).toDouble() / (n - 1)
                    var nxt = Double.MAX_VALUE
                    for (d in remaining) if (d !== c) nxt = minOf(nxt, stepCost(c, d, p2))
                    cost += 0.5 * nxt
                }
                if (cost < bestCost) { bestCost = cost; best = c }
            }
            remaining.remove(best)
            out.add(best)
        }
        return out
    }
}
