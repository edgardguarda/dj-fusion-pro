package app.djfusion.harmony

import kotlin.math.abs
import kotlin.math.ln
import kotlin.math.roundToInt

/** Tonalidade: nota (0 = Dó ... 11 = Si) e modo. */
data class MusicalKey(val tonic: Int, val minor: Boolean) {
    /** Número na Roda de Camelot (1 a 12). Dó maior = 8B, Lá menor = 8A. */
    val number: Int
        get() {
            val majorTonic = if (minor) (tonic + 3) % 12 else tonic     // relativa maior
            val fifths = (majorTonic * 7) % 12                           // posição no círculo das quintas
            return (8 + fifths - 1) % 12 + 1
        }

    /** Código de Camelot, como "8A" (menor) ou "8B" (maior). */
    val code: String get() = "$number${if (minor) 'A' else 'B'}"

    val name: String get() = NOTES[tonic] + if (minor) " menor" else " maior"
    /** Nota em letras, como no VirtualDJ e no Traktor: Am, F#, C#m... */
    val letter: String get() = LETTERS[tonic] + if (minor) "m" else ""

    /** A mesma música tocada [semitones] meio-tons acima (ou abaixo, se negativo). */
    fun shifted(semitones: Int): MusicalKey = MusicalKey(((tonic + semitones) % 12 + 12) % 12, minor)

    companion object {
        private val NOTES = arrayOf("Dó", "Dó#", "Ré", "Ré#", "Mi", "Fá", "Fá#", "Sol", "Sol#", "Lá", "Lá#", "Si")
        private val LETTERS = arrayOf("C", "C#", "D", "D#", "E", "F", "F#", "G", "G#", "A", "A#", "B")

        /** Do que o motor devolve: nota, 1 se menor. */
        fun of(tonic: Int, minor: Boolean) = MusicalKey(tonic.coerceIn(0, 11), minor)
    }
}

object Camelot {
    /** Confiança mínima (0 a 1) para mostrar e usar a tonalidade detectada. */
    const val MIN_CONFIDENCE = 0.35f

    /**
     * Compatibilidade harmônica entre duas tonalidades, 0 = perfeita:
     * - mesmo número (qualquer letra) = 0 (mesma tonalidade ou a relativa maior/menor);
     * - número vizinho, mesma letra = 1 (sobe ou desce uma quinta);
     * - dois números, mesma letra = 2 ("salto de energia");
     * - número vizinho com a outra letra = 2;
     * - o resto = choque (3 ou mais).
     */
    fun distance(a: MusicalKey, b: MusicalKey): Int {
        val raw = abs(a.number - b.number)
        val d = minOf(raw, 12 - raw)
        val sameLetter = a.minor == b.minor
        return when {
            d == 0 -> 0
            sameLetter && d == 1 -> 1
            sameLetter && d == 2 -> 2
            !sameLetter && d == 1 -> 2
            else -> 3 + d
        }
    }

    fun describe(distance: Int): String = when (distance) {
        0 -> "perfeita"
        1 -> "boa"
        2 -> "aceitável"
        else -> "choca"
    }

    /** Meios-tons que a velocidade [rate] desloca o tom (sem key-lock): 12 x log2(rate). */
    fun semitonesFor(rate: Float): Int = if (rate <= 0f) 0 else (12.0 * ln(rate.toDouble()) / ln(2.0)).roundToInt()

    /** Matiz (0..360) da roda para o número dado, para pintar a chave de cada tom. */
    fun hue(number: Int): Float = ((number - 1) * 30f) % 360f
}
