package app.djfusion.harmony

/**
 * Onde a música "de verdade" começa e termina, pela forma de onda (picos de 3 bandas, 150 por segundo).
 * O fim musical é o último trecho de 2 s com nível de pelo menos 30% do nível típico da faixa: assim o
 * AUTO DJ não espera um fade-out longo nem o silêncio do fim do arquivo para começar a mixagem.
 */
object TrackShape {
    const val FRAMES_PER_BIN = 320          // 48000 / 150
    private const val WIN = 300             // 2 s em picos

    private fun windows(wave: ByteArray): FloatArray {
        val bins = wave.size / 3
        val n = bins / WIN
        val out = FloatArray(n)
        for (w in 0 until n) {
            var sum = 0f
            for (b in w * WIN until (w + 1) * WIN) {
                val a = maxOf(wave[b * 3].toInt() and 0xFF, wave[b * 3 + 1].toInt() and 0xFF, wave[b * 3 + 2].toInt() and 0xFF)
                sum += a
            }
            out[w] = sum / WIN
        }
        return out
    }

    private fun typical(w: FloatArray): Float = w.sorted()[w.size / 2]

    /** Quadro onde a música termina musicalmente (≤ [lengthFrames]). */
    fun musicalEnd(wave: ByteArray?, lengthFrames: Long): Long {
        if (wave == null) return lengthFrames
        val w = windows(wave)
        if (w.size < 6) return lengthFrames
        val ref = typical(w)
        if (ref <= 0f) return lengthFrames
        val last = w.indexOfLast { it >= ref * 0.3f }
        if (last < 0) return lengthFrames
        return minOf(lengthFrames, (last + 1L) * WIN * FRAMES_PER_BIN)
    }

    /** Quadro onde o som começa (pula silêncio inicial). */
    fun musicalStart(wave: ByteArray?): Long {
        if (wave == null) return 0
        val w = windows(wave)
        if (w.size < 6) return 0
        val ref = typical(w)
        val first = w.indexOfFirst { it >= ref * 0.1f }
        return if (first <= 0) 0 else first.toLong() * WIN * FRAMES_PER_BIN
    }

    /** Média da banda [band] (0 graves, 1 médios, 2 agudos) em cada batida da grade. */
    fun bandPerBeat(wave: ByteArray?, firstBeat: Long, beatFrames: Double, band: Int): FloatArray {
        if (wave == null || beatFrames <= 0.0) return FloatArray(0)
        val bins = wave.size / 3
        val totalFrames = bins.toLong() * FRAMES_PER_BIN
        val n = ((totalFrames - firstBeat) / beatFrames).toInt().coerceAtLeast(0)
        val out = FloatArray(n)
        for (b in 0 until n) {
            val a = ((firstBeat + b * beatFrames) / FRAMES_PER_BIN).toInt().coerceIn(0, bins)
            val z = ((firstBeat + (b + 1) * beatFrames) / FRAMES_PER_BIN).toInt().coerceIn(a, bins)
            var sum = 0f
            for (i in a until z) sum += (wave[i * 3 + band].toInt() and 0xFF)
            out[b] = if (z > a) sum / (z - a) else 0f
        }
        return out
    }

    private fun median(v: FloatArray): Float {
        val nz = v.filter { it > 4f }.sorted()
        return if (nz.isEmpty()) 0f else nz[nz.size / 2]
    }

    /**
     * Batida (múltipla de 16, uma frase) onde a música "pega": graves cheios (bumbo + baixo) por uma frase inteira.
     * É onde a música que entra deve estar quando a mixagem termina. 0 se começa cheia ou sem dados.
     */
    fun grooveBeat(wave: ByteArray?, firstBeat: Long, beatFrames: Double): Int {
        val low = bandPerBeat(wave, firstBeat, beatFrames, 0)
        if (low.size < 48) return 0
        val ref = median(low)
        if (ref <= 0f) return 0
        var b = 0
        while (b + 16 <= low.size / 2) {
            var full = 0
            for (i in b until b + 16) if (low[i] >= ref * 0.7f) full++
            if (full >= 12) return b
            b += 16
        }
        return 0
    }

    /**
     * Batida (múltipla de 16) onde começa a saída da música: daí até [endBeat] os graves ficam fracos.
     * Devolve [endBeat] se a música vai cheia até o fim.
     */
    fun outroBeat(wave: ByteArray?, firstBeat: Long, beatFrames: Double, endBeat: Int): Int {
        val low = bandPerBeat(wave, firstBeat, beatFrames, 0)
        if (low.size < 48 || endBeat <= 32) return endBeat
        val ref = median(low)
        if (ref <= 0f) return endBeat
        var b = (endBeat / 16) * 16
        val limit = endBeat - 64     // a saída tem no máximo 64 batidas
        while (b - 16 >= limit && b - 16 >= 0) {
            var weak = 0
            for (i in b - 16 until minOf(b, low.size)) if (low[i] < ref * 0.55f) weak++
            if (weak < 12) break
            b -= 16
        }
        return if (b >= endBeat - 4) endBeat else b
    }

    /**
     * Em qual das 4 batidas cai o "1" do compasso: a batida em que os graves (bumbo) e as mudanças de
     * energia são mais fortes, somando a música inteira. Devolve 0..3 (0 = a grade já começa no 1).
     */
    fun downbeatOffset(wave: ByteArray?, firstBeat: Long, beatFrames: Double): Int {
        val low = bandPerBeat(wave, firstBeat, beatFrames, 0)
        val all = bandPerBeat(wave, firstBeat, beatFrames, 1)
        if (low.size < 32) return 0
        val score = DoubleArray(4)
        for (b in 1 until low.size) {
            // força do grave na batida + subida de energia (entradas de frase caem no 1)
            val rise = maxOf(0f, (low[b] + all[b]) - (low[b - 1] + all[b - 1]))
            score[b % 4] += low[b] + 0.6 * rise
        }
        var best = 0
        for (o in 1..3) if (score[o] > score[best]) best = o
        val others = (score.sum() - score[best]) / 3.0
        // só muda se o 1 for claramente mais forte (música de batida reta não tem diferença)
        return if (score[best] > others * 1.06) best else 0
    }

    /**
     * Batida do "drop": onde os graves voltam com mais força depois de uma parte mais vazia (break).
     * Procura em compassos (4 batidas), entre [fromBeat] e [toBeat]; -1 se não houver uma volta clara.
     */
    fun dropBeat(wave: ByteArray?, firstBeat: Long, beatFrames: Double, fromBeat: Int, toBeat: Int): Int {
        val low = bandPerBeat(wave, firstBeat, beatFrames, 0)
        if (low.size < 48) return -1
        val ref = median(low)
        if (ref <= 0f) return -1
        var best = -1
        var bestScore = 0.0
        var b = ((fromBeat + 3) / 4) * 4
        val end = minOf(toBeat, low.size - 8)
        while (b in 16..end) {
            var after = 0.0; var before = 0.0
            for (k in 0 until 8) after += low[b + k]
            for (k in 1..16) before += low[b - k]
            after /= 8.0; before /= 16.0
            // depois forte (perto do normal) e antes vazio: a volta do break
            if (after >= ref * 0.85 && before < ref * 0.6) {
                val score = after - before
                if (score > bestScore) { bestScore = score; best = b }
            }
            b += 4
        }
        return best
    }
}
