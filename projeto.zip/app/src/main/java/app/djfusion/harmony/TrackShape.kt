package app.djfusion.harmony

/**
 * Onde a música "de verdade" começa e termina, pela forma de onda (picos de 3 bandas, 150 por segundo).
 * O fim musical é o último trecho de 2 s com nível de pelo menos 30% do nível típico da faixa: assim o
 * AUTO DJ não espera um fade-out longo nem o silêncio do fim do arquivo para começar a mixagem.
 */
object TrackShape {
    const val FRAMES_PER_BIN = 320          // 48000 / 150
    private const val WIN = 300             // 2 s em picos

    private fun windows(wave: ByteArray): FloatArray {
        val bins = wave.size / 3
        val n = bins / WIN
        val out = FloatArray(n)
        for (w in 0 until n) {
            var sum = 0f
            for (b in w * WIN until (w + 1) * WIN) {
                val a = maxOf(wave[b * 3].toInt() and 0xFF, wave[b * 3 + 1].toInt() and 0xFF, wave[b * 3 + 2].toInt() and 0xFF)
                sum += a
            }
            out[w] = sum / WIN
        }
        return out
    }

    private fun typical(w: FloatArray): Float = w.sorted()[w.size / 2]

    /** Quadro onde a música termina musicalmente (≤ [lengthFrames]). */
    fun musicalEnd(wave: ByteArray?, lengthFrames: Long): Long {
        if (wave == null) return lengthFrames
        val w = windows(wave)
        if (w.size < 6) return lengthFrames
        val ref = typical(w)
        if (ref <= 0f) return lengthFrames
        val last = w.indexOfLast { it >= ref * 0.3f }
        if (last < 0) return lengthFrames
        return minOf(lengthFrames, (last + 1L) * WIN * FRAMES_PER_BIN)
    }

    /** Quadro onde o som começa (pula silêncio inicial). */
    fun musicalStart(wave: ByteArray?): Long {
        if (wave == null) return 0
        val w = windows(wave)
        if (w.size < 6) return 0
        val ref = typical(w)
        val first = w.indexOfFirst { it >= ref * 0.1f }
        return if (first <= 0) 0 else first.toLong() * WIN * FRAMES_PER_BIN
    }
}
