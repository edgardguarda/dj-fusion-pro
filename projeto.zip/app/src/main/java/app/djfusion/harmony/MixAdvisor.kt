package app.djfusion.harmony

import kotlin.math.abs

/**
 * Técnicas de mixagem harmônica (além da Roda de Camelot básica) e o "assistente de mixagem": para a música que
 * está tocando, dá nota a cada candidata e explica a técnica que combina — como os DJs usam no Mixed In Key.
 *
 * Técnicas pela roda (n = número, letra A menor / B maior):
 *  - Mesmo tom (n, mesma letra): mistura perfeita, pode ser longa.
 *  - Relativa (n, outra letra): mesmas notas, muda o clima (alegre <-> sombrio).
 *  - Quinta acima / abaixo (n±1, mesma letra): a transição mais usada, suave.
 *  - Diagonal (n±1, outra letra): muda clima e sobe/desce um pouco.
 *  - Energy boost (+2, mesma letra): sobe a energia sem choque.
 *  - Semitom acima (+7, mesma letra): sobe meio tom, efeito de "subida" (usar em corte curto ou eco).
 *  - Tom inteiro (+2 já coberto) / −7 semitom abaixo: baixa a energia.
 *  - Choque: tons sem relação; só com corte seco, eco ou filtro.
 * Andamento: igual, ±6% (ajuste fino), dobro/metade (half-time) ou distante (corte/eco).
 */
object MixAdvisor {

    data class Relation(val name: String, val keyScore: Double, val technique: String)

    fun keyRelation(a: MusicalKey?, b: MusicalKey?): Relation {
        if (a == null || b == null) return Relation("tom desconhecido", 2.5, "use troca de graves curta")
        val up = ((b.number - a.number) % 12 + 12) % 12
        val same = a.minor == b.minor
        return when {
            up == 0 && same -> Relation("mesmo tom", 0.0, "mistura longa, troca de graves")
            up == 0 -> Relation(if (b.minor) "relativa menor (fica mais sombrio)" else "relativa maior (fica mais alegre)", 0.4, "mistura longa")
            same && up == 1 -> Relation("quinta acima (+1)", 0.5, "troca de graves em 16 batidas")
            same && up == 11 -> Relation("quinta abaixo (−1)", 0.6, "troca de graves em 16 batidas")
            !same && (up == 1 || up == 11) -> Relation("diagonal (clima + energia)", 1.2, "filtro em 8–16 batidas")
            same && up == 2 -> Relation("energy boost (+2)", 1.4, "entrada curta, 8 batidas")
            same && up == 7 -> Relation("semitom acima (+7, sobe a energia)", 1.8, "corte na frase ou eco")
            same && up == 5 -> Relation("semitom abaixo (−7, baixa a energia)", 2.0, "eco ou filtro")
            same && up == 10 -> Relation("dois abaixo (−2)", 2.0, "filtro curto")
            else -> Relation("choque de tom", 5.0, "só com eco, corte seco ou filtro forte")
        }
    }

    data class BpmFit(val ratio: Double, val errPct: Double, val label: String, val score: Double)

    fun bpmFit(refBpm: Double, bpm: Double): BpmFit {
        if (refBpm <= 0 || bpm <= 0) return BpmFit(1.0, 99.0, "sem andamento", 3.0)
        var best = 1.0
        var err = Double.MAX_VALUE
        for (k in doubleArrayOf(1.0, 2.0, 0.5)) {
            val e = abs(refBpm / (bpm * k) - 1.0)
            if (e < err) { err = e; best = k }
        }
        val pct = err * 100
        val kind = when (best) { 2.0 -> " (dobro)"; 0.5 -> " (metade)"; else -> "" }
        val label = when {
            pct < 0.5 -> "mesmo andamento$kind"
            pct <= 6 -> String.format(java.util.Locale.ROOT, "%.1f%% de ajuste%s", pct, kind)
            pct <= 12 -> String.format(java.util.Locale.ROOT, "%.0f%% (ajuste grande)%s", pct, kind)
            else -> String.format(java.util.Locale.ROOT, "%.0f%% (longe: use corte/eco)", pct)
        }
        val score = if (pct <= 6) pct / 6.0 else if (pct <= 12) 1.5 + (pct - 6) / 6.0 else 4.0
        return BpmFit(best, pct, label, score)
    }

    data class Suggestion(val track: SetTrack, val score: Double, val key: Relation, val bpm: BpmFit, val energyText: String)

    /** Melhores próximas músicas para [ref] (menor nota = melhor). [energyUp] prefere subir a energia. */
    fun suggest(ref: SetTrack, candidates: List<SetTrack>, energyUp: Boolean = true, limit: Int = 10): List<Suggestion> =
        candidates.filter { it.id != ref.id }.map { c ->
            val k = keyRelation(ref.key, c.key)
            val b = bpmFit(ref.bpm, c.bpm)
            val (eScore, eText) = if (ref.energy < 0f || c.energy < 0f) 0.5 to "" else {
                val d = c.energy - ref.energy
                val lv = (d * 9).let { if (it >= 0) "+%.0f".format(java.util.Locale.ROOT, it) else "%.0f".format(java.util.Locale.ROOT, it) }
                val s = if (energyUp) (if (d < -0.1f) -d * 3.0 else abs(d - 0.08f) * 1.2) else abs(d) * 1.5
                s to "energia $lv"
            }
            Suggestion(c, k.keyScore * 1.6 + b.score + eScore, k, b, eText)
        }.sortedBy { it.score }.take(limit)
}
