package app.djfusion

import android.content.Context
import java.io.File

/**
 * Registro de erros do app: avisos de erro, falhas recuperadas (o app continua) e fechamentos inesperados
 * (gravados em arquivo antes de o Android fechar o app). Tudo entra no relatório de diagnóstico.
 */
object ErrorLog {
    private val items = java.util.ArrayDeque<String>()
    private const val FILE = "erros.txt"

    private fun now(): String = java.text.SimpleDateFormat("dd/MM HH:mm:ss", java.util.Locale.ROOT).format(java.util.Date())

    /** Guarda um erro recuperado ([where] = parte do app). */
    @Synchronized
    fun add(where: String, text: String, e: Throwable? = null) {
        val line = "${now()} [$where] $text" + (e?.let { " · ${it.javaClass.simpleName}: ${it.message ?: ""}" } ?: "")
        if (items.peekFirst()?.substringAfter(' ')?.substringAfter(' ') == line.substringAfter(' ').substringAfter(' ')) return
        items.addFirst(line)
        while (items.size > 80) items.pollLast()
    }

    @Synchronized
    fun recent(): List<String> = items.toList()

    /** Grava o motivo de um fechamento inesperado antes de o app fechar (o próximo relatório mostra). */
    fun installCrashHandler(context: Context) {
        val app = context.applicationContext
        val prev = Thread.getDefaultUncaughtExceptionHandler()
        Thread.setDefaultUncaughtExceptionHandler { t, e ->
            runCatching {
                val f = File(app.filesDir, FILE)
                val sw = java.io.StringWriter()
                e.printStackTrace(java.io.PrintWriter(sw))
                val ver = runCatching { app.packageManager.getPackageInfo(app.packageName, 0).versionName }.getOrNull()
                f.appendText("=== ${now()} · versão $ver · linha ${t.name}\n${sw.toString().lines().take(30).joinToString("\n")}\n")
                // guarda só o fim (os últimos fechamentos)
                if (f.length() > 60_000) f.writeText(f.readText().takeLast(40_000))
            }
            prev?.uncaughtException(t, e)
        }
    }

    /** Fechamentos inesperados gravados (o mais recente por último). */
    fun crashes(context: Context): List<String> {
        val f = File(context.filesDir, FILE)
        if (!f.exists()) return emptyList()
        return runCatching { f.readText().split("=== ").filter { it.isNotBlank() }.map { "=== $it".trim() } }.getOrDefault(emptyList())
    }

    fun clearCrashes(context: Context) { runCatching { File(context.filesDir, FILE).delete() } }
}
