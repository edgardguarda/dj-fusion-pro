// Liga o motor (core/engine) a uma saída de áudio Oboe de baixa latência.
// Este é o único arquivo que depende do Oboe.
#pragma once
#include <oboe/Oboe.h>

#include <android/log.h>

#if defined(__SSE__)
#include <xmmintrin.h>
#endif
#include <algorithm>
#include <atomic>
#include <memory>
#include <mutex>

#include "core/engine.h"

namespace djf {

constexpr int kEngineRate = 48000;   // todas as faixas são decodificadas nesta taxa
constexpr int kMaxBlockFrames = 4096;

class AudioHost : public oboe::AudioStreamDataCallback,
                  public oboe::AudioStreamErrorCallback,
                  public std::enable_shared_from_this<AudioHost> {
 public:
  AudioHost() : engine_(kEngineRate, kMaxBlockFrames) {}

  Engine& engine() { return engine_; }

  bool start() {
    std::lock_guard<std::mutex> lock(mutex_);
    wanted_ = true;
    if (stream_) return true;
    return openLocked();
  }

  void stop() {
    std::lock_guard<std::mutex> lock(mutex_);
    wanted_ = false;
    closeLocked();
  }

  // out: [taxa real, quadros por rajada, tamanho do buffer em quadros, 1 se exclusivo, canais, modo efetivo]
  void info(int32_t out[6]) const {
    for (int i = 0; i < 6; ++i) out[i] = info_[i].load(std::memory_order_relaxed);
  }

  // Saída do fone. mode: 0 = só som geral em estéreo; 1 = dividido (esquerdo = fone, direito = som geral, em mono);
  // 2 = quatro canais (1-2 som geral, 3-4 fone). deviceId: aparelho de saída (0 = o padrão do Android).
  // Se o aparelho não aceitar quatro canais, cai para o modo 1; se não abrir de jeito nenhum, volta ao padrão.
  void configureOutput(int mode, int deviceId) {
    std::lock_guard<std::mutex> lock(mutex_);
    reqMode_ = mode < 0 || mode > 2 ? 0 : mode;
    reqDevice_ = deviceId < 0 ? 0 : deviceId;
    if (wanted_) {
      closeLocked();
      openLocked();
    }
  }

  oboe::DataCallbackResult onAudioReady(oboe::AudioStream* st, void* audioData, int32_t numFrames) override {
    flushDenormals();
    float* out = static_cast<float*>(audioData);
    const int mode = effMode_.load(std::memory_order_relaxed);
    const int ch = st->getChannelCount();
    if (mode == 0 || ch < 2) {
      engine_.render(out, numFrames);
    } else {
      // Fone: renderiza geral e fone em blocos e monta os canais da saída.
      int done = 0;
      while (done < numFrames) {
        const int n = std::min(numFrames - done, kMaxBlockFrames);
        engine_.render(master_.get(), n, hp_.get());
        for (int i = 0; i < n; ++i) {
          const float mL = master_[2 * i], mR = master_[2 * i + 1], hL = hp_[2 * i], hR = hp_[2 * i + 1];
          float* o = out + static_cast<size_t>(done + i) * ch;
          if (mode == 1 || ch < 4) {
            o[0] = 0.5f * (hL + hR);
            o[1] = 0.5f * (mL + mR);
            for (int c = 2; c < ch; ++c) o[c] = 0.f;
          } else {
            o[0] = mL; o[1] = mR; o[2] = hL; o[3] = hR;
            for (int c = 4; c < ch; ++c) o[c] = 0.f;
          }
        }
        done += n;
      }
    }
    // Se houve underrun, aumenta o buffer (mais folga, um pouco mais de latência) até estabilizar.
    if ((++cb_ & 31) == 0) {
      auto x = st->getXRunCount();
      if (x.error() == oboe::Result::OK && x.value() > lastXrun_) {
        lastXrun_ = x.value();
        int32_t burst = st->getFramesPerBurst();
        int32_t want = std::min(st->getBufferSizeInFrames() + burst, st->getBufferCapacityInFrames());
        st->setBufferSizeInFrames(want);
        info_[2].store(st->getBufferSizeInFrames(), std::memory_order_relaxed);
      }
    }
    return oboe::DataCallbackResult::Continue;
  }

  // Números minúsculos (caudas de filtro, eco e reverb) são lentíssimos em CPU ARM e causam engasgos.
  // Pedimos ao processador que os trate como zero, nesta thread de áudio.
  static void flushDenormals() {
#if defined(__aarch64__)
    uint64_t fpcr;
    asm volatile("mrs %0, fpcr" : "=r"(fpcr));
    if (!(fpcr & (1ull << 24))) {
      fpcr |= (1ull << 24);
      asm volatile("msr fpcr, %0" : : "r"(fpcr));
    }
#elif defined(__SSE__)
    _MM_SET_FLUSH_ZERO_MODE(_MM_FLUSH_ZERO_ON);
#endif
  }

  // Fone desligado, USB removido ou rota trocada: o Oboe fecha o fluxo e avisa aqui. Reabrimos.
  void onErrorAfterClose(oboe::AudioStream*, oboe::Result error) override {
    __android_log_print(ANDROID_LOG_WARN, "DJFusion", "erro de áudio: %s", oboe::convertToText(error));
    std::unique_lock<std::mutex> lock(mutex_, std::try_to_lock);
    if (!lock.owns_lock()) return;  // stop() está em andamento
    stream_.reset();
    if (wanted_) openLocked();
  }

 private:
  bool openLocked() {
    if (!master_) {
      master_.reset(new float[2 * kMaxBlockFrames]());
      hp_.reset(new float[2 * kMaxBlockFrames]());
    }
    // Tentativas, da preferida para a mais simples.
    struct Try { int mode; int device; int channels; };
    Try tries[4];
    int nt = 0;
    if (reqMode_ == 2 && reqDevice_ != 0) tries[nt++] = {2, reqDevice_, 4};
    if (reqMode_ >= 1 && reqDevice_ != 0) tries[nt++] = {1, reqDevice_, 2};
    if (reqMode_ >= 1) tries[nt++] = {1, 0, 2};
    tries[nt++] = {0, 0, 2};
    for (int k = 0; k < nt; ++k) {
      if (openWith(tries[k].mode, tries[k].device, tries[k].channels)) return true;
    }
    return false;
  }

  bool openWith(int mode, int device, int channels) {
    oboe::AudioStreamBuilder builder;
    builder.setDirection(oboe::Direction::Output)
        ->setPerformanceMode(oboe::PerformanceMode::LowLatency)
        ->setSharingMode(oboe::SharingMode::Exclusive)
        ->setFormat(oboe::AudioFormat::Float)
        ->setChannelCount(channels)
        ->setSampleRate(kEngineRate)
        ->setSampleRateConversionQuality(oboe::SampleRateConversionQuality::Medium)
        ->setUsage(oboe::Usage::Media)
        ->setContentType(oboe::ContentType::Music)
        ->setDataCallback(shared_from_this())
        ->setErrorCallback(shared_from_this());
    if (device != 0) builder.setDeviceId(device);
    std::shared_ptr<oboe::AudioStream> stream;
    oboe::Result r = builder.openStream(stream);
    if (r != oboe::Result::OK) {
      __android_log_print(ANDROID_LOG_WARN, "DJFusion", "não abriu o áudio (modo %d, aparelho %d, %d canais): %s",
                          mode, device, channels, oboe::convertToText(r));
      return false;
    }
    const int got = stream->getChannelCount();
    if (mode == 2 && got < 4) mode = 1;
    if (mode == 1 && got < 2) mode = 0;
    effMode_.store(mode, std::memory_order_relaxed);
    // Começa com folga generosa (6 rajadas); para DJ, estabilidade vale mais que 5 ms a menos.
    stream->setBufferSizeInFrames(std::min(stream->getFramesPerBurst() * 6, stream->getBufferCapacityInFrames()));
    cb_ = 0;
    lastXrun_ = 0;
    r = stream->requestStart();
    if (r != oboe::Result::OK) {
      __android_log_print(ANDROID_LOG_ERROR, "DJFusion", "não iniciou o áudio: %s", oboe::convertToText(r));
      stream->close();
      return false;
    }
    info_[0].store(stream->getSampleRate());
    info_[1].store(stream->getFramesPerBurst());
    info_[2].store(stream->getBufferSizeInFrames());
    info_[3].store(stream->getSharingMode() == oboe::SharingMode::Exclusive ? 1 : 0);
    info_[4].store(got);
    info_[5].store(mode);
    stream_ = std::move(stream);
    return true;
  }

  void closeLocked() {
    if (stream_) {
      stream_->requestStop();
      stream_->close();
      stream_.reset();
    }
  }

  Engine engine_;
  std::mutex mutex_;
  std::shared_ptr<oboe::AudioStream> stream_;
  bool wanted_ = false;
  uint32_t cb_ = 0;
  int32_t lastXrun_ = 0;
  std::atomic<int32_t> info_[6] = {{0}, {0}, {0}, {0}, {0}, {0}};
  int reqMode_ = 0, reqDevice_ = 0;
  std::atomic<int> effMode_{0};
  std::unique_ptr<float[]> master_, hp_;
};

}  // namespace djf
