// Liga o motor (core/engine) a uma saída de áudio Oboe de baixa latência.
// Este é o único arquivo que depende do Oboe.
#pragma once
#include <oboe/Oboe.h>

#include <android/log.h>

#if defined(__SSE__)
#include <xmmintrin.h>
#endif
#include <algorithm>
#include <atomic>
#include <memory>
#include <mutex>

#include "core/engine.h"

namespace djf {

constexpr int kEngineRate = 48000;   // todas as faixas são decodificadas nesta taxa
constexpr int kMaxBlockFrames = 4096;

// Fila de áudio entre a saída principal e a segunda saída ("tocar também no celular"). Um escritor (a thread
// da saída principal) e um leitor (a da segunda saída), sem trava. Os relógios das duas placas diferem um pouco:
// o leitor descarta ou completa com silêncio para manter o atraso pequeno e estável.
class MirrorRing {
 public:
  static constexpr int kCap = 1 << 15;        // quadros estéreo (~0,7 s)
  void reset() { w_.store(0); r_.store(0); }
  void write(const float* stereo, int frames) {
    int64_t w = w_.load(std::memory_order_relaxed);
    for (int i = 0; i < frames; ++i) {
      const int64_t k = (w + i) & (kCap - 1);
      buf_[2 * k] = stereo[2 * i];
      buf_[2 * k + 1] = stereo[2 * i + 1];
    }
    w_.store(w + frames, std::memory_order_release);
  }
  // Lê [frames] quadros para [out] com [ch] canais (estéreo nos dois primeiros).
  void read(float* out, int frames, int ch, int target) {
    const int64_t w = w_.load(std::memory_order_acquire);
    int64_t r = r_.load(std::memory_order_relaxed);
    int64_t avail = w - r;
    if (avail > kCap - 4096 || avail < 0) { r = w - target; avail = target; }        // atrasou demais: pula
    else if (avail > target * 2 + frames) { r += avail - target; avail = target; }   // deriva: volta ao alvo
    for (int i = 0; i < frames; ++i) {
      float* o = out + static_cast<size_t>(i) * ch;
      if (i < avail) {
        const int64_t k = (r + i) & (kCap - 1);
        o[0] = buf_[2 * k];
        o[1] = ch > 1 ? buf_[2 * k + 1] : 0.f;
        if (ch == 1) o[0] = 0.5f * (buf_[2 * k] + buf_[2 * k + 1]);
      } else {
        o[0] = 0.f; if (ch > 1) o[1] = 0.f;
      }
      for (int c = 2; c < ch; ++c) o[c] = 0.f;
    }
    r_.store(r + std::min<int64_t>(avail, frames), std::memory_order_release);
  }

 private:
  float buf_[2 * kCap] = {};
  std::atomic<int64_t> w_{0}, r_{0};
};

class AudioHost : public oboe::AudioStreamDataCallback,
                  public oboe::AudioStreamErrorCallback,
                  public std::enable_shared_from_this<AudioHost> {
 public:
  AudioHost() : engine_(kEngineRate, kMaxBlockFrames) {}

  Engine& engine() { return engine_; }

  bool start() {
    std::lock_guard<std::mutex> lock(mutex_);
    wanted_ = true;
    if (stream_) return true;
    return openLocked();
  }

  void stop() {
    std::lock_guard<std::mutex> lock(mutex_);
    wanted_ = false;
    closeLocked();
  }

  // out: [taxa real, quadros por rajada, tamanho do buffer em quadros, 1 se exclusivo, canais, modo efetivo,
  //       aparelho aberto, 1 se a segunda saída toca]
  void info(int32_t out[8]) const {
    for (int i = 0; i < 7; ++i) out[i] = info_[i].load(std::memory_order_relaxed);
    out[7] = mirrorActive_.load(std::memory_order_relaxed) ? 1 : 0;
  }

  // Saída do fone. mode: 0 = só som geral em estéreo; 1 = dividido (esquerdo = fone, direito = som geral, em mono);
  // 2 = quatro canais (1-2 som geral, 3-4 fone). deviceId: aparelho de saída (0 = o padrão do Android).
  // Se o aparelho não aceitar quatro canais, cai para o modo 1; se não abrir de jeito nenhum, volta ao padrão.
  // mirrorDevice: segunda saída que toca junto (0 = nenhuma); mirrorWhat: 0 = som geral, 1 = fone (pré-escuta).
  void configureOutput(int mode, int deviceId, int mirrorDevice = 0, int mirrorWhat = 0) {
    std::lock_guard<std::mutex> lock(mutex_);
    reqMode_ = mode < 0 || mode > 2 ? 0 : mode;
    reqDevice_ = deviceId < 0 ? 0 : deviceId;
    reqMirror_ = mirrorDevice < 0 ? 0 : mirrorDevice;
    mirrorWhat_.store(mirrorWhat == 1 ? 1 : 0, std::memory_order_relaxed);
    if (wanted_) {
      closeLocked();
      openLocked();
    }
  }

  // 1 se a segunda saída está tocando.
  bool mirrorOn() const { return mirrorStream_ != nullptr; }

  oboe::DataCallbackResult onAudioReady(oboe::AudioStream* st, void* audioData, int32_t numFrames) override {
    flushDenormals();
    float* out = static_cast<float*>(audioData);
    const int mode = effMode_.load(std::memory_order_relaxed);
    const int ch = st->getChannelCount();
    const bool mirror = mirrorActive_.load(std::memory_order_acquire);
    const bool wantHp = mode != 0 || (mirror && mirrorWhat_.load(std::memory_order_relaxed) == 1);
    int done = 0;
    while (done < numFrames) {
      const int n = std::min(numFrames - done, kMaxBlockFrames);
      engine_.render(master_.get(), n, wantHp ? hp_.get() : nullptr);
      for (int i = 0; i < n; ++i) {
        const float mL = master_[2 * i], mR = master_[2 * i + 1];
        const float hL = wantHp ? hp_[2 * i] : 0.f, hR = wantHp ? hp_[2 * i + 1] : 0.f;
        float* o = out + static_cast<size_t>(done + i) * ch;
        if (mode == 0 || ch < 2) {
          o[0] = ch == 1 ? 0.5f * (mL + mR) : mL;
          if (ch > 1) o[1] = mR;
          for (int c = 2; c < ch; ++c) o[c] = 0.f;
        } else if (mode == 1 || ch < 4) {
          o[0] = 0.5f * (hL + hR);
          o[1] = 0.5f * (mL + mR);
          for (int c = 2; c < ch; ++c) o[c] = 0.f;
        } else {
          o[0] = mL; o[1] = mR; o[2] = hL; o[3] = hR;
          for (int c = 4; c < ch; ++c) o[c] = 0.f;
        }
      }
      if (mirror) ring_.write(mirrorWhat_.load(std::memory_order_relaxed) == 1 ? hp_.get() : master_.get(), n);
      done += n;
    }
    // Se houve underrun, aumenta o buffer (mais folga, um pouco mais de latência) até estabilizar.
    if ((++cb_ & 31) == 0) {
      auto x = st->getXRunCount();
      if (x.error() == oboe::Result::OK && x.value() > lastXrun_) {
        lastXrun_ = x.value();
        int32_t burst = st->getFramesPerBurst();
        int32_t want = std::min(st->getBufferSizeInFrames() + burst, st->getBufferCapacityInFrames());
        st->setBufferSizeInFrames(want);
        info_[2].store(st->getBufferSizeInFrames(), std::memory_order_relaxed);
      }
    }
    return oboe::DataCallbackResult::Continue;
  }

  // Números minúsculos (caudas de filtro, eco e reverb) são lentíssimos em CPU ARM e causam engasgos.
  // Pedimos ao processador que os trate como zero, nesta thread de áudio.
  static void flushDenormals() {
#if defined(__aarch64__)
    uint64_t fpcr;
    asm volatile("mrs %0, fpcr" : "=r"(fpcr));
    if (!(fpcr & (1ull << 24))) {
      fpcr |= (1ull << 24);
      asm volatile("msr fpcr, %0" : : "r"(fpcr));
    }
#elif defined(__SSE__)
    _MM_SET_FLUSH_ZERO_MODE(_MM_FLUSH_ZERO_ON);
#endif
  }

  // Fone desligado, USB removido ou rota trocada: o Oboe fecha o fluxo e avisa aqui. Reabrimos.
  void onErrorAfterClose(oboe::AudioStream*, oboe::Result error) override {
    __android_log_print(ANDROID_LOG_WARN, "DJFusion", "erro de áudio: %s", oboe::convertToText(error));
    std::unique_lock<std::mutex> lock(mutex_, std::try_to_lock);
    if (!lock.owns_lock()) return;  // stop() está em andamento
    stream_.reset();
    mirrorActive_.store(false, std::memory_order_release);
    if (mirrorStream_) { mirrorStream_->requestStop(); mirrorStream_->close(); mirrorStream_.reset(); }
    if (wanted_) openLocked();
  }

 private:
  bool openLocked() {
    if (!master_) {
      master_.reset(new float[2 * kMaxBlockFrames]());
      hp_.reset(new float[2 * kMaxBlockFrames]());
    }
    // Tentativas, da preferida para a mais simples.
    struct Try { int mode; int device; int channels; };
    Try tries[4];
    int nt = 0;
    if (reqMode_ == 2 && reqDevice_ != 0) tries[nt++] = {2, reqDevice_, 4};
    if (reqMode_ >= 1 && reqDevice_ != 0) tries[nt++] = {1, reqDevice_, 2};
    if (reqMode_ == 0 && reqDevice_ != 0) tries[nt++] = {0, reqDevice_, 2};
    if (reqMode_ >= 1) tries[nt++] = {1, 0, 2};
    tries[nt++] = {0, 0, 2};
    bool ok = false;
    for (int k = 0; k < nt && !ok; ++k) ok = openWith(tries[k].mode, tries[k].device, tries[k].channels);
    if (ok && reqMirror_ != 0 && reqMirror_ != info_[6].load()) openMirrorLocked();
    return ok;
  }

  // Segunda saída: lê da fila o que a principal tocou (som geral ou fone).
  class MirrorCb : public oboe::AudioStreamDataCallback {
   public:
    explicit MirrorCb(AudioHost* h) : h_(h) {}
    oboe::DataCallbackResult onAudioReady(oboe::AudioStream* st, void* data, int32_t frames) override {
      const int target = std::max(1024, st->getFramesPerBurst() * 4);
      h_->ring_.read(static_cast<float*>(data), frames, st->getChannelCount(), target);
      return oboe::DataCallbackResult::Continue;
    }
   private:
    AudioHost* h_;
  };

  void openMirrorLocked() {
    if (!mirrorCb_) mirrorCb_ = std::make_shared<MirrorCb>(this);
    oboe::AudioStreamBuilder b;
    b.setDirection(oboe::Direction::Output)
        ->setPerformanceMode(oboe::PerformanceMode::LowLatency)
        ->setSharingMode(oboe::SharingMode::Shared)
        ->setFormat(oboe::AudioFormat::Float)
        ->setChannelCount(2)
        ->setSampleRate(kEngineRate)
        ->setSampleRateConversionQuality(oboe::SampleRateConversionQuality::Medium)
        ->setUsage(oboe::Usage::Media)
        ->setContentType(oboe::ContentType::Music)
        ->setDeviceId(reqMirror_)
        ->setDataCallback(mirrorCb_);
    std::shared_ptr<oboe::AudioStream> st;
    if (b.openStream(st) != oboe::Result::OK) {
      __android_log_print(ANDROID_LOG_WARN, "DJFusion", "segunda saída (aparelho %d) não abriu", reqMirror_);
      return;
    }
    ring_.reset();
    mirrorActive_.store(true, std::memory_order_release);
    if (st->requestStart() != oboe::Result::OK) {
      mirrorActive_.store(false);
      st->close();
      return;
    }
    mirrorStream_ = std::move(st);
  }

  bool openWith(int mode, int device, int channels) {
    oboe::AudioStreamBuilder builder;
    builder.setDirection(oboe::Direction::Output)
        ->setPerformanceMode(oboe::PerformanceMode::LowLatency)
        ->setSharingMode(oboe::SharingMode::Exclusive)
        ->setFormat(oboe::AudioFormat::Float)
        ->setChannelCount(channels)
        ->setSampleRate(kEngineRate)
        ->setSampleRateConversionQuality(oboe::SampleRateConversionQuality::Medium)
        ->setUsage(oboe::Usage::Media)
        ->setContentType(oboe::ContentType::Music)
        ->setDataCallback(shared_from_this())
        ->setErrorCallback(shared_from_this());
    if (device != 0) builder.setDeviceId(device);
    std::shared_ptr<oboe::AudioStream> stream;
    oboe::Result r = builder.openStream(stream);
    if (r != oboe::Result::OK) {
      __android_log_print(ANDROID_LOG_WARN, "DJFusion", "não abriu o áudio (modo %d, aparelho %d, %d canais): %s",
                          mode, device, channels, oboe::convertToText(r));
      return false;
    }
    const int got = stream->getChannelCount();
    if (mode == 2 && got < 4) mode = 1;
    if (mode == 1 && got < 2) mode = 0;
    effMode_.store(mode, std::memory_order_relaxed);
    // Começa com folga generosa (6 rajadas); para DJ, estabilidade vale mais que 5 ms a menos.
    stream->setBufferSizeInFrames(std::min(stream->getFramesPerBurst() * 6, stream->getBufferCapacityInFrames()));
    cb_ = 0;
    lastXrun_ = 0;
    r = stream->requestStart();
    if (r != oboe::Result::OK) {
      __android_log_print(ANDROID_LOG_ERROR, "DJFusion", "não iniciou o áudio: %s", oboe::convertToText(r));
      stream->close();
      return false;
    }
    info_[0].store(stream->getSampleRate());
    info_[1].store(stream->getFramesPerBurst());
    info_[2].store(stream->getBufferSizeInFrames());
    info_[3].store(stream->getSharingMode() == oboe::SharingMode::Exclusive ? 1 : 0);
    info_[4].store(got);
    info_[5].store(mode);
    info_[6].store(stream->getDeviceId());
    stream_ = std::move(stream);
    return true;
  }

  void closeLocked() {
    mirrorActive_.store(false, std::memory_order_release);
    if (mirrorStream_) {
      mirrorStream_->requestStop();
      mirrorStream_->close();
      mirrorStream_.reset();
    }
    if (stream_) {
      stream_->requestStop();
      stream_->close();
      stream_.reset();
    }
  }

  Engine engine_;
  std::mutex mutex_;
  std::shared_ptr<oboe::AudioStream> stream_;
  bool wanted_ = false;
  uint32_t cb_ = 0;
  int32_t lastXrun_ = 0;
  std::atomic<int32_t> info_[7] = {{0}, {0}, {0}, {0}, {0}, {0}, {0}};
  int reqMode_ = 0, reqDevice_ = 0, reqMirror_ = 0;
  std::atomic<int> mirrorWhat_{0};
  std::atomic<bool> mirrorActive_{false};
  MirrorRing ring_;
  std::shared_ptr<MirrorCb> mirrorCb_;
  std::shared_ptr<oboe::AudioStream> mirrorStream_;
  std::atomic<int> effMode_{0};
  std::unique_ptr<float[]> master_, hp_;
};

}  // namespace djf
