// Nível de energia da faixa (0 a 1), parecido com o "energy level" do Mixed In Key: volume, densidade de
// ataques e brilho do trecho central. Serve para o AUTO DJ e o HARMONIZAR montarem uma curva de energia.
#pragma once
#include <algorithm>
#include <cmath>
#include <vector>

#include "track.h"

namespace djf {

// Devolve -1 se a faixa é curta ou silenciosa demais.
inline float analyzeEnergy(const Track& t) {
  const int sr = t.sampleRate > 0 ? t.sampleRate : 48000;
  const int64_t win = sr / 50;                       // 20 ms
  if (t.frames < static_cast<int64_t>(sr) * 5) return -1.f;   // menos de 5 s: não mede
  const int64_t a = t.frames * 15 / 100, b = t.frames * 85 / 100;
  const float k = 1.f / 32768.f;
  double sumRms = 0, sumDiff = 0;
  int frames = 0, onsets = 0;
  double hist[8] = {0, 0, 0, 0, 0, 0, 0, 0};
  float prev = 0.f;
  for (int64_t s = a; s + win <= b; s += win) {
    double e = 0, d = 0;
    for (int64_t i = s; i < s + win; ++i) {
      const float m = 0.5f * (t.pcm[static_cast<size_t>(2 * i)] + t.pcm[static_cast<size_t>(2 * i + 1)]) * k;
      e += static_cast<double>(m) * m;
      const float df = m - prev;
      d += static_cast<double>(df) * df;
      prev = m;
    }
    const double rms = std::sqrt(e / static_cast<double>(win));
    double avg = 0;
    for (double h : hist) avg += h;
    avg /= 8.0;
    if (frames >= 8 && rms > 1.6 * avg && rms > 0.01) ++onsets;
    hist[frames % 8] = rms;
    sumRms += rms;
    sumDiff += std::sqrt(d / static_cast<double>(win));
    ++frames;
  }
  if (frames == 0) return -1.f;
  const double meanRms = sumRms / frames;
  if (meanRms < 1e-4) return -1.f;
  const double db = 20.0 * std::log10(meanRms);
  const double secs = static_cast<double>(frames) * win / sr;
  const double L = std::clamp((db + 30.0) / 22.0, 0.0, 1.0);             // -30 dBFS .. -8 dBFS
  const double D = std::clamp((onsets / secs) / 4.0, 0.0, 1.0);          // 0 .. 4 ataques por segundo
  const double B = std::clamp(((sumDiff / frames) / meanRms - 0.05) / 0.45, 0.0, 1.0);
  return static_cast<float>(0.55 * L + 0.25 * D + 0.20 * B);
}

// Volume médio da faixa em dBFS (RMS em blocos de 400 ms, ignorando silêncio e trechos bem mais baixos que a
// média, como no LUFS). Devolve 0 se não deu para medir (curta ou silenciosa).
inline float analyzeLoudness(const Track& t) {
  const int sr = t.sampleRate > 0 ? t.sampleRate : 48000;
  const int64_t win = sr * 2 / 5;
  if (t.frames < win * 4) return 0.f;
  const float k = 1.f / 32768.f;
  std::vector<double> blocks;
  blocks.reserve(static_cast<size_t>(t.frames / win));
  for (int64_t s = 0; s + win <= t.frames; s += win) {
    double e = 0;
    for (int64_t i = s; i < s + win; ++i) {
      const float l = t.pcm[static_cast<size_t>(2 * i)] * k, r = t.pcm[static_cast<size_t>(2 * i + 1)] * k;
      e += 0.5 * (static_cast<double>(l) * l + static_cast<double>(r) * r);
    }
    e /= static_cast<double>(win);
    if (e > 3.2e-5) blocks.push_back(e);               // > -45 dBFS
  }
  if (blocks.empty()) return 0.f;
  double m = 0;
  for (double e : blocks) m += e;
  m /= static_cast<double>(blocks.size());
  double g = 0; int n = 0;
  for (double e : blocks) if (e > m * 0.1) { g += e; ++n; }   // portão relativo de -10 dB
  if (n == 0) return 0.f;
  return static_cast<float>(10.0 * std::log10(g / n));
}

}  // namespace djf
