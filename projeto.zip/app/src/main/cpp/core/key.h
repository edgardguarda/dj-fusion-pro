// Detecção de tonalidade (tom e modo) de uma faixa, feita uma vez fora do tempo real.
//
// Método: espectro (FFT 8192 a 12 kHz) de ~100 s do meio da faixa, cada bin vira uma das 12 notas (cromagrama),
// com compressão do volume por quadro; compara-se com os perfis de Krumhansl para os 24 tons possíveis.
// Funciona bem em música com harmonia clara; em música só de percussão ou ruído devolve confiança baixa.
#pragma once
#include <algorithm>
#include <cmath>
#include <complex>
#include <cstdint>
#include <vector>

#include "track.h"

namespace djf {

struct KeyResult {
  bool valid = false;
  int tonic = 0;        // 0 = Dó, 1 = Dó#, ... 11 = Si
  bool minor = false;
  float confidence = 0; // 0 a 1
  float rBest = 0;      // correlação com o melhor perfil (diagnóstico)
};

namespace key_detail {
inline void fft(std::vector<std::complex<float>>& a) {
  const size_t n = a.size();
  for (size_t i = 1, j = 0; i < n; ++i) {
    size_t bit = n >> 1;
    for (; j & bit; bit >>= 1) j ^= bit;
    j ^= bit;
    if (i < j) std::swap(a[i], a[j]);
  }
  for (size_t len = 2; len <= n; len <<= 1) {
    const float ang = -6.28318530717958648f / static_cast<float>(len);
    const std::complex<float> wl(std::cos(ang), std::sin(ang));
    for (size_t i = 0; i < n; i += len) {
      std::complex<float> w(1.f, 0.f);
      for (size_t k = 0; k < len / 2; ++k) {
        const std::complex<float> u = a[i + k], v = a[i + k + len / 2] * w;
        a[i + k] = u + v;
        a[i + k + len / 2] = u - v;
        w *= wl;
      }
    }
  }
}

inline double pearson(const double* x, const double* y) {
  double mx = 0, my = 0;
  for (int i = 0; i < 12; ++i) { mx += x[i]; my += y[i]; }
  mx /= 12; my /= 12;
  double sxy = 0, sxx = 0, syy = 0;
  for (int i = 0; i < 12; ++i) {
    sxy += (x[i] - mx) * (y[i] - my);
    sxx += (x[i] - mx) * (x[i] - mx);
    syy += (y[i] - my) * (y[i] - my);
  }
  return (sxx > 0 && syy > 0) ? sxy / std::sqrt(sxx * syy) : 0.0;
}
}  // namespace key_detail

inline KeyResult analyzeKey(const Track& t) {
  using namespace key_detail;
  KeyResult res;
  constexpr int kDec = 4, kN = 8192, kHopS = 4096;
  const double rate = static_cast<double>(t.sampleRate) / kDec;
  if (t.frames < static_cast<int64_t>(8) * t.sampleRate || t.sampleRate < 8000) return res;
  const int64_t maxFrames = static_cast<int64_t>(100) * t.sampleRate;
  const int64_t from = t.frames > maxFrames ? (t.frames - maxFrames) / 2 : 0;
  const int64_t to = std::min(t.frames, from + maxFrames);
  // mono a 12 kHz (média de 4 amostras: filtro simples contra aliasing)
  std::vector<float> mono;
  mono.reserve(static_cast<size_t>((to - from) / kDec) + 1);
  for (int64_t i = from; i + kDec <= to; i += kDec) {
    float s = 0;
    for (int k = 0; k < kDec; ++k) s += static_cast<float>(t.pcm[2 * (i + k)]) + static_cast<float>(t.pcm[2 * (i + k) + 1]);
    mono.push_back(s / (kDec * 2 * 32768.f));
  }
  if (mono.size() < static_cast<size_t>(kN)) return res;

  std::vector<float> win(kN);
  for (int i = 0; i < kN; ++i) win[i] = 0.5f - 0.5f * std::cos(6.28318530717958648f * i / kN);
  // Só os PICOS do espectro contam (notas e harmônicos são picos; chimbal, caixa e ruído são largos e viram quase nada),
  // e a afinação da faixa é estimada a partir deles (muita música não está em 440 Hz, o que espalhava a nota entre duas).
  struct Peak { float midi; float w; int frame; };
  std::vector<Peak> peaks;
  std::vector<std::complex<float>> buf(kN);
  std::vector<float> mag(kN / 2 + 1);
  int frameNo = 0;
  const int bLo = static_cast<int>(std::ceil(70.0 * kN / rate)), bHi = static_cast<int>(std::floor(1800.0 * kN / rate));
  for (size_t start = 0; start + kN <= mono.size(); start += kHopS, ++frameNo) {
    for (int i = 0; i < kN; ++i) buf[i] = std::complex<float>(mono[start + i] * win[i], 0.f);
    fft(buf);
    float top = 0.f;
    for (int b = 0; b <= kN / 2; ++b) { mag[b] = std::abs(buf[b]); if (b >= bLo && b <= bHi) top = std::max(top, mag[b]); }
    if (top < 1e-3f) continue;  // silêncio
    for (int b = std::max(bLo, 2); b <= std::min(bHi, kN / 2 - 1); ++b) {
      const float m = mag[b];
      if (m < 0.02f * top || m <= mag[b - 1] || m < mag[b + 1]) continue;
      // interpolação parabólica: frequência do pico com precisão menor que um bin
      const float a0 = std::log(mag[b - 1] + 1e-9f), a1 = std::log(m + 1e-9f), a2 = std::log(mag[b + 1] + 1e-9f);
      const float den = a0 - 2 * a1 + a2;
      const float d = den < -1e-6f ? std::clamp(0.5f * (a0 - a2) / den, -0.5f, 0.5f) : 0.f;
      const double f = (b + d) * rate / kN;
      peaks.push_back({static_cast<float>(69.0 + 12.0 * std::log2(f / 440.0)), std::sqrt(m / top), frameNo});
    }
  }
  if (peaks.empty()) return res;
  // afinação: média circular do desvio (em notas) dos picos em relação à nota mais próxima
  double sx = 0, sy = 0;
  for (const Peak& p : peaks) { const double ang = 6.28318530717958648 * (p.midi - std::round(p.midi)); sx += p.w * std::cos(ang); sy += p.w * std::sin(ang); }
  const double tuning = std::atan2(sy, sx) / 6.28318530717958648;   // -0,5 .. 0,5 nota
  double chroma[12] = {0};
  {
    // cada quadro pesa igual (normaliza pela soma do quadro)
    std::vector<double> frameSum(static_cast<size_t>(frameNo) + 1, 0.0);
    for (const Peak& p : peaks) frameSum[static_cast<size_t>(p.frame)] += p.w;
    for (const Peak& p : peaks) {
      const int n = ((static_cast<int>(std::lround(p.midi - tuning)) % 12) + 12) % 12;
      chroma[n] += p.w / frameSum[static_cast<size_t>(p.frame)];
    }
  }
  double tot = 0;
  for (int n = 0; n < 12; ++n) tot += chroma[n];
  if (tot <= 0) return res;

  static const double kMaj[12] = {6.35, 2.23, 3.48, 2.33, 4.38, 4.09, 2.52, 5.19, 2.39, 3.66, 2.29, 2.88};
  static const double kMin[12] = {6.33, 2.68, 3.52, 5.38, 2.60, 3.53, 2.54, 4.75, 3.98, 2.69, 3.34, 3.17};
  double best = -2, second = -2;
  int bestTonic = 0;
  bool bestMinor = false;
  for (int minor = 0; minor < 2; ++minor) {
    for (int tonic = 0; tonic < 12; ++tonic) {
      double prof[12];
      for (int n = 0; n < 12; ++n) prof[(n + tonic) % 12] = minor ? kMin[n] : kMaj[n];
      const double r = pearson(chroma, prof);
      if (r > best) { second = best; best = r; bestTonic = tonic; bestMinor = minor == 1; }
      else if (r > second) second = r;
    }
  }
  res.valid = true;
  res.tonic = bestTonic;
  res.minor = bestMinor;
  res.confidence = static_cast<float>(std::clamp((best - 0.40) / 0.35 + 1.0 * (best - second), 0.0, 1.0)); res.rBest = static_cast<float>(best);
  return res;
}

}  // namespace djf
