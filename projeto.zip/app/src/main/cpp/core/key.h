// Detecção de tonalidade (tom e modo) de uma faixa, feita uma vez fora do tempo real.
//
// Método: espectro (FFT 8192 a 12 kHz) de ~100 s do meio da faixa, cada bin vira uma das 12 notas (cromagrama),
// com compressão do volume por quadro; compara-se com os perfis de Krumhansl para os 24 tons possíveis.
// Funciona bem em música com harmonia clara; em música só de percussão ou ruído devolve confiança baixa.
#pragma once
#include <algorithm>
#include <cmath>
#include <complex>
#include <cstdint>
#include <vector>

#include "track.h"

namespace djf {

struct KeyResult {
  bool valid = false;
  int tonic = 0;        // 0 = Dó, 1 = Dó#, ... 11 = Si
  bool minor = false;
  float confidence = 0; // 0 a 1
  float rBest = 0;      // correlação com o melhor perfil (diagnóstico)
};

namespace key_detail {
inline void fft(std::vector<std::complex<float>>& a) {
  const size_t n = a.size();
  for (size_t i = 1, j = 0; i < n; ++i) {
    size_t bit = n >> 1;
    for (; j & bit; bit >>= 1) j ^= bit;
    j ^= bit;
    if (i < j) std::swap(a[i], a[j]);
  }
  for (size_t len = 2; len <= n; len <<= 1) {
    const float ang = -6.28318530717958648f / static_cast<float>(len);
    const std::complex<float> wl(std::cos(ang), std::sin(ang));
    for (size_t i = 0; i < n; i += len) {
      std::complex<float> w(1.f, 0.f);
      for (size_t k = 0; k < len / 2; ++k) {
        const std::complex<float> u = a[i + k], v = a[i + k + len / 2] * w;
        a[i + k] = u + v;
        a[i + k + len / 2] = u - v;
        w *= wl;
      }
    }
  }
}

inline double pearson(const double* x, const double* y) {
  double mx = 0, my = 0;
  for (int i = 0; i < 12; ++i) { mx += x[i]; my += y[i]; }
  mx /= 12; my /= 12;
  double sxy = 0, sxx = 0, syy = 0;
  for (int i = 0; i < 12; ++i) {
    sxy += (x[i] - mx) * (y[i] - my);
    sxx += (x[i] - mx) * (x[i] - mx);
    syy += (y[i] - my) * (y[i] - my);
  }
  return (sxx > 0 && syy > 0) ? sxy / std::sqrt(sxx * syy) : 0.0;
}
}  // namespace key_detail

inline KeyResult analyzeKey(const Track& t) {
  using namespace key_detail;
  KeyResult res;
  constexpr int kDec = 4, kN = 8192, kHopS = 4096;
  const double rate = static_cast<double>(t.sampleRate) / kDec;
  if (t.frames < static_cast<int64_t>(8) * t.sampleRate || t.sampleRate < 8000) return res;
  const int64_t maxFrames = static_cast<int64_t>(100) * t.sampleRate;
  const int64_t from = t.frames > maxFrames ? (t.frames - maxFrames) / 2 : 0;
  const int64_t to = std::min(t.frames, from + maxFrames);
  // mono a 12 kHz (média de 4 amostras: filtro simples contra aliasing)
  std::vector<float> mono;
  mono.reserve(static_cast<size_t>((to - from) / kDec) + 1);
  for (int64_t i = from; i + kDec <= to; i += kDec) {
    float s = 0;
    for (int k = 0; k < kDec; ++k) s += static_cast<float>(t.pcm[2 * (i + k)]) + static_cast<float>(t.pcm[2 * (i + k) + 1]);
    mono.push_back(s / (kDec * 2 * 32768.f));
  }
  if (mono.size() < static_cast<size_t>(kN)) return res;

  std::vector<float> win(kN);
  for (int i = 0; i < kN; ++i) win[i] = 0.5f - 0.5f * std::cos(6.28318530717958648f * i / kN);
  // nota de cada bin (-1 = fora da faixa 70..1800 Hz)
  std::vector<int8_t> binNote(kN / 2, -1);
  std::vector<float> binW(kN / 2, 0.f);
  for (int b = 1; b < kN / 2; ++b) {
    const double f = b * rate / kN;
    if (f < 70.0 || f > 1800.0) continue;
    const double m = 69.0 + 12.0 * std::log2(f / 440.0);
    binNote[b] = static_cast<int8_t>(((static_cast<int>(std::lround(m)) % 12) + 12) % 12);
    binW[b] = 1.f;
  }

  double chroma[12] = {0};
  std::vector<std::complex<float>> buf(kN);
  for (size_t start = 0; start + kN <= mono.size(); start += kHopS) {
    for (int i = 0; i < kN; ++i) buf[i] = std::complex<float>(mono[start + i] * win[i], 0.f);
    fft(buf);
    double frame[12] = {0};
    double total = 0;
    for (int b = 1; b < kN / 2; ++b) {
      if (binNote[b] < 0) continue;
      const double mag = std::abs(buf[b]);
      frame[binNote[b]] += std::sqrt(mag) * binW[b];  // compressão: notas fracas também contam
      total += mag;
    }
    if (total < 1e-3) continue;  // silêncio
    double sum = 0;
    for (int n = 0; n < 12; ++n) sum += frame[n];
    if (sum <= 0) continue;
    for (int n = 0; n < 12; ++n) chroma[n] += frame[n] / sum;  // cada quadro pesa igual
  }
  double tot = 0;
  for (int n = 0; n < 12; ++n) tot += chroma[n];
  if (tot <= 0) return res;

  static const double kMaj[12] = {6.35, 2.23, 3.48, 2.33, 4.38, 4.09, 2.52, 5.19, 2.39, 3.66, 2.29, 2.88};
  static const double kMin[12] = {6.33, 2.68, 3.52, 5.38, 2.60, 3.53, 2.54, 4.75, 3.98, 2.69, 3.34, 3.17};
  double best = -2, second = -2;
  int bestTonic = 0;
  bool bestMinor = false;
  for (int minor = 0; minor < 2; ++minor) {
    for (int tonic = 0; tonic < 12; ++tonic) {
      double prof[12];
      for (int n = 0; n < 12; ++n) prof[(n + tonic) % 12] = minor ? kMin[n] : kMaj[n];
      const double r = pearson(chroma, prof);
      if (r > best) { second = best; best = r; bestTonic = tonic; bestMinor = minor == 1; }
      else if (r > second) second = r;
    }
  }
  res.valid = true;
  res.tonic = bestTonic;
  res.minor = bestMinor;
  res.confidence = static_cast<float>(std::clamp((best - 0.40) / 0.35 + 1.0 * (best - second), 0.0, 1.0)); res.rBest = static_cast<float>(best);
  return res;
}

}  // namespace djf
