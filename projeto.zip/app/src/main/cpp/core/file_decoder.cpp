// Implementação das dr_libs (MP3, FLAC, WAV) e do decodificador por descritor de arquivo.
#define DR_MP3_IMPLEMENTATION
#define DR_FLAC_IMPLEMENTATION
#define DR_WAV_IMPLEMENTATION
#define DR_FLAC_NO_OGG
#if defined(__GNUC__)
#pragma GCC diagnostic push
#pragma GCC diagnostic ignored "-Wunused-function"
#pragma GCC diagnostic ignored "-Wunused-parameter"
#pragma GCC diagnostic ignored "-Wsign-compare"
#pragma GCC diagnostic ignored "-Wimplicit-fallthrough"
#endif
#include "../third_party/dr_mp3.h"
#include "../third_party/dr_flac.h"
#include "../third_party/dr_wav.h"
#if defined(__GNUC__)
#pragma GCC diagnostic pop
#endif

#include "file_decoder.h"

#include <unistd.h>

#include <vector>

namespace djf {

namespace {

struct FdSrc {
  int fd;
  int64_t base;   // posição inicial do descritor (normalmente 0)
};

size_t onRead(void* user, void* out, size_t n) {
  auto* s = static_cast<FdSrc*>(user);
  size_t done = 0;
  while (done < n) {
    const ssize_t r = ::read(s->fd, static_cast<char*>(out) + done, n - done);
    if (r <= 0) break;
    done += static_cast<size_t>(r);
  }
  return done;
}

// As três bibliotecas usam a mesma ideia de "origem" (início, atual, fim) com enums próprios.
template <typename Origin>
int whence(Origin o, Origin set, Origin cur) { return o == set ? SEEK_SET : (o == cur ? SEEK_CUR : SEEK_END); }

int64_t position(int fd) { return static_cast<int64_t>(::lseek(fd, 0, SEEK_CUR)); }

}  // namespace

DecodeOut decodeFile(int fd, FileKind kind, int64_t fileSize, int outRate, int64_t maxFrames,
                     std::atomic<float>* progress, const std::atomic<bool>* cancel) {
  DecodeOut res;
  FdSrc src{fd, position(fd)};
  if (src.base < 0) src.base = 0;
  constexpr size_t kChunk = 4096;
  std::vector<float> buf;
  std::unique_ptr<TrackBuilder> builder;

  auto feed = [&](uint32_t channels, uint32_t rate, auto readFrames) -> bool {
    if (channels < 1 || channels > 32 || rate < 8000 || rate > 384000) {
      res.error = "formato inválido (" + std::to_string(channels) + " canais, " + std::to_string(rate) + " Hz)";
      return false;
    }
    res.channels = static_cast<int>(channels);
    res.srcRate = static_cast<int>(rate);
    builder = std::make_unique<TrackBuilder>(static_cast<int>(rate), outRate, maxFrames);
    buf.resize(kChunk * channels);
    int k = 0;
    while (true) {
      if (cancel && cancel->load(std::memory_order_relaxed)) { res.error = "cancelado"; return false; }
      const uint64_t n = readFrames(buf.data(), kChunk);
      if (n == 0) break;
      builder->appendFloat(buf.data(), static_cast<size_t>(n), static_cast<int>(channels));
      if (builder->tooLong()) { res.tooLong = true; return false; }
      if (progress && fileSize > 0 && (++k & 15) == 0) {
        progress->store(static_cast<float>(std::min(1.0, static_cast<double>(position(fd) - src.base) / fileSize)),
                        std::memory_order_relaxed);
      }
    }
    return true;
  };

  bool ok = false;
  try {
    switch (kind) {
      case FileKind::Mp3: {
        drmp3 mp3;
        auto seek = [](void* u, int off, drmp3_seek_origin o) -> drmp3_bool32 {
          auto* s = static_cast<FdSrc*>(u);
          const int w = whence(o, DRMP3_SEEK_SET, DRMP3_SEEK_CUR);
          const off_t r = ::lseek(s->fd, (w == SEEK_SET ? s->base : 0) + off, w);
          return r >= 0 ? DRMP3_TRUE : DRMP3_FALSE;
        };
        auto tell = [](void* u, drmp3_int64* p) -> drmp3_bool32 {
          auto* s = static_cast<FdSrc*>(u);
          *p = position(s->fd) - s->base;
          return DRMP3_TRUE;
        };
        if (!drmp3_init(&mp3, onRead, seek, tell, nullptr, &src, nullptr)) { res.error = "não é um MP3 válido"; break; }
        ok = feed(mp3.channels, mp3.sampleRate, [&](float* out, uint64_t n) { return drmp3_read_pcm_frames_f32(&mp3, n, out); });
        drmp3_uninit(&mp3);
        break;
      }
      case FileKind::Flac: {
        auto seek = [](void* u, int off, drflac_seek_origin o) -> drflac_bool32 {
          auto* s = static_cast<FdSrc*>(u);
          const int w = whence(o, DRFLAC_SEEK_SET, DRFLAC_SEEK_CUR);
          return ::lseek(s->fd, (w == SEEK_SET ? s->base : 0) + off, w) >= 0 ? DRFLAC_TRUE : DRFLAC_FALSE;
        };
        auto tell = [](void* u, drflac_int64* p) -> drflac_bool32 {
          auto* s = static_cast<FdSrc*>(u);
          *p = position(s->fd) - s->base;
          return DRFLAC_TRUE;
        };
        drflac* f = drflac_open(onRead, seek, tell, &src, nullptr);
        if (!f) { res.error = "não é um FLAC válido"; break; }
        ok = feed(f->channels, f->sampleRate, [&](float* out, uint64_t n) { return drflac_read_pcm_frames_f32(f, n, out); });
        drflac_close(f);
        break;
      }
      case FileKind::Wav: {
        drwav wav;
        auto seek = [](void* u, int off, drwav_seek_origin o) -> drwav_bool32 {
          auto* s = static_cast<FdSrc*>(u);
          const int w = whence(o, DRWAV_SEEK_SET, DRWAV_SEEK_CUR);
          return ::lseek(s->fd, (w == SEEK_SET ? s->base : 0) + off, w) >= 0 ? DRWAV_TRUE : DRWAV_FALSE;
        };
        auto tell = [](void* u, drwav_int64* p) -> drwav_bool32 {
          auto* s = static_cast<FdSrc*>(u);
          *p = position(s->fd) - s->base;
          return DRWAV_TRUE;
        };
        if (!drwav_init(&wav, onRead, seek, tell, &src, nullptr)) { res.error = "não é um WAV válido"; break; }
        ok = feed(wav.channels, wav.sampleRate, [&](float* out, uint64_t n) { return drwav_read_pcm_frames_f32(&wav, n, out); });
        drwav_uninit(&wav);
        break;
      }
    }
  } catch (...) {
    res.error = "sem memória";
    ok = false;
  }
  if (!ok || !builder) {
    if (res.error.empty() && !res.tooLong) res.error = "falha ao decodificar";
    return res;
  }
  std::shared_ptr<Track> t = builder->finish();
  if (builder->tooLong()) { res.tooLong = true; return res; }
  if (t->frames <= 0) { res.error = "nenhum áudio no arquivo"; return res; }
  if (progress) progress->store(1.f);
  res.track = std::move(t);
  return res;
}

}  // namespace djf
