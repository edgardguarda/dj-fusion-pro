// Separação de stems (voz, bateria, baixo e o resto) por processamento de sinal, sem rede neural:
//  - STFT (2048 pontos, salto 512, janela raiz de Hann) do canal do meio (L+R)/2 e do lado (L-R)/2;
//  - HPSS (Fitzgerald 2010): mediana no tempo destaca o que é sustentado (harmônico), mediana na frequência
//    destaca o que é ataque (percussivo). Máscaras suaves de Wiener;
//  - bateria = parte percussiva; baixo = parte harmônica abaixo de ~180 Hz;
//  - voz = parte harmônica entre ~250 Hz e ~6 kHz que está no centro do estéreo (onde a voz é mixada);
//  - resto (melodia, teclados, efeitos) = original − voz − bateria − baixo (reconstrução exata).
// Qualidade: boa para tirar/realçar bateria e baixo e para "acapella/instrumental" de músicas com voz central;
// inferior à de modelos de IA (Demucs/Spleeter), que dependem de rede neural pesada.
#pragma once
#include <algorithm>
#include <atomic>
#include <cmath>
#include <complex>
#include <functional>
#include <vector>

#include "key.h"
#include "track.h"

namespace djf {

// Separa e grava em t.stemPcm; publica t.stemsReady. progress(0..1) é chamado de vez em quando.
// Devolve false se cancelado ou faixa curta demais.
inline bool separateStems(const Track& t, const std::function<void(float)>& progress = {},
                          const std::atomic<bool>* cancel = nullptr) {
  constexpr int N = 2048, H = 512, K = N / 2 + 1, MT = 17, MF = 17;
  const int64_t frames = t.frames;
  if (frames < N * 4) return false;
  const int sr = t.sampleRate > 0 ? t.sampleRate : 48000;
  std::vector<float> win(N);
  for (int i = 0; i < N; ++i) win[i] = std::sqrt(0.5f - 0.5f * std::cos(6.28318530717958648f * i / N));

  // pesos por frequência
  std::vector<float> wBass(K), wVoc(K);
  for (int k = 0; k < K; ++k) {
    const float f = static_cast<float>(k) * sr / N;
    wBass[k] = f <= 150.f ? 1.f : (f >= 260.f ? 0.f : (260.f - f) / 110.f);
    float v = f < 180.f ? 0.f : (f < 320.f ? (f - 180.f) / 140.f : 1.f);
    if (f > 6000.f) v *= std::max(0.f, 1.f - (f - 6000.f) / 3000.f);
    wVoc[k] = v;
  }

  const float k16 = 1.f / 32768.f;
  auto mid = [&](int64_t i) -> float {
    if (i < 0 || i >= frames) return 0.f;
    return 0.5f * (t.pcm[static_cast<size_t>(2 * i)] + t.pcm[static_cast<size_t>(2 * i + 1)]) * k16;
  };
  auto side = [&](int64_t i) -> float {
    if (i < 0 || i >= frames) return 0.f;
    return 0.5f * (t.pcm[static_cast<size_t>(2 * i)] - t.pcm[static_cast<size_t>(2 * i + 1)]) * k16;
  };

  // anéis com os últimos MT quadros (espectro do meio, magnitude, e do lado)
  std::vector<std::vector<std::complex<float>>> ringM(MT, std::vector<std::complex<float>>(K));
  std::vector<std::vector<float>> ringMag(MT, std::vector<float>(K)), ringSide(MT, std::vector<float>(K));
  // saída: acumulador OLA de N amostras por stem (0 voz, 1 bateria, 2 baixo)
  std::vector<float> acc[3];
  for (auto& a : acc) a.assign(static_cast<size_t>(N) + H, 0.f);
  std::vector<int16_t> out(static_cast<size_t>(frames) * 3, 0);

  const int64_t first = -(N - H);                         // início do quadro 0 (preenchido com zeros antes)
  const int64_t T = (frames - first) / H + 1;             // quadros de análise
  const int lag = MT / 2;                                 // o quadro do centro da mediana
  std::vector<std::complex<float>> buf(N), bufS(N), syn(N);
  std::vector<float> tmp(std::max(MT, MF));
  std::vector<std::complex<float>> spec[3];
  for (auto& sp : spec) sp.assign(N, {0.f, 0.f});
  int64_t written = 0;                                    // amostras de saída já finalizadas
  const float olaNorm = 1.f / (static_cast<float>(N) * 2.f);   // 1/N da IFFT e soma das janelas = 2

  for (int64_t tf = 0; tf < T + lag; ++tf) {
    if (cancel && cancel->load(std::memory_order_relaxed)) return false;
    // 1) análise do quadro tf (se existir)
    if (tf < T) {
      const int64_t s0 = first + tf * H;
      for (int i = 0; i < N; ++i) {
        buf[i] = {mid(s0 + i) * win[i], 0.f};
        bufS[i] = {side(s0 + i) * win[i], 0.f};
      }
      key_detail::fft(buf);
      key_detail::fft(bufS);
      auto& rm = ringM[tf % MT];
      auto& rg = ringMag[tf % MT];
      auto& rs = ringSide[tf % MT];
      for (int k = 0; k < K; ++k) {
        rm[k] = buf[k];
        rg[k] = std::abs(buf[k]);
        rs[k] = std::abs(bufS[k]);
      }
    } else {
      auto& rg = ringMag[tf % MT];
      std::fill(rg.begin(), rg.end(), 0.f);
    }
    // 2) o quadro c = tf - lag já tem os vizinhos no tempo: calcula as máscaras e sintetiza
    const int64_t c = tf - lag;
    if (c < 0 || c >= T) continue;
    const auto& M = ringM[c % MT];
    const auto& mag = ringMag[c % MT];
    const auto& smag = ringSide[c % MT];
    for (auto& sp : spec) std::fill(sp.begin(), sp.end(), std::complex<float>(0.f, 0.f));
    for (int k = 0; k < K; ++k) {
      // mediana no tempo (harmônico)
      int n = 0;
      for (int j = 0; j < MT; ++j) {
        const int64_t q = c - lag + j;
        if (q < 0 || q >= T) continue;
        tmp[n++] = ringMag[q % MT][k];
      }
      std::nth_element(tmp.begin(), tmp.begin() + n / 2, tmp.begin() + n);
      const float h = tmp[n / 2];
      // mediana na frequência (percussivo)
      n = 0;
      for (int j = -MF / 2; j <= MF / 2; ++j) {
        const int kk = k + j;
        if (kk < 0 || kk >= K) continue;
        tmp[n++] = mag[kk];
      }
      std::nth_element(tmp.begin(), tmp.begin() + n / 2, tmp.begin() + n);
      const float p = tmp[n / 2];
      const float h2 = h * h, p2 = p * p;
      float mp = p2 / (h2 + p2 + 1e-12f);
      // graves: o bumbo é curto e fica nas mesmas frequências do baixo; o que passa muito do nível sustentado
      // (mediana no tempo) é ataque, então vai para a bateria
      if (wBass[k] > 0.f && mag[k] > 1e-9f) {
        const float excess = std::max(0.f, mag[k] - 1.3f * h) / mag[k];
        mp = std::max(mp, excess * wBass[k]);
      }
      const float mh = 1.f - mp;
      const float m2 = mag[k] * mag[k], s2 = smag[k] * smag[k];
      const float center = m2 / (m2 + s2 + 1e-12f);
      const float mVoc = mh * (1.f - wBass[k]) * wVoc[k] * center * center;
      const float mDrum = mp;
      const float mBass = mh * wBass[k];
      spec[0][k] = M[k] * mVoc;
      spec[1][k] = M[k] * mDrum;
      spec[2][k] = M[k] * mBass;
    }
    const int64_t s0 = first + c * H;
    for (int st = 0; st < 3; ++st) {
      // espectro hermitiano -> IFFT por conjugação: ifft(X) = conj(fft(conj(X)))/N
      auto& X = spec[st];
      for (int k = 1; k < N / 2; ++k) X[N - k] = std::conj(X[k]);
      for (int i = 0; i < N; ++i) syn[i] = std::conj(X[i]);
      key_detail::fft(syn);
      // acumula no anel: posição relativa ao início do quadro c
      for (int i = 0; i < N; ++i) {
        const int64_t pos = s0 + i - written;     // 0.. N-1 (o anel começa em 'written')
        if (pos >= 0 && pos < static_cast<int64_t>(acc[st].size())) acc[st][static_cast<size_t>(pos)] += syn[i].real() * win[i] * olaNorm;
      }
    }
    // 3) as primeiras H amostras do anel não recebem mais nada: grava e desloca
    const int64_t ready = s0 + H;                 // tudo antes disso está completo
    while (written < ready) {
      const int64_t take = std::min<int64_t>(H, ready - written);
      for (int st = 0; st < 3; ++st) {
        for (int64_t i = 0; i < take; ++i) {
          const int64_t idx = written + i;
          if (idx >= 0 && idx < frames) {
            const float v = std::max(-1.f, std::min(1.f, acc[st][static_cast<size_t>(i)]));
            out[static_cast<size_t>(idx * 3 + st)] = static_cast<int16_t>(std::lrint(v * 32767.f));
          }
        }
        std::move(acc[st].begin() + take, acc[st].end(), acc[st].begin());
        std::fill(acc[st].end() - take, acc[st].end(), 0.f);
      }
      written += take;
    }
    if (progress && (c & 255) == 0) progress(static_cast<float>(c) / static_cast<float>(T));
  }
  t.stemPcm.swap(out);
  t.stemsReady.store(true, std::memory_order_release);
  if (progress) progress(1.f);
  return true;
}

}  // namespace djf
