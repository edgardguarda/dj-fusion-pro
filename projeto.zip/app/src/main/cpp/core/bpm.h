// Detecção de andamento (BPM) e da primeira batida, feita uma vez ao importar a faixa. Fora do tempo real.
//
// Método: curva de ataques (energia dos graves e do sinal inteiro, só as subidas), autocorrelação com
// intervalo fracionário e uma leve preferência por andamentos perto de 120 BPM, depois a fase da grade
// de batidas. Funciona bem em música com bumbo marcado; em música sem pulso claro devolve confiança baixa.
#pragma once
#include <algorithm>
#include <cmath>
#include <cstdint>
#include <vector>

#include "track.h"

namespace djf {

struct BpmResult {
  double bpm = 0;                // 0 = não detectado
  int64_t firstBeatFrame = 0;    // posição de uma batida, na primeira batida da faixa
  float confidence = 0;          // 0 a 1
};

namespace bpm_detail {
constexpr int kHop = 240;  // 200 valores por segundo na taxa de 48 kHz

inline double lerpAt(const std::vector<float>& v, double x) {
  if (x < 0) return 0;
  const size_t i = static_cast<size_t>(x);
  if (i + 1 >= v.size()) return 0;
  const double f = x - static_cast<double>(i);
  return v[i] * (1.0 - f) + v[i + 1] * f;
}

// score(bpm) = soma de env[t] * env[t + L] (e do dobro de L), só dentro de [a, b)
inline double combScore(const std::vector<float>& env, size_t a, size_t b, double lag) {
  double s = 0;
  for (size_t t = a; t < b; ++t) {
    const float e = env[t];
    if (e <= 0.f) continue;
    s += e * (lerpAt(env, static_cast<double>(t) + lag) + 0.5 * lerpAt(env, static_cast<double>(t) + 2 * lag));
  }
  return s;
}
// Curva de ataques (energia dos graves e do sinal inteiro, só as subidas, sem a média local): 200 valores por segundo.
inline std::vector<float> onsetEnv(const Track& t) {
  const int sr = t.sampleRate;
  const int64_t nHops = t.frames / kHop;
  std::vector<float> env(static_cast<size_t>(nHops), 0.f);
  {
    const double pi = 3.14159265358979323846;
    const double a = 1.0 - std::exp(-2.0 * pi * 150.0 / sr);
    double l1 = 0, l2 = 0, prevLow = 0, prevFull = 0;
    for (int64_t h = 0; h < nHops; ++h) {
      double eLow = 0, eFull = 0;
      const int16_t* p = &t.pcm[static_cast<size_t>(h) * kHop * 2];
      for (int i = 0; i < kHop; ++i) {
        const double m = 0.5 * (p[2 * i] + p[2 * i + 1]) / 32768.0;
        l1 += a * (m - l1);
        l2 += a * (l1 - l2);
        eLow += l2 * l2;
        eFull += m * m;
      }
      eLow /= kHop;
      eFull /= kHop;
      const double lowDb = std::log(1.0 + 3000.0 * eLow);
      const double fullDb = std::log(1.0 + 300.0 * eFull);
      env[static_cast<size_t>(h)] = static_cast<float>(std::max(0.0, lowDb - prevLow) + 0.5 * std::max(0.0, fullDb - prevFull));
      prevLow = lowDb;
      prevFull = fullDb;
    }
    // tira a média local (1 s) para sobrar só o que sobressai
    std::vector<float> smooth(env.size());
    double acc = 0;
    const int w = 100;
    for (size_t i = 0; i < env.size(); ++i) {
      acc += env[i];
      if (i >= static_cast<size_t>(2 * w)) acc -= env[i - 2 * w];
      const size_t n = std::min(i + 1, static_cast<size_t>(2 * w));
      smooth[i] = static_cast<float>(acc / n);
    }
    for (size_t i = 0; i < env.size(); ++i) {
      const size_t j = std::min(env.size() - 1, i + w);  // centraliza a janela
      env[i] = std::max(0.f, env[i] - smooth[j]);
    }
  }

  return env;
}
}  // namespace bpm_detail

inline BpmResult analyzeBpm(const Track& t) {
  using namespace bpm_detail;
  BpmResult res;
  const int sr = t.sampleRate;
  if (sr != 48000 || t.frames < 8LL * sr) return res;
  // 1) curva de ataques
  std::vector<float> env = onsetEnv(t);
  // 2) janela de análise do andamento: até 90 s, no meio da faixa
  const size_t winLen = std::min<size_t>(env.size(), 90 * 200);
  const size_t winA = (env.size() - winLen) / 2, winB = winA + winLen;
  double zero = 0;
  for (size_t i = winA; i < winB; ++i) zero += static_cast<double>(env[i]) * env[i];
  if (zero <= 1e-9) return res;

  auto prior = [](double bpm) {
    const double x = std::log2(bpm / 120.0);
    return std::exp(-0.5 * x * x / 0.8);
  };
  // coarse: autocorrelação em 0,1 BPM
  double bestBpm = 0, bestScore = -1;
  for (double bpm = 60.0; bpm <= 200.0; bpm += 0.1) {
    const double sc = combScore(env, winA, winB - 400, 12000.0 / bpm) * prior(bpm);
    if (sc > bestScore) { bestScore = sc; bestBpm = bpm; }
  }
  // fino: a grade de batidas só fica nítida ao longo de toda a janela se o andamento estiver exato.
  // Para cada candidato (passo de 0,01 BPM) procura a melhor fase e fica com o que soma mais.
  auto gridScore = [&](double bpm, size_t a, size_t b, double* phaseOut) {
    const double period = 12000.0 / bpm;
    double best = -1, bestPh = 0;
    for (double ph = 0; ph < period; ph += 0.25) {
      double s = 0;
      for (double x = ph + std::ceil((static_cast<double>(a) - ph) / period) * period; x < static_cast<double>(b) - 2; x += period)
        s += lerpAt(env, x);
      if (s > best) { best = s; bestPh = ph; }
    }
    if (phaseOut) *phaseOut = bestPh;
    return best;
  };
  double bestGrid = -1, bestPhase = 0;
  for (double bpm = bestBpm - 0.6; bpm <= bestBpm + 0.6; bpm += 0.01) {
    double ph = 0;
    const double g = gridScore(bpm, winA, winB, &ph);
    if (g > bestGrid) { bestGrid = g; bestPhase = ph; bestBpm = bpm; }
  }
  const double bestRaw = combScore(env, winA, winB - 400, 12000.0 / bestBpm);
  while (bestBpm < 75.0) bestBpm *= 2.0;
  while (bestBpm >= 175.0) bestBpm /= 2.0;
  const double period = 12000.0 / bestBpm;
  // a fase é absoluta (em valores da curva desde o início da faixa): leva para a primeira batida
  bestPhase = std::fmod(bestPhase, period);

  res.bpm = bestBpm;
  res.firstBeatFrame = static_cast<int64_t>((bestPhase + 0.5) * kHop);
  res.confidence = static_cast<float>(std::min(1.0, std::max(0.0, bestRaw / zero)));
  return res;
}

// Mapa de andamento: para músicas que mudam de velocidade (montagens, medleys, gravações ao vivo).
// Mede o andamento em janelas de 16 s (passo de 8 s) perto do andamento geral (0,8x a 1,25x) e junta
// janelas vizinhas iguais em trechos. Só marca "variável" quando um trecho de pelo menos 2 janelas
// soa claramente melhor num andamento mais de 1,5% diferente do geral.
struct TempoSection {
  int64_t startFrame = 0;
  double bpm = 0;
  int64_t firstBeatFrame = 0;  // uma batida dentro do trecho (posição absoluta na faixa)
};
struct TempoMap {
  bool variable = false;
  float maxDevPct = 0;  // maior diferença (%) entre um trecho e o andamento geral
  std::vector<TempoSection> sections;
};

inline TempoMap analyzeTempoMap(const Track& t, double globalBpm, int64_t globalFirstBeat) {
  using namespace bpm_detail;
  TempoMap m;
  if (t.sampleRate != 48000 || globalBpm < 40 || t.frames < 40LL * t.sampleRate) return m;
  const std::vector<float> env = onsetEnv(t);
  const size_t W = 16 * 200, H = 8 * 200;
  if (env.size() < W + 400) return m;
  struct Win { size_t a; double bpm; double phase; bool own; };
  std::vector<Win> wins;
  for (size_t a = 0; a + W <= env.size(); a += H) {
    const size_t b = a + W - 400;
    double zero = 0;
    for (size_t i = a; i < a + W; ++i) zero += static_cast<double>(env[i]) * env[i];
    Win w{a, globalBpm, 0, false};
    if (zero > 1e-9) {
      const double atGlobal = combScore(env, a, b, 12000.0 / globalBpm);
      double best = -1, bestBpm = globalBpm;
      for (double bpm = globalBpm * 0.8; bpm <= globalBpm * 1.25; bpm += 0.25) {
        const double sc = combScore(env, a, b, 12000.0 / bpm);
        if (sc > best) { best = sc; bestBpm = bpm; }
      }
      for (double bpm = bestBpm - 0.3; bpm <= bestBpm + 0.3; bpm += 0.02) {
        const double sc = combScore(env, a, b, 12000.0 / bpm);
        if (sc > best) { best = sc; bestBpm = bpm; }
      }
      const double dev = std::fabs(bestBpm / globalBpm - 1.0);
      // precisa soar bem melhor no outro andamento (e o trecho precisa ter pulso)
      if (dev > 0.015 && best > atGlobal * 1.25 && best / zero > 0.15) { w.bpm = bestBpm; w.own = true; }
    }
    wins.push_back(w);
  }
  // janela isolada diferente das vizinhas: provavelmente um engano (break, virada) -> volta ao geral
  for (size_t i = 0; i < wins.size(); ++i) {
    if (!wins[i].own) continue;
    const bool prevSame = i > 0 && wins[i - 1].own && std::fabs(wins[i - 1].bpm / wins[i].bpm - 1.0) < 0.006;
    const bool nextSame = i + 1 < wins.size() && wins[i + 1].own && std::fabs(wins[i + 1].bpm / wins[i].bpm - 1.0) < 0.006;
    if (!prevSame && !nextSame) { wins[i].own = false; wins[i].bpm = globalBpm; }
  }
  // junta em trechos
  for (size_t i = 0; i < wins.size(); ++i) {
    const double bpm = wins[i].bpm;
    if (!m.sections.empty() && std::fabs(m.sections.back().bpm / bpm - 1.0) < 0.006) continue;
    TempoSection s;
    s.startFrame = i == 0 ? 0 : static_cast<int64_t>(wins[i].a + H / 2) * kHop;  // começa no meio da sobreposição
    s.bpm = bpm;
    m.sections.push_back(s);
  }
  // andamento médio e fase de cada trecho, medidos no próprio trecho
  for (size_t k = 0; k < m.sections.size(); ++k) {
    TempoSection& s = m.sections[k];
    const int64_t endFrame = k + 1 < m.sections.size() ? m.sections[k + 1].startFrame : t.frames;
    const size_t a = static_cast<size_t>(s.startFrame / kHop), b = std::min(env.size(), static_cast<size_t>(endFrame / kHop));
    if (std::fabs(s.bpm / globalBpm - 1.0) < 0.006) {
      s.bpm = globalBpm;
      s.firstBeatFrame = globalFirstBeat;
      continue;
    }
    // a borda do trecho é aproximada (±8 s): mede longe dela
    const size_t a2 = k == 0 ? a : std::min(b, a + 1600);
    const size_t b2 = k + 1 < m.sections.size() && b > a2 + 1600 ? b - 800 : b;
    auto grid = [&](double bpm, double* phOut) {
      const double period = 12000.0 / bpm;
      double best = -1, bestPh = 0;
      for (double ph = 0; ph < period; ph += 0.25) {
        double sc = 0;
        for (double x = ph + std::ceil((static_cast<double>(a2) - ph) / period) * period; x < static_cast<double>(b2) - 2; x += period) sc += lerpAt(env, x);
        if (sc > best) { best = sc; bestPh = ph; }
      }
      *phOut = bestPh;
      return best;
    };
    double bestG = -1, bestPh = 0, bestBpm = s.bpm;
    for (double bpm = s.bpm - 0.5; bpm <= s.bpm + 0.5; bpm += 0.02) {
      double ph = 0;
      const double g = grid(bpm, &ph);
      if (g > bestG) { bestG = g; bestPh = ph; bestBpm = bpm; }
    }
    s.bpm = bestBpm;
    s.firstBeatFrame = static_cast<int64_t>((bestPh + 0.5) * kHop);
    m.maxDevPct = std::max(m.maxDevPct, static_cast<float>(std::fabs(s.bpm / globalBpm - 1.0) * 100.0));
  }
  // borda de cada trecho: o ponto (a cada 0,1 s, até 8 s para cada lado) em que a grade de antes
  // deixa de acertar as batidas e a de depois passa a acertar
  auto gridSum = [&](const TempoSection& s, double from, double to) {
    const double period = 12000.0 / s.bpm, ph = static_cast<double>(s.firstBeatFrame) / kHop;
    double sc = 0;
    for (double x = ph + std::ceil((from - ph) / period) * period; x < to; x += period) sc += lerpAt(env, x);
    return sc;
  };
  for (size_t k = 1; k < m.sections.size(); ++k) {
    const double c = static_cast<double>(m.sections[k].startFrame) / kHop;
    double best = -1, bestX = c;
    for (double x = std::max(1.0, c - 1600); x <= std::min(static_cast<double>(env.size()) - 2, c + 1600); x += 20) {
      const double sc = gridSum(m.sections[k - 1], x - 1600, x) + gridSum(m.sections[k], x, x + 1600);
      if (sc > best) { best = sc; bestX = x; }
    }
    m.sections[k].startFrame = static_cast<int64_t>(bestX * kHop);
  }
  m.variable = m.sections.size() > 1 && m.maxDevPct > 1.5f;
  if (!m.variable) m.sections.clear();
  return m;
}

}  // namespace djf
