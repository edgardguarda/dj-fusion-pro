// Detecção de andamento (BPM) e da primeira batida, feita uma vez ao importar a faixa. Fora do tempo real.
//
// Método: curva de ataques (energia dos graves e do sinal inteiro, só as subidas), autocorrelação com
// intervalo fracionário e uma leve preferência por andamentos perto de 120 BPM, depois a fase da grade
// de batidas. Funciona bem em música com bumbo marcado; em música sem pulso claro devolve confiança baixa.
#pragma once
#include <algorithm>
#include <cmath>
#include <cstdint>
#include <vector>

#include "track.h"

namespace djf {

struct BpmResult {
  double bpm = 0;                // 0 = não detectado
  int64_t firstBeatFrame = 0;    // posição de uma batida, na primeira batida da faixa
  float confidence = 0;          // 0 a 1
};

namespace bpm_detail {
constexpr int kHop = 240;  // 200 valores por segundo na taxa de 48 kHz

inline double lerpAt(const std::vector<float>& v, double x) {
  if (x < 0) return 0;
  const size_t i = static_cast<size_t>(x);
  if (i + 1 >= v.size()) return 0;
  const double f = x - static_cast<double>(i);
  return v[i] * (1.0 - f) + v[i + 1] * f;
}

// score(bpm) = soma de env[t] * env[t + L] (e do dobro de L), só dentro de [a, b)
inline double combScore(const std::vector<float>& env, size_t a, size_t b, double lag) {
  double s = 0;
  for (size_t t = a; t < b; ++t) {
    const float e = env[t];
    if (e <= 0.f) continue;
    s += e * (lerpAt(env, static_cast<double>(t) + lag) + 0.5 * lerpAt(env, static_cast<double>(t) + 2 * lag));
  }
  return s;
}
}  // namespace bpm_detail

inline BpmResult analyzeBpm(const Track& t) {
  using namespace bpm_detail;
  BpmResult res;
  const int sr = t.sampleRate;
  if (sr != 48000 || t.frames < 8LL * sr) return res;
  const int64_t nHops = t.frames / kHop;

  // 1) curva de ataques
  std::vector<float> env(static_cast<size_t>(nHops), 0.f);
  {
    const double pi = 3.14159265358979323846;
    const double a = 1.0 - std::exp(-2.0 * pi * 150.0 / sr);
    double l1 = 0, l2 = 0, prevLow = 0, prevFull = 0;
    for (int64_t h = 0; h < nHops; ++h) {
      double eLow = 0, eFull = 0;
      const int16_t* p = &t.pcm[static_cast<size_t>(h) * kHop * 2];
      for (int i = 0; i < kHop; ++i) {
        const double m = 0.5 * (p[2 * i] + p[2 * i + 1]) / 32768.0;
        l1 += a * (m - l1);
        l2 += a * (l1 - l2);
        eLow += l2 * l2;
        eFull += m * m;
      }
      eLow /= kHop;
      eFull /= kHop;
      const double lowDb = std::log(1.0 + 3000.0 * eLow);
      const double fullDb = std::log(1.0 + 300.0 * eFull);
      env[static_cast<size_t>(h)] = static_cast<float>(std::max(0.0, lowDb - prevLow) + 0.5 * std::max(0.0, fullDb - prevFull));
      prevLow = lowDb;
      prevFull = fullDb;
    }
    // tira a média local (1 s) para sobrar só o que sobressai
    std::vector<float> smooth(env.size());
    double acc = 0;
    const int w = 100;
    for (size_t i = 0; i < env.size(); ++i) {
      acc += env[i];
      if (i >= static_cast<size_t>(2 * w)) acc -= env[i - 2 * w];
      const size_t n = std::min(i + 1, static_cast<size_t>(2 * w));
      smooth[i] = static_cast<float>(acc / n);
    }
    for (size_t i = 0; i < env.size(); ++i) {
      const size_t j = std::min(env.size() - 1, i + w);  // centraliza a janela
      env[i] = std::max(0.f, env[i] - smooth[j]);
    }
  }

  // 2) janela de análise do andamento: até 90 s, no meio da faixa
  const size_t winLen = std::min<size_t>(env.size(), 90 * 200);
  const size_t winA = (env.size() - winLen) / 2, winB = winA + winLen;
  double zero = 0;
  for (size_t i = winA; i < winB; ++i) zero += static_cast<double>(env[i]) * env[i];
  if (zero <= 1e-9) return res;

  auto prior = [](double bpm) {
    const double x = std::log2(bpm / 120.0);
    return std::exp(-0.5 * x * x / 0.8);
  };
  // coarse: autocorrelação em 0,1 BPM
  double bestBpm = 0, bestScore = -1;
  for (double bpm = 60.0; bpm <= 200.0; bpm += 0.1) {
    const double sc = combScore(env, winA, winB - 400, 12000.0 / bpm) * prior(bpm);
    if (sc > bestScore) { bestScore = sc; bestBpm = bpm; }
  }
  // fino: a grade de batidas só fica nítida ao longo de toda a janela se o andamento estiver exato.
  // Para cada candidato (passo de 0,01 BPM) procura a melhor fase e fica com o que soma mais.
  auto gridScore = [&](double bpm, size_t a, size_t b, double* phaseOut) {
    const double period = 12000.0 / bpm;
    double best = -1, bestPh = 0;
    for (double ph = 0; ph < period; ph += 0.25) {
      double s = 0;
      for (double x = ph + std::ceil((static_cast<double>(a) - ph) / period) * period; x < static_cast<double>(b) - 2; x += period)
        s += lerpAt(env, x);
      if (s > best) { best = s; bestPh = ph; }
    }
    if (phaseOut) *phaseOut = bestPh;
    return best;
  };
  double bestGrid = -1, bestPhase = 0;
  for (double bpm = bestBpm - 0.6; bpm <= bestBpm + 0.6; bpm += 0.01) {
    double ph = 0;
    const double g = gridScore(bpm, winA, winB, &ph);
    if (g > bestGrid) { bestGrid = g; bestPhase = ph; bestBpm = bpm; }
  }
  const double bestRaw = combScore(env, winA, winB - 400, 12000.0 / bestBpm);
  while (bestBpm < 75.0) bestBpm *= 2.0;
  while (bestBpm >= 175.0) bestBpm /= 2.0;
  const double period = 12000.0 / bestBpm;
  // a fase é absoluta (em valores da curva desde o início da faixa): leva para a primeira batida
  bestPhase = std::fmod(bestPhase, period);

  res.bpm = bestBpm;
  res.firstBeatFrame = static_cast<int64_t>((bestPhase + 0.5) * kHop);
  res.confidence = static_cast<float>(std::min(1.0, std::max(0.0, bestRaw / zero)));
  return res;
}

}  // namespace djf
