// Motor de DJ: dois decks, crossfader e master. C++ puro, sem Android, para ser testado no Linux.
//
// Threads:
//  - controle (UI, MIDI): chama os métodos públicos. Vários produtores são serializados por um mutex
//    (fora do tempo real) e entregam comandos à thread de áudio por uma fila sem trava.
//  - áudio: chama render(). Não aloca, não trava, não faz I/O.
// Toda descontinuidade (pausar, buscar, cue) passa por uma rampa de ganho de ~4 ms até zero, sem estalo.
#pragma once
#include <atomic>
#include <cstdint>
#include <memory>
#include <mutex>
#include <vector>

#include "fx.h"
#include "spsc_queue.h"
#include "track.h"

namespace djf {

class Engine {
 public:
  static constexpr int kDecks = 2;

  struct DeckInfo {
    bool loaded = false;
    bool playing = false;       // intenção de tocar (o áudio sai com rampa de 4 ms)
    int64_t positionFrames = 0;
    int64_t cueFrames = 0;
    int64_t lengthFrames = 0;
    float peak = 0.f;           // 0 a 1, com queda gradual
  };

  Engine(int sampleRate, int maxBlockFrames);

  // ---- thread de controle ----
  // Falha se o deck for inválido ou se a faixa não estiver na taxa do motor. Carregar sobre um deck
  // tocando corta o som na hora: a interface deve impedir isso.
  bool loadTrack(int deck, std::shared_ptr<const Track> track);
  void unload(int deck);
  void play(int deck);
  void pause(int deck);
  // Tocando: volta ao cue e para. Parado: grava a posição atual como cue.
  void cue(int deck);
  void seekFrames(int deck, int64_t frame);
  void setVolume(int deck, float v);      // 0 a 1
  void setCrossfader(float x);            // 0 = só A, 1 = só B, potência constante
  void setMaster(float v);                // 0 a 1
  // Velocidade de reprodução (1 = normal). Muda o tom junto com o andamento, como um prato de vinil.
  void setRate(int deck, float rate);     // limitado a 0 .. 2 (±100%)
  // Equalizador de 3 bandas: band 0 = graves, 1 = médios, 2 = agudos. 0,5 = neutro, 0 = corta, 1 = +6 dB.
  void setEq(int deck, int band, float v);
  // Filtro de DJ: 0,5 = desligado, abaixo = passa-baixas, acima = passa-altas.
  void setFilter(int deck, float v);
  // Repete o trecho [start, end) em quadros. O trecho precisa ter pelo menos 256 quadros.
  void setLoop(int deck, int64_t start, int64_t end);
  void clearLoop(int deck);
  // Efeito do deck: type 0 desligado, 1 eco, 2 flanger, 3 reverb. amount 0..1. beatSeconds ajusta o eco à batida.
  void setFx(int deck, int type, float amount, double beatSeconds);
  // Key-lock: muda o andamento sem mudar o tom (esticamento por grãos com alinhamento de fase, WSOLA).
  void setKeyLock(int deck, bool on);
  // Stems: ganho de 0 a 1 de cada parte (0 voz, 1 bateria, 2 baixo, 3 resto). Só tem efeito depois que a
  // faixa tiver stems separados (Track::stemsReady). Todos em 1 = som original exato.
  void setStemGain(int deck, int stem, float gain);
  // Muda o tom em semitons (-12..12) sem mudar o andamento.
  void setKeyShift(int deck, float semitones);
  // Ganho de entrada (auto-gain), de 0 a 4 (1 = sem mudança), antes do fader.
  void setTrim(int deck, float gain);
  // Scratch: enquanto ativo, a posição segue `velocity` (1 = velocidade normal para frente, negativo = para trás,
  // 0 = mão segurando o prato). Ao soltar, volta ao andamento normal se o deck estava tocando, senão para.
  void scratch(int deck, bool active, float velocity);
  // Fone (PFL): barramento de pré-escuta. O sinal do deck vai ao fone antes do fader e do crossfader.
  void setHeadphoneCue(int deck, bool on);
  void setHeadphoneLevel(float v);        // 0 a 1
  void setHeadphoneMix(float v);          // 0 = só cue, 1 = só master

  // Toca o deck com a batida alinhada à de outro deck que já está tocando (alinhamento feito na thread de áudio,
  // sem a imprecisão do tempo de resposta da interface). `startBeat` = batida (inteira) da faixa onde começar.
  // Se o outro deck não está tocando, começa direto na batida `startBeat`.
  void playSynced(int deck, int refDeck, double refFirstBeat, double refBeatFrames,
                  double firstBeat, double beatFrames, double startBeat);

  // Sampler: 8 pads, cada um com um trecho curto próprio (copiado). Mistura-se ao som geral, passa pelo master.
  static constexpr int kSamples = 8;
  bool loadSample(int slot, std::shared_ptr<const Track> sample);
  void clearSample(int slot);
  // delayFrames > 0: começa depois desse número de quadros (para cair exatamente na batida).
  void triggerSample(int slot, bool loop, int64_t delayFrames = 0);
  // Velocidade do pad (1 = original). Usado para o loop acompanhar o andamento do deck que está tocando.
  void setSampleSpeed(int slot, float speed);
  void stopSample(int slot);
  void setSamplerVolume(float v);         // 0 a 1
  uint32_t samplerPlayingMask() const { return sampMask_.load(std::memory_order_relaxed); }

  // Faixa carregada no deck (referência compartilhada, segura para usar fora do tempo real). Nula se vazio.
  std::shared_ptr<const Track> trackOf(int deck);

  DeckInfo deckInfo(int deck) const;
  float masterPeak() const { return masterPeak_.load(std::memory_order_relaxed); }
  // Libera faixas antigas já substituídas pela thread de áudio.
  void collectGarbage();
  int sampleRate() const { return sr_; }

  // Gravação do som geral (o que sai nas caixas). A thread de áudio copia para um anel sem trava;
  // outra thread lê com readRecorded e grava o arquivo. Se o leitor atrasar, quadros são descartados (contados).
  void setRecording(bool on);
  size_t readRecorded(float* dst, size_t maxFloats);   // devolve quantos floats (estéreo intercalado) copiou
  uint64_t recordDropped() const { return recDropped_.load(std::memory_order_relaxed); }

  // ---- thread de áudio ----
  // `out`: estéreo intercalado, float, `frames` quadros (saída geral). `hp`, se não for nulo, recebe o
  // barramento do fone (estéreo intercalado, mesmo tamanho).
  void render(float* out, int frames, float* hp = nullptr);

 private:
  enum class CmdType : uint8_t { Play, Pause, Cue, Seek, Volume, Crossfader, Master, Load, Rate, Eq, Filter, LoopOn, LoopOff, Fx, KeyLock, Scratch, HpCue, HpLevel, HpMix, PlaySynced, SampLoad, SampPlay, SampStop, SampVol, SampRate, StemGain, KeyShift, Trim };
  struct Cmd {
    CmdType type = CmdType::Play;
    uint8_t deck = 0;
    float f = 0.f;
    int64_t i = 0;
    int64_t j = 0;
    const Track* track = nullptr;
    uint32_t seq = 0;
    double d[4] = {0, 0, 0, 0};
  };

  struct DeckAudio {
    const Track* track = nullptr;
    double pos = 0;             // quadros (fracionário por causa da velocidade)
    int64_t cue = 0;
    int64_t pendingSeek = -1;
    bool wantPlay = false;
    float playGain = 0.f;
    float vol = 1.f;
    float volSm = 1.f;
    float trim = 1.f;
    float trimSm = 1.f;
    float peak = 0.f;
    float rate = 1.f, rateSm = 1.f;
    float eqKnob[3] = {0.5f, 0.5f, 0.5f};
    float eqSm[3] = {0.5f, 0.5f, 0.5f};     // botão suavizado, uma vez por bloco
    bool eqDirty = false;
    // 3 seções biquad em série (prateleira grave, pico médio, prateleira aguda), forma direta II transposta.
    float eqB0[3] = {1, 1, 1}, eqB1[3] = {0, 0, 0}, eqB2[3] = {0, 0, 0}, eqA1[3] = {0, 0, 0}, eqA2[3] = {0, 0, 0};
    float eqZ1[2][3] = {{0, 0, 0}, {0, 0, 0}}, eqZ2[2][3] = {{0, 0, 0}, {0, 0, 0}};
    float filterKnob = 0.5f, filterSm = 0.5f;
    float svfIc1[2] = {0, 0}, svfIc2[2] = {0, 0};
    float svfA1 = 0, svfA2 = 0, svfA3 = 0, svfK = 1.f;
    int filterMode = 0;                     // 0 desligado, 1 passa-baixas, 2 passa-altas
    bool loopOn = false;
    int64_t loopStart = 0, loopEnd = 0;
    DeckFx fx;
    // key-lock
    bool keyLock = false;
    bool stretchReset = true;
    bool stretchSkipSearch = true;
    int hopCount = 0;
    int nextVoice = 0;
    int64_t prevStart = 0;
    int64_t gStart[2] = {0, 0};
    int gPhase[2] = {-1, -1};
    // stems e tom
    float stemTarget[4] = {1.f, 1.f, 1.f, 1.f};
    float stemSm[4] = {1.f, 1.f, 1.f, 1.f};
    const int16_t* stemPtr = nullptr;   // válido durante o bloco
    float stemC[4] = {1.f, 0.f, 0.f, 0.f};   // [resto, voz, bateria, baixo] já combinados
    bool stemActive = false;
    float keyShift = 0.f;               // semitons
    float grainP = 1.f;                 // velocidade de leitura dos grãos (tom)
    // scratch
    bool scratch = false;
    float scratchVel = 0.f, scratchSm = 0.f, scratchGain = 0.f;
    bool cueOn = false;
  };

  struct DeckPub {
    std::atomic<bool> loaded{false};
    std::atomic<bool> playing{false};
    std::atomic<int64_t> pos{0};
    std::atomic<int64_t> cue{0};
    std::atomic<int64_t> length{0};
    std::atomic<float> peak{0.f};
    std::atomic<uint32_t> appliedSeq{0};
  };

  struct Retired {
    std::shared_ptr<const Track> track;
    int deck;        // deck, ou slot do sampler quando sample = true
    uint32_t seq;
    bool sample = false;
  };
  struct SampSlot {
    const Track* track = nullptr;
    bool loop = false;
    bool want = false;
    double pos = 0;
    float gain = 0.f;
    double speed = 1.0;
    int64_t delay = 0;
  };
  static constexpr size_t kRecCap = size_t{1} << 21;   // floats: ~21 s de estéreo a 48 kHz
  std::unique_ptr<float[]> recBuf_;
  std::atomic<size_t> recHead_{0}, recTail_{0};
  std::atomic<bool> recOn_{false};
  std::atomic<uint64_t> recDropped_{0};
  void recordPush(const float* src, int frames);

  bool send(const Cmd& c);
  void drain();
  void renderBlock(float* out, float* hp, int n);
  void stretchRead(DeckAudio& D, float& l, float& r);
  static void frameAt(const DeckAudio& D, int64_t i, float& l, float& r);
  void startGrain(DeckAudio& D);

  const int sr_;
  const int maxBlock_;
  float rampStep_;
  float smoothCoef_;
  float peakDecayPerFrame_;
  void updateEq(DeckAudio& D, int n);

  // lado do áudio
  DeckAudio d_[kDecks];
  float xTarget_ = 0.5f, xSm_ = 0.5f;
  float xCached_ = -1.f, xgC_[2] = {0.f, 0.f};
  float masterTarget_ = 0.9f, masterSm_ = 0.9f;
  float masterPeakLocal_ = 0.f;
  float hpTarget_ = 0.7f, hpSm_ = 0.7f, hpMixTarget_ = 0.f, hpMixSm_ = 0.f;
  float scratchCoef_ = 0.f;
  static constexpr int kGrain = 2048;     // tamanho do grão (~43 ms); salto = metade
  static constexpr int kHop = kGrain / 2;
  float win_[kGrain];

  // publicado para a interface
  DeckPub pub_[kDecks];
  std::atomic<uint32_t> sampSeq_[8];
  std::atomic<uint32_t> sampMask_{0};
  SampSlot s_[8];
  float sampVol_ = 0.8f, sampVolSm_ = 0.8f;
  std::atomic<float> masterPeak_{0.f};

  // lado do controle
  SpscQueue<Cmd, 1024> queue_;
  std::mutex producerMutex_;
  std::shared_ptr<const Track> current_[kDecks];
  uint32_t issued_[kDecks] = {0, 0};
  uint32_t issuedS_[8] = {0, 0, 0, 0, 0, 0, 0, 0};
  std::shared_ptr<const Track> currentS_[8];
  std::vector<Retired> retired_;
};

}  // namespace djf
