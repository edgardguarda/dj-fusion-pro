// Decodificador próprio de MP3, FLAC e WAV (dr_libs, domínio público), igual em qualquer celular.
// Lê direto de um descritor de arquivo, em pedaços, e entrega a faixa já convertida para o motor.
#pragma once
#include <atomic>
#include <cstdint>
#include <memory>
#include <string>

#include "track.h"

namespace djf {

enum class FileKind { Mp3 = 1, Flac = 2, Wav = 3 };

struct DecodeOut {
  std::shared_ptr<Track> track;   // nulo se falhou
  bool tooLong = false;
  std::string error;              // motivo, se falhou
  int srcRate = 0, channels = 0;
};

// fd: descritor aberto para leitura (não é fechado aqui). fileSize em bytes (para o progresso; 0 = desconhecido).
// progress (0..1) e cancel podem ser nulos.
DecodeOut decodeFile(int fd, FileKind kind, int64_t fileSize, int outRate, int64_t maxFrames,
                     std::atomic<float>* progress, const std::atomic<bool>* cancel);

}  // namespace djf
