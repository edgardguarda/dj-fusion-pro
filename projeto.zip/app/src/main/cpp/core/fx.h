// Efeito de deck: eco sincronizado à batida, flanger ou reverb. Um efeito por deck, com mistura (0 a 1).
// Toda a memória é reservada no construtor; process() não aloca. Mistura 0 = som seco exato.
#pragma once
#include <algorithm>
#include <cmath>
#include <vector>

namespace djf {

class DeckFx {
 public:
  enum Type { Off = 0, Echo = 1, Flanger = 2, Reverb = 3 };

  explicit DeckFx(int sampleRate = 48000) : sr_(sampleRate) {
    echoLen_ = sr_ * 2;  // até 2 s de eco
    for (int c = 0; c < 2; ++c) {
      echo_[c].assign(static_cast<size_t>(echoLen_), 0.f);
      flange_[c].assign(static_cast<size_t>(kFlangeLen), 0.f);
    }
    const double s = sr_ / 44100.0;
    static const int combBase[kCombs] = {1116, 1188, 1277, 1356};
    for (int c = 0; c < 2; ++c) {
      for (int i = 0; i < kCombs; ++i) {
        combLen_[c][i] = static_cast<int>((combBase[i] + c * 23) * s);
        comb_[c][i].assign(static_cast<size_t>(combLen_[c][i]), 0.f);
      }
      apLen_[c][0] = static_cast<int>((556 + c * 23) * s);
      apLen_[c][1] = static_cast<int>((441 + c * 23) * s);
      for (int i = 0; i < 2; ++i) ap_[c][i].assign(static_cast<size_t>(apLen_[c][i]), 0.f);
    }
  }

  // Chamado na thread de áudio (ao processar um comando).
  void set(int type, float amount, double beatSeconds) {
    if (type != type_) {
      clear();
      type_ = type;
    }
    target_ = std::min(1.f, std::max(0.f, amount));
    // eco: uma "colcheia pontuada" fica ruim em andamentos lentos; usa 3/4 de batida, limitada a 1,5 s
    echoDelay_ = std::min(1.5, std::max(0.08, beatSeconds * 0.75));
  }

  bool active() const { return type_ != Off && (amount_ > 1e-4f || target_ > 1e-4f); }

  // l, r: amostras de entrada e saída. smooth: coeficiente de suavização por amostra.
  void process(float& l, float& r, float smooth) {
    amount_ += (target_ - amount_) * smooth;
    if (type_ == Off || (amount_ < 1e-4f && target_ < 1e-4f)) return;
    const float in[2] = {l, r};
    float wet[2] = {0.f, 0.f};
    switch (type_) {
      case Echo: {
        const int d = std::min(echoLen_ - 1, std::max(1, static_cast<int>(echoDelay_ * sr_)));
        for (int c = 0; c < 2; ++c) {
          const int rd = (echoPos_ - d + echoLen_) % echoLen_;
          const float y = echo_[c][static_cast<size_t>(rd)];
          echo_[c][static_cast<size_t>(echoPos_)] = in[c] + y * 0.5f;
          wet[c] = y;
        }
        echoPos_ = (echoPos_ + 1) % echoLen_;
        l = in[0] + wet[0] * amount_;
        r = in[1] + wet[1] * amount_;
        break;
      }
      case Flanger: {
        lfo_ += 0.3 / sr_;
        if (lfo_ >= 1.0) lfo_ -= 1.0;
        const float m = 0.5f + 0.5f * static_cast<float>(std::sin(2.0 * 3.14159265358979 * lfo_));
        const float dSamp = (0.001f + 0.005f * m) * static_cast<float>(sr_);  // 1 a 6 ms
        for (int c = 0; c < 2; ++c) {
          float rp = static_cast<float>(flangePos_) - dSamp;
          while (rp < 0) rp += kFlangeLen;
          const int i0 = static_cast<int>(rp);
          const float f = rp - i0;
          const float a = flange_[c][static_cast<size_t>(i0 % kFlangeLen)];
          const float b = flange_[c][static_cast<size_t>((i0 + 1) % kFlangeLen)];
          const float y = a + (b - a) * f;
          flange_[c][static_cast<size_t>(flangePos_)] = in[c] + y * 0.55f;
          wet[c] = y;
        }
        flangePos_ = (flangePos_ + 1) % kFlangeLen;
        l = in[0] + wet[0] * amount_ * 0.8f;
        r = in[1] + wet[1] * amount_ * 0.8f;
        break;
      }
      case Reverb: {
        for (int c = 0; c < 2; ++c) {
          const float x = in[c] * 0.03f;  // ganho de entrada dos filtros de pente
          float sum = 0.f;
          for (int i = 0; i < kCombs; ++i) {
            const int p = combPos_[c][i];
            const float y = comb_[c][i][static_cast<size_t>(p)];
            combLp_[c][i] = y * (1.f - kDamp) + combLp_[c][i] * kDamp;
            comb_[c][i][static_cast<size_t>(p)] = x + combLp_[c][i] * kRoom;
            combPos_[c][i] = (p + 1) % combLen_[c][i];
            sum += y;
          }
          for (int i = 0; i < 2; ++i) {
            const int p = apPos_[c][i];
            const float bufv = ap_[c][i][static_cast<size_t>(p)];
            const float y = -sum + bufv;
            ap_[c][i][static_cast<size_t>(p)] = sum + bufv * 0.5f;
            apPos_[c][i] = (p + 1) % apLen_[c][i];
            sum = y;
          }
          wet[c] = sum * 5.f;
        }
        l = in[0] + wet[0] * amount_;
        r = in[1] + wet[1] * amount_;
        break;
      }
      default:
        break;
    }
  }

 private:
  static constexpr int kCombs = 4;
  static constexpr int kFlangeLen = 1024;
  static constexpr float kRoom = 0.86f;
  static constexpr float kDamp = 0.25f;

  void clear() {
    for (int c = 0; c < 2; ++c) {
      std::fill(echo_[c].begin(), echo_[c].end(), 0.f);
      std::fill(flange_[c].begin(), flange_[c].end(), 0.f);
      for (int i = 0; i < kCombs; ++i) {
        std::fill(comb_[c][i].begin(), comb_[c][i].end(), 0.f);
        combLp_[c][i] = 0.f;
      }
      for (int i = 0; i < 2; ++i) std::fill(ap_[c][i].begin(), ap_[c][i].end(), 0.f);
    }
  }

  int sr_;
  int type_ = Off;
  float target_ = 0.f, amount_ = 0.f;
  double echoDelay_ = 0.375;
  int echoLen_ = 0, echoPos_ = 0;
  std::vector<float> echo_[2];
  std::vector<float> flange_[2];
  int flangePos_ = 0;
  double lfo_ = 0.0;
  std::vector<float> comb_[2][kCombs];
  int combLen_[2][kCombs] = {};
  int combPos_[2][kCombs] = {};
  float combLp_[2][kCombs] = {};
  std::vector<float> ap_[2][2];
  int apLen_[2][2] = {};
  int apPos_[2][2] = {};
};

}  // namespace djf
