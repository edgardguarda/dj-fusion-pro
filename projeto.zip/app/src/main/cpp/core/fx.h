// Efeito de deck: eco, flanger, reverb, trans, bitcrush, phaser, filtro LFO, wobble, tremolo, delay pingue-pongue, stutter e ruído (riser). Um efeito por deck, com mistura (0 a 1).
// Toda a memória é reservada no construtor; process() não aloca. Mistura 0 = som seco exato.
#pragma once
#include <algorithm>
#include <cmath>
#include <cstdint>
#include <vector>

namespace djf {

class DeckFx {
 public:
  enum Type { Off = 0, Echo = 1, Flanger = 2, Reverb = 3, Trans = 4, Crush = 5, Phaser = 6, FilterLfo = 7, Wobble = 8,
              Tremolo = 9, PingPong = 10, Stutter = 11, Noise = 12 };
  static constexpr int kTypes = 13;

  explicit DeckFx(int sampleRate = 48000) : sr_(sampleRate) {
    echoLen_ = sr_ * 2;  // até 2 s de eco
    for (int c = 0; c < 2; ++c) {
      echo_[c].assign(static_cast<size_t>(echoLen_), 0.f);
      flange_[c].assign(static_cast<size_t>(kFlangeLen), 0.f);
    }
    const double s = sr_ / 44100.0;
    static const int combBase[kCombs] = {1116, 1188, 1277, 1356};
    for (int c = 0; c < 2; ++c) {
      for (int i = 0; i < kCombs; ++i) {
        combLen_[c][i] = static_cast<int>((combBase[i] + c * 23) * s);
        comb_[c][i].assign(static_cast<size_t>(combLen_[c][i]), 0.f);
      }
      apLen_[c][0] = static_cast<int>((556 + c * 23) * s);
      apLen_[c][1] = static_cast<int>((441 + c * 23) * s);
      for (int i = 0; i < 2; ++i) ap_[c][i].assign(static_cast<size_t>(apLen_[c][i]), 0.f);
    }
  }

  // Chamado na thread de áudio (ao processar um comando).
  void set(int type, float amount, double beatSeconds) {
    if (type != type_) {
      clear();
      type_ = type;
    }
    target_ = std::min(1.f, std::max(0.f, amount));
    // eco: uma "colcheia pontuada" fica ruim em andamentos lentos; usa 3/4 de batida, limitada a 1,5 s
    echoDelay_ = std::min(1.5, std::max(0.08, beatSeconds * 0.75));
    beat_ = std::min(5.0, std::max(0.1, beatSeconds));
  }

  bool active() const { return type_ != Off && (amount_ > 1e-4f || target_ > 1e-4f); }

  // l, r: amostras de entrada e saída. smooth: coeficiente de suavização por amostra.
  void process(float& l, float& r, float smooth) {
    amount_ += (target_ - amount_) * smooth;
    if (type_ == Off || (amount_ < 1e-4f && target_ < 1e-4f)) return;
    const float in[2] = {l, r};
    float wet[2] = {0.f, 0.f};
    switch (type_) {
      case Echo: {
        const int d = std::min(echoLen_ - 1, std::max(1, static_cast<int>(echoDelay_ * sr_)));
        for (int c = 0; c < 2; ++c) {
          const int rd = (echoPos_ - d + echoLen_) % echoLen_;
          const float y = echo_[c][static_cast<size_t>(rd)];
          // a quantidade controla a mistura e quantas repetições ficam (30% a 70% de retorno)
          echo_[c][static_cast<size_t>(echoPos_)] = in[c] + y * (0.3f + 0.4f * amount_);
          wet[c] = y;
        }
        echoPos_ = (echoPos_ + 1) % echoLen_;
        l = in[0] + wet[0] * amount_ * 1.2f;
        r = in[1] + wet[1] * amount_ * 1.2f;
        break;
      }
      case Flanger: {
        lfo_ += 0.3 / sr_;
        if (lfo_ >= 1.0) lfo_ -= 1.0;
        const float m = 0.5f + 0.5f * static_cast<float>(std::sin(2.0 * 3.14159265358979 * lfo_));
        const float dSamp = (0.001f + 0.005f * m) * static_cast<float>(sr_);  // 1 a 6 ms
        for (int c = 0; c < 2; ++c) {
          float rp = static_cast<float>(flangePos_) - dSamp;
          while (rp < 0) rp += kFlangeLen;
          const int i0 = static_cast<int>(rp);
          const float f = rp - i0;
          const float a = flange_[c][static_cast<size_t>(i0 % kFlangeLen)];
          const float b = flange_[c][static_cast<size_t>((i0 + 1) % kFlangeLen)];
          const float y = a + (b - a) * f;
          flange_[c][static_cast<size_t>(flangePos_)] = in[c] + y * (0.5f + 0.35f * amount_);
          wet[c] = y;
        }
        flangePos_ = (flangePos_ + 1) % kFlangeLen;
        // mistura em partes iguais no máximo: o cancelamento de fase fica bem audível
        l = in[0] * (1.f - 0.3f * amount_) + wet[0] * amount_;
        r = in[1] * (1.f - 0.3f * amount_) + wet[1] * amount_;
        break;
      }
      case Reverb: {
        for (int c = 0; c < 2; ++c) {
          const float x = in[c] * 0.03f;  // ganho de entrada dos filtros de pente
          float sum = 0.f;
          for (int i = 0; i < kCombs; ++i) {
            const int p = combPos_[c][i];
            const float y = comb_[c][i][static_cast<size_t>(p)];
            combLp_[c][i] = y * (1.f - kDamp) + combLp_[c][i] * kDamp;
            comb_[c][i][static_cast<size_t>(p)] = x + combLp_[c][i] * kRoom;
            combPos_[c][i] = (p + 1) % combLen_[c][i];
            sum += y;
          }
          for (int i = 0; i < 2; ++i) {
            const int p = apPos_[c][i];
            const float bufv = ap_[c][i][static_cast<size_t>(p)];
            const float y = -sum + bufv;
            ap_[c][i][static_cast<size_t>(p)] = sum + bufv * 0.5f;
            apPos_[c][i] = (p + 1) % apLen_[c][i];
            sum = y;
          }
          wet[c] = sum * 8.f;
        }
        l = in[0] * (1.f - 0.25f * amount_) + wet[0] * amount_;
        r = in[1] * (1.f - 0.25f * amount_) + wet[1] * amount_;
        break;
      }
      case Trans: {
        // corta o som em 1/4 de batida (liga metade do tempo), com bordas suaves de 3 ms
        transPh_ += 4.0 / (beat_ * sr_);
        if (transPh_ >= 1.0) transPh_ -= 1.0;
        const float open = transPh_ < 0.5 ? 1.f : 0.f;
        transG_ += (open - transG_) * 0.007f;
        const float g = 1.f - amount_ * (1.f - transG_);
        l = in[0] * g;
        r = in[1] * g;
        break;
      }
      case Phaser: {
        // 6 filtros passa-tudo com o centro varrendo no ritmo (uma volta a cada 2 batidas), com realimentação
        phPh_ += 1.0 / (beat_ * 2.0 * sr_);
        if (phPh_ >= 1.0) phPh_ -= 1.0;
        const double lfo = 0.5 + 0.5 * std::sin(2.0 * 3.14159265358979 * phPh_);
        const double fc = 250.0 * std::pow(16.0, lfo);                 // 250 Hz a 4 kHz
        const double t = std::tan(3.14159265358979 * fc / sr_);
        const float a = static_cast<float>((t - 1.0) / (t + 1.0));
        for (int c = 0; c < 2; ++c) {
          float x = in[c] + phFb_[c] * 0.6f * amount_;
          for (int k = 0; k < 6; ++k) {
            const float y = a * x + phZ_[c][k];
            phZ_[c][k] = x - a * y;
            x = y;
          }
          phFb_[c] = x;
          wet[c] = x;
        }
        l = in[0] * (1.f - 0.5f * amount_) + wet[0] * amount_;
        r = in[1] * (1.f - 0.5f * amount_) + wet[1] * amount_;
        break;
      }
      case Crush: {
        // menos bits e menos amostras por segundo conforme a quantidade
        const float levels = std::pow(2.f, 12.f - 10.f * amount_);
        const int hold = 1 + static_cast<int>(amount_ * 15.f);
        if (++crushCnt_ >= hold) {
          crushCnt_ = 0;
          for (int c = 0; c < 2; ++c) crushHold_[c] = std::round(in[c] * levels) / levels;
        }
        l = in[0] + (crushHold_[0] - in[0]) * std::min(1.f, amount_ * 1.5f);
        r = in[1] + (crushHold_[1] - in[1]) * std::min(1.f, amount_ * 1.5f);
        break;
      }
      case FilterLfo: {
        // filtro passa-baixa ressonante varrendo de 200 Hz a 8 kHz, uma ida e volta a cada 2 batidas
        flPh_ += 1.0 / (beat_ * 2.0 * sr_);
        if (flPh_ >= 1.0) flPh_ -= 1.0;
        const double lfo = 0.5 - 0.5 * std::cos(2.0 * 3.14159265358979 * flPh_);
        const double fc = 200.0 * std::pow(40.0, lfo);
        const float f = static_cast<float>(2.0 * std::sin(3.14159265358979 * std::min(fc, sr_ * 0.2) / sr_));
        const float q = 0.35f;   // ressonância (quanto menor, mais "assobio" na frequência de corte)
        for (int c = 0; c < 2; ++c) {
          // filtro de estado variável (Chamberlin): passa-baixa
          svLow_[c] += f * svBand_[c];
          const float high = in[c] - svLow_[c] - q * svBand_[c];
          svBand_[c] += f * high;
          wet[c] = svLow_[c];
        }
        l = in[0] * (1.f - amount_) + wet[0] * amount_;
        r = in[1] * (1.f - amount_) + wet[1] * amount_;
        break;
      }
      case Wobble: {
        // vibrato de fita: atraso de 1 a 7 ms oscilando uma vez por batida (som "derretendo")
        flPh_ += 1.0 / (beat_ * sr_);
        if (flPh_ >= 1.0) flPh_ -= 1.0;
        const float m = 0.5f + 0.5f * static_cast<float>(std::sin(2.0 * 3.14159265358979 * flPh_));
        const float dSamp = (0.001f + 0.006f * m * amount_) * static_cast<float>(sr_);
        for (int c = 0; c < 2; ++c) {
          flange_[c][static_cast<size_t>(flangePos_)] = in[c];
          float rp = static_cast<float>(flangePos_) - dSamp;
          while (rp < 0) rp += kFlangeLen;
          const int i0 = static_cast<int>(rp);
          const float fr = rp - i0;
          const float a = flange_[c][static_cast<size_t>(i0 % kFlangeLen)];
          const float b = flange_[c][static_cast<size_t>((i0 + 1) % kFlangeLen)];
          wet[c] = a + (b - a) * fr;
        }
        flangePos_ = (flangePos_ + 1) % kFlangeLen;
        const float mix = std::min(1.f, amount_ * 1.5f);
        l = in[0] * (1.f - mix) + wet[0] * mix;
        r = in[1] * (1.f - mix) + wet[1] * mix;
        break;
      }
      case Tremolo: {
        // volume pulsando em 1/4 de batida (seno), profundidade = quantidade; sem cortes secos
        tremPh_ += 4.0 / (beat_ * sr_);
        if (tremPh_ >= 1.0) tremPh_ -= 1.0;
        const float m = 0.5f + 0.5f * static_cast<float>(std::cos(2.0 * 3.14159265358979 * tremPh_));
        const float g = 1.f - amount_ * 0.9f * (1.f - m);
        l = in[0] * g;
        r = in[1] * g;
        break;
      }
      case PingPong: {
        // atraso de 1/2 batida que pula de um lado para o outro (esquerda -> direita -> esquerda...)
        const int d = std::min(echoLen_ - 1, std::max(1, static_cast<int>(std::min(1.5, beat_ * 0.5) * sr_)));
        const int rd = (echoPos_ - d + echoLen_) % echoLen_;
        const float yl = echo_[0][static_cast<size_t>(rd)];
        const float yr = echo_[1][static_cast<size_t>(rd)];
        const float fb = 0.35f + 0.3f * amount_;
        // entra só pela esquerda (mono) e cruza a cada repetição
        echo_[0][static_cast<size_t>(echoPos_)] = 0.5f * (in[0] + in[1]) + yr * fb;
        echo_[1][static_cast<size_t>(echoPos_)] = yl * fb;
        echoPos_ = (echoPos_ + 1) % echoLen_;
        l = in[0] + yl * amount_;
        r = in[1] + yr * amount_;
        break;
      }
      case Stutter: {
        // a cada meia batida, guarda o primeiro 1/8 de batida e o repete até a próxima (gaguejo no ritmo)
        const int cycle = std::max(64, static_cast<int>(beat_ * 0.5 * sr_));
        const int slice = std::max(32, std::min(echoLen_ - 1, cycle / 4));
        const int n = stutN_;
        float o[2];
        if (n < slice) {
          for (int c = 0; c < 2; ++c) { echo_[c][static_cast<size_t>(n)] = in[c]; o[c] = in[c]; }
        } else {
          const int k = n % slice;
          // bordas de 2 ms em cada repetição para não estalar
          const int edge = std::min(96, slice / 4);
          const float g = k < edge ? static_cast<float>(k) / edge : (k > slice - edge ? static_cast<float>(slice - k) / edge : 1.f);
          for (int c = 0; c < 2; ++c) o[c] = echo_[c][static_cast<size_t>(k)] * g;
        }
        stutN_ = (n + 1) % cycle;
        l = in[0] * (1.f - amount_) + o[0] * amount_;
        r = in[1] * (1.f - amount_) + o[1] * amount_;
        break;
      }
      case Noise: {
        // ruído branco num filtro que sobe de 300 Hz a 9 kHz em 4 batidas (subida de tensão, "riser")
        noisePh_ += 1.0 / (beat_ * 4.0 * sr_);
        if (noisePh_ >= 1.0) noisePh_ -= 1.0;
        const double fc = 300.0 * std::pow(30.0, noisePh_);
        const float f = static_cast<float>(2.0 * std::sin(3.14159265358979 * std::min(fc, sr_ * 0.2) / sr_));
        for (int c = 0; c < 2; ++c) {
          noiseSeed_ = noiseSeed_ * 1664525u + 1013904223u;
          const float w = (static_cast<float>(noiseSeed_ >> 8) / 16777216.f) * 2.f - 1.f;
          svLow_[c] += f * svBand_[c];
          const float high = w - svLow_[c] - 0.5f * svBand_[c];
          svBand_[c] += f * high;
          wet[c] = svBand_[c] * 0.35f * static_cast<float>(0.3 + 0.7 * noisePh_);
        }
        l = in[0] + wet[0] * amount_;
        r = in[1] + wet[1] * amount_;
        break;
      }
      default:
        break;
    }
  }

 private:
  static constexpr int kCombs = 4;
  static constexpr int kFlangeLen = 1024;
  static constexpr float kRoom = 0.86f;
  static constexpr float kDamp = 0.25f;

  void clear() {
    for (int c = 0; c < 2; ++c) { phFb_[c] = 0.f; for (int k = 0; k < 6; ++k) phZ_[c][k] = 0.f; }
    for (int c = 0; c < 2; ++c) { svLow_[c] = 0.f; svBand_[c] = 0.f; }
    flPh_ = 0.0; tremPh_ = 0.0; noisePh_ = 0.0; stutN_ = 0;
    for (int c = 0; c < 2; ++c) {
      std::fill(echo_[c].begin(), echo_[c].end(), 0.f);
      std::fill(flange_[c].begin(), flange_[c].end(), 0.f);
      for (int i = 0; i < kCombs; ++i) {
        std::fill(comb_[c][i].begin(), comb_[c][i].end(), 0.f);
        combLp_[c][i] = 0.f;
      }
      for (int i = 0; i < 2; ++i) std::fill(ap_[c][i].begin(), ap_[c][i].end(), 0.f);
    }
  }

  int sr_;
  int type_ = Off;
  float target_ = 0.f, amount_ = 0.f;
  double echoDelay_ = 0.375;
  int echoLen_ = 0, echoPos_ = 0;
  std::vector<float> echo_[2];
  std::vector<float> flange_[2];
  int flangePos_ = 0;
  double lfo_ = 0.0;
  std::vector<float> comb_[2][kCombs];
  int combLen_[2][kCombs] = {};
  int combPos_[2][kCombs] = {};
  float combLp_[2][kCombs] = {};
  double beat_ = 0.5, transPh_ = 0.0;
  float transG_ = 1.f;
  int crushCnt_ = 0;
  double phPh_ = 0.0;
  float phZ_[2][6] = {};
  float phFb_[2] = {0.f, 0.f};
  float crushHold_[2] = {0.f, 0.f};
  double flPh_ = 0.0;
  float svLow_[2] = {0.f, 0.f}, svBand_[2] = {0.f, 0.f};
  double tremPh_ = 0.0, noisePh_ = 0.0;
  int stutN_ = 0;
  uint32_t noiseSeed_ = 22222u;
  std::vector<float> ap_[2][2];
  int apLen_[2][2] = {};
  int apPos_[2][2] = {};
};

}  // namespace djf
