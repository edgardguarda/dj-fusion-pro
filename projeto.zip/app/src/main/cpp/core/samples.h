// Escolha automática dos melhores trechos de uma faixa para virarem samples (pads): um golpe de bumbo,
// um golpe de caixa/chimbal, e loops de compasso inteiro alinhados na grade de batidas.
#pragma once
#include <algorithm>
#include <cmath>
#include <cstdint>
#include <memory>
#include <vector>

#include "track.h"

namespace djf {

struct SampleSpec {
  int kind = 0;           // 0 bumbo, 1 golpe agudo, 2 loop forte, 3 loop longo, 4 loop agudo
  int64_t start = 0;
  int64_t length = 0;
  bool loop = false;
};

namespace samples_detail {
// Energia por janela de 10 ms: total, graves (< ~150 Hz) e agudos (> ~3 kHz)
struct Env {
  std::vector<float> all, low, high;
  int win = 480;
};

inline Env envelope(const Track& t) {
  Env e;
  e.win = std::max(1, t.sampleRate / 100);
  const int64_t n = t.frames / e.win;
  e.all.assign(static_cast<size_t>(n), 0.f);
  e.low.assign(static_cast<size_t>(n), 0.f);
  e.high.assign(static_cast<size_t>(n), 0.f);
  const double pi = 3.14159265358979323846;
  const float aLow = static_cast<float>(1.0 - std::exp(-2.0 * pi * 150.0 / t.sampleRate));
  const float aHi = static_cast<float>(1.0 - std::exp(-2.0 * pi * 3000.0 / t.sampleRate));
  float lp = 0.f, lpHi = 0.f;
  for (int64_t w = 0; w < n; ++w) {
    double sa = 0, sl = 0, sh = 0;
    for (int i = 0; i < e.win; ++i) {
      const int64_t f = w * e.win + i;
      const float x = 0.5f * (t.pcm[2 * f] + t.pcm[2 * f + 1]) / 32768.f;
      lp += aLow * (x - lp);
      lpHi += aHi * (x - lpHi);
      const float hi = x - lpHi;
      sa += static_cast<double>(x) * x;
      sl += static_cast<double>(lp) * lp;
      sh += static_cast<double>(hi) * hi;
    }
    e.all[static_cast<size_t>(w)] = static_cast<float>(std::sqrt(sa / e.win));
    e.low[static_cast<size_t>(w)] = static_cast<float>(std::sqrt(sl / e.win));
    e.high[static_cast<size_t>(w)] = static_cast<float>(std::sqrt(sh / e.win));
  }
  return e;
}

inline double meanRange(const std::vector<float>& v, int64_t a, int64_t b) {
  a = std::max<int64_t>(0, a);
  b = std::min<int64_t>(static_cast<int64_t>(v.size()), b);
  if (b <= a) return 0.0;
  double s = 0;
  for (int64_t i = a; i < b; ++i) s += v[static_cast<size_t>(i)];
  return s / static_cast<double>(b - a);
}
}  // namespace samples_detail

// Até 4 trechos: bumbo, golpe agudo, loop de 1 compasso mais forte e loop de 2 compassos (ou agudo).
// bpm <= 0: sem grade; só os dois golpes e um trecho forte de 2 s (não repete em loop).
inline std::vector<SampleSpec> pickSamples(const Track& t, double bpm, int64_t firstBeat) {
  using namespace samples_detail;
  std::vector<SampleSpec> out;
  if (t.frames < static_cast<int64_t>(4) * t.sampleRate) return out;
  const Env e = envelope(t);
  const int64_t n = static_cast<int64_t>(e.all.size());
  if (n < 100) return out;
  const double sr = t.sampleRate;
  // Ignora o começo e o fim da faixa (intro e saída costumam ser fracos ou só efeitos)
  const int64_t lo = n / 10, hi = n - n / 10;

  // golpe de bumbo: maior subida de energia nos graves
  int64_t kickW = -1;
  float bestK = 0.f;
  for (int64_t w = lo + 1; w < hi; ++w) {
    const float rise = e.low[static_cast<size_t>(w)] - e.low[static_cast<size_t>(w - 1)];
    const float v = rise * e.low[static_cast<size_t>(w)];
    if (rise > 0 && v > bestK) { bestK = v; kickW = w; }
  }
  if (kickW >= 0 && bestK > 1e-5f) {
    SampleSpec s;
    s.kind = 0;
    s.start = std::max<int64_t>(0, (kickW - 1) * e.win);
    s.length = static_cast<int64_t>(0.32 * sr);
    out.push_back(s);
  }
  // golpe agudo (caixa, palma, chimbal): maior subida nos agudos, longe do bumbo
  int64_t hitW = -1;
  float bestH = 0.f;
  for (int64_t w = lo + 1; w < hi; ++w) {
    if (kickW >= 0 && std::llabs(w - kickW) < 8) continue;
    const float rise = e.high[static_cast<size_t>(w)] - e.high[static_cast<size_t>(w - 1)];
    const float v = rise * e.high[static_cast<size_t>(w)];
    if (rise > 0 && v > bestH) { bestH = v; hitW = w; }
  }
  if (hitW >= 0 && bestH > 1e-6f) {
    SampleSpec s;
    s.kind = 1;
    s.start = std::max<int64_t>(0, (hitW - 1) * e.win);
    s.length = static_cast<int64_t>(0.28 * sr);
    out.push_back(s);
  }

  if (bpm >= 40.0 && bpm <= 260.0) {
    const double bar = 4.0 * 60.0 / bpm * sr;                // quadros por compasso
    const int64_t barW = static_cast<int64_t>(std::lround(bar / e.win));
    // compassos inteiros na grade, dentro da região útil
    std::vector<int64_t> starts;
    for (int64_t k = 0;; ++k) {
      const int64_t f = firstBeat + static_cast<int64_t>(std::llround(k * bar));
      if (f < 0) continue;
      if (f / e.win < lo) continue;
      if (f + static_cast<int64_t>(2 * bar) >= t.frames || f / e.win + 2 * barW > hi) break;
      starts.push_back(f);
    }
    if (!starts.empty()) {
      // loop de 1 compasso: o mais forte
      size_t bestI = 0;
      double bestE = -1;
      for (size_t i = 0; i < starts.size(); ++i) {
        const double en = meanRange(e.all, starts[i] / e.win, starts[i] / e.win + barW);
        if (en > bestE) { bestE = en; bestI = i; }
      }
      SampleSpec l1;
      l1.kind = 2; l1.start = starts[bestI]; l1.length = static_cast<int64_t>(std::llround(bar)); l1.loop = true;
      out.push_back(l1);
      // loop de 2 compassos: a janela mais forte que não pisa no primeiro loop
      size_t best2 = starts.size();
      double e2 = -1;
      for (size_t i = 0; i < starts.size(); ++i) {
        const int64_t f = starts[i];
        const int64_t len2 = static_cast<int64_t>(std::llround(2 * bar));
        if (f + len2 > l1.start && f < l1.start + l1.length) continue;
        const double en = meanRange(e.all, f / e.win, f / e.win + 2 * barW);
        if (en > e2) { e2 = en; best2 = i; }
      }
      if (best2 < starts.size()) {
        SampleSpec l2;
        l2.kind = 3; l2.start = starts[best2]; l2.length = static_cast<int64_t>(std::llround(2 * bar)); l2.loop = true;
        out.push_back(l2);
      }
    }
  } else {
    // sem andamento: um trecho forte de 2 s, uma vez
    int64_t bestW = -1;
    double bestE = -1;
    const int64_t span = 200;
    for (int64_t w = lo; w + span < hi; w += 50) {
      const double en = meanRange(e.all, w, w + span);
      if (en > bestE) { bestE = en; bestW = w; }
    }
    if (bestW >= 0) {
      SampleSpec s;
      s.kind = 2; s.start = bestW * e.win; s.length = span * e.win;
      out.push_back(s);
    }
  }
  return out;
}

// Copia o trecho para uma faixa própria, com entrada e saída suaves (sem estalo).
inline std::shared_ptr<Track> makeSample(const Track& t, const SampleSpec& s) {
  auto out = std::make_shared<Track>();
  out->sampleRate = t.sampleRate;
  const int64_t start = std::max<int64_t>(0, std::min(s.start, t.frames));
  const int64_t len = std::max<int64_t>(0, std::min(s.length, t.frames - start));
  out->frames = len;
  out->pcm.assign(t.pcm.begin() + 2 * start, t.pcm.begin() + 2 * (start + len));
  const int64_t fade = std::min<int64_t>(len / 2, static_cast<int64_t>(0.002 * t.sampleRate));
  for (int64_t i = 0; i < fade; ++i) {
    const float g = static_cast<float>(i) / static_cast<float>(fade);
    for (int c = 0; c < 2; ++c) {
      out->pcm[static_cast<size_t>(2 * i + c)] = static_cast<int16_t>(out->pcm[static_cast<size_t>(2 * i + c)] * g);
      const int64_t j = len - 1 - i;
      out->pcm[static_cast<size_t>(2 * j + c)] = static_cast<int16_t>(out->pcm[static_cast<size_t>(2 * j + c)] * g);
    }
  }
  return out;
}

}  // namespace djf
