// Oito sons clássicos de DJ, sintetizados na hora (sem arquivos, sem direitos de terceiros):
// buzina (air horn), sirene, laser, bumbo 808, palma, subida (riser), descida e explosão.
// Assim os pads do sampler já tocam algo antes de o DJ gerar amostras das músicas.
#pragma once
#include <algorithm>
#include <cmath>
#include <cstdint>
#include <memory>
#include <vector>

#include "track.h"

namespace djf {

constexpr int kBuiltinSamples = 8;
inline const char* builtinSampleName(int i) {
  static const char* names[kBuiltinSamples] = {"BUZINA", "SIRENE", "LASER", "BUMBO 808", "PALMA", "SUBIDA", "DESCIDA", "EXPLOSÃO"};
  return (i >= 0 && i < kBuiltinSamples) ? names[i] : "";
}

inline std::shared_ptr<Track> makeBuiltinSample(int which, int sr = 48000) {
  const double pi = 3.14159265358979323846;
  double secs = 1.0;
  switch (which) {
    case 0: secs = 1.4; break;   // buzina
    case 1: secs = 2.0; break;   // sirene
    case 2: secs = 0.5; break;   // laser
    case 3: secs = 0.9; break;   // 808
    case 4: secs = 0.35; break;  // palma
    case 5: secs = 4.0; break;   // subida
    case 6: secs = 2.5; break;   // descida
    case 7: secs = 2.2; break;   // explosão
    default: return nullptr;
  }
  const int64_t n = static_cast<int64_t>(secs * sr);
  auto t = std::make_shared<Track>();
  t->sampleRate = sr;
  t->frames = n;
  t->pcm.assign(static_cast<size_t>(n) * 2, 0);
  uint32_t seed = 12345u + static_cast<uint32_t>(which) * 7919u;
  auto noise = [&]() {
    seed = seed * 1664525u + 1013904223u;
    return static_cast<double>((seed >> 9) & 0xFFFF) / 32768.0 - 1.0;
  };
  double ph[6] = {0, 0, 0, 0, 0, 0};
  double lp = 0, lp2 = 0, bp = 0;
  for (int64_t i = 0; i < n; ++i) {
    const double tt = static_cast<double>(i) / sr;
    const double u = tt / secs;
    double v = 0;
    switch (which) {
      case 0: {  // buzina: 3 serras desafinadas em blocos curtos
        const double f[3] = {415.0, 466.0, 554.0};
        for (int k = 0; k < 3; ++k) {
          ph[k] += f[k] * (1.0 + 0.004 * std::sin(2 * pi * 6 * tt)) / sr;
          v += 2.0 * (ph[k] - std::floor(ph[k])) - 1.0;
        }
        v *= 0.22;
        const double block = std::fmod(tt, 0.35);
        const double gate = tt < 0.7 ? (block < 0.28 ? 1.0 : 0.0) : 1.0;
        v *= gate * std::min(1.0, tt * 60) * std::min(1.0, (secs - tt) * 8);
        break;
      }
      case 1: {  // sirene: senoide subindo e descendo
        const double f = 700 + 500 * std::sin(2 * pi * 1.5 * tt);
        ph[0] += f / sr;
        v = 0.5 * std::sin(2 * pi * ph[0]) + 0.15 * std::sin(4 * pi * ph[0]);
        v *= std::min(1.0, tt * 20) * std::min(1.0, (secs - tt) * 4);
        break;
      }
      case 2: {  // laser: queda rápida de frequência
        const double f = 2500 * std::exp(-tt * 9) + 120;
        ph[0] += f / sr;
        v = 0.5 * (2.0 * (ph[0] - std::floor(ph[0])) - 1.0) * std::exp(-tt * 5);
        break;
      }
      case 3: {  // bumbo 808: senoide com queda de altura e cauda longa
        const double f = 48 + 110 * std::exp(-tt * 22);
        ph[0] += f / sr;
        v = 0.9 * std::sin(2 * pi * ph[0]) * std::exp(-tt * 3.2);
        v = std::tanh(v * 1.4);
        break;
      }
      case 4: {  // palma: rajadas de ruído filtrado
        double env = 0;
        for (double d : {0.0, 0.011, 0.022}) if (tt >= d) env += std::exp(-(tt - d) * 140);
        env += 0.5 * std::exp(-tt * 18);
        const double x = noise();
        bp += 0.35 * (x - bp);
        v = 0.7 * (x - bp) * env * 0.6;
        break;
      }
      case 5: {  // subida: ruído com filtro abrindo + tom subindo
        const double cut = 0.01 + 0.5 * u * u;
        lp += cut * (noise() - lp);
        const double f = 200 * std::pow(8.0, u);
        ph[0] += f / sr;
        v = (0.45 * lp + 0.18 * std::sin(2 * pi * ph[0])) * (0.2 + 0.8 * u) * std::min(1.0, (secs - tt) * 20);
        break;
      }
      case 6: {  // descida: o contrário
        const double cut = 0.5 * (1 - u) * (1 - u) + 0.01;
        lp += cut * (noise() - lp);
        const double f = 1600 * std::pow(0.08, u);
        ph[0] += f / sr;
        v = (0.45 * lp + 0.2 * std::sin(2 * pi * ph[0])) * (1.0 - 0.8 * u) * std::min(1.0, tt * 40);
        break;
      }
      case 7: {  // explosão: impacto grave + ruído escuro com cauda
        const double f = 40 + 80 * std::exp(-tt * 15);
        ph[0] += f / sr;
        lp += 0.04 * (noise() - lp);
        lp2 += 0.02 * (lp - lp2);
        v = 0.8 * std::sin(2 * pi * ph[0]) * std::exp(-tt * 4) + 2.2 * lp2 * std::exp(-tt * 1.6);
        v = std::tanh(v * 1.2);
        break;
      }
    }
    const int16_t s = static_cast<int16_t>(std::lrint(std::max(-1.0, std::min(1.0, v)) * 30000.0));
    t->pcm[static_cast<size_t>(2 * i)] = s;
    t->pcm[static_cast<size_t>(2 * i + 1)] = s;
  }
  return t;
}

}  // namespace djf
