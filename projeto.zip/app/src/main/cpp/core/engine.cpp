#include "engine.h"

#include <algorithm>
#include <cmath>

namespace djf {

namespace {
constexpr float kHalfPi = 1.57079632679489662f;
// NaN vira 0: um NaN que chegasse ao áudio contaminaria o filtro e o eco para sempre.
inline float clamp01(float v) { return !(v >= 0.f) ? 0.f : (v > 1.f ? 1.f : v); }
// Limitador suave: abaixo de 0,8 não mexe no som; acima, curva suave que nunca passa de 1 (sem estalo de corte seco).
inline float softLimit(float x) {
  const float a = std::fabs(x);
  if (a <= 0.8f) return x;
  const float y = 0.8f + 0.2f * std::tanh((a - 0.8f) * 5.f);
  return x < 0.f ? -y : y;
}
}  // namespace

Engine::Engine(int sampleRate, int maxBlockFrames) : sr_(sampleRate), maxBlock_(maxBlockFrames) {
  rampStep_ = 1.0f / (0.004f * static_cast<float>(sr_));
  smoothCoef_ = 1.0f - std::exp(-1.0f / (0.010f * static_cast<float>(sr_)));
  peakDecayPerFrame_ = 1.0f / (0.8f * static_cast<float>(sr_));
  for (auto& a : sampSeq_) a.store(0);
  scratchCoef_ = 1.0f - std::exp(-1.0f / (0.003f * static_cast<float>(sr_)));
  for (int k = 0; k < kGrain; ++k) {
    win_[k] = 0.5f * (1.f - std::cos(6.28318530717958648f * static_cast<float>(k) / static_cast<float>(kGrain)));
  }
  for (int d = 0; d < kDecks; ++d) d_[d].fx = DeckFx(sampleRate);
}

// ---------------------------------------------------------------- controle

bool Engine::send(const Cmd& c) {
  std::lock_guard<std::mutex> lock(producerMutex_);
  return queue_.push(c);
}

bool Engine::loadTrack(int deck, std::shared_ptr<const Track> track) {
  if (deck < 0 || deck >= kDecks || !track || track->sampleRate != sr_) return false;
  std::lock_guard<std::mutex> lock(producerMutex_);
  Cmd c;
  c.type = CmdType::Load;
  c.deck = static_cast<uint8_t>(deck);
  c.track = track.get();
  c.seq = issued_[deck] + 1;
  if (!queue_.push(c)) return false;
  issued_[deck] = c.seq;
  if (current_[deck]) retired_.push_back({current_[deck], deck, c.seq});
  current_[deck] = std::move(track);
  return true;
}

void Engine::unload(int deck) {
  if (deck < 0 || deck >= kDecks) return;
  std::lock_guard<std::mutex> lock(producerMutex_);
  Cmd c;
  c.type = CmdType::Load;
  c.deck = static_cast<uint8_t>(deck);
  c.track = nullptr;
  c.seq = issued_[deck] + 1;
  if (!queue_.push(c)) return;
  issued_[deck] = c.seq;
  if (current_[deck]) retired_.push_back({current_[deck], deck, c.seq});
  current_[deck].reset();
}

void Engine::play(int deck) {
  if (deck < 0 || deck >= kDecks) return;
  Cmd c; c.type = CmdType::Play; c.deck = static_cast<uint8_t>(deck);
  send(c);
}

void Engine::pause(int deck) {
  if (deck < 0 || deck >= kDecks) return;
  Cmd c; c.type = CmdType::Pause; c.deck = static_cast<uint8_t>(deck);
  send(c);
}

void Engine::cue(int deck) {
  if (deck < 0 || deck >= kDecks) return;
  Cmd c; c.type = CmdType::Cue; c.deck = static_cast<uint8_t>(deck);
  send(c);
}

void Engine::seekFrames(int deck, int64_t frame) {
  if (deck < 0 || deck >= kDecks) return;
  Cmd c; c.type = CmdType::Seek; c.deck = static_cast<uint8_t>(deck); c.i = frame;
  send(c);
}

void Engine::setVolume(int deck, float v) {
  if (deck < 0 || deck >= kDecks) return;
  Cmd c; c.type = CmdType::Volume; c.deck = static_cast<uint8_t>(deck); c.f = clamp01(v);
  send(c);
}

void Engine::setCrossfader(float x) {
  Cmd c; c.type = CmdType::Crossfader; c.f = clamp01(x);
  send(c);
}

void Engine::setMaster(float v) {
  Cmd c; c.type = CmdType::Master; c.f = clamp01(v);
  send(c);
}

void Engine::setRate(int deck, float rate) {
  if (deck < 0 || deck >= kDecks || !(rate == rate)) return;
  Cmd c; c.type = CmdType::Rate; c.deck = static_cast<uint8_t>(deck);
  c.f = rate < 0.5f ? 0.5f : (rate > 2.0f ? 2.0f : rate);
  send(c);
}

void Engine::setEq(int deck, int band, float v) {
  if (deck < 0 || deck >= kDecks || band < 0 || band > 2) return;
  Cmd c; c.type = CmdType::Eq; c.deck = static_cast<uint8_t>(deck); c.i = band; c.f = clamp01(v);
  send(c);
}

void Engine::setFilter(int deck, float v) {
  if (deck < 0 || deck >= kDecks) return;
  Cmd c; c.type = CmdType::Filter; c.deck = static_cast<uint8_t>(deck); c.f = clamp01(v);
  send(c);
}

void Engine::setLoop(int deck, int64_t start, int64_t end) {
  if (deck < 0 || deck >= kDecks || start < 0 || end - start < 256) return;
  Cmd c; c.type = CmdType::LoopOn; c.deck = static_cast<uint8_t>(deck); c.i = start; c.j = end;
  send(c);
}

void Engine::setFx(int deck, int type, float amount, double beatSeconds) {
  if (deck < 0 || deck >= kDecks) return;
  Cmd c;
  c.type = CmdType::Fx;
  c.deck = static_cast<uint8_t>(deck);
  c.f = clamp01(amount);
  c.i = (type >= 0 && type <= 3) ? type : 0;
  c.j = static_cast<int64_t>((beatSeconds >= 0.05 && beatSeconds <= 5.0 ? beatSeconds : 0.5) * 1e6);
  send(c);
}

void Engine::setKeyLock(int deck, bool on) {
  if (deck < 0 || deck >= kDecks) return;
  Cmd c; c.type = CmdType::KeyLock; c.deck = static_cast<uint8_t>(deck); c.i = on ? 1 : 0;
  send(c);
}

void Engine::scratch(int deck, bool active, float velocity) {
  if (deck < 0 || deck >= kDecks || !(velocity == velocity)) return;
  Cmd c; c.type = CmdType::Scratch; c.deck = static_cast<uint8_t>(deck); c.i = active ? 1 : 0;
  c.f = velocity < -8.f ? -8.f : (velocity > 8.f ? 8.f : velocity);
  send(c);
}

void Engine::setHeadphoneCue(int deck, bool on) {
  if (deck < 0 || deck >= kDecks) return;
  Cmd c; c.type = CmdType::HpCue; c.deck = static_cast<uint8_t>(deck); c.i = on ? 1 : 0;
  send(c);
}

void Engine::setHeadphoneLevel(float v) {
  Cmd c; c.type = CmdType::HpLevel; c.f = clamp01(v);
  send(c);
}

void Engine::setHeadphoneMix(float v) {
  Cmd c; c.type = CmdType::HpMix; c.f = clamp01(v);
  send(c);
}

void Engine::playSynced(int deck, int refDeck, double refFirstBeat, double refBeatFrames,
                        double firstBeat, double beatFrames, double startBeat) {
  if (deck < 0 || deck >= kDecks || refDeck < 0 || refDeck >= kDecks || deck == refDeck) return;
  if (!(refBeatFrames > 1.0) || !(beatFrames > 1.0) || !(startBeat == startBeat)) return;
  Cmd c;
  c.type = CmdType::PlaySynced;
  c.deck = static_cast<uint8_t>(deck);
  c.i = refDeck;
  c.d[0] = refFirstBeat; c.d[1] = refBeatFrames; c.d[2] = firstBeat + startBeat * beatFrames; c.d[3] = beatFrames;
  send(c);
}

bool Engine::loadSample(int slot, std::shared_ptr<const Track> sample) {
  if (slot < 0 || slot >= kSamples || !sample || sample->sampleRate != sr_ || sample->frames < 16) return false;
  std::lock_guard<std::mutex> lock(producerMutex_);
  Cmd c;
  c.type = CmdType::SampLoad;
  c.deck = static_cast<uint8_t>(slot);
  c.track = sample.get();
  c.seq = issuedS_[slot] + 1;
  if (!queue_.push(c)) return false;
  issuedS_[slot] = c.seq;
  if (currentS_[slot]) retired_.push_back({currentS_[slot], slot, c.seq, true});
  currentS_[slot] = std::move(sample);
  return true;
}

void Engine::clearSample(int slot) {
  if (slot < 0 || slot >= kSamples) return;
  std::lock_guard<std::mutex> lock(producerMutex_);
  Cmd c;
  c.type = CmdType::SampLoad;
  c.deck = static_cast<uint8_t>(slot);
  c.track = nullptr;
  c.seq = issuedS_[slot] + 1;
  if (!queue_.push(c)) return;
  issuedS_[slot] = c.seq;
  if (currentS_[slot]) retired_.push_back({currentS_[slot], slot, c.seq, true});
  currentS_[slot].reset();
}

void Engine::setStemGain(int deck, int stem, float gain) {
  if (deck < 0 || deck >= kDecks || stem < 0 || stem > 3) return;
  Cmd c; c.type = CmdType::StemGain; c.deck = static_cast<uint8_t>(deck); c.i = stem; c.f = clamp01(gain);
  send(c);
}

void Engine::setKeyShift(int deck, float semitones) {
  if (deck < 0 || deck >= kDecks) return;
  if (!(semitones == semitones)) semitones = 0.f;
  Cmd c; c.type = CmdType::KeyShift; c.deck = static_cast<uint8_t>(deck); c.f = std::max(-12.f, std::min(12.f, semitones));
  send(c);
}

void Engine::setTrim(int deck, float gain) {
  if (deck < 0 || deck >= kDecks) return;
  if (!(gain == gain)) gain = 1.f;
  Cmd c; c.type = CmdType::Trim; c.deck = static_cast<uint8_t>(deck); c.f = std::max(0.f, std::min(4.f, gain));
  send(c);
}

void Engine::triggerSample(int slot, bool loop, int64_t delayFrames) {
  if (slot < 0 || slot >= kSamples) return;
  Cmd c; c.type = CmdType::SampPlay; c.deck = static_cast<uint8_t>(slot); c.i = loop ? 1 : 0;
  c.j = std::max<int64_t>(0, std::min<int64_t>(delayFrames, static_cast<int64_t>(sr_) * 8));
  send(c);
}

void Engine::setSampleSpeed(int slot, float speed) {
  if (slot < 0 || slot >= kSamples) return;
  if (!(speed > 0.f)) speed = 1.f;
  Cmd c; c.type = CmdType::SampRate; c.deck = static_cast<uint8_t>(slot); c.f = std::min(4.f, std::max(0.25f, speed));
  send(c);
}

void Engine::setRecording(bool on) {
  if (on) {
    if (!recBuf_) recBuf_.reset(new float[kRecCap]);
    recTail_.store(recHead_.load(std::memory_order_acquire), std::memory_order_release);
    recDropped_.store(0, std::memory_order_relaxed);
  }
  recOn_.store(on && recBuf_ != nullptr, std::memory_order_release);
}

void Engine::recordPush(const float* src, int frames) {
  const size_t n = static_cast<size_t>(frames) * 2;
  const size_t h = recHead_.load(std::memory_order_relaxed);
  const size_t t = recTail_.load(std::memory_order_acquire);
  if (kRecCap - 1 - (h - t) < n) { recDropped_.fetch_add(frames, std::memory_order_relaxed); return; }
  for (size_t k = 0; k < n; ++k) recBuf_[(h + k) & (kRecCap - 1)] = src[k];
  recHead_.store(h + n, std::memory_order_release);
}

size_t Engine::readRecorded(float* dst, size_t maxFloats) {
  if (!recBuf_) return 0;
  const size_t t = recTail_.load(std::memory_order_relaxed);
  const size_t h = recHead_.load(std::memory_order_acquire);
  size_t n = std::min(h - t, maxFloats);
  n -= n % 2;
  for (size_t k = 0; k < n; ++k) dst[k] = recBuf_[(t + k) & (kRecCap - 1)];
  recTail_.store(t + n, std::memory_order_release);
  return n;
}

void Engine::stopSample(int slot) {
  if (slot < 0 || slot >= kSamples) return;
  Cmd c; c.type = CmdType::SampStop; c.deck = static_cast<uint8_t>(slot);
  send(c);
}

void Engine::setSamplerVolume(float v) {
  Cmd c; c.type = CmdType::SampVol; c.f = clamp01(v);
  send(c);
}

void Engine::clearLoop(int deck) {
  if (deck < 0 || deck >= kDecks) return;
  Cmd c; c.type = CmdType::LoopOff; c.deck = static_cast<uint8_t>(deck);
  send(c);
}

std::shared_ptr<const Track> Engine::trackOf(int deck) {
  if (deck < 0 || deck >= kDecks) return nullptr;
  std::lock_guard<std::mutex> lock(producerMutex_);
  return current_[deck];
}

Engine::DeckInfo Engine::deckInfo(int deck) const {
  DeckInfo info;
  if (deck < 0 || deck >= kDecks) return info;
  const DeckPub& p = pub_[deck];
  info.loaded = p.loaded.load(std::memory_order_relaxed);
  info.playing = p.playing.load(std::memory_order_relaxed);
  info.positionFrames = p.pos.load(std::memory_order_relaxed);
  info.cueFrames = p.cue.load(std::memory_order_relaxed);
  info.lengthFrames = p.length.load(std::memory_order_relaxed);
  info.peak = p.peak.load(std::memory_order_relaxed);
  return info;
}

void Engine::collectGarbage() {
  std::lock_guard<std::mutex> lock(producerMutex_);
  retired_.erase(
      std::remove_if(retired_.begin(), retired_.end(),
                     [this](const Retired& r) {
                       if (r.sample) return sampSeq_[r.deck].load(std::memory_order_acquire) >= r.seq;
                       return pub_[r.deck].appliedSeq.load(std::memory_order_acquire) >= r.seq;
                     }),
      retired_.end());
}

// ------------------------------------------------------------------- áudio

void Engine::drain() {
  Cmd c;
  while (queue_.pop(c)) {
    if (c.type == CmdType::Crossfader) { xTarget_ = c.f; continue; }
    if (c.type == CmdType::Master) { masterTarget_ = c.f; continue; }
    if (c.type == CmdType::HpLevel) { hpTarget_ = c.f; continue; }
    if (c.type == CmdType::HpMix) { hpMixTarget_ = c.f; continue; }
    if (c.type == CmdType::SampVol) { sampVol_ = c.f; continue; }
    if (c.type == CmdType::SampRate) { if (c.deck < kSamples) s_[c.deck].speed = c.f; continue; }
    if (c.type == CmdType::SampLoad || c.type == CmdType::SampPlay || c.type == CmdType::SampStop) {
      if (c.deck >= kSamples) continue;
      SampSlot& S = s_[c.deck];
      if (c.type == CmdType::SampLoad) {
        S.track = c.track;
        S.want = false;
        S.pos = 0;
        S.gain = 0.f;
        sampSeq_[c.deck].store(c.seq, std::memory_order_release);
      } else if (c.type == CmdType::SampPlay) {
        if (S.track) { S.pos = 0; S.loop = c.i != 0; S.want = true; S.delay = c.j; }
      } else {
        S.want = false;
      }
      continue;
    }
    DeckAudio& D = d_[c.deck];
    DeckPub& P = pub_[c.deck];
    switch (c.type) {
      case CmdType::Load:
        D.track = c.track;
        for (int k = 0; k < 4; ++k) { D.stemTarget[k] = 1.f; D.stemSm[k] = 1.f; }
        D.stemActive = false;
        D.scratch = false;          // carregar outra música solta o prato (reverso, scratch)
        D.scratchVel = 0.f;
        D.pos = 0;
        D.cue = 0;
        D.loopOn = false;
        D.pendingSeek = -1;
        D.wantPlay = false;
        D.playGain = 0.f;
        P.loaded.store(c.track != nullptr, std::memory_order_relaxed);
        P.length.store(c.track ? c.track->frames : 0, std::memory_order_relaxed);
        P.pos.store(0, std::memory_order_relaxed);
        P.cue.store(0, std::memory_order_relaxed);
        P.playing.store(false, std::memory_order_relaxed);
        P.appliedSeq.store(c.seq, std::memory_order_release);
        break;
      case CmdType::Play:
        if (!D.track) break;
        if (D.pos >= static_cast<double>(D.track->frames)) D.pendingSeek = 0;  // fim da faixa: recomeça do início
        D.wantPlay = true;
        P.playing.store(true, std::memory_order_relaxed);
        break;
      case CmdType::Pause:
        D.wantPlay = false;
        P.playing.store(false, std::memory_order_relaxed);
        break;
      case CmdType::Cue:
        if (!D.track) break;
        if (D.wantPlay) {
          D.pendingSeek = D.cue;
          D.wantPlay = false;
          P.playing.store(false, std::memory_order_relaxed);
        } else {
          D.cue = std::min<int64_t>(static_cast<int64_t>(D.pos), D.track->frames);
          P.cue.store(D.cue, std::memory_order_relaxed);
        }
        break;
      case CmdType::Seek:
        if (!D.track) break;
        D.pendingSeek = std::max<int64_t>(0, std::min(c.i, D.track->frames));
        break;
      case CmdType::Volume:
        D.vol = c.f;
        break;
      case CmdType::Trim:
        D.trim = c.f;
        break;
      case CmdType::Rate:
        D.rate = c.f;
        break;
      case CmdType::Eq:
        D.eqKnob[c.i] = c.f;
        break;
      case CmdType::Filter:
        D.filterKnob = c.f;
        break;
      case CmdType::LoopOn:
        if (D.track && c.j <= D.track->frames) {
          D.loopStart = c.i;
          D.loopEnd = c.j;
          D.loopOn = true;
        }
        break;
      case CmdType::Fx:
        d_[c.deck].fx.set(static_cast<int>(c.i), c.f, static_cast<double>(c.j) * 1e-6);
        break;
      case CmdType::LoopOff:
        D.loopOn = false;
        break;
      case CmdType::KeyLock:
        D.keyLock = c.i != 0;
        D.stretchReset = true;
        break;
      case CmdType::StemGain:
        D.stemTarget[c.i & 3] = c.f;
        break;
      case CmdType::KeyShift:
        D.keyShift = c.f;
        D.stretchReset = true;
        break;
      case CmdType::Scratch:
        if (c.i != 0) {
          if (!D.scratch) {
            // ao tocar no prato, a velocidade parte da atual (segurar o disco em movimento)
            D.scratchSm = (D.wantPlay && D.playGain > 0.f) ? D.rateSm : 0.f;
            D.scratchGain = 1.f;
          }
          D.scratch = true;
          D.scratchVel = c.f;
        } else if (D.scratch) {
          D.scratch = false;
          D.rateSm = D.scratchSm;  // a rampa de velocidade continua de onde a mão largou
          D.stretchReset = true;
        }
        break;
      case CmdType::HpCue:
        D.cueOn = c.i != 0;
        break;
      case CmdType::PlaySynced: {
        if (!D.track) break;
        const int ref = static_cast<int>(c.i);
        double target = c.d[2];
        if (d_[ref].track && d_[ref].wantPlay && d_[ref].playGain > 0.f) {
          double ph = std::fmod(d_[ref].pos - c.d[0], c.d[1]);
          if (ph < 0) ph += c.d[1];
          target += (ph / c.d[1]) * c.d[3];
        }
        D.pendingSeek = std::max<int64_t>(0, std::min<int64_t>(static_cast<int64_t>(target), D.track->frames - 1));
        D.wantPlay = true;
        P.playing.store(true, std::memory_order_relaxed);
        break;
      }
      default:
        break;
    }
  }
}

void Engine::render(float* out, int frames, float* hp) {
  drain();
  while (frames > 0) {
    const int n = std::min(frames, maxBlock_);
    renderBlock(out, hp, n);
    if (recOn_.load(std::memory_order_acquire)) recordPush(out, n);
    out += 2 * n;
    if (hp) hp += 2 * n;
    frames -= n;
  }
}

namespace {
// Curva do equalizador em dB: 0 corta (-40 dB), 0,5 neutro, 1 dá +6 dB.
inline float eqDb(float v) { return v < 0.5f ? -40.f * (1.f - 2.f * v) : 6.f * (2.f * v - 1.f); }

// Interpolação cúbica (Hermite) entre y0 e y1, com vizinhos ym1 e y2.
inline float hermite(float ym1, float y0, float y1, float y2, float t) {
  const float c1 = 0.5f * (y1 - ym1);
  const float c2 = ym1 - 2.5f * y0 + 2.f * y1 - 0.5f * y2;
  const float c3 = 0.5f * (y2 - ym1) + 1.5f * (y0 - y1);
  return ((c3 * t + c2) * t + c1) * t + y0;
}
}  // namespace

// Coeficientes das três seções (livro de receitas de áudio de Robert Bristow-Johnson).
void Engine::updateEq(DeckAudio& D, int n) {
  const float blockCoef = 1.0f - std::pow(1.0f - smoothCoef_, static_cast<float>(n));
  for (int b = 0; b < 3; ++b) {
    const float before = D.eqSm[b];
    D.eqSm[b] += (D.eqKnob[b] - D.eqSm[b]) * blockCoef;
    if (std::fabs(D.eqKnob[b] - D.eqSm[b]) < 1e-4f) D.eqSm[b] = D.eqKnob[b];
    if (D.eqSm[b] == before) continue;
    const double db = eqDb(D.eqSm[b]);
    if (std::fabs(db) < 1e-3) {  // neutro: seção idêntica, o som passa sem mudança
      D.eqB0[b] = 1; D.eqB1[b] = D.eqB2[b] = D.eqA1[b] = D.eqA2[b] = 0;
      continue;
    }
    const double pi = 3.14159265358979323846;
    const double A = std::pow(10.0, db / 40.0);
    const double f0 = b == 0 ? 200.0 : (b == 1 ? 1000.0 : 4500.0);
    const double w0 = 2.0 * pi * f0 / sr_;
    const double cw = std::cos(w0), sw = std::sin(w0);
    double b0, b1, b2, a0, a1, a2;
    if (b == 1) {  // pico, Q = 1
      const double alpha = sw / (2.0 * 1.0);
      b0 = 1 + alpha * A; b1 = -2 * cw; b2 = 1 - alpha * A;
      a0 = 1 + alpha / A; a1 = -2 * cw; a2 = 1 - alpha / A;
    } else {       // prateleiras com inclinação S = 1
      const double alpha = sw / 2.0 * std::sqrt(2.0);
      const double tsa = 2.0 * std::sqrt(A) * alpha;
      if (b == 0) {
        b0 = A * ((A + 1) - (A - 1) * cw + tsa);
        b1 = 2 * A * ((A - 1) - (A + 1) * cw);
        b2 = A * ((A + 1) - (A - 1) * cw - tsa);
        a0 = (A + 1) + (A - 1) * cw + tsa;
        a1 = -2 * ((A - 1) + (A + 1) * cw);
        a2 = (A + 1) + (A - 1) * cw - tsa;
      } else {
        b0 = A * ((A + 1) + (A - 1) * cw + tsa);
        b1 = -2 * A * ((A - 1) + (A + 1) * cw);
        b2 = A * ((A + 1) + (A - 1) * cw - tsa);
        a0 = (A + 1) - (A - 1) * cw + tsa;
        a1 = 2 * ((A - 1) - (A + 1) * cw);
        a2 = (A + 1) - (A - 1) * cw - tsa;
      }
    }
    D.eqB0[b] = static_cast<float>(b0 / a0); D.eqB1[b] = static_cast<float>(b1 / a0);
    D.eqB2[b] = static_cast<float>(b2 / a0); D.eqA1[b] = static_cast<float>(a1 / a0);
    D.eqA2[b] = static_cast<float>(a2 / a0);
  }
}

// Um quadro da faixa com os stems aplicados (se houver). Os stems são mono (centro) e somados aos dois canais.
void Engine::frameAt(const DeckAudio& D, int64_t i, float& l, float& r) {
  const float k16 = 1.0f / 32768.0f;
  const int16_t* pcm = D.track->pcm.data();
  l = pcm[2 * i] * k16;
  r = pcm[2 * i + 1] * k16;
  if (D.stemActive) {
    const int16_t* s = D.stemPtr + 3 * i;
    const float add = (D.stemC[1] * s[0] + D.stemC[2] * s[1] + D.stemC[3] * s[2]) * k16;
    l = D.stemC[0] * l + add;
    r = D.stemC[0] * r + add;
  }
}

// Escolhe onde o próximo grão começa: perto da posição nominal, no ponto cuja forma de onda melhor continua
// a do grão anterior (correlação normalizada, busca grossa e depois fina), para não haver defasagem audível.
void Engine::startGrain(DeckAudio& D) {
  const int64_t frames = D.track->frames;
  const int16_t* pcm = D.track->pcm.data();
  int64_t s = static_cast<int64_t>(D.pos);
  if (D.stretchSkipSearch) {
    D.stretchSkipSearch = false;
  } else {
    // o centro do grão (fase kHop, lida na velocidade grainP) deve cair onde a música estará daqui a kHop quadros
    s = static_cast<int64_t>(D.pos + static_cast<double>(kHop) * (static_cast<double>(D.rateSm) - D.grainP));
    const int64_t target = D.prevStart + static_cast<int64_t>(kHop * D.grainP);
    constexpr int kLen = 512, kStride = 2, kWin = 384, kCoarse = 8;
    auto mid = [&](int64_t i) { return static_cast<float>(pcm[2 * i]) + static_cast<float>(pcm[2 * i + 1]); };
    auto score = [&](int64_t cand) {
      float dot = 0.f, en = 1e-3f;
      for (int k = 0; k < kLen; k += kStride) {
        const float a = mid(target + k), b = mid(cand + k);
        dot += a * b;
        en += b * b;
      }
      return dot / std::sqrt(en);
    };
    const bool ok = target >= 0 && target + kLen < frames;
    if (ok) {
      int64_t best = s;
      float bestScore = -1e30f;
      auto valid = [&](int64_t cand) { return cand >= 0 && cand + kLen < frames; };
      for (int d = -kWin; d <= kWin; d += kCoarse) {
        if (!valid(s + d)) continue;
        const float sc = score(s + d);
        if (sc > bestScore) { bestScore = sc; best = s + d; }
      }
      if (bestScore > -1e29f) {
        const int64_t center = best;
        for (int d = -kCoarse + 1; d < kCoarse; ++d) {
          if (d == 0 || !valid(center + d)) continue;
          const float sc = score(center + d);
          if (sc > bestScore) { bestScore = sc; best = center + d; }
        }
        s = best;
      }
    }
  }
  if (s < 0) s = 0;
  D.prevStart = s;
  D.gStart[D.nextVoice] = s;
  D.gPhase[D.nextVoice] = 0;
  D.nextVoice ^= 1;
}

// Duas janelas de Hann sobrepostas em 50% (soma exatamente 1); cada grão é lido na velocidade original,
// então o tom não muda. O andamento vem de onde cada grão começa (D.pos avança no ritmo do tempo).
void Engine::stretchRead(DeckAudio& D, float& l, float& r) {
  const int64_t frames = D.track->frames;
  const int16_t* pcm = D.track->pcm.data();
  if (D.stretchReset) {
    D.stretchReset = false;
    D.stretchSkipSearch = true;
    D.gStart[0] = static_cast<int64_t>(D.pos);
    D.gPhase[0] = kHop;    // começa no pico da janela: sem fade-in audível
    D.gPhase[1] = -1;
    D.prevStart = D.gStart[0];
    D.nextVoice = 1;
    D.hopCount = kHop;
  }
  if (D.hopCount <= 0) {
    startGrain(D);
    D.hopCount += kHop;
  }
  --D.hopCount;
  float sl = 0.f, sr = 0.f;
  (void)pcm;
  for (int v = 0; v < 2; ++v) {
    if (D.gPhase[v] < 0) continue;
    const float w = win_[D.gPhase[v]];
    if (D.grainP == 1.f) {
      const int64_t idx = D.gStart[v] + D.gPhase[v];
      if (idx >= 0 && idx < frames) {
        float a, b;
        frameAt(D, idx, a, b);
        sl += w * a;
        sr += w * b;
      }
    } else {
      // tom mudado: o grão é lido mais rápido/devagar (interpolação linear)
      const double fpos = static_cast<double>(D.gStart[v]) + static_cast<double>(D.gPhase[v]) * D.grainP;
      const int64_t i0 = static_cast<int64_t>(fpos);
      if (i0 >= 0 && i0 + 1 < frames) {
        const float fr = static_cast<float>(fpos - static_cast<double>(i0));
        float a0, b0, a1, b1;
        frameAt(D, i0, a0, b0);
        frameAt(D, i0 + 1, a1, b1);
        sl += w * (a0 + (a1 - a0) * fr);
        sr += w * (b0 + (b1 - b0) * fr);
      }
    }
    if (++D.gPhase[v] >= kGrain) D.gPhase[v] = -1;
  }
  l = sl;
  r = sr;
}

void Engine::renderBlock(float* out, float* hp, int n) {
  float blockPeak[kDecks] = {0.f, 0.f};
  float masterBlockPeak = 0.f;
  const float k16 = 1.0f / 32768.0f;

  // Filtro de DJ: os coeficientes são recalculados uma vez por bloco (o cálculo de tan é caro demais por amostra).
  for (int d = 0; d < kDecks; ++d) {
    DeckAudio& D = d_[d];
    updateEq(D, n);
    D.filterSm += (D.filterKnob - D.filterSm) * (1.0f - std::pow(1.0f - smoothCoef_, static_cast<float>(n)));
    const float f = D.filterSm;
    int mode = 0;
    double fc = 0;
    if (f < 0.48f) {
      mode = 1;
      fc = 20000.0 * std::pow(60.0 / 20000.0, (0.5 - f) / 0.5);
    } else if (f > 0.52f) {
      mode = 2;
      fc = 20.0 * std::pow(8000.0 / 20.0, (f - 0.5) / 0.5);
    }
    if (mode == 0) {
      D.svfIc1[0] = D.svfIc1[1] = D.svfIc2[0] = D.svfIc2[1] = 0.f;
    } else {
      fc = std::min(fc, 0.45 * sr_);
      const double g = std::tan(3.14159265358979323846 * fc / sr_);
      const double k = 1.0 / 0.9;
      const double a1 = 1.0 / (1.0 + g * (g + k));
      D.svfK = static_cast<float>(k);
      D.svfA1 = static_cast<float>(a1);
      D.svfA2 = static_cast<float>(g * a1);
      D.svfA3 = static_cast<float>(g * g * a1);
    }
    D.filterMode = mode;
  }

  for (int i = 0; i < n; ++i) {
    xSm_ += (xTarget_ - xSm_) * smoothCoef_;
    hpSm_ += (hpTarget_ - hpSm_) * smoothCoef_;
    hpMixSm_ += (hpMixTarget_ - hpMixSm_) * smoothCoef_;
    masterSm_ += (masterTarget_ - masterSm_) * smoothCoef_;
    if (xSm_ != xCached_) {  // trigonometria só quando o crossfader se mexe
      xCached_ = xSm_;
      xgC_[0] = std::cos(xSm_ * kHalfPi);
      xgC_[1] = std::sin(xSm_ * kHalfPi);
    }
    const float xg[kDecks] = {xgC_[0], xgC_[1]};

    float mixL = 0.f, mixR = 0.f, cueL = 0.f, cueR = 0.f;
    for (int d = 0; d < kDecks; ++d) {
      DeckAudio& D = d_[d];
      const bool scr = D.scratch && D.track != nullptr;
      const bool run = (D.track != nullptr) && (D.wantPlay || scr) && D.pendingSeek < 0;
      if (!run) D.stretchReset = true;
      const float target = run ? 1.f : 0.f;
      if (D.playGain < target) D.playGain = std::min(target, D.playGain + rampStep_);
      else if (D.playGain > target) D.playGain = std::max(target, D.playGain - rampStep_);

      if (D.pendingSeek >= 0 && D.playGain <= 0.f) {
        D.pos = D.track ? static_cast<double>(std::min(D.pendingSeek, D.track->frames)) : 0.0;
        D.pendingSeek = -1;
        D.stretchReset = true;
      }

      if (scr) {
        D.scratchSm += (D.scratchVel - D.scratchSm) * scratchCoef_;
        const float ag = std::fabs(D.scratchSm) * 6.f;
        D.scratchGain = ag > 1.f ? 1.f : ag;   // parado na mão = silêncio (nada de nível DC)
      }
      D.rateSm += (D.rate - D.rateSm) * smoothCoef_;
      if (std::fabs(D.rate - D.rateSm) < 1e-6f) D.rateSm = D.rate;
      // stems: ganhos suavizados; com todos em 1 o caminho é o original (bit a bit)
      if (D.track) {
        bool any = false;
        for (int k = 0; k < 4; ++k) {
          D.stemSm[k] += (D.stemTarget[k] - D.stemSm[k]) * smoothCoef_;
          if (std::fabs(D.stemTarget[k] - D.stemSm[k]) < 1e-5f) D.stemSm[k] = D.stemTarget[k];
          if (D.stemSm[k] != 1.f) any = true;
        }
        D.stemActive = any && D.track->stemsReady.load(std::memory_order_acquire);
        if (D.stemActive) {
          D.stemPtr = D.track->stemPcm.data();
          const float gO = D.stemSm[3];
          D.stemC[0] = gO;
          D.stemC[1] = D.stemSm[0] - gO;
          D.stemC[2] = D.stemSm[1] - gO;
          D.stemC[3] = D.stemSm[2] - gO;
        }
      }

      float l = 0.f, r = 0.f;
      if (D.track && D.playGain > 0.f) {
        const int64_t frames = D.track->frames;
        const float step = scr ? D.scratchSm : D.rateSm;
        if (D.pos < 0.0) D.pos = 0.0;
        if (D.pos < static_cast<double>(frames)) {
          if ((D.keyLock || D.keyShift != 0.f) && !scr) {
            const float shiftP = D.keyShift == 0.f ? 1.f : std::exp2(D.keyShift / 12.f);
            D.grainP = D.keyLock ? shiftP : shiftP * D.rateSm;
            stretchRead(D, l, r);
          } else {
            const int64_t i0 = static_cast<int64_t>(D.pos);
            const float t = static_cast<float>(D.pos - static_cast<double>(i0));
            if (t == 0.f) {
              frameAt(D, i0, l, r);
            } else {
              const int64_t im = i0 > 0 ? i0 - 1 : 0;
              const int64_t i1 = std::min(i0 + 1, frames - 1);
              const int64_t i2 = std::min(i0 + 2, frames - 1);
              float lm, rm, l0, r0, l1, r1, l2, r2;
              frameAt(D, im, lm, rm); frameAt(D, i0, l0, r0); frameAt(D, i1, l1, r1); frameAt(D, i2, l2, r2);
              l = hermite(lm, l0, l1, l2, t);
              r = hermite(rm, r0, r1, r2, t);
            }
          }
          D.pos += static_cast<double>(step);
          if (D.loopOn && D.pos >= static_cast<double>(D.loopEnd)) {
            const double len = static_cast<double>(D.loopEnd - D.loopStart);
            D.pos = static_cast<double>(D.loopStart) + std::fmod(D.pos - static_cast<double>(D.loopStart), len);
            D.stretchReset = true;
          }
          if (D.pos < 0.0) D.pos = 0.0;
        }
        if (D.pos >= static_cast<double>(frames)) {
          if (scr) {
            D.pos = static_cast<double>(frames) - 1.0;   // na mão do DJ o disco não "acaba"
          } else {  // acabou: para sem rampa (a faixa termina em silêncio)
            D.wantPlay = false;
            D.playGain = 0.f;
            pub_[d].playing.store(false, std::memory_order_relaxed);
          }
        }
        const float g = scr ? D.playGain * D.scratchGain : D.playGain;
        l *= g;
        r *= g;
      }

      // Equalizador: prateleira grave, pico médio e prateleira aguda em série. Neutro = identidade exata.
      {
        float* ch[2] = {&l, &r};
        for (int c = 0; c < 2; ++c) {
          float x = *ch[c];
          for (int b = 0; b < 3; ++b) {
            const float y = D.eqB0[b] * x + D.eqZ1[c][b];
            D.eqZ1[c][b] = D.eqB1[b] * x - D.eqA1[b] * y + D.eqZ2[c][b];
            D.eqZ2[c][b] = D.eqB2[b] * x - D.eqA2[b] * y;
            x = y;
          }
          *ch[c] = x;
        }
      }

      // Filtro de DJ (variável de estado, forma TPT).
      if (D.filterMode != 0) {
        float* ch[2] = {&l, &r};
        for (int c = 0; c < 2; ++c) {
          const float x = *ch[c];
          const float v3 = x - D.svfIc2[c];
          const float v1 = D.svfA1 * D.svfIc1[c] + D.svfA2 * v3;
          const float v2 = D.svfIc2[c] + D.svfA2 * D.svfIc1[c] + D.svfA3 * v3;
          D.svfIc1[c] = 2.f * v1 - D.svfIc1[c];
          D.svfIc2[c] = 2.f * v2 - D.svfIc2[c];
          *ch[c] = D.filterMode == 1 ? v2 : x - D.svfK * v1 - v2;
        }
      }

      D.fx.process(l, r, smoothCoef_);
      if (D.cueOn) { cueL += l; cueR += r; }   // pré-escuta: antes do fader e do crossfader

      D.volSm += (D.vol - D.volSm) * smoothCoef_;
      D.trimSm += (D.trim - D.trimSm) * smoothCoef_;
      l *= D.volSm * D.trimSm;
      r *= D.volSm * D.trimSm;
      blockPeak[d] = std::max(blockPeak[d], std::max(std::fabs(l), std::fabs(r)));
      mixL += l * xg[d];
      mixR += r * xg[d];
    }

    sampVolSm_ += (sampVol_ - sampVolSm_) * smoothCoef_;
    for (int k = 0; k < kSamples; ++k) {
      SampSlot& S = s_[k];
      if (!S.track) continue;
      if (S.want && S.delay > 0) { --S.delay; continue; }   // espera a batida
      const float tg = S.want ? 1.f : 0.f;
      if (S.gain < tg) S.gain = std::min(tg, S.gain + rampStep_);
      else if (S.gain > tg) S.gain = std::max(tg, S.gain - rampStep_);
      if (S.gain <= 0.f) continue;
      const int64_t idx = static_cast<int64_t>(S.pos);
      if (idx < S.track->frames) {
        // interpolação linear: o pad pode tocar mais rápido ou mais devagar para seguir o andamento
        const float fr = static_cast<float>(S.pos - static_cast<double>(idx));
        int64_t nx = idx + 1;
        if (nx >= S.track->frames) nx = S.loop ? 0 : idx;
        const float g = k16 * S.gain * sampVolSm_;
        const float l0 = S.track->pcm[static_cast<size_t>(2 * idx)], l1 = S.track->pcm[static_cast<size_t>(2 * nx)];
        const float r0 = S.track->pcm[static_cast<size_t>(2 * idx + 1)], r1 = S.track->pcm[static_cast<size_t>(2 * nx + 1)];
        mixL += (l0 + (l1 - l0) * fr) * g;
        mixR += (r0 + (r1 - r0) * fr) * g;
      }
      S.pos += S.speed;
      if (S.pos >= static_cast<double>(S.track->frames)) {
        if (S.loop && S.want) S.pos -= static_cast<double>(S.track->frames);
        else { S.want = false; S.gain = 0.f; }
      }
    }
    mixL = softLimit(mixL * masterSm_);
    mixR = softLimit(mixR * masterSm_);
    out[2 * i] = mixL;
    out[2 * i + 1] = mixR;
    if (hp) {
      hp[2 * i] = softLimit((cueL * (1.f - hpMixSm_) + mixL * hpMixSm_) * hpSm_);
      hp[2 * i + 1] = softLimit((cueR * (1.f - hpMixSm_) + mixR * hpMixSm_) * hpSm_);
    }
    masterBlockPeak = std::max(masterBlockPeak, std::max(std::fabs(mixL), std::fabs(mixR)));
  }

  {
    uint32_t mask = 0;
    for (int k = 0; k < kSamples; ++k) if (s_[k].track && s_[k].gain > 0.f) mask |= 1u << k;
    sampMask_.store(mask, std::memory_order_relaxed);
  }
  const float decay = peakDecayPerFrame_ * static_cast<float>(n);
  for (int d = 0; d < kDecks; ++d) {
    DeckAudio& D = d_[d];
    D.peak = std::max(blockPeak[d], D.peak - decay);
    pub_[d].peak.store(D.peak, std::memory_order_relaxed);
    pub_[d].pos.store(static_cast<int64_t>(D.pos), std::memory_order_relaxed);
    pub_[d].cue.store(D.cue, std::memory_order_relaxed);
  }
  masterPeakLocal_ = std::max(masterBlockPeak, masterPeakLocal_ - decay);
  masterPeak_.store(masterPeakLocal_, std::memory_order_relaxed);
}

}  // namespace djf
