#include "engine.h"

#include <algorithm>
#include <cmath>

namespace djf {

namespace {
constexpr float kHalfPi = 1.57079632679489662f;
// NaN vira 0: um NaN que chegasse ao áudio contaminaria o filtro e o eco para sempre.
inline float clamp01(float v) { return !(v >= 0.f) ? 0.f : (v > 1.f ? 1.f : v); }
// Limitador suave: abaixo de 0,8 não mexe no som; acima, curva suave que nunca passa de 1 (sem estalo de corte seco).
inline float softLimit(float x) {
  const float a = std::fabs(x);
  if (a <= 0.8f) return x;
  const float y = 0.8f + 0.2f * std::tanh((a - 0.8f) * 5.f);
  return x < 0.f ? -y : y;
}
}  // namespace

Engine::Engine(int sampleRate, int maxBlockFrames) : sr_(sampleRate), maxBlock_(maxBlockFrames) {
  rampStep_ = 1.0f / (0.004f * static_cast<float>(sr_));
  smoothCoef_ = 1.0f - std::exp(-1.0f / (0.010f * static_cast<float>(sr_)));
  peakDecayPerFrame_ = 1.0f / (0.8f * static_cast<float>(sr_));
  for (int d = 0; d < kDecks; ++d) d_[d].fx = DeckFx(sampleRate);
}

// ---------------------------------------------------------------- controle

bool Engine::send(const Cmd& c) {
  std::lock_guard<std::mutex> lock(producerMutex_);
  return queue_.push(c);
}

bool Engine::loadTrack(int deck, std::shared_ptr<const Track> track) {
  if (deck < 0 || deck >= kDecks || !track || track->sampleRate != sr_) return false;
  std::lock_guard<std::mutex> lock(producerMutex_);
  Cmd c;
  c.type = CmdType::Load;
  c.deck = static_cast<uint8_t>(deck);
  c.track = track.get();
  c.seq = issued_[deck] + 1;
  if (!queue_.push(c)) return false;
  issued_[deck] = c.seq;
  if (current_[deck]) retired_.push_back({current_[deck], deck, c.seq});
  current_[deck] = std::move(track);
  return true;
}

void Engine::unload(int deck) {
  if (deck < 0 || deck >= kDecks) return;
  std::lock_guard<std::mutex> lock(producerMutex_);
  Cmd c;
  c.type = CmdType::Load;
  c.deck = static_cast<uint8_t>(deck);
  c.track = nullptr;
  c.seq = issued_[deck] + 1;
  if (!queue_.push(c)) return;
  issued_[deck] = c.seq;
  if (current_[deck]) retired_.push_back({current_[deck], deck, c.seq});
  current_[deck].reset();
}

void Engine::play(int deck) {
  if (deck < 0 || deck >= kDecks) return;
  Cmd c; c.type = CmdType::Play; c.deck = static_cast<uint8_t>(deck);
  send(c);
}

void Engine::pause(int deck) {
  if (deck < 0 || deck >= kDecks) return;
  Cmd c; c.type = CmdType::Pause; c.deck = static_cast<uint8_t>(deck);
  send(c);
}

void Engine::cue(int deck) {
  if (deck < 0 || deck >= kDecks) return;
  Cmd c; c.type = CmdType::Cue; c.deck = static_cast<uint8_t>(deck);
  send(c);
}

void Engine::seekFrames(int deck, int64_t frame) {
  if (deck < 0 || deck >= kDecks) return;
  Cmd c; c.type = CmdType::Seek; c.deck = static_cast<uint8_t>(deck); c.i = frame;
  send(c);
}

void Engine::setVolume(int deck, float v) {
  if (deck < 0 || deck >= kDecks) return;
  Cmd c; c.type = CmdType::Volume; c.deck = static_cast<uint8_t>(deck); c.f = clamp01(v);
  send(c);
}

void Engine::setCrossfader(float x) {
  Cmd c; c.type = CmdType::Crossfader; c.f = clamp01(x);
  send(c);
}

void Engine::setMaster(float v) {
  Cmd c; c.type = CmdType::Master; c.f = clamp01(v);
  send(c);
}

void Engine::setRate(int deck, float rate) {
  if (deck < 0 || deck >= kDecks || !(rate == rate)) return;
  Cmd c; c.type = CmdType::Rate; c.deck = static_cast<uint8_t>(deck);
  c.f = rate < 0.5f ? 0.5f : (rate > 2.0f ? 2.0f : rate);
  send(c);
}

void Engine::setEq(int deck, int band, float v) {
  if (deck < 0 || deck >= kDecks || band < 0 || band > 2) return;
  Cmd c; c.type = CmdType::Eq; c.deck = static_cast<uint8_t>(deck); c.i = band; c.f = clamp01(v);
  send(c);
}

void Engine::setFilter(int deck, float v) {
  if (deck < 0 || deck >= kDecks) return;
  Cmd c; c.type = CmdType::Filter; c.deck = static_cast<uint8_t>(deck); c.f = clamp01(v);
  send(c);
}

void Engine::setLoop(int deck, int64_t start, int64_t end) {
  if (deck < 0 || deck >= kDecks || start < 0 || end - start < 256) return;
  Cmd c; c.type = CmdType::LoopOn; c.deck = static_cast<uint8_t>(deck); c.i = start; c.j = end;
  send(c);
}

void Engine::setFx(int deck, int type, float amount, double beatSeconds) {
  if (deck < 0 || deck >= kDecks) return;
  Cmd c;
  c.type = CmdType::Fx;
  c.deck = static_cast<uint8_t>(deck);
  c.f = clamp01(amount);
  c.i = (type >= 0 && type <= 3) ? type : 0;
  c.j = static_cast<int64_t>((beatSeconds >= 0.05 && beatSeconds <= 5.0 ? beatSeconds : 0.5) * 1e6);
  send(c);
}

void Engine::clearLoop(int deck) {
  if (deck < 0 || deck >= kDecks) return;
  Cmd c; c.type = CmdType::LoopOff; c.deck = static_cast<uint8_t>(deck);
  send(c);
}

Engine::DeckInfo Engine::deckInfo(int deck) const {
  DeckInfo info;
  if (deck < 0 || deck >= kDecks) return info;
  const DeckPub& p = pub_[deck];
  info.loaded = p.loaded.load(std::memory_order_relaxed);
  info.playing = p.playing.load(std::memory_order_relaxed);
  info.positionFrames = p.pos.load(std::memory_order_relaxed);
  info.cueFrames = p.cue.load(std::memory_order_relaxed);
  info.lengthFrames = p.length.load(std::memory_order_relaxed);
  info.peak = p.peak.load(std::memory_order_relaxed);
  return info;
}

void Engine::collectGarbage() {
  std::lock_guard<std::mutex> lock(producerMutex_);
  retired_.erase(
      std::remove_if(retired_.begin(), retired_.end(),
                     [this](const Retired& r) {
                       return pub_[r.deck].appliedSeq.load(std::memory_order_acquire) >= r.seq;
                     }),
      retired_.end());
}

// ------------------------------------------------------------------- áudio

void Engine::drain() {
  Cmd c;
  while (queue_.pop(c)) {
    if (c.type == CmdType::Crossfader) { xTarget_ = c.f; continue; }
    if (c.type == CmdType::Master) { masterTarget_ = c.f; continue; }
    DeckAudio& D = d_[c.deck];
    DeckPub& P = pub_[c.deck];
    switch (c.type) {
      case CmdType::Load:
        D.track = c.track;
        D.pos = 0;
        D.cue = 0;
        D.loopOn = false;
        D.pendingSeek = -1;
        D.wantPlay = false;
        D.playGain = 0.f;
        P.loaded.store(c.track != nullptr, std::memory_order_relaxed);
        P.length.store(c.track ? c.track->frames : 0, std::memory_order_relaxed);
        P.pos.store(0, std::memory_order_relaxed);
        P.cue.store(0, std::memory_order_relaxed);
        P.playing.store(false, std::memory_order_relaxed);
        P.appliedSeq.store(c.seq, std::memory_order_release);
        break;
      case CmdType::Play:
        if (!D.track) break;
        if (D.pos >= static_cast<double>(D.track->frames)) D.pendingSeek = 0;  // fim da faixa: recomeça do início
        D.wantPlay = true;
        P.playing.store(true, std::memory_order_relaxed);
        break;
      case CmdType::Pause:
        D.wantPlay = false;
        P.playing.store(false, std::memory_order_relaxed);
        break;
      case CmdType::Cue:
        if (!D.track) break;
        if (D.wantPlay) {
          D.pendingSeek = D.cue;
          D.wantPlay = false;
          P.playing.store(false, std::memory_order_relaxed);
        } else {
          D.cue = std::min<int64_t>(static_cast<int64_t>(D.pos), D.track->frames);
          P.cue.store(D.cue, std::memory_order_relaxed);
        }
        break;
      case CmdType::Seek:
        if (!D.track) break;
        D.pendingSeek = std::max<int64_t>(0, std::min(c.i, D.track->frames));
        break;
      case CmdType::Volume:
        D.vol = c.f;
        break;
      case CmdType::Rate:
        D.rate = c.f;
        break;
      case CmdType::Eq:
        D.eqKnob[c.i] = c.f;
        break;
      case CmdType::Filter:
        D.filterKnob = c.f;
        break;
      case CmdType::LoopOn:
        if (D.track && c.j <= D.track->frames) {
          D.loopStart = c.i;
          D.loopEnd = c.j;
          D.loopOn = true;
        }
        break;
      case CmdType::Fx:
        d_[c.deck].fx.set(static_cast<int>(c.i), c.f, static_cast<double>(c.j) * 1e-6);
        break;
      case CmdType::LoopOff:
        D.loopOn = false;
        break;
      default:
        break;
    }
  }
}

void Engine::render(float* out, int frames) {
  drain();
  while (frames > 0) {
    const int n = std::min(frames, maxBlock_);
    renderBlock(out, n);
    out += 2 * n;
    frames -= n;
  }
}

namespace {
// Curva do equalizador em dB: 0 corta (-40 dB), 0,5 neutro, 1 dá +6 dB.
inline float eqDb(float v) { return v < 0.5f ? -40.f * (1.f - 2.f * v) : 6.f * (2.f * v - 1.f); }

// Interpolação cúbica (Hermite) entre y0 e y1, com vizinhos ym1 e y2.
inline float hermite(float ym1, float y0, float y1, float y2, float t) {
  const float c1 = 0.5f * (y1 - ym1);
  const float c2 = ym1 - 2.5f * y0 + 2.f * y1 - 0.5f * y2;
  const float c3 = 0.5f * (y2 - ym1) + 1.5f * (y0 - y1);
  return ((c3 * t + c2) * t + c1) * t + y0;
}
}  // namespace

// Coeficientes das três seções (livro de receitas de áudio de Robert Bristow-Johnson).
void Engine::updateEq(DeckAudio& D, int n) {
  const float blockCoef = 1.0f - std::pow(1.0f - smoothCoef_, static_cast<float>(n));
  for (int b = 0; b < 3; ++b) {
    const float before = D.eqSm[b];
    D.eqSm[b] += (D.eqKnob[b] - D.eqSm[b]) * blockCoef;
    if (std::fabs(D.eqKnob[b] - D.eqSm[b]) < 1e-4f) D.eqSm[b] = D.eqKnob[b];
    if (D.eqSm[b] == before) continue;
    const double db = eqDb(D.eqSm[b]);
    if (std::fabs(db) < 1e-3) {  // neutro: seção idêntica, o som passa sem mudança
      D.eqB0[b] = 1; D.eqB1[b] = D.eqB2[b] = D.eqA1[b] = D.eqA2[b] = 0;
      continue;
    }
    const double pi = 3.14159265358979323846;
    const double A = std::pow(10.0, db / 40.0);
    const double f0 = b == 0 ? 200.0 : (b == 1 ? 1000.0 : 4500.0);
    const double w0 = 2.0 * pi * f0 / sr_;
    const double cw = std::cos(w0), sw = std::sin(w0);
    double b0, b1, b2, a0, a1, a2;
    if (b == 1) {  // pico, Q = 1
      const double alpha = sw / (2.0 * 1.0);
      b0 = 1 + alpha * A; b1 = -2 * cw; b2 = 1 - alpha * A;
      a0 = 1 + alpha / A; a1 = -2 * cw; a2 = 1 - alpha / A;
    } else {       // prateleiras com inclinação S = 1
      const double alpha = sw / 2.0 * std::sqrt(2.0);
      const double tsa = 2.0 * std::sqrt(A) * alpha;
      if (b == 0) {
        b0 = A * ((A + 1) - (A - 1) * cw + tsa);
        b1 = 2 * A * ((A - 1) - (A + 1) * cw);
        b2 = A * ((A + 1) - (A - 1) * cw - tsa);
        a0 = (A + 1) + (A - 1) * cw + tsa;
        a1 = -2 * ((A - 1) + (A + 1) * cw);
        a2 = (A + 1) + (A - 1) * cw - tsa;
      } else {
        b0 = A * ((A + 1) + (A - 1) * cw + tsa);
        b1 = -2 * A * ((A - 1) + (A + 1) * cw);
        b2 = A * ((A + 1) + (A - 1) * cw - tsa);
        a0 = (A + 1) - (A - 1) * cw + tsa;
        a1 = 2 * ((A - 1) - (A + 1) * cw);
        a2 = (A + 1) - (A - 1) * cw - tsa;
      }
    }
    D.eqB0[b] = static_cast<float>(b0 / a0); D.eqB1[b] = static_cast<float>(b1 / a0);
    D.eqB2[b] = static_cast<float>(b2 / a0); D.eqA1[b] = static_cast<float>(a1 / a0);
    D.eqA2[b] = static_cast<float>(a2 / a0);
  }
}

void Engine::renderBlock(float* out, int n) {
  float blockPeak[kDecks] = {0.f, 0.f};
  float masterBlockPeak = 0.f;
  const float k16 = 1.0f / 32768.0f;

  // Filtro de DJ: os coeficientes são recalculados uma vez por bloco (o cálculo de tan é caro demais por amostra).
  for (int d = 0; d < kDecks; ++d) {
    DeckAudio& D = d_[d];
    updateEq(D, n);
    D.filterSm += (D.filterKnob - D.filterSm) * (1.0f - std::pow(1.0f - smoothCoef_, static_cast<float>(n)));
    const float f = D.filterSm;
    int mode = 0;
    double fc = 0;
    if (f < 0.48f) {
      mode = 1;
      fc = 20000.0 * std::pow(60.0 / 20000.0, (0.5 - f) / 0.5);
    } else if (f > 0.52f) {
      mode = 2;
      fc = 20.0 * std::pow(8000.0 / 20.0, (f - 0.5) / 0.5);
    }
    if (mode == 0) {
      D.svfIc1[0] = D.svfIc1[1] = D.svfIc2[0] = D.svfIc2[1] = 0.f;
    } else {
      fc = std::min(fc, 0.45 * sr_);
      const double g = std::tan(3.14159265358979323846 * fc / sr_);
      const double k = 1.0 / 0.9;
      const double a1 = 1.0 / (1.0 + g * (g + k));
      D.svfK = static_cast<float>(k);
      D.svfA1 = static_cast<float>(a1);
      D.svfA2 = static_cast<float>(g * a1);
      D.svfA3 = static_cast<float>(g * g * a1);
    }
    D.filterMode = mode;
  }

  for (int i = 0; i < n; ++i) {
    xSm_ += (xTarget_ - xSm_) * smoothCoef_;
    masterSm_ += (masterTarget_ - masterSm_) * smoothCoef_;
    if (xSm_ != xCached_) {  // trigonometria só quando o crossfader se mexe
      xCached_ = xSm_;
      xgC_[0] = std::cos(xSm_ * kHalfPi);
      xgC_[1] = std::sin(xSm_ * kHalfPi);
    }
    const float xg[kDecks] = {xgC_[0], xgC_[1]};

    float mixL = 0.f, mixR = 0.f;
    for (int d = 0; d < kDecks; ++d) {
      DeckAudio& D = d_[d];
      const bool run = (D.track != nullptr) && D.wantPlay && D.pendingSeek < 0;
      const float target = run ? 1.f : 0.f;
      if (D.playGain < target) D.playGain = std::min(target, D.playGain + rampStep_);
      else if (D.playGain > target) D.playGain = std::max(target, D.playGain - rampStep_);

      if (D.pendingSeek >= 0 && D.playGain <= 0.f) {
        D.pos = D.track ? static_cast<double>(std::min(D.pendingSeek, D.track->frames)) : 0.0;
        D.pendingSeek = -1;
      }

      D.rateSm += (D.rate - D.rateSm) * smoothCoef_;
      if (std::fabs(D.rate - D.rateSm) < 1e-6f) D.rateSm = D.rate;

      float l = 0.f, r = 0.f;
      if (D.track && D.playGain > 0.f) {
        const int64_t frames = D.track->frames;
        if (D.pos < static_cast<double>(frames)) {
          const int16_t* pcm = D.track->pcm.data();
          const int64_t i0 = static_cast<int64_t>(D.pos);
          const float t = static_cast<float>(D.pos - static_cast<double>(i0));
          if (t == 0.f) {
            l = pcm[2 * i0] * k16;
            r = pcm[2 * i0 + 1] * k16;
          } else {
            const int64_t im = i0 > 0 ? i0 - 1 : 0;
            const int64_t i1 = std::min(i0 + 1, frames - 1);
            const int64_t i2 = std::min(i0 + 2, frames - 1);
            l = hermite(pcm[2 * im] * k16, pcm[2 * i0] * k16, pcm[2 * i1] * k16, pcm[2 * i2] * k16, t);
            r = hermite(pcm[2 * im + 1] * k16, pcm[2 * i0 + 1] * k16, pcm[2 * i1 + 1] * k16,
                        pcm[2 * i2 + 1] * k16, t);
          }
          D.pos += static_cast<double>(D.rateSm);
          if (D.loopOn && D.pos >= static_cast<double>(D.loopEnd)) {
            const double len = static_cast<double>(D.loopEnd - D.loopStart);
            D.pos = static_cast<double>(D.loopStart) + std::fmod(D.pos - static_cast<double>(D.loopStart), len);
          }
        }
        if (D.pos >= static_cast<double>(frames)) {  // acabou: para sem rampa (a faixa termina em silêncio)
          D.wantPlay = false;
          D.playGain = 0.f;
          pub_[d].playing.store(false, std::memory_order_relaxed);
        }
        l *= D.playGain;
        r *= D.playGain;
      }

      // Equalizador: prateleira grave, pico médio e prateleira aguda em série. Neutro = identidade exata.
      {
        float* ch[2] = {&l, &r};
        for (int c = 0; c < 2; ++c) {
          float x = *ch[c];
          for (int b = 0; b < 3; ++b) {
            const float y = D.eqB0[b] * x + D.eqZ1[c][b];
            D.eqZ1[c][b] = D.eqB1[b] * x - D.eqA1[b] * y + D.eqZ2[c][b];
            D.eqZ2[c][b] = D.eqB2[b] * x - D.eqA2[b] * y;
            x = y;
          }
          *ch[c] = x;
        }
      }

      // Filtro de DJ (variável de estado, forma TPT).
      if (D.filterMode != 0) {
        float* ch[2] = {&l, &r};
        for (int c = 0; c < 2; ++c) {
          const float x = *ch[c];
          const float v3 = x - D.svfIc2[c];
          const float v1 = D.svfA1 * D.svfIc1[c] + D.svfA2 * v3;
          const float v2 = D.svfIc2[c] + D.svfA2 * D.svfIc1[c] + D.svfA3 * v3;
          D.svfIc1[c] = 2.f * v1 - D.svfIc1[c];
          D.svfIc2[c] = 2.f * v2 - D.svfIc2[c];
          *ch[c] = D.filterMode == 1 ? v2 : x - D.svfK * v1 - v2;
        }
      }

      D.fx.process(l, r, smoothCoef_);

      D.volSm += (D.vol - D.volSm) * smoothCoef_;
      l *= D.volSm;
      r *= D.volSm;
      blockPeak[d] = std::max(blockPeak[d], std::max(std::fabs(l), std::fabs(r)));
      mixL += l * xg[d];
      mixR += r * xg[d];
    }

    mixL = softLimit(mixL * masterSm_);
    mixR = softLimit(mixR * masterSm_);
    out[2 * i] = mixL;
    out[2 * i + 1] = mixR;
    masterBlockPeak = std::max(masterBlockPeak, std::max(std::fabs(mixL), std::fabs(mixR)));
  }

  const float decay = peakDecayPerFrame_ * static_cast<float>(n);
  for (int d = 0; d < kDecks; ++d) {
    DeckAudio& D = d_[d];
    D.peak = std::max(blockPeak[d], D.peak - decay);
    pub_[d].peak.store(D.peak, std::memory_order_relaxed);
    pub_[d].pos.store(static_cast<int64_t>(D.pos), std::memory_order_relaxed);
    pub_[d].cue.store(D.cue, std::memory_order_relaxed);
  }
  masterPeakLocal_ = std::max(masterBlockPeak, masterPeakLocal_ - decay);
  masterPeak_.store(masterPeakLocal_, std::memory_order_relaxed);
}

}  // namespace djf
