// Ponte JNI entre o Kotlin (app.djfusion.audio.NativeEngine) e o motor C++.
#include <jni.h>

#include <algorithm>
#include <atomic>
#include <chrono>
#include <cstdio>
#include <cstring>
#include <mutex>
#include <string>
#include <thread>
#include <memory>
#include <vector>

#include "audio_host.h"
#include "core/bpm.h"
#include "core/energy.h"
#include "core/key.h"
#include "core/samples.h"
#include "core/stems.h"
#include "core/track.h"

namespace {

std::shared_ptr<djf::AudioHost>& hostPtr() {
  static std::shared_ptr<djf::AudioHost> host = std::make_shared<djf::AudioHost>();
  return host;
}
djf::Engine& engine() { return hostPtr()->engine(); }

using TrackPtr = std::shared_ptr<const djf::Track>;

}  // namespace

extern "C" {

#define JNI(ret, name) JNIEXPORT ret JNICALL Java_app_djfusion_audio_NativeEngine_##name

// ---------------------------------------------------------------- saída de áudio
JNI(jboolean, nativeStart)(JNIEnv*, jclass) { return hostPtr()->start() ? JNI_TRUE : JNI_FALSE; }

JNI(void, nativeConfigureOutput)(JNIEnv*, jclass, jint mode, jint deviceId) {
  hostPtr()->configureOutput(mode, deviceId);
}

JNI(void, nativeStop)(JNIEnv*, jclass) { hostPtr()->stop(); }

JNI(void, nativeStreamInfo)(JNIEnv* env, jclass, jintArray out) {
  int32_t v[6];
  hostPtr()->info(v);
  if (!out || env->GetArrayLength(out) < 6) return;
  env->SetIntArrayRegion(out, 0, 6, reinterpret_cast<const jint*>(v));
}

// ------------------------------------------------------ construção de faixas
JNI(jlong, nativeBeginTrack)(JNIEnv*, jclass, jint srcRate, jlong maxFrames) {
  if (srcRate < 8000 || srcRate > 384000) return 0;
  return reinterpret_cast<jlong>(new djf::TrackBuilder(srcRate, djf::kEngineRate, maxFrames));
}

JNI(void, nativeAppend)(JNIEnv* env, jclass, jlong handle, jobject buffer, jint offset, jint size,
                        jint channels, jboolean isFloat) {
  auto* b = reinterpret_cast<djf::TrackBuilder*>(handle);
  if (!b || channels < 1 || size <= 0) return;
  auto* base = static_cast<const uint8_t*>(env->GetDirectBufferAddress(buffer));
  if (!base || offset < 0) return;
  const jlong cap = env->GetDirectBufferCapacity(buffer);
  if (cap < 0 || static_cast<jlong>(offset) + size > cap) return;  // nunca ler além do buffer
  const uint8_t* p = base + offset;
  try {
  if (isFloat) {
    const size_t frames = static_cast<size_t>(size) / (sizeof(float) * channels);
    static thread_local std::vector<float> tmp;
    tmp.resize(frames * channels);
    std::memcpy(tmp.data(), p, tmp.size() * sizeof(float));  // cópia evita leitura desalinhada
    b->appendFloat(tmp.data(), frames, channels);
  } else {
    const size_t frames = static_cast<size_t>(size) / (sizeof(int16_t) * channels);
    static thread_local std::vector<int16_t> tmp;
    tmp.resize(frames * channels);
    std::memcpy(tmp.data(), p, tmp.size() * sizeof(int16_t));
    b->appendPcm16(tmp.data(), frames, channels);
  }
  } catch (...) {
    b->markFailed();  // sem memória: nunca deixar uma exceção C++ atravessar o JNI
  }
}

JNI(jboolean, nativeBuilderTooLong)(JNIEnv*, jclass, jlong handle) {
  auto* b = reinterpret_cast<djf::TrackBuilder*>(handle);
  return (b && b->tooLong()) ? JNI_TRUE : JNI_FALSE;
}

// 0 = faixa vazia, -1 = passou do limite, senão um identificador da faixa pronta.
JNI(jlong, nativeFinishTrack)(JNIEnv*, jclass, jlong handle) {
  std::unique_ptr<djf::TrackBuilder> b(reinterpret_cast<djf::TrackBuilder*>(handle));
  if (!b) return 0;
  try {
    std::shared_ptr<djf::Track> t = b->finish();
    if (b->tooLong()) return -1;
    if (t->frames <= 0) return 0;
    return reinterpret_cast<jlong>(new TrackPtr(std::move(t)));
  } catch (...) {
    return -1;
  }
}

JNI(void, nativeAbortTrack)(JNIEnv*, jclass, jlong handle) {
  delete reinterpret_cast<djf::TrackBuilder*>(handle);
}

JNI(jlong, nativeTrackFrames)(JNIEnv*, jclass, jlong track) {
  auto* t = reinterpret_cast<TrackPtr*>(track);
  return t ? (*t)->frames : 0;
}

JNI(jbyteArray, nativeTrackPeaks)(JNIEnv* env, jclass, jlong track) {
  auto* t = reinterpret_cast<TrackPtr*>(track);
  const size_t n = t ? (*t)->peaks.size() : 0;
  jbyteArray arr = env->NewByteArray(static_cast<jsize>(n));
  if (arr && n > 0) {
    env->SetByteArrayRegion(arr, 0, static_cast<jsize>(n), reinterpret_cast<const jbyte*>((*t)->peaks.data()));
  }
  return arr;
}

// Solta a referência do lado Kotlin. O motor mantém a sua própria, se a faixa estiver carregada.
JNI(void, nativeFreeTrack)(JNIEnv*, jclass, jlong track) { delete reinterpret_cast<TrackPtr*>(track); }

// -------------------------------------------------------------- controle dos decks
JNI(jboolean, nativeLoad)(JNIEnv*, jclass, jint deck, jlong track) {
  auto* t = reinterpret_cast<TrackPtr*>(track);
  return (t && engine().loadTrack(deck, *t)) ? JNI_TRUE : JNI_FALSE;
}
JNI(void, nativeUnload)(JNIEnv*, jclass, jint deck) { engine().unload(deck); }
JNI(void, nativePlay)(JNIEnv*, jclass, jint deck) { engine().play(deck); }
JNI(void, nativePause)(JNIEnv*, jclass, jint deck) { engine().pause(deck); }
JNI(void, nativeCue)(JNIEnv*, jclass, jint deck) { engine().cue(deck); }
JNI(void, nativeSeek)(JNIEnv*, jclass, jint deck, jlong frame) { engine().seekFrames(deck, frame); }
JNI(void, nativeSetVolume)(JNIEnv*, jclass, jint deck, jfloat v) { engine().setVolume(deck, v); }
JNI(void, nativeSetCrossfader)(JNIEnv*, jclass, jfloat x) { engine().setCrossfader(x); }
JNI(void, nativeSetMaster)(JNIEnv*, jclass, jfloat v) { engine().setMaster(v); }
JNI(void, nativeSetRate)(JNIEnv*, jclass, jint deck, jfloat rate) { engine().setRate(deck, rate); }
JNI(void, nativeSetEq)(JNIEnv*, jclass, jint deck, jint band, jfloat v) { engine().setEq(deck, band, v); }
JNI(void, nativeSetFx)(JNIEnv*, jclass, jint deck, jint type, jfloat amount, jfloat beatSeconds) {
  engine().setFx(deck, type, amount, beatSeconds);
}
JNI(void, nativeSetKeyLock)(JNIEnv*, jclass, jint deck, jboolean on) { engine().setKeyLock(deck, on == JNI_TRUE); }
JNI(void, nativeScratch)(JNIEnv*, jclass, jint deck, jboolean active, jfloat velocity) {
  engine().scratch(deck, active == JNI_TRUE, velocity);
}
JNI(void, nativeSetHeadphoneCue)(JNIEnv*, jclass, jint deck, jboolean on) { engine().setHeadphoneCue(deck, on == JNI_TRUE); }
JNI(void, nativeSetHeadphoneLevel)(JNIEnv*, jclass, jfloat v) { engine().setHeadphoneLevel(v); }
JNI(void, nativeSetHeadphoneMix)(JNIEnv*, jclass, jfloat v) { engine().setHeadphoneMix(v); }
JNI(void, nativeSetFilter)(JNIEnv*, jclass, jint deck, jfloat v) { engine().setFilter(deck, v); }
JNI(void, nativeSetLoop)(JNIEnv*, jclass, jint deck, jlong start, jlong end) { engine().setLoop(deck, start, end); }
JNI(void, nativeClearLoop)(JNIEnv*, jclass, jint deck) { engine().clearLoop(deck); }

// Detecta o andamento da faixa (fora do tempo real, pode levar algumas centenas de ms).
// out: [bpm (0 = não detectado), primeira batida em quadros, confiança de 0 a 1]
JNI(void, nativeAnalyze)(JNIEnv* env, jclass, jlong track, jdoubleArray out) {
  double v[3] = {0, 0, 0};
  auto* t = reinterpret_cast<TrackPtr*>(track);
  if (t) {
    try {
      const djf::BpmResult r = djf::analyzeBpm(**t);
      v[0] = r.bpm;
      v[1] = static_cast<double>(r.firstBeatFrame);
      v[2] = r.confidence;
    } catch (...) {
    }
  }
  env->SetDoubleArrayRegion(out, 0, 3, v);
}

// Tonalidade da faixa. out: [válida (0/1), nota 0..11 (0 = Dó), 1 se menor, confiança x 1000]
JNI(void, nativeAnalyzeKey)(JNIEnv* env, jclass, jlong track, jintArray out) {
  jint v[4] = {0, 0, 0, 0};
  auto* t = reinterpret_cast<TrackPtr*>(track);
  if (t && out && env->GetArrayLength(out) >= 4) {
    try {
      const djf::KeyResult r = djf::analyzeKey(**t);
      v[0] = r.valid ? 1 : 0;
      v[1] = r.tonic;
      v[2] = r.minor ? 1 : 0;
      v[3] = static_cast<jint>(r.confidence * 1000.f);
    } catch (...) {
    }
  }
  if (out && env->GetArrayLength(out) >= 4) env->SetIntArrayRegion(out, 0, 4, v);
}

// Escolhe e carrega os trechos da faixa do deck nos pads slotBase..slotBase+3 (os que sobrarem ficam vazios).
// info: 4 grupos de [tipo, tamanho em quadros, 1 se repete em loop]; devolve quantos pads foram preenchidos.
JNI(jint, nativeBuildSamples)(JNIEnv* env, jclass, jint deck, jdouble bpm, jlong firstBeat, jint slotBase,
                              jlongArray info) {
  const std::shared_ptr<const djf::Track> src = engine().trackOf(deck);
  const std::shared_ptr<const djf::Track>* t = src ? &src : nullptr;
  if (!t || slotBase < 0 || slotBase + 4 > djf::Engine::kSamples || !info || env->GetArrayLength(info) < 12) return 0;
  jlong v[12] = {0};
  int n = 0;
  try {
    const auto specs = djf::pickSamples(**t, bpm, firstBeat);
    for (const auto& s : specs) {
      if (n >= 4) break;
      std::shared_ptr<const djf::Track> smp = djf::makeSample(**t, s);
      if (!engine().loadSample(slotBase + n, smp)) continue;
      v[3 * n] = s.kind;
      v[3 * n + 1] = smp->frames;
      v[3 * n + 2] = s.loop ? 1 : 0;
      ++n;
    }
  } catch (...) {
  }
  for (int k = n; k < 4; ++k) engine().clearSample(slotBase + k);
  env->SetLongArrayRegion(info, 0, 12, v);
  return n;
}
JNI(void, nativeClearSamples)(JNIEnv*, jclass) {
  for (int k = 0; k < djf::Engine::kSamples; ++k) engine().clearSample(k);
}
JNI(void, nativeTriggerSample)(JNIEnv*, jclass, jint slot, jboolean loop) { engine().triggerSample(slot, loop == JNI_TRUE); }
JNI(void, nativeStopSample)(JNIEnv*, jclass, jint slot) { engine().stopSample(slot); }
JNI(void, nativeSetSamplerVolume)(JNIEnv*, jclass, jfloat v) { engine().setSamplerVolume(v); }
JNI(jint, nativeSamplerMask)(JNIEnv*, jclass) { return static_cast<jint>(engine().samplerPlayingMask()); }
JNI(void, nativePlaySynced)(JNIEnv*, jclass, jint deck, jint refDeck, jdouble refFirstBeat, jdouble refBeatFrames,
                            jdouble firstBeat, jdouble beatFrames, jdouble startBeat) {
  engine().playSynced(deck, refDeck, refFirstBeat, refBeatFrames, firstBeat, beatFrames, startBeat);
}


// Energia da faixa de 0 a 1 (-1 se não deu para medir).
JNI(jfloat, nativeAnalyzeEnergy)(JNIEnv*, jclass, jlong track) {
  auto* t = reinterpret_cast<TrackPtr*>(track);
  if (!t) return -1.f;
  try { return djf::analyzeEnergy(**t); } catch (...) { return -1.f; }
}

JNI(void, nativeTriggerSampleAt)(JNIEnv*, jclass, jint slot, jboolean loop, jlong delayFrames) {
  engine().triggerSample(slot, loop == JNI_TRUE, delayFrames);
}
JNI(void, nativeSetSampleSpeed)(JNIEnv*, jclass, jint slot, jfloat speed) { engine().setSampleSpeed(slot, speed); }

// ------------------------------------------------------------------ stems (voz, bateria, baixo, resto)
namespace {
std::atomic<bool> gStemCancel[2];
std::atomic<float> gStemProgress[2];
}
// Separa os stems da faixa (bloqueia: chamar fora da thread principal). O deck só serve para o progresso
// e o cancelamento. Devolve true se terminou.
JNI(jboolean, nativeSeparateStems)(JNIEnv*, jclass, jlong track, jint deck) {
  auto* t = reinterpret_cast<TrackPtr*>(track);
  if (!t || deck < 0 || deck > 1) return JNI_FALSE;
  if ((*t)->stemsReady.load(std::memory_order_acquire)) { gStemProgress[deck].store(1.f); return JNI_TRUE; }
  gStemCancel[deck].store(false);
  gStemProgress[deck].store(0.f);
  try {
    const bool ok = djf::separateStems(**t, [deck](float p) { gStemProgress[deck].store(p, std::memory_order_relaxed); },
                                       &gStemCancel[deck]);
    return ok ? JNI_TRUE : JNI_FALSE;
  } catch (...) {
    return JNI_FALSE;
  }
}
JNI(void, nativeCancelStems)(JNIEnv*, jclass, jint deck) { if (deck >= 0 && deck <= 1) gStemCancel[deck].store(true); }
JNI(jfloat, nativeStemProgress)(JNIEnv*, jclass, jint deck) {
  return (deck >= 0 && deck <= 1) ? gStemProgress[deck].load(std::memory_order_relaxed) : 0.f;
}
JNI(void, nativeSetStemGain)(JNIEnv*, jclass, jint deck, jint stem, jfloat gain) { engine().setStemGain(deck, stem, gain); }
JNI(void, nativeSetTrim)(JNIEnv*, jclass, jint deck, jfloat gain) { engine().setTrim(deck, gain); }
// Volume médio da faixa em dBFS (0 = não medido).
JNI(jfloat, nativeAnalyzeLoudness)(JNIEnv*, jclass, jlong track) {
  auto* t = reinterpret_cast<TrackPtr*>(track);
  if (!t) return 0.f;
  try { return djf::analyzeLoudness(**t); } catch (...) { return 0.f; }
}
JNI(void, nativeSetKeyShift)(JNIEnv*, jclass, jint deck, jfloat semitones) { engine().setKeyShift(deck, semitones); }

// ------------------------------------------------------------------ gravação do set (WAV 16 bits)
namespace {
std::mutex gRecMutex;
std::thread gRecThread;
std::atomic<bool> gRecRun{false};
std::atomic<int64_t> gRecFrames{0};
FILE* gRecFile = nullptr;

void put32(unsigned char* p, uint32_t v) { p[0] = v & 0xFF; p[1] = (v >> 8) & 0xFF; p[2] = (v >> 16) & 0xFF; p[3] = (v >> 24) & 0xFF; }
void put16(unsigned char* p, uint16_t v) { p[0] = v & 0xFF; p[1] = (v >> 8) & 0xFF; }

void writeHeader(FILE* f, int sr, uint32_t dataBytes) {
  unsigned char h[44];
  std::memcpy(h, "RIFF", 4); put32(h + 4, 36 + dataBytes); std::memcpy(h + 8, "WAVEfmt ", 8);
  put32(h + 16, 16); put16(h + 20, 1); put16(h + 22, 2); put32(h + 24, static_cast<uint32_t>(sr));
  put32(h + 28, static_cast<uint32_t>(sr) * 4); put16(h + 32, 4); put16(h + 34, 16);
  std::memcpy(h + 36, "data", 4); put32(h + 40, dataBytes);
  std::fseek(f, 0, SEEK_SET);
  std::fwrite(h, 1, 44, f);
}

void recLoop() {
  std::vector<float> buf(16384);
  std::vector<int16_t> pcm(16384);
  for (;;) {
    const bool running = gRecRun.load(std::memory_order_acquire);
    const size_t n = engine().readRecorded(buf.data(), buf.size());
    if (n > 0) {
      for (size_t k = 0; k < n; ++k) {
        const float v = std::max(-1.f, std::min(1.f, buf[k]));
        pcm[k] = static_cast<int16_t>(v * 32767.f);
      }
      std::fwrite(pcm.data(), sizeof(int16_t), n, gRecFile);
      gRecFrames.fetch_add(static_cast<int64_t>(n / 2), std::memory_order_relaxed);
    } else if (!running) {
      break;
    } else {
      std::this_thread::sleep_for(std::chrono::milliseconds(15));
    }
  }
}
}  // namespace

JNI(jboolean, nativeRecordStart)(JNIEnv* env, jclass, jstring path) {
  std::lock_guard<std::mutex> lock(gRecMutex);
  if (gRecFile || !path) return JNI_FALSE;
  const char* p = env->GetStringUTFChars(path, nullptr);
  if (!p) return JNI_FALSE;
  gRecFile = std::fopen(p, "wb");
  env->ReleaseStringUTFChars(path, p);
  if (!gRecFile) return JNI_FALSE;
  writeHeader(gRecFile, engine().sampleRate(), 0);
  gRecFrames.store(0);
  engine().setRecording(true);
  gRecRun.store(true, std::memory_order_release);
  gRecThread = std::thread(recLoop);
  return JNI_TRUE;
}

// Para a gravação, fecha o WAV e devolve quantos quadros foram gravados (-1 se não estava gravando).
JNI(jlong, nativeRecordStop)(JNIEnv*, jclass) {
  std::lock_guard<std::mutex> lock(gRecMutex);
  if (!gRecFile) return -1;
  engine().setRecording(false);
  gRecRun.store(false, std::memory_order_release);
  if (gRecThread.joinable()) gRecThread.join();
  const int64_t frames = gRecFrames.load();
  const uint64_t bytes = static_cast<uint64_t>(frames) * 4;
  writeHeader(gRecFile, engine().sampleRate(), bytes > 0xFFFFFFF0ull ? 0xFFFFFFF0u : static_cast<uint32_t>(bytes));
  std::fclose(gRecFile);
  gRecFile = nullptr;
  return frames;
}

JNI(jlong, nativeRecordFrames)(JNIEnv*, jclass) { return gRecFrames.load(std::memory_order_relaxed); }

// out: [bit0 carregada | bit1 tocando, posição, cue, tamanho], tudo em quadros
JNI(void, nativeDeckState)(JNIEnv* env, jclass, jint deck, jlongArray out) {
  const djf::Engine::DeckInfo info = engine().deckInfo(deck);
  jlong v[4] = {(info.loaded ? 1 : 0) | (info.playing ? 2 : 0), info.positionFrames, info.cueFrames,
                info.lengthFrames};
  env->SetLongArrayRegion(out, 0, 4, v);
}
JNI(jfloat, nativeDeckPeak)(JNIEnv*, jclass, jint deck) { return engine().deckInfo(deck).peak; }
JNI(jfloat, nativeMasterPeak)(JNIEnv*, jclass) { return engine().masterPeak(); }
JNI(void, nativeCollectGarbage)(JNIEnv*, jclass) { engine().collectGarbage(); }

}  // extern "C"
