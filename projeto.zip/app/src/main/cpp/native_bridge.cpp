// Ponte JNI entre o Kotlin (app.djfusion.audio.NativeEngine) e o motor C++.
#include <jni.h>

#include <cstring>
#include <memory>
#include <vector>

#include "audio_host.h"
#include "core/bpm.h"
#include "core/key.h"
#include "core/samples.h"
#include "core/track.h"

namespace {

std::shared_ptr<djf::AudioHost>& hostPtr() {
  static std::shared_ptr<djf::AudioHost> host = std::make_shared<djf::AudioHost>();
  return host;
}
djf::Engine& engine() { return hostPtr()->engine(); }

using TrackPtr = std::shared_ptr<const djf::Track>;

}  // namespace

extern "C" {

#define JNI(ret, name) JNIEXPORT ret JNICALL Java_app_djfusion_audio_NativeEngine_##name

// ---------------------------------------------------------------- saída de áudio
JNI(jboolean, nativeStart)(JNIEnv*, jclass) { return hostPtr()->start() ? JNI_TRUE : JNI_FALSE; }

JNI(void, nativeConfigureOutput)(JNIEnv*, jclass, jint mode, jint deviceId) {
  hostPtr()->configureOutput(mode, deviceId);
}

JNI(void, nativeStop)(JNIEnv*, jclass) { hostPtr()->stop(); }

JNI(void, nativeStreamInfo)(JNIEnv* env, jclass, jintArray out) {
  int32_t v[6];
  hostPtr()->info(v);
  if (!out || env->GetArrayLength(out) < 6) return;
  env->SetIntArrayRegion(out, 0, 6, reinterpret_cast<const jint*>(v));
}

// ------------------------------------------------------ construção de faixas
JNI(jlong, nativeBeginTrack)(JNIEnv*, jclass, jint srcRate, jlong maxFrames) {
  if (srcRate < 8000 || srcRate > 384000) return 0;
  return reinterpret_cast<jlong>(new djf::TrackBuilder(srcRate, djf::kEngineRate, maxFrames));
}

JNI(void, nativeAppend)(JNIEnv* env, jclass, jlong handle, jobject buffer, jint offset, jint size,
                        jint channels, jboolean isFloat) {
  auto* b = reinterpret_cast<djf::TrackBuilder*>(handle);
  if (!b || channels < 1 || size <= 0) return;
  auto* base = static_cast<const uint8_t*>(env->GetDirectBufferAddress(buffer));
  if (!base || offset < 0) return;
  const jlong cap = env->GetDirectBufferCapacity(buffer);
  if (cap < 0 || static_cast<jlong>(offset) + size > cap) return;  // nunca ler além do buffer
  const uint8_t* p = base + offset;
  try {
  if (isFloat) {
    const size_t frames = static_cast<size_t>(size) / (sizeof(float) * channels);
    static thread_local std::vector<float> tmp;
    tmp.resize(frames * channels);
    std::memcpy(tmp.data(), p, tmp.size() * sizeof(float));  // cópia evita leitura desalinhada
    b->appendFloat(tmp.data(), frames, channels);
  } else {
    const size_t frames = static_cast<size_t>(size) / (sizeof(int16_t) * channels);
    static thread_local std::vector<int16_t> tmp;
    tmp.resize(frames * channels);
    std::memcpy(tmp.data(), p, tmp.size() * sizeof(int16_t));
    b->appendPcm16(tmp.data(), frames, channels);
  }
  } catch (...) {
    b->markFailed();  // sem memória: nunca deixar uma exceção C++ atravessar o JNI
  }
}

JNI(jboolean, nativeBuilderTooLong)(JNIEnv*, jclass, jlong handle) {
  auto* b = reinterpret_cast<djf::TrackBuilder*>(handle);
  return (b && b->tooLong()) ? JNI_TRUE : JNI_FALSE;
}

// 0 = faixa vazia, -1 = passou do limite, senão um identificador da faixa pronta.
JNI(jlong, nativeFinishTrack)(JNIEnv*, jclass, jlong handle) {
  std::unique_ptr<djf::TrackBuilder> b(reinterpret_cast<djf::TrackBuilder*>(handle));
  if (!b) return 0;
  try {
    std::shared_ptr<djf::Track> t = b->finish();
    if (b->tooLong()) return -1;
    if (t->frames <= 0) return 0;
    return reinterpret_cast<jlong>(new TrackPtr(std::move(t)));
  } catch (...) {
    return -1;
  }
}

JNI(void, nativeAbortTrack)(JNIEnv*, jclass, jlong handle) {
  delete reinterpret_cast<djf::TrackBuilder*>(handle);
}

JNI(jlong, nativeTrackFrames)(JNIEnv*, jclass, jlong track) {
  auto* t = reinterpret_cast<TrackPtr*>(track);
  return t ? (*t)->frames : 0;
}

JNI(jbyteArray, nativeTrackPeaks)(JNIEnv* env, jclass, jlong track) {
  auto* t = reinterpret_cast<TrackPtr*>(track);
  const size_t n = t ? (*t)->peaks.size() : 0;
  jbyteArray arr = env->NewByteArray(static_cast<jsize>(n));
  if (arr && n > 0) {
    env->SetByteArrayRegion(arr, 0, static_cast<jsize>(n), reinterpret_cast<const jbyte*>((*t)->peaks.data()));
  }
  return arr;
}

// Solta a referência do lado Kotlin. O motor mantém a sua própria, se a faixa estiver carregada.
JNI(void, nativeFreeTrack)(JNIEnv*, jclass, jlong track) { delete reinterpret_cast<TrackPtr*>(track); }

// -------------------------------------------------------------- controle dos decks
JNI(jboolean, nativeLoad)(JNIEnv*, jclass, jint deck, jlong track) {
  auto* t = reinterpret_cast<TrackPtr*>(track);
  return (t && engine().loadTrack(deck, *t)) ? JNI_TRUE : JNI_FALSE;
}
JNI(void, nativeUnload)(JNIEnv*, jclass, jint deck) { engine().unload(deck); }
JNI(void, nativePlay)(JNIEnv*, jclass, jint deck) { engine().play(deck); }
JNI(void, nativePause)(JNIEnv*, jclass, jint deck) { engine().pause(deck); }
JNI(void, nativeCue)(JNIEnv*, jclass, jint deck) { engine().cue(deck); }
JNI(void, nativeSeek)(JNIEnv*, jclass, jint deck, jlong frame) { engine().seekFrames(deck, frame); }
JNI(void, nativeSetVolume)(JNIEnv*, jclass, jint deck, jfloat v) { engine().setVolume(deck, v); }
JNI(void, nativeSetCrossfader)(JNIEnv*, jclass, jfloat x) { engine().setCrossfader(x); }
JNI(void, nativeSetMaster)(JNIEnv*, jclass, jfloat v) { engine().setMaster(v); }
JNI(void, nativeSetRate)(JNIEnv*, jclass, jint deck, jfloat rate) { engine().setRate(deck, rate); }
JNI(void, nativeSetEq)(JNIEnv*, jclass, jint deck, jint band, jfloat v) { engine().setEq(deck, band, v); }
JNI(void, nativeSetFx)(JNIEnv*, jclass, jint deck, jint type, jfloat amount, jfloat beatSeconds) {
  engine().setFx(deck, type, amount, beatSeconds);
}
JNI(void, nativeSetKeyLock)(JNIEnv*, jclass, jint deck, jboolean on) { engine().setKeyLock(deck, on == JNI_TRUE); }
JNI(void, nativeScratch)(JNIEnv*, jclass, jint deck, jboolean active, jfloat velocity) {
  engine().scratch(deck, active == JNI_TRUE, velocity);
}
JNI(void, nativeSetHeadphoneCue)(JNIEnv*, jclass, jint deck, jboolean on) { engine().setHeadphoneCue(deck, on == JNI_TRUE); }
JNI(void, nativeSetHeadphoneLevel)(JNIEnv*, jclass, jfloat v) { engine().setHeadphoneLevel(v); }
JNI(void, nativeSetHeadphoneMix)(JNIEnv*, jclass, jfloat v) { engine().setHeadphoneMix(v); }
JNI(void, nativeSetFilter)(JNIEnv*, jclass, jint deck, jfloat v) { engine().setFilter(deck, v); }
JNI(void, nativeSetLoop)(JNIEnv*, jclass, jint deck, jlong start, jlong end) { engine().setLoop(deck, start, end); }
JNI(void, nativeClearLoop)(JNIEnv*, jclass, jint deck) { engine().clearLoop(deck); }

// Detecta o andamento da faixa (fora do tempo real, pode levar algumas centenas de ms).
// out: [bpm (0 = não detectado), primeira batida em quadros, confiança de 0 a 1]
JNI(void, nativeAnalyze)(JNIEnv* env, jclass, jlong track, jdoubleArray out) {
  double v[3] = {0, 0, 0};
  auto* t = reinterpret_cast<TrackPtr*>(track);
  if (t) {
    try {
      const djf::BpmResult r = djf::analyzeBpm(**t);
      v[0] = r.bpm;
      v[1] = static_cast<double>(r.firstBeatFrame);
      v[2] = r.confidence;
    } catch (...) {
    }
  }
  env->SetDoubleArrayRegion(out, 0, 3, v);
}

// Tonalidade da faixa. out: [válida (0/1), nota 0..11 (0 = Dó), 1 se menor, confiança x 1000]
JNI(void, nativeAnalyzeKey)(JNIEnv* env, jclass, jlong track, jintArray out) {
  jint v[4] = {0, 0, 0, 0};
  auto* t = reinterpret_cast<TrackPtr*>(track);
  if (t && out && env->GetArrayLength(out) >= 4) {
    try {
      const djf::KeyResult r = djf::analyzeKey(**t);
      v[0] = r.valid ? 1 : 0;
      v[1] = r.tonic;
      v[2] = r.minor ? 1 : 0;
      v[3] = static_cast<jint>(r.confidence * 1000.f);
    } catch (...) {
    }
  }
  if (out && env->GetArrayLength(out) >= 4) env->SetIntArrayRegion(out, 0, 4, v);
}

// Escolhe e carrega os trechos da faixa do deck nos pads slotBase..slotBase+3 (os que sobrarem ficam vazios).
// info: 4 grupos de [tipo, tamanho em quadros, 1 se repete em loop]; devolve quantos pads foram preenchidos.
JNI(jint, nativeBuildSamples)(JNIEnv* env, jclass, jint deck, jdouble bpm, jlong firstBeat, jint slotBase,
                              jlongArray info) {
  const std::shared_ptr<const djf::Track> src = engine().trackOf(deck);
  const std::shared_ptr<const djf::Track>* t = src ? &src : nullptr;
  if (!t || slotBase < 0 || slotBase + 4 > djf::Engine::kSamples || !info || env->GetArrayLength(info) < 12) return 0;
  jlong v[12] = {0};
  int n = 0;
  try {
    const auto specs = djf::pickSamples(**t, bpm, firstBeat);
    for (const auto& s : specs) {
      if (n >= 4) break;
      std::shared_ptr<const djf::Track> smp = djf::makeSample(**t, s);
      if (!engine().loadSample(slotBase + n, smp)) continue;
      v[3 * n] = s.kind;
      v[3 * n + 1] = smp->frames;
      v[3 * n + 2] = s.loop ? 1 : 0;
      ++n;
    }
  } catch (...) {
  }
  for (int k = n; k < 4; ++k) engine().clearSample(slotBase + k);
  env->SetLongArrayRegion(info, 0, 12, v);
  return n;
}
JNI(void, nativeClearSamples)(JNIEnv*, jclass) {
  for (int k = 0; k < djf::Engine::kSamples; ++k) engine().clearSample(k);
}
JNI(void, nativeTriggerSample)(JNIEnv*, jclass, jint slot, jboolean loop) { engine().triggerSample(slot, loop == JNI_TRUE); }
JNI(void, nativeStopSample)(JNIEnv*, jclass, jint slot) { engine().stopSample(slot); }
JNI(void, nativeSetSamplerVolume)(JNIEnv*, jclass, jfloat v) { engine().setSamplerVolume(v); }
JNI(jint, nativeSamplerMask)(JNIEnv*, jclass) { return static_cast<jint>(engine().samplerPlayingMask()); }
JNI(void, nativePlaySynced)(JNIEnv*, jclass, jint deck, jint refDeck, jdouble refFirstBeat, jdouble refBeatFrames,
                            jdouble firstBeat, jdouble beatFrames, jdouble startBeat) {
  engine().playSynced(deck, refDeck, refFirstBeat, refBeatFrames, firstBeat, beatFrames, startBeat);
}

// out: [bit0 carregada | bit1 tocando, posição, cue, tamanho], tudo em quadros
JNI(void, nativeDeckState)(JNIEnv* env, jclass, jint deck, jlongArray out) {
  const djf::Engine::DeckInfo info = engine().deckInfo(deck);
  jlong v[4] = {(info.loaded ? 1 : 0) | (info.playing ? 2 : 0), info.positionFrames, info.cueFrames,
                info.lengthFrames};
  env->SetLongArrayRegion(out, 0, 4, v);
}
JNI(jfloat, nativeDeckPeak)(JNIEnv*, jclass, jint deck) { return engine().deckInfo(deck).peak; }
JNI(jfloat, nativeMasterPeak)(JNIEnv*, jclass) { return engine().masterPeak(); }
JNI(void, nativeCollectGarbage)(JNIEnv*, jclass) { engine().collectGarbage(); }

}  // extern "C"
