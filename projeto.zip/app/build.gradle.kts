plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
    id("org.jetbrains.kotlin.plugin.compose")
}

android {
    namespace = "app.djfusion"
    compileSdk = 35

    defaultConfig {
        applicationId = "app.djfusion.pro"   // provisório, muda no /replica-brand
        minSdk = 27                           // AAudio disponível
        targetSdk = 35
        versionCode = 16
        versionName = "1.6.0"
        testInstrumentationRunner = "androidx.test.runner.AndroidJUnitRunner"

        ndk {
            // arm64: POCO X7 Pro e quase todo celular atual; x86_64: emulador do teste automático
            abiFilters += listOf("arm64-v8a", "x86_64")
        }
        externalNativeBuild {
            cmake {
                cppFlags += "-std=c++17"
                arguments += listOf("-DANDROID_STL=c++_shared")
            }
        }
    }

    externalNativeBuild {
        cmake {
            path = file("src/main/cpp/CMakeLists.txt")
            version = "3.22.1"
        }
    }

    buildFeatures {
        compose = true
        prefab = true   // Oboe vem do Maven como pacote Prefab
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions {
        jvmTarget = "17"
    }

    // Assinatura fixa do app: todo APK sai com a mesma chave, então a versão nova instala por cima da antiga
    // (sem desinstalar e sem perder a biblioteca). Uso pessoal; para a Play Store usar uma chave guardada fora do repositório.
    signingConfigs {
        create("edgard") {
            storeFile = file("assinatura-edgard.p12")
            storeType = "pkcs12"
            storePassword = "egdjstudio"
            keyAlias = "edgard"
            keyPassword = "egdjstudio"
        }
    }

    buildTypes {
        debug {
            signingConfig = signingConfigs.getByName("edgard")
        }
        release {
            isMinifyEnabled = false
            signingConfig = signingConfigs.getByName("edgard")
        }
    }
}

dependencies {
    implementation("androidx.core:core-ktx:1.13.1")
    implementation("androidx.activity:activity-compose:1.9.3")
    implementation("androidx.lifecycle:lifecycle-viewmodel-compose:2.8.7")
    implementation("androidx.lifecycle:lifecycle-runtime-compose:2.8.7")

    implementation(platform("androidx.compose:compose-bom:2024.10.01"))
    implementation("androidx.compose.ui:ui")
    implementation("androidx.compose.ui:ui-graphics")
    implementation("androidx.compose.foundation:foundation")
    implementation("androidx.compose.material3:material3")

    implementation("com.google.oboe:oboe:1.9.0")

    // teste de ponta a ponta no emulador (toques reais, seletor de arquivos do Android)
    androidTestImplementation("androidx.test.ext:junit:1.2.1")
    androidTestImplementation("androidx.test:runner:1.6.2")
    androidTestImplementation("androidx.test:rules:1.6.1")
    androidTestImplementation("androidx.test.uiautomator:uiautomator:2.3.0")
    androidTestImplementation(platform("androidx.compose:compose-bom:2024.10.01"))
    androidTestImplementation("androidx.compose.ui:ui-test-junit4")
    debugImplementation("androidx.compose.ui:ui-test-manifest")
}
