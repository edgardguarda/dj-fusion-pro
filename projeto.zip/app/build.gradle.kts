plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
    id("org.jetbrains.kotlin.plugin.compose")
}

android {
    namespace = "app.djfusion"
    compileSdk = 36

    defaultConfig {
        applicationId = "app.djfusion.pro"   // provisório, muda no /replica-brand
        minSdk = 27                           // AAudio disponível
        targetSdk = 36                        // exigido pela Play Store desde 31/08/2026 (Android 16)
        versionCode = 74
        versionName = "3.7.30"
        testInstrumentationRunner = "androidx.test.runner.AndroidJUnitRunner"

        ndk {
            // arm64: POCO X7 Pro e quase todo celular atual; x86_64: emulador do teste automático
            abiFilters += listOf("arm64-v8a", "x86_64")
        }
        externalNativeBuild {
            cmake {
                cppFlags += "-std=c++17"
                arguments += listOf("-DANDROID_STL=c++_shared")
            }
        }
    }

    externalNativeBuild {
        cmake {
            path = file("src/main/cpp/CMakeLists.txt")
            version = "3.22.1"
        }
    }

    buildFeatures {
        compose = true
        prefab = true   // Oboe vem do Maven como pacote Prefab
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions {
        jvmTarget = "17"
    }

    // o APK final não pode parar por avisos do lint (o teste no emulador é quem aprova)
    lint {
        checkReleaseBuilds = false
        abortOnError = false
    }

    // Assinatura fixa do app: todo APK sai com a mesma chave, então a versão nova instala por cima da antiga
    // (sem desinstalar e sem perder a biblioteca). Uso pessoal; para a Play Store usar uma chave guardada fora do repositório.
    signingConfigs {
        create("edgard") {
            storeFile = file("assinatura-edgard.p12")
            storeType = "pkcs12"
            storePassword = "egdjstudio"
            keyAlias = "edgard"
            keyPassword = "egdjstudio"
        }
    }

    // Play Store: chave de ENVIO guardada fora do repositório (segredos do GitHub ou variáveis no computador).
    // Sem ela (testes), o APK sai com a chave do projeto.
    val uploadStore = System.getenv("DJ_UPLOAD_STORE")
    if (uploadStore != null && file(uploadStore).exists()) {
        signingConfigs.create("upload") {
            storeFile = file(uploadStore)
            storeType = "pkcs12"
            storePassword = System.getenv("DJ_UPLOAD_PASS")
            keyAlias = System.getenv("DJ_UPLOAD_ALIAS") ?: "upload"
            keyPassword = System.getenv("DJ_UPLOAD_PASS")
        }
    }

    buildTypes {
        debug {
            signingConfig = signingConfigs.getByName("edgard")
        }
        release {
            // proteção: código embaralhado e encolhido (R8) — dificulta copiar e modificar o app
            isMinifyEnabled = true
            isShrinkResources = true
            proguardFiles(getDefaultProguardFile("proguard-android-optimize.txt"), "proguard-rules.pro")
            signingConfig = signingConfigs.findByName("upload") ?: signingConfigs.getByName("edgard")
        }
    }
}

// o pacote para a Play Store (.aab) sai junto com o APK final
tasks.matching { it.name == "assembleRelease" }.configureEach {
    dependsOn("bundleRelease")
    finalizedBy("liberarEspaco")
}
// Depois do APK final: apaga os arquivos intermediários da compilação (vários GB) e deixa só os APKs/.aab prontos.
// No servidor de teste, o disco cheio impedia o emulador de ser instalado.
tasks.register<Delete>("liberarEspaco") {
    delete(layout.buildDirectory.dir("intermediates"), layout.buildDirectory.dir("tmp"),
        layout.buildDirectory.dir("kotlin"), layout.buildDirectory.dir("generated"), file(".cxx"))
}

dependencies {
    implementation("androidx.core:core-ktx:1.13.1")
    implementation("androidx.activity:activity-compose:1.9.3")
    implementation("androidx.lifecycle:lifecycle-viewmodel-compose:2.8.7")
    implementation("androidx.lifecycle:lifecycle-runtime-compose:2.8.7")

    implementation(platform("androidx.compose:compose-bom:2024.10.01"))
    implementation("androidx.compose.ui:ui")
    implementation("androidx.compose.ui:ui-graphics")
    implementation("androidx.compose.foundation:foundation")
    implementation("androidx.compose.material3:material3")

    implementation("com.microsoft.onnxruntime:onnxruntime-android:1.22.0")   // rede neural dos stems (Spleeter)
    implementation("com.google.oboe:oboe:1.9.3")   // 1.9.3: páginas de 16 KB (exigido pela Play Store)

    // atualização dentro do app quando instalado pela Play Store
    implementation("com.google.android.play:app-update-ktx:2.1.0")

    // teste de ponta a ponta no emulador (toques reais, seletor de arquivos do Android)
    androidTestImplementation("androidx.test.ext:junit:1.2.1")
    androidTestImplementation("androidx.test:runner:1.6.2")
    androidTestImplementation("androidx.test:rules:1.6.1")
    androidTestImplementation("androidx.test.uiautomator:uiautomator:2.3.0")
    androidTestImplementation(platform("androidx.compose:compose-bom:2024.10.01"))
    androidTestImplementation("androidx.compose.ui:ui-test-junit4")
    debugImplementation("androidx.compose.ui:ui-test-manifest")
}
