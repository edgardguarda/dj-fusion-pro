# Edgard Guarda DJ Studio — regras do R8 (APK final embaralhado)

# Motor de áudio em C++: as funções nativas são achadas pelo nome (Java_app_djfusion_audio_NativeEngine_...)
-keep class app.djfusion.audio.NativeEngine { *; }
-keepclasseswithmembernames,includedescriptorclasses class * { native <methods>; }

# Mensagens de erro do relatório ficam legíveis (nome do arquivo e linha)
-keepattributes SourceFile,LineNumberTable
-renamesourcefileattribute SourceFile

# ONNX Runtime (rede neural dos stems): usa JNI e reflexão
-keep class ai.onnxruntime.** { *; }
-dontwarn ai.onnxruntime.**
-keep class app.djfusion.audio.SpleeterCore { *; }
