# Política de privacidade — Edgard Guarda DJ Studio

Última atualização: 16 de novembro de 2026.

**Resumo: o app não coleta, não envia e não vende nenhum dado seu.**

- **Músicas**: o app só abre as músicas e pastas que você escolhe no seletor de arquivos do Android. Elas não saem do seu celular.
- **Biblioteca, cues, playlists, mapas da controladora e ajustes**: ficam guardados só no seu celular. Os backups automáticos ficam na pasta Documentos do próprio aparelho.
- **Gravações do set**: são salvas no seu celular, na pasta que o app mostra.
- **Relatório de diagnóstico**: só é criado quando você toca em RELATÓRIO. Ele é salvo no seu celular e copiado para a área de transferência; só sai do aparelho se você mesmo enviar.
- **Internet**: o app não usa internet para nada próprio. A única comunicação é a da própria Play Store para verificar atualizações do app.
- **Permissões**: o app não pede acesso a câmera, microfone, localização, contatos ou arquivos em geral.
- **Crianças**: o app não é direcionado a crianças e não coleta dados de ninguém.

Contato: (coloque aqui o seu e-mail de desenvolvedor da Play Console).
