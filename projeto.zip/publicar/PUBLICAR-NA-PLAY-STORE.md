# Publicar e vender o Edgard Guarda DJ Studio na Play Store

## O que o app já tem pronto (versão 3.0.0)
- **Android 16 (API 36)** como alvo — exigido pela Play Store para apps novos e atualizações desde 31/08/2026.
- **Páginas de 16 KB** no motor de áudio (C++ e Oboe 1.9.3) — exigido pela Play Store.
- **Pacote .aab** (formato que a Play Store aceita) gerado junto com o APK a cada compilação.
- **Atualização dentro do app**: instalado pela Play Store, o app procura versão nova ao abrir, baixa enquanto o DJ toca e só instala quando ele mandar (AJUSTES › SOBRE › ATUALIZAÇÕES). Quem comprou recebe todas as versões novas sem pagar de novo — a Play Store cuida disso.
- **Proteção**: código embaralhado (R8), conferência da assinatura (cópia modificada aparece em VERIFICAR e no relatório), nenhuma permissão perigosa, sem internet própria.

## Passo a passo (só você pode fazer: exige seus documentos e conta bancária)
1. **Conta de desenvolvedor**: play.google.com/console → criar conta (taxa única de US$ 25), com verificação de identidade.
2. **Perfil de pagamentos (comerciante)**: em Configurações › Perfil de pagamentos, com seus dados bancários. Sem isso não dá para vender.
3. **Criar o app**: nome "Edgard Guarda DJ Studio", app (não jogo), **pago**. Atenção: um app publicado como gratuito não pode virar pago depois.
4. **Chave de envio (importante)**:
   - Gere uma chave NOVA só sua (não use a do repositório, que é pública): Android Studio › Build › Generate Signed Bundle › Create new.
   - Guarde o arquivo e a senha em 2 lugares seguros. Perdeu = pede redefinição à Google.
   - Para o GitHub compilar com ela: Settings › Secrets › Actions: `DJ_UPLOAD_STORE_B64` (arquivo em base64), `DJ_UPLOAD_PASS`, `DJ_UPLOAD_ALIAS`. (O projeto já lê `DJ_UPLOAD_STORE`, `DJ_UPLOAD_PASS` e `DJ_UPLOAD_ALIAS`.)
   - Ative a **Assinatura de apps do Google Play** (padrão). Depois, copie o "SHA-256 do certificado da chave de assinatura do app" (Integridade do app) e coloque em `OFFICIAL_CERTS` no AppViewModel.kt.
5. **Teste fechado obrigatório** (contas pessoais novas): pelo menos **12 testadores** com o app instalado por **14 dias seguidos** antes de pedir produção.
6. **Ficha da loja**: ícone 512×512, imagem de destaque 1024×500, pelo menos 2 capturas de tela (o teste automático já tira várias), descrição curta e completa.
7. **Política de privacidade**: publique o texto de `POLITICA-DE-PRIVACIDADE.md` numa página (Google Sites é grátis) e cole o link.
8. **Segurança dos dados**: o app **não coleta nem compartilha dados** (tudo fica no celular). Classificação de conteúdo: questionário IARC (app de música, sem conteúdo sensível).
9. **Preço e países**: defina o preço (ex.: R$ 29,90) e os países.
10. **Enviar o .aab**: Produção (ou teste fechado) › Criar versão › enviar `app-release.aab`. A cada versão nova, o `versionCode` sobe (o projeto já faz isso).

## Atualizar depois
Cada versão nova: enviar o novo `.aab` na Play Console. Os compradores recebem pela Play Store (e o app avisa e instala quando o DJ mandar).

## Proteção do código (urgente)
O repositório no GitHub está **público**: qualquer um pode copiar o código e a chave antiga. Antes de vender:
- GitHub › Settings › General › Danger Zone › **Change visibility → Private**.
- Use a chave de envio nova (passo 4); a do repositório fica só para testes.
