# AURA 9 Android — Verificações realizadas

Data: 22/11/2026

## Comprovado

- Aplicativo Android compilado pelo Gradle 8.9 e SDK 35 no GitHub Actions (execução 45070628938).
- Assinatura de depuração verificada pelo `apksigner`.
- Identificador Android verificado: `br.com.edgard.aura.completo9`.
- A interface AURA 6.2 original foi incluída integralmente, com `assets/aura.html` de 1.946.648 bytes.
- A camada Android de controles foi incluída no APK.
- Os testes Java de geração de ganhos, bass swap, detecção de BPM, sobreposição e preservação de saída rítmica passaram; as verificações complementares de cabeça/cauda e rejeição de drift passaram localmente (2.470 verificações no total).
- No Chromium local, a interface original carregou sem erros JavaScript; 75 botões e os painéis de biblioteca, efeitos, decks e gravador original permaneceram no DOM. A nova interface Android disparou as chamadas `start('s-curve','32')`, `record(true)` e `saveMaster()` via ponte simulada.
- O ZIP do APK foi lido integralmente e contém `classes.dex`, `assets/aura.html`, `assets/native-ui.js` e assinatura.

## Não comprovado — NÃO declarar homologado

- Instalação e abertura no telefone real do usuário.
- Decodificação MediaCodec e mixagem AudioTrack reproduzindo as músicas reais do usuário.
- Qualidade subjetiva de transições com vocais, breakdowns e outras estruturas reais.
- Reconhecimento neural YAMNet/LinkSeg em WebView; pesos ONNX não estão embutidos.
- Sincronização com preservação independente de tonalidade: no motor Android, a alteração de velocidade altera o pitch.
- Recurso de stems/efeitos do AURA Web atuando no motor nativo. A interface e os recursos originais estão preservados no modo clássico Web Audio, não portados integralmente para AudioTrack.
- Teste de emulador Android: não foi conclusivo. Os workflows anteriores falharam na inicialização do emulador no ambiente remoto, antes de lançar o aplicativo.

**Conclusão:** versão experimental integrada, não garantia de mixagem perfeita.
