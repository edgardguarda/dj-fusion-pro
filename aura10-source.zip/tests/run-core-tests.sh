#!/bin/sh
set -eu
cd "$(dirname "$0")/.."
mkdir -p build-core
javac -d build-core app/src/main/java/br/com/edgard/aura/core/*.java tests/EngineTest.java
java -cp build-core EngineTest
