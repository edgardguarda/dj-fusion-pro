package br.com.edgard.aura;

import java.io.File;
import java.io.IOException;
import java.io.RandomAccessFile;

/** Streaming PCM16 WAV recorder; no accumulated master in JVM memory. */
public final class WavWriter implements AutoCloseable {
    private final RandomAccessFile out;
    private long bytes;
    public final File file;
    public WavWriter(File f,int hz) throws IOException {
        file=f;out=new RandomAccessFile(f,"rw");out.setLength(0);
        for(int i=0;i<44;i++)out.write(0);
        sampleRate=hz;
    }
    private final int sampleRate;
    public void write(byte[] data,int size) throws IOException {
        if(bytes+size>=0xFFFF0000L)throw new IOException("WAV excede limite de 4 GB");
        out.write(data,0,size);bytes+=size;
    }
    private void le32(long x)throws IOException{out.write((int)x&255);out.write((int)(x>>>8)&255);out.write((int)(x>>>16)&255);out.write((int)(x>>>24)&255);}
    private void le16(int x)throws IOException{out.write(x&255);out.write((x>>>8)&255);}
    @Override public void close() throws IOException {
        out.seek(0);
        out.writeBytes("RIFF");le32(36+bytes);out.writeBytes("WAVE");
        out.writeBytes("fmt ");le32(16);le16(1);le16(2);
        le32(sampleRate);le32(sampleRate*4L);le16(4);le16(16);
        out.writeBytes("data");le32(bytes);out.close();
    }
}
