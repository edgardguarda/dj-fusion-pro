package br.com.edgard.aura;

import android.content.Context;
import android.media.MediaCodec;
import android.media.AudioFormat;
import android.media.MediaExtractor;
import android.media.MediaFormat;
import android.net.Uri;

import java.io.BufferedOutputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.nio.ByteBuffer;
import java.nio.ByteOrder;

/** Android decoder: audio files become on-disk stereo PCM16; never a full RAM copy. */
public final class AudioDecoder {
    public static final class Result {
        public final File file; public final int sampleRate; public final long frames;
        Result(File f,int r,long n){file=f;sampleRate=r;frames=n;}
    }
    public interface Progress { void onProgress(long frames); }
    private static short floatToPcm16(float x){
        if(Float.isNaN(x))return 0;
        return (short)Math.max(-32768,Math.min(32767,Math.round(x*32767f)));
    }
    public static Result decode(Context context,Uri uri,File destination,Progress progress) throws Exception {
        MediaExtractor extractor=new MediaExtractor();
        MediaCodec codec=null;
        boolean complete=false;
        try {
            extractor.setDataSource(context,uri,null);
            int track=-1;MediaFormat format=null;
            for(int i=0;i<extractor.getTrackCount();i++){
                MediaFormat candidate=extractor.getTrackFormat(i);
                if(candidate.containsKey(MediaFormat.KEY_MIME)&&candidate.getString(MediaFormat.KEY_MIME).startsWith("audio/")){
                    track=i;format=candidate;break;
                }
            }
            if(track<0)throw new IOException("Arquivo sem faixa de áudio compatível");
            extractor.selectTrack(track);
            String mime=format.getString(MediaFormat.KEY_MIME);
            codec=MediaCodec.createDecoderByType(mime);
            codec.configure(format,null,null,0);codec.start();
            int channels=format.containsKey(MediaFormat.KEY_CHANNEL_COUNT)?format.getInteger(MediaFormat.KEY_CHANNEL_COUNT):2;
            int rate=format.containsKey(MediaFormat.KEY_SAMPLE_RATE)?format.getInteger(MediaFormat.KEY_SAMPLE_RATE):44100;
            if(channels<1||channels>8)throw new IOException("Número de canais não suportado");
            int pcmEncoding=AudioFormat.ENCODING_PCM_16BIT;
            boolean inputDone=false,outputDone=false;
            long frames=0;byte[] stereo=new byte[32768];
            MediaCodec.BufferInfo info=new MediaCodec.BufferInfo();
            try(BufferedOutputStream out=new BufferedOutputStream(new FileOutputStream(destination),1<<18)){
                int emptyPasses=0;
                while(!outputDone) {
                    if(Thread.currentThread().isInterrupted())throw new InterruptedException("Decodificação interrompida");
                    if(!inputDone){
                        int ix=codec.dequeueInputBuffer(10000);
                        if(ix>=0){
                            ByteBuffer input=codec.getInputBuffer(ix);
                            if(input==null)throw new IOException("Buffer de entrada indisponível");
                            input.clear();int size=extractor.readSampleData(input,0);
                            if(size<0){codec.queueInputBuffer(ix,0,0,0,MediaCodec.BUFFER_FLAG_END_OF_STREAM);inputDone=true;}
                            else{codec.queueInputBuffer(ix,0,size,extractor.getSampleTime(),0);extractor.advance();}
                        }
                    }
                    int ox=codec.dequeueOutputBuffer(info,10000);
                    if(ox==MediaCodec.INFO_OUTPUT_FORMAT_CHANGED){
                        MediaFormat of=codec.getOutputFormat();
                        if(of.containsKey(MediaFormat.KEY_SAMPLE_RATE))rate=of.getInteger(MediaFormat.KEY_SAMPLE_RATE);
                        if(of.containsKey(MediaFormat.KEY_CHANNEL_COUNT))channels=of.getInteger(MediaFormat.KEY_CHANNEL_COUNT);
                        pcmEncoding=of.containsKey(MediaFormat.KEY_PCM_ENCODING)?of.getInteger(MediaFormat.KEY_PCM_ENCODING):AudioFormat.ENCODING_PCM_16BIT;
                        if(pcmEncoding!=AudioFormat.ENCODING_PCM_16BIT && pcmEncoding!=AudioFormat.ENCODING_PCM_FLOAT)
                            throw new IOException("Saída PCM incompatível (encoding="+pcmEncoding+"). Tente MP3, M4A ou FLAC comum.");
                    } else if(ox>=0){
                        ByteBuffer data=codec.getOutputBuffer(ox);
                        if(info.size>0&&data!=null){
                            data.position(info.offset);data.limit(info.offset+info.size);data.order(ByteOrder.LITTLE_ENDIAN);
                            if(channels<1||channels>8)throw new IOException("Canais não suportados");
                            int block=channels*(pcmEncoding==AudioFormat.ENCODING_PCM_FLOAT?4:2);
                            int count=info.size/block;
                            int offset=0;
                            for(int s=0;s<count;s++){
                                short left,right;
                                if(pcmEncoding==AudioFormat.ENCODING_PCM_FLOAT){
                                    left=floatToPcm16(data.getFloat());right=left;
                                    if(channels>1)right=floatToPcm16(data.getFloat());
                                    for(int c=2;c<channels;c++)data.getFloat();
                                }else{
                                    left=data.getShort();right=left;
                                    if(channels>1)right=data.getShort();
                                    for(int c=2;c<channels;c++)data.getShort();
                                }
                                stereo[offset++]=(byte)(left&255);stereo[offset++]=(byte)((left>>>8)&255);
                                stereo[offset++]=(byte)(right&255);stereo[offset++]=(byte)((right>>>8)&255);
                                if(offset>=stereo.length){out.write(stereo,0,offset);offset=0;}
                            }
                            if(offset>0)out.write(stereo,0,offset);
                            frames+=count;
                            if(progress!=null&&(frames% (rate*5L))<count)progress.onProgress(frames);
                        }
                        outputDone=(info.flags&MediaCodec.BUFFER_FLAG_END_OF_STREAM)!=0;
                        codec.releaseOutputBuffer(ox,false);
                        emptyPasses=0;
                    } else if(ox==MediaCodec.INFO_TRY_AGAIN_LATER&&inputDone){
                        if(++emptyPasses>100)throw new IOException("Timeout no decodificador");
                    }
                    if(destination.length()>1_000_000_000L)throw new IOException("Limite de cache: 1 GB por música");
                }
            }
            if(frames<rate*2L)throw new IOException("Música menor que 2 segundos");
            complete=true;return new Result(destination,rate,frames);
        } finally {
            try{if(codec!=null){codec.stop();codec.release();}}catch(Exception ignored){}
            try{extractor.release();}catch(Exception ignored){}
            if(!complete)destination.delete();
        }
    }
}
