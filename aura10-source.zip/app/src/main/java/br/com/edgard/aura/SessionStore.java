package br.com.edgard.aura;

import android.content.Context;
import br.com.edgard.aura.core.TrackData;
import org.json.JSONArray;
import org.json.JSONObject;
import java.io.File;
import java.util.ArrayList;
import java.util.List;

public final class SessionStore {
    public static void save(Context ctx,List<TrackData> tracks,int style,int beats)throws Exception{
        JSONObject root=new JSONObject();JSONArray list=new JSONArray();
        root.put("style",style).put("beats",beats);
        for(TrackData t:tracks){JSONObject v=new JSONObject();v.put("title",t.title).put("file",t.file.getAbsolutePath()).put("sampleRate",t.sampleRate).put("frames",t.frames).put("bpm",t.bpm).put("confidence",t.confidence).put("phase",t.phaseSeconds).put("rms",t.rms)
            .put("tailBpm",t.tailBpm).put("tailConfidence",t.tailConfidence)
            .put("tailPhase",t.tailPhaseSeconds).put("tailStart",t.tailStartSeconds)
            .put("introCue",t.introCueSeconds);list.put(v);}
        root.put("tracks",list);
        File target=new File(ctx.getFilesDir(),"session.json");
        File pending=new File(ctx.getFilesDir(),"session.json.pending");
        java.nio.file.Files.write(pending.toPath(),root.toString().getBytes(java.nio.charset.StandardCharsets.UTF_8));
        if(!pending.renameTo(target)){
            java.nio.file.Files.move(pending.toPath(),target.toPath(),java.nio.file.StandardCopyOption.REPLACE_EXISTING);
        }
    }
    public static final class Loaded{public final List<TrackData> tracks;public final int style,beats;Loaded(List<TrackData> t,int s,int b){tracks=t;style=s;beats=b;}}
    public static Loaded load(Context ctx)throws Exception{
        File f=new File(ctx.getFilesDir(),"session.json");
        JSONObject root=new JSONObject(new String(java.nio.file.Files.readAllBytes(f.toPath()),java.nio.charset.StandardCharsets.UTF_8));
        JSONArray arr=root.getJSONArray("tracks");List<TrackData> tracks=new ArrayList<>();
        for(int i=0;i<arr.length();i++){
            JSONObject v=arr.getJSONObject(i);File file=new File(v.getString("file"));
            if(!file.isFile())continue;
            tracks.add(new TrackData(v.getString("title"),file,v.getInt("sampleRate"),v.getLong("frames"),v.getDouble("bpm"),v.getDouble("confidence"),v.getDouble("phase"),v.getDouble("rms"),v.optDouble("tailBpm",v.getDouble("bpm")),v.optDouble("tailConfidence",0),v.optDouble("tailPhase",v.getDouble("phase")),v.optDouble("tailStart",0),v.optDouble("introCue",0)));
        }
        return new Loaded(tracks,root.optInt("style",0),root.optInt("beats",16));
    }
}
