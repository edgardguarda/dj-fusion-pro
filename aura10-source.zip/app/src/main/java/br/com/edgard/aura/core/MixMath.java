package br.com.edgard.aura.core;

/** Pure sample-clock mixing math; never schedules a DJ transition on UI timers. */
public final class MixMath {
    public static final int AUTO=0, SMOOTH=1, LINEAR=2, S_CURVE=3, ENERGY=4, BASS_SWAP=5, EARLY=6, LATE=7;
    private MixMath() {}
    public static double clamp(double x,double a,double b){return Math.max(a,Math.min(b,x));}
    public static double smoothstep(double x){x=clamp(x,0,1); return x*x*(3-2*x);}
    public static double shape(int style,double t){
        t=clamp(t,0,1);
        switch(style){
            case LINEAR:return t;
            case S_CURVE:return smoothstep(t);
            case ENERGY:return smoothstep(smoothstep(t));
            case BASS_SWAP:return smoothstep((t-0.35)/0.30);
            case EARLY:return 1-(1-t)*(1-t);
            case LATE:return t*t;
            case SMOOTH:case AUTO:default:return t;
        }
    }
    public static double gain(int style,boolean incoming,double t){
        double f=shape(style,t);
        if(style==LINEAR)return incoming?f:1-f;
        return incoming?Math.sin(f*Math.PI*0.5):Math.cos(f*Math.PI*0.5);
    }
    /** Low end remains owned by one deck (rather than two loud kicks at once). */
    public static double bassGain(boolean incoming,double t){
        double f=smoothstep((t-0.30)/0.40);
        return incoming?f:1-f;
    }
    /** Saturating guard for sums slightly >1; ordinary signals remain linear. */
    public static double limit(double x){
        double a=Math.abs(x);if(a<=0.92)return x;
        return Math.copySign(Math.min(0.999,0.92+(a-0.92)/(1+4*(a-0.92))),x);
    }
    public static double stretchRatio(double bpmA,double bpmB){return bpmA/bpmB;}
    /** Validate adjustment before authorizing a long, beat-aligned blend. */
    public static boolean compatible(TrackData a,TrackData b){
        if(!a.trustworthyTempo() || !b.trustworthyTempo())return false;
        double ratio=stretchRatio(a.bpm,b.bpm);
        return ratio>=0.96 && ratio<=1.04;
    }
}
