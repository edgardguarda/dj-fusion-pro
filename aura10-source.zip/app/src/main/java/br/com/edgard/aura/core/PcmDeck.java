package br.com.edgard.aura.core;

import java.io.*;

/** A tiny sequential page cache. Reads stereo frames, interpolates continuously. */
public final class PcmDeck implements AutoCloseable {
    private final RandomAccessFile file;
    public final TrackData data;
    private final byte[] bytes=new byte[16384*4];
    private long cachedStart=-1;
    private int cachedFrames=0;
    public double cursor;
    public double step;
    private double lowL=0,lowR=0;
    public PcmDeck(TrackData data,int outputRate,double rate,double startSeconds)throws IOException{
        this.data=data;file=new RandomAccessFile(data.file,"r");
        cursor=startSeconds*data.sampleRate;
        step=(double)data.sampleRate/outputRate*rate;
    }
    private void load(long frame)throws IOException{
        if(frame>=cachedStart&&frame<cachedStart+cachedFrames)return;
        cachedStart=frame;
        file.seek(frame*4);int desired=(int)Math.min(bytes.length,(data.frames-frame)*4);
        int off=0;while(off<desired){int n=file.read(bytes,off,desired-off);if(n<0)break;off+=n;}
        cachedFrames=off/4;
    }
    private float at(long frame,int ch)throws IOException{
        if(frame<0||frame>=data.frames)return 0;
        load(frame);int idx=(int)(frame-cachedStart)*4+ch*2;
        return (short)((bytes[idx]&255)|(bytes[idx+1]<<8))/32768f;
    }
    /** Read one stereo sample and advance one *output* frame. */
    public void next(float[] out)throws IOException{
        long f=(long)Math.floor(cursor);double fraction=cursor-f;
        out[0]=(float)(at(f,0)*(1-fraction)+at(f+1,0)*fraction);
        out[1]=(float)(at(f,1)*(1-fraction)+at(f+1,1)*fraction);
        cursor+=step;
    }
    public void resetLow(){lowL=lowR=0;}
    /** Continuous first-order lowpass; high = signal - low. */
    public float split(float sample,boolean left,int outputRate){
        double a=Math.exp(-2*Math.PI*160/outputRate);
        if(left){lowL=lowL*a+(1-a)*sample;return (float)lowL;}
        lowR=lowR*a+(1-a)*sample;return (float)lowR;
    }
    public void close()throws IOException{file.close();}
}
