package br.com.edgard.aura.core;

import java.io.File;

/** Audio already decoded to interleaved little-endian stereo PCM16. */
public final class TrackData {
    public final String title;
    public final File file;
    public final int sampleRate;
    public final long frames;
    public final double bpm;
    public final double confidence;
    public final double phaseSeconds;
    public final double rms;
    public final double tailBpm,tailConfidence,tailPhaseSeconds,tailStartSeconds;
    public final double introCueSeconds;
    public TrackData(String title, File file, int sampleRate, long frames,
                     double bpm, double confidence, double phaseSeconds, double rms) {
        this(title,file,sampleRate,frames,bpm,confidence,phaseSeconds,rms,bpm,confidence,phaseSeconds,0,0);
    }
    public TrackData(String title,File file,int sampleRate,long frames,
                     double bpm,double confidence,double phaseSeconds,double rms,
                     double tailBpm,double tailConfidence,double tailPhaseSeconds,double tailStartSeconds){
        this(title,file,sampleRate,frames,bpm,confidence,phaseSeconds,rms,
             tailBpm,tailConfidence,tailPhaseSeconds,tailStartSeconds,0);
    }
    public TrackData(String title,File file,int sampleRate,long frames,
                     double bpm,double confidence,double phaseSeconds,double rms,
                     double tailBpm,double tailConfidence,double tailPhaseSeconds,double tailStartSeconds,double introCueSeconds){
        this.title=title;this.file=file;this.sampleRate=sampleRate;this.frames=frames;
        this.bpm=bpm;this.confidence=confidence;this.phaseSeconds=phaseSeconds;this.rms=rms;
        this.tailBpm=tailBpm;this.tailConfidence=tailConfidence;this.tailPhaseSeconds=tailPhaseSeconds;
        this.tailStartSeconds=tailStartSeconds;this.introCueSeconds=introCueSeconds;
    }
    public double duration() {return frames/(double) sampleRate;}
    public boolean trustworthyTempo() {return bpm >= 75 && bpm <= 170 && confidence >= 0.30;}
}
