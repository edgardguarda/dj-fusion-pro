package br.com.edgard.aura;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Intent;
import android.media.AudioAttributes;
import android.media.AudioFormat;
import android.media.AudioManager;
import android.media.AudioTrack;
import android.os.Build;
import android.os.IBinder;
import android.os.Process;
import android.util.Log;
import br.com.edgard.aura.core.*;
import java.util.List;
import java.util.concurrent.atomic.AtomicBoolean;

/** Sample-clock stereo mixer. No UI timer or browser thread drives the audio. */
public final class AudioService extends Service {
    public static final String START="br.com.edgard.aura.START";
    public static final String STOP="br.com.edgard.aura.STOP";
    public static final String PAUSE="br.com.edgard.aura.PAUSE";
    public static final String RESUME="br.com.edgard.aura.RESUME";
    public static final String NEXT="br.com.edgard.aura.NEXT";
    public static final String RECORD="br.com.edgard.aura.RECORD";
    public static final String RECORD_OFF="br.com.edgard.aura.RECORD_OFF";
    private static final String CHANNEL="aura-dj-playback";
    private final AtomicBoolean running=new AtomicBoolean(false);
    private Thread thread;
    private final AtomicBoolean paused=new AtomicBoolean(false),skipRequested=new AtomicBoolean(false);
    private volatile AudioTrack output;
    private final AtomicBoolean recording=new AtomicBoolean(false);
    private volatile WavWriter recorder;
    private volatile String currentTitle="";
    private static final AtomicBoolean ACTIVE=new AtomicBoolean(false);
    public static boolean isPlaying(){return ACTIVE.get();}
    @Override public IBinder onBind(Intent intent){return null;}
    private void status(String msg){getSharedPreferences("aura",MODE_PRIVATE).edit().putString("status",msg).apply();}
    @Override public int onStartCommand(Intent intent,int flags,int startId){
        if(intent==null)return START_NOT_STICKY;
        if(STOP.equals(intent.getAction())){stopEngine();stopForeground(STOP_FOREGROUND_REMOVE);stopSelf();return START_NOT_STICKY;}
        if(RECORD.equals(intent.getAction())){
            recording.set(true);status("Gravação master habilitada · WAV PCM16");return START_NOT_STICKY;
        }
        if(RECORD_OFF.equals(intent.getAction())){
            recording.set(false);return START_NOT_STICKY;
        }
        if(PAUSE.equals(intent.getAction())){paused.set(true);if(output!=null)output.pause();status("Pausado");return START_NOT_STICKY;}
        if(RESUME.equals(intent.getAction())){paused.set(false);if(output!=null)output.play();status("Reprodução retomada");return START_NOT_STICKY;}
        if(NEXT.equals(intent.getAction())){skipRequested.set(true);return START_NOT_STICKY;}
        if(START.equals(intent.getAction())&&!running.get()){
            paused.set(false);skipRequested.set(false);
            recording.set(getSharedPreferences("aura",MODE_PRIVATE).getBoolean("recordRequested",false));
            createChannel();
            Intent open=new Intent(this,MainActivity.class);
            int pflags=PendingIntent.FLAG_UPDATE_CURRENT|(Build.VERSION.SDK_INT>=23?PendingIntent.FLAG_IMMUTABLE:0);
            PendingIntent openPending=PendingIntent.getActivity(this,3,open,pflags);
            Notification note=new Notification.Builder(this,CHANNEL).setContentTitle("AURA DJ — tocando")
                    .setContentText("Mixagem automática nativa").setSmallIcon(android.R.drawable.ic_media_play)
                    .setContentIntent(openPending).setOngoing(true).build();
            startForeground(7,note);
            running.set(true);ACTIVE.set(true);
            thread=new Thread(this::playLoop,"AURA-native-PCM-output");thread.start();
        }
        return START_NOT_STICKY;
    }
    private void createChannel(){
        NotificationManager m=(NotificationManager)getSystemService(NOTIFICATION_SERVICE);
        if(Build.VERSION.SDK_INT>=26)m.createNotificationChannel(new NotificationChannel(CHANNEL,"AURA DJ — áudio",NotificationManager.IMPORTANCE_LOW));
    }
    private void stopEngine(){running.set(false);paused.set(false);Thread t=thread;if(t!=null)t.interrupt();}
    @Override public void onDestroy(){stopEngine();super.onDestroy();}
    private static int signed16(double x){return (int)Math.round(MixMath.limit(MixMath.clamp(x,-1.8,1.8))*32767);}
    private void playLoop(){
        Process.setThreadPriority(Process.THREAD_PRIORITY_AUDIO);
        AudioTrack audio=null;PcmDeck a=null,b=null;
        try{
            SessionStore.Loaded s=SessionStore.load(this);
            List<TrackData> tracks=new java.util.ArrayList<>(s.tracks);
            getSharedPreferences("aura",MODE_PRIVATE).edit().putString("dj_mode","playing").putInt("dj_index",0).apply();
            if(tracks.isEmpty())throw new IllegalStateException("Nenhuma música pronta");
            final int hz=48000;
            int min=AudioTrack.getMinBufferSize(hz,AudioFormat.CHANNEL_OUT_STEREO,AudioFormat.ENCODING_PCM_16BIT);
            if(min<=0)throw new IllegalStateException("AudioTrack indisponível");
            AudioFormat fmt=new AudioFormat.Builder().setEncoding(AudioFormat.ENCODING_PCM_16BIT).setSampleRate(hz).setChannelMask(AudioFormat.CHANNEL_OUT_STEREO).build();
            AudioAttributes att=new AudioAttributes.Builder().setContentType(AudioAttributes.CONTENT_TYPE_MUSIC).setUsage(AudioAttributes.USAGE_MEDIA).build();
            audio=new AudioTrack.Builder().setAudioFormat(fmt).setAudioAttributes(att).setBufferSizeInBytes(Math.max(min*3,32768)).setTransferMode(AudioTrack.MODE_STREAM).build();
            if(audio.getState()!=AudioTrack.STATE_INITIALIZED)throw new IllegalStateException("Não foi possível inicializar saída de áudio");
            audio.play();output=audio;
            int idx=0;double rateA=1.0;
            a=new PcmDeck(tracks.get(0),hz,rateA,0);
            TrackPlanner.Handoff handoff=null;double blendFrames=0,blendIndex=0;
            if(tracks.size()>1){handoff=TrackPlanner.plan(tracks.get(0),tracks.get(1),rateA,s.beats);b=new PcmDeck(tracks.get(1),hz,handoff.rateNext,handoff.cueBSeconds);}
            final byte[] pcm=new byte[4096*4];float[] va=new float[2],vb=new float[2];
            status("Tocando: "+tracks.get(0).title);
            long refreshAt=0;long stateAt=0;
            boolean completed=false;
            while(running.get()){
                // The decoder may add the remaining tracks while deck A is playing.
                long now=System.nanoTime();
                if(now-refreshAt>850_000_000L){
                    refreshAt=now;
                    try{
                        List<TrackData> updated=SessionStore.load(this).tracks;
                        if(updated.size()>tracks.size()){
                            tracks.clear();tracks.addAll(updated);
                        }
                        if(handoff==null && idx+1<tracks.size()){
                            handoff=TrackPlanner.plan(tracks.get(idx),tracks.get(idx+1),rateA,s.beats);
                            b=new PcmDeck(tracks.get(idx+1),hz,handoff.rateNext,handoff.cueBSeconds);
                        }
                    }catch(Exception refreshError){Log.w("AURA","Playlist refresh failed",refreshError);}
                }
                if(now-stateAt>950_000_000L){
                    stateAt=now;
                    getSharedPreferences("aura",MODE_PRIVATE).edit()
                      .putInt("dj_index",idx)
                      .putFloat("dj_time",(float)(a.cursor/a.data.sampleRate))
                      .putString("dj_mode",paused.get()?"paused":blendFrames>0?"mixing":"playing")
                      .putString("dj_next",idx+1<tracks.size()?tracks.get(idx+1).title:"")
                      .apply();
                }
                if(paused.get()){
                    try{Thread.sleep(50);}catch(InterruptedException ex){break;}
                    continue;
                }
                int cursor=0;
                while(cursor<pcm.length&&running.get()){
                    double secA=a.cursor/a.data.sampleRate;
                    // The Android audio sample clock is the only source of timing.
                    if(handoff==null && a.cursor>=a.data.frames-2){completed=true;running.set(false);break;}
                    if(skipRequested.getAndSet(false) && b!=null && blendFrames<=0){
                        blendFrames=2.2*hz;blendIndex=0;
                        status("Próxima faixa: transição manual protegida");
                    }
                    if(handoff!=null && b!=null && secA>=handoff.startASeconds && blendFrames<=0){
                        blendFrames=Math.max(1,Math.round(handoff.durationSeconds*hz));blendIndex=0;
                        status("Mixando: "+tracks.get(idx).title+" → "+tracks.get(idx+1).title+(handoff.beatmatch?" (beatmatch)":" (crossfade)"));
                    }
                    a.next(va);
                    double left=va[0],right=va[1];
                    if(blendFrames>0 && b!=null){
                        b.next(vb);
                        double t=MixMath.clamp(blendIndex/blendFrames,0,1);
                        double ga=MixMath.gain(s.style,false,t),gb=MixMath.gain(s.style,true,t);
                        double la=a.split(va[0],true,hz),ra=a.split(va[1],false,hz);
                        double lb=b.split(vb[0],true,hz),rb=b.split(vb[1],false,hz);
                        left=ga*(va[0]-la)+gb*(vb[0]-lb)+MixMath.bassGain(false,t)*la+MixMath.bassGain(true,t)*lb;
                        right=ga*(va[1]-ra)+gb*(vb[1]-rb)+MixMath.bassGain(false,t)*ra+MixMath.bassGain(true,t)*rb;
                        if(++blendIndex>=blendFrames){
                            a.close();a=b;idx++;rateA=handoff.rateNext;b=null;handoff=null;blendFrames=0;
                            if(idx+1<tracks.size()){
                                handoff=TrackPlanner.plan(tracks.get(idx),tracks.get(idx+1),rateA,s.beats);
                                b=new PcmDeck(tracks.get(idx+1),hz,handoff.rateNext,handoff.cueBSeconds);
                            }
                            status("Tocando: "+tracks.get(idx).title);
                        }
                    }
                    int l=signed16(left),r=signed16(right);
                    pcm[cursor++]=(byte)l;pcm[cursor++]=(byte)(l>>8);
                    pcm[cursor++]=(byte)r;pcm[cursor++]=(byte)(r>>8);
                }
                if(cursor==0)break;
                try{
                    if(recording.get()){
                        if(recorder==null){
                            java.io.File dir=new java.io.File(getFilesDir(),"masters");dir.mkdirs();
                            java.io.File f=new java.io.File(dir,"aura-master-"+System.currentTimeMillis()+".wav");
                            recorder=new WavWriter(f,hz);
                            getSharedPreferences("aura",MODE_PRIVATE).edit().putString("lastMaster",f.getAbsolutePath()).apply();
                        }
                        recorder.write(pcm,cursor);
                    }else if(recorder!=null){
                        recorder.close();recorder=null;
                    }
                }catch(Exception recError){
                    recording.set(false);status("Erro ao gravar master: "+recError.getMessage());
                    try{if(recorder!=null)recorder.close();}catch(Exception ignored){}
                    recorder=null;
                }
                int written=0;
                while(written<cursor&&running.get()){
                    int n=audio.write(pcm,written,cursor-written,AudioTrack.WRITE_BLOCKING);
                    if(n<0)throw new IllegalStateException("Falha AudioTrack: "+n);
                    if(n==0)throw new IllegalStateException("Áudio parou de avançar");
                    written+=n;
                }
            }
            if(completed)status("Set concluído");else status("Reprodução encerrada");
        }catch(Exception e){
            getSharedPreferences("aura",MODE_PRIVATE).edit().putString("lastCrash",Log.getStackTraceString(e)).apply();
            status("ERRO: "+e.getClass().getSimpleName()+" — "+e.getMessage());
        }
        finally{
            try{if(a!=null)a.close();}catch(Exception ignored){}
            try{if(b!=null)b.close();}catch(Exception ignored){}
            if(recorder!=null){try{recorder.close();}catch(Exception e){Log.e("AURA","Failed to finalize master",e);}recorder=null;}
            output=null;
            if(audio!=null){try{audio.pause();audio.flush();audio.release();}catch(Exception ignored){}}
            running.set(false);ACTIVE.set(false);
            getSharedPreferences("aura",MODE_PRIVATE).edit().putString("dj_mode","idle").apply();
            stopForeground(STOP_FOREGROUND_REMOVE);stopSelf();
        }
    }
}
