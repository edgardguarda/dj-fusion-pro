/* AURA 10 Android host. The original UI stays in the APK;
 * native mode owns file selection, preparation and audio transport. */
(function () {
 'use strict';
 if (window.__AURA10_ATTACHED) return;
 window.__AURA10_ATTACHED = true;
 const api = window.AURA_ANDROID;
 if (!api || typeof api.snapshot !== 'function') return;
 const $ = (id) => document.getElementById(id);
 const escape = (s) => String(s ?? '').replace(/[&<>"']/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
 const fmt = (v) => {const n=Math.max(0,Math.floor(Number(v)||0));return `${Math.floor(n/60)}:${String(n%60).padStart(2,'0')}`;};
 const css = document.createElement('style');
 css.textContent = `
  #aura10-native-controller{background:#0c2519;border:1px solid #287f53;border-radius:12px;padding:8px;display:grid;gap:5px;font:12px/1.35 system-ui;color:#e1f7e9}
  #aura10-native-controller .head{display:flex;justify-content:space-between;align-items:center;gap:8px;min-height:34px}
  #aura10-native-controller .head button{min-height:30px;padding:4px 8px;font-size:11px}
  #aura10-native-controller .detail{display:none;gap:5px;grid-template-columns:repeat(3,minmax(0,1fr))}
  #aura10-native-controller.open .detail{display:grid}
  #aura10-native-controller .detail button{min-width:0;min-height:37px;padding:4px 5px;font-size:11px;white-space:normal}
  #aura10-state{color:#a7e7c2;overflow-wrap:anywhere;font-size:11px}
  #aura10-native-tracklist{overflow:auto;min-height:0;overscroll-behavior:contain}
  #aura10-native-tracklist .entry{padding:7px 6px;display:grid;grid-template-columns:22px minmax(0,1fr) auto;align-items:center;gap:7px;border-bottom:1px solid #31513f}
  #aura10-native-tracklist .entry.on{background:#174c30;border-radius:8px}
  #aura10-native-tracklist .entry b{overflow:hidden;text-overflow:ellipsis;white-space:nowrap;font-size:12px}
  #aura10-native-tracklist .entry small{color:#a6b9ae;white-space:nowrap}
  body.aura10-native #tracks,body.aura10-native #libraryPanel>.pager{display:none!important}
  body.aura10-native #libraryPanel #openLocalIA,body.aura10-native #libraryPanel #portableBanner{display:none!important}
  body.aura10-native #libraryPanel{grid-template-rows:auto minmax(0,1fr)!important}
  body.aura10-native #aura10-native-tracklist{display:block}
  body:not(.aura10-native) #aura10-native-tracklist{display:none}
  body.aura10-native #quickIAStatus{opacity:.7}
  body.aura10-native #aura10-native-controller{display:grid}
  body:not(.aura10-native) #aura10-native-controller{display:none}
  body.aura10-native #onSection,body.aura10-native #nextSection{opacity:.7}
  body.aura10-native .sampler-panel::after,
  body.aura10-native .djfx-panel::after{
    content:"Efeitos Web: somente no modo clássico. Não entram no master nativo.";
    display:block;color:#b9cdbf;font-size:10px;line-height:1.3;padding-top:5px;
  }
 `;
 document.head.appendChild(css);
 const panel = document.createElement('div');panel.id='aura10-native-controller';
 panel.innerHTML = `<div class="head"><strong>AURA 10 · ÁUDIO ANDROID</strong><button id="aura10-tools" type="button" aria-expanded="false">Opções ▾</button></div>
 <div id="aura10-state" role="status">Motor nativo iniciando…</div>
 <div class="detail" id="aura10-detail">
   <button id="aura10-pick" type="button">+ Músicas</button><button id="aura10-start" type="button">▶ AutoDJ</button><button id="aura10-record" type="button">● Gravar WAV</button>
   <button id="aura10-export" type="button">↓ Master WAV</button><button id="aura10-diag" type="button">Diagnóstico</button><button id="aura10-classic" type="button">Modo clássico</button>
 </div>`;
 const row = document.querySelector('.controls .mix-row') || document.querySelector('.controls');
 if(row)row.insertAdjacentElement('afterend',panel);else document.body.appendChild(panel);
 const list = document.createElement('div');list.id='aura10-native-tracklist';
 const legacyTracks=$('tracks');
 if(legacyTracks)legacyTracks.insertAdjacentElement('afterend',list);
 let native=true,record=false,lastJSON='',lastPlaylistKey='';
 document.body.classList.add('aura10-native');
 const style = () => $('mixStyleSelect')?.value || 'auto-dj';
 const beats = () => $('mixBeats')?.value || '0';
 function pick(){api.pick();}
 function start(){api.start(style(),beats());update();}
 function stop(){api.stop();update();}
 function pause(){api.pause();update();}
 function next(){api.next();update();}
 $('aura10-tools').onclick=()=>{const open=panel.classList.toggle('open');$('aura10-tools').setAttribute('aria-expanded',String(open));$('aura10-tools').textContent=open?'Opções ▴':'Opções ▾';};
 $('aura10-pick').onclick=pick;
 $('aura10-start').onclick=start;
 $('aura10-record').onclick=()=>{record=!record;api.record(record);$('aura10-record').textContent=record?'■ Encerrar WAV':'● Gravar WAV';};
 $('aura10-export').onclick=()=>api.saveMaster();
 $('aura10-diag').onclick=()=>api.diagnostic();
 $('aura10-classic').onclick=()=>{
   api.stop();native=false;document.body.classList.remove('aura10-native');
   const msg='Modo clássico utiliza Web Audio e seus efeitos, mas requer importar novamente as músicas para o motor Web. Para retornar ao Android nativo, toque em AURA 10.';
   panel.style.display='block';panel.classList.add('open');$('aura10-state').textContent=msg;
   $('aura10-classic').textContent='Voltar ao Android';
   $('aura10-classic').onclick=()=>{native=true;document.body.classList.add('aura10-native');$('aura10-classic').textContent='Modo clássico';$('aura10-classic').onclick=null;location.reload();};
 };
 // A native selection must never reach the legacy HTML's input/FileList.
 // The original app may retain its Web features in explicit classic mode.
 document.addEventListener('click', e=>{
   if(!native)return;
   const target=e.target.closest?.('#quickAdd,#drop,#files,#aura10-pick,#clear,#play,#pause,#stop,#next');
   if(!target)return;
   if(target.id==='aura10-pick')return;
   e.preventDefault();e.stopImmediatePropagation();
   if(target.id==='quickAdd'||target.id==='drop'||target.id==='files')pick();
   else if(target.id==='clear')api.clear();
   else ({play:start,pause,stop,next})[target.id]?.();
 },true);
 // Disable spurious legacy file-change events if the file chooser originated in WebView.
 $('files')?.addEventListener('change',e=>{if(native){e.stopImmediatePropagation();e.target.value='';}},true);
 function update(){
   if(!native)return;
   try{
     const v=JSON.parse(api.snapshot());
     const status=String(v.status||'AURA Android pronto');
     const selected=Math.max(0,v.selected||0),decoded=Math.max(0,v.decoded||0);
     const playing=!!v.playing,idx=Math.max(0,v.index||0);
     const prefix=v.busy?`DSP ${decoded}/${selected}`:playing?(v.mode==='paused'?'PAUSADO':'REPRODUÇÃO'):selected?`PRONTAS ${decoded}/${selected}`:'BIBLIOTECA VAZIA';
     $('aura10-state').textContent=prefix+' · '+status;
     $('trackCount') && ($('trackCount').textContent=String(selected));
     $('quickIAStatus') && ($('quickIAStatus').textContent='DSP nativo · IA neural desativada');
     $('transport') && ($('transport').textContent=playing?(v.mode==='paused'?'PAUSADO':'TOCANDO'):v.busy?'ANALISANDO':selected?'PRONTO':'VAZIO');
     $('status') && ($('status').textContent=prefix+' · '+status);
     for(const id of ['play','pause','next'])if($(id))$(id).disabled=!selected && id!=='pause';
     if($('pause'))$('pause').disabled=!playing;
     if($('next'))$('next').disabled=!playing;
     const names=Array.isArray(v.names)?v.names:[],tracks=Array.isArray(v.tracks)?v.tracks:[];
     const key=JSON.stringify({names,tracks,idx,playing});
     if(key!==lastPlaylistKey){
       lastPlaylistKey=key;
       const frag=document.createDocumentFragment();
       names.forEach((name,i)=>{
         const div=document.createElement('div');div.className='entry'+(playing&&tracks[idx]?.name===name?' on':'');
         const t=tracks.find(x=>x.name===name);const state=t?`${Number(t.bpm||0).toFixed(1)} BPM · ${fmt(t.seconds)} · DSP`:(v.busy?'Preparando…':'Pendente');
         div.innerHTML=`<small>${String(i+1).padStart(2,'0')}</small><b title="${escape(name)}">${escape(name)}</b><small>${escape(state)}</small>`;
         frag.appendChild(div);
       });
       list.replaceChildren(frag);
       if(!names.length)list.innerHTML='<div class="empty"><strong>Nenhuma música selecionada</strong><span>Toque em + Músicas.</span></div>';
     }
     const current=tracks[idx];
     const following=tracks[idx+1];
     if(current){
       $('currentName') && ($('currentName').textContent=current.name);
       $('onBpm') && ($('onBpm').textContent=`${Number(current.bpm||0).toFixed(1)} BPM · DSP`);
       $('onKey') && ($('onKey').textContent='Tom ?');
       $('onSection') && ($('onSection').textContent='Seção não verificada');
       $('time') && ($('time').textContent=`${fmt(v.time)} / ${fmt(current.seconds)}`);
       $('remaining') && ($('remaining').textContent=`-${fmt(Math.max(0,current.seconds-v.time))}`);
     }else{
       $('currentName') && ($('currentName').textContent=names[0]||'Nenhuma faixa');
       $('onBpm') && ($('onBpm').textContent='DSP em preparação');
     }
     $('nextName') && ($('nextName').textContent=following?.name||names[idx+1]||'Fim da fila');
     $('nextBpm') && ($('nextBpm').textContent=following?`${Number(following.bpm).toFixed(1)} BPM · DSP`:'BPM pendente');
     $('nextKey') && ($('nextKey').textContent='Tom ?');
     $('nextSection') && ($('nextSection').textContent='Seção não verificada');
     $('nextDuration') && ($('nextDuration').textContent=following?fmt(following.seconds):'--:--');
   }catch(e){$('aura10-state').textContent='Falha de comunicação Android: '+e.message;}
 }
 update();setInterval(update,1000);
})();
