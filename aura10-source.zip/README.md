# EDGARD AURA 10 — Android nativo (correção da integração)

Esta edição corrige falhas verificadas da versão AURA 9; não é a homologação definitiva de mixagem musical.

## Correções implementadas

1. **Sem análise dupla:** o seletor Android recebe as músicas diretamente. O HTML/WebView não recebe os arquivos e não inicia a análise paralela ONNX/DSP legado no modo nativo.
2. **Dados de ritmo persistidos:** BPM, confiança e fase da saída, entrada audível e duração são mantidos ao passar da preparação ao serviço de áudio. O código AURA 9 perdia esses campos.
3. **Reprodução não bloqueada por toda a fila:** assim que duas faixas estiverem decodificadas, o serviço de áudio começa. As outras são processadas sequencialmente em disco; a fila é ampliada por arquivo JSON escrito atomicamente.
4. **Diagnóstico e progresso:** cada música exibe progresso de decodificação e análise; Android mostra fila, tempo e faixas ativas diretamente na UI AURA original.
5. **Interface sem sobreposição fixa:** o painel Android fica dentro do console original, recolhido por padrão; a página antiga permanece acessível em modo clássico, com as limitações conhecidas.
6. **Compatibilidade de decodificação:** aceita saídas MediaCodec de 16 bits e ponto flutuante, convertendo PCM float para PCM16 intercalado.
7. **Segurança:** conteúdo remoto não carrega na mesma WebView que contém a ponte Android; links HTTPs externos abrem no navegador separado.

## Situação dos recursos

- Dois decks nativos, sincronia de BPM por leitura interpolada com **alteração de tonalidade**, crossfade com sobreposição e escolha de oito curvas de ganho: implementados.
- Gravação WAV do motor nativo: implementada (deve ser testada em celular).
- Interface clássica (FX, biblioteca original, displays, diagnóstico e outros): preservada, porém **não está completamente conectada ao motor Android**. O modo clássico pode usar o DSP/Web Audio antigo mediante nova importação.
- IA neural ONNX, stems e análise estrutural local: **não disponíveis no motor Android**. O app sinaliza isso, sem reportar falsamente que estão funcionando.
- Adequação de mixagem em músicas reais: **não homologada**. Testes sintéticos não certificam qualidade artística, fraseado ou tonalidade.

## Utilização

Instale o APK, abra o AURA 10, use `+ Músicas` e escolha arquivos no seletor Android. Toque em **AutoDJ** ou **Tocar**. A primeira reprodução inicia depois da preparação das duas primeiras faixas, e o restante segue sendo analisado. O estado da fila e os erros estão em **Opções → Diagnóstico**. Use **Opções → Testar som** para ouvir dois tons de teste produzidos pelo AudioTrack, sem importar música; esse teste diagnostica apenas a saída Android, não a qualidade da mixagem.

O aplicativo pode ocupar espaço considerável para o cache PCM16 estéreo (aprox. 11,5 MB/minuto por faixa a 48 kHz).

## Testes executados

- `bash tests/run-core-tests.sh`: BPM 129/131, alinhamento da fase em regiões de saída, crossfade efetivo e curvas de mixagem.
- `node --check app/src/main/assets/native-ui.js`.
- Teste visual automatizado Chromium de fila e interceptação de transporte com ponte Android simulada; **não substitui teste de celular**.
- APK compilado no GitHub Actions. Instalação e áudio em celular real ainda precisam ser observados.
