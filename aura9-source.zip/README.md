# Edgard AURA 9 — Android completo (edição experimental)

Esta edição **preserva o HTML integral do AURA 6.2** e adiciona um motor Android com **decodificação MediaCodec, mixagem PCM sincronizada no relógio de AudioTrack e gravação WAV**. A tela principal não é mais o protótipo reduzido da versão 8.1.

## Modos, limites e transparência

**Motor nativo (padrão):** importar pelo botão `+ Músicas` da interface, escolher estilo e número de tempos do AURA e tocar. A preparação PCM acontece no Android, fora do JavaScript. Se o ritmo do trecho final da música ON e do início da NEXT não for demonstrado, o aplicativo preserva uma **sobreposição de 2,4 a 4 segundos**, não um suposto beatmatch. A velocidade de cada faixa pode ser alterada até ±4%, **com alteração correspondente da tonalidade**. Não é Rubber Band R3; o Rubber Band não foi compilado para este APK.

**Modo clássico:** desligar `Motor nativo` no painel inferior para acessar o motor Web Audio original, junto dos seus controles e efeitos. Esse modo mantém as limitações do navegador e não é homologado.

**AURA 6.2 embutido:** interface, biblioteca, ON/NEXT, visualizações, efeitos, painel de análise, editor de grade, prévia, diagnósticos e recursos de gravação Web Audio originais permanecem no aplicativo. No modo nativo, entretanto, **alguns controles de processamento da interface Web não se aplicam ao motor Android**; os controles transport, estilo e duração são conectados ao motor nativo. A gravação nativa é feita pelos botões `● Gravar WAV` e `↓ Master WAV` do painel Android. Os dados neurais/modelos ONNX não são distribuídos no APK, e a IA Web não foi homologada no Android.

**Não há promessa de qualidade de mixagem garantida em todas as músicas**. Esses algoritmos possuem fallback audível, mas só testes reais com músicas e escuta permitem homologar a adequação musical. Não houve acesso às gravações das suas músicas nesta compilação.

## Fundamentos técnicos

- A interface original reside no arquivo de assets `app/src/main/assets/aura.html`, sem remover seus recursos.
- `MainActivity.java` abre a interface em WebView com origem local segura, usa o seletor Android e liga o transporte ao serviço de áudio nativo.
- `BeatAnalyzer.java` estima andamento e fase separadamente em janelas no início e próximo ao final de cada faixa.
- `TrackPlanner.java` exige coerência de andamento, confiança no ritmo e espaço suficiente antes de liberar um blend sincronizado; caso contrário, executa crossfade de 2,4 a 4 segundos.
- `AudioService.java` soma os dois decks por amostra, com filtro de graves e curvas de ganho no AudioTrack, preservando playback sem Internet e com notificação.
- `WavWriter.java` grava PCM16 stereo 48 kHz, com cabeçalho RIFF atualizado no encerramento.

## Testes e instalação

O script `tests/run-core-tests.sh` testa o núcleo na JVM Linux. Uma compilação Android assinada em modo de depuração não confirma que o aplicativo ou sua IA funcionam no celular. O APK será compilado em GitHub Actions; o resultado deve ser testado em aparelho real, incluindo a seleção de arquivos, a reprodução e o master.
