import br.com.edgard.aura.core.*;
import java.io.*;import java.util.*;
public class EngineTest {
    static int assertions=0;
    static void ok(boolean b,String s){assertions++;if(!b)throw new AssertionError(s);}
    static File pulses(double bpm,int rate,int seconds)throws Exception {
        File f=File.createTempFile("aura-test-", ".pcm");f.deleteOnExit();
        try(BufferedOutputStream out=new BufferedOutputStream(new FileOutputStream(f))){
            byte[] b=new byte[4];for(int i=0;i<rate*seconds;i++){
                double ph=(i/(double)rate*bpm/60.0)%1;
                double x=ph<0.015?Math.exp(-ph*230)*0.8:0;
                short s=(short)(x*32767);b[0]=(byte)s;b[1]=(byte)(s>>>8);b[2]=b[0];b[3]=b[1];out.write(b);
            }
        }return f;
    }
    public static void main(String[] args)throws Exception{
        for(int style=0;style<8;style++){
            ok(MixMath.gain(style,false,0)>0.99,"start deck");
            ok(MixMath.gain(style,true,0)<.001,"incoming start");
            ok(MixMath.gain(style,false,1)<.001,"end deck");
            ok(MixMath.gain(style,true,1)>.99,"incoming end");
            for(int i=0;i<=100;i++){
                double t=i/100.;
                ok(MixMath.gain(style,false,t)>=0 && MixMath.gain(style,false,t)<=1.01,"gain A");
                ok(MixMath.gain(style,true,t)>=0 && MixMath.gain(style,true,t)<=1.01,"gain B");
                ok(Math.abs(MixMath.bassGain(true,t)+MixMath.bassGain(false,t)-1)<1e-9,"bass ownership");
            }
        }
        ok(Math.abs(MixMath.stretchRatio(128.89,130.99)-.983968)<.00001,"rate");
        File f=pulses(129,48000,40),g=pulses(131,44100,40);
        BeatAnalyzer.Result a=BeatAnalyzer.analyze(f,48000),b=BeatAnalyzer.analyze(g,44100);
        ok(Math.abs(a.bpm-129)<0.25,"BPM 129 precise "+a.bpm);
        ok(Math.abs(b.bpm-131)<0.25,"BPM 131 precise "+b.bpm);
        TrackData aa=new TrackData("A",f,48000,f.length()/4,a.bpm,Math.max(.6,a.confidence),a.phase,a.rms);
        TrackData bb=new TrackData("B",g,44100,g.length()/4,b.bpm,Math.max(.6,b.confidence),b.phase,b.rms);
        TrackPlanner.Handoff h=TrackPlanner.plan(aa,bb,1,16);
        ok(h.beatmatch,"compatible pulse mix");ok(h.durationSeconds>6&&h.durationSeconds<9,"16 beats duration");
        // Verify the two decoded sources can overlap with interpolated reading.
        try(PcmDeck da=new PcmDeck(aa,48000,1,h.startASeconds);
            PcmDeck db=new PcmDeck(bb,48000,h.rateNext,h.cueBSeconds)){
            float[] x=new float[2],y=new float[2];int both=0;double power=0;
            for(int i=0;i<(int)(h.durationSeconds*48000);i++){
                da.next(x);db.next(y);double t=i/(h.durationSeconds*48000);
                double z=x[0]*MixMath.gain(1,false,t)+y[0]*MixMath.gain(1,true,t);
                power+=z*z;if(Math.abs(x[0])>.01&&Math.abs(y[0])>.01)both++;
            }
            ok(power>1,"actual overlapping audio power");
            System.out.printf(Locale.US,"pulses: %.2f BPM / %.2f BPM; overlap=%.2f s; dual-kick-frames=%d; power=%.1f%n",a.bpm,b.bpm,h.durationSeconds,both,power);
        }
        TrackData bad=new TrackData("bad",g,44100,g.length()/4,131,0,0,.1);
        TrackPlanner.Handoff safe=TrackPlanner.plan(aa,bad,1,64);
        ok(!safe.beatmatch&&safe.durationSeconds>=1.5,"non-beat fallback is AUDIBLE crossfade");
        System.out.println("PASS "+assertions+" checks");
    }
}
