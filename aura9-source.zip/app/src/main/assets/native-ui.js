/* AURA native Android controller. Original AURA DOM, assets, visualizers and legacy mode stay intact. */
(function(){
 'use strict';
 if(document.getElementById('aura9-native-controller'))return;
 const css=document.createElement('style');
 css.textContent=`
  #aura9-native-controller{position:fixed;z-index:11000;left:8px;right:8px;bottom:8px;
   background:#071c15;box-shadow:0 0 22px #000a;border:1px solid #39bc7c;
   border-radius:16px;color:#d4f9e4;padding:10px 12px;font:14px/1.35 system-ui,sans-serif;}
  #aura9-native-controller button{color:#eafff3;background:#194734;border:1px solid #359465;
   border-radius:10px;padding:8px;margin:4px 5px 0 0;font-size:13px;font-weight:650;}
  #aura9-native-controller button:disabled{opacity:.45;}
  #aura9-native-controller label{display:flex;align-items:center;gap:8px;}
  #aura9-native-controller small{font-size:11px;opacity:.85;display:block;margin-top:4px;max-height:40px;overflow:hidden;}
  #aura9-native-controller .expanded{margin-top:6px;}
  #aura9-native-controller .top{display:flex;gap:8px;align-items:center;justify-content:space-between;}
  body{padding-bottom:130px!important;}
 `;
 document.head.appendChild(css);
 const panel=document.createElement('section');panel.id='aura9-native-controller';
 panel.innerHTML=`<div class="top"><strong>● AURA 9 · ANDROID</strong>
   <label><input id="aura9-native-mode" type="checkbox" checked> Motor nativo</label>
   <button id="aura9-collapse" aria-label="Ocultar painel">▴</button></div>
   <div class="expanded" id="aura9-expand">
    <button id="aura9-import">＋ Músicas</button>
    <button id="aura9-play">▶ AutoDJ</button>
    <button id="aura9-pause">Ⅱ Pausar</button>
    <button id="aura9-next">⏭ Próxima</button>
    <button id="aura9-stop">■ Parar</button>
    <button id="aura9-record">● Gravar WAV</button>
    <button id="aura9-export">↓ Master WAV</button>
    <button id="aura9-diag">Diagnóstico</button>
    <small id="aura9-native-status">AURA Android: selecione as músicas</small>
   </div>`;
 document.body.appendChild(panel);
 const $=id=>document.getElementById(id);
 const active=()=>$('aura9-native-mode').checked;
 const style=()=>$('mixStyleSelect')?.value||'auto-dj';
 const beats=()=>$('mixBeats')?.value||'0';
 const status=()=>{try{$('aura9-native-status').textContent=window.AURA_ANDROID.status()+' · '+window.AURA_ANDROID.count()+' arquivos selecionados';}catch(e){$('aura9-native-status').textContent='Bridge nativa indisponível: '+e;}};
 const start=()=>{window.AURA_ANDROID.start(style(),beats());status();};
 $('aura9-import').onclick=()=>$('files')?.click();
 $('aura9-play').onclick=start;
 $('aura9-pause').onclick=()=>{window.AURA_ANDROID.pause();status();};
 $('aura9-next').onclick=()=>{window.AURA_ANDROID.next();status();};
 $('aura9-stop').onclick=()=>{window.AURA_ANDROID.stop();status();};
 let isRecording=false;
 $('aura9-record').onclick=()=>{isRecording=!isRecording;window.AURA_ANDROID.record(isRecording);$('aura9-record').textContent=isRecording?'■ Encerrar WAV':'● Gravar WAV';status();};
 $('aura9-export').onclick=()=>window.AURA_ANDROID.saveMaster();
 $('aura9-diag').onclick=()=>window.AURA_ANDROID.diagnostic();
 $('aura9-collapse').onclick=()=>{const t=$('aura9-expand');const closed=t.style.display==='none';t.style.display=closed?'':'none';$('aura9-collapse').textContent=closed?'▴':'▾';};
 // Capture legacy transport only when Android Native is selected. Original code keeps
 // working unchanged if the user explicitly disables the native mode.
 ['play','pause','stop','next'].forEach((id)=>{
   const b=$(id);if(!b)return;
   b.addEventListener('click',(event)=>{
     if(!active())return;
     event.preventDefault();event.stopImmediatePropagation();
     ({play:start,pause:()=>window.AURA_ANDROID.pause(),stop:()=>window.AURA_ANDROID.stop(),next:()=>window.AURA_ANDROID.next()})[id]();
     status();
   },true);
 });
 // Prevent two independent audio engines from running concurrently when native mode is selected.
 $('aura9-native-mode').addEventListener('change',()=>{
   if(active()){
     try{document.getElementById('stop')?.click();}catch(e){}
   }else{
     window.AURA_ANDROID.stop();
   }
   status();
 });
 setInterval(status,1400);status();
})();
