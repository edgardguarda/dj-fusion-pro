package br.com.edgard.aura;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Intent;
import android.graphics.Color;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.provider.OpenableColumns;
import android.util.Log;
import android.view.View;
import android.view.WindowManager;
import android.webkit.ConsoleMessage;
import android.webkit.JavascriptInterface;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebResourceResponse;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Toast;

import br.com.edgard.aura.core.BeatAnalyzer;
import br.com.edgard.aura.core.TrackData;
import br.com.edgard.aura.core.TrackPlanner;
import java.io.File;
import java.io.FileInputStream;
import java.io.InputStream;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

/** The COMPLETE original AURA UI is an offline Android asset.
 * Audio in Native mode is rendered by MediaCodec + AudioTrack, not WebAudio.
 * Classic mode remains accessible for advanced legacy controls/visualizers.
 */
public final class MainActivity extends Activity {
    private static final String TAG="AURA9";
    private static final int PICK_AUDIO=701, SAVE_MASTER=702;
    private static final String APP_URL="https://aura.android.local/index.html";
    private final Handler main=new Handler(Looper.getMainLooper());
    private WebView web;
    private android.webkit.ValueCallback<Uri[]> webFileResult;
    private boolean nativeFileSelect=false;
    private final ArrayList<Uri> musicUris=new ArrayList<>();
    private volatile boolean preparing=false;
    private volatile boolean loaded=false;
    private final ArrayList<TrackData> ready=new ArrayList<>();
    private int preparedStyle=0, preparedBeats=16;

    @Override public void onCreate(Bundle state){
        super.onCreate(state);
        Thread.setDefaultUncaughtExceptionHandler((thread,error)->{
            try{getSharedPreferences("aura",MODE_PRIVATE).edit().putString("lastCrash",Log.getStackTraceString(error)).commit();}catch(Throwable ignored){}
            android.os.Process.killProcess(android.os.Process.myPid());
        });
        getWindow().setStatusBarColor(Color.rgb(4,17,12));
        getWindow().setNavigationBarColor(Color.rgb(4,17,12));
        getWindow().setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_ADJUST_RESIZE);
        web=new WebView(this);web.setBackgroundColor(Color.rgb(4,17,12));
        WebSettings settings=web.getSettings();
        settings.setJavaScriptEnabled(true);
        settings.setDomStorageEnabled(true);
        settings.setDatabaseEnabled(true);
        settings.setAllowFileAccess(false);
        settings.setAllowContentAccess(true);
        settings.setMediaPlaybackRequiresUserGesture(false);
        settings.setDefaultTextEncodingName("UTF-8");
        web.addJavascriptInterface(new Bridge(),"AURA_ANDROID");
        web.setWebViewClient(new WebViewClient(){
            @Override public WebResourceResponse shouldInterceptRequest(WebView view,WebResourceRequest req){
                Uri u=req.getUrl();
                if(!"aura.android.local".equals(u.getHost()))return super.shouldInterceptRequest(view,req);
                String path=u.getPath();
                if(!"/index.html".equals(path) && !"/native-ui.js".equals(path))return new WebResourceResponse("text/plain","UTF-8",403,"Forbidden",new java.util.HashMap<>(),new java.io.ByteArrayInputStream(new byte[0]));
                try{
                    InputStream content=getAssets().open("/native-ui.js".equals(path)?"native-ui.js":"aura.html");
                    return new WebResourceResponse("/native-ui.js".equals(path)?"application/javascript":"text/html","UTF-8",content);
                }catch(Exception e){Log.e(TAG,"Asset load failed",e);return new WebResourceResponse("text/plain","UTF-8",new java.io.ByteArrayInputStream(e.toString().getBytes(StandardCharsets.UTF_8)));}
            }
            @Override public void onPageFinished(WebView view,String url){
                loaded=true;
                // Keep the original HTML unchanged: the native controls are a separate, auditable layer.
                view.evaluateJavascript("(function(){var s=document.createElement('script');s.src='/native-ui.js';document.body.appendChild(s);})();",null);
            }
        });
        web.setWebChromeClient(new WebChromeClient(){
            @Override public boolean onShowFileChooser(WebView v,android.webkit.ValueCallback<Uri[]> result,FileChooserParams params){
                if(webFileResult!=null)webFileResult.onReceiveValue(null);
                webFileResult=result;
                nativeFileSelect=false;
                boolean audio=false;
                for(String a:params.getAcceptTypes())if(a!=null&&(a.contains("audio")||a.contains(".mp3")||a.contains(".wav")))audio=true;
                nativeFileSelect=audio;
                openPicker(audio,params.getMode()==FileChooserParams.MODE_OPEN_MULTIPLE);
                return true;
            }
            @Override public boolean onConsoleMessage(ConsoleMessage m){
                if(m.messageLevel()==ConsoleMessage.MessageLevel.ERROR)Log.e(TAG,"Web UI: "+m.message()+" @"+m.lineNumber());
                return true;
            }
        });
        setContentView(web);
        web.loadUrl(APP_URL);
    }
    private void openPicker(boolean music,boolean multiple){
        Intent i=new Intent(Intent.ACTION_OPEN_DOCUMENT);
        i.addCategory(Intent.CATEGORY_OPENABLE);i.setType(music?"audio/*":"*/*");
        i.putExtra(Intent.EXTRA_ALLOW_MULTIPLE,multiple);
        i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION|Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION);
        try{startActivityForResult(i,PICK_AUDIO);}catch(Exception e){
            if(webFileResult!=null){webFileResult.onReceiveValue(null);webFileResult=null;}
            alert("Seletor de músicas",e.toString());
        }
    }
    @Override protected void onActivityResult(int request,int result,Intent data){
        super.onActivityResult(request,result,data);
        if(request==SAVE_MASTER){
            if(result==RESULT_OK&&data!=null&&data.getData()!=null){
                Uri out=data.getData();
                new Thread(()->{
                    String path=getSharedPreferences("aura",MODE_PRIVATE).getString("lastMaster","");
                    try(java.io.InputStream in=new java.io.FileInputStream(new File(path));
                        java.io.OutputStream dest=getContentResolver().openOutputStream(out)){
                        if(dest==null)throw new java.io.IOException("Não foi possível salvar o master");
                        byte[] block=new byte[65536];int n;
                        while((n=in.read(block))>=0)dest.write(block,0,n);
                        status("Master WAV salvo no destino escolhido.");
                    }catch(Exception e){status("Não foi possível exportar o master: "+e);}
                },"AURA-master-export").start();
            }
            return;
        }
        if(request!=PICK_AUDIO)return;
        ArrayList<Uri> list=new ArrayList<>();
        if(result==RESULT_OK && data!=null){
            ClipData clip=data.getClipData();
            if(clip!=null){for(int i=0;i<clip.getItemCount();i++)list.add(clip.getItemAt(i).getUri());}
            else if(data.getData()!=null)list.add(data.getData());
        }
        if(nativeFileSelect && !list.isEmpty()){
            musicUris.clear();musicUris.addAll(list);
            for(Uri u:list)try{getContentResolver().takePersistableUriPermission(u,Intent.FLAG_GRANT_READ_URI_PERMISSION);}catch(Exception ignored){}
            preparedStyle=0;preparedBeats=16;ready.clear();
            status("Músicas selecionadas: "+list.size()+". O DJ nativo está pronto para preparar.");
        }
        if(webFileResult!=null){webFileResult.onReceiveValue(list.isEmpty()?null:list.toArray(new Uri[0]));webFileResult=null;}
        nativeFileSelect=false;
    }
    private String trackName(Uri uri){
        try(android.database.Cursor c=getContentResolver().query(uri,new String[]{OpenableColumns.DISPLAY_NAME},null,null,null)){
            if(c!=null&&c.moveToFirst())return c.getString(0);
        }catch(Exception ignored){}
        return uri.getLastPathSegment()==null?"Música":uri.getLastPathSegment();
    }
    private void status(String s){getSharedPreferences("aura",MODE_PRIVATE).edit().putString("status",s).apply();}
    private String status(){return getSharedPreferences("aura",MODE_PRIVATE).getString("status","AURA Android nativo pronto");}
    private void alert(String title,String msg){main.post(()->new AlertDialog.Builder(this).setTitle(title).setMessage(msg).setPositiveButton("OK",null).show());}
    private void startNative(String style,String beats){
        if(preparing){status("Preparação em andamento…");return;}
        if(musicUris.isEmpty()){
            status("Importe músicas usando + Músicas antes de iniciar o motor Android.");return;
        }
        preparedStyle=styleIndex(style);
        try{preparedBeats=Integer.parseInt(beats);}catch(Exception ex){preparedBeats=16;}
        if(ready.size()==musicUris.size()){
            begin();return;
        }
        preparing=true;status("Analisando "+musicUris.size()+" músicas no motor Android…");
        ArrayList<Uri> selected=new ArrayList<>(musicUris);
        new Thread(()->prepare(selected),"AURA9-native-preparation").start();
    }
    private int styleIndex(String s){
        switch(s){
            case "smooth":return 1;case "linear":return 2;case "s-curve":return 3;
            case "focus":return 4;case "dj":return 5;case "early":return 6;case "late":return 7;
            default:return 0;
        }
    }
    private void prepare(List<Uri> list){
        ArrayList<TrackData> tmp=new ArrayList<>();
        StringBuilder failures=new StringBuilder();
        try{
            File dir=new File(getFilesDir(),"tracks-native");dir.mkdirs();
            for(int i=0;i<list.size();i++){
                Uri u=list.get(i);
                String name=trackName(u);int seq=i+1;
                status("Android DSP "+seq+"/"+list.size()+": "+name);
                try{
                    File file=new File(dir,String.format(Locale.ROOT,"mix-%04d.pcm",i));
                    AudioDecoder.Result decoded=AudioDecoder.decode(this,u,file,null);
                    BeatAnalyzer.Result head=BeatAnalyzer.analyze(file,decoded.sampleRate);
                    double tailStart=Math.max(0,decoded.frames/(double)decoded.sampleRate-44);
                    BeatAnalyzer.Result tail=BeatAnalyzer.analyzeRange(file,decoded.sampleRate,tailStart,42);
                    tmp.add(new TrackData(name,file,decoded.sampleRate,decoded.frames,
                           head.bpm,head.confidence,head.phase,head.rms,
                           tail.bpm,tail.confidence,tail.phase,tailStart,
                           BeatAnalyzer.firstAudible(file,decoded.sampleRate)));
                }catch(Throwable e){failures.append(name).append(": ").append(e.getMessage()).append("; ");Log.w(TAG,"Decode/analysis failed",e);}
            }
            List<TrackData> ordered=TrackPlanner.order(tmp);
            synchronized(ready){ready.clear();ready.addAll(ordered);}
            if(ready.size()>0){
                status("Análise Android: "+ready.size()+"/"+list.size()+". "+(failures.length()>0?failures:"Iniciando DJ."));
                begin();
            }else{status("Nenhuma música decodificada: "+failures);}
        }catch(Throwable t){status("Falha de preparação: "+t);Log.e(TAG,"Native preparation",t);}
        finally{preparing=false;}
    }
    private void begin(){
        try{
            List<TrackData> list;
            synchronized(ready){list=new ArrayList<>(ready);}
            if(list.isEmpty())return;
            SessionStore.save(this,list,preparedStyle,preparedBeats);
            Intent s=new Intent(this,AudioService.class);s.setAction(AudioService.START);
            if(Build.VERSION.SDK_INT>=26)startForegroundService(s);else startService(s);
            status("Iniciando mixagem AURA nativa…");
        }catch(Exception e){status("Falha ao iniciar: "+e);Log.e(TAG,"Start failed",e);}
    }
    private void stopNative(){Intent s=new Intent(this,AudioService.class);s.setAction(AudioService.STOP);startService(s);status("AURA Android: reprodução parada.");}
    private void pauseNative(){Intent s=new Intent(this,AudioService.class);s.setAction(AudioService.PAUSE);startService(s);}
    private void resumeNative(){Intent s=new Intent(this,AudioService.class);s.setAction(AudioService.RESUME);startService(s);}
    private void nextNative(){Intent s=new Intent(this,AudioService.class);s.setAction(AudioService.NEXT);startService(s);}
    private void toggleRecord(boolean requested){
        getSharedPreferences("aura",MODE_PRIVATE).edit().putBoolean("recordRequested",requested).apply();
        Intent s=new Intent(this,AudioService.class);
        s.setAction(requested?AudioService.RECORD:AudioService.RECORD_OFF);
        startService(s);
        status(requested?"Gravação WAV solicitada":"Gravação WAV interrompida");
    }
    private void exportMaster(){
        String path=getSharedPreferences("aura",MODE_PRIVATE).getString("lastMaster","");
        if(path.isEmpty()||!new File(path).exists()){alert("Master WAV","Nenhum master foi gravado ainda.");return;}
        Intent i=new Intent(Intent.ACTION_CREATE_DOCUMENT);
        i.addCategory(Intent.CATEGORY_OPENABLE);i.setType("audio/wav");
        i.putExtra(Intent.EXTRA_TITLE,"Edgard-AURA-Master.wav");
        startActivityForResult(i,SAVE_MASTER);
    }
    private void diagnostics(){
        String info="AURA 9 · Android "+Build.VERSION.RELEASE+" (SDK "+Build.VERSION.SDK_INT+")\n"+
         "Faixas selecionadas: "+musicUris.size()+"\nAnalisadas: "+ready.size()+"\n"+
         "Status: "+status()+"\nÚltima exceção: "+getSharedPreferences("aura",MODE_PRIVATE).getString("lastCrash","nenhuma");
        main.post(()->new AlertDialog.Builder(this).setTitle("AURA Diagnóstico Android").setMessage(info)
         .setPositiveButton("Copiar",(d,w)->{
             ClipboardManager c=(ClipboardManager)getSystemService(CLIPBOARD_SERVICE);
             if(c!=null)c.setPrimaryClip(ClipData.newPlainText("AURA Android diagnóstico",info));
         }).setNegativeButton("Fechar",null).show());
    }
    public final class Bridge {
        @JavascriptInterface public void start(String style,String beats){main.post(()->startNative(style,beats));}
        @JavascriptInterface public void stop(){main.post(()->stopNative());}
        @JavascriptInterface public void pause(){main.post(()->pauseNative());}
        @JavascriptInterface public void resume(){main.post(()->resumeNative());}
        @JavascriptInterface public void next(){main.post(()->nextNative());}
        @JavascriptInterface public void diagnostic(){diagnostics();}
        @JavascriptInterface public void record(boolean enabled){main.post(()->toggleRecord(enabled));}
        @JavascriptInterface public void saveMaster(){main.post(()->exportMaster());}
        @JavascriptInterface public String status(){return MainActivity.this.status();}
        @JavascriptInterface public int count(){return musicUris.size();}
        @JavascriptInterface public boolean busy(){return preparing;}
    }
    @Override public void onBackPressed(){if(web!=null&&web.canGoBack()){web.goBack();}else super.onBackPressed();}
    @Override protected void onDestroy(){if(web!=null){web.removeJavascriptInterface("AURA_ANDROID");web.destroy();web=null;}super.onDestroy();}
}
