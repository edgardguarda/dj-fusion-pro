package app.djfusion.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import app.djfusion.ui.theme.Metal

/**
 * EFEITOS: tudo de efeito num lugar só, um painel por deck.
 * Em cima, os efeitos contínuos (eco no ritmo, flanger, reverb, filtro) com a quantidade;
 * embaixo, os efeitos de performance que agem sozinhos no tempo da música (echo out, filtro automático,
 * freio e volta do disco).
 */
@Composable
fun FxScreen(vm: AppViewModel) {
    val decks by vm.decks.collectAsStateWithLifecycle()
    Row(Modifier.fillMaxSize().background(Metal.Bg).padding(10.dp), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
        FxDeckPanel(vm, 0, decks[0], Modifier.weight(1f).fillMaxHeight())
        AutoDjPanel(vm, Modifier.width(230.dp).fillMaxHeight())
        FxDeckPanel(vm, 1, decks[1], Modifier.weight(1f).fillMaxHeight())
    }
}

/** Ajustes das transições do AUTO DJ: estilo, duração e ajuste automático de tom. */
@Composable
private fun AutoDjPanel(vm: AppViewModel, modifier: Modifier) {
    val style by vm.autoDj.styleChoice.collectAsStateWithLifecycle()
    val beats by vm.autoDj.beatsChoice.collectAsStateWithLifecycle()
    val autoKey by vm.autoDj.autoKey.collectAsStateWithLifecycle()
    val keepTempo by vm.autoDj.keepTempo.collectAsStateWithLifecycle()
    val auto by vm.autoDj.state.collectAsStateWithLifecycle()
    val setOrder by vm.setOrder.collectAsStateWithLifecycle()
    val tracks by vm.tracks.collectAsStateWithLifecycle()
    val decks by vm.decks.collectAsStateWithLifecycle()
    Column(
        modifier.brushedBlack().padding(10.dp).verticalScroll(rememberScrollState()),
        verticalArrangement = Arrangement.spacedBy(6.dp),
    ) {
        Text("AUTO DJ · TRANSIÇÕES", color = Metal.Text, fontSize = 12.sp, fontWeight = FontWeight.ExtraBold, letterSpacing = 1.sp)
        Row(Modifier.fillMaxWidth().height(44.dp), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            MetalButton(if (auto.active) "Parar o AUTO DJ" else "Ligar o AUTO DJ", { vm.autoDj.toggle() }, led = Metal.Success, ledOn = auto.active, modifier = Modifier.weight(1f).fillMaxHeight()) {
                Text(if (auto.active) "PARAR" else "LIGAR", color = Metal.OnMetal, fontSize = 12.sp, fontWeight = FontWeight.ExtraBold, modifier = Modifier.align(Alignment.Center))
            }
            MetalButton("Mixar agora: AUTO DJ começa a transição no próximo compasso", { vm.autoDj.mixNow() }, enabled = auto.active, modifier = Modifier.weight(1.4f).fillMaxHeight()) {
                Text("MIXAR AGORA", color = Metal.OnMetal, fontSize = 11.sp, fontWeight = FontWeight.ExtraBold, maxLines = 1, modifier = Modifier.align(Alignment.Center))
            }
        }
        if (auto.status.isNotEmpty()) Text(auto.status, color = Metal.Success, fontSize = 10.sp, maxLines = 3)
        // próximas da lista (ordem do set / playlist)
        val playingId = decks.firstOrNull { it.playing }?.trackId
        val idx = setOrder.indexOf(playingId)
        val nextIds = if (setOrder.isEmpty()) emptyList() else (1..minOf(4, setOrder.size)).map { setOrder[(idx + it).mod(setOrder.size)] }.filter { it != playingId }.distinct()
        if (nextIds.isNotEmpty()) {
            Text("PRÓXIMAS DA LISTA", color = Metal.TextMuted, fontSize = 10.sp, fontWeight = FontWeight.Bold)
            val byId = tracks.associateBy { it.id }
            nextIds.forEachIndexed { i, id ->
                Text("${i + 1}. ${byId[id]?.title ?: "—"}", color = Metal.Text, fontSize = 11.sp, maxLines = 1, overflow = androidx.compose.ui.text.style.TextOverflow.Ellipsis)
            }
        } else {
            Text("Sem lista: o AUTO DJ escolhe a melhor próxima pela harmonia. Use HARMONIZAR ou uma playlist para fixar a ordem.", color = Metal.TextMuted, fontSize = 10.sp)
        }
        Text("ESTILO", color = Metal.TextMuted, fontSize = 10.sp, fontWeight = FontWeight.Bold)
        val styles = listOf("INTELIGENTE", "GRAVES (EQ)", "FILTRO", "ECO", "STEMS (VOZES)", "CORTE SECO", "FADE", "SEM MIXAGEM")
        for (row in styles.indices.chunked(2)) {
            Row(Modifier.fillMaxWidth().height(36.dp), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                for (i in row) {
                    MetalButton("Transição do AUTO DJ: ${styles[i]}", { vm.autoDj.setStyleChoice(i) }, led = Metal.Success, ledOn = style == i, modifier = Modifier.weight(1f).fillMaxHeight()) {
                        Text(styles[i], color = Metal.OnMetal, fontSize = 9.sp, fontWeight = FontWeight.ExtraBold, maxLines = 1, modifier = Modifier.align(Alignment.Center))
                    }
                }
            }
        }
        Text("DURAÇÃO (batidas)", color = Metal.TextMuted, fontSize = 10.sp, fontWeight = FontWeight.Bold)
        Row(Modifier.fillMaxWidth().height(36.dp), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            for ((label, v) in listOf("AUTO" to 0, "8" to 8, "16" to 16, "32" to 32)) {
                MetalButton("Duração da transição do AUTO DJ: $label", { vm.autoDj.setBeatsChoice(v) }, led = Metal.Success, ledOn = beats == v, modifier = Modifier.weight(1f).fillMaxHeight()) {
                    Text(label, color = Metal.OnMetal, fontSize = 11.sp, fontWeight = FontWeight.ExtraBold, maxLines = 1, modifier = Modifier.align(Alignment.Center))
                }
            }
        }
        MetalButton("AUTO DJ ajusta o tom da música que entra quando os tons chocam", { vm.autoDj.toggleAutoKey() }, led = Metal.Success, ledOn = autoKey, modifier = Modifier.fillMaxWidth().height(40.dp)) {
            Text("TOM AUTOMÁTICO: ${if (autoKey) "LIGADO" else "DESLIGADO"}", color = Metal.OnMetal, fontSize = 10.sp, fontWeight = FontWeight.ExtraBold, maxLines = 1, modifier = Modifier.align(Alignment.Center))
        }
        MetalButton("AUTO DJ mantém o andamento entre as músicas", { vm.autoDj.toggleKeepTempo() }, led = Metal.Success, ledOn = keepTempo, modifier = Modifier.fillMaxWidth().height(40.dp)) {
            Text(if (keepTempo) "ANDAMENTO: MANTÉM" else "ANDAMENTO: VOLTA A 0%", color = Metal.OnMetal, fontSize = 10.sp, fontWeight = FontWeight.ExtraBold, maxLines = 1, modifier = Modifier.align(Alignment.Center))
        }
        val em by vm.autoDj.energyMode.collectAsStateWithLifecycle()
        Text("CURVA DE ENERGIA DA NOITE", color = Metal.TextMuted, fontSize = 10.sp, fontWeight = FontWeight.Bold)
        Row(Modifier.fillMaxWidth().height(36.dp), horizontalArrangement = Arrangement.spacedBy(4.dp)) {
            for ((label, v) in listOf("LIVRE" to 0, "AQUECER" to 1, "ONDAS" to 2, "FECHAR" to 3)) {
                MetalButton("Curva de energia do AUTO DJ: $label", { vm.autoDj.setEnergyMode(v) }, led = Metal.Success, ledOn = em == v, modifier = Modifier.weight(1f).fillMaxHeight()) {
                    Text(label, color = Metal.OnMetal, fontSize = 9.sp, fontWeight = FontWeight.ExtraBold, maxLines = 1, softWrap = false, modifier = Modifier.align(Alignment.Center))
                }
            }
        }
        Text("Pontos de mixagem: hot cue 7 = onde a música ENTRA, hot cue 8 = onde ela SAI. O AUTO DJ respeita os seus pontos.", color = Metal.TextMuted, fontSize = 10.sp)
        Text(
            "Inteligente escolhe pela compatibilidade de tom, andamento, energia e stems e mixa do fim musical de uma " +
                "(sem fade-out nem silêncio) para depois da introdução da outra. Em toda mixagem a batida fica travada.",
            color = Metal.TextMuted, fontSize = 10.sp,
        )
    }
}

@Composable
private fun FxDeckPanel(vm: AppViewModel, deck: Int, ui: DeckUi, modifier: Modifier) {
    val name = AppViewModel.deckName(deck)
    val color = deckColor(deck)
    Column(modifier.brushedSilver().padding(10.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text("DECK $name", color = color, fontSize = 18.sp, fontWeight = FontWeight.ExtraBold)
            Text(
                if (ui.loaded) "  ${ui.title}" else "  vazio",
                color = Color(0xFF9AA4AE), fontSize = 12.sp, maxLines = 1, modifier = Modifier.weight(1f),
            )
            if (ui.hasBpm) Text(String.format(java.util.Locale.ROOT, "%.1f BPM", ui.playedBpm), color = Color(0xFF9AA4AE), fontSize = 12.sp, fontWeight = FontWeight.Bold)
        }
        Text("EFEITOS (no ritmo da música) · até 3 juntos: escolha o encaixe e depois o efeito", color = Color(0xFF9AA4AE), fontSize = 10.sp, fontWeight = FontWeight.Bold, letterSpacing = 1.sp)
        Row(Modifier.fillMaxWidth().height(40.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            for (slot in 0..2) {
                val t = ui.fxTypeAt(slot)
                MetalButton(
                    description = "Encaixe FX${slot + 1} do deck $name (tela de efeitos)",
                    onPress = { vm.setFxSlot(deck, slot) },
                    led = color, ledOn = ui.fxSel == slot,
                    modifier = Modifier.weight(1f).fillMaxHeight(),
                ) {
                    Text(
                        "FX${slot + 1}: " + (if (t > 0) FX_NAMES[t - 1] else "—") + (if (t > 0) " ${Math.round(ui.fxAmountAt(slot) * 100)}%" else ""),
                        color = if (ui.fxSel == slot) color else Metal.OnMetal, fontSize = 11.sp, fontWeight = FontWeight.ExtraBold, maxLines = 1, softWrap = false,
                    )
                }
            }
            MetalButton(
                description = "Desligar os 3 efeitos do deck $name",
                onPress = { vm.clearFx(deck) },
                modifier = Modifier.weight(0.7f).fillMaxHeight(),
            ) { Text("DESLIGA", color = Metal.OnMetal, fontSize = 11.sp, fontWeight = FontWeight.ExtraBold, maxLines = 1) }
        }
        for (row in 0..1) Row(Modifier.fillMaxWidth().height(46.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            val names = FX_NAMES
            for (t in (row * 4 + 1)..minOf(FX_NAMES.size, row * 4 + 4)) {
                MetalButton(
                    description = "Efeito ${names[t - 1]} do deck $name (tela de efeitos). Toque de novo para desligar.",
                    onPress = { vm.setFx(deck, t) },
                    led = color, ledOn = ui.fxSlotOf(t) >= 0,
                    modifier = Modifier.weight(1f).fillMaxHeight(),
                ) {
                    Text(names[t - 1], color = if (ui.fxSlotOf(t) == ui.fxSel) color else if (ui.fxSlotOf(t) >= 0) color.copy(alpha = 0.6f) else Metal.OnMetal, fontSize = 11.sp, fontWeight = FontWeight.ExtraBold, maxLines = 1, softWrap = false)
                }
            }
        }
        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            Column(Modifier.weight(1f)) {
                Text("QUANTIDADE", color = Color(0xFF9AA4AE), fontSize = 10.sp, fontWeight = FontWeight.Bold)
                MetalFader(
                    value = ui.selFxAmount, onChange = { vm.setFxAmount(deck, it) }, accent = color, fill = true,
                    description = "Quantidade do efeito do deck $name (tela de efeitos)",
                    modifier = Modifier.fillMaxWidth().height(40.dp), vertical = false,
                )
            }
            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                Knob(
                    value = ui.filter, onChange = { vm.setFilter(deck, it) }, accent = color,
                    description = "Filtro do deck $name (tela de efeitos). Esquerda corta os agudos, direita corta os graves. Toque duplo zera.",
                    modifier = Modifier.size(58.dp),
                )
                Text("FILTRO", color = Color(0xFF9AA4AE), fontSize = 10.sp, fontWeight = FontWeight.Bold)
            }
        }
        Text("PERFORMANCE (age sozinho, no tempo da música)", color = Color(0xFF9AA4AE), fontSize = 10.sp, fontWeight = FontWeight.Bold, letterSpacing = 1.sp)
        Row(Modifier.fillMaxWidth().weight(1f), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            PerfButton("ECHO OUT", "sai com eco em 2 compassos", "Echo out do deck $name: a música sai com eco no ritmo e para", color) { vm.echoOut(deck) }
            PerfButton("FILTRO AUTO", "sobe e volta em 4 compassos", "Filtro automático do deck $name: sobe e volta em 4 compassos", color) { vm.filterSweep(deck) }
        }
        Row(Modifier.fillMaxWidth().weight(1f), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            PerfButton("FREIO", "o disco para devagar", "Freio do deck $name: o disco desacelera até parar", color) { vm.brake(deck) }
            PerfButton("VOLTA", "o disco volta rápido", "Volta do deck $name: o disco gira para trás e para", color) { vm.spinback(deck) }
        }
    }
}

@Composable
private fun androidx.compose.foundation.layout.RowScope.PerfButton(
    label: String, hint: String, description: String, color: Color, onPress: () -> Unit,
) {
    MetalButton(
        description = description, onPress = onPress, led = color, ledOn = false,
        modifier = Modifier.weight(1f).fillMaxHeight(),
    ) {
        Column(horizontalAlignment = Alignment.CenterHorizontally, modifier = Modifier.align(Alignment.Center)) {
            Text(label, color = Metal.OnMetal, fontSize = 15.sp, fontWeight = FontWeight.ExtraBold, maxLines = 1)
            Text(hint, color = Color(0xFF9AA4AE), fontSize = 10.sp, textAlign = TextAlign.Center, maxLines = 1)
        }
    }
}
