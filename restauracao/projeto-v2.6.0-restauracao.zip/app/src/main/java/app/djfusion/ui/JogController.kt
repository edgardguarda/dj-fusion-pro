package app.djfusion.ui

import android.content.SharedPreferences
import android.os.Handler
import android.os.Looper
import app.djfusion.audio.NativeEngine
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

/**
 * Jog wheel de controladoras, sem atraso: cada passo girado vira deslocamento exato da música no motor
 * (o motor leva a agulha até lá em ~10 ms), em vez de estimar velocidade pelo tempo entre mensagens.
 * - dedo no prato (com VINIL) ou deck parado: scratch, a música vai e volta exatamente com a mão e para quando ela para;
 * - tocando sem encostar (ou VINIL desligado): empurrão, adianta/atrasa a batida proporcional ao giro;
 * - BUSCA: o prato corre a música 20 vezes mais rápido, sem som (achar um ponto numa música longa).
 * Chamado direto da linha de MIDI (não espera a tela): só usa o motor e valores lidos de StateFlow.
 */
class JogController(
    private val prefs: SharedPreferences,
    private val vm: AppViewModel,
    @Suppress("UNUSED_PARAMETER") scope: CoroutineScope,
) {
    @Volatile var ticksPerRev: Int = prefs.getInt("tpr", 128).coerceIn(32, 4096)
        private set

    /** Força do empurrão (girar a borda com a música tocando): 0,25 a 3 (1 = normal: uma volta = 0,3 s). */
    @Volatile var bendGain: Float = prefs.getFloat("bend", 1f).coerceIn(0.25f, 3f)
        private set

    fun setBendGain(v: Float) {
        bendGain = v.coerceIn(0.25f, 3f)
        prefs.edit().putFloat("bend", bendGain).apply()
    }

    fun setTicksPerRev(v: Int) {
        ticksPerRev = v.coerceIn(32, 4096)
        prefs.edit().putInt("tpr", ticksPerRev).apply()
    }

    private val main = Handler(Looper.getMainLooper())

    private class State {
        @Volatile var touching = false
        @Volatile var scratching = false
        @Volatile var searchTarget = -1L
        @Volatile var searchAt = 0L
        var releaser: Runnable? = null
    }

    private val st = arrayOf(State(), State())

    // ------------------------------------------------------------ BUSCA

    private val _search = MutableStateFlow(listOf(false, false))
    /** Modo BUSCA de cada deck: o prato corre a música rápido, sem som. */
    val search: StateFlow<List<Boolean>> = _search.asStateFlow()
    fun setSearch(deck: Int, on: Boolean) {
        if (deck !in 0..1) return
        _search.value = _search.value.mapIndexed { i, v -> if (i == deck) on else v }
    }

    // ------------------------------------------------------------ calibração (passos por volta)

    @Volatile private var calibDeck = -1
    @Volatile private var calibSum = 0
    private val _calib = MutableStateFlow(-1)
    /** Passos contados na calibração em andamento (-1 = sem calibração). */
    val calibration: StateFlow<Int> = _calib.asStateFlow()
    fun startCalibration(deck: Int) { calibSum = 0; calibDeck = deck; _calib.value = 0 }
    fun cancelCalibration() { calibDeck = -1; _calib.value = -1 }
    /** Termina a calibração: o total de passos de uma volta vira o novo valor. Retorna o valor ou -1. */
    fun finishCalibration(): Int {
        val n = calibSum
        calibDeck = -1
        _calib.value = -1
        if (n < 32) return -1
        setTicksPerRev(n)
        return n
    }

    // ------------------------------------------------------------ giro e toque

    /** Quadros da música por passo do prato (uma volta = 1,8 s, como um disco de 33⅓ rpm). */
    private fun framesPerTick(): Double = NativeEngine.SAMPLE_RATE * 1.8 / ticksPerRev

    /** Passos girados (positivo = para frente). Pode ser chamado de qualquer linha. */
    fun tick(deck: Int, ticks: Int) {
        if (deck !in 0..1 || ticks == 0) return
        if (calibDeck == deck) { calibSum += kotlin.math.abs(ticks); _calib.value = calibSum; return }
        val d = vm.decks.value[deck]
        if (!d.loaded || d.loading) return
        val s = st[deck]
        val frames = ticks * framesPerTick()
        when {
            _search.value[deck] -> {
                // giro contínuo soma no alvo anterior (o motor ainda pode não ter chegado lá); parado 200 ms, recomeça da posição
                val now = android.os.SystemClock.uptimeMillis()
                val base = if (now - s.searchAt < 200 && s.searchTarget >= 0) s.searchTarget else {
                    val buf = LongArray(4)
                    NativeEngine.nativeDeckState(deck, buf)
                    buf[1]
                }
                val target = (base + frames * 20).toLong().coerceIn(0L, (d.lengthFrames - 1).coerceAtLeast(0L))
                s.searchTarget = target
                s.searchAt = now
                NativeEngine.nativeSeek(deck, target)
            }
            (s.touching && vm.vinyl.value) || !d.playing -> {
                if (!s.scratching) {
                    s.scratching = true
                    main.post { vm.jogScratchBegin(deck) }
                }
                NativeEngine.nativeScratchMove(deck, frames)
                // controladora sem sensor de toque: solta o disco 120 ms depois do último passo
                if (!s.touching) scheduleRelease(deck, 120)
            }
            else -> NativeEngine.nativeNudge(deck, frames * (0.3 / 1.8) * bendGain)
        }
    }

    private fun scheduleRelease(deck: Int, ms: Long) {
        val s = st[deck]
        s.releaser?.let { main.removeCallbacks(it) }
        val r = Runnable {
            if (!s.touching && s.scratching) {
                s.scratching = false
                vm.jogScratchEnd(deck)
            }
        }
        s.releaser = r
        main.postDelayed(r, ms)
    }

    /** Dedo encostou (true) ou saiu (false) do prato. Pode ser chamado de qualquer linha. */
    fun touch(deck: Int, on: Boolean) {
        if (deck !in 0..1) return
        val s = st[deck]
        s.touching = on
        if (on) {
            val d = vm.decks.value[deck]
            if (d.loaded && !d.loading && !_search.value[deck] && (vm.vinyl.value || !d.playing)) {
                // segura o disco: a agulha para onde está (como a mão num vinil)
                if (!s.scratching) {
                    s.scratching = true
                    main.post { vm.jogScratchBegin(deck) }
                }
                NativeEngine.nativeScratchMove(deck, 0.0)
            }
        } else if (s.scratching) {
            s.releaser?.let { main.removeCallbacks(it) }
            s.scratching = false
            main.post { vm.jogScratchEnd(deck) }
            NativeEngine.nativeScratch(deck, false, 0f)
        }
    }
}
