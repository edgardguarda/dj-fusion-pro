package app.djfusion.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.gestures.detectHorizontalDragGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.State
import androidx.compose.runtime.getValue
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.onClick
import androidx.compose.ui.semantics.role
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import app.djfusion.harmony.MusicalKey
import app.djfusion.ui.theme.Metal
import kotlin.math.min

internal fun deckColor(deck: Int): Color = if (deck == 0) Metal.DeckA else Metal.DeckB
private fun onDeckColor(deck: Int): Color = if (deck == 0) Metal.OnDeckA else Metal.OnDeckB

private val Engraving = Color(0xFF8C949D)
private val TRANSPORT_HEIGHT = 52.dp

/**
 * Tela DJ Live. Duas ondas rolantes no alto e, embaixo, os dois decks grandes com a mesa no meio.
 * Cada deck: fader de tempo, prato (ou pads) e coluna de informação; a fileira de transporte fica embaixo,
 * alinhada com o crossfader. A posição e o nível mudam 30 vezes por segundo e só são lidos nos pontos
 * que os desenham, para o resto da tela não ser recomposto.
 */
@Composable
fun DjLiveScreen(vm: AppViewModel) {
    val decks by vm.decks.collectAsStateWithLifecycle()
    val live = vm.live.collectAsStateWithLifecycle()
    Column(Modifier.fillMaxSize().background(Metal.Bg)) {
        WaveBlock(vm, 0, decks[0], live)
        Spacer(Modifier.height(2.dp))
        WaveBlock(vm, 1, decks[1], live)
        Spacer(Modifier.height(2.dp))
        val dock by vm.browserDock.collectAsStateWithLifecycle()
        Box(Modifier.fillMaxWidth().weight(1f)) {
            Row(Modifier.fillMaxSize()) {
                DeckPanel(vm, 0, decks[0], decks[1].shownKey, live, Modifier.weight(1f).fillMaxHeight())
                MixerPanel(vm, live, Modifier.width(224.dp).fillMaxHeight())
                DeckPanel(vm, 1, decks[1], decks[0].shownKey, live, Modifier.weight(1f).fillMaxHeight())
            }
            if (dock) {
                BrowserDock(
                    vm,
                    Modifier.align(Alignment.BottomCenter).fillMaxWidth().fillMaxHeight(0.62f)
                        .border(1.dp, Metal.DeckA.copy(alpha = 0.6f), RoundedCornerShape(topStart = 8.dp, topEnd = 8.dp))
                        .clip(RoundedCornerShape(topStart = 8.dp, topEnd = 8.dp)),
                )
            }
        }
    }
}

private fun emptyHint(vm: AppViewModel, deck: Int): () -> Unit = {
    val n = AppViewModel.deckName(deck)
    if (vm.decks.value[deck].loading) vm.say("Espere a música terminar de carregar no deck $n.")
    else vm.say("Deck $n sem música. Abra a BIBLIOTECA e toque no botão $n de uma faixa.")
}

@Composable
private fun WaveBlock(vm: AppViewModel, deck: Int, ui: DeckUi, live: State<LiveUi>) {
    val loops by vm.loopRegion.collectAsStateWithLifecycle()
    val loopRegion = loops[deck]
    val zoom by vm.waveZoom.collectAsStateWithLifecycle()
    val zoomSec = AppViewModel.WAVE_ZOOMS[zoom]
    val name = AppViewModel.deckName(deck)
    val color = deckColor(deck)
    Column(Modifier.fillMaxWidth().height(56.dp)) {
        Box(Modifier.fillMaxWidth().weight(1f)) {
            ScrollingWave(
                peaks = ui.wave,
                position = { live.value.decks[deck].positionFrames },
                bpm = if (ui.hasBpm) ui.bpm else 0.0,
                firstBeatFrame = ui.firstBeatFrame,
                hotcues = ui.hotcues, cueNames = ui.hotcueNames,
                cue = { live.value.decks[deck].cueFrames },
                deckColor = color,
                viewSeconds = zoomSec,
                ghost = { ghostBeats(vm, deck, live) },
                loop = loopRegion,
                modifier = Modifier.fillMaxSize()
                    .semantics { contentDescription = "Onda do deck $name: arraste para procurar (parado) ou empurrar a batida (tocando); toque duplo muda o zoom" }
                    .pointerInput(Unit) { detectTapGestures(onDoubleTap = { vm.cycleWaveZoom() }) }
                    .pointerInput(deck, zoomSec) {
                        // arrastar a onda: parado procura o ponto exato; tocando empurra/segura a batida (como no Serato)
                        detectHorizontalDragGestures { change, dx ->
                            change.consume()
                            val frames = -dx * 48000.0 * zoomSec / size.width
                            if (vm.decks.value[deck].playing) vm.nudge(deck, frames * 0.25) else vm.scrubBy(deck, frames.toLong())
                        }
                    },
            )
            Row(
                Modifier.align(Alignment.TopStart).padding(4.dp),
                verticalAlignment = Alignment.CenterVertically,
            ) {
                Box(
                    Modifier.size(22.dp).clip(RoundedCornerShape(5.dp)).background(color),
                    contentAlignment = Alignment.Center,
                ) {
                    Text(name, color = onDeckColor(deck), fontSize = 13.sp, fontWeight = FontWeight.ExtraBold)
                }
                Box(
                    Modifier.padding(start = 6.dp).clip(RoundedCornerShape(5.dp)).background(Color(0xFF2A2F35))
                        .semantics { contentDescription = "Carregar música no deck $name"; role = Role.Button; onClick { vm.openBrowser(deck); true } }
                        .pointerInput(Unit) { detectTapGestures(onTap = { vm.openBrowser(deck) }) }
                        .padding(horizontal = 8.dp, vertical = 2.dp),
                ) {
                    Text("♪ CARREGAR", color = Metal.Text, fontSize = 11.sp, fontWeight = FontWeight.ExtraBold, maxLines = 1)
                }
                if (deck == 0) {
                    val dockOn by vm.browserDock.collectAsStateWithLifecycle()
                    val q by vm.quantize.collectAsStateWithLifecycle()
                    TopChip(if (dockOn) "☰ LISTA ✓" else "☰ LISTA", dockOn, "Mostrar ou esconder a lista de músicas fixa") { vm.toggleBrowserDock() }
                    TopChip(if (q) "Q ✓" else "Q", q, "Quantize: cues e loops presos na batida (ligado: $q)") { vm.toggleQuantize() }
                    val vin by vm.vinyl.collectAsStateWithLifecycle()
                    TopChip("VINIL", vin, "Modo vinil (ligado: $vin): tocar no disco faz scratch") { vm.toggleVinyl() }
                    val srch by vm.jog.search.collectAsStateWithLifecycle()
                    val searchOn = srch.any { it }
                    TopChip("BUSCA", searchOn, "Modo BUSCA dos pratos da controladora (ligado: $searchOn): girar corre a música rápido, sem som") {
                        vm.jog.setSearch(0, !searchOn); vm.jog.setSearch(1, !searchOn)
                        vm.say(if (!searchOn) "BUSCA ligada: o prato da controladora corre a música 20 vezes mais rápido." else "BUSCA desligada: o prato volta ao normal.")
                    }
                }
                val overlay = when {
                    ui.loading -> "Carregando… ${(ui.loadProgress * 100).toInt()}%"
                    !ui.loaded -> "Deck $name vazio · toque em CARREGAR"
                    else -> null
                }
                Text(
                    (overlay ?: ui.title) + if (overlay == null && ui.artist.isNotEmpty()) "  ·  ${ui.artist}" else "",
                    color = Metal.Text, fontSize = 12.sp, fontWeight = FontWeight.Bold,
                    maxLines = 1, overflow = TextOverflow.Ellipsis,
                    modifier = Modifier.padding(start = 6.dp)
                        .background(Color(0xAA000000), RoundedCornerShape(4.dp)).padding(horizontal = 6.dp, vertical = 1.dp),
                )
            }
            if (ui.loaded && !ui.loading) {
                RemainingText(live, deck, ui.lengthFrames, Modifier.align(Alignment.TopEnd).padding(4.dp))
            }
        }
        OverviewStrip(
            peaks = ui.wave,
            position = { live.value.decks[deck].positionFrames },
            lengthFrames = ui.lengthFrames,
            deckColor = color,
            description = "Visão geral do deck $name. Toque para ir a outro ponto da música.",
            onSeek = { vm.seekFraction(deck, it) },
            modifier = Modifier.fillMaxWidth().height(14.dp),
            hotcues = ui.hotcues,
            loop = loopRegion,
        )
    }
}

/** Batidas do outro deck projetadas na onda deste (só com os dois andamentos e o outro tocando). */
internal fun ghostBeats(vm: AppViewModel, deck: Int, live: State<LiveUi>): GhostBeats? {
    val all = vm.decks.value
    val me = all[deck]
    val ot = all[1 - deck]
    if (!me.loaded || !me.hasBpm || !ot.loaded || !ot.hasBpm || !ot.playing) return null
    val beat2 = 48000.0 * 60.0 / ot.bpm
    val p2 = live.value.decks[1 - deck].positionFrames
    if (p2 < ot.firstBeatFrame) return null
    val rel = (p2 - ot.firstBeatFrame) / beat2
    val idx = Math.floor(rel).toLong()
    val myPerSec = 48000.0 * me.rate
    val otPerSec = 48000.0 * ot.rate
    return GhostBeats(
        periodFrames = beat2 / otPerSec * myPerSec,
        nextFrames = (idx + 1 - rel) * beat2 / otPerSec * myPerSec,
        nextIndex = idx + 1,
        color = deckColor(1 - deck),
    )
}

@Composable
private fun RemainingText(live: State<LiveUi>, deck: Int, length: Long, modifier: Modifier) {
    val pos = live.value.decks[deck].positionFrames
    Text(
        "-" + formatTimeTenths(framesToMs(length - pos)),
        color = Metal.Text, fontSize = 13.sp, fontFamily = FontFamily.Monospace, fontWeight = FontWeight.Bold,
        modifier = modifier.background(Color(0xAA000000), RoundedCornerShape(4.dp)).padding(horizontal = 6.dp, vertical = 1.dp),
    )
}

@Composable
private fun ElapsedText(live: State<LiveUi>, deck: Int, loaded: Boolean, color: Color, length: Long = 0L) {
    val pos = live.value.decks[deck].positionFrames
    val rem = DisplayPrefs.remaining && length > 0
    Text(
        if (!loaded) "-:--.-" else if (rem) "-" + formatTimeTenths(framesToMs(length - pos)) else formatTimeTenths(framesToMs(pos)),
        color = color, fontSize = 15.sp, fontFamily = FontFamily.Monospace, fontWeight = FontWeight.Bold, maxLines = 1,
        modifier = Modifier
            .semantics { contentDescription = "Tempo do deck: toque para alternar tocado e restante"; role = Role.Button; onClick { DisplayPrefs.remaining = !DisplayPrefs.remaining; true } }
            .pointerInput(Unit) { detectTapGestures(onTap = { DisplayPrefs.remaining = !DisplayPrefs.remaining }) },
    )
}

// ------------------------------------------------------------------------------------- deck

@Composable
private fun DeckPanel(
    vm: AppViewModel, deck: Int, ui: DeckUi, otherKey: MusicalKey?, live: State<LiveUi>, modifier: Modifier,
) {
    val left = deck == 0
    Column(modifier.brushedSilver().padding(horizontal = 6.dp, vertical = 5.dp)) {
        Row(Modifier.fillMaxWidth().weight(1f), verticalAlignment = Alignment.CenterVertically) {
            if (left) {
                TempoColumn(vm, deck, ui)
                PlatterArea(vm, deck, ui, live, Modifier.weight(1f).fillMaxHeight())
                InfoColumn(vm, deck, ui, otherKey, live)
            } else {
                InfoColumn(vm, deck, ui, otherKey, live)
                PlatterArea(vm, deck, ui, live, Modifier.weight(1f).fillMaxHeight())
                TempoColumn(vm, deck, ui)
            }
        }
        Spacer(Modifier.height(5.dp))
        Transport(vm, deck, ui, Modifier.fillMaxWidth().height(TRANSPORT_HEIGHT))
    }
}

@Composable
private fun TempoColumn(vm: AppViewModel, deck: Int, ui: DeckUi) {
    val color = deckColor(deck)
    val name = AppViewModel.deckName(deck)
    Column(Modifier.width(50.dp).fillMaxHeight(), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(2.dp)) {
        // faixa do pitch: toque para trocar (±8, ±16, ±25, ±50, ±100 %)
        SmallChip(if (ui.pitchRange >= 100) "WIDE" else "±${ui.pitchRange}%", "Faixa do pitch do deck $name: ±${ui.pitchRange}%. Toque para trocar.", color) { vm.cyclePitchRange(deck) }
        MetalFader(
            value = vm.pitchFaderValue(ui),
            onChange = { vm.setPitchFader(deck, it) },
            accent = color,
            description = "Tempo do deck $name. Para cima acelera, para baixo desacelera. Meio é a velocidade normal.",
            modifier = Modifier.fillMaxWidth().weight(1f).padding(vertical = 1.dp),
        )
        Text(
            String.format(java.util.Locale.ROOT, "%+.2f%%", (ui.rate - 1f) * 100f),
            color = if (ui.rate == 1f) Engraving else color,
            fontSize = 10.sp, fontFamily = FontFamily.Monospace, fontWeight = FontWeight.Bold, maxLines = 1,
            modifier = Modifier
                .semantics { contentDescription = "Voltar o pitch do deck $name a 0%"; role = Role.Button; onClick { vm.resetPitch(deck); true } }
                .pointerInput(Unit) { detectTapGestures(onDoubleTap = { vm.resetPitch(deck) }, onTap = { vm.resetPitch(deck) }) },
        )
        Row(Modifier.fillMaxWidth().height(26.dp), horizontalArrangement = Arrangement.spacedBy(2.dp)) {
            BendButton("−", "Segurar a música do deck $name (pitch bend para trás)", Modifier.weight(1f)) { on -> vm.pitchBend(deck, -1, on) }
            BendButton("+", "Empurrar a música do deck $name (pitch bend para frente)", Modifier.weight(1f)) { on -> vm.pitchBend(deck, 1, on) }
        }
    }
}

/** Botão que age enquanto está apertado (pitch bend). */
@Composable
private fun BendButton(label: String, description: String, modifier: Modifier, onHold: (Boolean) -> Unit) {
    var down by androidx.compose.runtime.remember { androidx.compose.runtime.mutableStateOf(false) }
    Box(
        modifier.fillMaxHeight().clip(RoundedCornerShape(5.dp))
            .background(if (down) Color(0xFF5A6068) else Color(0xFF2A2F35))
            .semantics { contentDescription = description; role = Role.Button; onClick { onHold(true); onHold(false); true } }
            .pointerInput(Unit) {
                detectTapGestures(onPress = {
                    down = true
                    onHold(true)
                    tryAwaitRelease()
                    onHold(false)
                    down = false
                })
            },
        contentAlignment = Alignment.Center,
    ) { Text(label, color = Metal.Text, fontSize = 15.sp, fontWeight = FontWeight.ExtraBold) }
}

/** Etiqueta pequena tocável (faixa do pitch, divisão do efeito). */
@Composable
private fun SmallChip(label: String, description: String, color: Color, onClick: () -> Unit) {
    Box(
        Modifier.fillMaxWidth().height(20.dp).clip(RoundedCornerShape(5.dp)).background(Color(0xFF16191D))
            .semantics { contentDescription = description; role = Role.Button; onClick { onClick(); true } }
            .pointerInput(Unit) { detectTapGestures(onTap = { onClick() }) },
        contentAlignment = Alignment.Center,
    ) { Text(label, color = color, fontSize = 10.sp, fontWeight = FontWeight.ExtraBold, maxLines = 1) }
}

@Composable
private fun InfoColumn(vm: AppViewModel, deck: Int, ui: DeckUi, otherKey: MusicalKey?, live: State<LiveUi>) {
    val color = deckColor(deck)
    val name = AppViewModel.deckName(deck)
    val ready = ui.loaded && !ui.loading
    val hint = emptyHint(vm, deck)
    Column(
        Modifier.width(92.dp).fillMaxHeight().padding(horizontal = 4.dp),
        verticalArrangement = Arrangement.spacedBy(5.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
    ) {
        // visor: tempo tocado, andamento e tom
        Column(
            Modifier.fillMaxWidth().clip(RoundedCornerShape(6.dp)).background(Color(0xFF0B0C0E))
                .padding(vertical = 4.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
        ) {
            ElapsedText(live, deck, ui.loaded, color, ui.lengthFrames)
            Text(
                when {
                    ready && ui.hasBpm -> String.format(java.util.Locale.ROOT, "%.2f", ui.playedBpm)
                    ready && ui.analyzing -> "…"
                    else -> "---.--"
                },
                color = if (ready && ui.hasBpm) Metal.Text else Color(0xFF4A5056),
                fontSize = 20.sp, fontFamily = FontFamily.Monospace, fontWeight = FontWeight.ExtraBold, maxLines = 1,
            )
            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                val all by vm.decks.collectAsStateWithLifecycle()
                val other = all[1 - deck]
                // diferença de andamento para o outro deck (para acertar no ouvido): verde quando bate
                val delta = if (ready && ui.hasBpm && other.loaded && other.hasBpm && !ui.syncLock) ui.playedBpm - other.playedBpm else null
                Text(
                    when {
                        ui.syncLock -> "SYNC"
                        delta != null -> (if (delta >= 0) "+" else "−") + String.format(java.util.Locale.ROOT, "%.2f", kotlin.math.abs(delta))
                        else -> "BPM"
                    },
                    color = when {
                        ui.syncLock -> color
                        delta != null && kotlin.math.abs(delta) < 0.05 -> Metal.Success
                        delta != null && kotlin.math.abs(delta) < 1.0 -> Metal.Warning
                        delta != null -> Color(0xFFFF6B6B)
                        else -> Metal.TextMuted
                    },
                    fontSize = 9.sp, fontWeight = FontWeight.Bold, maxLines = 1,
                    modifier = Modifier.semantics {
                        contentDescription = if (delta != null) "Diferença de andamento do deck $name para o outro: " + String.format(java.util.Locale.ROOT, "%.2f", delta) + " BPM" else "Andamento do deck $name"
                    },
                )
                KeyChip(
                    ui.shownKey, otherKey, small = true,
                    modifier = Modifier
                        .semantics { contentDescription = "Tom do deck $name: toque para alternar Camelot e letras"; role = Role.Button; onClick { DisplayPrefs.keyLetters = !DisplayPrefs.keyLetters; true } }
                        .pointerInput(Unit) { detectTapGestures(onTap = { DisplayPrefs.keyLetters = !DisplayPrefs.keyLetters }) },
                )
            }
            if (ui.keyShift != 0) {
                Text(
                    "TOM ${if (ui.keyShift > 0) "+" else ""}${ui.keyShift}", color = Metal.Warning,
                    fontSize = 9.sp, fontWeight = FontWeight.ExtraBold, maxLines = 1,
                )
            }
        }
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(4.dp)) {
            SmallTextButton("÷2", "Dividir o andamento detectado do deck $name por 2", Modifier.weight(1f)) {
                if (ready) vm.scaleBpm(deck, 0.5) else hint()
            }
            SmallTextButton("TAP", "Marcar o andamento do deck $name tocando no ritmo (4 toques ou mais)", Modifier.weight(1.2f)) {
                if (ready) vm.tapBpm(deck) else hint()
            }
            SmallTextButton("×2", "Dobrar o andamento detectado do deck $name", Modifier.weight(1f)) {
                if (ready) vm.scaleBpm(deck, 2.0) else hint()
            }
        }
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(4.dp)) {
            SmallTextButton("♭", "Baixar o tom do deck $name meio tom, sem mudar o andamento", Modifier.weight(1f)) {
                if (ready) vm.shiftKey(deck, -1) else hint()
            }
            SmallTextButton("TOM", "Ajustar o tom do deck $name para combinar com o outro deck", Modifier.weight(1.3f)) {
                if (ready) vm.matchKey(deck) else hint()
            }
            SmallTextButton("♯", "Subir o tom do deck $name meio tom, sem mudar o andamento", Modifier.weight(1f)) {
                if (ready) vm.shiftKey(deck, 1) else hint()
            }
        }
        Spacer(Modifier.weight(1f))
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(4.dp)) {
            DeckToggle("KEY", "Key-lock do deck $name. Ligado, mudar o tempo não muda o tom da música.", ui.keyLock, color, Modifier.weight(1f)) {
                vm.toggleKeyLock(deck)
            }
            DeckToggle("SLIP", "Slip do deck $name. Ligado, depois de scratch, loop, reverso ou censura a música volta onde estaria.", ui.slip, color, Modifier.weight(1f)) {
                vm.toggleSlip(deck)
            }
        }
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(4.dp)) {
            DeckToggle(
                "PADS",
                if (ui.padsOpen) "Voltar ao prato do deck $name" else "Abrir pads de hot cue, loop e efeito do deck $name",
                ui.padsOpen, color, Modifier.weight(1f),
            ) { vm.togglePads(deck) }
            DeckToggle(
                "STEMS",
                if (ui.stemsOpen) "Fechar stems do deck $name" else "Abrir stems do deck $name: voz, bateria, baixo e melodia",
                ui.stemsOpen, color, Modifier.weight(1f),
            ) { vm.toggleStems(deck) }
        }
    }
}

@Composable
private fun DeckToggle(label: String, description: String, on: Boolean, color: Color, modifier: Modifier = Modifier.fillMaxWidth(), onPress: () -> Unit) {
    MetalButton(
        description = description, onPress = onPress, led = color, ledOn = on,
        modifier = modifier.height(36.dp),
    ) {
        Text(label, color = if (on) color else Metal.OnMetal, fontSize = 11.sp, fontWeight = FontWeight.ExtraBold, maxLines = 1, softWrap = false)
    }
}

@Composable
private fun PlatterArea(vm: AppViewModel, deck: Int, ui: DeckUi, live: State<LiveUi>, modifier: Modifier) {
    val color = deckColor(deck)
    val name = AppViewModel.deckName(deck)
    val ready = ui.loaded && !ui.loading
    val hint = emptyHint(vm, deck)
    val scratchCb: ((Boolean, Float) -> Unit)? =
        if (ready) ({ active: Boolean, vel: Float -> vm.scratch(deck, active, vel) }) else null
    BoxWithConstraints(modifier, contentAlignment = Alignment.Center) {
        val side = min(maxHeight.value, maxWidth.value).dp
        if (ui.stemsOpen) {
            StemsPanel(vm, deck, ui, Modifier.width(maxWidth.coerceAtMost(side * 1.25f)).fillMaxHeight().padding(vertical = 2.dp))
        } else if (!ui.padsOpen) {
            Platter(
                deckColor = color,
                position = { live.value.decks[deck].positionFrames },
                lengthFrames = { ui.lengthFrames },
                modifier = Modifier.size(side)
                    .semantics { contentDescription = if (ready) "Prato do deck $name. Gire para fazer scratch." else "Prato do deck $name vazio. Toque para carregar uma música." }
                    .then(if (!ui.loaded && !ui.loading) Modifier.pointerInput(Unit) { detectTapGestures(onTap = { vm.openBrowser(deck) }) } else Modifier),
                onScratch = scratchCb,
                onBend = if (ready) ({ active: Boolean, vel: Float -> vm.jogBend(deck, active, vel) }) else null,
                vinyl = { vm.vinyl.value },
                onMove = if (ready) ({ r: Float, rim: Boolean -> vm.platterMove(deck, r, rim) }) else null,
                playing = { vm.decks.value[deck].playing },
                cue = { live.value.decks[deck].cueFrames },
            ) {
                EgMark(Modifier.size(side * 0.30f), ring = false)
                if (ui.stemProgress in 0f..0.999f) {
                    Text(
                        "STEMS ${(ui.stemProgress * 100).toInt()}%", color = Color.White.copy(alpha = 0.8f), fontSize = 10.sp,
                        fontWeight = FontWeight.ExtraBold, modifier = Modifier.align(Alignment.BottomCenter).padding(bottom = side * 0.16f),
                    )
                }
                if (!ui.loaded && !ui.loading) {
                    Text(
                        "toque para carregar", color = Color.White.copy(alpha = 0.75f), fontSize = 11.sp, fontWeight = FontWeight.Bold,
                        modifier = Modifier.align(Alignment.BottomCenter).padding(bottom = side * 0.16f),
                    )
                }
            }
        } else {
            PadsPanel(vm, deck, ui, Modifier.width(maxWidth.coerceAtMost(side * 1.25f)).fillMaxHeight().padding(vertical = 2.dp))
        }
    }
}

/** Nomes curtos e completos dos efeitos de deck (tipo 1 a 5). */
internal val FX_NAMES = listOf("ECO", "FLANGER", "REVERB", "TRANS", "BITCRUSH", "PHASER", "FILTRO LFO", "WOBBLE")
private val FX_SHORT = listOf("ECO", "FLG", "REV", "TRS", "CRSH", "PHS")
private val PAD_MODES = listOf("CUES", "LOOP", "SAMPLER", "MANOBRAS", "ROLL", "SALTO", "GRADE")
/** Nome curto na aba (a tela do deck é estreita); a descrição para leitor de tela usa o nome inteiro. */
private val PAD_TABS = listOf("CUE", "LOOP", "SAMP", "MANOB", "ROLL", "SALTO", "GRADE")

/**
 * Pads do deck em modos, como o PAD MODE da controladora: CUES (hot cues e pulo de batida), LOOP (automático
 * e manual com IN/OUT), SAMPLER (8 pads) e MANOBRAS (reverso, censura, freio, volta, grade). Embaixo, o efeito.
 */
@Composable
private fun PadsPanel(vm: AppViewModel, deck: Int, ui: DeckUi, modifier: Modifier) {
    val color = deckColor(deck)
    val name = AppViewModel.deckName(deck)
    val ready = ui.loaded && !ui.loading
    val hint = emptyHint(vm, deck)
    val pads by vm.pads.collectAsStateWithLifecycle()
    val manual by vm.manualLoop.collectAsStateWithLifecycle()
    Column(modifier, verticalArrangement = Arrangement.spacedBy(4.dp)) {
        // abas dos modos
        Row(Modifier.fillMaxWidth().height(30.dp), horizontalArrangement = Arrangement.spacedBy(4.dp)) {
            PAD_MODES.forEachIndexed { i, m ->
                val on = ui.padMode == i
                Box(
                    Modifier.weight(PAD_TABS[i].length + 1.5f).fillMaxHeight().clip(RoundedCornerShape(6.dp))
                        .background(if (on) color else Color(0xFF2A2F35))
                        .semantics { role = Role.Tab; contentDescription = "Modo dos pads $m do deck $name"; onClick { vm.setPadMode(deck, i); true } }
                        .pointerInput(Unit) { detectTapGestures(onTap = { vm.setPadMode(deck, i) }) },
                    contentAlignment = Alignment.Center,
                ) {
                    Text(PAD_TABS[i], color = if (on) onDeckColor(deck) else Metal.Text, fontSize = 9.sp, fontWeight = FontWeight.ExtraBold, maxLines = 1, softWrap = false)
                }
            }
        }
        @Composable
        fun padRow(content: @Composable androidx.compose.foundation.layout.RowScope.() -> Unit) =
            Row(Modifier.fillMaxWidth().weight(1f), horizontalArrangement = Arrangement.spacedBy(6.dp), content = content)

        @Composable
        fun androidx.compose.foundation.layout.RowScope.pad(label: String, desc: String, lit: Boolean, enabled: Boolean, size: Int, onPress: () -> Unit) =
            MetalButton(
                description = desc, onPress = onPress, enabled = enabled, onDisabledPress = hint,
                led = color, ledOn = lit, modifier = Modifier.weight(1f).fillMaxHeight(),
            ) { Text(label, color = if (lit) color else Metal.OnMetal, fontSize = size.sp, fontWeight = FontWeight.ExtraBold, maxLines = 1, softWrap = false) }

        when (ui.padMode) {
            0 -> {
                PadRowLabel("HOT CUES 1–8 · segure para dar nome ou apagar")
                for (row in 0..1) {
                    padRow {
                        for (slot in row * 4 until row * 4 + 4) {
                            HotCuePad(
                                slot = slot, frame = ui.hotcues[slot], enabled = ready, deckName = name,
                                label = ui.hotcueNames.getOrElse(slot) { "" },
                                onTap = { if (ready) vm.hotcue(deck, slot) else hint() },
                                onLong = { vm.openCueEdit(deck, slot) },
                                modifier = Modifier.weight(1f).fillMaxHeight(),
                            )
                        }
                    }
                }
            }
            1 -> {
                PadRowLabel("LOOP AUTOMÁTICO (batidas)")
                padRow {
                    for (beats in intArrayOf(1, 2, 4, 8)) {
                        pad("$beats", "Loop de $beats batida(s) no deck $name. Toque de novo para soltar.", ui.loopBeats == beats, ready, 18) { vm.toggleLoop(deck, beats) }
                    }
                }
                PadRowLabel("LOOP MANUAL")
                padRow {
                    val (inAt, outAt) = manual[deck]
                    pad("IN", "LOOP IN do deck $name: marca o início do loop", inAt >= 0, ready, 14) { vm.loopIn(deck) }
                    pad("OUT", "LOOP OUT do deck $name: fecha e liga o loop", outAt >= 0, ready, 14) { vm.loopOut(deck) }
                    pad("RELOOP", "RELOOP do deck $name: liga ou desliga o loop manual", ui.loopBeats == -1, ready, 11) { vm.reloop(deck) }
                    pad("⟲ IN", "Volta ao início do loop do deck $name", false, ready, 13) { vm.loopToStart(deck) }
                }
            }
            2 -> {
                val base = deck * 4
                PadRowLabel("SAMPLER · pads ${base + 1}–${base + 4}")
                padRow {
                    for (i in base until base + 4) {
                        val p = pads[i]
                        pad(
                            if (p.ready) shortPad(p.label) else "${i + 1}",
                            "Pad ${i + 1} do sampler (deck $name): ${if (p.ready) p.label else "vazio"}",
                            p.playing, true, 10,
                        ) { vm.padPress(i) }
                    }
                }
                PadRowLabel("PADS")
                padRow {
                    pad("AMOSTRAR", "Gerar amostras das músicas dos decks", false, true, 10) { vm.buildSamples() }
                    pad("PRONTOS", "Sons prontos de DJ nos pads (deck $name)", false, true, 10) { vm.loadBuiltinPads() }
                    val vol by vm.samplerVol.collectAsStateWithLifecycle()
                    MetalFader(
                        value = vol, onChange = { vm.setSamplerVolume(it) }, accent = color, fill = true,
                        description = "Volume do sampler (deck $name)", modifier = Modifier.weight(2f).fillMaxHeight(), vertical = false,
                    )
                }
            }
            4 -> {
                PadRowLabel("ROLL · repete enquanto ligado e volta no ponto")
                padRow {
                    for ((lbl, b) in listOf("1/8" to 0.125f, "1/4" to 0.25f, "1/2" to 0.5f, "1" to 1f)) {
                        pad(lbl, "Roll de $lbl de batida no deck $name. Toque de novo para soltar.", ui.rollBeats == b, ready, 15) { vm.roll(deck, b) }
                    }
                }
                PadRowLabel("DIVISÃO DO EFEITO (batidas)")
                padRow {
                    for ((lbl, b) in listOf("1/4" to 0.25f, "1/2" to 0.5f, "3/4" to 0.75f, "1" to 1f, "2" to 2f)) {
                        pad(lbl, "Efeito do deck $name em $lbl de batida", ui.fxBeats == b, true, 13) { vm.setFxBeats(deck, b) }
                    }
                }
            }
            5 -> {
                val js by vm.jumpSize.collectAsStateWithLifecycle()
                PadRowLabel("SALTO DE BATIDAS · $js")
                padRow {
                    pad("◀ $js", "Pular -$js batida(s) no deck $name", false, ready, 14) { vm.beatJump(deck, -js) }
                    pad("◀ 1", "Pular -1 batida(s) no deck $name", false, ready, 14) { vm.beatJump(deck, -1) }
                    pad("1 ▶", "Pular +1 batida(s) no deck $name", false, ready, 14) { vm.beatJump(deck, 1) }
                    pad("$js ▶", "Pular +$js batida(s) no deck $name", false, ready, 14) { vm.beatJump(deck, js) }
                }
                PadRowLabel("TAMANHO DO SALTO")
                padRow {
                    for (n in AppViewModel.JUMP_SIZES) pad("$n", "Salto de $n batidas", js == n, true, 13) { vm.setJumpSize(n) }
                }
            }
            6 -> {
                PadRowLabel("GRADE · ajuste a grade de batidas na onda")
                padRow {
                    pad("◀▮", "Grade de batidas do deck $name 5 ms para trás", false, ready, 13) { vm.nudgeGrid(deck, -1) }
                    pad("▮▶", "Grade de batidas do deck $name 5 ms para frente", false, ready, 13) { vm.nudgeGrid(deck, 1) }
                    pad("1 AQUI", "Marcar o 1 do compasso do deck $name na posição atual", false, ready, 11) { vm.downbeatHere(deck) }
                    pad("TAP", "Andamento do deck $name na mão (toque no ritmo)", false, ready, 12) { if (ready) vm.tapBpm(deck) else hint() }
                }
                PadRowLabel("BPM DA GRADE · ${if (ui.hasBpm) String.format(java.util.Locale.ROOT, "%.2f", ui.bpm) else "—"}")
                padRow {
                    pad("−0,1", "BPM da grade do deck $name menos 0,1", false, ready, 12) { vm.adjustBpm(deck, -0.1) }
                    pad("−0,01", "BPM da grade do deck $name menos 0,01", false, ready, 11) { vm.adjustBpm(deck, -0.01) }
                    pad("+0,01", "BPM da grade do deck $name mais 0,01", false, ready, 11) { vm.adjustBpm(deck, 0.01) }
                    pad("+0,1", "BPM da grade do deck $name mais 0,1", false, ready, 12) { vm.adjustBpm(deck, 0.1) }
                }
            }
            3 -> {
                PadRowLabel("MANOBRAS")
                padRow {
                    pad("REV", "Reverso do deck $name: toca ao contrário. Toque de novo para voltar.", ui.reverse, ready, 12) { vm.toggleReverse(deck) }
                    pad("CENS", "Censura do deck $name: 2 batidas ao contrário e volta no ponto certo.", false, ready, 12) { vm.censor(deck) }
                    pad("DUPLA", "Instant double no deck $name: a mesma música do outro deck, no mesmo ponto", false, true, 11) { vm.instantDouble(deck) }
                    pad("CAPTURA", "Capturar o compasso do deck $name num pad do sampler", false, ready, 9) { vm.captureLoop(deck) }
                }
                PadRowLabel("PERFORMANCE")
                padRow {
                    pad("FREIO", "Freio do deck $name (pads)", false, ready, 11) { vm.brake(deck) }
                    pad("VOLTA", "Volta do deck $name (pads)", false, ready, 11) { vm.spinback(deck) }
                    pad("ECHO OUT", "Echo out do deck $name (pads)", false, ready, 10) { vm.echoOut(deck) }
                    pad("FILTRO", "Filtro automático do deck $name (pads)", false, ready, 10) { vm.filterSweep(deck) }
                }
            }
        }
        val activeFx = (0..2).map { ui.fxTypeAt(it) }.filter { it > 0 }.joinToString("+") { FX_NAMES[it - 1].take(4) }
        PadRowLabel("EFEITOS · encaixe FX${ui.fxSel + 1}" + if (activeFx.isNotEmpty()) " · ligados: $activeFx" else " · até 3 juntos")
        Row(Modifier.fillMaxWidth().weight(1f), horizontalArrangement = Arrangement.spacedBy(4.dp), verticalAlignment = Alignment.CenterVertically) {
            MetalButton(
                description = "Encaixe de efeito do deck $name: FX${ui.fxSel + 1}. Toque para trocar (até 3 efeitos juntos).",
                onPress = { vm.setFxSlot(deck, (ui.fxSel + 1) % 3) },
                led = color, ledOn = ui.selFxType > 0,
                modifier = Modifier.weight(1.1f).fillMaxHeight(),
            ) {
                Text("FX${ui.fxSel + 1}", color = color, fontSize = 11.sp, fontWeight = FontWeight.ExtraBold, maxLines = 1, softWrap = false)
            }
            for (t in 1..FX_SHORT.size) {   // na tela DJ cabem os 6 principais; os outros ficam em EFEITOS
                val slot = ui.fxSlotOf(t)
                MetalButton(
                    description = "Efeito ${FX_NAMES[t - 1]} do deck $name. Toque de novo para desligar.",
                    onPress = { vm.setFx(deck, t) },
                    led = color, ledOn = slot >= 0,
                    modifier = Modifier.weight(1f).fillMaxHeight(),
                ) {
                    Text(
                        FX_SHORT[t - 1] + if (slot >= 0 && slot != ui.fxSel) "${slot + 1}" else "",
                        color = when { slot == ui.fxSel -> color; slot >= 0 -> color.copy(alpha = 0.6f); else -> Metal.OnMetal },
                        fontSize = 10.sp, fontWeight = FontWeight.ExtraBold, maxLines = 1, softWrap = false,
                    )
                }
            }
            MetalFader(
                value = ui.selFxAmount, onChange = { vm.setFxAmount(deck, it) }, accent = color, fill = true,
                description = "Quantidade do efeito do deck $name",
                modifier = Modifier.weight(1.6f).fillMaxHeight(), vertical = false,
            )
        }
    }
}

private val STEM_NAMES = listOf("VOZ", "BATERIA", "BAIXO", "MELODIA")
private val STEM_COLORS = listOf(Color(0xFF4FC3F7), Color(0xFFFFB74D), Color(0xFFFF5252), Color(0xFFB39DDB))

/** Stems do deck: um fader e um botão de corte para cada parte, e atalhos ACAPELLA / INSTRUMENTAL. */
@Composable
private fun StemsPanel(vm: AppViewModel, deck: Int, ui: DeckUi, modifier: Modifier) {
    val name = AppViewModel.deckName(deck)
    val color = deckColor(deck)
    val ready = ui.stemsReady
    Column(modifier, verticalArrangement = Arrangement.spacedBy(4.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            PadRowLabel("STEMS")
            Spacer(Modifier.width(6.dp))
            val status = when {
                ready -> "prontos"
                ui.stemProgress >= 0f -> "separando ${(ui.stemProgress * 100).toInt()}%"
                ui.stemProgress < -1.5f -> "indisponíveis (música longa ou pouca memória)"
                ui.loading -> "carregando a música…"
                !ui.loaded -> "carregue uma música"
                else -> "aguardando"
            }
            Text(status, color = if (ready) Metal.Success else Metal.Warning, fontSize = 10.sp, fontWeight = FontWeight.Bold, maxLines = 1)
        }
        if (!ready && ui.stemProgress >= 0f) {
            Box(Modifier.fillMaxWidth().height(4.dp).clip(RoundedCornerShape(2.dp)).background(Color(0xFF1E2226))) {
                Box(Modifier.fillMaxWidth(ui.stemProgress.coerceIn(0f, 1f)).fillMaxHeight().background(color))
            }
        }
        Row(Modifier.fillMaxWidth().weight(1f), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            for (st in 0..3) {
                val g = ui.stemGains[st]
                val c = STEM_COLORS[st]
                Column(Modifier.weight(1f).fillMaxHeight(), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(3.dp)) {
                    MetalFader(
                        value = g, onChange = { vm.setStemGain(deck, st, it) }, accent = if (ready) c else Color(0xFF3A4046), fill = true,
                        description = "Volume do stem ${STEM_NAMES[st]} do deck $name",
                        modifier = Modifier.fillMaxWidth().weight(1f),
                    )
                    MetalButton(
                        description = "${if (g > 0.5f) "Cortar" else "Voltar"} ${STEM_NAMES[st]} do deck $name",
                        onPress = { vm.toggleStem(deck, st) }, led = c, ledOn = ready && g > 0.5f,
                        modifier = Modifier.fillMaxWidth().height(30.dp),
                    ) {
                        Text(STEM_NAMES[st].take(3), color = if (ready && g > 0.5f) Color(0xFF101317) else Metal.OnMetal, fontSize = 11.sp, fontWeight = FontWeight.ExtraBold, maxLines = 1)
                    }
                }
            }
        }
        Row(Modifier.fillMaxWidth().height(32.dp), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            val presets = listOf("ACAPELLA" to 1, "INSTR." to 2, "BATERIA" to 3, "TUDO" to 0)
            val desc = listOf("Acapella do deck $name: só a voz", "Instrumental do deck $name: tira a voz", "Só a bateria do deck $name", "Todos os stems do deck $name de volta")
            presets.forEachIndexed { i, (label, code) ->
                MetalButton(description = desc[i], onPress = { vm.stemPreset(deck, code) }, modifier = Modifier.weight(1f).fillMaxHeight()) {
                    Text(label, color = Metal.OnMetal, fontSize = 10.sp, fontWeight = FontWeight.ExtraBold, maxLines = 1, softWrap = false)
                }
            }
        }
    }
}

@Composable
private fun PadRowLabel(text: String) {
    Text(text, color = Engraving, fontSize = 9.sp, fontWeight = FontWeight.Bold, letterSpacing = 1.sp, maxLines = 1)
}

@Composable
private fun Transport(vm: AppViewModel, deck: Int, ui: DeckUi, modifier: Modifier) {
    val color = deckColor(deck)
    val name = AppViewModel.deckName(deck)
    val ready = ui.loaded && !ui.loading
    val hint = emptyHint(vm, deck)
    Row(modifier, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
        val cue = @Composable {
            MetalButton(
                description = "Cue do deck $name. Tocando: volta ao ponto e para. Parado: marca o ponto; segure para ouvir dali.",
                onPress = { vm.cueDown(deck) }, onRelease = { vm.cueUp(deck) }, enabled = ready, onDisabledPress = hint,
                led = Color(0xFFFF8A3D), ledOn = ready && !ui.playing,
                modifier = Modifier.weight(1f).fillMaxHeight(),
            ) { Text("CUE", color = Color(0xFFFF8A3D), fontSize = 16.sp, fontWeight = FontWeight.ExtraBold, letterSpacing = 1.sp, maxLines = 1) }
        }
        val play = @Composable {
            MetalButton(
                description = if (ui.playing) "Pausar deck $name" else "Tocar deck $name",
                onPress = { vm.togglePlay(deck) }, enabled = ready, onDisabledPress = hint,
                led = Metal.Success, ledOn = ui.playing,
                modifier = Modifier.weight(1.4f).fillMaxHeight(),
            ) { TransportGlyph(ui.playing, if (ui.playing) Metal.Success else Metal.OnMetal, Modifier.size(26.dp)) }
        }
        val sync = @Composable {
            MetalButton(
                description = "Sync do deck $name. Iguala o andamento ao do outro deck, alinha a batida e trava. Toque de novo para soltar.",
                onPress = { vm.syncButton(deck) }, enabled = ready, onDisabledPress = hint,
                led = color, ledOn = ui.syncLock,
                modifier = Modifier.weight(1f).fillMaxHeight(),
            ) { Text(if (ui.syncLock) "SYNC ●" else "SYNC", color = if (ui.syncLock) color else Metal.OnMetal, fontSize = 13.sp, fontWeight = FontWeight.ExtraBold, maxLines = 1) }
        }
        val fone = @Composable {
            MetalButton(
                description = "Fone do deck $name. Ligado, você ouve este deck no fone antes de soltá-lo no som geral.",
                onPress = { vm.toggleHeadphoneCue(deck) },
                led = color, ledOn = ui.cueOn,
                modifier = Modifier.weight(1f).fillMaxHeight(),
            ) { Text("FONE", color = if (ui.cueOn) color else Metal.OnMetal, fontSize = 13.sp, fontWeight = FontWeight.ExtraBold, maxLines = 1) }
        }
        if (deck == 0) { cue(); play(); sync(); fone() } else { fone(); sync(); cue(); play() }
    }
}

/** Pad de hot cue: vazio grava a posição atual, gravado vai até ela e toca, toque longo apaga. */
@Composable
private fun HotCuePad(
    slot: Int, frame: Long, enabled: Boolean, deckName: String, label: String,
    onTap: () -> Unit, onLong: () -> Unit, modifier: Modifier,
) {
    val set = frame >= 0
    val c = HOT_COLORS[slot]
    Box(
        modifier
            .semantics {
                contentDescription = if (set) {
                    "Hot cue ${slot + 1} do deck $deckName${if (label.isNotEmpty()) " ($label)" else ""}. Toque para ir até ela. Segure para dar nome ou apagar."
                } else {
                    "Hot cue ${slot + 1} do deck $deckName, vazia. Toque para gravar a posição atual."
                }
                role = Role.Button
                onClick { onTap(); true }
            }
            .clip(RoundedCornerShape(8.dp))
            .drawBehind {
                val corner = CornerRadius(8.dp.toPx())
                if (!enabled) {
                    drawRoundRect(Color(0xFF1E2226), cornerRadius = corner)
                } else if (set) {
                    drawRoundRect(Brush.verticalGradient(listOf(c, c.copy(alpha = 0.62f))), cornerRadius = corner)
                    drawRoundRect(Color.White.copy(alpha = 0.35f), cornerRadius = corner, style = Stroke(1.dp.toPx()))
                } else {
                    drawRoundRect(Color(0xFF1B1E22), cornerRadius = corner)
                    drawRoundRect(c.copy(alpha = 0.55f), cornerRadius = corner, style = Stroke(1.5f.dp.toPx()))
                }
            }
            .pointerInput(enabled, set) {
                detectTapGestures(
                    onTap = { onTap() },
                    onLongPress = { if (enabled && set) onLong() else onTap() },
                )
            },
        contentAlignment = Alignment.Center,
    ) {
        val txt = when {
            set && label.isNotEmpty() -> "${slot + 1} $label"
            slot == 6 -> "7 ENTRA"
            slot == 7 -> "8 SAI"
            else -> "${slot + 1}"
        }
        Text(
            txt,
            color = if (set && enabled) Color(0xFF14171B) else c.copy(alpha = if (enabled) 0.9f else 0.35f),
            fontSize = if (txt.length > 6) 10.sp else if (txt.length > 2) 11.sp else 16.sp, fontWeight = FontWeight.ExtraBold, maxLines = 1, softWrap = false,
            overflow = androidx.compose.ui.text.style.TextOverflow.Clip,
        )
    }
}

@Composable
private fun SmallTextButton(label: String, description: String, modifier: Modifier = Modifier, onClick: () -> Unit) {
    Box(
        modifier
            .semantics { contentDescription = description; role = Role.Button; onClick { onClick(); true } }
            .clip(RoundedCornerShape(6.dp))
            .background(Color(0xFF2A2F35))
            .pointerInput(Unit) { detectTapGestures(onTap = { onClick() }) }
            .padding(vertical = 5.dp),
        contentAlignment = Alignment.Center,
    ) {
        Text(label, color = Metal.Text, fontSize = 12.sp, fontWeight = FontWeight.Bold, maxLines = 1)
    }
}

// ------------------------------------------------------------------------------------- mesa

@Composable
private fun MixerPanel(vm: AppViewModel, live: State<LiveUi>, modifier: Modifier) {
    val volumes by vm.volumes.collectAsStateWithLifecycle()
    val decks by vm.decks.collectAsStateWithLifecycle()
    val master by vm.master.collectAsStateWithLifecycle()
    val hpLevel by vm.hpLevel.collectAsStateWithLifecycle()
    val hpMix by vm.hpMix.collectAsStateWithLifecycle()
    val cross by vm.crossfader.collectAsStateWithLifecycle()
    Column(
        modifier.brushedBlack().padding(horizontal = 8.dp, vertical = 5.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
    ) {
        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
            Text("MASTER", color = Metal.TextMuted, fontSize = 9.sp, fontWeight = FontWeight.Bold, letterSpacing = 1.sp)
            MetalFader(
                value = master, onChange = vm::setMaster, accent = Color(0xFFE6E9EC), description = "Volume master",
                modifier = Modifier.weight(1f).height(26.dp).padding(start = 6.dp), vertical = false,
            )
            val ag by vm.autoGain.collectAsStateWithLifecycle()
            Box(
                Modifier.padding(start = 6.dp).clip(RoundedCornerShape(5.dp))
                    .background(if (ag) Color(0xFF203A2C) else Color(0xFF2A2F35))
                    .semantics { contentDescription = "Auto-gain: iguala o volume das músicas"; role = Role.Button; onClick { vm.toggleAutoGain(); true } }
                    .pointerInput(Unit) { detectTapGestures(onTap = { vm.toggleAutoGain() }) }
                    .padding(horizontal = 6.dp, vertical = 4.dp),
            ) {
                Text("AUTO\nGAIN", color = if (ag) Metal.Success else Metal.TextMuted, fontSize = 8.sp, lineHeight = 9.sp, fontWeight = FontWeight.ExtraBold)
            }
        }
        LevelMeter({ live.value.masterPeak }, Modifier.fillMaxWidth().height(5.dp).padding(top = 1.dp), vertical = false, segments = 24)
        PhaseMeter(decks, live, Modifier.fillMaxWidth().height(13.dp).padding(top = 3.dp))
        Row(
            Modifier.fillMaxWidth().padding(top = 4.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceEvenly,
        ) {
            KnobInline("FONE", hpLevel, "Volume do fone", centered = false, onChange = vm::setHeadphoneLevel)
            KnobInline("MIX FONE", hpMix, "Mistura do fone. Esquerda só o deck em pré-escuta, direita só o som geral.", centered = false, onChange = vm::setHeadphoneMix)
        }
        Row(Modifier.weight(1f).fillMaxWidth().padding(top = 4.dp)) {
            ChannelStrip(vm, 0, decks[0], volumes[0], live, Modifier.weight(1f).fillMaxHeight())
            ChannelStrip(vm, 1, decks[1], volumes[1], live, Modifier.weight(1f).fillMaxHeight())
        }
        Spacer(Modifier.height(5.dp))
        Column(Modifier.fillMaxWidth().height(TRANSPORT_HEIGHT)) {
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                Text("A", color = Metal.DeckA, fontSize = 11.sp, fontWeight = FontWeight.ExtraBold)
                Text("CROSSFADER", color = Metal.TextMuted, fontSize = 8.sp, fontWeight = FontWeight.Bold, letterSpacing = 1.sp)
                Text("B", color = Metal.DeckB, fontSize = 11.sp, fontWeight = FontWeight.ExtraBold)
            }
            MetalFader(
                value = cross, onChange = vm::setCrossfader, accent = Color(0xFFE6E9EC),
                description = "Crossfader. Esquerda toca só o deck A, direita só o deck B.",
                modifier = Modifier.fillMaxWidth().weight(1f), vertical = false,
            )
        }
    }
}

/**
 * Medidor de fase: cada linha é um compasso (4 batidas) de um deck, com a batida atual acesa e a marca da posição.
 * Marcas alinhadas = batidas casadas.
 */
@Composable
private fun PhaseMeter(decks: List<DeckUi>, live: State<LiveUi>, modifier: Modifier) {
    androidx.compose.foundation.Canvas(modifier.semantics { contentDescription = "Medidor de fase das batidas dos dois decks" }) {
        val rowH = size.height / 2f - 1f
        for (d in 0..1) {
            val ui = decks[d]
            val y = d * (rowH + 2f)
            val segW = size.width / 4f
            val c = deckColor(d)
            if (!ui.loaded || !ui.hasBpm) {
                drawRect(Color(0xFF1E2226), androidx.compose.ui.geometry.Offset(0f, y), androidx.compose.ui.geometry.Size(size.width, rowH))
                continue
            }
            val beatF = 60.0 * 48000.0 / ui.bpm
            val beats = (live.value.decks[d].positionFrames - ui.firstBeatFrame) / beatF
            val inBar = ((beats % 4.0) + 4.0) % 4.0
            val cur = inBar.toInt()
            for (k in 0..3) {
                drawRect(
                    if (k == cur) c.copy(alpha = if (ui.playing) 0.9f else 0.5f) else Color(0xFF2A2F35),
                    androidx.compose.ui.geometry.Offset(k * segW + 1f, y), androidx.compose.ui.geometry.Size(segW - 2f, rowH),
                )
            }
            val x = (inBar / 4.0 * size.width).toFloat()
            drawRect(Color.White, androidx.compose.ui.geometry.Offset(x - 1f, y), androidx.compose.ui.geometry.Size(2f, rowH))
        }
    }
}

@Composable
private fun KnobInline(label: String, value: Float, description: String, centered: Boolean, onChange: (Float) -> Unit) {
    Row(verticalAlignment = Alignment.CenterVertically) {
        Text(label, color = Metal.TextMuted, fontSize = 8.sp, fontWeight = FontWeight.Bold)
        Knob(
            value = value, onChange = onChange, accent = Color(0xFFE6E9EC), centered = centered,
            description = description, modifier = Modifier.padding(start = 4.dp).size(28.dp),
        )
    }
}

@Composable
private fun ChannelStrip(
    vm: AppViewModel, deck: Int, d: DeckUi, volume: Float, live: State<LiveUi>, modifier: Modifier,
) {
    val name = AppViewModel.deckName(deck)
    val color = deckColor(deck)
    Row(modifier.padding(horizontal = 1.dp), horizontalArrangement = Arrangement.spacedBy(3.dp)) {
        val knobs = @Composable {
            Column(Modifier.width(42.dp).fillMaxHeight(), verticalArrangement = Arrangement.SpaceEvenly, horizontalAlignment = Alignment.CenterHorizontally) {
                KnobCell("AGUDO", d.eq[2], color, "Equalizador agudos do deck $name. Meio é neutro, embaixo corta. Toque duplo zera.") { vm.setEq(deck, 2, it) }
                KnobCell("MÉDIO", d.eq[1], color, "Equalizador médios do deck $name. Meio é neutro, embaixo corta. Toque duplo zera.") { vm.setEq(deck, 1, it) }
                KnobCell("GRAVE", d.eq[0], color, "Equalizador graves do deck $name. Meio é neutro, embaixo corta. Toque duplo zera.") { vm.setEq(deck, 0, it) }
                KnobCell("FILTRO", d.filter, color, "Filtro do deck $name. Esquerda corta os agudos, direita corta os graves, meio desliga. Toque duplo zera.") { vm.setFilter(deck, it) }
            }
        }
        val fader = @Composable {
            Column(Modifier.width(32.dp).fillMaxHeight(), horizontalAlignment = Alignment.CenterHorizontally) {
                MetalFader(
                    value = volume, onChange = { vm.setVolume(deck, it) }, accent = color, fill = true,
                    description = "Volume do deck $name", modifier = Modifier.fillMaxWidth().weight(1f),
                )
                Text(name, color = color, fontSize = 12.sp, fontWeight = FontWeight.ExtraBold)
            }
        }
        val meter = @Composable {
            LevelMeter({ live.value.decks[deck].peak }, Modifier.width(6.dp).fillMaxHeight().padding(bottom = 16.dp))
        }
        if (deck == 0) { knobs(); fader(); meter() } else { meter(); fader(); knobs() }
    }
}

@Composable
private fun KnobCell(label: String, value: Float, color: Color, description: String, onChange: (Float) -> Unit) {
    Column(horizontalAlignment = Alignment.CenterHorizontally) {
        Knob(value = value, onChange = onChange, accent = color, description = description, modifier = Modifier.size(25.dp))
        Text(label, color = Metal.TextMuted, fontSize = 7.sp, lineHeight = 8.sp, fontWeight = FontWeight.Bold, maxLines = 1)
    }
}


@Composable
private fun TopChip(label: String, on: Boolean, desc: String, onTap: () -> Unit) {
    Box(
        Modifier.padding(start = 6.dp).clip(RoundedCornerShape(5.dp))
            .background(if (on) Metal.DeckA else Color(0xFF2A2F35))
            .semantics { contentDescription = desc; role = Role.Button; onClick { onTap(); true } }
            .pointerInput(Unit) { detectTapGestures(onTap = { onTap() }) }
            .padding(horizontal = 8.dp, vertical = 2.dp),
    ) { Text(label, color = if (on) Color.White else Metal.Text, fontSize = 11.sp, fontWeight = FontWeight.ExtraBold, maxLines = 1) }
}

/** Nome curto do pad para a tela DJ: "A · LOOP 1 COMPASSO · música" vira "LOOP 1C". */
private fun shortPad(label: String): String {
    val core = if (label.contains(" · ")) label.split(" · ").getOrElse(1) { label } else label
    return core.replace("LOOP 1 COMPASSO", "LOOP 1C").replace("LOOP 2 COMPASSOS", "LOOP 2C").replace("TRECHO FORTE", "TRECHO").take(9)
}
