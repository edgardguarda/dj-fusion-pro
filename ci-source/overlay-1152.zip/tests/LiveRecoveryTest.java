import br.com.edgard.aura.core.*;
import java.io.*;
public class LiveRecoveryTest {
 static int checks;static void check(boolean ok,String msg){checks++;if(!ok)throw new AssertionError(msg);}
 public static void main(String[] args)throws Exception{
  File a=File.createTempFile("egmix-tail-",".pcm");int hz=8000;int frames=30*hz;
  try(DataOutputStream out=new DataOutputStream(new BufferedOutputStream(new FileOutputStream(a)))){
   for(int i=0;i<frames;i++){short s=(short)(i<22*hz?Math.sin(i*.17)*7000:0);out.writeShort(Short.reverseBytes(s));out.writeShort(Short.reverseBytes(s));}
  }
  double end=BeatAnalyzer.lastAudible(a,hz,frames);check(end>=22&&end<22.15,"trailing silence end "+end);
  TrackData x=new TrackData("A",a,hz,frames,0,0,0,.12);x.audibleEndSeconds=end;TrackData y=new TrackData("B",a,hz,frames,0,0,0,.12);
  TrackPlanner.Handoff plan=TrackPlanner.plan(x,y,1,16);check(plan.startASeconds+plan.durationSeconds<22.05,"fade before silence");
  for(int i=1;i<10000;i++){double rem=i/1000.;double duration=LiveTransitionPolicy.duration(rem,6);check(duration>=.02&&duration<=6,"bounded fade");if(rem<=6.75)check(LiveTransitionPolicy.shouldStart(0,100,rem,6,false),"cooldown cannot erase overlap");}
  check(!LiveTransitionPolicy.shouldStart(5,10,20,6,true),"do not advance healthy aligned start");check(LiveTransitionPolicy.shouldStart(10,10,20,6,true),"honor planned start");
  check(!LiveTransitionPolicy.shouldStart(0,10,-1,6,true),"EOF not a mix");a.delete();System.out.println("PASS LiveRecoveryTest "+checks+" checks; audible end "+end+" s, overlap "+plan.durationSeconds+" s");
 }
}
