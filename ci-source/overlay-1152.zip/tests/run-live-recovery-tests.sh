#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")/.."
build=$(mktemp -d); trap 'rm -rf "$build"' EXIT
javac -encoding UTF-8 -d "$build" app/src/main/java/br/com/edgard/aura/core/{TrackData,StemStorage,TrackPlanner,HarmonicAnalyzer,BeatAnalyzer,MixMath,LiveTransitionPolicy}.java tests/LiveRecoveryTest.java
java -cp "$build" LiveRecoveryTest
