package br.com.edgard.aura;

import android.content.Context;
import br.com.edgard.aura.core.PcmCacheMaintenance;
import br.com.edgard.aura.core.DecodeProgressGuard;
import android.media.MediaCodec;
import android.media.AudioFormat;
import android.media.MediaExtractor;
import android.media.MediaFormat;
import android.net.Uri;

import java.io.BufferedOutputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.nio.ByteBuffer;
import java.nio.ByteOrder;

/** Android decoder: audio files become on-disk stereo PCM16; never a full RAM copy. */
public final class AudioDecoder {
    public static final class Result {
        public final File file; public final int sampleRate; public final long frames;
        Result(File f,int r,long n){file=f;sampleRate=r;frames=n;}
    }
    public interface Progress { void onProgress(long frames); }
    private static short floatToPcm16(float x){
        if(Float.isNaN(x))return 0;
        return (short)Math.max(-32768,Math.min(32767,Math.round(x*32767f)));
    }
    public static Result decode(Context context,Uri uri,File destination,Progress progress) throws Exception {
        return decode(context,uri,destination,progress,0);
    }
    /** Optional duration limit checked on decoded frames, not untrusted file metadata. */
    public static Result decode(Context context,Uri uri,File destination,Progress progress,int maxSeconds) throws Exception {
        if(maxSeconds<0)throw new IllegalArgumentException("Limite inválido");
        MediaExtractor extractor=new MediaExtractor();
        MediaCodec codec=null;
        boolean complete=false;
        try {
            extractor.setDataSource(context,uri,null);
            int track=-1;MediaFormat format=null;
            for(int i=0;i<extractor.getTrackCount();i++){
                MediaFormat candidate=extractor.getTrackFormat(i);
                if(candidate.containsKey(MediaFormat.KEY_MIME)&&candidate.getString(MediaFormat.KEY_MIME).startsWith("audio/")){
                    track=i;format=candidate;break;
                }
            }
            if(track<0)throw new IOException("Arquivo sem faixa de áudio compatível");
            extractor.selectTrack(track);
            String mime=format.getString(MediaFormat.KEY_MIME);
            codec=MediaCodec.createDecoderByType(mime);
            codec.configure(format,null,null,0);codec.start();
            int channels=format.containsKey(MediaFormat.KEY_CHANNEL_COUNT)?format.getInteger(MediaFormat.KEY_CHANNEL_COUNT):2;
            int rate=format.containsKey(MediaFormat.KEY_SAMPLE_RATE)?format.getInteger(MediaFormat.KEY_SAMPLE_RATE):44100;
            if(channels<1||channels>8)throw new IOException("Número de canais não suportado");
            int pcmEncoding=AudioFormat.ENCODING_PCM_16BIT;
            boolean inputDone=false,outputDone=false;
            long frames=0;byte[] stereo=new byte[32768];
            MediaCodec.BufferInfo info=new MediaCodec.BufferInfo();
            if(rate<=0||rate>384000)throw new IOException("Taxa de amostragem inválida");
            File parent=destination.getAbsoluteFile().getParentFile();
            if(parent==null||!PcmCacheMaintenance.hasSpace(parent.getUsableSpace(),0))throw new IOException("Espaço insuficiente: preserve 128 MiB livres");
            try(BufferedOutputStream out=new BufferedOutputStream(new FileOutputStream(destination),1<<18)){
                DecodeProgressGuard progressGuard=new DecodeProgressGuard(15_000_000_000L,System.nanoTime());
                long nextSpaceCheck=0;
                while(!outputDone) {
                    if(Thread.currentThread().isInterrupted())throw new InterruptedException("Decodificação interrompida");
                    if(progressGuard.expired(System.nanoTime()))throw new IOException("Decodificador sem produzir áudio por 15 segundos");
                    if(!inputDone){
                        int ix=codec.dequeueInputBuffer(0);
                        if(ix>=0){
                            ByteBuffer input=codec.getInputBuffer(ix);
                            if(input==null)throw new IOException("Buffer de entrada indisponível");
                            input.clear();int size=extractor.readSampleData(input,0);
                            if(size<0){codec.queueInputBuffer(ix,0,0,0,MediaCodec.BUFFER_FLAG_END_OF_STREAM);inputDone=true;}
                            else{codec.queueInputBuffer(ix,0,size,extractor.getSampleTime(),0);extractor.advance();}
                        }
                    }
                    int ox=codec.dequeueOutputBuffer(info,inputDone?10000:1000);
                    if(ox==MediaCodec.INFO_OUTPUT_FORMAT_CHANGED){
                        MediaFormat of=codec.getOutputFormat();
                        if(of.containsKey(MediaFormat.KEY_SAMPLE_RATE)){
                            int updated=of.getInteger(MediaFormat.KEY_SAMPLE_RATE);
                            if(updated<=0||updated>384000||(frames>0&&updated!=rate))throw new IOException("Taxa PCM alterada durante a faixa");
                            rate=updated;
                        }
                        if(of.containsKey(MediaFormat.KEY_CHANNEL_COUNT))channels=of.getInteger(MediaFormat.KEY_CHANNEL_COUNT);
                        pcmEncoding=of.containsKey(MediaFormat.KEY_PCM_ENCODING)?of.getInteger(MediaFormat.KEY_PCM_ENCODING):AudioFormat.ENCODING_PCM_16BIT;
                        if(pcmEncoding!=AudioFormat.ENCODING_PCM_16BIT && pcmEncoding!=AudioFormat.ENCODING_PCM_FLOAT)
                            throw new IOException("Saída PCM incompatível (encoding="+pcmEncoding+"). Tente MP3, M4A ou FLAC comum.");
                    } else if(ox>=0){
                        ByteBuffer data=codec.getOutputBuffer(ox);
                        if(info.size>0&&data!=null){
                            data.position(info.offset);data.limit(info.offset+info.size);data.order(ByteOrder.LITTLE_ENDIAN);
                            if(channels<1||channels>8)throw new IOException("Canais não suportados");
                            int block=channels*(pcmEncoding==AudioFormat.ENCODING_PCM_FLOAT?4:2);
                            if(info.size%block!=0)throw new IOException("Quadro PCM incompleto");
                            int count=info.size/block;
                            if(maxSeconds>0&&frames+count>rate*(long)maxSeconds)throw new IOException("Limite de duração: "+maxSeconds/60+" minutos");
                            if(!PcmCacheMaintenance.canAppend(frames,count))throw new IOException("Limite de cache: 1 GB por música");
                            if(frames+count>=nextSpaceCheck){
                                // Include the next 4 MiB interval and output buffering in the reserve check.
                                if(!PcmCacheMaintenance.hasSpace(parent.getUsableSpace(),4L*count+4L*1024*1024+(1<<18)))
                                    throw new IOException("Espaço insuficiente: preserve 128 MiB livres");
                                nextSpaceCheck=frames+count+1024*1024;
                            }
                            int offset=0;
                            if(channels==2 && pcmEncoding==AudioFormat.ENCODING_PCM_16BIT){
                                while(data.hasRemaining()){int n=Math.min(data.remaining(),stereo.length);data.get(stereo,0,n);out.write(stereo,0,n);}
                            }else for(int s=0;s<count;s++){
                                short left,right;
                                if(pcmEncoding==AudioFormat.ENCODING_PCM_FLOAT){
                                    left=floatToPcm16(data.getFloat());right=left;
                                    if(channels>1)right=floatToPcm16(data.getFloat());
                                    for(int c=2;c<channels;c++)data.getFloat();
                                }else{
                                    left=data.getShort();right=left;
                                    if(channels>1)right=data.getShort();
                                    for(int c=2;c<channels;c++)data.getShort();
                                }
                                stereo[offset++]=(byte)(left&255);stereo[offset++]=(byte)((left>>>8)&255);
                                stereo[offset++]=(byte)(right&255);stereo[offset++]=(byte)((right>>>8)&255);
                                if(offset>=stereo.length){out.write(stereo,0,offset);offset=0;}
                            }
                            if(offset>0)out.write(stereo,0,offset);
                            frames+=count;
                            if(count>0)progressGuard.progress(System.nanoTime());
                            if(progress!=null&&(frames% (rate*5L))<count)progress.onProgress(frames);
                        }
                        outputDone=(info.flags&MediaCodec.BUFFER_FLAG_END_OF_STREAM)!=0;
                        codec.releaseOutputBuffer(ox,false);
                    }

                }
            }
            if(frames<rate*2L)throw new IOException("Música menor que 2 segundos");
            complete=true;return new Result(destination,rate,frames);
        } finally {
            try{if(codec!=null)codec.stop();}catch(Exception ignored){}
            try{if(codec!=null)codec.release();}catch(Exception ignored){}
            try{extractor.release();}catch(Exception ignored){}
            if(!complete)destination.delete();
        }
    }
}
