package br.com.edgard.aura.core;
/** Deadline-aware fallback: cooldown may defer phase-sensitive transitions, never suppress a viable overlap until EOF. */
public final class LiveTransitionPolicy {
 private LiveTransitionPolicy(){}
 public static boolean shouldStart(double position,double planned,double remaining,double requested,boolean safe){
  if(!Double.isFinite(position)||!Double.isFinite(planned)||!Double.isFinite(remaining)||!Double.isFinite(requested)||remaining<=0||requested<=0)return false;
  // Reserve one second of extra headroom if a prior recovery gate is active.
  return safe?position>=planned||remaining<=.25:position>=planned||remaining<=requested+.75;
 }
 public static double duration(double remaining,double requested){return Math.max(.02,Math.min(requested,Math.max(.02,remaining-.12)));}
}
