package br.com.edgard.aura;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import br.com.edgard.aura.core.TrackData;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.ArrayList;

/** Debug-only real AudioTrack smoke fixture. No microphone or external files. */
public final class DebugPcmSmokeActivity extends Activity {
    @Override public void onCreate(Bundle state){
        super.onCreate(state);
        new Thread(()->{
            try{
                ArrayList<TrackData> tracks=new ArrayList<>();
                for(int i=0;i<3;i++){
                    File file=new File(getFilesDir(),"aura-pcm-smoke-"+i+".pcm");
                    writePcm(file,220+i*110,12);
                    TrackData track=new TrackData("PCM smoke "+(i+1),file,48000,12*48000,120,.9,0,.12);
                    track.audibleEndSeconds=10;tracks.add(track);
                }
                SessionStore.save(this,tracks,0,0);
                getSharedPreferences("aura",MODE_PRIVATE).edit()
                    .putString("smokePCM","fixtures-created").putLong("pcm_buffer_misses",-1).apply();
                runOnUiThread(()->{
                    startForegroundService(new Intent(this,AudioService.class).setAction(AudioService.START));
                    android.os.Handler handler=new android.os.Handler(android.os.Looper.getMainLooper());
                    String[] modes={"distortion","crush","overdrive","fuzz","roll","beatgrid","slip","overloop","off"};
                    for(int i=0;i<modes.length;i++){final String mode=modes[i];handler.postDelayed(()->{if(AudioService.isPlaying())startService(new Intent(this,AudioService.class).setAction(AudioService.FX).putExtra("mode",mode).putExtra("amount",.85).putExtra("division",4));},1500+i*1700L);}
                    String[] pads={"vinheta","backspin","tapestop","scratch"};
                    for(int i=0;i<pads.length;i++){final String pad=pads[i];handler.postDelayed(()->{if(AudioService.isPlaying())startService(new Intent(this,AudioService.class).setAction(AudioService.SAMPLER).putExtra("key",pad).putExtra("volume",.85));},2100+i*2200L);}
                    handler.postDelayed(this::finish,30000);
                });
            }catch(Exception e){
                getSharedPreferences("aura",MODE_PRIVATE).edit()
                    .putString("smokePCM","failed: "+e).apply();
            }
        },"AURA-PCM-smoke-fixtures").start();
    }
    private static void writePcm(File file,int freq,int seconds)throws IOException {
        int rate=48000,total=seconds*rate;
        byte[] data=new byte[4096*4];
        try(FileOutputStream out=new FileOutputStream(file)) {
            for(int start=0;start<total;start+=4096){
                int n=Math.min(4096,total-start);
                for(int i=0;i<n;i++){
                    double t=(start+i)/(double)rate;
                    short l=(short)(t<10?Math.sin(2*Math.PI*freq*t)*5200:0);
                    short r=(short)(t<10?Math.sin(2*Math.PI*(freq*1.01)*t)*5200:0);
                    int k=i*4;
                    data[k]=(byte)l;data[k+1]=(byte)(l>>8);
                    data[k+2]=(byte)r;data[k+3]=(byte)(r>>8);
                }
                out.write(data,0,n*4);
            }
        }
    }
}
