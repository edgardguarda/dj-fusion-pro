# EG MIX 11.5.2 — Live Recovery Beta

Correção dirigida aos três sintomas relatados na 11.5.1. Não é homologação acústica no celular.

* PCM: leitura estéreo PCM16 direta em blocos, polling de decoder mais curto, reutilização dos caches por URI e início progressivo após as três primeiras faixas válidas (ou toda a biblioteca se menor). Ordenação harmônica no grupo inicial, anexação das restantes durante o set sem reordenar o deck já tocando; a seleção global completa é possível quando toda a biblioteca foi analisada antes de Tocar. Análise em prioridade de fundo após início progressivo. Arquivos novos ainda precisam de decodificação e análise; não há promessa de latência fixa.
* Transição: busca do último áudio acima de limiar RMS, remoção de silêncio final do planejamento, sobreposição segura até 6s (ou duração de beatmatch planejada), reserva de tempo quando a proteção de underrun está ativa. Recuperações por falha e falta de NEXT continuam possíveis e são contadas separadamente. Não foi comprovado beatmatch perfeito.
* Samplers: carregamento PCM antes do primeiro bloco de áudio, caminho SoundPool auxiliar quando barramento PCM não está pronto, mensagem explícita de indisponibilidade. Efeitos rítmicos usam BPM de saída quando entrada é incerta. A interface expõe contadores reais de quadros alterados pelo FX, samples do sampler e transições; o PCM master mantém o limiter.
* Teste de integração Android: fixture sintética de três faixas com silêncio final e comandos reais do serviço para FX/samplers; contadores persistidos ao final. Não usa as músicas pessoais do usuário. O resultado no emulador deve ser consultado no registro da compilação.
* Testes locais: LiveRecoveryTest, core, smart studio, samplers, FX, segurança e assets. Os números de verificações são asserções de software, não testes físicos.
* Modelo HTDemucs incorporado e inalterado. Assinatura debug nova; preserve dados antes de substituir instalação incompatível.
