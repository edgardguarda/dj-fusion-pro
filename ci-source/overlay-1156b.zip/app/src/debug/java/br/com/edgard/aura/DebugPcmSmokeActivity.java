package br.com.edgard.aura;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import br.com.edgard.aura.core.TrackData;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.ArrayList;

/** Debug-only real AudioTrack smoke fixture. No microphone or external files. */
public final class DebugPcmSmokeActivity extends Activity {
    @Override public void onCreate(Bundle state){
        super.onCreate(state);
        new Thread(()->{
            try{
                ArrayList<TrackData> tracks=new ArrayList<>();
                for(int i=0;i<3;i++){
                    File file=new File(getFilesDir(),"aura-pcm-smoke-"+i+".pcm");
                    writePcm(file,220+i*110,12);
                    TrackData track=new TrackData("PCM smoke "+(i+1),file,48000,12*48000,120,.9,0,.12);
                    track.audibleEndSeconds=10;
                    // Distinct aligned synthetic WAV24 roles; original PCM remains available.
                    File folder=new File(TrackData.stemRoot(getFilesDir()),TrackData.stemKey(file,48000));
                    if(!folder.isDirectory()&&!folder.mkdirs())throw new IOException("fixture folder");
                    for(int k=0;k<4;k++)writeStem(new File(folder,TrackData.STEM_NAMES[k]+".wav"),220+i*110,k);
                    track.attachStems(folder);tracks.add(track);
                }
                SessionStore.save(this,tracks,0,0);
                getSharedPreferences("aura",MODE_PRIVATE).edit()
                    .putString("smokePCM","fixtures-created").putLong("pcm_buffer_misses",-1).apply();
                runOnUiThread(()->{
                    startForegroundService(new Intent(this,AudioService.class).setAction(AudioService.START));
                    android.os.Handler handler=new android.os.Handler(android.os.Looper.getMainLooper());
                    String[] modes={"distortion","crush","overdrive","fuzz","roll","beatgrid","slip","overloop","off"};
                    for(int i=0;i<modes.length;i++){final String mode=modes[i];handler.postDelayed(()->{if(AudioService.isPlaying())startService(new Intent(this,AudioService.class).setAction(AudioService.FX).putExtra("mode",mode).putExtra("amount",.85).putExtra("division",4));},1500+i*1700L);}
                    String[] pads={"vinheta","backspin","tapestop","scratch"};
                    for(int i=0;i<pads.length;i++){final String pad=pads[i];handler.postDelayed(()->{if(AudioService.isPlaying())startService(new Intent(this,AudioService.class).setAction(AudioService.SAMPLER).putExtra("key",pad).putExtra("volume",.85));},2100+i*2200L);}
                    handler.postDelayed(this::finish,30000);
                });
            }catch(Exception e){
                getSharedPreferences("aura",MODE_PRIVATE).edit()
                    .putString("smokePCM","failed: "+e).apply();
            }
        },"AURA-PCM-smoke-fixtures").start();
    }
    private static void le(java.io.OutputStream out,long n,int bytes)throws IOException{
        for(int k=0;k<bytes;k++)out.write((int)(n>>>(8*k))&255);
    }
    private static void writeStem(File file,int freq,int role)throws IOException{
        int n=12*44100;
        try(java.io.BufferedOutputStream out=new java.io.BufferedOutputStream(new FileOutputStream(file),65536)){
            out.write("RIFF".getBytes(java.nio.charset.StandardCharsets.US_ASCII));le(out,36L+n*6L,4);
            out.write("WAVEfmt ".getBytes(java.nio.charset.StandardCharsets.US_ASCII));le(out,16,4);le(out,1,2);le(out,2,2);le(out,44100,4);le(out,264600,4);le(out,6,2);le(out,24,2);
            out.write("data".getBytes(java.nio.charset.StandardCharsets.US_ASCII));le(out,n*6L,4);
            for(int i=0;i<n;i++){double t=i/44100.;for(int ch=0;ch<2;ch++)le(out,t<10?(int)(Math.sin(2*Math.PI*(freq+role*70)*(ch==0?1:1.01)*t)*350000):0,3);}
        }
    }
    private static void writePcm(File file,int freq,int seconds)throws IOException {
        int rate=48000,total=seconds*rate;
        byte[] data=new byte[4096*4];
        try(FileOutputStream out=new FileOutputStream(file)) {
            for(int start=0;start<total;start+=4096){
                int n=Math.min(4096,total-start);
                for(int i=0;i<n;i++){
                    double t=(start+i)/(double)rate;
                    short l=(short)(t<10?Math.sin(2*Math.PI*freq*t)*5200:0);
                    short r=(short)(t<10?Math.sin(2*Math.PI*(freq*1.01)*t)*5200:0);
                    int k=i*4;
                    data[k]=(byte)l;data[k+1]=(byte)(l>>8);
                    data[k+2]=(byte)r;data[k+3]=(byte)(r>>8);
                }
                out.write(data,0,n*4);
            }
        }
    }
}
