import br.com.edgard.aura.core.*;import java.io.*;import java.util.*;
public class SmartStudioTest {
 static int count;static void check(boolean x){count++;if(!x)throw new AssertionError("check "+count);}
 static TrackData t(String n,double bpm,String key){TrackData x=new TrackData(n,new File(n),44100,44100*180L,bpm,.8,0,.2);x.camelot=key;return x;}
 public static void main(String[] args)throws Exception{
 double[] c={6.35,2.23,3.48,2.33,4.38,4.09,2.52,5.19,2.39,3.66,2.29,2.88};check(HarmonicAnalyzer.classify(c).key.equals("8B"));check(HarmonicAnalyzer.classify(new double[12]).key.isEmpty());check(HarmonicAnalyzer.distance("12A","1A")<HarmonicAnalyzer.distance("12A","5A"));
 TrackData a=t("A",125,"8A"), b=t("B",125,"2B"),d=t("D",126,"9A"),e=t("E",140,"8A");List<TrackData> order=TrackPlanner.order(Arrays.asList(a,b,e,d));check(order.get(0)==a);check(order.get(1)==d);check(new HashSet<>(order).size()==4);
 TrackData weakIntro=new TrackData("weak",new File("weak"),44100,44100*180L,130,.25,0,.2,130,.8,0,136);
 TrackData close=t("close",132,""), far=t("far",122,"");check(TrackPlanner.order(Arrays.asList(weakIntro,far,close)).get(1)==close);
 check(TrackPlanner.plan(weakIntro,close,1,16).beatmatch);
 TrackData uncertain=new TrackData("uncertain",new File("uncertain"),44100,44100*180L,129.93,.25,0,.2,130,.25,0,136);
 check(TrackPlanner.order(Arrays.asList(uncertain,far,close)).get(1)==close);
 check(!TrackPlanner.plan(uncertain,close,1,16).beatmatch);
 TrackData disagrees=new TrackData("unreliable",new File("unreliable"),44100,44100*180L,130,.25,0,.2,86,.2,0,136);
 check(!TrackPlanner.plan(disagrees,close,1,16).beatmatch);
 for(int mode=1;mode<=4;mode++){MasterRhythmFx fx=new MasterRhythmFx(48000);float[] out=new float[2];for(int i=0;i<50000;i++)fx.process((float)Math.sin(i*.03),.3f,out);fx.configure(mode,4,120);boolean changed=false;for(int i=0;i<30000;i++){float v=(float)Math.sin(i*.017);fx.configure(mode,4,120);fx.process(v,.2f,out);check(Float.isFinite(out[0])&&Float.isFinite(out[1])&&Math.abs(out[0])<=1.001);changed|=Math.abs(out[0]-v)>.1;}check(changed);fx.configure(0,4,120);for(int i=0;i<3000;i++){fx.configure(0,4,120);fx.process(.1f,.2f,out);}check(Math.abs(out[0]-.1)<.001);}
 if(args.length>0)for(String f:args){File file=new File(f);HarmonicAnalyzer.Result key=HarmonicAnalyzer.analyze(file,44100,file.length()/4);System.out.println(f+": "+key.key+" confidence="+key.confidence);}
 System.out.println("PASS smart studio checks="+count);
 }
}
