import br.com.edgard.aura.core.*;
import java.io.*;import java.nio.file.*;import java.util.*;
public final class PerformanceAutodjTest {
 static int checks;
 static void check(boolean v,String m){checks++;if(!v)throw new AssertionError(m);}
 static TrackData t(String n,double bpm,String k){TrackData a=new TrackData(n,new File(n),48000,48000*180L,bpm,.85,0,.2);a.camelot=k;return a;}
 static String hash(byte[] b)throws Exception{return SourceFingerprint.sha256(new ByteArrayInputStream(b));}
 public static void main(String[] args)throws Exception{
   byte[] a={97,98,99},b={97,98,100};String h=hash(a);
   check(h.equals("ba7816bf8f01cfea414140de5dae2223b00361a396177a9cb410ff61f20015ad"),"known SHA-256");
   check(SourceFingerprint.matches(h,hash(a)),"same content");check(!SourceFingerprint.matches(h,hash(b)),"same size changed contents");
   check(!SourceFingerprint.matches("",h)&&!SourceFingerprint.matches(null,h),"legacy cache fails closed");
   try{hash(new byte[0]);throw new AssertionError("empty accepted");}catch(IOException expected){checks++;}
   try{SourceFingerprint.sha256(new InputStream(){public int read(){return 0;}public int read(byte[] a){return 0;}});throw new AssertionError("no progress accepted");}catch(IOException expected){checks++;}
   Thread.currentThread().interrupt();try{hash(a);throw new AssertionError("cancel ignored");}catch(InterruptedIOException expected){checks++;}finally{Thread.interrupted();}
   TrackData prev=t("played",130,"1A"),on=t("ON",126,"8A"),bad=t("far",148,"2B"),good=t("new",127,"9A");
   List<TrackData> queue=new ArrayList<>(Arrays.asList(prev,on,bad));check(!TrackPlanner.promoteBestNext(queue,1,128),"only one candidate");queue.add(good);
   check(TrackPlanner.promoteBestNext(queue,1,128),"new arrival chosen at safe boundary");check(queue.get(0)==prev&&queue.get(1)==on&&queue.get(2)==good&&queue.get(3)==bad,"prefix untouched; next selected");
   check(!TrackPlanner.promoteBestNext(queue,2,128),"already promoted deck preserved");
   check(!TrackPlanner.promoteBestNext(queue,3,128),"end of set");
   Random rng=new Random(1155);
   for(int n=2;n<=300;n++){
     List<TrackData> x=new ArrayList<>();for(int i=0;i<n;i++)x.add(t("track"+i,80+rng.nextInt(88),(1+rng.nextInt(12))+(rng.nextBoolean()?"A":"B")));
     Set<TrackData> all=new HashSet<>(x);List<TrackData> played=new ArrayList<>();int first=n/4;for(int i=0;i<=first;i++)played.add(x.get(i));
     double best=Double.POSITIVE_INFINITY;TrackData expected=null;for(int i=first+1;i<Math.min(n,first+1+128);i++){double cost=TrackPlanner.compatibility(x.get(first),x.get(i))+.005*(i-first-1);if(cost<best){best=cost;expected=x.get(i);}}
     TrackPlanner.promoteBestNext(x,first,128);check(x.get(first+1)==expected,"best bounded candidate");check(x.subList(0,first+1).equals(played),"played prefix fixed");check(x.size()==n&&new HashSet<>(x).equals(all),"no track lost or duplicated");
   }
   for(int i=1;i<=12;i++)for(int j=1;j<=12;j++)for(String m:new String[]{"A","B"})for(String n:new String[]{"A","B"}){
     int d=Math.min(Math.abs(i-j),12-Math.abs(i-j));double want=d==0?(m.equals(n)?0:.15):m.equals(n)&&d==1?.25:2+.3*d;
     check(HarmonicAnalyzer.distance(i+m,j+n)==want,"Camelot distance equivalence");
   }
   for(String k:new String[]{"",null,"0A","01A","13A","1a","8C","A","8AA","123A"})check(HarmonicAnalyzer.distance(k,"8A")==1.2,"unknown key");
   System.out.println("PASS performance-autodj: "+checks+" checks; exact source identity, bounded dynamic ranking, immutable played prefix, Camelot equivalence");
 }
}
