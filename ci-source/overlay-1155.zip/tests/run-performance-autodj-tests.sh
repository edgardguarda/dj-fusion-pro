#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")/.."
mkdir -p build-performance-autodj
javac -encoding UTF-8 -d build-performance-autodj app/src/main/java/br/com/edgard/aura/core/{SourceFingerprint,TrackData,StemStorage,TrackPlanner,HarmonicAnalyzer}.java tests/PerformanceAutodjTest.java
java -cp build-performance-autodj PerformanceAutodjTest
