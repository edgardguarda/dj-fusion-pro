#!/usr/bin/env python3
"""Structural regression: keep deck setup out of AudioTrack's render loop."""
from pathlib import Path
root=Path(__file__).resolve().parent.parent
service=(root/'app/src/main/java/br/com/edgard/aura/AudioService.java').read_text()
preparer=(root/'app/src/main/java/br/com/edgard/aura/core/AsyncDeckPreparer.java').read_text()
recorder=(root/'app/src/main/java/br/com/edgard/aura/AsyncWavRecorder.java').read_text()
loop=service.split('while(running.get()){',1)[1]
checks={
    'next deck planning exclusively background': 'TrackPlanner.plan(' not in service,
    'no new PCM deck after render loop starts': 'new BufferedPcmDeck(' not in loop,
    'asynchronous handoff launched': 'requestRankedNext(nextPreparer,' in service and 'preparer.request(tracks.get(idx),tracks.get(idx+1),rate,beats)' in service,
    'background handoff worker': 'AURA-PCM-handoff-prepare' in preparer,
    'cancelled preparations discarded': 'request.generation!=generation' in preparer,
    'handoff state only cleared for matching request': 'pendingGeneration.compareAndSet(request.generation,-1)' in preparer,
    'stale results rejected on handoff': 'result.generation!=generation' in preparer,
    'physical AudioTrack underruns exposed': 'audio.getUnderrunCount()' in service,
    'empty WAV never marked exportable': 'pending.length()>44' in recorder and 'StandardCopyOption.ATOMIC_MOVE' in recorder,
    'recording available only after finalization': 'putString("lastMaster"' in service and 'onCompleted.run()' in recorder,
}
for label,ok in checks.items():print(('PASS' if ok else 'FAIL'),label)
if not all(checks.values()):raise SystemExit('Audio-thread release gate failed')
