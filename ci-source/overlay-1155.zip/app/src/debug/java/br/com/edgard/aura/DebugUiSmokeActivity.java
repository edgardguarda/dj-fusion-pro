package br.com.edgard.aura;
import android.app.Activity;
import android.os.Bundle;
import android.content.Intent;
import android.net.Uri;
import android.webkit.WebView;
import br.com.edgard.aura.core.TrackData;
import br.com.edgard.aura.core.PcmSessionCache;
import java.io.*;
import java.util.*;
import org.json.JSONArray;
/** Shell-only debug fixture: no direct service commands; UI controls are exercised via the local WebView. */
public final class DebugUiSmokeActivity extends Activity {
    @Override public void onCreate(Bundle state){
        super.onCreate(state);
        new Thread(()->{try{
            ArrayList<TrackData> cache=new ArrayList<>();JSONArray uris=new JSONArray(),names=new JSONArray();
            final int hz=48000,seconds=15;
            for(int k=0;k<3;k++){
                String name="UI test "+(k+1)+".wav";
                File wav=new File(getFilesDir(),name);File pcm=k<2?new File(PcmSessionCache.create(getFilesDir()),"cached.pcm"):null;
                try(WavWriter w=new WavWriter(wav,hz);OutputStream raw=pcm==null?null:new FileOutputStream(pcm)){
                    byte[] buf=new byte[4096*4];for(int start=0;start<hz*seconds;start+=4096){int count=Math.min(4096,hz*seconds-start);
                        for(int i=0;i<count;i++){double t=(start+i)/(double)hz;double beat=Math.exp(-12*(t%.5));
                            short l=(short)(t<13?Math.sin(2*Math.PI*(220+55*k)*t)*(3000+6500*beat):0);
                            short r=(short)(t<13?Math.sin(2*Math.PI*(221+55*k)*t)*(3000+6500*beat):0);int o=i*4;
                            buf[o]=(byte)l;buf[o+1]=(byte)(l>>8);buf[o+2]=(byte)r;buf[o+3]=(byte)(r>>8);}
                        w.write(buf,count*4);if(raw!=null)raw.write(buf,0,count*4);}}
                String uri=Uri.fromFile(wav).toString();uris.put(uri);names.put(name);
                if(pcm!=null){TrackData t=new TrackData(name,pcm,hz,hz*seconds,120,.9,0,.15);t.sourceUri=uri;try(InputStream in=new FileInputStream(wav)){t.sourceHash=br.com.edgard.aura.core.SourceFingerprint.sha256(in);}
                    // Change one original without changing its size; stale PCM must never be reused.
                    if(k==1)try(RandomAccessFile rw=new RandomAccessFile(wav,"rw")){rw.seek(100);int old=rw.read();rw.seek(100);rw.write(old^1);}
                    t.audibleEndSeconds=13;t.camelot="8A";t.keyConfidence=.8;cache.add(t);}
            }
            SessionStore.save(this,cache,0,16);
            getSharedPreferences("aura",MODE_PRIVATE).edit().putString("fastUris",uris.toString()).putString("fastNames",names.toString()).putString("uiFixture","ready").commit();
            runOnUiThread(()->{WebView.setWebContentsDebuggingEnabled(true);startActivity(new Intent(this,MainActivity.class));finish();});
        }catch(Exception ex){android.util.Log.e("EGMIX_UI_TEST","fixture failed",ex);}} ,"EGMIX-ui-fixture").start();
    }
}
