package br.com.edgard.aura.core;
import java.io.*;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
/** Exact encoded source identity, independent of URI or unreliable provider timestamps. */
public final class SourceFingerprint {
    private SourceFingerprint(){}
    public static String sha256(InputStream in)throws IOException{
        if(in==null)throw new IOException("Arquivo original indisponível");
        try {
            MessageDigest md=MessageDigest.getInstance("SHA-256");
            byte[] buf=new byte[128*1024];int n,empty=0;long bytes=0;
            while(true){
                if(Thread.currentThread().isInterrupted())throw new InterruptedIOException("Análise cancelada");
                n=in.read(buf);if(n<0)break;
                if(n==0){if(++empty>=16)throw new IOException("Arquivo sem progresso");continue;}
                empty=0;md.update(buf,0,n);bytes+=n;
            }
            if(bytes==0)throw new IOException("Arquivo vazio");
            char[] out=new char[64],hex="0123456789abcdef".toCharArray();int i=0;
            for(byte b:md.digest()){out[i++]=hex[(b&255)>>>4];out[i++]=hex[b&15];}
            return new String(out);
        }catch(NoSuchAlgorithmException e){throw new IOException(e);}
    }
    public static boolean matches(String expected,String actual){
        return expected!=null&&actual!=null&&expected.length()==64&&expected.matches("[0-9a-f]{64}")&&expected.equals(actual);
    }
}
