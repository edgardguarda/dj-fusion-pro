package br.com.edgard.aura.core;

import java.io.*;
import java.util.*;

/** Conservative onset-envelope estimator. No fabricated vocal, phrase or downbeat labels. */
public final class BeatAnalyzer {
    public static final class Result {
        public final double bpm,phase,confidence,rms;
        Result(double bpm,double phase,double confidence,double rms){this.bpm=bpm;this.phase=phase;this.confidence=confidence;this.rms=rms;}
    }
    public static Result analyze(File pcm,int rate)throws IOException {
        final int hop=512;
        // First 75 seconds: enough for most intros, bounded analysis cost.
        final int count=(int)Math.min(pcm.length()/4/hop,(long)(75.0*rate/hop));
        if(count<100)return new Result(0,0,0,0.1);
        double[] env=new double[count];
        double sum=0;long samples=0;
        try(BufferedInputStream in=new BufferedInputStream(new FileInputStream(pcm),1<<16)){
            byte[] chunk=new byte[hop*4];double previous=0;
            for(int i=0;i<count;i++){
                if(Thread.currentThread().isInterrupted())throw new InterruptedIOException("Cancelado");
                int got=0;while(got<chunk.length){int n=in.read(chunk,got,chunk.length-got);if(n<0)break;got+=n;}
                if(got<chunk.length)break;
                double e=0;
                for(int j=0;j<got;j+=4){
                    short l=(short)((chunk[j]&255)|(chunk[j+1]<<8));
                    short r=(short)((chunk[j+2]&255)|(chunk[j+3]<<8));
                    double lv=l/32768.0,rv=r/32768.0;
                    double energy=(lv*lv+rv*rv)*.5;e+=energy;sum+=energy;samples++;
                }
                double root=Math.sqrt(e/hop);
                env[i]=Math.max(0,root-previous*0.82);
                previous=root;
            }
        }
        return analyzeEnvelope(env,hop/(double)rate,Math.sqrt(sum/Math.max(1,samples)));
    }
    /** Independent rhythmic estimate for a bounded portion near the real transition. 
     * Phase is returned in GLOBAL source time, not relative to the analysis window. */
    public static Result analyzeRange(File pcm,int rate,double fromSeconds,double seconds)throws IOException {
        if(rate<=0)throw new IllegalArgumentException("Sample rate inválido");
        long total=pcm.length()/4;
        long begin=Math.max(0,Math.min(total,(long)Math.floor(fromSeconds*rate)));
        int hop=512;
        int count=(int)Math.min((total-begin)/hop,Math.floor(seconds*rate/hop));
        if(count<100)return new Result(0,0,0,0);
        double[] env=new double[count];double sum=0;long samples=0;
        try(FileInputStream source=new FileInputStream(pcm);DataInputStream in=new DataInputStream(new BufferedInputStream(source,1<<16))){
            source.getChannel().position(begin*4);byte[] chunk=new byte[hop*4];double previous=0;
            for(int i=0;i<count;i++){
                if(Thread.currentThread().isInterrupted())throw new InterruptedIOException("Cancelado");
                in.readFully(chunk);
                double e=0;
                for(int j=0;j<chunk.length;j+=4){
                    short l=(short)((chunk[j]&255)|(chunk[j+1]<<8));
                    short r=(short)((chunk[j+2]&255)|(chunk[j+3]<<8));
                    double lv=l/32768.0,rv=r/32768.0;
                    double energy=(lv*lv+rv*rv)*.5;e+=energy;sum+=energy;samples++;
                }
                double root=Math.sqrt(e/hop);
                env[i]=Math.max(0,root-previous*.82);
                previous=root;
            }
        }
        Result local=analyzeEnvelope(env,hop/(double)rate,Math.sqrt(sum/Math.max(1,samples)));
        double period=local.bpm>0?60/local.bpm:1;
        double phase=((begin/(double)rate+local.phase)%period+period)%period;
        return new Result(local.bpm,phase,local.confidence,local.rms);
    }
    /** Measured entrance cue; never skip to a hypothetical chorus/drop. */
    public static double firstAudible(File pcm,int rate) throws IOException {
        int hop=2048;int max=(int)Math.min(pcm.length()/4/hop,Math.max(1,rate*25L/hop));
        int streak=0;
        try(BufferedInputStream in=new BufferedInputStream(new FileInputStream(pcm),1<<15)){
            byte[] buf=new byte[hop*4];
            for(int i=0;i<max;i++){
                int got=0;while(got<buf.length){int n=in.read(buf,got,buf.length-got);if(n<0)break;got+=n;}
                if(got<buf.length)break;
                double sum=0;
                for(int j=0;j<buf.length;j+=4){
                    short l=(short)((buf[j]&255)|(buf[j+1]<<8));
                    short r=(short)((buf[j+2]&255)|(buf[j+3]<<8));
                    double lv=l/32768.0,rv=r/32768.0;
                    sum+=(lv*lv+rv*rv)*.5;
                }
                double rms=Math.sqrt(sum/hop);
                if(rms>0.008){if(++streak>=3)return Math.max(0,(i-streak+1)*hop/(double)rate-.07);}
                else streak=0;
            }
        }
        return 0;
    }
    /** Estimate end of audible music, excluding appended silence. Read bounded tail blocks only. */
    public static double lastAudible(File pcm,int rate,long frames)throws IOException{
        final int hop=Math.max(512,rate/20), block=hop*16;
        final long lower=Math.max(0,frames-rate*45L);
        byte[] buf=new byte[block*4];int streak=0;long first=frames;
        try(RandomAccessFile in=new RandomAccessFile(pcm,"r")){
            long end=frames;while(end>lower){
                if(Thread.currentThread().isInterrupted())throw new InterruptedIOException("Cancelado");
                long start=Math.max(lower,end-block);int n=(int)(end-start);in.seek(start*4);in.readFully(buf,0,n*4);
                for(int hi=n;hi>=hop;hi-=hop){int lo=hi-hop;double sum=0;
                    for(int j=lo*4;j<hi*4;j+=4){double l=(short)((buf[j]&255)|(buf[j+1]<<8))/32768.0,r=(short)((buf[j+2]&255)|(buf[j+3]<<8))/32768.0;sum+=(l*l+r*r)*.5;}
                    if(Math.sqrt(sum/hop)>.012){if(streak++==0)first=start+hi;if(streak>=3)return Math.min(frames,first+hop)/(double)rate;}else streak=0;
                }
                end=start;
            }
        }
        return frames/(double)rate;
    }
    public static Result analyzeEnvelope(double[] env,double dt,double rms){
        int n=env.length;if(n<100)return new Result(0,0,0,rms);
        double mean=0;for(double v:env)mean+=v;mean/=n;
        // An uninterrupted sine/pad can exhibit tiny hop-RMS ripples that the
        // autocorrelation mistakes for beats. Ignore the first decoder-start
        // frame and demand a substantial dynamic onset envelope.
        int warmup=Math.min(8,n/10);
        double steadyMean=0,variance=0;
        for(int i=warmup;i<n;i++)steadyMean+=env[i];
        steadyMean/=Math.max(1,n-warmup);
        for(int i=warmup;i<n;i++){
            double delta=env[i]-steadyMean;variance+=delta*delta;
        }
        double dynamics=Math.sqrt(variance/Math.max(1,n-warmup))/Math.max(1e-8,steadyMean);
        if(steadyMean<1e-6 || dynamics<0.14)return new Result(0,0,0,rms);
        double[] onset=new double[n];for(int i=1;i<n-1;i++)onset[i]=Math.max(0,env[i]-mean)*((env[i]>env[i-1]&&env[i]>=env[i+1])?1:0.12);
        double best=-1;int lagBest=0;
        // Include beat level + quarter subdivision; prefer direct beats for dance music.
        for(int bpm=76;bpm<=170;bpm++){
            double expected=60.0/bpm/dt;
            int lag=(int)Math.round(expected);
            double sum=0,scale=0;
            for(int i=lag;i<n;i++) {sum+=onset[i]*onset[i-lag];scale+=onset[i]*onset[i];}
            double s=sum/(scale+1e-10);
            if(s>best){best=s;lagBest=lag;}
        }
        if(lagBest==0 || best<0.10)return new Result(0,0,0,rms);
        // Refinement: centroid around the optimum (lags are quantized at ~10 ms).
        int picked=lagBest;double max=best;
        for(int lag=Math.max(1,lagBest-1);lag<=lagBest+1;lag++){
            double s=0,w=0;for(int i=lag;i<n;i++){s+=onset[i]*onset[i-lag];w+=onset[i]*onset[i];}
            double v=s/(w+1e-10);if(v>max){max=v;picked=lag;}
        }
        double bpm=60/(picked*dt);
        double[] buckets=new double[picked];
        for(int i=0;i<n;i++)buckets[i%picked]+=onset[i];
        int peak=0;for(int i=1;i<picked;i++)if(buckets[i]>buckets[peak])peak=i;
        double confidence=MixMath.clamp((max-0.10)/0.55,0,1);
        // Silence and sustained music should not produce false grid confidence.
        double second=0;for(int i=0;i<picked;i++)if(Math.abs(i-peak)>2&&Math.abs(i-peak)<picked-2)second=Math.max(second,buckets[i]);
        double contrast=(buckets[peak]-second)/Math.max(1e-9,buckets[peak]);
        confidence*=MixMath.clamp(contrast*5,0,1);
        // Comb-search across the full 75 s prevents 512-frame quantization from
        // accumulating beat drift. Quantized autocorrelation is only a prior.
        double maxOnset=0;
        for(double o:onset)maxOnset=Math.max(maxOnset,o);
        double[] peakTime=new double[n],peakWeight=new double[n];int count=0;
        for(int i=2;i<n-2;i++){
            if(onset[i]>=maxOnset*0.13 && onset[i]>onset[i-1] && onset[i]>=onset[i+1]){
                peakTime[count]=i*dt;peakWeight[count]=Math.sqrt(onset[i]);count++;
            }
        }
        if(count<14)return new Result(bpm,peak*dt,confidence*.45,rms);
        double[] phaseBins=new double[64];double bestScore=-1,bestTempo=bpm;
        int bestBin=0;
        for(double candidate=Math.max(75,bpm*.955);candidate<=Math.min(171,bpm*1.045);candidate+=0.01){
            Arrays.fill(phaseBins,0);
            double period=60/candidate;
            for(int j=0;j<count;j++){
                double frac=peakTime[j]/period;
                frac-=Math.floor(frac);
                int bin=(int)Math.floor(frac*64)%64;
                phaseBins[bin]+=peakWeight[j];
            }
            double score=0;int chosen=0;
            for(int i=0;i<64;i++){
                double x=phaseBins[(i+63)%64]+phaseBins[i]+phaseBins[(i+1)%64];
                if(x>score){score=x;chosen=i;}
            }
            if(score>bestScore){bestScore=score;bestTempo=candidate;bestBin=chosen;}
        }
        double period=60/bestTempo;
        double phase=period*(bestBin+0.5)/64.0;
        int beatCount=(int)(n*dt/period)+5;
        double[] strongest=new double[beatCount],times=new double[beatCount];
        for(int j=0;j<count;j++){
            long ix=Math.round((peakTime[j]-phase)/period)+1;
            if(ix<0||ix>=beatCount)continue;
            double predicted=phase+(ix-1)*period;
            if(Math.abs(peakTime[j]-predicted)>0.11*period)continue;
            int index=(int)ix;
            if(peakWeight[j]>strongest[index]){strongest[index]=peakWeight[j];times[index]=peakTime[j];}
        }
        double sw=0,sx=0,sy=0,sxx=0,sxy=0;int matched=0;
        for(int i=0;i<beatCount;i++)if(strongest[i]>0){
            double w=strongest[i],k=i-1,y=times[i];
            sw+=w;sx+=w*k;sy+=w*y;sxx+=w*k*k;sxy+=w*k*y;matched++;
        }
        double denom=sw*sxx-sx*sx;
        if(matched>=14&&Math.abs(denom)>1e-7){
            double slope=(sw*sxy-sx*sy)/denom;
            double intercept=(sy-slope*sx)/sw;
            if(slope>period*.975&&slope<period*1.025){
                double fine=60/slope;
                double finePhase=(intercept%slope+slope)%slope;
                // The phase is trustworthy only when many real onsets support it.
                double coverage=matched/(double)Math.max(1,Math.round(n*dt/slope));
                double weightedResidual=0;
                for(int ix=0;ix<beatCount;ix++)if(strongest[ix]>0){
                    weightedResidual+=strongest[ix]*Math.abs(times[ix]-(intercept+slope*(ix-1)));
                }
                weightedResidual/=Math.max(1e-10,sw);
                double precision=MixMath.clamp(1-weightedResidual/(.075*slope),0,1);
                double autocorrelationStrength=MixMath.clamp((max-.08)/.52,0,1);
                double agreement=MixMath.clamp(coverage*1.08,0,1);
                // Do not rely on a single coarse phase-bin contrast: a very
                // accurate beat lattice can straddle adjacent histogram bins.
                double verifiedConfidence=(.24+.76*autocorrelationStrength)*agreement*precision;
                // A strong offbeat at half a period can look just as coherent
                // as the real beat. Likewise, a 155 BPM kick may be detected
                // as 77.5 BPM if every other kick becomes the selected beat.
                // Do not claim a reliable phase when both lattices have
                // substantial onset support: prefer a safe crossfade.
                double beatSupport=0,halfBeatSupport=0;
                for(int j=0;j<count;j++){
                    double location=(peakTime[j]-finePhase)/slope;
                    if(Math.abs(location-Math.rint(location))<.11)
                        beatSupport+=peakWeight[j];
                    if(Math.abs(location-.5-Math.rint(location-.5))<.11)
                        halfBeatSupport+=peakWeight[j];
                }
                double alternateRatio=halfBeatSupport/Math.max(1e-9,beatSupport);
                double trustworthy=Math.max(confidence*.5,verifiedConfidence);
                if(alternateRatio>=.70)trustworthy=Math.min(trustworthy,.25);
                return new Result(fine,finePhase,trustworthy,rms);
            }
        }
        return new Result(bestTempo,phase,Math.min(0.25,confidence),rms);
    }
}
