package br.com.edgard.aura.core;

import java.util.ArrayList;
import java.util.List;

/** Lightweight planner that never claims harmonic/phrase evidence it does not measure. */
public final class TrackPlanner {
    public static final class Handoff {
        public final boolean beatmatch,phraseAligned;
        public final double rateNext;
        public final int beats;
        public final double durationSeconds;
        public final double startASeconds;
        public final double cueBSeconds;
        public final String reason;
        Handoff(boolean beatmatch,double rateNext,int beats,double durationSeconds,double startASeconds,double cueBSeconds,String reason){
            this(beatmatch,false,rateNext,beats,durationSeconds,startASeconds,cueBSeconds,reason);
        }
        Handoff(boolean beatmatch,boolean phraseAligned,double rateNext,int beats,double durationSeconds,double startASeconds,double cueBSeconds,String reason){
            this.beatmatch=beatmatch;this.phraseAligned=phraseAligned;this.rateNext=rateNext;this.beats=beats;this.durationSeconds=durationSeconds;
            this.startASeconds=startASeconds;this.cueBSeconds=cueBSeconds;this.reason=reason;
        }
    }
    /** Selects compatible next music if the requested order is not explicitly fixed. */
    public static List<TrackData> order(List<TrackData> tracks){
        ArrayList<TrackData> remain=new ArrayList<>(tracks),out=new ArrayList<>();
        if(remain.isEmpty())return out;
        out.add(remain.remove(0));
        while(!remain.isEmpty()){
            TrackData last=out.get(out.size()-1);int best=0;double score=Double.POSITIVE_INFINITY;
            for(int i=0;i<Math.min(128,remain.size());i++){
                TrackData next=remain.get(i);
                double cost=compatibility(last,next);
                cost+=0.005*i;
                if(cost<score){score=cost;best=i;}
            }
            out.add(remain.remove(best));
        }
        return out;
    }
    /** Score is identical for initial planning and progressive deck selection. */
    public static double compatibility(TrackData last,TrackData next){
        // Evaluate actual handoff endpoints, not just the introductions.
        boolean exitKnown=last.tailConfidence>=.30&&validTempo(last.tailBpm);
        boolean exitTentative=!exitKnown&&!last.trustworthyTempo()&&agreeingWeakTempo(last);
        double exit=(exitKnown||exitTentative)?last.tailBpm:last.bpm;
        boolean exitUsable=exitKnown||last.trustworthyTempo()||exitTentative;
        boolean entryTentative=!next.trustworthyTempo()&&agreeingWeakTempo(next);
        boolean entryUsable=next.trustworthyTempo()||entryTentative;
        double mismatch=exitUsable&&entryUsable?Math.abs(Math.log(exit/next.bpm)):0;
        // Weak but mutually consistent head/tail BPM may rank the queue;
        // it never relaxes the independent high-confidence sync gate below.
        double cost=exitUsable&&entryUsable?mismatch*20+(exitTentative||entryTentative?.8:0):5;
        if(exitUsable&&entryUsable&&mismatch>Math.log(1.04))cost+=exitTentative||entryTentative?1.5:3;
        // Favor a candidate whose own exit can be used for the following blend.
        if(next.tailConfidence<.30)cost+=.6;
        cost+=HarmonicAnalyzer.distance(last.camelot,next.camelot);
        if(last.rms>0&&next.rms>0)cost+=Math.min(1,Math.abs(Math.log(last.rms/next.rms))*.35);
        return cost;
    }
    /** Renderer boundary only: choose from a bounded lookahead, never modify played/current decks. */
    public static boolean promoteBestNext(List<TrackData> tracks,int current,int lookahead){
        if(current<0||current>=tracks.size()-1||lookahead<1)return false;
        int first=current+1,best=first,limit=first+Math.min(lookahead,tracks.size()-first);
        double score=Double.POSITIVE_INFINITY;
        for(int i=first;i<limit;i++){
            double cost=compatibility(tracks.get(current),tracks.get(i))+.005*(i-first);
            if(cost<score){score=cost;best=i;}
        }
        if(best==first)return false;
        java.util.Collections.swap(tracks,first,best);return true;
    }
    private static boolean validTempo(double bpm){return Double.isFinite(bpm)&&bpm>=75&&bpm<=170;}
    private static boolean agreeingWeakTempo(TrackData t){return validTempo(t.bpm)&&validTempo(t.tailBpm)&&t.confidence>=.18&&t.tailConfidence>=.18&&Math.abs(Math.log(t.bpm/t.tailBpm))<.015;}
    /** A is already playing at an independently chosen fixed rate, B is not. */
    public static Handoff plan(TrackData a,TrackData b,double rateA,int requestedBeats){
        final boolean tempoConsistent = a.bpm>0 && a.tailBpm>0 &&
            Math.abs(Math.log(a.bpm/a.tailBpm))<0.006;
        final boolean verifiedA = a.tailBpm>=75 && a.tailBpm<=170 &&
            a.tailConfidence>=.40 && tempoConsistent;
        final boolean verifiedB = b.trustworthyTempo() && b.confidence>=.40;
        final double target = a.tailBpm*rateA;
        final double targetRate = verifiedA && verifiedB ? target/b.bpm : 1;
        final boolean aligned=verifiedA && verifiedB && targetRate>=.96 && targetRate<=1.04 &&
            rateA>=.96 && rateA<=1.04 && a.duration()>=30 && b.duration()>=20;
        int beats=requestedBeats>0?requestedBeats:16;
        // Uncertified downbeats: cap automatic blends to 16 beats. The user may
        // select longer lengths, but those still need independent tail/head evidence.
        if(aligned){
            double fade=beats*60.0/target;
            double periodA=60.0/a.tailBpm;
            double periodB=60.0/b.bpm;
            double latestA=a.audibleEnd()-(fade+.30)*rateA;
            double phase=a.tailPhaseSeconds;
            double beatIndex=Math.floor((latestA-phase)/(4*periodA));
            double atA=phase+4*Math.max(0,beatIndex)*periodA;
            double cueB=b.phaseSeconds;
            if(b.introCueSeconds>cueB)cueB+=Math.ceil((b.introCueSeconds-cueB)/periodB)*periodB;
            boolean phrased=false;
            // Structural boundary is a *hypothesis*, never a certified downbeat.
            // Only use the paired entry/outro if both confidence values are high.
            if(a.phraseOutroConfidence>=.65 && b.phraseIntroConfidence>=.65 &&
               a.phraseOutroSeconds>=Math.max(3,a.tailStartSeconds) &&
               a.phraseOutroSeconds<=latestA &&
               b.phraseIntroSeconds>=b.introCueSeconds &&
               b.phraseIntroSeconds<=24 &&
               b.phraseIntroSeconds+fade*targetRate<b.duration()-.08){
                atA=a.phraseOutroSeconds;
                cueB=b.phraseIntroSeconds;
                phrased=true;
            }
            if(atA>=Math.max(3,a.tailStartSeconds) && atA+fade*rateA<a.audibleEnd()-0.08 &&
               cueB>=0 && cueB+fade*targetRate<b.duration()-0.08){
                return new Handoff(true,phrased,targetRate,beats,fade,atA,cueB,
                    phrased ? "Transição por hipótese de frase 4/4 com confiança alta (não certifica downbeat)" :
                    "BPM e fase estimados separadamente; fraseado sem confiança suficiente");
            }
        }
        // Always use an audible multi-second overlap, never the 0.23 s 'handoff'.
        double safe=Math.min(6.0,Math.max(2.4,Math.min(a.audibleEnd(),b.duration())*.065));
        double start=Math.max(0,a.audibleEnd()-safe*rateA-.40*rateA);
        double cue=Math.max(0,Math.min(b.introCueSeconds,b.duration()*.15));
        return new Handoff(false,1,0,safe,start,cue,
                "Sobreposição protegida; batidas e/ou andamento não foram comprovados");
    }
}
