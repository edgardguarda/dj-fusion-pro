package br.com.edgard.aura.core;
import java.io.*;
/** Bounded PCM chroma estimator. Unknown keys remain unknown. */
public final class HarmonicAnalyzer {
 public static final class Result {public final String key; public final double confidence; public Result(String k,double c){key=k;confidence=c;}}
 private static final double[] MAJ={6.35,2.23,3.48,2.33,4.38,4.09,2.52,5.19,2.39,3.66,2.29,2.88}, MIN={6.33,2.68,3.52,5.38,2.60,3.53,2.54,4.75,3.98,2.69,3.34,3.17};
 private static final String[] CM={"8B","3B","10B","5B","12B","7B","2B","9B","4B","11B","6B","1B"}, CN={"5A","12A","7A","2A","9A","4A","11A","6A","1A","8A","3A","10A"};
 public static Result classify(double[] chroma){double sum=0;for(double x:chroma)sum+=x;if(sum<=1e-9)return new Result("",0);double best=-2,second=-2;String key="";for(int mode=0;mode<2;mode++)for(int root=0;root<12;root++){double a=0,b=0,c=0;double[] p=mode==0?MAJ:MIN;double mean=0;for(double v:p)mean+=v/12;for(int i=0;i<12;i++){double x=chroma[(root+i)%12]-sum/12,y=p[i]-mean;a+=x*y;b+=x*x;c+=y*y;}double score=b>0?a/Math.sqrt(b*c):0;if(score>best){second=best;best=score;key=(mode==0?CM:CN)[root];}else second=Math.max(second,score);}double conf=Math.max(0,Math.min(1,(best-second)*4));return new Result(best>=.52&&conf>=.12?key:"",conf);}
 public static Result analyze(File file,int hz,long frames)throws IOException{if(hz<8000||frames<hz)return new Result("",0);int n=2048, dec=Math.max(1,hz/11025),raw=n*dec;double rate=hz/(double)dec;double[] chroma=new double[12],x=new double[n],coef=new double[48],win=new double[n];byte[] bytes=new byte[raw*4];for(int j=0;j<48;j++)coef[j]=2*Math.cos(2*Math.PI*440*Math.pow(2,(j+36-69)/12.0)/rate);for(int j=0;j<n;j++)win[j]=.5-.5*Math.cos(2*Math.PI*j/(n-1));try(RandomAccessFile in=new RandomAccessFile(file,"r")){for(int w=0;w<48;w++){if(Thread.currentThread().isInterrupted())throw new InterruptedIOException();long pos=Math.max(0,Math.min(frames-raw,Math.round(frames*(.08+.84*w/47.0))));if(pos+raw>frames)continue;in.seek(pos*4);in.readFully(bytes);double rms=0;for(int i=0;i<n;i++){double s=0;for(int k=0;k<dec;k++){int o=(i*dec+k)*4;short l=(short)((bytes[o]&255)|(bytes[o+1]<<8)),r=(short)((bytes[o+2]&255)|(bytes[o+3]<<8));s+=(l+r)/65536.0;}s/=dec;rms+=s*s;x[i]=s*win[i];}if(rms/n<1e-5)continue;double[] local=new double[12];double total=0;for(int j=0;j<48;j++){double q=0,q1=0,q2=0;for(double s:x){q=s+coef[j]*q1-q2;q2=q1;q1=q;}double e=Math.sqrt(Math.max(0,q1*q1+q2*q2-coef[j]*q1*q2));local[j%12]+=e;total+=e;}if(total>0)for(int j=0;j<12;j++)chroma[j]+=local[j]/total;}}return classify(chroma);}
 private static int camelot(String key){
  if(key==null||key.length()<2||key.length()>3)return -1;
  int last=key.length()-1;char mode=key.charAt(last);if(mode!='A'&&mode!='B')return -1;
  int n=key.charAt(0)-'0';if(n<1||n>9)return -1;
  if(last==2){int digit=key.charAt(1)-'0';if(n!=1||digit<0||digit>2)return -1;n=10+digit;}
  return (n-1)*2+(mode=='B'?1:0);
 }
 public static double distance(String a,String b){int x=camelot(a),y=camelot(b);if(x<0||y<0)return 1.2;boolean same=(x&1)==(y&1);int d=Math.abs(x/2-y/2);d=Math.min(d,12-d);return d==0?(same?0:.15):same&&d==1?.25:2.0+.3*d;}
}
