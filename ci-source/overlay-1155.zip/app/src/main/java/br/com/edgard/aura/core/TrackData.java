package br.com.edgard.aura.core;

import java.io.File;

/** Audio already decoded to interleaved little-endian stereo PCM16. */
public final class TrackData {
    public final String title;
    public double audibleEndSeconds=0;
    public double audibleEnd(){return Double.isFinite(audibleEndSeconds)&&audibleEndSeconds>2?Math.min(duration(),audibleEndSeconds):duration();}
    public String camelot=""; public double keyConfidence=0; public String sourceUri=""; public String sourceHash="";
    private static final java.util.concurrent.atomic.AtomicLong IDS=new java.util.concurrent.atomic.AtomicLong();
    public final long stemToken=IDS.incrementAndGet();
    private volatile int stemGains=0x64646464;
    private File stemFolder;
    public void attachStems(File folder) throws java.io.IOException {
        if(!nativeStemRate(sampleRate))throw new java.io.IOException("Stems nativos exigem faixa original 44,1 ou 48 kHz");
        validateStems(folder,stemFrames(frames,sampleRate));stemFolder=folder;
    }
    public File stemFolder(){return stemFolder;}
    public int stemGains(){return stemGains;}
    public synchronized void setStemGain(int role,int percent){
        if(role<0||role>3||percent<0||percent>100||stemFolder==null)return;
        int shift=role*8;stemGains=(stemGains&~(255<<shift))|(percent<<shift);
    }
    public synchronized void setStemPreset(int mask){
        if(stemFolder==null||mask<0||mask>15)return;
        int value=0;for(int i=0;i<4;i++)if((mask&(1<<i))!=0)value|=100<<(i*8);stemGains=value;
    }
    public static final String[] STEM_NAMES={"drums","bass","other","vocals"};
    public static String pcmHash(File pcm)throws java.io.IOException{
        try{java.security.MessageDigest md=java.security.MessageDigest.getInstance("SHA-256");
            try(java.io.InputStream in=new java.io.BufferedInputStream(new java.io.FileInputStream(pcm))){byte[] buf=new byte[65536];int n;while((n=in.read(buf))!=-1){if(Thread.currentThread().isInterrupted())throw new java.io.InterruptedIOException("Cancelado");md.update(buf,0,n);}}
            StringBuilder out=new StringBuilder();for(byte x:md.digest())out.append(String.format(java.util.Locale.ROOT,"%02x",x&255));return out.toString();
        }catch(java.security.NoSuchAlgorithmException e){throw new java.io.IOException(e);}
    }
    public static void validateStems(File folder,long frames)throws java.io.IOException{
        if(folder==null||frames<2||frames>(0xffffffffL-36)/6)throw new java.io.IOException("Grupo inválido");
        for(String role:STEM_NAMES){File f=new File(folder,role+".wav");
            try(java.io.RandomAccessFile in=new java.io.RandomAccessFile(f,"r")){
                if(in.length()!=44+frames*6)throw new java.io.IOException("Stem desalinhado: "+role);
                byte[] h=new byte[44];in.readFully(h);java.nio.ByteBuffer b=java.nio.ByteBuffer.wrap(h).order(java.nio.ByteOrder.LITTLE_ENDIAN);
                if(b.getInt(0)!=0x46464952||Integer.toUnsignedLong(b.getInt(4))!=36+frames*6||b.getInt(8)!=0x45564157||b.getInt(12)!=0x20746d66||b.getInt(16)!=16||b.getShort(20)!=1||b.getShort(22)!=2||b.getInt(24)!=44100||b.getInt(28)!=264600||b.getShort(32)!=6||b.getShort(34)!=24||b.getInt(36)!=0x61746164||Integer.toUnsignedLong(b.getInt(40))!=frames*6)throw new java.io.IOException("Formato WAV inválido: "+role);
            }
        }
    }
    public static File stemRoot(File files){return new File(files,"native-stems-v1");}
    public static boolean nativeStemRate(int rate){return rate==44100||rate==48000;}
    public static long stemFrames(long sourceFrames,int rate){
        if(!nativeStemRate(rate)||sourceFrames<2||sourceFrames>1200L*rate)throw new IllegalArgumentException("Formato neural nativo inválido");
        return Math.round(sourceFrames*44100.0/rate);
    }
    /** Preserve old 44.1 kHz cache keys. Rate-qualified keys avoid cross-rate collisions. */
    public static String stemKey(File pcm,int rate)throws java.io.IOException{
        String hash=pcmHash(pcm);if(rate==44100)return hash;
        if(!nativeStemRate(rate))throw new java.io.IOException("Taxa de amostragem incompatível");
        try{byte[] digest=java.security.MessageDigest.getInstance("SHA-256").digest((rate+":"+hash).getBytes(java.nio.charset.StandardCharsets.US_ASCII));
            StringBuilder b=new StringBuilder();for(byte x:digest)b.append(String.format(java.util.Locale.ROOT,"%02x",x&255));return b.toString();
        }catch(java.security.NoSuchAlgorithmException e){throw new java.io.IOException(e);}
    }
    public static File locateStems(File files,File pcm,int rate,long frames)throws java.io.IOException{
        if(!nativeStemRate(rate)||frames<2||frames>1200L*rate||!stemRoot(files).isDirectory())return null;
        File folder=new File(stemRoot(files),stemKey(pcm,rate));if(!folder.isDirectory())return null;
        validateStems(folder,stemFrames(frames,rate));return folder;
    }
    /** Publish only complete groups. Never overwrite a group used by a deck. */
    public static void publishStems(File files,File pcm,long frames,File exported,String base)throws java.io.IOException{
        publishStems(files,pcm,44100,frames,exported,base);
    }
    public static void publishStems(File files,File pcm,int rate,long sourceFrames,File exported,String base)throws java.io.IOException{
        long frames=stemFrames(sourceFrames,rate);
        File root=stemRoot(files);if(!root.isDirectory()&&!root.mkdirs())throw new java.io.IOException("Cache de stems indisponível");
        File target=new File(root,stemKey(pcm,rate));if(target.isDirectory()){validateStems(target,frames);return;}
        File tmp=new File(root,"pending-"+java.util.UUID.randomUUID());if(!tmp.mkdir())throw new java.io.IOException("Cache de stems indisponível");
        try{for(String role:STEM_NAMES){File src=new File(exported,base+"."+role+".wav");File dst=new File(tmp,role+".wav");
            try(java.io.InputStream in=new java.io.FileInputStream(src);java.io.OutputStream out=new java.io.FileOutputStream(dst)){byte[] buf=new byte[65536];int n;while((n=in.read(buf))!=-1){if(Thread.currentThread().isInterrupted())throw new java.io.InterruptedIOException("Cancelado");out.write(buf,0,n);}}}
            validateStems(tmp,frames);StemStorage.label(tmp,base);if(Thread.currentThread().isInterrupted())throw new java.io.InterruptedIOException("Cancelado");
            if(!tmp.renameTo(target))throw new java.io.IOException("Publicação de stems falhou");
        }finally{File[] children=tmp.listFiles();if(children!=null)for(File f:children)f.delete();tmp.delete();}
    }
    public final File file;
    public final int sampleRate;
    public final long frames;
    public final double bpm;
    public final double confidence;
    public final double phaseSeconds;
    public final double rms;
    public final double tailBpm,tailConfidence,tailPhaseSeconds,tailStartSeconds;
    public final double introCueSeconds;
    public final double phraseIntroSeconds,phraseOutroSeconds,phraseIntroConfidence,phraseOutroConfidence;
    public TrackData(String title, File file, int sampleRate, long frames,
                     double bpm, double confidence, double phaseSeconds, double rms) {
        this(title,file,sampleRate,frames,bpm,confidence,phaseSeconds,rms,bpm,confidence,phaseSeconds,0,0);
    }
    public TrackData(String title,File file,int sampleRate,long frames,
                     double bpm,double confidence,double phaseSeconds,double rms,
                     double tailBpm,double tailConfidence,double tailPhaseSeconds,double tailStartSeconds){
        this(title,file,sampleRate,frames,bpm,confidence,phaseSeconds,rms,
             tailBpm,tailConfidence,tailPhaseSeconds,tailStartSeconds,0);
    }
    public TrackData(String title,File file,int sampleRate,long frames,
                     double bpm,double confidence,double phaseSeconds,double rms,
                     double tailBpm,double tailConfidence,double tailPhaseSeconds,double tailStartSeconds,double introCueSeconds){
        this(title,file,sampleRate,frames,bpm,confidence,phaseSeconds,rms,
             tailBpm,tailConfidence,tailPhaseSeconds,tailStartSeconds,introCueSeconds,0,0,0,0);
    }
    public TrackData(String title,File file,int sampleRate,long frames,
                     double bpm,double confidence,double phaseSeconds,double rms,
                     double tailBpm,double tailConfidence,double tailPhaseSeconds,double tailStartSeconds,double introCueSeconds,
                     double phraseIntroSeconds,double phraseOutroSeconds,double phraseIntroConfidence,double phraseOutroConfidence){
        this.title=title;this.file=file;this.sampleRate=sampleRate;this.frames=frames;
        this.bpm=bpm;this.confidence=confidence;this.phaseSeconds=phaseSeconds;this.rms=rms;
        this.tailBpm=tailBpm;this.tailConfidence=tailConfidence;this.tailPhaseSeconds=tailPhaseSeconds;
        this.tailStartSeconds=tailStartSeconds;this.introCueSeconds=introCueSeconds;
        this.phraseIntroSeconds=phraseIntroSeconds;this.phraseOutroSeconds=phraseOutroSeconds;
        this.phraseIntroConfidence=phraseIntroConfidence;this.phraseOutroConfidence=phraseOutroConfidence;
    }
    public double duration() {return frames/(double) sampleRate;}
    public boolean trustworthyTempo() {return bpm >= 75 && bpm <= 170 && confidence >= 0.30;}
}
