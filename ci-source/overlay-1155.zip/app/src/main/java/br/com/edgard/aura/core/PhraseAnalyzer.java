package br.com.edgard.aura.core;

import java.io.File;
import java.io.IOException;
import java.io.FileInputStream;
import java.io.DataInputStream;
import java.io.BufferedInputStream;
import java.io.InterruptedIOException;

/**
 * Offline structural phrase hypotheses from stereo PCM energy/brightness
 * changes at an independently measured 4/4 beat grid. Not a downbeat oracle:
 * if evidence is weak, confidence is zero and the planner uses ordinary beats.
 */
public final class PhraseAnalyzer {
    private PhraseAnalyzer(){}
    public static final class Result {
        public final double introSeconds,outroSeconds,introConfidence,outroConfidence;
        public Result(double in,double out,double ic,double oc){
            introSeconds=in;outroSeconds=out;introConfidence=ic;outroConfidence=oc;
        }
    }
    private static final class Candidate {
        double time,confidence;
    }
    public static Result analyze(File pcm,int rate,long frames,
            double headBpm,double headPhase,double headConfidence,
            double tailBpm,double tailPhase,double tailConfidence) throws IOException {
        if(pcm==null||rate<=0||frames<=0)return new Result(0,0,0,0);
        double duration=frames/(double)rate;
        Candidate intro=new Candidate(),outro=new Candidate();
        if(headConfidence>=.42&&headBpm>=75&&headBpm<=170&&duration>=45)
            intro=analyzeWindow(pcm,rate,frames,headBpm,headPhase,0,
                    Math.min(duration,62),4,Math.min(30,duration*.33),false);
        if(tailConfidence>=.42&&tailBpm>=75&&tailBpm<=170&&duration>=45)
            outro=analyzeWindow(pcm,rate,frames,tailBpm,tailPhase,
                    Math.max(0,duration-90),duration,Math.max(0,duration-65),
                    Math.max(0,duration-6),true);
        return new Result(intro.time,outro.time,intro.confidence,outro.confidence);
    }
    private static Candidate analyzeWindow(File file,int hz,long total,double bpm,double phase,
            double from,double to,double earliest,double latest,boolean preferLate) throws IOException {
        Candidate best=new Candidate();
        double bar=240.0/bpm;
        // Phase corresponds to a beat, but the bar number is inferred and can be
        // shifted by 1..3 beats; this is why we never certify downbeats here.
        long firstBar=(long)Math.floor((from-phase)/bar)-2;
        long lastBar=(long)Math.ceil((to-phase)/bar)+2;
        int count=(int)(lastBar-firstBar+1);
        if(count<7||count>10000)return best;
        double[] power=new double[count],brightness=new double[count];
        long[] n=new long[count];
        int hop=1024;
        byte[] buf=new byte[hop*4];
        long begin=(long)Math.max(0,Math.floor(from*hz));
        long end=(long)Math.min(total,Math.ceil(to*hz));
        double prev=0;
        try(FileInputStream source=new FileInputStream(file);DataInputStream raf=new DataInputStream(new BufferedInputStream(source,1<<16))){
            source.getChannel().position(begin*4);
            for(long pos=begin;pos<end;){
                if(Thread.currentThread().isInterrupted())throw new InterruptedIOException("Cancelado");
                int amount=(int)Math.min(hop,end-pos);
                raf.readFully(buf,0,amount*4);
                double squared=0,changes=0;
                for(int i=0;i<amount;i++){
                    int j=i*4;
                    // Sum both channels as energy: anti-phase recordings survive.
                    short l=(short)((buf[j]&255)|(buf[j+1]<<8));
                    short r=(short)((buf[j+2]&255)|(buf[j+3]<<8));
                    double left=l/32768.0,right=r/32768.0;
                    squared+=left*left+right*right;
                    changes+=Math.abs(left-prev);prev=left;
                }
                int ix=(int)Math.floor((((pos+amount*.5)/hz)-phase)/bar-firstBar);
                if(ix>=0&&ix<count){power[ix]+=squared/amount;brightness[ix]+=changes/Math.max(1,amount);n[ix]++;}
                pos+=amount;
            }
        }
        double[] e=new double[count],b=new double[count];
        for(int i=0;i<count;i++){
            e[i]=n[i]>0?Math.sqrt(power[i]/n[i]):0;
            b[i]=n[i]>0?brightness[i]/n[i]:0;
        }
        for(int i=2;i<count-2;i++){
            long barNo=firstBar+i;
            double t=phase+barNo*bar;
            if(t<earliest||t>latest||t<from+bar||t>to-bar)continue;
            double before=(e[i-2]+e[i-1])*.5,after=(e[i]+e[i+1])*.5;
            double brightBefore=(b[i-2]+b[i-1])*.5,brightAfter=(b[i]+b[i+1])*.5;
            double energyChange=Math.abs(after-before)/Math.max(.025,Math.max(after,before));
            double brightChange=Math.abs(brightAfter-brightBefore)/
                    Math.max(.012,Math.max(brightAfter,brightBefore));
            double novelty=MixMath.clamp(.83*energyChange+.17*brightChange,0,1);
            // Ignore very quiet recordings unless a meaningful phrase emerges.
            if(Math.max(before,after)<.025 || novelty<.36)continue;
            double confidence=MixMath.clamp((novelty-.28)/.60,0,1);
            // Penalize end-of-song silence; prefer structural change with audible music.
            if(after<.006)confidence*=.5;
            double preferred=preferLate?latest-8:Math.max(earliest,8);
            double distance=Math.abs(t-preferred);
            double score=confidence*(.75+.25*Math.exp(-distance/30));
            if(score>best.confidence){best.time=t;best.confidence=score;}
        }
        if(best.confidence<.55){best.time=0;best.confidence=0;}
        return best;
    }
}
