// Node 22+; talks only to the emulator WebView's local debugger. Uses actual DOM click handlers, not direct service commands.
import {execFileSync} from 'node:child_process';
import {writeFileSync,mkdirSync} from 'node:fs';
const pkg='br.com.edgard.aura.completo11',sleep=ms=>new Promise(r=>setTimeout(r,ms));
const adb=(...a)=>execFileSync('adb',a,{encoding:'utf8',timeout:30000}).trim();
mkdirSync('ui-evidence',{recursive:true});
let ws,seq=0;const events=[],pending=new Map();
try{
  adb('shell','am','start','-W','-n',pkg+'/br.com.edgard.aura.DebugUiSmokeActivity');
  let target;
  for(let i=0;i<60&&!target;i++){
    try{const pid=adb('shell','pidof',pkg).split(' ')[0];adb('forward','tcp:9222','localabstract:webview_devtools_remote_'+pid);const pages=await (await fetch('http://127.0.0.1:9222/json')).json();target=pages.find(x=>x.url.includes('/index.html'));}catch{}
    if(!target)await sleep(1000);
  }
  if(!target)throw Error('WebView index not available');
  ws=new WebSocket(target.webSocketDebuggerUrl.replace(/ws:\/\/[^/]+/,'ws://127.0.0.1:9222'));
  await new Promise((resolve,reject)=>{ws.onopen=resolve;ws.onerror=reject;});
  ws.onmessage=e=>{const j=JSON.parse(e.data);if(j.id){pending.get(j.id)?.(j);pending.delete(j.id);}else if(j.method==='Runtime.exceptionThrown')events.push(j);};
  const send=(method,params={})=>new Promise((resolve,reject)=>{const id=++seq;pending.set(id,j=>j.error?reject(Error(JSON.stringify(j.error))):resolve(j.result));ws.send(JSON.stringify({id,method,params}));setTimeout(()=>{if(pending.delete(id))reject(Error('CDP timeout'));},10000).unref();});
  await send('Runtime.enable');
  const ev=async expression=>{const r=await send('Runtime.evaluate',{expression,returnByValue:true,awaitPromise:true});if(r.exceptionDetails)throw Error(JSON.stringify(r.exceptionDetails));return r.result.value;};
  const snap=()=>ev('JSON.parse(AURA_ANDROID.snapshot())');
  const until=async(label,fn,seconds=50)=>{for(let i=0;i<seconds*2;i++){try{const v=await fn();if(v)return v;}catch{}await sleep(500);}throw Error('Timeout: '+label);};
  const click=sel=>ev(`(()=>{const e=document.querySelector(${JSON.stringify(sel)});if(!e||e.disabled)return false;e.click();return true})()`);
  await until('native controller',()=>ev('!!document.querySelector("#aura10-native-controller")'));
  await until('play enabled',()=>ev('!document.querySelector("#play").disabled'));
  if(!await click('#play'))throw Error('Play not sent');
  await until('PCM playing',async()=>{const s=await snap();return s.playing&&!s.quick&&s.mode==='playing'&&s.samplerReady;},75);
  const first=await snap();writeFileSync('ui-evidence/first.json',JSON.stringify(first,null,2));
  // Exercise user-facing pause/resume and verify service state, then actual FX and pads.
  await until('Pause enabled',()=>click('#pause'));await until('pause acknowledged',async()=> (await snap()).mode==='paused');
  await sleep(700);await until('Resume enabled',()=>click('#play'));await until('resume acknowledged',async()=> (await snap()).mode==='playing');
  await until('Distortion enabled',()=>click('[data-djfx="distortion"]'));
  await until('FX produced audio',async()=> (await snap()).fxAppliedFrames>4800);
  for(const key of ['vinheta','backspin','tapestop','scratch']){const before=(await snap()).samplerFrames;if(!await click(`[data-sampler="${key}"]`))throw Error('Pad unavailable: '+key);await until(key+' produced audio',async()=> (await snap()).samplerFrames>before+4800,10);}
  const last=await until('two overlapping mixes',async()=>{const s=await snap();return s.mixedTransitions>=2&&s.mixedFrames>48000&&s.hardHandoffs===0?s:false;},100);
  writeFileSync('ui-evidence/result.json',JSON.stringify({result:'PASS',first,last,webErrors:events},null,2));
  if(events.length)throw Error('WebView JavaScript exceptions');
  console.log('PASS actual WebView-to-PCM bridge',JSON.stringify({decoded:last.decoded,fx:last.fxAppliedFrames,sampler:last.samplerFrames,mixes:last.mixedTransitions,mixedFrames:last.mixedFrames,hard:last.hardHandoffs}));
}catch(e){writeFileSync('ui-evidence/error.txt',String(e.stack||e));throw e;}
finally{ws?.close();try{writeFileSync('ui-evidence/logcat.txt',adb('logcat','-d','-v','time'));}catch{}try{adb('forward','--remove','tcp:9222');}catch{}}
