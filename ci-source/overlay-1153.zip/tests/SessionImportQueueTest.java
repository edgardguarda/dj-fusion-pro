import br.com.edgard.aura.core.*;
import java.io.File;
import java.util.*;
import java.util.concurrent.atomic.AtomicReference;

/** Session refresh stress: only watcher scans, renderer bounded append. */
public final class SessionImportQueueTest {
    private static long assertions;
    static void check(boolean v,String m){assertions++;if(!v)throw new AssertionError(m);}
    static TrackData song(int id){return new TrackData("Track "+id,new File("/test-virtual/"+id+".pcm"),48000,48000,128,.9,0,.2);}
    public static void main(String[] args)throws Exception {
        ArrayList<TrackData> playing=new ArrayList<>();
        playing.add(song(0));playing.add(song(1));
        SessionImportQueue queue=new SessionImportQueue(playing);
        ArrayList<TrackData> source=new ArrayList<>();
        for(int i=0;i<10002;i++)source.add(song(i));
        queue.offerSnapshot(source);
        queue.offerSnapshot(source); // Repeated watcher loads must not duplicate.
        Set<String> rejected=new HashSet<>();
        rejected.add(song(2400).file.getAbsolutePath());
        check(queue.drainInto(playing,rejected,32)==32,"first refresh must honor 32-entry budget");
        check(playing.size()==34,"first refresh size");
        check(playing.get(0).title.equals("Track 0") && playing.get(1).title.equals("Track 1"),"preserve initial playback indices");
        int iterations=1;
        while(playing.size()<10001 && iterations++<1000){
            int previous=playing.size();
            int added=queue.drainInto(playing,rejected,32);
            check(added<=32 && added>=0,"bounded append");
            check(playing.size()==previous+added,"consistency");
        }
        check(playing.size()==10001,"all 9999 accepted imports delivered");
        check(queue.drainInto(playing,rejected,32)==0,"queue consumed once");
        HashSet<String> unique=new HashSet<>();
        for(TrackData track:playing)check(unique.add(track.file.getAbsolutePath()),"duplicate output path");
        check(!unique.contains(song(2400).file.getAbsolutePath()),"rejected cache excluded");
        ArrayList<TrackData> update=new ArrayList<>(source);
        update.add(song(10002));update.add(song(10003));
        queue.offerSnapshot(update);
        check(queue.drainInto(playing,rejected,32)==2,"new tracks appended once");
        check(playing.get(10002).title.equals("Track 10003"),"new imports maintain order");
        AtomicReference<Throwable> error=new AtomicReference<>();
        final ArrayList<TrackData> asyncPlaying=new ArrayList<>();
        asyncPlaying.add(song(-1));
        final SessionImportQueue asyncQueue=new SessionImportQueue(asyncPlaying);
        Thread writer=new Thread(()->{
            try{
                for(int round=0;round<80;round++){
                    ArrayList<TrackData> batch=new ArrayList<>();
                    for(int i=0;i<40;i++)batch.add(song(20000+round*40+i));
                    asyncQueue.offerSnapshot(batch);
                }
            }catch(Throwable e){error.set(e);}
        });
        writer.start();
        int emptyPolls=0;
        while(writer.isAlive() || emptyPolls<100){
            int added=asyncQueue.drainInto(asyncPlaying,Collections.emptySet(),16);
            check(added<=16,"async bounded");
            if(added==0)emptyPolls++;else emptyPolls=0;
            if(!writer.isAlive()&&emptyPolls>=100)break;
            Thread.yield();
        }
        writer.join();
        check(error.get()==null,"worker no failure");
        check(asyncPlaying.size()==3201,"async reader received all 3200 songs");
        boolean invalid=false;
        try{queue.drainInto(playing,rejected,0);}catch(IllegalArgumentException e){invalid=true;}
        check(invalid,"reject budget 0");
        ArrayList<TrackData> restored=new ArrayList<>();restored.add(song(0));
        SessionImportQueue progressive=new SessionImportQueue(restored,"current-set");
        TrackData cached=new TrackData("Cached in another session",new File("/old-cache/track.pcm"),44100,44100,125,.9,0,.2);
        TrackData fresh=new TrackData("Fresh decode",new File("/new-cache/track.pcm"),48000,48000,128,.9,0,.2);
        progressive.offerSnapshot(Arrays.asList(cached,fresh),"unrelated-set");
        check(progressive.drainInto(restored,Collections.emptySet(),32)==0,"reject foreign session");
        progressive.offerSnapshot(Arrays.asList(cached,fresh),"current-set");
        progressive.offerSnapshot(Arrays.asList(cached,fresh),"current-set");
        check(progressive.drainInto(restored,Collections.emptySet(),32)==2,"reuse plus newly decoded PCM across directories");
        check(restored.size()==3&&restored.get(1)==cached&&restored.get(2)==fresh,"append once in planned order");
        System.out.println("PASS SessionImportQueueTest checks="+assertions);
    }
}
