package br.com.edgard.aura.core;

import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.concurrent.ConcurrentLinkedQueue;

/**
 * Single-writer session import gate. The playlist watcher resolves paths and
 * deduplicates on its own thread. The PCM renderer only polls up to a bounded
 * number of prepared additions once per refresh; it never scans the playlist
 * or builds a HashSet of every previously loaded track during playback.
 *
 * The initial playback order is never changed. Rejected decoder caches are
 * omitted even if their source session file still lists them.
 */
public final class SessionImportQueue {
    private final String sessionDirectory;
    private final String sessionId;
    private final Set<String> seen = new HashSet<>();
    private final ConcurrentLinkedQueue<TrackData> pending = new ConcurrentLinkedQueue<>();

    public SessionImportQueue(List<TrackData> playing) {this(playing,null);}
    public SessionImportQueue(List<TrackData> playing,String sessionId) {
        this.sessionId=sessionId;
        if (playing == null) throw new IllegalArgumentException("playing");
        String directory=null;
        for (TrackData t : playing) if (t != null && t.file != null){
            if(directory==null)directory=t.file.getAbsoluteFile().getParent();
            seen.add(t.file.getAbsolutePath());
        }
        sessionDirectory=directory;
    }

    /** Watcher thread: may allocate or scan a refreshed session. */
    public void offerSnapshot(List<TrackData> refreshed) {
        offerSnapshot(refreshed,null);
    }
    public void offerSnapshot(List<TrackData> refreshed,String incomingId) {
        if (refreshed == null || !java.util.Objects.equals(sessionId,incomingId)) return;
        for (TrackData t : refreshed) {
            if (t != null && t.file != null && (sessionId!=null || sessionDirectory==null || sessionDirectory.equals(t.file.getAbsoluteFile().getParent()))
                    && seen.add(t.file.getAbsolutePath()))
                pending.offer(t);
        }
    }

    /** Renderer thread: bounded polling only, no disk I/O, no full-set scans. */
    public int drainInto(List<TrackData> playing, Set<String> rejected, int budget) {
        if (playing == null || rejected == null || budget <= 0)
            throw new IllegalArgumentException("Invalid import budget");
        int appended = 0;
        for (int i=0; i<budget; i++) {
            TrackData t=pending.poll();
            if (t==null) break;
            if (!rejected.contains(t.file.getAbsolutePath())) {
                playing.add(t);
                appended++;
            }
        }
        return appended;
    }
}
