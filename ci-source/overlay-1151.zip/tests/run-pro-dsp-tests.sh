#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")/.."
mkdir -p build-pro-dsp
javac -d build-pro-dsp \
 app/src/main/java/br/com/edgard/aura/core/{MixMath,TrackData,StemStorage,TrackPlanner,HarmonicAnalyzer,BufferedPcmDeck,WsolaStereoStretch,BeatPhaseController,PhraseAnalyzer,MasterAudioMeter,LookaheadMasterLimiter,SessionTrackAppender,PcmHandoffWatchdog}.java \
 tests/ProfessionalDspTest.java tests/MasterOutputRegressionTest.java tests/WsolaSourceTimelineRegressionTest.java tests/PcmHandoffWatchdogTest.java
java -cp build-pro-dsp ProfessionalDspTest

java -cp build-pro-dsp MasterOutputRegressionTest
java -cp build-pro-dsp WsolaSourceTimelineRegressionTest

java -cp build-pro-dsp PcmHandoffWatchdogTest

# Android output underrun burst safety gate (pure Java, deterministically tested).
javac -d build-pro-dsp app/src/main/java/br/com/edgard/aura/core/OutputUnderrunGuard.java tests/OutputUnderrunGuardTest.java
java -cp build-pro-dsp OutputUnderrunGuardTest

# Android output buffer grow-only policy (all deterministic; no device calls).
javac -d build-pro-dsp app/src/main/java/br/com/edgard/aura/core/{AdaptiveOutputBuffer,OutputUnderrunGuard}.java tests/AdaptiveOutputBufferTest.java
java -cp build-pro-dsp AdaptiveOutputBufferTest

# Creative native FX: stereo safety, bypass transparency, limiter ceiling.
javac -d build-pro-dsp app/src/main/java/br/com/edgard/aura/core/{MasterCreativeFx,LookaheadMasterLimiter}.java tests/MasterCreativeFxTest.java
java -cp build-pro-dsp MasterCreativeFxTest
