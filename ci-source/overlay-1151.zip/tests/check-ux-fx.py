#!/usr/bin/env python3
"""Release gates for the Android scroll/FX UI and truthful stem affordances."""
from pathlib import Path
r=Path(__file__).resolve().parent.parent
fast=(r/'app/src/main/assets/aura-fast.html').read_text()
classic=(r/'app/src/main/assets/aura.html').read_text()
native=(r/'app/src/main/assets/native-ui.js').read_text()
service=(r/'app/src/main/java/br/com/edgard/aura/AudioService.java').read_text()
bridge=(r/'app/src/main/java/br/com/edgard/aura/MainActivity.java').read_text()
fx=(r/'app/src/main/java/br/com/edgard/aura/core/MasterCreativeFx.java').read_text()
checks={
  'mobile touch-scroll shell exists': 'touch-action:pan-y' in fast and '.wrap{display:flex' in fast,
  'native library not permanently viewport-height': 'height:auto!important;min-height:0!important' in native,
  'native nested tracklist allows swipe': '#aura10-native-tracklist{overflow:visible!important' in native,
  'empty state offers file import': 'aura-empty-add' in native and 'Pronto para o seu primeiro set' in native,
  'real native FX bridge': 'pcmFx(String mode,double amount)' in bridge and 'AudioService.FX' in bridge,
  'FX bridge requires active native PCM': 'if(!AudioService.isPlaying())return;' in bridge,
  'FX delivered before limiter': service.index('creativeFx.process(left,right,fxOut)')<service.index('masterLimiter.process(dc[0],dc[1],vm)'),
  'FX processing outside UI thread': 'creativeFx.configure(creativeFxMode,creativeFxAmount)' in service,
  'native 4 FX implemented': all('"'+x+'".equals(mode)' in service for x in ['distortion','crush','overdrive','fuzz']),
  'FX actually changes samples': all(x in fx for x in ['processedL','processedR','soft(','overdrive(','holdCounter']),
  'Web rhythm not falsely enabled in native': "const rhythmic=pad.dataset.fxGroup==='rhythm'" in native,
  'native samplers connected': "api.sampler(key," in native,
  'native stem controls require actual prepared data': 'renderNativeStems(v)' in native and 'v.pcmStems?.[i]' in native and 'api.stemGain' in native and 'NeuralStemActivity.class' in bridge and 'stemFolder()==null' in bridge,
  'classic real-stem presets': all('data-stem-preset="'+x+'"' in classic for x in ['original','instrumental','vocals','drums']),
  'preset gated by actual stem data': "preset.disabled=!active.size" in classic,
  'new version': '11.5.1-smart-studio-beta' in (r/'app/build.gradle').read_text(),
}
for name,ok in checks.items(): print(('PASS ' if ok else 'FAIL ')+name)
if not all(checks.values()):raise SystemExit('UX/FX release gates failed')
print('PASS UX/FX safety checks=',len(checks))
