#!/usr/bin/env python3
"""Release gate: block privilege regression, unsafe WebView settings and debug exposure."""
from pathlib import Path
import re

root=Path(__file__).resolve().parent.parent
man=(root/'app/src/main/AndroidManifest.xml').read_text()
dbg=(root/'app/src/debug/AndroidManifest.xml').read_text()
activity=(root/'app/src/main/java/br/com/edgard/aura/MainActivity.java').read_text()
policy=(root/'app/src/main/java/br/com/edgard/aura/core/PrivateAudioExport.java').read_text()
version=(root/'app/build.gradle').read_text()
checks={
  'no INTERNET permission': 'android.permission.INTERNET' not in man,
  'no backup': 'android:allowBackup="false"' in man,
  'no cleartext': 'android:usesCleartextTraffic="false"' in man,
  'only launcher exported': len(re.findall(r'android:exported="true"',man))==1,
  'native services private': len(re.findall(r'<service .*?android:exported="false"',man))==2,
  'debug activities protected': dbg.count('android:permission="android.permission.DUMP"')==4,
  'WebView no local file access': 'settings.setAllowFileAccess(false)' in activity,
  'WebView no content access': 'settings.setAllowContentAccess(false)' in activity,
  'WebView no cross-origin files': 'settings.setAllowUniversalAccessFromFileURLs(false)' in activity,
  'WebView no mixed content': 'settings.setMixedContentMode(WebSettings.MIXED_CONTENT_NEVER_ALLOW)' in activity,
  'WebView network blocked': 'settings.setBlockNetworkLoads(true)' in activity,
  'WebView scheme and host validated': '!"https".equals(u.getScheme())' in activity,
  'JS injection page allowlist': 'Never inject a native controller into a foreign page' in activity,
  'diagnostic export path validated': activity.count('PrivateAudioExport.resolve(')>=4,
  'canonical contained path': 'getCanonicalFile()' in policy,
  'version bumped': 'versionCode 1151' in version and '11.5.1-smart-studio-beta' in version,
}
for name,ok in checks.items(): print(('PASS' if ok else 'FAIL'),name)
if not all(checks.values()): raise SystemExit('Security release gate failed')
