#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")/.."
python3 tests/check-audio-thread.py
mkdir -p build-audio-safety
javac -d build-audio-safety \
  app/src/main/java/br/com/edgard/aura/core/{TrackData,StemStorage,TrackPlanner,HarmonicAnalyzer,BufferedPcmDeck,WsolaStereoStretch,AsyncDeckPreparer}.java \
  app/src/main/java/br/com/edgard/aura/{WavWriter,AsyncWavRecorder}.java \
  tests/AsyncDeckPreparerTest.java tests/RecordingFinalizationTest.java \
  tests/HandoffRaceAndCacheIntegrityTest.java tests/AtomicWavSafetyTest.java
java -cp build-audio-safety AsyncDeckPreparerTest
java -cp build-audio-safety RecordingFinalizationTest
java -cp build-audio-safety HandoffRaceAndCacheIntegrityTest
java -cp build-audio-safety AtomicWavSafetyTest

# Watcher scans and deduplicates off-thread; sample-clock thread drains a
# bounded queue even for 10,000 imported tracks.
javac -d build-audio-safety app/src/main/java/br/com/edgard/aura/core/{TrackData,StemStorage}.java \
  app/src/main/java/br/com/edgard/aura/core/SessionImportQueue.java \
  tests/SessionImportQueueTest.java
java -cp build-audio-safety SessionImportQueueTest
