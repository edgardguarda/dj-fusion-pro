#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")/.."
mkdir -p build-quality
javac -encoding UTF-8 -d build-quality app/src/main/java/br/com/edgard/aura/core/{TrackData,StemStorage,TrackPlanner,HarmonicAnalyzer,BufferedPcmDeck,WsolaStereoStretch,AsyncDeckPreparer,PcmGlitchGuard,PcmSamplerBus}.java app/src/main/java/br/com/edgard/aura/{WavWriter,AsyncWavRecorder}.java tests/QualityUpgradeTest.java
java -cp build-quality QualityUpgradeTest
