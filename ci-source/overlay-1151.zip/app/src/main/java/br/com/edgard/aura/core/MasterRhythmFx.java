package br.com.edgard.aura.core;
/** Beat-length master effects. Source playback continues underneath; no allocation on render. */
public final class MasterRhythmFx {
 public static final int OFF=0,ROLL=1,GATE=2,SLIP=3,OVERLOOP=4;
 private final float[] l,r;private final int hz;private int write,filled,mode,requested,period=1,phase,anchor;private double wet;
 public MasterRhythmFx(int hz){this.hz=hz;l=new float[hz*8];r=new float[l.length];}
 public void configure(int m,int division,double bpm){requested=m>=1&&m<=4&&Double.isFinite(bpm)&&bpm>=70&&bpm<=180?m:OFF;int d=Math.max(1,Math.min(16,division));int p=(int)Math.round(hz*60/Math.max(70,bpm)/d*(m==OVERLOOP?4:m==SLIP?2:1));p=Math.max(64,Math.min(l.length/2,p));if(requested!=mode&&wet<.001&&(requested==OFF||requested==GATE||filled>=p)){mode=requested;period=p;phase=0;anchor=(write-period+l.length)%l.length;}}
 public void process(float a,float b,float[] out){double target=requested==mode&&mode!=OFF&&(mode==GATE||filled>=period)?1:0;wet+=(target-wet)*.008;float x=a,y=b;if(mode==GATE){double t=phase/(double)period;double gain=Math.min(1,Math.min(t,.65-t)*period/96.0);gain=Math.max(0,gain);x=(float)(a*gain);y=(float)(b*gain);}else if(mode!=OFF&&filled>=period){int pos=(anchor+phase)%l.length;x=l[pos];y=r[pos];double edge=Math.min(1,Math.min(phase,period-1-phase)/96.0);x=(float)(a+(x-a)*edge);y=(float)(b+(y-b)*edge);if(mode==OVERLOOP){x=(a+x)*.5f;y=(b+y)*.5f;}}
  out[0]=(float)(a+(x-a)*wet);out[1]=(float)(b+(y-b)*wet); // keep captured interval stable while loop runs
  if(mode==OFF||mode==GATE||wet<.001){l[write]=a;r[write]=b;write=(write+1)%l.length;filled=Math.min(l.length,filled+1);}
  phase=(phase+1)%period;
 }
}
