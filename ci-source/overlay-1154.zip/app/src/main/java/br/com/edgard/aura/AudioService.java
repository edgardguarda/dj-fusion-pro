package br.com.edgard.aura;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Intent;
import android.media.AudioAttributes;
import android.media.AudioFormat;
import android.media.AudioManager;
import android.media.AudioTrack;
import android.os.Build;
import android.os.IBinder;
import android.os.Process;
import android.util.Log;
import br.com.edgard.aura.core.*;
import java.util.List;
import java.util.concurrent.atomic.AtomicBoolean;
import java.util.concurrent.atomic.AtomicReference;
import java.util.concurrent.atomic.AtomicInteger;

/** Sample-clock stereo mixer. No UI timer or browser thread drives the audio. */
public final class AudioService extends Service {
    public static final String START="br.com.edgard.aura.START";
    public static final String STOP="br.com.edgard.aura.STOP";
    public static final String PAUSE="br.com.edgard.aura.PAUSE";
    public static final String RESUME="br.com.edgard.aura.RESUME";
    public static final String NEXT="br.com.edgard.aura.NEXT";
    public static final String RECORD="br.com.edgard.aura.RECORD";
    public static final String RECORD_OFF="br.com.edgard.aura.RECORD_OFF";
    public static final String SELFTEST="br.com.edgard.aura.SELFTEST";
    public static final String FX="br.com.edgard.aura.FX";
    public static final String SEEK="br.com.edgard.aura.PCM_SEEK";
    private static final class SeekCommand {
        final double seconds; final long token;
        SeekCommand(double seconds,long token){this.seconds=seconds;this.token=token;}
    }
    private final AtomicReference<SeekCommand> seekRequest=new AtomicReference<>();
    private static final java.util.concurrent.atomic.AtomicLong TRACK_TOKEN=new java.util.concurrent.atomic.AtomicLong();
    private static volatile long activeTrackToken;
    private static volatile TrackData stemOn,stemNext;
    public static TrackData[] stemDecks(){return new TrackData[]{stemOn,stemNext};}
    public static void changeStem(long token,int role,int value){
        if(!ACTIVE.get())return;
        TrackData a=stemOn,b=stemNext;TrackData t=a!=null&&a.stemToken==token?a:b!=null&&b.stemToken==token?b:null;
        if(t!=null){if(role==-1)t.setStemPreset(value);else t.setStemGain(role,value);}
    }
    private static volatile double activeTrackDuration,activeTrackPosition;
    private static volatile String activeTrackTitle="";
    public static double seekPosition(){return activeTrackPosition;}
    public static String seekTitle(){return activeTrackTitle;}
    private static volatile boolean seekAvailable;
    public static long seekToken(){return activeTrackToken;}
    public static double seekDuration(){return activeTrackDuration;}
    public static boolean canSeek(){return seekAvailable && ACTIVE.get();}
    public static final String SAMPLER="br.com.edgard.aura.SAMPLER";
    private volatile PcmSamplerBus pcmSamplers;
    private static volatile boolean samplerLoaded;
    public static boolean samplersReady(){return ACTIVE.get()&&samplerLoaded;}
    public static volatile boolean libraryPreparing;
    public static volatile long fxAppliedFrames,samplerFrames,mixedFrames,mixedTransitions,hardHandoffs;
    private volatile int creativeFxMode=MasterCreativeFx.OFF;
    private volatile double creativeFxAmount=.45;
    private volatile int rhythmMode=0,rhythmDivision=4;
    private static final String CHANNEL="aura-dj-playback";
    private final AtomicBoolean running=new AtomicBoolean(false);
    private Thread thread;
    private final AtomicBoolean paused=new AtomicBoolean(false),skipRequested=new AtomicBoolean(false);
    private volatile AudioTrack output;
    private volatile AudioManager focusManager;
    private final AtomicBoolean userPaused = new AtomicBoolean(false);
    private final AtomicBoolean focusPaused = new AtomicBoolean(false);
    private final AudioManager.OnAudioFocusChangeListener focusListener = change -> {
        if(change == AudioManager.AUDIOFOCUS_GAIN) {
            if(focusPaused.getAndSet(false) && !userPaused.get()) paused.set(false);
        } else if(change == AudioManager.AUDIOFOCUS_LOSS) {
            // Permanent loss requires an explicit resume with a new focus grant.
            focusPaused.set(false);paused.set(true);
        } else if(change == AudioManager.AUDIOFOCUS_LOSS_TRANSIENT ||
                change == AudioManager.AUDIOFOCUS_LOSS_TRANSIENT_CAN_DUCK) {
            if(!userPaused.get() && !paused.get()) { focusPaused.set(true); paused.set(true); }
        }
    };
    private boolean acquireAudioFocus() {
        AudioManager manager = (AudioManager)getSystemService(AUDIO_SERVICE);
        if(manager == null) return false;
        int granted = manager.requestAudioFocus(focusListener, AudioManager.STREAM_MUSIC,
                AudioManager.AUDIOFOCUS_GAIN);
        if(granted != AudioManager.AUDIOFOCUS_REQUEST_GRANTED) return false;
        focusManager = manager;
        return true;
    }
    private void releaseAudioFocus() {
        AudioManager manager = focusManager;
        focusManager = null;
        if(manager != null) try { manager.abandonAudioFocus(focusListener); }
            catch(Exception e) { Log.w("AURA", "Abandon audio focus", e); }
    }
    private final AtomicBoolean recording=new AtomicBoolean(false);
    private volatile AsyncWavRecorder recorder;
    private volatile PcmIncidentCapture incidentCapture;
    // Capture is opt-in: diagnostic WAVs may contain copyrighted or private music.
    private volatile boolean incidentCaptureEnabled;
    private final AtomicBoolean recorderPending = new AtomicBoolean(false);
    /** The storage directory and WAV header are created off the audio-rendering thread. */
    private void prepareRecorderAsync(int hz) {
        if(!recording.get() || !running.get() || recorder!=null || !recorderPending.compareAndSet(false,true)) return;
        new Thread(()->{
            try {
                java.io.File dir=new java.io.File(getFilesDir(),"masters");
                if(!dir.isDirectory()&&!dir.mkdirs())throw new java.io.IOException("Diretório de gravações indisponível");
                java.io.File f=new java.io.File(dir,"aura-master-"+System.currentTimeMillis()+".wav");
                AsyncWavRecorder next=new AsyncWavRecorder(f,hz,()->{
                    getSharedPreferences("aura",MODE_PRIVATE).edit()
                            .putString("lastMaster",f.getAbsolutePath()).apply();
                });
                if(recording.get() && running.get() && recorder==null){
                    recorder=next;
                    // Publish the last exportable WAV only after its RIFF header
                    // is finalized successfully by the background writer.
                }else next.close();
            }catch(Exception e){
                recording.set(false);
                Log.e("AURA","WAV recorder initialization",e);
                status("Falha ao iniciar gravador: "+e.getMessage());
            }finally{recorderPending.set(false);}
        },"AURA-WAV-setup").start();
    }

    /** Device buffer resize is submitted by the renderer, executed off audio thread. */
    private final AtomicInteger pendingOutputBufferFrames=new AtomicInteger();
    private final AtomicInteger actualOutputBufferFrames=new AtomicInteger();
    private void applyOutputBufferRequest() {
        final int target=pendingOutputBufferFrames.getAndSet(0);
        if(target<=0)return;
        AudioTrack device=output;
        if(device==null)return;
        try {
            int actual=device.setBufferSizeInFrames(target);
            if(actual>0){
                actualOutputBufferFrames.set(actual);
                Log.i("AURA", "PCM output buffer resized to " +actual+" frames");
            }else Log.w("AURA", "PCM output buffer resize declined: "+actual);
        }catch(RuntimeException e){
            Log.w("AURA", "Output device rejected buffer growth",e);
        }
    }

    /** Playlist disk IO is separated from the AudioTrack rendering thread. */
    private final class SessionWatcher implements AutoCloseable {
        private volatile boolean stopped;
        private final SessionImportQueue imports;
        private final Thread worker;
        SessionWatcher(java.util.List<TrackData> initial,String sessionId){
            imports=new SessionImportQueue(initial,sessionId);
            worker=new Thread(()->{
                long lastRevision=-1;
                while(!stopped){
                    applyOutputBufferRequest();
                    try{long revision=SessionStore.revision();if(revision!=lastRevision){SessionStore.Loaded current=SessionStore.load(AudioService.this);imports.offerSnapshot(current.tracks,current.sessionId);lastRevision=revision;}}
                    catch(Exception e){Log.w("AURA","PCM session refresh",e);}
                    PcmIncidentCapture cap=incidentCapture;
                    if(cap!=null){
                        boolean allowed=getSharedPreferences("aura",MODE_PRIVATE)
                                .getBoolean("pcm_incident_capture_enabled",false);
                        cap.setEnabled(allowed);
                        incidentCaptureEnabled=allowed;
                        String latest=cap.lastClip();
                        if(!latest.isEmpty())getSharedPreferences("aura",MODE_PRIVATE).edit()
                                .putString("pcm_last_incident",latest)
                                .putString("pcm_last_incident_reason",cap.lastReason()).apply();
                    }
                    flushDeferredDiagnostics();
                    try{Thread.sleep(850);}catch(InterruptedException ignored){}
                }
            },"AURA-PCM-playlist-worker");
            worker.setDaemon(true);worker.start();
        }
        /** At most 32 additions per refresh, without scanning the active set. */
        int importAvailable(java.util.List<TrackData> tracks, java.util.Set<String> rejected){
            return imports.drainInto(tracks,rejected,32);
        }
        @Override public void close(){
            stopped=true;worker.interrupt();
            if(Thread.currentThread()!=worker){
                try{worker.join(200);}catch(InterruptedException ignored){Thread.currentThread().interrupt();}
            }
        }
    }

    private volatile String currentTitle="";
    /** Never perform SharedPreferences serialization on the render thread. */
    private volatile Thread renderThread;
    private final AtomicReference<Runnable> pendingTelemetry=new AtomicReference<>();
    private final AtomicReference<String> pendingStatus=new AtomicReference<>();
    private static final AtomicBoolean ACTIVE=new AtomicBoolean(false);
    public static boolean isPlaying(){return ACTIVE.get();}
    private void flushDeferredDiagnostics(){
        Runnable telemetry=pendingTelemetry.getAndSet(null);
        if(telemetry!=null)try{telemetry.run();}catch(Exception e){Log.w("AURA","PCM telemetry",e);}
        String message=pendingStatus.getAndSet(null);
        if(message!=null)getSharedPreferences("aura",MODE_PRIVATE).edit().putString("status",message).apply();
    }
    @Override public IBinder onBind(Intent intent){return null;}
    private void status(String msg){
        if(Thread.currentThread()==renderThread){pendingStatus.set(msg);return;}
        getSharedPreferences("aura",MODE_PRIVATE).edit().putString("status",msg).apply();
    }
    @Override public int onStartCommand(Intent intent,int flags,int startId){
        if(intent==null)return START_NOT_STICKY;
        if(SELFTEST.equals(intent.getAction())){
            if(running.get())status("Saída Android já está ocupada pela reprodução.");
            else new Thread(this::testOutput,"AURA-AudioTrack-selftest").start();
            return START_NOT_STICKY;
        }
        if(SEEK.equals(intent.getAction())){
            double seconds=intent.getDoubleExtra("seconds",-1);
            long token=intent.getLongExtra("trackToken",-1);
            if(running.get() && canSeek() && token==activeTrackToken && Double.isFinite(seconds) && seconds>=0)
                seekRequest.set(new SeekCommand(seconds,token));
            return START_NOT_STICKY;
        }
        if(SAMPLER.equals(intent.getAction())){
            PcmSamplerBus bus=pcmSamplers;
            String name=intent.getStringExtra("key");
            double volume=intent.getDoubleExtra("volume",.78);
            if(!running.get()||paused.get()||bus==null||!bus.trigger(name,volume))
                status("Sampler nativo ainda não está pronto");
            return START_NOT_STICKY;
        }
        if(FX.equals(intent.getAction())){
            if(!running.get())return START_NOT_STICKY;
            String mode=intent.getStringExtra("mode");
            int selected="distortion".equals(mode)?MasterCreativeFx.DISTORTION:
                    "crush".equals(mode)?MasterCreativeFx.CRUSH:
                    "overdrive".equals(mode)?MasterCreativeFx.OVERDRIVE:
                    "fuzz".equals(mode)?MasterCreativeFx.FUZZ:MasterCreativeFx.OFF;
            double amount=intent.getDoubleExtra("amount",.45);
            creativeFxAmount=Double.isFinite(amount)?Math.max(0,Math.min(1,amount)):.45;
            creativeFxMode=selected;
            rhythmDivision=Math.max(1,Math.min(16,intent.getIntExtra("division",4)));
            rhythmMode="roll".equals(mode)?1:"beatgrid".equals(mode)?2:"slip".equals(mode)?3:"overloop".equals(mode)?4:0;
            status(selected==MasterCreativeFx.OFF&&rhythmMode==0?"Efeitos PCM desativados":"Efeito PCM solicitado: "+mode);
            return START_NOT_STICKY;
        }
        if(STOP.equals(intent.getAction())){stopEngine();stopForeground(STOP_FOREGROUND_REMOVE);stopSelf();return START_NOT_STICKY;}
        if(RECORD.equals(intent.getAction())){
            recording.set(true);prepareRecorderAsync(48000);status("Gravação master habilitada · WAV PCM16");return START_NOT_STICKY;
        }
        if(RECORD_OFF.equals(intent.getAction())){
            recording.set(false);return START_NOT_STICKY;
        }
        if(PAUSE.equals(intent.getAction())){userPaused.set(true);focusPaused.set(false);paused.set(true);status("Pausando PCM…");return START_NOT_STICKY;}
        if(RESUME.equals(intent.getAction())){
            if(!running.get()){status("Estúdio PCM não está em execução");return START_NOT_STICKY;}
            if(!acquireAudioFocus()){status("Sem foco de áudio: impossível retomar PCM");return START_NOT_STICKY;}
            userPaused.set(false);focusPaused.set(false);paused.set(false);
            status("Retomando PCM…");return START_NOT_STICKY;
        }
        if(NEXT.equals(intent.getAction())){seekRequest.set(null);skipRequested.set(true);return START_NOT_STICKY;}
        if(START.equals(intent.getAction())&&!running.get()){
            paused.set(false);userPaused.set(false);focusPaused.set(false);skipRequested.set(false);
            if(!acquireAudioFocus()){
                status("Sem foco de áudio: reprodução não iniciada");
                stopSelf();return START_NOT_STICKY;
            }
            recording.set(getSharedPreferences("aura",MODE_PRIVATE).getBoolean("recordRequested",false));
            createChannel();
            Intent open=new Intent(this,MainActivity.class);
            int pflags=PendingIntent.FLAG_UPDATE_CURRENT|(Build.VERSION.SDK_INT>=23?PendingIntent.FLAG_IMMUTABLE:0);
            PendingIntent openPending=PendingIntent.getActivity(this,3,open,pflags);
            Notification note=new Notification.Builder(this,CHANNEL).setContentTitle("EG MIX — tocando")
                    .setContentText("Mixagem automática nativa").setSmallIcon(android.R.drawable.ic_media_play)
                    .setContentIntent(openPending).setOngoing(true).build();
            startForeground(7,note);
            getSharedPreferences("aura",MODE_PRIVATE).edit().putString("dj_mode","loading").apply();
            running.set(true);ACTIVE.set(true);samplerLoaded=false;fxAppliedFrames=samplerFrames=mixedFrames=mixedTransitions=hardHandoffs=0;
            if(recording.get())prepareRecorderAsync(48000);
            thread=new Thread(this::playLoop,"AURA-native-PCM-output");thread.start();
        }
        return START_NOT_STICKY;
    }
    private void testOutput(){
        AudioTrack test=null;
        try{
            final int hz=48000;
            int min=AudioTrack.getMinBufferSize(hz,AudioFormat.CHANNEL_OUT_STEREO,AudioFormat.ENCODING_PCM_16BIT);
            if(min<=0)throw new IllegalStateException("AudioTrack indisponível: "+min);
            AudioAttributes at=new AudioAttributes.Builder().setUsage(AudioAttributes.USAGE_MEDIA)
                .setContentType(AudioAttributes.CONTENT_TYPE_MUSIC).build();
            AudioFormat af=new AudioFormat.Builder().setEncoding(AudioFormat.ENCODING_PCM_16BIT)
                .setSampleRate(hz).setChannelMask(AudioFormat.CHANNEL_OUT_STEREO).build();
            test=new AudioTrack.Builder().setAudioAttributes(at).setAudioFormat(af)
                .setBufferSizeInBytes(Math.max(min*2,16384)).setTransferMode(AudioTrack.MODE_STREAM).build();
            if(test.getState()!=AudioTrack.STATE_INITIALIZED)throw new IllegalStateException("AudioTrack não inicializado");
            test.play();
            byte[] data=new byte[2048*4];
            for(int frame=0;frame<hz*2;frame+=2048){
                int count=Math.min(2048,hz*2-frame);
                for(int i=0;i<count;i++){
                    double t=(frame+i)/(double)hz;
                    double env=Math.min(1,Math.min(t/.07,(2-t)/.13));
                    short v=(short)Math.round(0.18*32767*Math.max(0,env)*Math.sin(2*Math.PI*(t<1?440:660)*t));
                    int k=i*4;data[k]=(byte)v;data[k+1]=(byte)(v>>8);data[k+2]=data[k];data[k+3]=data[k+1];
                }
                int off=0,bytes=count*4;
                while(off<bytes){int n=test.write(data,off,bytes-off,AudioTrack.WRITE_BLOCKING);
                    if(n<=0)throw new IllegalStateException("AudioTrack.write retornou "+n);
                    off+=n;
                }
            }
            status("Teste Android executado: dois tons de 440 e 660 Hz. Se não ouviu, verifique volume/saída.");
        }catch(Exception e){
            getSharedPreferences("aura",MODE_PRIVATE).edit().putString("lastCrash",Log.getStackTraceString(e)).apply();
            status("Falha no teste de som nativo: "+e);
            Log.e("AURA","Android AudioTrack test",e);
        }finally{
            if(test!=null){try{test.stop();test.release();}catch(Exception ignored){}}
            if(!running.get())stopSelf();
        }
    }
    private void createChannel(){
        NotificationManager m=(NotificationManager)getSystemService(NOTIFICATION_SERVICE);
        if(Build.VERSION.SDK_INT>=26)m.createNotificationChannel(new NotificationChannel(CHANNEL,"EG MIX — áudio",NotificationManager.IMPORTANCE_LOW));
    }
    private void stopEngine(){
        running.set(false);recording.set(false);paused.set(false);userPaused.set(false);focusPaused.set(false);
        creativeFxMode=MasterCreativeFx.OFF;rhythmMode=0;
        seekRequest.set(null);seekAvailable=false;
        pendingOutputBufferFrames.set(0);
        Thread t=thread;if(t!=null)t.interrupt();
        // Unblock a pending WRITE_BLOCKING so the render thread can release its AudioTrack.
        AudioTrack track=output;
        if(track!=null)try{track.pause();track.flush();}catch(Exception ignored){}
        releaseAudioFocus();
    }
    @Override public void onDestroy(){stopEngine();super.onDestroy();}
    private static int signed16(double x){return (int)Math.round(MixMath.clamp(x,-.999, .999)*32767);}
    private void playLoop(){
        renderThread=Thread.currentThread();
        AudioTrack audio=null;BufferedPcmDeck a=null,b=null;SessionWatcher watcher=null;AsyncDeckPreparer nextPreparer=null,seekPreparer=null;
        AsyncDeckPreparer.Result seekCandidate=null;
        boolean completed=false;
        try{
            SessionStore.Loaded s=SessionStore.load(this);
            List<TrackData> tracks=new java.util.ArrayList<>(s.tracks);
            watcher=new SessionWatcher(tracks,s.sessionId);
            getSharedPreferences("aura",MODE_PRIVATE).edit().putString("dj_mode","loading").putInt("dj_index",0).apply();
            if(tracks.isEmpty())throw new IllegalStateException("Nenhuma música pronta");
            final int hz=48000;
            int min=AudioTrack.getMinBufferSize(hz,AudioFormat.CHANNEL_OUT_STEREO,AudioFormat.ENCODING_PCM_16BIT);
            if(min<=0)throw new IllegalStateException("AudioTrack indisponível");
            AudioFormat fmt=new AudioFormat.Builder().setEncoding(AudioFormat.ENCODING_PCM_16BIT).setSampleRate(hz).setChannelMask(AudioFormat.CHANNEL_OUT_STEREO).build();
            AudioAttributes att=new AudioAttributes.Builder().setContentType(AudioAttributes.CONTENT_TYPE_MUSIC).setUsage(AudioAttributes.USAGE_MEDIA).build();
            // Reserve spare capacity, but keep the original playing latency.
            // On repeated Android underruns, the background watcher may grow the
            // active buffer incrementally without re-creating the AudioTrack.
            int capacityBytes=(int)Math.min(Integer.MAX_VALUE,Math.max((long)min*6,65536L));
            audio=new AudioTrack.Builder().setAudioFormat(fmt).setAudioAttributes(att)
                    .setBufferSizeInBytes(capacityBytes).setTransferMode(AudioTrack.MODE_STREAM).build();
            if(audio.getState()!=AudioTrack.STATE_INITIALIZED)throw new IllegalStateException("Não foi possível inicializar saída de áudio");
            final int outputCapacityFrames=audio.getBufferCapacityInFrames();
            int initialFrames=(int)Math.min(outputCapacityFrames,
                    (Math.max((long)min*3,32768L)+3)/4);
            int configuredFrames=audio.setBufferSizeInFrames(initialFrames);
            actualOutputBufferFrames.set(configuredFrames>0 ? configuredFrames : audio.getBufferSizeInFrames());
            int idx=0;double rateA=1.0;
            // A bad first file must not invalidate the entire set. This happens before
            // AudioTrack playback starts; awaitPrimed never waits on the rendering path.
            final java.util.Set<String> rejectedFiles=new java.util.HashSet<>();
            while(!tracks.isEmpty()){
                a=new BufferedPcmDeck(tracks.get(0),hz,rateA,0);
                if(a.awaitPrimed(4000))break;
                rejectedFiles.add(tracks.get(0).file.getAbsolutePath());
                Log.w("AURA","Skipping unplayable starting PCM track: "+tracks.get(0).title+"; "+a.error);
                a.close();a=null;tracks.remove(0);
            }
            if(a==null)throw new IllegalStateException("Nenhuma música com buffer PCM disponível");
            TrackPlanner.Handoff handoff=null;double blendFrames=0,blendIndex=0;
            BeatPhaseController phaseServo=null;
            PcmHandoffWatchdog handoffWatchdog = new PcmHandoffWatchdog();
            nextPreparer=new AsyncDeckPreparer(hz);
            seekPreparer=new AsyncDeckPreparer(hz);
            activeTrackToken=TRACK_TOKEN.incrementAndGet();activeTrackDuration=a.data.duration();activeTrackPosition=a.cursor/a.data.sampleRate;activeTrackTitle=a.data.title;seekAvailable=true;
            MasterAudioMeter quality=new MasterAudioMeter();
            DigitalOutputHealth health=new DigitalOutputHealth(hz);
            MixAutoRecovery repair=new MixAutoRecovery(hz);
            OutputUnderrunGuard outputGuard=new OutputUnderrunGuard(hz);
            AdaptiveOutputBuffer bufferTuner=new AdaptiveOutputBuffer(hz);
            StereoDcBlocker dcBlocker=new StereoDcBlocker(hz);
            MasterCreativeFx creativeFx=new MasterCreativeFx();
            br.com.edgard.aura.core.MasterRhythmFx rhythmFx=new br.com.edgard.aura.core.MasterRhythmFx(hz);
            PcmSamplerBus samplerBus=new PcmSamplerBus();
            pcmSamplers=samplerBus;
            try{PcmSamplerAssets.load(getApplicationContext(),samplerBus);samplerLoaded=samplerBus.ready();}
            catch(Exception e){Log.w("EG-MIX","Native PCM samplers not ready",e);status("Samplers PCM: falha de carregamento; saída auxiliar disponível.");}
            float[] dc=new float[2], fxOut=new float[2];
            incidentCapture=new PcmIncidentCapture(new java.io.File(getFilesDir(),"pcm-incidents"),hz);
            incidentCapture.setEnabled(getSharedPreferences("aura",MODE_PRIVATE)
                    .getBoolean("pcm_incident_capture_enabled",false));
            // One stereo-linked limiter prevents large transition peaks without
            // processing ordinary audio through the legacy saturating waveshaper.
            LookaheadMasterLimiter masterLimiter=new LookaheadMasterLimiter(hz,240,.94,130);
            double phaseErrorMs=0;
            boolean phaseLocked=false;
            if(idx+1<tracks.size())
                nextPreparer.request(tracks.get(idx),tracks.get(idx+1),rateA,s.beats);
            final byte[] pcm=new byte[4096*4];float[] va=new float[2],vb=new float[2],vm=new float[2];
            final PcmGlitchGuard onGuard=new PcmGlitchGuard();
            final PcmGlitchGuard nextGuard=new PcmGlitchGuard();
            audio.play();output=audio;
            Process.setThreadPriority(Process.THREAD_PRIORITY_AUDIO);
            boolean devicePaused=false;long missingSince=0, outputFrames=0, bufferMisses=0;
            boolean blendDegraded=false;
            boolean currentBlockMissing=false;
            String pendingIncidentCause=null;
            status("Tocando: "+tracks.get(idx).title);
            long refreshAt=0;long stateAt=0;
            int previousDeviceUnderruns=0;
            long seekDeadline=0;
            TrackData seekTrack=null;
            while(running.get()){
                // The decoder may add the remaining tracks while deck A is playing.
                stemOn=a.data;stemNext=b==null?null:b.data;
                long now=System.nanoTime();
                if(now-refreshAt>850_000_000L){
                    refreshAt=now;
                    // File IO, full-session scans and deduplication happen on
                    // the watcher. Only a bounded, lock-free drain runs here.
                    watcher.importAvailable(tracks,rejectedFiles);
                    if(handoff==null && idx+1<tracks.size() && b==null
                            && !nextPreparer.pending() && !nextPreparer.hasReady())
                        nextPreparer.request(tracks.get(idx),tracks.get(idx+1),rateA,s.beats);
                }
                if(now-stateAt>950_000_000L){
                    stateAt=now;
                    MasterAudioMeter.Snapshot meter=quality.snapshot();
                    // Copy only small scalar diagnostics once a second.
                    // Preference writes are performed on the playlist worker,
                    // never in the AudioTrack rendering loop.
                    final float time=(float)(a.cursor/a.data.sampleRate);
                    final int curIndex=idx;
                    final String nextTitle=idx+1<tracks.size()?tracks.get(idx+1).title:"";
                    final String mode=paused.get()?"paused":blendFrames>0?"mixing":"playing";
                    final float phaseMs=(float)phaseErrorMs;
                    final boolean lock=phaseLocked;
                    final boolean pitch=(b!=null&&b.isPitchPreserving()) || a.isPitchPreserving();
                    final boolean phrase=handoff!=null && handoff.phraseAligned && phaseServo!=null;
                    final long starves=a.starves+(b==null?0:b.starves);
                    final int bufA=a.availableFrames(),bufB=b==null?0:b.availableFrames();
                    final long framesOut=outputFrames, misses=bufferMisses;
                    final long autoDeferred=repair.deferredTransitions(),autoPhase=repair.phaseFallbacks();
                    final String lastRecovery=repair.lastReason();
                    final long healthAlerts=health.alerts();
                    // AudioTrack underruns are measured by Android's output
                    // device, unlike decoder-buffer misses and digital peaks.
                    final int deviceUnderruns=audio.getUnderrunCount();
                    if(deviceUnderruns>previousDeviceUnderruns && !devicePaused && outputFrames>hz){
                        PcmIncidentCapture diag=incidentCapture;
                        if(diag!=null)diag.trigger("ANDROID_OUTPUT_UNDERRUN");
                        status("Diagnóstico: Android reportou falta de áudio na saída");
                    }
                    // Hardware underruns are NOT an estimated beatgrid error.
                    // Only a burst triggers a bounded safety fallback; audio stays playing.
                    if(outputGuard.observe(outputFrames,deviceUnderruns,
                            !devicePaused && !paused.get() && outputFrames>hz)){
                        int nextSize=bufferTuner.onBurst(outputFrames,
                                actualOutputBufferFrames.get(),outputCapacityFrames);
                        if(nextSize>0)pendingOutputBufferFrames.set(nextSize);
                        if(phaseServo!=null){
                            phaseServo=null;
                            phaseLocked=false;
                            if(b!=null && b.isPitchPreserving() && handoff!=null){
                                try{b.setTempo(handoff.rateNext);}
                                catch(IllegalArgumentException ignored){}
                            }
                        }
                        PcmIncidentCapture diag=incidentCapture;
                        if(diag!=null)diag.trigger("ANDROID_OUTPUT_UNDERRUN_BURST");
                        status("Saída Android instável: ajuste de buffer; crossfade protegido antes do fim");
                    }
                    previousDeviceUnderruns=deviceUnderruns;
                    final long outputBursts=outputGuard.bursts();
                    final int activeDeviceBuffer=actualOutputBufferFrames.get();
                    final long bufferGrowthRequests=bufferTuner.requests();
                    final long outputCooldown=outputGuard.remainingFrames(outputFrames);
                    final float limiterGain=(float)masterLimiter.gain();
                    final long limiterReduced=masterLimiter.reducedFrames();
                    pendingTelemetry.set(()->getSharedPreferences("aura",MODE_PRIVATE).edit()
                      .putFloat("pcm_master_peak_dbfs",(float)meter.peakDbfs)
                      .putFloat("pcm_master_rms_dbfs",(float)meter.rmsDbfs)
                      .putFloat("pcm_master_stereo_correlation",(float)meter.stereoCorrelation)
                      .putFloat("pcm_master_dc_left",(float)meter.dcLeft)
                      .putFloat("pcm_master_dc_right",(float)meter.dcRight)
                      .putLong("pcm_master_pre_limit_clips",meter.preLimitClips)
                      .putLong("pcm_master_output_clips",meter.outputClips)
                      .putLong("pcm_master_silent_frames",meter.silentFrames)
                      .putFloat("pcm_master_limiter_gain",limiterGain)
                      .putLong("pcm_master_limiter_reduced_frames",limiterReduced)
                      .putFloat("pcm_phase_error_ms",phaseMs)
                      .putBoolean("pcm_phase_locked_estimated",lock)
                      .putBoolean("pcm_pitch_preserving",pitch)
                      .putBoolean("pcm_phrase_hypothesis_used",phrase)
                      .putInt("dj_index",curIndex)
                      .putFloat("dj_time",time)
                      .putString("dj_mode",mode)
                      .putString("dj_next",nextTitle)
                      .putLong("pcm_starves",starves)
                      .putInt("pcm_buffer_a",bufA)
                      .putInt("pcm_buffer_b",bufB)
                      .putLong("pcm_output_frames",framesOut)
                      .putLong("pcm_buffer_misses",misses)
                      .putLong("pcm_auto_deferred",autoDeferred)
                      .putLong("pcm_auto_phase_fallbacks",autoPhase)
                      .putString("pcm_auto_last_reason",lastRecovery)
                      .putLong("pcm_auto_digital_alerts",healthAlerts)
                      .putInt("pcm_android_output_underruns",deviceUnderruns)
                      .putLong("pcm_android_underrun_bursts",outputBursts)
                      .putInt("pcm_android_buffer_frames",activeDeviceBuffer)
                      .putInt("pcm_android_buffer_capacity_frames",outputCapacityFrames)
                      .putLong("pcm_android_buffer_growth_requests",bufferGrowthRequests)
                      .putLong("pcm_android_safety_frames_left",outputCooldown)
                      .putBoolean("pcm_incident_capture_active",incidentCaptureEnabled)
                      .apply());
                }
                activeTrackPosition=a.cursor/a.data.sampleRate;
                // Manual seek: build and prime a replacement deck off the render thread.
                // Track identity and generation prevent a late result from replacing the next song.
                seekAvailable=blendFrames<=0 && !skipRequested.get();
                SeekCommand command=seekRequest.getAndSet(null);
                if(seekTrack!=null && (seekTrack!=a.data || blendFrames>0 || skipRequested.get())){
                    seekPreparer.cancel();if(seekCandidate!=null)seekCandidate.discard();
                    seekCandidate=null;seekTrack=null;
                }
                if(command!=null && seekAvailable && command.token==activeTrackToken){
                    if(seekCandidate!=null)seekCandidate.discard();seekCandidate=null;
                    seekTrack=a.data;seekDeadline=now+4_000_000_000L;
                    seekPreparer.requestSeek(a.data,rateA,command.seconds);
                    status("POSIÇÃO: preparando novo buffer PCM…");
                }
                if(seekTrack!=null && seekCandidate==null)seekCandidate=seekPreparer.take();
                if(seekTrack!=null && (now>=seekDeadline || (seekCandidate!=null &&
                        (seekCandidate.error!=null || seekCandidate.deck.hasFailed())))){
                    if(seekCandidate!=null)seekCandidate.discard();seekCandidate=null;
                    seekPreparer.cancel();seekTrack=null;status("POSIÇÃO: busca indisponível; faixa preservada");
                }
                if(seekCandidate!=null && seekCandidate.deck.isPrimed()){
                    a.close();a=seekCandidate.deck;seekCandidate=null;seekTrack=null;
                    activeTrackPosition=a.cursor/a.data.sampleRate;
                    if(b!=null)b.close();b=null;handoff=null;nextPreparer.cancel();
                    phaseServo=null;phaseLocked=false;blendFrames=0;blendIndex=0;blendDegraded=false;
                    onGuard.bridgeDiscontinuity();nextGuard.reset();samplerBus.resetHistory();
                    handoffWatchdog.reset();repair.transitionEnded();missingSince=0;stateAt=0;
                    if(idx+1<tracks.size())nextPreparer.request(tracks.get(idx),tracks.get(idx+1),rateA,s.beats);
                    if(devicePaused)audio.flush();
                    status("POSIÇÃO PCM: "+(int)(a.cursor/a.data.sampleRate)+" s");
                }
                // Closing a paused recording must not wait for playback to resume.
                if(!recording.get() && recorder!=null){recorder.close();recorder=null;}
                if(paused.get()){
                    if(!devicePaused){audio.pause();devicePaused=true;}
                    try{Thread.sleep(20);}catch(InterruptedException ex){break;}
                    continue;
                }
                if(devicePaused){audio.play();devicePaused=false;}
                int cursor=0;
                currentBlockMissing=false;
                creativeFx.configure(creativeFxMode,creativeFxAmount);
                rhythmFx.configure(rhythmMode,rhythmDivision,a.data.trustworthyTempo()?a.data.bpm*a.getTempo():a.data.tailConfidence>=.40?a.data.tailBpm*a.getTempo():0,creativeFxAmount);
                while(cursor<pcm.length&&running.get()){
                    // Attach a background-prepared deck; never allocate its PCM ring here.
                    if(b==null && handoff==null && (outputFrames&255)==0){
                        AsyncDeckPreparer.Result prepared=nextPreparer.take();
                        if(prepared!=null){
                            if(idx+1<tracks.size() && prepared.current==tracks.get(idx)
                                    && prepared.next==tracks.get(idx+1) && prepared.error==null){
                                b=prepared.deck;handoff=prepared.handoff;
                            }else{
                                prepared.discard();
                                if(prepared.error!=null && idx+1<tracks.size()
                                        && prepared.next==tracks.get(idx+1)){
                                    String rejected=tracks.get(idx+1).title;
                                    rejectedFiles.add(tracks.get(idx+1).file.getAbsolutePath());
                                    tracks.remove(idx+1);
                                    status("Falha ao preparar próxima faixa: "+rejected);
                                }
                            }
                        }
                        if(b==null && idx+1<tracks.size() && !nextPreparer.pending()
                                && !nextPreparer.hasReady())
                            nextPreparer.request(tracks.get(idx),tracks.get(idx+1),rateA,s.beats);
                    }
                    // A corrupt incoming track must not terminate the playing deck.
                    // Remove it from this set and try the next eligible track.
                    if(b!=null && (b.hasFailed() || (b.atEnd() && !b.isPrimed()))){
                        pendingIncidentCause="NEXT_DECODER_FAILED";
                        String badTitle=tracks.get(idx+1).title;
                        rejectedFiles.add(tracks.get(idx+1).file.getAbsolutePath());
                        if(b!=null)b.close();b=null;tracks.remove(idx+1);
                        handoff=null;phaseServo=null;phaseLocked=false;
                        blendFrames=0;blendIndex=0;blendDegraded=false;
                        nextGuard.reset();
                        nextPreparer.cancel();
                        if(idx+1<tracks.size())
                            nextPreparer.request(tracks.get(idx),tracks.get(idx+1),rateA,s.beats);
                        status("Música indisponível ignorada: "+badTitle);
                    }
                    // Recover a failed/exhausted outgoing deck. A slow incoming deck
                    // gets a bounded deadline instead of silently terminating the set.
                    // A producer failure does not invalidate already buffered audio.
                    boolean outgoingUnavailable=a.atEnd() ||
                            (a.hasFailed() && a.availableFrames()<2);
                    PcmHandoffWatchdog.State transition=handoffWatchdog.evaluate(
                            outgoingUnavailable,b!=null||nextPreparer.pending(),b!=null&&b.isPrimed(),
                            b!=null&&b.hasFailed(),System.nanoTime());
                    if(transition==PcmHandoffWatchdog.State.TIMED_OUT
                            && idx+1<tracks.size()){
                        String timeoutTitle=tracks.get(idx+1).title;
                        rejectedFiles.add(tracks.get(idx+1).file.getAbsolutePath());
                        if(b!=null)b.close();b=null;tracks.remove(idx+1);
                        handoff=null;phaseServo=null;phaseLocked=false;
                        blendFrames=0;blendIndex=0;blendDegraded=false;
                        nextGuard.reset();
                        nextPreparer.cancel();
                        if(idx+1<tracks.size())
                            nextPreparer.request(tracks.get(idx),tracks.get(idx+1),rateA,s.beats);
                        status("Próxima faixa demorou demais, ignorando: "+timeoutTitle);
                        // Evaluate the next candidate on the next iteration.
                    }
                    if(outgoingUnavailable && b!=null && b.isPrimed() && blendFrames<=0){
                        hardHandoffs++;
                        a.close();a=b;idx++;activeTrackToken=TRACK_TOKEN.incrementAndGet();activeTrackDuration=a.data.duration();activeTrackPosition=a.cursor/a.data.sampleRate;activeTrackTitle=a.data.title;rateA=a.getTempo();phaseServo=null;phaseLocked=false;
                        b=null;handoff=null;phaseServo=null;phaseLocked=false;blendFrames=0;blendIndex=0;blendDegraded=false;
                        onGuard.fadeInFromSilence();nextGuard.reset();
                        nextPreparer.cancel();
                        if(idx+1<tracks.size())
                            nextPreparer.request(tracks.get(idx),tracks.get(idx+1),rateA,s.beats);
                        status("PCM: próxima faixa recuperada no fim da anterior");
                    }
                    double secA=a.cursor/a.data.sampleRate;
                    if(outgoingUnavailable && b==null && idx+1>=tracks.size() && libraryPreparing && missingSince!=0 && System.nanoTime()-missingSince>20_000_000_000L){status("Próxima faixa ainda em análise; sessão encerrada com segurança.");completed=true;break;}
                    // The Android audio sample clock is the only source of timing.
                    if(handoff==null && outgoingUnavailable && b==null
                            && idx+1>=tracks.size() && !nextPreparer.pending() && !libraryPreparing){
                        completed=true;break;
                    }
                    // Keep an early NEXT request pending until NEXT is actually ready.
                    if(seekTrack==null && skipRequested.get() && b!=null && b.isPrimed() && blendFrames<=0
                            && repair.mayStart(outputFrames)){
                        skipRequested.set(false);
                        double startError=BeatPhaseController.phaseErrorBeats(
                                a.cursor/a.data.sampleRate,a.data.tailBpm,a.data.tailPhaseSeconds,
                                b.cursor/b.data.sampleRate,b.data.bpm,b.data.phaseSeconds);
                        boolean eligible=handoff.beatmatch && BeatPhaseController.suitableForBeatmatch(startError);
                        phaseServo=eligible ? new BeatPhaseController(handoff.rateNext) : null;
                        phaseLocked=false;
                        double available=(a.data.frames-a.cursor)/a.data.sampleRate/rateA;
                        blendFrames=Math.max(1,Math.min(2.2,available-.10)*hz);blendIndex=0;blendDegraded=false;
                        status("Próxima faixa: transição manual protegida");
                    }
                    double available=(a.data.frames-a.cursor)/a.data.sampleRate/rateA;
                    double audibleRemaining=(a.data.audibleEnd()-secA)/rateA;
                    if(seekTrack==null && handoff!=null && b!=null && b.isPrimed() && blendFrames<=0 &&
                       LiveTransitionPolicy.shouldStart(secA,handoff.startASeconds,Math.max(.001,audibleRemaining),handoff.durationSeconds,
                            repair.mayStart(outputFrames)&&outputGuard.mayStartAutomatic(outputFrames))){
                        blendFrames=Math.max(1,Math.round(LiveTransitionPolicy.duration(Math.min(available,Math.max(.12,audibleRemaining)),handoff.durationSeconds)*hz));
                        blendIndex=0;blendDegraded=false;
                        double startError=BeatPhaseController.phaseErrorBeats(
                                a.cursor/a.data.sampleRate,a.data.tailBpm,a.data.tailPhaseSeconds,
                                b.cursor/b.data.sampleRate,b.data.bpm,b.data.phaseSeconds);
                        boolean eligible=handoff.beatmatch && BeatPhaseController.suitableForBeatmatch(startError);
                        phaseServo=eligible ? new BeatPhaseController(handoff.rateNext) : null;
                        phaseLocked=false;
                        status("Mixando: "+tracks.get(idx).title+" → "+tracks.get(idx+1).title+
                                (eligible?" (beatmatch candidato)":" (crossfade seguro)"));
                    }
                    boolean gotOn=a.next(va);
                    if(!gotOn){
                        // Do not abort the set while a viable incoming deck is loading.
                        // The glitch guard gradually silences the ended/failed deck.
                        // Do not end the set while the asynchronous next-deck
                        // preparation is still viable and inside its deadline.
                        if(a.hasFailed() && b==null && idx+1>=tracks.size())
                            throw new java.io.IOException("Falha no buffer PCM ON",a.error);
                        if(a.atEnd() && b==null && idx+1>=tracks.size()
                                && !nextPreparer.pending() && !nextPreparer.hasReady() && !libraryPreparing){
                            completed=true;break;
                        }
                        bufferMisses++;
                        currentBlockMissing=true;
                        if(missingSince==0)missingSince=System.nanoTime();
                        if(System.nanoTime()-missingSince>3_000_000_000L && !outgoingUnavailable)
                            throw new java.io.IOException("Buffer PCM ON sem dados por 3 segundos");
                    }else missingSince=0;
                    // Guard brief underruns against a one-sample drop to hard zero.
                    onGuard.process(va,gotOn);
                    double left=va[0],right=va[1];
                    if(blendFrames>0 && b!=null){
                        if(phaseServo!=null && (outputFrames&2047)==0){
                            double error=BeatPhaseController.phaseErrorBeats(
                                a.cursor/a.data.sampleRate,a.data.tailBpm,a.data.tailPhaseSeconds,
                                b.cursor/b.data.sampleRate,b.data.bpm,b.data.phaseSeconds);
                            double targetRate=phaseServo.update(error,a.data.tailBpm*rateA,2048.0/hz);
                            if(b.isPitchPreserving())b.setTempo(targetRate);
                            phaseErrorMs=phaseServo.errorMs();phaseLocked=phaseServo.locked();
                            if(repair.onPhaseEstimate(error)==MixAutoRecovery.Action.CANCEL_BEATMATCH){
                                phaseServo=null;phaseLocked=false;
                                // Return to the planned constant tempo instead of leaving
                                // the last PI correction latched indefinitely.
                                if(b.isPitchPreserving() && handoff!=null){
                                    try { b.setTempo(handoff.rateNext); }
                                    catch(IllegalArgumentException ignored){}
                                }
                                PcmIncidentCapture cap=incidentCapture;
                                if(cap!=null)cap.trigger("PHASE_ESTIMATE_UNRELIABLE");
                                status("Autocorreção: beatmatch incerto desativado; crossfade seguro");
                            }
                        }
                        boolean hasNext=b.next(vb);
                        nextGuard.process(vb,hasNext);
                        MixAutoRecovery.Action recovery=repair.onIncomingFrame(hasNext,true,outputFrames);
                        if(!hasNext){
                            currentBlockMissing=true;
                            // This failure is handled at the top of the next PCM frame.
                            // Keep ON at full gain rather than throwing and stopping the set.
                            bufferMisses++;
                            if(!blendDegraded){
                                blendDegraded=true;
                                status("PCM NEXT sem buffer: sincronização cancelada, crossfade de segurança");
                            }
                            // The master continues with ON at its full gain until NEXT recovers.
                            // This is degraded fallback, NOT a verified beatmatch.
                            left=va[0];right=va[1];
                            if(recovery==MixAutoRecovery.Action.DEFER_CROSSFADE){
                                blendFrames=0;blendIndex=0;phaseServo=null;phaseLocked=false;
                                blendDegraded=true;
                                PcmIncidentCapture cap=incidentCapture;
                                if(cap!=null)cap.trigger("INCOMING_BUFFER_STARVATION");
                                status("Autocorreção: crossfade adiado para recuperar o pré-buffer");
                            }
                        }
                        if(hasNext && blendFrames>0){
                            if(gotOn&&Math.abs(va[0])+Math.abs(va[1])>1e-5&&Math.abs(vb[0])+Math.abs(vb[1])>1e-5)mixedFrames++;
                            double t=MixMath.clamp(blendIndex/blendFrames,0,1);
                            double ga=MixMath.gain(s.style,false,t),gb=MixMath.gain(s.style,true,t);
                            double la=a.split(va[0],true,hz),ra=a.split(va[1],false,hz);
                            double lb=b.split(vb[0],true,hz),rb=b.split(vb[1],false,hz);
                            left=ga*(va[0]-la)+gb*(vb[0]-lb)+MixMath.bassGain(false,t)*la+MixMath.bassGain(true,t)*lb;
                            right=ga*(va[1]-ra)+gb*(vb[1]-rb)+MixMath.bassGain(false,t)*ra+MixMath.bassGain(true,t)*rb;
                        }
                        if(hasNext && ++blendIndex>=blendFrames){
                            mixedTransitions++;
                            a.close();a=b;idx++;activeTrackToken=TRACK_TOKEN.incrementAndGet();activeTrackDuration=a.data.duration();activeTrackPosition=a.cursor/a.data.sampleRate;activeTrackTitle=a.data.title;rateA=a.getTempo();phaseServo=null;phaseLocked=false;b=null;handoff=null;blendFrames=0;blendDegraded=false;
                            onGuard.reset();nextGuard.reset();
                            nextPreparer.cancel();
                            if(idx+1<tracks.size())
                                nextPreparer.request(tracks.get(idx),tracks.get(idx+1),rateA,s.beats);
                            repair.transitionEnded();
                            status("Tocando: "+tracks.get(idx).title);
                        }
                    }
                    creativeFx.process(left,right,fxOut);
                    rhythmFx.process(fxOut[0],fxOut[1],fxOut);
                    // One-shots bypass music distortion but enter the measured,
                    // protected PCM master before DC removal and lookahead limiting.
                    samplerBus.remember((fxOut[0]+fxOut[1])*.5);
                    double sampler= samplerBus.next();
                    if(Math.abs(fxOut[0]-left)+Math.abs(fxOut[1]-right)>1e-4)fxAppliedFrames++;
                    if(Math.abs(sampler)+Math.abs(samplerBus.right())>1e-5)samplerFrames++;
                    dcBlocker.process(fxOut[0]+sampler,fxOut[1]+samplerBus.right(),dc);
                    masterLimiter.process(dc[0],dc[1],vm);
                    int l=signed16(vm[0]),r=signed16(vm[1]);
                    quality.accept(left,right,l,r);
                    pcm[cursor++]=(byte)l;pcm[cursor++]=(byte)(l>>8);
                    pcm[cursor++]=(byte)r;pcm[cursor++]=(byte)(r>>8);
                    outputFrames++;
                }
                stemOn=a.data;stemNext=b==null?null:b.data;
                if(cursor==0)break;
                PcmIncidentCapture cap=incidentCapture;
                if(cap!=null){
                    cap.offer(pcm,cursor);
                    if(pendingIncidentCause!=null){cap.trigger(pendingIncidentCause);pendingIncidentCause=null;}
                }
                DigitalOutputHealth.Fault fault=health.observe(pcm,cursor,currentBlockMissing);
                if(fault!=DigitalOutputHealth.Fault.NONE){
                    if(cap!=null)cap.trigger(fault.name());
                    status("Diagnóstico PCM: "+fault+" (captura local apenas se autorizada)");
                }
                // No file creation and no WAV writes on the audio rendering path.
                AsyncWavRecorder localRecorder=recorder;
                if(recording.get() && localRecorder!=null){
                    if(!localRecorder.offer(pcm,cursor)){
                        recording.set(false);
                        status("Gravador WAV: fila cheia ou erro de escrita");
                        localRecorder.close();recorder=null;
                    }
                }else if(!recording.get() && localRecorder!=null){
                    localRecorder.close();recorder=null;
                }
                int written=0;
                while(written<cursor&&running.get()){
                    int n=audio.write(pcm,written,cursor-written,AudioTrack.WRITE_BLOCKING);
                    // STOP pauses the device to unblock WRITE_BLOCKING; a short
                    // transfer during intentional shutdown is not a crash.
                    if(!running.get())break;
                    if(n<=0){
                        if(cap!=null)cap.trigger("AUDIOTRACK_WRITE_FAILURE");
                        throw new IllegalStateException("Falha AudioTrack ("+n+")");
                    }
                    written+=n;
                }
                if(completed)break;
            }
            // Natural EOF is not a STOP. Write the lookahead tail before release.
            if(completed && running.get()){
                byte[] tail=new byte[masterLimiter.latencyFrames()*4];
                int nbytes=0;
                for(int frame=0;frame<masterLimiter.latencyFrames();frame++){
                    masterLimiter.process(0,0,vm);
                    int l=signed16(vm[0]),r=signed16(vm[1]);
                    quality.accept(0,0,l,r);
                    tail[nbytes++]=(byte)l;tail[nbytes++]=(byte)(l>>8);
                    tail[nbytes++]=(byte)r;tail[nbytes++]=(byte)(r>>8);
                    outputFrames++;
                }
                AsyncWavRecorder localRecorder=recorder;
                if(recording.get() && localRecorder!=null)localRecorder.offer(tail,nbytes);
                int off=0;
                while(off<nbytes&&running.get()){
                    int n=audio.write(tail,off,nbytes-off,AudioTrack.WRITE_BLOCKING);
                    if(n<=0)throw new IllegalStateException("Falha ao finalizar saída PCM: "+n);
                    off+=n;
                }
            }
            if(completed)status("Set concluído");else status("Reprodução encerrada");
        }catch(Exception e){
            getSharedPreferences("aura",MODE_PRIVATE).edit().putString("lastCrash",Log.getStackTraceString(e)).apply();
            status("ERRO: "+e.getClass().getSimpleName()+" — "+e.getMessage());
        }
        finally{
            try{if(a!=null)a.close();}catch(Exception ignored){}
            try{if(b!=null)b.close();}catch(Exception ignored){}
            if(recorder!=null){recorder.close();recorder=null;}
            if(seekCandidate!=null)seekCandidate.discard();
            if(seekPreparer!=null)seekPreparer.close();
            stemOn=stemNext=null;seekAvailable=false;seekRequest.set(null);activeTrackDuration=0;activeTrackPosition=0;activeTrackTitle="";
            if(nextPreparer!=null)nextPreparer.close();
            if(watcher!=null)watcher.close();
            PcmIncidentCapture cap=incidentCapture;
            if(cap!=null){cap.close();incidentCapture=null;}
            // Final state is flushed only after the audio loop has stopped.
            renderThread=null;
            flushDeferredDiagnostics();
            output=null;
            pendingOutputBufferFrames.set(0);
            actualOutputBufferFrames.set(0);
            if(audio!=null){
                try{
                    // In streaming mode stop() drains queued audio. pause()+flush()
                    // dropped the final buffers even after flushing the limiter.
                    if(completed && running.get())audio.stop();
                    else{audio.pause();audio.flush();}
                }catch(Exception e){Log.w("AURA","PCM audio device shutdown",e);}
                finally{try{audio.release();}catch(Exception ignored){}}
            }
            running.set(false);ACTIVE.set(false);samplerLoaded=false;releaseAudioFocus();
            getSharedPreferences("aura",MODE_PRIVATE).edit().putString("dj_mode","idle")
                    .putLong("live_fx_frames",fxAppliedFrames).putLong("live_sampler_frames",samplerFrames)
                    .putLong("live_mixed_frames",mixedFrames).putLong("live_mixed_transitions",mixedTransitions)
                    .putLong("live_hard_handoffs",hardHandoffs).apply();
            stopForeground(STOP_FOREGROUND_REMOVE);stopSelf();
        }
    }
}
