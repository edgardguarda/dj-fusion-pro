package br.com.edgard.aura.core;
/** Beat-length master effects. Source playback continues underneath; no allocation on render. */
public final class MasterRhythmFx {
    public static final int OFF=0,ROLL=1,GATE=2,SLIP=3,OVERLOOP=4;
    private final float[] l,r;
    private final int hz;
    private int write,filled,mode,requested,period=1,phase,anchor,activeDivision=1;
    private int requestedPeriod=1,requestedDivision=1;
    private double wet,amount;
    public MasterRhythmFx(int hz){this.hz=hz;l=new float[hz*8];r=new float[l.length];}
    public void configure(int m,int division,double bpm){configure(m,division,bpm,1);}
    public void configure(int m,int division,double bpm,double intensity){
        amount=Double.isFinite(intensity)?Math.max(0,Math.min(1,intensity)):0;
        requested=m>=ROLL&&m<=OVERLOOP&&Double.isFinite(bpm)&&bpm>=70&&bpm<=180&&amount>0?m:OFF;
        requestedDivision=Math.max(1,Math.min(16,division));
        if(requested!=OFF){
            int p=(int)Math.round(hz*60.0/bpm/requestedDivision*(m==OVERLOOP?4:m==SLIP?2:1));
            requestedPeriod=Math.max(64,Math.min(l.length/2,p));
        }else requestedPeriod=1;
        // Reconfigure only for a deliberate subdivision change or a material tempo change.
        // Small WSOLA servo adjustments must not continually restart the effect.
        if(changing()&&wet<.001&&(requested==OFF||requested==GATE||filled>=requestedPeriod)){
            mode=requested;period=requestedPeriod;activeDivision=requestedDivision;phase=0;
            anchor=(write-period+l.length)%l.length;
        }
    }
    private boolean changing(){return requested!=mode||(requested!=OFF&&(requestedDivision!=activeDivision||Math.abs(requestedPeriod-period)>Math.max(32,period/100)));}
    public void process(float a,float b,float[] out){
        double target=!changing()&&mode!=OFF&&(mode==GATE||filled>=period)?amount:0;
        wet+=(target-wet)*.008;
        float x=a,y=b;
        if(mode==GATE){double t=phase/(double)period;double gain=Math.min(1,Math.min(t,.65-t)*period/96.0);gain=Math.max(0,gain);x=(float)(a*gain);y=(float)(b*gain);}
        else if(mode!=OFF&&filled>=period){int pos=(anchor+phase)%l.length;x=l[pos];y=r[pos];double edge=Math.min(1,Math.min(phase,period-1-phase)/96.0);x=(float)(a+(x-a)*edge);y=(float)(b+(y-b)*edge);if(mode==OVERLOOP){x=(a+x)*.5f;y=(b+y)*.5f;}}
        out[0]=(float)(a+(x-a)*wet);out[1]=(float)(b+(y-b)*wet);
        if(mode==OFF||mode==GATE||wet<.001){l[write]=a;r[write]=b;write=(write+1)%l.length;filled=Math.min(l.length,filled+1);}
        phase=(phase+1)%period;
    }
}
