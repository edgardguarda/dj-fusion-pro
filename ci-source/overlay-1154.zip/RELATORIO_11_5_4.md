# EG MIX 11.5.4 — Controle e auditoria funcional

Base: pacote único 11.5.3, commit 7e6fb70fe3b4be142e4063c24839dd39e80c134a.

## Defeitos reproduzidos e corrigidos

- MasterRhythmFx: mudar a divisão enquanto o mesmo efeito permanecia ativo não alterava o período. Teste de reprodução da falha: 120 BPM, 48 kHz, divisão 4 = 6000 quadros; mudar para divisão 8 mantinha 6000 em vez de 3000. A correção reconfigura divisão e mudanças de andamento superiores a 1%, com transição suave e sem reiniciar continuamente por pequenas oscilações do servo WSOLA.
- A intensidade recebida do controle era usada somente nos efeitos de timbre. Agora a intensidade controla também a mistura dry/wet dos quatro efeitos rítmicos, com bypass em zero. O teste mede o sinal, e não apenas o estado do botão.
- Diagnóstico exibia versão 11.5.2 embora o APK fosse 11.5.3. Corrigido para 11.5.4.

## Escopo

A revisão abrangeu as funcionalidades observáveis e os caminhos principais do código; não é certificação de todas as linhas ou combinações possíveis. Os demais recursos permanecem presentes. A ordem inteligente progressiva, o cache identificado por URI, os controles exclusivos do modo clássico, o funcionamento com a tela bloqueada e a inferência ARM64 têm pendências descritas no relatório funcional de entrega. Não houve nova inferência HTDemucs no Android nesta revisão. A chave de assinatura antiga não está disponível.
