#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")/.."
mkdir -p build-smart
javac -encoding UTF-8 -d build-smart app/src/main/java/br/com/edgard/aura/core/{TrackData,StemStorage,TrackPlanner,HarmonicAnalyzer,MasterRhythmFx}.java tests/SmartStudioTest.java tests/RhythmControlRegressionTest.java
java -cp build-smart SmartStudioTest "$@"

java -cp build-smart RhythmControlRegressionTest
