import br.com.edgard.aura.core.MasterRhythmFx;
import java.lang.reflect.Field;
public class RhythmControlRegressionTest {
 static int checks; static void check(boolean x){checks++;if(!x)throw new AssertionError("check "+checks);}
 static int period(MasterRhythmFx fx)throws Exception{Field f=MasterRhythmFx.class.getDeclaredField("period");f.setAccessible(true);return f.getInt(fx);}
 static float[] out=new float[2];
 static void run(MasterRhythmFx fx,int mode,int div,double bpm,double amount,int frames){for(int i=0;i<frames;i++){fx.configure(mode,div,bpm,amount);fx.process(.5f,-.25f,out);check(Float.isFinite(out[0])&&Float.isFinite(out[1]));}}
 public static void main(String[] args)throws Exception{
  for(int mode=1;mode<=4;mode++){
   MasterRhythmFx fx=new MasterRhythmFx(48000);run(fx,0,4,120,0,96000);
   run(fx,mode,4,120,1,24000);int p=period(fx);check(p==6000*(mode==4?4:mode==3?2:1));
   run(fx,mode,8,120,1,24000);check(period(fx)==p/2);
   run(fx,mode,8,100,1,24000);check(period(fx)==Math.round(p*.6));
   run(fx,mode,8,100.2,1,24000);check(period(fx)==Math.round(p*.6));
   run(fx,mode,8,100,0,4000);check(Math.abs(out[0]-.5)<.0001&&Math.abs(out[1]+.25)<.0001);
  }
  MasterRhythmFx fx=new MasterRhythmFx(48000);run(fx,0,4,120,0,30000);run(fx,2,4,120,.25,18000);
  double min=1,max=-1;for(int i=0;i<12000;i++){fx.configure(2,4,120,.25);fx.process(.5f,-.25f,out);min=Math.min(min,out[0]);max=Math.max(max,out[0]);}
  check(Math.abs(min-.375)<.001&&Math.abs(max-.5)<.001);
  run(fx,2,4,120,0,4000);check(Math.abs(out[0]-.5)<.0001);
  System.out.println("PASS rhythm control: "+checks+" checks; live subdivision, material tempo change, servo stability, stereo bypass and 25% wet mix");
 }
}
