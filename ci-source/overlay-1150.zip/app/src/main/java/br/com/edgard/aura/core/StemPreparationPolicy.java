package br.com.edgard.aura.core;

/** Disk budgeting for the 44.1 kHz neural pipeline; PCM input already exists. */
public final class StemPreparationPolicy {
    private StemPreparationPolicy() {}
    public static final long MAX_FRAMES=1200L*44100, RESERVE=256L*1024*1024;
    public static boolean nativeSupported(int sourceRate){return TrackData.nativeStemRate(sourceRate);}
    public static long requiredBytes(long frames, boolean export){
        if(frames<=0||frames>MAX_FRAMES)throw new IllegalArgumentException("Duração fora do limite");
        // Raw ten-channel float staging + aligned WAVs. For native-only, omit the original WAV.
        // Raw staging is deleted before cache publication (24 bytes/frame copy).
        // Export can share the private filesystem: 30 local + 30 external + 24 cache.
        return Math.addExact(Math.multiplyExact(frames,export?84L:64L),RESERVE);
    }
    public static boolean ready(boolean model, boolean song, boolean export, boolean destination, boolean idle){
        return model&&song&&idle&&(!export||destination);
    }
}
