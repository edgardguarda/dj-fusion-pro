import br.com.edgard.aura.core.*;
import java.io.*;
import java.nio.file.*;
import java.util.*;

/** Verify mapping from 48 kHz master clock to 44.1 kHz neural WAVs. */
public final class NativeStem48kTest {
 static final int N=88200, SOURCE=96000; static int checks;
 static void ok(boolean b,String m){checks++;if(!b)throw new AssertionError(m);}
 static void le(DataOutputStream o,long n,int bytes)throws IOException{for(int i=0;i<bytes;i++)o.write((int)(n>>>(i*8))&255);}
 static int sample(int i,int role,int ch){return (int)(Math.sin(i*(.017+role*.009)+ch*.37)*(600+role*400));}
 static double expected(long i,int role,int ch){long pos=i*44100, x=Math.min(N-1,pos/48000),y=Math.min(N-1,x+1);double t=(pos%48000)/48000.;return (sample((int)x,role,ch)*(1-t)+sample((int)y,role,ch)*t)/32768.;}
 static void wav(File f,int role)throws IOException{try(DataOutputStream o=new DataOutputStream(new BufferedOutputStream(new FileOutputStream(f)))){o.writeBytes("RIFF");le(o,N*6+36,4);o.writeBytes("WAVEfmt ");le(o,16,4);le(o,1,2);le(o,2,2);le(o,44100,4);le(o,264600,4);le(o,6,2);le(o,24,2);o.writeBytes("data");le(o,N*6,4);for(int i=0;i<N;i++)for(int ch=0;ch<2;ch++)le(o,sample(i,role,ch)*256,3);}}
 static TrackData track(File f){return new TrackData("48k",f,48000,SOURCE,120,.8,0,.2);}
 static void next(BufferedPcmDeck d,float[] out)throws Exception{long deadline=System.nanoTime()+2_000_000_000L;while(!d.next(out)){if(d.hasFailed()||System.nanoTime()>deadline)throw new IOException("deck stalled",d.error);Thread.sleep(1);}}
 static void eq(float a,double b,double tol,String m){ok(Math.abs(a-b)<tol,m+" "+a+" "+b);}
 public static void main(String[] args)throws Exception{
  Path root=Files.createTempDirectory("native-48k");File dir=root.toFile(),pcm=new File(dir,"source.pcm"),export=new File(dir,"export");export.mkdir();
  try{try(DataOutputStream o=new DataOutputStream(new BufferedOutputStream(new FileOutputStream(pcm)))){for(int i=0;i<SOURCE;i++)for(int ch=0;ch<2;ch++){double v=0;for(int k=0;k<4;k++)v+=expected(i,k,ch);le(o,Math.round(v*32768),2);}}
   for(int k=0;k<4;k++)wav(new File(export,"track."+TrackData.STEM_NAMES[k]+".wav"),k);
   ok(TrackData.stemFrames(SOURCE,48000)==N,"frame count");ok(TrackData.stemKey(pcm,44100).equals(TrackData.pcmHash(pcm)),"legacy cache");ok(!TrackData.stemKey(pcm,48000).equals(TrackData.pcmHash(pcm)),"distinct rate key");
   TrackData.publishStems(dir,pcm,48000,SOURCE,export,"track");File pack=TrackData.locateStems(dir,pcm,48000,SOURCE);ok(pack!=null,"published");ok(TrackData.locateStems(dir,pcm,44100,SOURCE)==null,"rate separation");
   TrackData a=track(pcm),ref=track(pcm);a.attachStems(pack);a.setStemPreset(8);
   for(int start:new int[]{0,8123,92000})try(BufferedPcmDeck d=new BufferedPcmDeck(a,48000,1,start/48000.,false)){ok(d.awaitPrimed(3000),"prime");float[] x=new float[2];for(int i=0;i<Math.min(16000,SOURCE-start-2);i++){next(d,x);for(int ch=0;ch<2;ch++)eq(x[ch],expected(start+i,3,ch),.000003,"seek and rate mapping");}}
   a.setStemPreset(15);try(BufferedPcmDeck d=new BufferedPcmDeck(a,48000,1.04,.13,true);BufferedPcmDeck r=new BufferedPcmDeck(ref,48000,1.04,.13,true)){ok(d.awaitPrimed(3000)&&r.awaitPrimed(3000),"WSOLA prime");float[] x=new float[2],y=new float[2];for(int i=0;i<25000;i++){next(d,x);next(r,y);for(int ch=0;ch<2;ch++)eq(x[ch],y[ch],.000035,"WSOLA aligned sum");}a.setStemPreset(0);for(int i=0;i<1600;i++)next(d,x);eq(x[0],0,.000001,"mute L");eq(x[1],0,.000001,"mute R");}
   System.out.println("PASS NativeStem48kTest: "+checks+" checks (48 kHz master, 44.1 kHz stems, seek, WSOLA, cache identity)");
  }finally{try(var paths=Files.walk(root)){paths.sorted(Comparator.reverseOrder()).forEach(p->p.toFile().delete());}}
 }
}
