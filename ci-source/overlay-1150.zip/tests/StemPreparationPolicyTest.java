import br.com.edgard.aura.core.*;
import java.io.*;
import java.nio.file.*;
import java.util.*;
public class StemPreparationPolicyTest {
 static int n;static void check(boolean x){n++;if(!x)throw new AssertionError("check "+n);}
 public static void main(String[] args)throws Exception{
  for(int mask=0;mask<32;mask++){
   boolean model=(mask&1)!=0,song=(mask&2)!=0,export=(mask&4)!=0,dest=(mask&8)!=0,idle=(mask&16)!=0;
   check(StemPreparationPolicy.ready(model,song,export,dest,idle)==(model&&song&&idle&&(!export||dest)));
  }
  for(int rate:new int[]{8000,22050,32000,44100,48000,96000,192000})check(StemPreparationPolicy.nativeSupported(rate)==(rate==44100||rate==48000));
  for(long frames:new long[]{1,44100,44100*60,StemPreparationPolicy.MAX_FRAMES}){
   check(StemPreparationPolicy.requiredBytes(frames,false)==64*frames+StemPreparationPolicy.RESERVE);
   check(StemPreparationPolicy.requiredBytes(frames,true)==84*frames+StemPreparationPolicy.RESERVE);
  }
  for(long frames:new long[]{-1,0,StemPreparationPolicy.MAX_FRAMES+1,Long.MAX_VALUE})try{StemPreparationPolicy.requiredBytes(frames,false);throw new AssertionError("duration");}catch(IllegalArgumentException ok){n++;}
  Path dir=Files.createTempDirectory("optional-export");try{
   int frames=8195;float[] master=new float[2*frames],stems=new float[8*frames];Random r=new Random(81);for(int i=0;i<master.length;i++)master[i]=r.nextFloat()*2-1;for(int i=0;i<stems.length;i++)stems[i]=r.nextFloat()*3-1.5f;
   File raw=dir.resolve("raw").toFile();NeuralStemPipeline.Staging s=new NeuralStemPipeline.Staging(raw);try(NeuralStemPipeline.Staging close=s){s.write(master,stems,frames,frames);}
   File only=dir.resolve("native").toFile(),all=dir.resolve("export").toFile();s.export(only,"x",false);s.export(all,"x",true);
   check(only.list().length==4);check(all.list().length==5);check(!new File(only,"x.wav").exists());
   for(String role:new String[]{"drums","bass","other","vocals"}){File a=new File(only,"x."+role+".wav"),b=new File(all,"x."+role+".wav");check(a.length()==44+6L*frames);check(Arrays.equals(Files.readAllBytes(a.toPath()),Files.readAllBytes(b.toPath())));}
  }finally{try(var files=Files.walk(dir)){files.sorted(Comparator.reverseOrder()).forEach(p->p.toFile().delete());}}
  System.out.println("PASS StemPreparationPolicyTest: "+n+" checks");
 }
}
