#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")/.."
build=$(mktemp -d);trap 'rm -rf "$build"' EXIT
javac -d "$build" app/src/main/java/br/com/edgard/aura/core/{TrackData,StemStorage,BufferedPcmDeck,WsolaStereoStretch}.java tests/NativeStemDeckTest.java tests/NativeStem48kTest.java
java -cp "$build" NativeStemDeckTest

java -cp "$build" NativeStem48kTest
