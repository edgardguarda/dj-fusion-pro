# EG MIX 11.5.0 — Neural Multirate (beta)

## Alterações
- Estúdio PCM: suporte a músicas decodificadas a 44,1 ou 48 kHz, com modelo HTDemucs e WAVs neurais mantidos a 44,1 kHz.
- Reamostragem linear de 44,1 a 48 kHz no produtor de buffers, antes da sobreposição WSOLA compartilhada. Relógio único dos quatro stems; preservação do código de reprodução direta a 44,1 kHz. A interpolação é uma solução de custo baixo, não uma certificação de resposta acústica.
- Chave de cache diferenciada para 48 kHz e compatibilidade com caches antigos a 44,1 kHz. Validação dos quadros de saída e textos de orientação atualizados.
- Gradle aceita assinatura persistente externa opcional; não há chave privada nos pacotes. A assinatura padrão de depuração continua temporária.

## Testes locais desta revisão
- NativeStem48kTest: 122.007 verificações (sinais sintéticos; posição, interpolação, WSOLA, silenciamento e cache).
- NativeStemDeckTest: 106.016 verificações; demais testes de pipeline neural, contrato tensorial, qualidade numérica, preparação, armazenamento, samplers, segurança e XML/JS/WAV aprovados. Logs em docs/testes-11.5.0.
- Não foi repetida a inferência neural real nesta revisão. Modelo e rede não alterados. Não foi testado em celular. Outras taxas de amostragem usam exportação e mixer clássico; inferência simultânea à reprodução e vinheta paulistana continuam pendentes.
- Compilação oficial e certificado final serão registrados no relatório de entrega.
