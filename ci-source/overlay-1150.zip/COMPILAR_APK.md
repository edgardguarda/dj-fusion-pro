# Compilar EG MIX 11.5.0 com HTDemucs integrado

**Estado da entrega:** código-fonte + modelo treinado real. A compilação remota desta revisão está registrada em https://github.com/edgardguarda/dj-fusion-pro/actions/runs/45712238393. Homologação física ainda necessária. As instruções abaixo permitem recompilar a partir das fontes.

## Opção 1 — Android Studio (Windows, macOS ou Linux)

1. Extraia o pacote COMPLETO em uma pasta. O arquivo `app/src/main/assets/models/htdemucs_fp16weights.onnx` já está incluído e verificado.
2. Instale o Android Studio (https://developer.android.com/studio). Abra a pasta `EG_MIX_11_4_9` como projeto existente.
3. Configure JDK 17, SDK Platform 35, Build Tools 35.0.0 e Gradle 8.9 (Android Gradle Plugin 8.7.3). O ZIP não inclui o SDK, o Gradle nem o Gradle Wrapper. Deixe o Android Studio sincronizar e baixar as dependências, incluindo ONNX Runtime Android 1.22.0. Use uma instalação do Gradle 8.9 caso o IDE solicite a distribuição.
4. Use Build > Generate App Bundles or APKs > Generate APKs, ou execute no terminal da raiz do projeto: `gradle --no-daemon assembleDebug`.
5. Resultado esperado: `app/build/outputs/apk/debug/app-debug.apk`. Confira com `apksigner verify --verbose --print-certs app-debug.apk` (utilize o caminho do SDK e do APK) e `python tools/verify-bundled-apk.py app/build/outputs/apk/debug/app-debug.apk` (Python 3.11+).

## Opção 2 — GitHub Actions (sem instalar SDK no computador)

1. Crie um repositório **privado e vazio** no GitHub. Extraia o pacote GITHUB, menor, que contém o código e as automações, mas não o binário ONNX (acima de 100 MB). A automação obtém o arquivo exato antes de compilar. Não tente enviar o modelo de 166 MB pelo Git comum.
2. Com Git instalado, na raiz da pasta extraída, execute os comandos abaixo, substituindo a URL pela do seu repositório vazio. Confirme que `.github/workflows/build-android.yml` está presente.

```sh
git init -b main
git add .
git commit -m "EG MIX 11.5.0 com modelo neural integrado"
git remote add origin https://github.com/SEU_USUARIO/SEU_REPOSITORIO.git
git push -u origin main
```

3. Acesse Actions > **Build EG MIX Android com modelo neural (beta)**. O push para main dispara a compilação; também há Run workflow para execução manual.
4. Após conclusão com sucesso, abra o resumo da execução e baixe o artifact **EG-MIX-11.5.0-neural-debug-apk**. Contém `app-debug.apk` e `SHA256SUMS.txt`.
5. A automação executa testes locais, verifica o SHA-256 do modelo, compila, verifica a assinatura do APK e confere o conteúdo (modelo não comprimido, DEX, bibliotecas ARM64 e CRCs). O workflow de compilação desta revisão utilizou um subconjunto das suítes automatizadas antes da compilação.

## Uso do modelo no Android

Na tela de separação neural escolha a música. Para o Estúdio PCM (44,1 kHz) não é preciso escolher pasta; marque a exportação WAV se desejar salvar os cinco WAVs externamente. Para outras taxas, marque a exportação e use o mixer clássico. O APK contém o modelo ONNX; no primeiro processamento o aplicativo copia o modelo para armazenamento privado, verifica o SHA-256 e abre a rede neural. Não precisa baixar nem importar o modelo manualmente. A opção de importação alternativa permanece, mas só aceita o mesmo modelo exato. Reserve pelo menos 166 MB adicionais para a cópia privada, além do espaço de processamento/saída de stems e memória disponível. A rede roda localmente e sem permissão INTERNET. Pare a reprodução antes de separar.

## Assinatura e atualização

O APK debug recebe a chave debug do computador/runner de compilação. Ela pode ser diferente da assinatura da sua instalação anterior. Se o Android rejeitar uma atualização por assinatura incompatível, não desinstale a versão anterior sem exportar e preservar seus dados. Uma versão de distribuição requer a chave de assinatura original ou uma chave release própria, guardada em segurança. Não há chave privada no pacote.

## Validação física indispensável

Teste instalação, primeira cópia do ONNX, separação de uma música, quatro stems, mixagem independente, cancelamento, baixa memória, gravação, exportação, foco de áudio e samplers. A análise sintática e as suítes JVM não comprovam compilação Android ou latência em celular. Inferência simultânea à reprodução permanece fora do escopo.


## Assinatura persistente opcional
A partir desta versão, Gradle aceita as variáveis de ambiente `EGMIX_KEYSTORE` (caminho absoluto de um keystore), `EGMIX_STORE_PASSWORD`, `EGMIX_KEY_ALIAS` e `EGMIX_KEY_PASSWORD`. Todas devem ser definidas juntas. Não inclua chaves nem senhas no ZIP ou GitHub público. Use sempre o mesmo certificado para futuras atualizações. Sem elas, o build usa a assinatura debug temporária do ambiente. A chave anterior não está disponível e não pode ser recuperada do APK. Preserve os arquivos e dados importantes antes de qualquer desinstalação.
