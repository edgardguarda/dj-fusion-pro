# EG MIX 11.5.0 — Neural Multirate (beta)

HTDemucs integrado, quatro stems por deck, cache privado e suporte nativo a 44,1 e 48 kHz. Consulte RELATORIO_11_5_0.md e COMPILAR_APK.md. Relatórios anteriores são históricos. A assinatura de depuração pode variar entre builds.
