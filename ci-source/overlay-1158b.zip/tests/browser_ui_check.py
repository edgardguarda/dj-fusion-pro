"""Browser integration with mocked Android bridge. Does not execute Android audio."""
import json
from playwright.sync_api import sync_playwright
from pathlib import Path
import os
assets=Path(__file__).resolve().parents[1]/'app/src/main/assets'
errors=[]
with sync_playwright() as p:
    browser=p.chromium.launch(executable_path=os.environ.get('CHROMIUM') or ('/usr/bin/chromium' if Path('/usr/bin/chromium').exists() else None),headless=True,args=['--no-sandbox','--disable-dev-shm-usage','--disable-background-networking'])
    page=browser.new_page(viewport={'width':412,'height':915},is_mobile=True,has_touch=True,device_scale_factor=1)
    page.set_default_timeout(5000)
    page.on('pageerror',lambda e:errors.append(str(e)))
    page.set_content((assets/'aura-fast.html').read_text(),wait_until='domcontentloaded',timeout=30000)
    page.evaluate('''window.calls=[];window.state={status:'Reprodução estável',busy:false,selected:3,decoded:0,playing:true,quick:true,index:0,time:37,durationMs:160000,quickSeekToken:5,pcmDuration:180,pcmPosition:42,pcmTitle:'Track A.mp3',pcmSeekToken:77,pcmCanSeek:true,next:'Track B',mode:'playing',names:['Track A.mp3','Faixa B - nome longo para teste de leitura.wav','Track C.mp3'],tracks:[],nextReady:true,currentBpm:128,nextBpm:129,beatmatched:false,masterPeakDbfs:-3.5,recordRequested:false,hasMaster:false};
    window.AURA_ANDROID={snapshot(){return JSON.stringify(window.state)}};
    for(const name of ['pick','clear','start','studio','stop','pause','resume','next','diagnostic','record','testAudio','saveMaster','seek','seekPcm','pickJingle','resetJingle','sampler','pcmFx','autoCapture','exportIncident','stemGain','stemPreset','pcmRhythm','neuralStems','cancelNeural','quick'])window.AURA_ANDROID[name]=(...args)=>window.calls.push([name,...args]);window.confirm=()=>true;''')
    # Android 11 stock WebView 83 lacks Element.replaceChildren.
    page.evaluate('Element.prototype.replaceChildren=undefined')
    page.add_script_tag(content=(assets/'native-ui.js').read_text())
    def wait():page.wait_for_timeout(620)
    def state(**kwargs):page.evaluate('(s)=>Object.assign(window.state,s)',kwargs);wait()
    def click(id):page.locator('#'+id).click()
    def checkcall(name):assert any(x[0]==name for x in page.evaluate('window.calls')),name
    wait();assert page.locator('#aura10-native-tracklist .entry').count()==3
    assert page.locator('#play').is_disabled() and page.locator('#pause').is_enabled()
    click('pause');checkcall('pause');state(mode='paused');assert page.locator('#play').inner_text().strip()=='Retomar';click('play');checkcall('resume');assert not any(x[0]=='start' for x in page.evaluate('window.calls'))
    state(mode='mixing');assert page.locator('#seek').is_disabled() and page.locator('#next').is_disabled()
    state(mode='playing');assert page.locator('#seek').is_enabled()
    page.locator('#seek').evaluate("e=>{e.value=75;e.dispatchEvent(new Event('input',{bubbles:true}));e.dispatchEvent(new Event('change',{bubbles:true}));}")
    assert ['seek',75,5] in page.evaluate('window.calls')
    click('quickLibrary');assert page.locator('#libraryPanel').is_visible();page.locator('#eg-library-search').fill('Faixa B');assert page.locator('#aura10-native-tracklist .entry').count()==1
    page.locator('#eg-library-search').fill('impossível');assert 'Nenhuma música' in page.locator('#aura10-native-tracklist').inner_text();page.locator('#eg-library-search').fill('')
    click('tab-preview');assert page.locator('#previewPanel').is_visible() and not page.locator('#libraryPanel').is_visible();assert 'modo clássico' in page.locator('#previewPanel').inner_text()
    click('tab-diagnostics');assert page.locator('#diagnosticsPanel').is_visible();page.get_by_role('button',name='Diagnóstico Android',exact=True).click();checkcall('diagnostic')
    click('tab-library');click('quickConsole');click('aura10-tools');assert page.locator('#aura10-record').is_disabled()
    state(quick=False,pcmTitle='Track A.mp3',mode='paused',busy=True);assert page.locator('#play').is_enabled();click('play');checkcall('resume');state(busy=False,mode='playing');assert page.locator('#eg-meter').is_visible();assert page.locator('#eg-peak').inner_text()=='-3.5 dBFS';assert page.locator('#aura10-record').is_enabled()
    page.locator('#seek').evaluate("e=>{e.value=80;e.dispatchEvent(new Event('input',{bubbles:true}));e.dispatchEvent(new Event('change',{bubbles:true}));}")
    assert ['seekPcm',80,77] in page.evaluate('window.calls')
    state(rhythmReady=True);pad=page.locator('[data-djfx=roll]');assert pad.is_enabled();pad.click();assert any(c[0]=='pcmRhythm' and c[1]=='roll' for c in page.evaluate('window.calls'));pad.click();state(rhythmReady=False);assert pad.is_disabled()
    state(pcmStems=[{'token':901,'title':'Track A','gains':[100,100,100,100]},{'token':902,'title':'Track B','gains':[100,100,100,100]}])
    stem_a=page.get_by_role('slider',name='ON · atual Vocais',include_hidden=True);stem_b=page.get_by_role('slider',name='NEXT · próxima Vocais',include_hidden=True);assert stem_a.is_enabled() and stem_b.is_enabled()
    stem_a.evaluate("e=>{e.value=25;e.dispatchEvent(new Event('input',{bubbles:true}))}");assert ['stemGain',901,3,25] in page.evaluate('window.calls')
    page.get_by_role('button',name='Instrumental',exact=True).last.click();assert ['stemPreset',902,7] in page.evaluate('window.calls')
    stem_a.evaluate("e=>e.dispatchEvent(new PointerEvent('pointerdown',{bubbles:true}))")
    state(pcmStems=[{'token':902,'title':'Track B','gains':[100,100,100,0]},None]);before=len(page.evaluate('window.calls'))
    stem_a.evaluate("e=>{e.value=10;e.dispatchEvent(new Event('input',{bubbles:true}));e.dispatchEvent(new PointerEvent('pointerup',{bubbles:true}))}");assert len(page.evaluate('window.calls'))==before
    assert stem_b.is_disabled()
    state(pcmStems=[None,None]);assert stem_a.is_disabled()
    click('aura10-record');checkcall('record');state(recordRequested=True);assert 'encerrar' in page.locator('#aura10-record').inner_text()
    page.locator('[data-sampler=vinheta]').click();checkcall('sampler');page.get_by_role('button',name='Importar vinheta WAV',exact=True).click();checkcall('pickJingle')
    page.get_by_role('button',name='Restaurar vinheta original',exact=True).click();checkcall('resetJingle')
    click('aura10-tools');state(quick=True,playing=True,mode='playing',recordRequested=False)
    # Save mock previews (only when explicitly requested through env).
    if os.getenv('EG_PREVIEW'):
      page.locator('.wrap').evaluate('e=>e.scrollTop=0');page.screenshot(path=os.environ['EG_PREVIEW']+'/console-412.png')
    for width,height in [(320,640),(360,800),(412,915),(800,390),(1024,768)]:
      page.set_viewport_size({'width':width,'height':height});wait()
      assert page.locator('.wrap').evaluate('e=>e.scrollWidth<=e.clientWidth+2'),(width,height,'horizontal overflow')
      assert page.locator('#play').bounding_box()['height']>=44,(width,height,'play target')
      assert page.locator('[data-sampler=vinheta]').bounding_box()['height']>=44,(width,height,'sampler target')
      if os.getenv('EG_PREVIEW') and width==320:
        page.locator('.wrap').evaluate('e=>e.scrollTop=0');page.screenshot(path=os.environ['EG_PREVIEW']+'/console-320.png')
    state(quick=False,neuralBusy=True,neuralProgress=43,neuralMessage='Separando');assert page.locator('#eg-neural-progress').is_visible();assert page.locator('#eg-neural-percent').inner_text()=='43%';click('eg-neural-action');checkcall('cancelNeural');state(neuralBusy=False,playing=False,quick=False,busy=False,mode='idle');assert page.locator('#play').is_enabled();assert 'Nenhuma faixa' in page.locator('#currentName').inner_text();assert page.locator('#seek').is_disabled();click('play');checkcall('start')
    state(busy=True,playing=False,autoPlayPending=False);assert page.locator('#play').is_enabled() and page.locator('#stop').is_enabled();state(autoPlayPending=True);assert page.locator('#play').is_disabled();state(busy=False,autoPlayPending=False,analysisComplete=True,tracks=[{'name':'Track C.mp3','bpm':130,'confidence':.8,'camelot':'8A','seconds':120},{'name':'Track A.mp3','bpm':129,'confidence':.8,'camelot':'9A','seconds':180}]);assert '8A' in page.locator('#aura10-native-tracklist .entry').first.inner_text();assert 'Track C' in page.locator('#aura10-native-tracklist .entry').first.inner_text()
    state(busy=False,selected=0,names=[],tracks=[],analysisComplete=False);assert page.locator('#aura-empty-add').is_visible();page.locator('#aura-empty-add').click();checkcall('pick')
    assert not errors,errors
    print(json.dumps({'result':'PASS','viewport_sizes':5,'calls':page.evaluate('window.calls'),'script_errors':errors},ensure_ascii=False))
    browser.close()
