#!/usr/bin/env bash
set -euo pipefail
mkdir -p neural-evidence
adb install -r live-apk/app-debug.apk
adb logcat -c
adb shell am start -W -n br.com.edgard.aura.completo11/br.com.edgard.aura.DebugNeuralLiveActivity
# Wait for real preparation screen, then tap actual separation button.
found=0
for i in $(seq 1 30); do
  sleep 2
  adb shell uiautomator dump /sdcard/neural-ui.xml >/dev/null 2>&1 || continue
  adb exec-out cat /sdcard/neural-ui.xml > neural-evidence/ui.xml
  if pos=$(python3 - <<'P'
import re,xml.etree.ElementTree as ET
for n in ET.parse('neural-evidence/ui.xml').iter('node'):
 if 'SEPARAR 4 STEMS' in n.get('text','').upper() and n.get('enabled')=='true':
  x,y,a,b=map(int,re.findall(r'\d+',n.get('bounds')));print((x+a)//2,(y+b)//2);break
else: raise SystemExit(1)
P
  ); then adb shell input tap $pos;found=1;break;fi
done
if [ "$found" != 1 ]; then adb logcat -d > neural-evidence/logcat.txt;echo 'Neural start button unavailable';exit 1;fi
# 6 minutes max. Stop early on real published stems or a reported failure.
for i in $(seq 1 90); do
 sleep 4
 adb logcat -d -s EGMIX_NEURAL:I > neural-evidence/neural-log.txt
 if grep -Eq 'IA 100% Concluído|IA 0% (Falha:|Memória insuficiente|Separação cancelada)' neural-evidence/neural-log.txt;then break;fi
done
adb logcat -d -v time > neural-evidence/logcat.txt
adb exec-out run-as br.com.edgard.aura.completo11 ls -R files/native-stems-v1 > neural-evidence/stems.txt || true
cat neural-evidence/neural-log.txt
# A model result, advancing actual PCM time, and four persisted files are all required.
grep -q LIVE_PREDICT_AUDIO_ADVANCED neural-evidence/neural-log.txt
grep -q 'IA 100% Concluído' neural-evidence/neural-log.txt
for stem in vocals drums bass other;do grep -q "$stem.wav" neural-evidence/stems.txt;done
! grep -q 'FATAL EXCEPTION' neural-evidence/logcat.txt
echo 'PASS real HTDemucs inference and PCM progression concurrently on Android x86_64'
