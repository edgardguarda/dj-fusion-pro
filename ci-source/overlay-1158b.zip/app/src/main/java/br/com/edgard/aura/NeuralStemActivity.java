package br.com.edgard.aura;

import android.app.Activity;
import android.app.ActivityManager;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.provider.DocumentsContract;
import android.view.WindowManager;
import android.widget.*;
import br.com.edgard.aura.core.NeuralStemPipeline;
import br.com.edgard.aura.core.StemPreparationPolicy;
import br.com.edgard.aura.core.TrackData;
import java.io.*;
import java.security.MessageDigest;
import java.util.UUID;
import java.util.concurrent.atomic.AtomicBoolean;
import android.database.Cursor;
import android.provider.OpenableColumns;

/** Private, offline preparation screen. No network permission or audio upload. */
public final class NeuralStemActivity extends Activity {
    private static final int MODEL=901, SONG=902, DEST=903;
    private static final AtomicBoolean BUSY=new AtomicBoolean();
    public static boolean isBusy(){return BUSY.get();}
    private volatile Thread worker;
    private static volatile Thread activeWorker;
    private static volatile int jobPct;
    private static final String TAG="EGMIX_NEURAL";
    private static volatile String jobText="Nenhuma separação em andamento";
    private static final java.util.concurrent.atomic.AtomicLong REVISION=new java.util.concurrent.atomic.AtomicLong();
    public static long revision(){return REVISION.get();}
    public static int jobProgress(){return jobPct;}
    public static String jobMessage(){return jobText;}
    public static void cancelJob(){Thread w=activeWorker;if(w!=null){jobText="Cancelando após o bloco atual…";w.interrupt();}}
    private boolean detached;

    private Uri song,destination,modelUri;
    private TextView status,selection;
    private Button start,chooseModel,chooseSong,chooseFolder,download,cancel,storage,batch;
    private java.util.ArrayList<String> library=new java.util.ArrayList<>();
    private volatile String batchLabel="";
    private ProgressBar progress;
    private CheckBox exportWavs;
    private boolean backPending;
    private File modelFile;
    private boolean bundledModel;
    private static final Object MODEL_LOCK=new Object();
    private static volatile String modelStatus="Modelo integrado";
    public static String modelState(){return modelStatus;}
    public static void prepareBundledModelAsync(android.content.Context context){
        if("Verificando modelo".equals(modelStatus)||"Modelo verificado".equals(modelStatus))return;
        modelStatus="Verificando modelo";
        new Thread(()->{android.os.Process.setThreadPriority(android.os.Process.THREAD_PRIORITY_BACKGROUND);synchronized(MODEL_LOCK){File target=new File(context.getFilesDir(),"htdemucs-fp16weights.onnx"),part=new File(context.getFilesDir(),"htdemucs-autoload.tmp");try{
            try{verifyModel(target);modelStatus="Modelo verificado";return;}catch(Exception ignored){}
            if(context.getFilesDir().getUsableSpace()<230000000L)throw new IOException("Espaço insuficiente");
            try(InputStream in=context.getAssets().open(MODEL_ASSET);OutputStream out=new BufferedOutputStream(new FileOutputStream(part))){byte[] buf=new byte[65536];int n;while((n=in.read(buf))!=-1)out.write(buf,0,n);}
            verifyModel(part);android.system.Os.rename(part.getAbsolutePath(),target.getAbsolutePath());modelStatus="Modelo verificado";
        }catch(Exception e){modelStatus="Modelo integrado; preparação sob demanda";}finally{part.delete();}}},"EGMIX-model-verify").start();
    }
    private static final String MODEL_ASSET="models/htdemucs_fp16weights.onnx";
    @Override public void onCreate(Bundle b){
        super.onCreate(b);
        // Keep the screen awake only while a neural job is active.
        modelFile=new File(getFilesDir(),"htdemucs-fp16weights.onnx");
        try(android.content.res.AssetFileDescriptor descriptor=getAssets().openFd(MODEL_ASSET)){bundledModel=descriptor.getLength()==165612636L;}catch(IOException ignored){bundledModel=false;}
        ScrollView scroll=new ScrollView(this);LinearLayout layout=new LinearLayout(this);layout.setOrientation(LinearLayout.VERTICAL);
        int pad=(int)(20*getResources().getDisplayMetrics().density);layout.setPadding(pad,pad,pad,pad);scroll.addView(layout);
        TextView title=new TextView(this);title.setText("EG MIX • Separação neural");title.setTextSize(24);layout.addView(title);
        TextView info=new TextView(this);info.setText("HTDemucs: vocais, bateria, baixo e outros instrumentos. Processamento local, sem enviar músicas. Pode preparar durante a reprodução, com prioridade ao áudio. Se houver pressão de memória, aquecimento ou falhas de saída, a separação será interrompida. O modelo de 166 MB está integrado. A preparação pode levar vários minutos. Para o Estúdio PCM, você não precisa exportar WAVs.");layout.addView(info);
        download=button(layout,"Obter cópia do modelo oficial (opcional)",()->{try{startActivity(new Intent(Intent.ACTION_VIEW,Uri.parse(OnnxStemModel.DOWNLOAD)));}catch(Exception e){status.setText("Navegador indisponível");}});
        chooseModel=button(layout,"Selecionar modelo ONNX (opcional)",()->pick(MODEL,"*/*"));
        chooseSong=button(layout,"1. Escolher música",()->pick(SONG,"audio/*"));
        exportWavs=new CheckBox(this);exportWavs.setText("Exportar também 5 WAVs para uma pasta");layout.addView(exportWavs);
        chooseFolder=button(layout,"2. Escolher pasta de destino (exportação)",()->{try{startActivityForResult(new Intent(Intent.ACTION_OPEN_DOCUMENT_TREE).addFlags(Intent.FLAG_GRANT_WRITE_URI_PERMISSION|Intent.FLAG_GRANT_READ_URI_PERMISSION),DEST);}catch(Exception e){status.setText("Seletor de pasta indisponível");}});
        storage=button(layout,"Gerenciar stems armazenados",this::manageStorage);
        selection=new TextView(this);layout.addView(selection);
        start=button(layout,"Separar 4 stems",this::begin);
        java.util.ArrayList<String> incoming=getIntent().getStringArrayListExtra("library");if(incoming!=null)library.addAll(incoming);
        batch=button(layout,"Preparar toda a biblioteca com IA ("+library.size()+")",this::beginBatch);
        cancel=button(layout,"Cancelar processamento",()->{Thread w=worker;if(w!=null){w.interrupt();status.setText("Cancelando após o bloco atual…");}});
        progress=new ProgressBar(this,null,android.R.attr.progressBarStyleHorizontal);progress.setMax(100);layout.addView(progress);
        status=new TextView(this);status.setText("Escolha a música. Por padrão, os stems ficam no Estúdio PCM (44,1 ou 48 kHz). Para outras taxas, marque a exportação WAV.");layout.addView(status);
        exportWavs.setOnCheckedChangeListener((v,checked)->refresh());
        if(b!=null){song=b.getParcelable("song");destination=b.getParcelable("destination");modelUri=b.getParcelable("model");exportWavs.setChecked(b.getBoolean("export",false));}
        if(song==null)song=getIntent().getData();
        setContentView(scroll);refresh();
    }
    private Button button(LinearLayout l,String text,Runnable action){Button b=new Button(this);b.setText(text);b.setMinHeight((int)(48*getResources().getDisplayMetrics().density));b.setOnClickListener(v->action.run());l.addView(b);return b;}
    private void pick(int request,String mime){try{Intent i=new Intent(Intent.ACTION_OPEN_DOCUMENT).addCategory(Intent.CATEGORY_OPENABLE).setType(mime).addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);startActivityForResult(i,request);}catch(Exception e){status.setText("Seletor indisponível");}}
    @Override protected void onActivityResult(int req,int res,Intent data){super.onActivityResult(req,res,data);if(res!=RESULT_OK||data==null||data.getData()==null)return;
        if(req==MODEL)modelUri=data.getData();else if(req==SONG)song=data.getData();else if(req==DEST)destination=data.getData();refresh();}
    private void refresh(){boolean idle=worker==null&&!BUSY.get();for(Button b:new Button[]{chooseModel,chooseSong,download,storage})b.setEnabled(idle);
        exportWavs.setEnabled(idle);chooseFolder.setEnabled(idle&&exportWavs.isChecked());
        batch.setEnabled(idle&&!library.isEmpty()&&!exportWavs.isChecked()&&(bundledModel||modelFile.isFile()||modelUri!=null));
        start.setEnabled(StemPreparationPolicy.ready(modelUri!=null||modelFile.isFile()||bundledModel,song!=null,exportWavs.isChecked(),destination!=null,idle));cancel.setEnabled(worker!=null);
        if(worker!=null)getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);else getWindow().clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
        selection.setText("Modelo: "+(modelUri!=null?"selecionado, será verificado":modelFile.isFile()?"salvo, será verificado":bundledModel?"integrado no APK":"pendente")+"\nMúsica: "+(song==null?"pendente":displayName(song))+"\nDestino: "+(!exportWavs.isChecked()?"Estúdio PCM (privado)":destination==null?"escolha uma pasta":"Estúdio PCM + WAVs quando compatível")+"\nEspaço livre: "+formatBytes(getFilesDir().getUsableSpace()));}
    private void report(String s,int pct){jobText=batchLabel+s;jobPct=pct;android.util.Log.i(TAG,"IA "+pct+"% "+s);runOnUiThread(()->{if(!isDestroyed()){status.setText(batchLabel+s);progress.setProgress(pct);}});}
    private void begin(){if(song!=null)beginJobs(java.util.Collections.singletonList(song),exportWavs.isChecked()?destination:null);}
    private void beginBatch(){if(library.isEmpty())return;new android.app.AlertDialog.Builder(this).setTitle("Preparar biblioteca com IA").setMessage("Separar automaticamente todas as faixas da biblioteca, uma por vez, e reutilizar os stems válidos existentes. Pode levar bastante tempo e usar espaço de armazenamento. A música não será enviada a servidores.").setNegativeButton("Cancelar",null).setPositiveButton("Preparar",(d,w)->{java.util.ArrayList<Uri> jobs=new java.util.ArrayList<>();for(String u:library)jobs.add(Uri.parse(u));beginJobs(jobs,null);}).show();}
    private void beginJobs(java.util.List<Uri> jobs,Uri dest){if(worker!=null||jobs.isEmpty())return;if(QuickMixService.isPlaying()){status.setText("Pare a sessão legada antes de preparar IA.");return;}if(!BUSY.compareAndSet(false,true)){status.setText("Outra separação está terminando.");return;}final Uri newModel=modelUri;jobPct=0;jobText="Iniciando preparação";worker=new Thread(()->{android.os.Process.setThreadPriority(android.os.Process.THREAD_PRIORITY_BACKGROUND);int ok=0,failed=0;try{for(int i=0;i<jobs.size();i++){if(Thread.currentThread().isInterrupted())break;batchLabel=jobs.size()>1?"Faixa "+(i+1)+"/"+jobs.size()+" • ":"";if(process(jobs.get(i),dest,i==0?newModel:null))ok++;else failed++;}if(jobs.size()>1){batchLabel="";report("Biblioteca: "+ok+" preparadas, "+failed+" falhas, "+(jobs.size()-ok-failed)+" pendentes.",ok==jobs.size()?100:0);}}finally{activeWorker=null;BUSY.set(false);runOnUiThread(()->{worker=null;if(!isDestroyed()){refresh();if(backPending)finish();}});}},"EG-MIX-neural-stems");worker.setPriority(Thread.MIN_PRIORITY);activeWorker=worker;refresh();worker.start();}
    private void manageStorage(){
        if(BUSY.get())return;
        java.util.List<br.com.edgard.aura.core.StemStorage.Group> groups=br.com.edgard.aura.core.StemStorage.list(getFilesDir());
        if(groups.isEmpty()){new android.app.AlertDialog.Builder(this).setTitle("Stems armazenados").setMessage("Nenhum grupo gerenciável no cache privado.").setPositiveButton("OK",null).show();return;}
        String[] rows=new String[groups.size()];long total=0;for(int i=0;i<rows.length;i++){br.com.edgard.aura.core.StemStorage.Group g=groups.get(i);total+=g.bytes;rows[i]=g.title+" • "+formatBytes(g.bytes)+(g.scheduled?" • exclusão agendada":"");}
        new android.app.AlertDialog.Builder(this).setTitle("Stems privados • "+formatBytes(total)).setItems(rows,(d,i)->{
            br.com.edgard.aura.core.StemStorage.Group g=groups.get(i);
            new android.app.AlertDialog.Builder(this).setTitle(g.title).setMessage(g.scheduled?"Cancelar exclusão agendada?":"Excluir somente os quatro stems privados na próxima inicialização completa do aplicativo? A música original e os WAVs exportados permanecem. A faixa voltará ao master original.")
                .setNegativeButton("Voltar",null).setPositiveButton(g.scheduled?"Cancelar exclusão":"Agendar exclusão",(a,b)->{try{br.com.edgard.aura.core.StemStorage.schedule(getFilesDir(),g.key,!g.scheduled);status.setText(g.scheduled?"Exclusão cancelada.":"Exclusão agendada. Reinicie completamente o aplicativo para liberar espaço.");}catch(IOException e){status.setText("Falha: "+e.getMessage());}manageStorage();}).show();
        }).setNegativeButton("Fechar",null).show();
    }
    private String formatBytes(long n){return android.text.format.Formatter.formatFileSize(this,n);}
    private static void verifyModel(File f)throws Exception{
        if(!f.isFile()||f.length()!=165612636L)throw new IOException("Modelo ausente ou tamanho incorreto");
        MessageDigest digest=MessageDigest.getInstance("SHA-256");try(InputStream in=new BufferedInputStream(new FileInputStream(f))){byte[] buf=new byte[65536];int n;while((n=in.read(buf))!=-1){NeuralStemPipeline.checkCancelled();digest.update(buf,0,n);}}
        StringBuilder hex=new StringBuilder();for(byte v:digest.digest())hex.append(String.format(java.util.Locale.ROOT,"%02x",v&255));
        if(!OnnxStemModel.SHA256.contentEquals(hex))throw new IOException("SHA-256 do modelo não corresponde à versão oficial selecionada");
    }
    private void importModel(Uri uri)throws Exception{synchronized(MODEL_LOCK){importModelLocked(uri);modelStatus="Modelo verificado";}}
    private void importModelLocked(Uri uri)throws Exception{
        if(uri==null){
            try{verifyModel(modelFile);return;}catch(IOException invalid){if(!bundledModel)throw invalid;}
            report("Preparando modelo integrado (166 MB)…",4);
        }
        if(getFilesDir().getUsableSpace()<165612636L+64L*1024*1024)throw new IOException("Espaço insuficiente para preparar o modelo neural");
        File part=new File(getFilesDir(),"htdemucs-import-"+UUID.randomUUID()+".tmp");
        try{try(InputStream in=uri==null?getAssets().open(MODEL_ASSET,android.content.res.AssetManager.ACCESS_STREAMING):getContentResolver().openInputStream(uri);OutputStream out=new BufferedOutputStream(new FileOutputStream(part))){if(in==null)throw new IOException("Modelo indisponível");byte[] buf=new byte[65536];long length=0;int n;while((n=in.read(buf))!=-1){NeuralStemPipeline.checkCancelled();if((length+=n)>165612636L)throw new IOException("Modelo grande demais");out.write(buf,0,n);}}
            verifyModel(part); // POSIX atomic replacement in the same private directory.
            android.system.Os.rename(part.getAbsolutePath(),modelFile.getAbsolutePath());
        }finally{part.delete();}
    }
    private void checkLiveResources(br.com.edgard.aura.core.LiveNeuralGuard guard)throws Exception{
        NeuralStemPipeline.checkCancelled();
        ActivityManager manager=(ActivityManager)getSystemService(ACTIVITY_SERVICE);
        ActivityManager.MemoryInfo mem=new ActivityManager.MemoryInfo();if(manager!=null)manager.getMemoryInfo(mem);
        android.os.PowerManager power=(android.os.PowerManager)getSystemService(POWER_SERVICE);
        int thermal=android.os.Build.VERSION.SDK_INT>=29&&power!=null?power.getCurrentThermalStatus():0;
        android.content.SharedPreferences p=getSharedPreferences("aura",MODE_PRIVATE);
        String reason=guard.check(AudioService.isPlaying(),manager!=null&&mem.lowMemory,manager==null?Long.MAX_VALUE:mem.availMem,thermal,p.getInt("pcm_android_output_underruns",0));
        if(reason!=null)throw new IOException(reason+". Reprodução preservada; tente novamente com áudio parado.");
    }
    private boolean process(Uri input,Uri dest,Uri newModel){
        br.com.edgard.aura.core.LiveNeuralGuard guard=new br.com.edgard.aura.core.LiveNeuralGuard();
        File work=new File(getCacheDir(),"neural-"+UUID.randomUUID());boolean made=false;
        Uri published=null;
        try{
            checkLiveResources(guard);clearInterruptedJobs();made=work.mkdir();
            if(!made)throw new IOException("Não foi possível criar pasta temporária");
            report("Decodificando música…",3);AudioDecoder.Result pcm=AudioDecoder.decode(this,input,new File(work,"source.pcm"),frames->{if(Thread.currentThread().isInterrupted())throw new IllegalStateException("Cancelado");},1200);
            boolean nativeSupported=StemPreparationPolicy.nativeSupported(pcm.sampleRate);
            if(!nativeSupported&&dest==null)throw new IOException("Esta faixa não é 44,1 ou 48 kHz. Marque a exportação WAV para usar em outro mixer compatível.");
            if(nativeSupported&&dest==null&&newModel==null){
                File existing=TrackData.locateStems(getFilesDir(),pcm.file,pcm.sampleRate,pcm.frames);
                if(existing!=null){br.com.edgard.aura.core.StemStorage.schedule(getFilesDir(),existing.getName(),false);runOnUiThread(()->{if(!isDestroyed())setResult(RESULT_OK);});TrackData.markStemsPublished(input.toString());REVISION.incrementAndGet();report("Esta faixa já está preparada. Stems reaproveitados no Estúdio PCM.",100);return true;}
            }
            report("Verificando modelo neural…",4);importModel(newModel);
            if(newModel!=null)runOnUiThread(()->{if(newModel.equals(modelUri)){modelUri=null;if(!isDestroyed())refresh();}});
            File raw=new File(work,"stems.float"), outputs=new File(work,"wav");
            NeuralStemPipeline.Staging staging;
            try(NeuralStemPipeline.PcmSource source=new NeuralStemPipeline.PcmSource(pcm.file,pcm.sampleRate,pcm.frames)){
                long total=source.outputFrames();if(total>1200L*44100)throw new IOException("Limite: 20 minutos por faixa");
                if(work.getUsableSpace()<StemPreparationPolicy.requiredBytes(total,dest!=null))throw new IOException("Espaço livre insuficiente para separar a faixa");
                ActivityManager manager=(ActivityManager)getSystemService(ACTIVITY_SERVICE);
                if(manager!=null){ActivityManager.MemoryInfo info=new ActivityManager.MemoryInfo();manager.getMemoryInfo(info);if(info.lowMemory)throw new IOException("Pouca memória disponível. Feche outros aplicativos e tente novamente.");}
                checkLiveResources(guard);report("Carregando rede neural…",4);
                staging=new NeuralStemPipeline.Staging(raw);
                try(NeuralStemPipeline.Staging close=staging;OnnxStemModel net=new OnnxStemModel(modelFile)){NeuralStemPipeline.run(total,NeuralStemPipeline.SEGMENT,NeuralStemPipeline.OVERLAP,source,inputBlock->{checkLiveResources(guard);long token=AudioService.seekToken();double before=AudioService.seekPosition();boolean playing=AudioService.isPlaying();
                    float[] output=net.predict(inputBlock);double after=AudioService.seekPosition();
                    if(playing&&AudioService.isPlaying()&&token==AudioService.seekToken()&&after>before+.10)android.util.Log.i(TAG,"LIVE_PREDICT_AUDIO_ADVANCED before="+before+" after="+after+" output="+output.length);
                    checkLiveResources(guard);return output;},staging,(done,all)->report("Separando quatro canais • "+(done*100/all)+"%",5+(int)(done*85/all)));}
            }
            checkLiveResources(guard);report("Preparando WAV estéreo 24 bits…",92);String base=outputBase(input);staging.export(outputs,base,dest!=null);
            raw.delete();
            if(dest!=null){
            NeuralStemPipeline.checkCancelled();String id=DocumentsContract.getTreeDocumentId(dest);Uri root=DocumentsContract.buildDocumentUriUsingTree(dest,id);
            published=DocumentsContract.createDocument(getContentResolver(),root,DocumentsContract.Document.MIME_TYPE_DIR,"EG MIX STEMS "+UUID.randomUUID().toString().substring(0,8));
            if(published==null)throw new IOException("Destino não permite criar pasta");
            File[] files=outputs.listFiles();if(files==null||files.length!=5)throw new IOException("Grupo incompleto");
            int saved=0;for(File f:files){report("Salvando arquivos • "+saved+"/5",94+saved);NeuralStemPipeline.checkCancelled();Uri u=DocumentsContract.createDocument(getContentResolver(),published,"audio/wav",f.getName());if(u==null)throw new IOException("Falha ao criar WAV");
                try(InputStream in=new BufferedInputStream(new FileInputStream(f));OutputStream out=getContentResolver().openOutputStream(u,"w")){if(out==null)throw new IOException("Falha ao salvar WAV");byte[] buf=new byte[65536];int n;while((n=in.read(buf))!=-1){NeuralStemPipeline.checkCancelled();out.write(buf,0,n);}}
                saved++;
            }
            NeuralStemPipeline.checkCancelled();published=null;
            }
            if(nativeSupported){try{
                br.com.edgard.aura.core.TrackData.publishStems(getFilesDir(),pcm.file,pcm.sampleRate,pcm.frames,outputs,base);
                TrackData.markStemsPublished(input.toString());REVISION.incrementAndGet();
                br.com.edgard.aura.core.StemStorage.schedule(getFilesDir(),TrackData.stemKey(pcm.file,pcm.sampleRate),false);
                runOnUiThread(()->{if(!isDestroyed())setResult(RESULT_OK);});
                report("Concluído: stems disponíveis no Estúdio PCM."+(dest!=null?" WAVs também exportados.":" Sem cópia externa.")+" Os stems serão usados quando o deck for preparado novamente; o deck atual não é interrompido.",100);return true;
            }catch(IOException cacheError){report((dest!=null?"WAVs exportados; cache nativo não salvo: ":"Falha ao salvar stems privados: ")+cacheError.getMessage(),dest!=null?100:0);return dest!=null;}}
            else {report("WAVs exportados. Para esta taxa de amostragem, importe os WAVs em um aplicativo compatível.",100);return true;}
        }catch(OutOfMemoryError e){report("Memória insuficiente para o modelo neural. Nenhuma separação aprovada.",0);return false;}
        catch(Exception e){report(Thread.currentThread().isInterrupted()?"Separação cancelada.":"Falha: "+e.getMessage(),0);return false;}
        finally{if(published!=null)try{DocumentsContract.deleteDocument(getContentResolver(),published);}catch(Exception ignored){}if(made)clean(work);}
    }
    /** Only the worker holding BUSY may touch these app-private UUID work folders. */
    private void clearInterruptedJobs(){
        File[] entries=getCacheDir().listFiles();if(entries==null)return;
        for(File f:entries)if(f.isDirectory()&&f.getName().matches("neural-[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}"))clean(f);
    }
    private String displayName(Uri uri){
        String name="Musica";
        try(Cursor c=getContentResolver().query(uri,new String[]{OpenableColumns.DISPLAY_NAME},null,null,null)){
            if(c!=null&&c.moveToFirst()&&c.getString(0)!=null)name=c.getString(0);
        }catch(Exception ignored){}
        return name;
    }
    private String outputBase(Uri uri){
        String name=displayName(uri);
        name=name.replaceFirst("\\.[^.]+$","").replaceAll("[^\\p{L}\\p{N} _-]","_").trim();
        if(name.isEmpty())name="Musica";
        if(name.length()>64)name=name.substring(0,64);
        return "EGMIX_"+name+"_"+UUID.randomUUID().toString().substring(0,8);
    }
    private static void clean(File f){File[] files=f.listFiles();if(files!=null)for(File child:files)clean(child);f.delete();}
    @Override protected void onSaveInstanceState(Bundle b){super.onSaveInstanceState(b);b.putParcelable("song",song);b.putParcelable("destination",destination);b.putParcelable("model",modelUri);b.putBoolean("export",exportWavs.isChecked());}
    @Override public void onBackPressed(){
        if(worker==null){super.onBackPressed();return;}
        android.app.AlertDialog.Builder dialog=new android.app.AlertDialog.Builder(this).setTitle("Separação em andamento").setMessage("Você pode cancelar após o bloco atual. Com o motor PCM ativo, também pode voltar ao console e acompanhar o progresso.").setNegativeButton("Continuar aqui",null).setPositiveButton("Cancelar e voltar",(d,w)->{backPending=true;cancelJob();});
        if(AudioService.isPlaying())dialog.setNeutralButton("Voltar ao console",(d,w)->{detached=true;finish();});dialog.show();
    }
    @Override protected void onDestroy(){Thread w=worker;if(w!=null&&!detached)w.interrupt();super.onDestroy();}
}
