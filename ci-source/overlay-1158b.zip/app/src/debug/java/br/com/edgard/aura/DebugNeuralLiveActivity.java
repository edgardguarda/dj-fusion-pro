package br.com.edgard.aura;
import android.app.Activity;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.content.Intent;
import android.net.Uri;
import br.com.edgard.aura.core.TrackData;
import java.io.*;
import java.util.*;
/** Shell-only test. Starts real PCM playback, then opens the real neural preparation screen. */
public final class DebugNeuralLiveActivity extends Activity {
    @Override public void onCreate(Bundle state){super.onCreate(state);new Thread(()->{try{
        int hz=44100,seconds=300;File pcm=new File(getFilesDir(),"neural-live-master.pcm"),wav=new File(getFilesDir(),"neural-live-input.wav");
        byte[] buf=new byte[4096*4];
        try(OutputStream raw=new BufferedOutputStream(new FileOutputStream(pcm));WavWriter w=new WavWriter(wav,hz)){
            for(int start=0;start<hz*seconds;start+=4096){int n=Math.min(4096,hz*seconds-start);
                for(int i=0;i<n;i++){double t=(start+i)/(double)hz;double env=Math.exp(-18*(t%.5));double kick=.09*env*Math.sin(2*Math.PI*(65*t+4*Math.sin(2*Math.PI*t)));double bass=.12*Math.sin(2*Math.PI*110*t)*(.5+.5*Math.cos(2*Math.PI*t));double melody=.08*Math.sin(2*Math.PI*440*t+2*Math.sin(2*Math.PI*1.3*t));double chord=.06*Math.sin(2*Math.PI*329.63*t)+.045*Math.sin(2*Math.PI*523.25*t);short l=(short)(32767*(kick+bass+melody+chord));short r=(short)(32767*(kick+bass+.6*melody+chord));int o=i*4;buf[o]=(byte)l;buf[o+1]=(byte)(l>>8);buf[o+2]=(byte)r;buf[o+3]=(byte)(r>>8);}
                raw.write(buf,0,n*4);if(start<hz*7)w.write(buf,Math.min(n,hz*7-start)*4);
            }
        }
        TrackData t=new TrackData("Neural live fixture",pcm,hz,(long)hz*seconds,120,.9,0,.15);t.audibleEndSeconds=seconds;SessionStore.save(this,Collections.singletonList(t),0,0);
        runOnUiThread(()->{startForegroundService(new Intent(this,AudioService.class).setAction(AudioService.START));new Handler(Looper.getMainLooper()).postDelayed(()->{Intent i=new Intent(this,NeuralStemActivity.class);i.setData(Uri.fromFile(wav));startActivity(i);finish();},3000);});
    }catch(Exception e){android.util.Log.e("EGMIX_NEURAL","fixture failed",e);}},"EGMIX-neural-live-fixture").start();}
}
