package br.com.edgard.aura.core;

import java.io.IOException;
import java.io.RandomAccessFile;

/**
 * SPSC PCM16 -> stereo-float prefetcher. All file operations happen on the
 * dedicated producer. The audio thread only reads a published ring and advances
 * a source cursor; it never waits for disk or allocates samples.
 *
 * Optional WSOLA worker preserves pitch in bounded beatmatch; without it the
 * historic linear-resampling path remains bit compatible.
 */
public final class BufferedPcmDeck implements AutoCloseable {
    public static final int RING_FRAMES = 1 << 16;
    public static final int STARTUP_FRAMES = 8192;
    /** Bounded WSOLA producer lead reduces phase-control latency (<~340ms at 48 kHz). */
    public static final int WSOLA_AHEAD_FRAMES = 16384;
    private static final int READ_FRAMES = 2048;
    private final float[] samples = new float[RING_FRAMES * 2];
    /** Source clock at each stretched output sample (WSOLA overlap weighted). */
    private final double[] sourcePositions;
    private final float[] stemRing;
    private final float[] gains=new float[4];
    private final float gainStep;
    /** Bounded integrated loudness trim with RMS fallback; no analysis on audio thread. */
    public final float autoLevel;
    public static float levelForRms(double rms){
        if(!Double.isFinite(rms)||rms<.02||rms>1)return 1f;
        return (float)Math.max(.501187,Math.min(1.412538,.16/rms));
    }
    public boolean hasNeuralStems(){return stemRing!=null;}
    /** Smooth handoff of vocal ownership; no change to stored manual stem gains. */
    public static float autoVocalGain(boolean incoming,double progress){
        double t=Math.max(0,Math.min(1,(progress-(incoming?.58:.12))/.30));
        float f=(float)(t*t*(3-2*t));return incoming?f:1-f;
    }
    private final class StemReader implements AutoCloseable {
        private final RandomAccessFile[] files=new RandomAccessFile[4];
        private final byte[] raw=new byte[(READ_FRAMES+2)*6];
        private final float[] first=new float[READ_FRAMES*2],second=new float[READ_FRAMES*2];
        private final long neuralFrames=stemRing==null?0:TrackData.stemFrames(data.frames,data.sampleRate);
        StemReader()throws IOException{
            if(stemRing==null)return;
            try{TrackData.validateStems(data.stemFolder(),neuralFrames);for(int k=0;k<4;k++)files[k]=new RandomAccessFile(new java.io.File(data.stemFolder(),TrackData.STEM_NAMES[k]+".wav"),"r");}
            catch(IOException e){close();throw e;}
        }
        private float pcm(byte[] b,int k){return ((b[k]&255)|((b[k+1]&255)<<8)|(b[k+2]<<16))/8388608f;}
        // Map all stems to the same source clock before the shared WSOLA hop.
        // 48 kHz is an upsampling path from 44.1 kHz, so no downsampling aliasing.
        private void read(RandomAccessFile f,long at,int n,float[] buf)throws IOException{
            java.util.Arrays.fill(buf,0,n*2,0f);
            int valid=(int)Math.max(0,Math.min(n,data.frames-at));if(valid==0)return;
            if(at<0)throw new IOException("Posição de stem inválida");
            if(data.sampleRate==44100){f.seek(44+at*6);f.readFully(raw,0,valid*6);for(int i=0;i<valid*2;i++)buf[i]=pcm(raw,i*3);return;}
            long first=Math.min(neuralFrames-1,at*44100/data.sampleRate);
            long last=Math.min(neuralFrames-1,(at+valid-1)*44100/data.sampleRate+1);
            f.seek(44+first*6);f.readFully(raw,0,(int)(last-first+1)*6);
            for(int i=0;i<valid;i++){
                long pos=(at+i)*44100,ix=Math.min(neuralFrames-1,pos/data.sampleRate);
                float frac=(pos%data.sampleRate)/(float)data.sampleRate;
                int x=(int)(ix-first)*6,y=(int)(Math.min(neuralFrames-1,ix+1)-first)*6;
                for(int ch=0;ch<2;ch++)buf[i*2+ch]=pcm(raw,x+ch*3)*(1-frac)+pcm(raw,y+ch*3)*frac;
            }
        }
        void fill(long write,long from,long old,int n,WsolaStereoStretch stretch)throws IOException{
            if(stemRing==null)return;
            for(int k=0;k<4;k++){read(files[k],from,n,first);if(old>=0)read(files[k],old,n,second);
                for(int i=0;i<n;i++){int dst=(int)((write+i)&(RING_FRAMES-1))*8+k*2;float t=old<0?1:stretch.hopWeight(i);
                    for(int ch=0;ch<2;ch++){int off=i*2+ch;stemRing[dst+ch]=first[off]*t+(old<0?0:second[off]*(1-t));}
                }
            }
        }
        public void close(){for(RandomAccessFile f:files)if(f!=null)try{f.close();}catch(IOException ignored){}}
    }
    private final Thread reader;
    public final TrackData data;
    public volatile IOException error;
    private volatile boolean stopped;
    private volatile long published;
    private volatile long needed;
    private volatile boolean producerFinished;
    private final boolean pitchPreserving;
    private final double sourceStep;
    private double stretchedCursor;
    private volatile double tempo;
    private volatile WsolaStereoStretch wsola;
    public volatile long starves;
    public double cursor;
    public final double step;
    private double lowL, lowR;
    /** Fixed low-pass coefficient calculated once per deck, not four exp() calls per PCM frame. */
    private final double lowPassPole;

    public BufferedPcmDeck(TrackData data, int outputRate, double rate, double startSeconds) {
        this(data,outputRate,rate,startSeconds,false);
    }
    public BufferedPcmDeck(TrackData data, int outputRate, double rate, double startSeconds, boolean preservePitch) {
        if(data==null || outputRate<=0 || data.sampleRate<=0 || data.frames<2 ||
                !Double.isFinite(rate) || rate<=0 || rate>4 ||
                !Double.isFinite(startSeconds) || startSeconds<0)
            throw new IllegalArgumentException("Invalid PCM deck parameters");
        if(preservePitch && (rate<.94 || rate>1.06))throw new IllegalArgumentException("Pitch stretch out of range");
        this.data=data;
        autoLevel=data.playbackLevel();
        stemRing=data.stemFolder()==null?null:new float[RING_FRAMES*8];
        int initial=data.stemGains();for(int i=0;i<4;i++)gains[i]=((initial>>>(i*8))&255)/100f;
        gainStep=1f/Math.max(1,outputRate*.025f);
        this.pitchPreserving=preservePitch;
        this.sourcePositions=preservePitch ? new double[RING_FRAMES] : null;
        this.tempo=rate;
        this.sourceStep=(double)data.sampleRate/outputRate;
        this.lowPassPole=Math.exp(-2*Math.PI*160/outputRate);
        this.step=(double)data.sampleRate/outputRate*rate;
        this.cursor=Math.min(data.frames-2, startSeconds*data.sampleRate);
        long start=(long)Math.floor(cursor);
        this.published=preservePitch?0:start;
        this.needed=preservePitch?0:start;
        reader=new Thread(()->readLoop(start),"AURA-PCM-prefetch");
        reader.setDaemon(true);
        reader.start();
    }

    private void readLoop(long start) {
        if(pitchPreserving){stretchLoop(start);return;}
        byte[] bytes=new byte[READ_FRAMES*4];
        long write=start;
        try(RandomAccessFile file=new RandomAccessFile(data.file,"r");StemReader stems=new StemReader()) {
            // Fail fast for a truncated decoder cache, even if its valid head
            // could otherwise fill the startup buffer and sound briefly OK.
            if(data.frames>Long.MAX_VALUE/4 || file.length()<data.frames*4L)
                throw new IOException("Cache PCM incompleto antes da reprodução");
            file.seek(start*4);
            while(!stopped && write<data.frames) {
                long room=needed + RING_FRAMES - 4 - write;
                if(room<=0){try{Thread.sleep(2);}catch(InterruptedException ignored){} continue;}
                int frames=(int)Math.min(Math.min(READ_FRAMES,room),data.frames-write);
                int size=frames*4,read=0;
                while(read<size && !stopped){
                    int n=file.read(bytes,read,size-read);
                    if(n<0)throw new IOException("PCM truncado em "+write+" quadros");
                    if(n==0)throw new IOException("Leitura PCM sem progresso");
                    read+=n;
                }
                if(stopped)break;
                for(int i=0;i<frames;i++){
                    int src=i*4,dst=(int)((write+i)&(RING_FRAMES-1))*2;
                    samples[dst]=(short)((bytes[src]&255)|(bytes[src+1]<<8))/32768f;
                    samples[dst+1]=(short)((bytes[src+2]&255)|(bytes[src+3]<<8))/32768f;
                }
                stems.fill(write,write,-1,frames,null);
                write+=frames;
                // Volatile store publishes the fully converted frame data.
                published=write;
            }
        }catch(IOException e){if(!stopped)error=e;}
        finally{producerFinished=true;}
    }

    private void stretchLoop(long start) {
        long write=0;
        float[] chunk=new float[WsolaStereoStretch.HOP*2];
        double[] timeline=new double[WsolaStereoStretch.HOP];
        try(RandomAccessFile input=new RandomAccessFile(data.file,"r");StemReader stems=new StemReader()){
            if(data.frames>Long.MAX_VALUE/4 || input.length()<data.frames*4L)
                throw new IOException("Cache PCM/WSOLA incompleto antes da reprodução");
            try(WsolaStereoStretch stretch=new WsolaStereoStretch(input,data.frames,start,tempo)){
            wsola=stretch;
            while(!stopped){
                long room=Math.min(needed+RING_FRAMES-4-write,needed+WSOLA_AHEAD_FRAMES-write);
                if(room<WsolaStereoStretch.HOP){
                    try{Thread.sleep(2);}catch(InterruptedException ignored){}continue;
                }
                stretch.setTempo(tempo);
                if(!stretch.render(chunk,timeline))break;
                for(int i=0;i<WsolaStereoStretch.HOP;i++){
                    int src=i*2,dst=(int)((write+i)&(RING_FRAMES-1))*2;
                    samples[dst]=chunk[src];samples[dst+1]=chunk[src+1];
                    sourcePositions[(int)((write+i)&(RING_FRAMES-1))]=timeline[i];
                }
                stems.fill(write,stretch.hopNew(),stretch.hopOld(),WsolaStereoStretch.HOP,stretch);
                write+=WsolaStereoStretch.HOP;
                published=write;
            }
            }
        }catch(IOException e){if(!stopped)error=e;}
        finally{producerFinished=true;wsola=null;}
    }
    public void setTempo(double target){
        if(!pitchPreserving)return;
        if(!Double.isFinite(target)||target<.94||target>1.06)
            throw new IllegalArgumentException("Tempo outside WSOLA limits");
        tempo=target;
    }
    public double getTempo(){return tempo;}
    public boolean isPitchPreserving(){return pitchPreserving;}
    public int availableFrames(){return (int)Math.max(0,Math.min(Integer.MAX_VALUE,
            published-(long)Math.floor(pitchPreserving?stretchedCursor:cursor)));}
    public boolean isPrimed(){
        // A truncated track may leave a few valid frames in the ring. Do not
        // label it safe to start: there is no viable complete incoming deck.
        return error==null && (availableFrames()>=STARTUP_FRAMES ||
            (producerFinished && availableFrames()>=2));
    }
    /** Only call before starting output, never on the audio rendering path. */
    public boolean awaitPrimed(long timeoutMs) throws InterruptedException {
        long deadline=System.nanoTime()+timeoutMs*1_000_000L;
        while(!stopped && error==null && !isPrimed() && System.nanoTime()<deadline) Thread.sleep(4);
        return isPrimed();
    }
    /** No I/O, no sleeps, no allocations, and no blocking locks. */
    public boolean next(float[] result) {return next(result,1f);}
    public boolean next(float[] result,float vocalFactor) {
        if(result==null || result.length<2)throw new IllegalArgumentException("Stereo output needed");
        long frame=(long)Math.floor(pitchPreserving?stretchedCursor:cursor);
        long limit=published;
        if(stopped || frame+1>=limit || (!pitchPreserving && frame+1>=data.frames)){
            result[0]=result[1]=0;
            // Natural EOF is not a disk starvation and must not pollute diagnostics.
            if(!stopped && !atEnd() && !producerFinished) starves++;
            return false;
        }
        double frac=(pitchPreserving?stretchedCursor:cursor)-frame;
        int ix=(int)(frame&(RING_FRAMES-1))*2;
        int iy=(int)((frame+1)&(RING_FRAMES-1))*2;
        result[0]=(float)(samples[ix]*(1-frac)+samples[iy]*frac);
        result[1]=(float)(samples[ix+1]*(1-frac)+samples[iy+1]*frac);
        if(stemRing!=null){
            int target=data.stemGains();float left=0,right=0;int sx=ix*4,sy=iy*4;
            for(int k=0;k<4;k++){float desired=((target>>>(k*8))&255)/100f;if(k==3)desired*=Math.max(0f,Math.min(1f,vocalFactor));float g=gains[k];g+=Math.max(-gainStep,Math.min(gainStep,desired-g));gains[k]=g;
                int ch=k*2;left+=g*(float)(stemRing[sx+ch]*(1-frac)+stemRing[sy+ch]*frac);right+=g*(float)(stemRing[sx+ch+1]*(1-frac)+stemRing[sy+ch+1]*frac);}
            result[0]=left;result[1]=right;
        }
        if(pitchPreserving){
            stretchedCursor+=sourceStep;
            // Playback timeline follows the *actual* WSOLA source alignment,
            // not an optimistic integration of the requested tempo.
            int px=(int)(frame&(RING_FRAMES-1));
            int py=(int)((frame+1)&(RING_FRAMES-1));
            cursor=sourcePositions[px]*(1-frac)+sourcePositions[py]*frac+sourceStep;
            needed=(long)Math.floor(stretchedCursor);
        }else{cursor+=step;needed=(long)Math.floor(cursor);}
        return true;
    }
    public float split(float sample,boolean left,int rate){
        // The deck output sample rate is immutable for its lifetime.
        double factor=lowPassPole;
        if(left){lowL=lowL*factor+(1-factor)*sample;return (float)lowL;}
        lowR=lowR*factor+(1-factor)*sample;return (float)lowR;
    }
    public boolean hasFailed(){return error!=null;}
    public boolean atEnd(){
        // For WSOLA, nominal source-time can reach EOF while there are still
        // output frames in its ring; never discard those audible tail frames.
        return pitchPreserving ? (producerFinished && stretchedCursor>=published-1)
                : cursor>=data.frames-2;
    }
    @Override public void close(){stopped=true;reader.interrupt();}
}
