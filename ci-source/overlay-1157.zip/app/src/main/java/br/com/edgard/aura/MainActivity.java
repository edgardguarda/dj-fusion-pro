package br.com.edgard.aura;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Intent;
import android.graphics.Color;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.provider.OpenableColumns;
import android.util.Log;
import android.view.View;
import android.view.WindowManager;
import android.webkit.ConsoleMessage;
import android.webkit.JavascriptInterface;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebResourceResponse;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import br.com.edgard.aura.core.PrivateAudioExport;
import br.com.edgard.aura.core.PcmSamplerBus;
import br.com.edgard.aura.core.CustomJingle;
import android.widget.Toast;

import br.com.edgard.aura.core.BeatAnalyzer;
import br.com.edgard.aura.core.TrackData;
import br.com.edgard.aura.core.TrackPlanner;
import br.com.edgard.aura.core.PhraseAnalyzer;
import java.io.File;
import java.io.FileInputStream;
import java.io.InputStream;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.concurrent.atomic.AtomicBoolean;
import org.json.JSONObject;
import org.json.JSONArray;
import java.util.concurrent.atomic.AtomicInteger;

/** The COMPLETE original AURA UI is an offline Android asset.
 * Audio in Native mode is rendered by MediaCodec + AudioTrack, not WebAudio.
 * Classic mode remains accessible for advanced legacy controls/visualizers.
 */
public final class MainActivity extends Activity {
    private static final String TAG="AURA11";
    private static final int PICK_AUDIO=701, SAVE_MASTER=702, SAVE_INCIDENT=703, PICK_JINGLE=704, NEURAL_STEMS=705;
    private static final String APP_URL="https://aura.android.local/index.html";
    private static final AtomicBoolean CRASH_HANDLER_INSTALLED=new AtomicBoolean(false);
    private final Handler main=new Handler(Looper.getMainLooper());
    private WebView web;
    private android.media.SoundPool quickSamplers;
    private boolean jingleBusy=false;
    private final java.util.Set<Integer> quickSamplerReady=java.util.concurrent.ConcurrentHashMap.newKeySet();
    private final java.util.Map<String,Integer> quickSamplerIds=new java.util.HashMap<>();
    private void ensureQuickSamplers(){
        if(quickSamplers!=null)return;
        try{
            android.media.AudioAttributes attr=new android.media.AudioAttributes.Builder()
                    .setUsage(android.media.AudioAttributes.USAGE_MEDIA)
                    .setContentType(android.media.AudioAttributes.CONTENT_TYPE_SONIFICATION).build();
            quickSamplers=new android.media.SoundPool.Builder().setMaxStreams(2).setAudioAttributes(attr).build();
            quickSamplers.setOnLoadCompleteListener((pool,id,status)->{if(pool==quickSamplers&&status==0)quickSamplerReady.add(id);});
            for(String key:PcmSamplerAssets.KEYS){
                int id;
                if("vinheta".equals(key)&&CustomJingle.available(getFilesDir())){
                    id=quickSamplers.load(CustomJingle.file(getFilesDir()).getAbsolutePath(),1);
                }else try(android.content.res.AssetFileDescriptor afd=getAssets().openFd("samplers/"+key+".wav")){
                    id=quickSamplers.load(afd,1);
                }
                quickSamplerIds.put(key,id);
            }
        }catch(Exception error){Log.w(TAG,"Quick sampler loading failed",error);}
    }
    private void reloadQuickSamplers(){
        if(quickSamplers!=null){quickSamplers.release();quickSamplers=null;}
        quickSamplerIds.clear();quickSamplerReady.clear();ensureQuickSamplers();
    }
    private boolean canChangeJingle(){
        if(jingleBusy||preparing||studioStarting||AudioService.isPlaying()||QuickMixService.isPlaying()){
            alert("Vinheta personalizada","Pare a reprodução e aguarde qualquer importação em andamento.");return false;
        }return true;
    }
    private void pickJingle(){
        if(!canChangeJingle())return;
        Intent picker=new Intent(Intent.ACTION_OPEN_DOCUMENT).addCategory(Intent.CATEGORY_OPENABLE).setType("audio/*");
        picker.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
        try{startActivityForResult(picker,PICK_JINGLE);}catch(Exception e){alert("Vinheta personalizada","Seletor indisponível.");}
    }
    private void changeJingle(Uri uri){
        if(!canChangeJingle())return;
        jingleBusy=true;
        final File dir=getFilesDir();
        new Thread(()->{
            String message;boolean ok=false;
            try{
                if(uri==null){CustomJingle.reset(dir);message="Vinheta original restaurada.";}
                else try(InputStream in=getContentResolver().openInputStream(uri)){
                    if(in==null)throw new java.io.IOException("Arquivo indisponível");
                    CustomJingle.save(dir,in);message="Vinheta WAV personalizada salva. Vale para a próxima sessão PCM e para o modo rápido.";
                }
                ok=true;
            }catch(Exception e){message="Não foi possível trocar a vinheta: "+e.getMessage();}
            final String result=message;final boolean success=ok;
            main.post(()->{jingleBusy=false;if(isFinishing()||isDestroyed())return;if(success)reloadQuickSamplers();status(result);alert("Vinheta personalizada",result);});
        },"EGMIX-jingle-import").start();
    }
    private void playSampler(String key,double volume){
        if(PcmSamplerBus.keyIndex(key)<0 || !Double.isFinite(volume))return;
        if(AudioService.isPlaying()&&AudioService.samplersReady()&&!"paused".equals(getSharedPreferences("aura",MODE_PRIVATE).getString("dj_mode",""))){
            Intent action=new Intent(this,AudioService.class).setAction(AudioService.SAMPLER);
            action.putExtra("key",key);action.putExtra("volume",Math.max(0,Math.min(1,volume)));
            startService(action);return;
        }
        ensureQuickSamplers();
        if(quickSamplers!=null){
            int sampleId=quickSamplerIds.containsKey(key)?quickSamplerIds.get(key):0;
            if(sampleId>0 && quickSamplerReady.contains(sampleId)){float v=(float)Math.max(0,Math.min(.32,volume*.32));
                int stream=quickSamplers.play(sampleId,v,v,1,0,1);status(stream>0?"Sampler "+key+" disparado (saída auxiliar)":"Sampler indisponível na saída auxiliar");return;}
        }
        status("Sampler "+key+" ainda carregando; tente novamente.");
    }
    private android.webkit.ValueCallback<Uri[]> webFileResult;
    private boolean nativeFileSelect=false;
    private final ArrayList<Uri> musicUris=new ArrayList<>();
    private volatile boolean preparing=false;
    private volatile boolean loaded=false;
    private volatile int decodedCount=0;
    private volatile int cacheReused=0,cacheInvalidated=0;
    private volatile String decodeFailures="";
    private volatile int selectedCount=0;
    private volatile int playIndex=0;
    private volatile Thread preparationThread;
    private final AtomicInteger prepVersion=new AtomicInteger(0);
    // Independent of PCM preparation: Play must never cancel persisted URI grants.
    private final AtomicInteger selectionVersion=new AtomicInteger(0);
    private volatile Thread selectionThread;
    private final ArrayList<String> selectedNames=new ArrayList<>();
    private final ArrayList<TrackData> ready=new ArrayList<>();
    private int preparedStyle=0, preparedBeats=16;
    private volatile boolean playAfterPrepare=false;
    private volatile boolean completeAnalysis=false;
    private volatile boolean progressiveStarted=false;
    private static final int STARTUP_TRACKS=2;
    private volatile String sessionId=java.util.UUID.randomUUID().toString();
    private volatile boolean studioStarting=false;

    @Override public void onCreate(Bundle state){
        super.onCreate(state);
        if(CRASH_HANDLER_INSTALLED.compareAndSet(false,true)){
            final android.content.Context appContext=getApplicationContext();
            final Thread.UncaughtExceptionHandler androidCrashHandler=Thread.getDefaultUncaughtExceptionHandler();
            Thread.setDefaultUncaughtExceptionHandler((thread,error)->{
                try{appContext.getSharedPreferences("aura",MODE_PRIVATE).edit()
                    .putString("lastCrash",Log.getStackTraceString(error)).commit();}catch(Throwable ignored){}
                // Keep Android's normal crash report and avoid Activity references.
                if(androidCrashHandler!=null)androidCrashHandler.uncaughtException(thread,error);
                else android.os.Process.killProcess(android.os.Process.myPid());
            });
        }
        restoreSelectedMusic();
        getWindow().setStatusBarColor(Color.rgb(4,17,12));
        getWindow().setNavigationBarColor(Color.rgb(4,17,12));
        getWindow().setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_ADJUST_RESIZE);
        web=new WebView(this);web.setBackgroundColor(Color.rgb(4,17,12));
        WebSettings settings=web.getSettings();
        settings.setJavaScriptEnabled(true);
        settings.setDomStorageEnabled(true);
        settings.setDatabaseEnabled(true);
        settings.setAllowFileAccess(false);
        settings.setAllowContentAccess(false);
        settings.setAllowFileAccessFromFileURLs(false);
        settings.setAllowUniversalAccessFromFileURLs(false);
        settings.setMixedContentMode(WebSettings.MIXED_CONTENT_NEVER_ALLOW);
        // All app assets are intercepted locally; remote scripts never see AURA_ANDROID.
        settings.setBlockNetworkLoads(true);
        settings.setMediaPlaybackRequiresUserGesture(false);
        settings.setDefaultTextEncodingName("UTF-8");
        web.addJavascriptInterface(new Bridge(),"AURA_ANDROID");
        web.setWebViewClient(new WebViewClient(){
            @Override public boolean shouldOverrideUrlLoading(WebView view,WebResourceRequest req){
                Uri url=req.getUrl();
                if("aura.android.local".equals(url.getHost())&&"https".equals(url.getScheme()))return false;
                if("https".equals(url.getScheme())){
                    try{startActivity(new Intent(Intent.ACTION_VIEW,url));}catch(Exception e){Log.w(TAG,"External link",e);}
                }
                return true;
            }
            @Override public WebResourceResponse shouldInterceptRequest(WebView view,WebResourceRequest req){
                Uri u=req.getUrl();
                // No remote JS receives the native bridge. AURA is offline by design.
                if(!"https".equals(u.getScheme()) || !"aura.android.local".equals(u.getHost()))
                    return new WebResourceResponse("text/plain","UTF-8",403,"Offline",new java.util.HashMap<>(),new java.io.ByteArrayInputStream(new byte[0]));
                String path=u.getPath();
                if("/native-ui.js".equals(path))Log.i(TAG,"AURA_LOCAL_JS_ASSET");
                if(!"/index.html".equals(path) && !"/classic.html".equals(path) && !"/native-ui.js".equals(path))return new WebResourceResponse("text/plain","UTF-8",403,"Forbidden",new java.util.HashMap<>(),new java.io.ByteArrayInputStream(new byte[0]));
                try{
                    InputStream content=getAssets().open("/native-ui.js".equals(path)?"native-ui.js":("/classic.html".equals(path)?"aura.html":"aura-fast.html"));
                    return new WebResourceResponse("/native-ui.js".equals(path)?"application/javascript":"text/html","UTF-8",content);
                }catch(Exception e){Log.e(TAG,"Asset load failed",e);return new WebResourceResponse("text/plain","UTF-8",new java.io.ByteArrayInputStream(e.toString().getBytes(StandardCharsets.UTF_8)));}
            }
            @Override public void onPageFinished(WebView view,String url){
                Uri page=Uri.parse(url==null?"":url);
                if(!"https".equals(page.getScheme()) || !"aura.android.local".equals(page.getHost()) ||
                   !("/index.html".equals(page.getPath()) || "/classic.html".equals(page.getPath()))){
                    loaded=false;
                    return; // Never inject a native controller into a foreign page.
                }
                loaded=true;
                Log.i(TAG,"AURA_OFFLINE_UI_READY "+page.getPath());
                // Keep the original HTML unchanged: the native controls are a separate, auditable layer.
                if(url!=null && url.endsWith("/classic.html")){
                    view.evaluateJavascript("(function(){var b=document.createElement('button');b.textContent='← Voltar ao Android';b.style='position:fixed;top:8px;right:8px;z-index:99999;background:#0a7647;color:#fff;border:1px solid #5f9;border-radius:10px;padding:10px';b.onclick=function(){location.href='/index.html'};document.body.appendChild(b)})();",null);
                }else{
                    view.evaluateJavascript("(function(){var s=document.createElement('script');s.src='/native-ui.js';document.body.appendChild(s);})();",null);
                }
            }
        });
        web.setWebChromeClient(new WebChromeClient(){
            @Override public boolean onShowFileChooser(WebView v,android.webkit.ValueCallback<Uri[]> result,FileChooserParams params){
                if(webFileResult!=null)webFileResult.onReceiveValue(null);
                webFileResult=result;
                // Web file chooser belongs exclusively to explicit CLASSIC mode.
                // The Android Native picker is invoked by AURA_ANDROID.pick().
                nativeFileSelect=false;
                boolean audio=false;
                for(String a:params.getAcceptTypes())if(a!=null&&(a.contains("audio")||a.contains(".mp3")||a.contains(".wav")))audio=true;
                openPicker(audio,params.getMode()==FileChooserParams.MODE_OPEN_MULTIPLE);
                return true;
            }
            @Override public boolean onConsoleMessage(ConsoleMessage m){
                if(m.messageLevel()==ConsoleMessage.MessageLevel.ERROR)Log.e(TAG,"Web UI: "+m.message()+" @"+m.lineNumber());
                return true;
            }
        });
        setContentView(web);
        ensureQuickSamplers();
        // Seed the legacy preferences before its bundled JS initializes.
        // The original ONNX Web pipeline must not compete with native MediaCodec.
        web.loadUrl(APP_URL);
        if(!musicUris.isEmpty()&&!AudioService.isPlaying()&&!QuickMixService.isPlaying())main.post(()->prepareLibrary(false));
        else if(AudioService.isPlaying())new Thread(()->{try{List<TrackData> cached=SessionStore.load(this).tracks;main.post(()->{if(!isDestroyed()&&AudioService.isPlaying()&&!preparing){synchronized(ready){ready.clear();ready.addAll(cached);}decodedCount=cached.size();completeAnalysis=cached.size()==selectedCount;}});}catch(Exception ignored){}},"EGMIX-library-restore").start();
        NeuralStemActivity.prepareBundledModelAsync(getApplicationContext());
    }
    private void openPicker(boolean music,boolean multiple){
        Intent i=new Intent(Intent.ACTION_OPEN_DOCUMENT);
        i.addCategory(Intent.CATEGORY_OPENABLE);i.setType(music?"audio/*":"*/*");
        i.putExtra(Intent.EXTRA_ALLOW_MULTIPLE,multiple);
        i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION|Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION);
        try{startActivityForResult(i,PICK_AUDIO);}catch(Exception e){
            if(webFileResult!=null){webFileResult.onReceiveValue(null);webFileResult=null;}
            alert("Seletor de músicas",e.toString());
        }
    }
    @Override protected void onActivityResult(int request,int result,Intent data){
        super.onActivityResult(request,result,data);
        if(request==NEURAL_STEMS){if(result==RESULT_OK){synchronized(ready){ready.clear();}decodedCount=0;completeAnalysis=false;}prepareLibrary(false);return;}
        if(request==PICK_JINGLE){if(result==RESULT_OK&&data!=null&&data.getData()!=null)changeJingle(data.getData());return;}
        if(request==SAVE_MASTER || request==SAVE_INCIDENT){
            final boolean incident=request==SAVE_INCIDENT;
            if(result==RESULT_OK&&data!=null&&data.getData()!=null){
                Uri out=data.getData();
                new Thread(()->{
                    String path=getSharedPreferences("aura",MODE_PRIVATE).getString(
                            incident?"pcm_last_incident":"lastMaster","");
                    try{
                        File verified=PrivateAudioExport.resolve(getFilesDir(),path,
                                incident?PrivateAudioExport.Kind.INCIDENT:PrivateAudioExport.Kind.MASTER);
                        if(verified==null)throw new java.io.IOException("Arquivo privado inválido ou ausente");
                        try(java.io.InputStream in=new java.io.FileInputStream(verified);
                        java.io.OutputStream dest=getContentResolver().openOutputStream(out)){
                        if(dest==null)throw new java.io.IOException("Não foi possível salvar o master");
                        byte[] block=new byte[65536];int n;
                        while((n=in.read(block))>=0)dest.write(block,0,n);
                        status(incident?"Captura de incidente exportada.":"Master WAV salvo no destino escolhido.");
                    }
                    }catch(Exception e){status("Não foi possível exportar o WAV: "+e);}
                },"AURA-master-export").start();
            }
            return;
        }
        if(request!=PICK_AUDIO)return;
        ArrayList<Uri> list=new ArrayList<>();
        if(result==RESULT_OK && data!=null){
            ClipData clip=data.getClipData();
            if(clip!=null){for(int i=0;i<clip.getItemCount();i++)list.add(clip.getItemAt(i).getUri());}
            else if(data.getData()!=null)list.add(data.getData());
        }
        if(nativeFileSelect && !list.isEmpty()){
            cancelPreparation();
            if(AudioService.isPlaying()||QuickMixService.isPlaying()){stopNative();}
            for(Uri u:list)if(!musicUris.contains(u))musicUris.add(u);completeAnalysis=false;
            list=new ArrayList<>(musicUris);
            synchronized(selectedNames){
                selectedNames.clear();for(int i=0;i<list.size();i++)selectedNames.add("Música "+(i+1));
            }
            selectedCount=list.size();decodedCount=0;playIndex=0;decodeFailures="";
            saveSelectedMusic();
            // ContentResolver queries can block for seconds on cloud-backed providers.
            // Do not resolve 20+ filenames on the Android UI thread.
            final int labelVersion=selectionVersion.incrementAndGet();
            Thread previous=selectionThread;if(previous!=null)previous.interrupt();
            final ArrayList<Uri> pendingNames=new ArrayList<>(list);
            selectionThread=new Thread(()->{
                // Persist all access grants before resolving potentially slow
                // display names from a cloud-backed provider.
                for(Uri uri:pendingNames){
                    if(Thread.currentThread().isInterrupted()||labelVersion!=selectionVersion.get())return;
                    try{getContentResolver().takePersistableUriPermission(uri,Intent.FLAG_GRANT_READ_URI_PERMISSION);}
                    catch(Exception ex){Log.w(TAG,"Unable to persist access: "+uri,ex);}
                }
                ArrayList<String> resolved=new ArrayList<>();
                for(Uri uri:pendingNames){
                    if(Thread.currentThread().isInterrupted()||labelVersion!=selectionVersion.get())return;
                    resolved.add(trackName(uri));
                }
                main.post(()->{
                    if(labelVersion!=selectionVersion.get()||!musicUris.equals(pendingNames))return;
                    synchronized(selectedNames){selectedNames.clear();selectedNames.addAll(resolved);}
                    saveSelectedMusic();
                    main.postDelayed(()->prepareLibrary(false),350);
                });
            },"AURA-resolve-file-labels");
            selectionThread.start();
            preparedStyle=0;preparedBeats=16;synchronized(ready){ready.clear();}
            status("Importadas "+list.size()+" faixas. Análise automática BPM + Camelot em seguida.");
        }
        // Native picker results MUST NOT also enter HTML's FileList. Doing so
        // launches 2 independent decoders and the broken ONNX worker.
        if(webFileResult!=null){webFileResult.onReceiveValue(nativeFileSelect||list.isEmpty()?null:list.toArray(new Uri[0]));webFileResult=null;}
        nativeFileSelect=false;
    }
    private void cancelPreparation(){
        synchronized(ready){prepVersion.incrementAndGet();}
        Thread t=preparationThread;if(t!=null)t.interrupt();
        preparing=false;playAfterPrepare=false;progressiveStarted=false;AudioService.libraryPreparing=false;
    }
    private void pickNative(){
        if(studioStarting){status("Aguarde o início da sessão ou toque em Parar.");return;}
        if(preparing){status("Análise PCM em andamento: "+decodedCount+"/"+selectedCount+". Use Parar para cancelar.");return;}
        nativeFileSelect=true;
        if(webFileResult!=null){webFileResult.onReceiveValue(null);webFileResult=null;}
        openPicker(true,true);
    }
    private void clearNative(){
        cancelPreparation();stopNative();
        selectionVersion.incrementAndGet();
        Thread resolver=selectionThread;if(resolver!=null)resolver.interrupt();
        musicUris.clear();synchronized(selectedNames){selectedNames.clear();}
        selectedCount=0;decodedCount=0;completeAnalysis=false;
        saveSelectedMusic();
        synchronized(ready){ready.clear();}
        status("Biblioteca limpa. Adicione músicas.");
    }
    private String trackName(Uri uri){
        try(android.database.Cursor c=getContentResolver().query(uri,new String[]{OpenableColumns.DISPLAY_NAME},null,null,null)){
            if(c!=null&&c.moveToFirst()){String name=c.getString(0);if(name!=null&&!name.trim().isEmpty())return name;}
        }catch(Exception ignored){}
        return uri.getLastPathSegment()==null?"Música":uri.getLastPathSegment();
    }
    private void saveSelectedMusic(){
        JSONArray uris=new JSONArray(),names=new JSONArray();
        synchronized(selectedNames){
            for(int i=0;i<musicUris.size();i++){
                uris.put(musicUris.get(i).toString());
                names.put(i<selectedNames.size()?selectedNames.get(i):"Música "+(i+1));
            }
        }
        getSharedPreferences("aura",MODE_PRIVATE).edit()
            .putString("fastUris",uris.toString())
            .putString("fastNames",names.toString()).apply();
    }
    private void restoreSelectedMusic(){
        try{
            android.content.SharedPreferences prefs=getSharedPreferences("aura",MODE_PRIVATE);
            JSONArray uris=new JSONArray(prefs.getString("fastUris","[]"));
            JSONArray names=new JSONArray(prefs.getString("fastNames","[]"));
            for(int i=0;i<uris.length();i++){
                Uri uri=Uri.parse(uris.getString(i));
                musicUris.add(uri);
                synchronized(selectedNames){selectedNames.add(i<names.length()?names.getString(i):"Música "+(i+1));}
            }
            selectedCount=musicUris.size();
        }catch(Exception e){Log.w(TAG,"Could not restore song selection",e);}
    }
    private void status(String s){getSharedPreferences("aura",MODE_PRIVATE).edit().putString("status",s).apply();}
    private String status(){return getSharedPreferences("aura",MODE_PRIVATE).getString("status","EG MIX Android nativo pronto");}
    private void alert(String title,String msg){main.post(()->new AlertDialog.Builder(this).setTitle(title).setMessage(msg).setPositiveButton("OK",null).show());}
    private void startQuick(String style,String beats){
        if(NeuralStemActivity.isBusy()||studioStarting){status("Aguarde a preparação em andamento.");return;}
        if(jingleBusy){status("Aguarde a troca da vinheta.");return;}
        // AURA 11: default to asynchronous source-URI playback; do not hold
        // the Play button hostage to full PCM decoding of eight songs.
        if(musicUris.isEmpty()){
            status("Selecione músicas em + Músicas antes de iniciar o DJ.");return;
        }
        cancelPreparation();
        if(AudioService.isPlaying())stopStudio();
        preparedStyle=styleIndex(style);
        try{preparedBeats=Integer.parseInt(beats);}catch(Exception ex){preparedBeats=0;}
        saveSelectedMusic();
        Intent fast=new Intent(this,QuickMixService.class).setAction(QuickMixService.START);
        fast.putExtra("style",preparedStyle).putExtra("beats",preparedBeats);
        try{
            if(Build.VERSION.SDK_INT>=26)startForegroundService(fast);else startService(fast);
            status("Iniciando som diretamente dos arquivos; sem esperar análises.");
        }catch(Exception ex){status("Falha ao iniciar motor imediato: "+ex);Log.e(TAG,"Fast start",ex);}
    }
    // Progressive preparation: preserve the active set and append ready tracks.
    private void startStudio(String style,String beats){
        if(NeuralStemActivity.isBusy()||jingleBusy){status("Aguarde a preparação em andamento.");return;}
        if(musicUris.isEmpty()){status("Importe músicas antes de iniciar.");return;}
        if(studioStarting)return;
        if(AudioService.isPlaying()){resumeNative();return;}
        if(QuickMixService.isPlaying()){status("Pare o motor rápido antes de iniciar o Estúdio PCM.");return;}
        preparedStyle=styleIndex(style);try{preparedBeats=Integer.parseInt(beats);}catch(Exception ex){preparedBeats=16;}
        prepareLibrary(true);
    }
    private void prepareLibrary(boolean play){
        if(musicUris.isEmpty()||NeuralStemActivity.isBusy())return;
        if(AudioService.isPlaying()){if(!play&&!preparing&&!completeAnalysis)main.postDelayed(()->prepareLibrary(false),600);return;}
        if(play)playAfterPrepare=true;
        if(preparing){if(play){status("Tocar após preparar as primeiras faixas; restante em segundo plano.");maybeStartProgressive(prepVersion.get(),musicUris.size());}return;}
        if(completeAnalysis){if(play){playAfterPrepare=false;sessionId=java.util.UUID.randomUUID().toString();begin();}return;}
        sessionId=java.util.UUID.randomUUID().toString();
        synchronized(ready){ready.clear();}preparing=true;decodedCount=0;cacheReused=cacheInvalidated=0;progressiveStarted=false;AudioService.libraryPreparing=true;
        int version=prepVersion.incrementAndGet();
        ArrayList<Uri> selected=new ArrayList<>(musicUris);
        status("Analisando biblioteca automaticamente: BPM, tonalidade e estrutura.");
        preparationThread=new Thread(()->prepare(selected,version),"EGMIX-library-analysis");
        preparationThread.start();
    }
    private int styleIndex(String s){
        switch(s){
            case "smooth":return 1;case "linear":return 2;case "s-curve":return 3;
            case "focus":return 4;case "dj":return 5;case "early":return 6;case "late":return 7;
            default:return 0;
        }
    }
    private String sourceFingerprint(Uri uri)throws java.io.IOException{
        try(java.io.InputStream in=getContentResolver().openInputStream(uri)){
            return br.com.edgard.aura.core.SourceFingerprint.sha256(in);
        }catch(SecurityException e){throw new java.io.IOException("Permissão do arquivo original indisponível",e);}
    }
    private void measureLoudness(TrackData track)throws java.io.InterruptedIOException{
        if(track.loudnessVersion==1)return;
        try{track.loudnessLufs=br.com.edgard.aura.core.LoudnessAnalyzer.analyze(track.file,track.sampleRate,track.frames);track.loudnessVersion=1;}
        catch(java.io.InterruptedIOException e){throw e;}catch(java.io.IOException e){Log.w(TAG,"Loudness indisponível; RMS preservado",e);}
    }
    private void prepare(List<Uri> list,int version){
        ArrayList<TrackData> tmp=new ArrayList<>();
        StringBuilder failures=new StringBuilder();
        try{
            // Reuse individual previously validated PCM files, even after adding more tracks.
            java.util.Map<String,TrackData> cache=new java.util.HashMap<>();
            try{for(TrackData t:SessionStore.load(this).tracks)if(!t.sourceUri.isEmpty())cache.put(t.sourceUri,t);}catch(Exception ignored){}
            File dir=br.com.edgard.aura.core.PcmSessionCache.create(getFilesDir());
            for(int i=0;i<list.size();i++){
                if(progressiveStarted)android.os.Process.setThreadPriority(android.os.Process.THREAD_PRIORITY_BACKGROUND);
                if(version!=prepVersion.get()||Thread.currentThread().isInterrupted())return;
                Uri u=list.get(i);String name=trackName(u);int seq=i+1;
                String sourceHash;
                try{status("Verificando arquivo "+seq+"/"+list.size()+": "+name);sourceHash=sourceFingerprint(u);}
                catch(java.io.IOException e){if(Thread.currentThread().isInterrupted())return;failures.append(name).append(": ").append(e.getMessage()).append("; ");decodeFailures=failures.toString();continue;}
                TrackData prior=cache.get(u.toString());
                if(prior!=null&&br.com.edgard.aura.core.SourceFingerprint.matches(prior.sourceHash,sourceHash)){
                    try{if(prior.audibleEndSeconds<=0)prior.audibleEndSeconds=BeatAnalyzer.lastAudible(prior.file,prior.sampleRate,prior.frames);
                        if(prior.stemFolder()==null){File f=TrackData.locateStems(getFilesDir(),prior.file,prior.sampleRate,prior.frames);if(f!=null)prior.attachStems(f);}}
                    catch(Exception ignored){}
                    if(version!=prepVersion.get()||Thread.currentThread().isInterrupted())return;
                    status("Verificando loudness "+seq+"/"+list.size()+": "+name);measureLoudness(prior);
                    if(version!=prepVersion.get()||Thread.currentThread().isInterrupted())return;
                    cacheReused++;tmp.add(prior);status("Análise reaproveitada "+seq+"/"+list.size()+": "+name);publishProgress(tmp,version,list.size());continue;
                }
                if(prior!=null)cacheInvalidated++;
                status("Decodificando "+seq+"/"+list.size()+": "+name);
                File file=new File(dir,String.format(Locale.ROOT,"mix-%04d.pcm",i));
                boolean published=false;
                try{
                    // Each session has its own immutable PCM cache files.
                    AudioDecoder.Result decoded=AudioDecoder.decode(this,u,file,frames->{
                        if(version!=prepVersion.get())Thread.currentThread().interrupt();
                        if(version==prepVersion.get())status("Decodificando "+seq+"/"+list.size()+" · "+String.format(Locale.ROOT,"%.1f",frames/1_000_000.0)+" M amostras: "+name);
                    });
                    if(version!=prepVersion.get()||Thread.currentThread().isInterrupted())return;
                    status("Medindo batidas "+seq+"/"+list.size()+": "+name);
                    BeatAnalyzer.Result head=BeatAnalyzer.analyze(file,decoded.sampleRate);
                    double audibleEnd=BeatAnalyzer.lastAudible(file,decoded.sampleRate,decoded.frames);
                    double tailStart=Math.max(0,audibleEnd-44);
                    BeatAnalyzer.Result tail=BeatAnalyzer.analyzeRange(file,decoded.sampleRate,tailStart,42);
                    PhraseAnalyzer.Result phrases;
                    try {
                        phrases=PhraseAnalyzer.analyze(file,decoded.sampleRate,decoded.frames,
                                head.bpm,head.phase,head.confidence,tail.bpm,tail.phase,tail.confidence);
                    } catch(java.io.IOException phraseError){
                        Log.w(TAG,"Phrase estimate unavailable",phraseError);
                        phrases=new PhraseAnalyzer.Result(0,0,0,0);
                    }
                    TrackData prepared=new TrackData(name,file,decoded.sampleRate,decoded.frames,
                          head.bpm,head.confidence,head.phase,head.rms,
                          tail.bpm,tail.confidence,tail.phase,tailStart,
                          BeatAnalyzer.firstAudible(file,decoded.sampleRate),
                          phrases.introSeconds,phrases.outroSeconds,
                          phrases.introConfidence,phrases.outroConfidence);
                    if(!br.com.edgard.aura.core.SourceFingerprint.matches(sourceHash,sourceFingerprint(u)))throw new java.io.IOException("Arquivo modificado durante a preparação; importe novamente");
                    prepared.sourceUri=u.toString();prepared.sourceHash=sourceHash;prepared.audibleEndSeconds=audibleEnd;
                    status("Medindo loudness "+seq+"/"+list.size()+": "+name);measureLoudness(prepared);
                    try{br.com.edgard.aura.core.HarmonicAnalyzer.Result key=br.com.edgard.aura.core.HarmonicAnalyzer.analyze(file,decoded.sampleRate,decoded.frames);prepared.camelot=key.key;prepared.keyConfidence=key.confidence;}catch(java.io.IOException e){Log.w(TAG,"Tom indisponível",e);}
                    try{File stemDir=TrackData.locateStems(getFilesDir(),file,decoded.sampleRate,decoded.frames);if(stemDir!=null)prepared.attachStems(stemDir);}catch(java.io.IOException e){Log.w(TAG,"Stems indisponíveis; master original preservado",e);}
                    synchronized(ready){
                        if(version!=prepVersion.get()||Thread.currentThread().isInterrupted())return;
                        tmp.add(prepared);
                        published=true;
                        decodedCount=tmp.size();
                        if(!progressiveStarted){ready.clear();ready.addAll(tmp);}
                    }
                    status("DSP pronto "+decodedCount+"/"+list.size()+": "+name);
                    publishProgress(tmp,version,list.size());
                }catch(Throwable e){
                    if(Thread.currentThread().isInterrupted())return;
                    failures.append(name).append(": ").append(e.getMessage()).append("; ");
                    decodeFailures=failures.toString();
                    Log.w(TAG,"Decode/analysis failed",e);
                    status("Arquivo recusado ("+seq+"/"+list.size()+"): "+name+" · "+e.getClass().getSimpleName());
                }finally{if(!published)file.delete();}
            }
            if(version!=prepVersion.get())return;
            finishAnalysis(tmp,version,list.size());
        }catch(Throwable t){status("Falha de preparação: "+t);Log.e(TAG,"Native preparation",t);}
        finally{main.post(()->{if(version==prepVersion.get()&&preparing){preparing=false;playAfterPrepare=false;preparationThread=null;AudioService.libraryPreparing=false;}});}
    }
    private void publishProgress(List<TrackData> tmp,int version,int total)throws Exception{
        synchronized(ready){if(version!=prepVersion.get())return;
            if(progressiveStarted){java.util.HashSet<String> seen=new java.util.HashSet<>();for(TrackData t:ready)seen.add(t.sourceUri);
                for(TrackData t:tmp)if(seen.add(t.sourceUri))ready.add(t);
                SessionStore.save(this,new ArrayList<>(ready),preparedStyle,preparedBeats,sessionId);
            }else{ready.clear();ready.addAll(tmp);}
            decodedCount=tmp.size();
        }
        main.post(()->maybeStartProgressive(version,total));
    }
    private void maybeStartProgressive(int version,int total){
        if(version!=prepVersion.get()||isDestroyed()||!playAfterPrepare||progressiveStarted||AudioService.isPlaying())return;
        synchronized(ready){if(ready.size()<Math.min(STARTUP_TRACKS,total))return;
            List<TrackData> order=TrackPlanner.order(ready);ready.clear();ready.addAll(order);progressiveStarted=true;playAfterPrepare=false;
            begin();
        }
    }
    private void finishAnalysis(List<TrackData> tmp,int version,int total)throws Exception{
        List<TrackData> ordered;
        synchronized(ready){if(version!=prepVersion.get()||Thread.currentThread().isInterrupted())return;
            if(progressiveStarted){java.util.HashSet<String> seen=new java.util.HashSet<>();for(TrackData t:ready)seen.add(t.sourceUri);for(TrackData t:tmp)if(seen.add(t.sourceUri))ready.add(t);ordered=new ArrayList<>(ready);}else ordered=TrackPlanner.order(tmp);
            if(!ordered.isEmpty())SessionStore.save(this,ordered,preparedStyle,preparedBeats,sessionId);
            ready.clear();ready.addAll(ordered);decodedCount=ordered.size();}
        main.post(()->{if(version!=prepVersion.get()||isDestroyed())return;preparing=false;preparationThread=null;completeAnalysis=!ordered.isEmpty();AudioService.libraryPreparing=false;
            status(ordered.isEmpty()?"Nenhuma faixa válida. Verifique os arquivos.":"Fila inteligente pronta: "+ordered.size()+"/"+total+" • BPM + Camelot (estimado).");
            boolean play=playAfterPrepare;playAfterPrepare=false;if(play&&!ordered.isEmpty())begin();});
    }
    private void begin(){
        if(studioStarting||AudioService.isPlaying()||QuickMixService.isPlaying()||isDestroyed())return;
        try{
            List<TrackData> list;
            synchronized(ready){
                list=new ArrayList<>(ready);
                if(list.isEmpty())return;
                SessionStore.save(this,list,preparedStyle,preparedBeats,sessionId);
            }
            studioStarting=true;
            main.postDelayed(()->studioStarting=false,8000);
            Intent s=new Intent(this,AudioService.class);s.setAction(AudioService.START);
            if(Build.VERSION.SDK_INT>=26)startForegroundService(s);else startService(s);
            status("Iniciando mixagem EG MIX nativa…");
        }catch(Exception e){studioStarting=false;status("Falha ao iniciar: "+e);Log.e(TAG,"Start failed",e);}
    }
    private void stopStudio(){Intent s=new Intent(this,AudioService.class).setAction(AudioService.STOP);startService(s);}
    private void stopNative(){
        cancelPreparation();
        if(QuickMixService.isPlaying())startService(new Intent(this,QuickMixService.class).setAction(QuickMixService.STOP));
        if(AudioService.isPlaying()||studioStarting)stopStudio();studioStarting=false;status("EG MIX Android: reprodução parada.");
    }
    private void pauseNative(){
        if(QuickMixService.isPlaying())startService(new Intent(this,QuickMixService.class).setAction(QuickMixService.PAUSE));
        if(AudioService.isPlaying())startService(new Intent(this,AudioService.class).setAction(AudioService.PAUSE));
    }
    private void resumeNative(){
        if(NeuralStemActivity.isBusy()){status("Aguarde o término da separação neural.");return;}
        if(QuickMixService.isPlaying())startService(new Intent(this,QuickMixService.class).setAction(QuickMixService.RESUME));
        if(AudioService.isPlaying())startService(new Intent(this,AudioService.class).setAction(AudioService.RESUME));
    }
    private void nextNative(){
        if(QuickMixService.isPlaying())startService(new Intent(this,QuickMixService.class).setAction(QuickMixService.NEXT));
        if(AudioService.isPlaying())startService(new Intent(this,AudioService.class).setAction(AudioService.NEXT));
    }
    private void toggleRecord(boolean requested){
        if(QuickMixService.isPlaying()){
            status("Gravação WAV não disponível no modo rápido. Use Estúdio PCM experimental para gravar.");return;
        }
        getSharedPreferences("aura",MODE_PRIVATE).edit().putBoolean("recordRequested",requested).apply();
        Intent s=new Intent(this,AudioService.class);
        s.setAction(requested?AudioService.RECORD:AudioService.RECORD_OFF);
        startService(s);
        status(requested?"Gravação WAV solicitada":"Gravação WAV interrompida");
    }
    private void testAudio(){
        if(AudioService.isPlaying()||QuickMixService.isPlaying()){
            status("Pare a reprodução antes de testar a saída de áudio.");return;
        }
        Intent s=new Intent(this,AudioService.class);s.setAction(AudioService.SELFTEST);
        try{startService(s);}catch(Exception e){status("Falha ao solicitar teste de som: "+e);}
    }
    private void exportMaster(){
        String path=getSharedPreferences("aura",MODE_PRIVATE).getString("lastMaster","");
        try{if(PrivateAudioExport.resolve(getFilesDir(),path,PrivateAudioExport.Kind.MASTER)==null){
            alert("Master WAV","Nenhum master válido foi gravado ainda.");return;
        }}catch(java.io.IOException e){alert("Master WAV","Arquivo de gravação inválido.");return;}
        Intent i=new Intent(Intent.ACTION_CREATE_DOCUMENT);
        i.addCategory(Intent.CATEGORY_OPENABLE);i.setType("audio/wav");
        i.putExtra(Intent.EXTRA_TITLE,"EG-MIX-Master.wav");
        startActivityForResult(i,SAVE_MASTER);
    }
    private void toggleIncidentCapture(boolean enabled){
        getSharedPreferences("aura",MODE_PRIVATE).edit()
                .putBoolean("pcm_incident_capture_enabled",enabled).apply();
        status(enabled?"Captura de incidentes PCM autorizada (arquivos locais; até 5 WAVs)":
                "Captura de incidentes PCM desativada");
    }
    private void exportIncident(){
        String path=getSharedPreferences("aura",MODE_PRIVATE).getString("pcm_last_incident","");
        try{if(PrivateAudioExport.resolve(getFilesDir(),path,PrivateAudioExport.Kind.INCIDENT)==null){
            File folder=new File(getFilesDir(),"pcm-incidents");
            File[] files=folder.listFiles((dir,name)->name.startsWith("incident-")&&name.endsWith(".wav"));
            if(files!=null&&files.length>0){
                java.util.Arrays.sort(files,(a,b)->Long.compare(b.lastModified(),a.lastModified()));
                path=files[0].getAbsolutePath();
                getSharedPreferences("aura",MODE_PRIVATE).edit().putString("pcm_last_incident",path).apply();
            }
        }}catch(java.io.IOException e){path="";}
        try{if(PrivateAudioExport.resolve(getFilesDir(),path,PrivateAudioExport.Kind.INCIDENT)==null){
            alert("Capturas PCM","Nenhum incidente válido foi capturado.");return;
        }}catch(java.io.IOException e){alert("Capturas PCM","Arquivo privado inválido.");return;}
        Intent i=new Intent(Intent.ACTION_CREATE_DOCUMENT);
        i.addCategory(Intent.CATEGORY_OPENABLE);i.setType("audio/wav");
        i.putExtra(Intent.EXTRA_TITLE,"EG-MIX-diagnostico-incidente.wav");
        startActivityForResult(i,SAVE_INCIDENT);
    }
    private void diagnostics(){
        android.content.SharedPreferences prefs=getSharedPreferences("aura",MODE_PRIVATE);
        String info="EG MIX 11.5.7 · Android "+Build.VERSION.RELEASE+" (SDK "+Build.VERSION.SDK_INT+")\n"+
         "Faixas selecionadas: "+selectedCount+"\nPCM decodificadas: "+decodedCount+"\nMotor rápido: "+QuickMixService.isPlaying()+"\nMotor PCM: "+AudioService.isPlaying()+"\n"+
         "Modo do motor: "+prefs.getString("dj_mode","idle")+"\n"+
         "FX quadros: "+AudioService.fxAppliedFrames+" | sampler: "+AudioService.samplerFrames+" | mix: "+AudioService.mixedFrames+" | transições: "+AudioService.mixedTransitions+" | recuperações sem mix: "+AudioService.hardHandoffs+"\n"+
         "Índice atual: "+prefs.getInt("dj_index",0)+"\n"+
         "Tempo: "+prefs.getFloat("dj_time",0)+" s / "+prefs.getInt("quick_duration_ms",0)+" ms\n"+
         "Próxima preparada: "+prefs.getBoolean("quick_next_ready",false)+"\n"+
         "BPM atual (medido): "+prefs.getFloat("quick_current_bpm",0)+"\n"+
         "BPM seguinte (medido): "+prefs.getFloat("quick_next_bpm",0)+"\n"+
         "Beatmatch aplicado: "+prefs.getBoolean("quick_beatmatch",false)+"\n"+
         "PCM buffer ON: "+prefs.getInt("pcm_buffer_a",-1)+" frames\n"+
         "PCM buffer NEXT: "+prefs.getInt("pcm_buffer_b",-1)+" frames\n"+
         "Falhas de alimentação PCM: "+prefs.getLong("pcm_starves",0)+"\n"+
         "Transições adiadas automaticamente: "+prefs.getLong("pcm_auto_deferred",0)+"\n"+
         "Beatmatch cancelado por fase incerta: "+prefs.getLong("pcm_auto_phase_fallbacks",0)+"\n"+
         "Última autocorreção: "+prefs.getString("pcm_auto_last_reason","nenhuma")+"\n"+
         "Alertas de áudio digital: "+prefs.getLong("pcm_auto_digital_alerts",0)+"\n"+
         "Underruns da saída Android: "+prefs.getInt("pcm_android_output_underruns",0)+"\n"+
         "Buffer Android atual/capacidade: "+prefs.getInt("pcm_android_buffer_frames",0)+" / "+
            prefs.getInt("pcm_android_buffer_capacity_frames",0)+" frames\n"+
         "Solicitações de ampliação do buffer: "+prefs.getLong("pcm_android_buffer_growth_requests",0)+"\n"+
         "Captura autorizada: "+prefs.getBoolean("pcm_incident_capture_enabled",false)+"\n"+
         "Última captura WAV: "+prefs.getString("pcm_last_incident","nenhuma")+"\n"+
         "PCM tonalidade preservada (WSOLA): "+prefs.getBoolean("pcm_pitch_preserving",false)+"\n"+
         "Fase sincronizada (modelo): "+prefs.getBoolean("pcm_phase_locked_estimated",false)+"\n"+
         "Erro de fase estimado: "+prefs.getFloat("pcm_phase_error_ms",0)+" ms\n"+
         "Hipótese de frase usada: "+prefs.getBoolean("pcm_phrase_hypothesis_used",false)+"\n"+
         "Pico master PCM: "+prefs.getFloat("pcm_master_peak_dbfs",-120)+" dBFS\n"+
         "RMS master PCM: "+prefs.getFloat("pcm_master_rms_dbfs",-120)+" dBFS\n"+
         "Picos antes do limiter: "+prefs.getLong("pcm_master_pre_limit_clips",0)+" quadros\n"+
         "Clipping após limiter: "+prefs.getLong("pcm_master_output_clips",0)+" quadros\n"+
         "Ganho do limiter estéreo: "+prefs.getFloat("pcm_master_limiter_gain",1)+" x\n"+
         "Quadros com atenuação: "+prefs.getLong("pcm_master_limiter_reduced_frames",0)+"\n"+
         "Correlação estéreo: "+prefs.getFloat("pcm_master_stereo_correlation",0)+"\n"+
         "Nota: métricas referem-se ao PCM digital antes da saída Android; não medem o DAC.\n"+
         "Tipo de mixagem: "+prefs.getString("quick_mix_detail","pendente")+"\n"+
         "Erro na análise: "+prefs.getString("lastBeatError","nenhum")+"\n"+
         "Status: "+status()+"\nErros nos arquivos: "+(decodeFailures.isEmpty()?"nenhum":decodeFailures)+"\n"+
         "Erro no player: "+prefs.getString("lastQuickError","nenhum")+"\n"+
         "Última exceção: "+prefs.getString("lastCrash","nenhuma");
        main.post(()->new AlertDialog.Builder(this).setTitle("EG MIX Diagnóstico Android").setMessage(info)
         .setPositiveButton("Copiar",(d,w)->{
             ClipboardManager c=(ClipboardManager)getSystemService(CLIPBOARD_SERVICE);
             if(c!=null)c.setPrimaryClip(ClipData.newPlainText("EG MIX Android diagnóstico",info));
         }).setNegativeButton("Fechar",null).show());
    }
    private String snapshot(){
        if(AudioService.isPlaying())studioStarting=false;
        JSONObject root=new JSONObject();
        try{
            root.put("status",status());root.put("busy",preparing);root.put("autoPlayPending",playAfterPrepare||studioStarting);root.put("analysisComplete",completeAnalysis);root.put("modelState",NeuralStemActivity.modelState());
            root.put("selected",selectedCount);root.put("decoded",decodedCount);root.put("cacheReused",cacheReused);root.put("cacheInvalidated",cacheInvalidated);root.put("pcmWakeHeld",AudioService.wakeHeld());
            root.put("playing",QuickMixService.isPlaying()||AudioService.isPlaying());root.put("quick",QuickMixService.isPlaying());
            root.put("samplerReady",AudioService.isPlaying()&&!"paused".equals(getSharedPreferences("aura",MODE_PRIVATE).getString("dj_mode",""))?AudioService.samplersReady():!quickSamplerReady.isEmpty());root.put("fxAppliedFrames",AudioService.fxAppliedFrames);root.put("samplerFrames",AudioService.samplerFrames);root.put("mixedFrames",AudioService.mixedFrames);root.put("mixedTransitions",AudioService.mixedTransitions);root.put("hardHandoffs",AudioService.hardHandoffs);
            JSONArray names=new JSONArray();
            synchronized(selectedNames){for(String name:selectedNames)names.put(name);}
            root.put("names",names);
            JSONArray done=new JSONArray();synchronized(ready){
                java.util.LinkedHashMap<String,TrackData> displayOrder=new java.util.LinkedHashMap<>();
                if(AudioService.isPlaying())for(TrackData t:AudioService.playbackOrder())displayOrder.put(t.file.getAbsolutePath(),t);
                for(TrackData t:ready)displayOrder.putIfAbsent(t.file.getAbsolutePath(),t);
                for(TrackData t:displayOrder.values()){
                JSONObject o=new JSONObject();o.put("name",t.title).put("bpm",Math.round(t.bpm*10)/10.0)
                    .put("confidence",t.confidence).put("camelot",t.camelot).put("keyConfidence",t.keyConfidence).put("seconds",t.duration()).put("loudnessLufs",Double.isFinite(t.loudnessLufs)?t.loudnessLufs:-1000).put("loudnessVersion",t.loudnessVersion)
                    .put("phraseIntroConfidence",t.phraseIntroConfidence).put("phraseOutroConfidence",t.phraseOutroConfidence);done.put(o);
            }}root.put("tracks",done);
            android.content.SharedPreferences p=getSharedPreferences("aura",MODE_PRIVATE);
            root.put("index",p.getInt("dj_index",0));root.put("time",p.getFloat("dj_time",0));
            root.put("durationMs",p.getInt("quick_duration_ms",0));
            root.put("quickSeekToken",p.getInt("quick_seek_token",-1));
            root.put("pcmDuration",AudioService.seekDuration());
            root.put("pcmPosition",AudioService.seekPosition());
            root.put("pcmTitle",AudioService.seekTitle());
            TrackData[] activeDecks=AudioService.stemDecks();root.put("rhythmReady",activeDecks[0]!=null&&(activeDecks[0].trustworthyTempo()||activeDecks[0].tailConfidence>=.40));
            root.put("pcmSeekToken",AudioService.seekToken());
            root.put("pcmCanSeek",AudioService.canSeek());
            JSONArray stemDecks=new JSONArray();for(TrackData t:AudioService.stemDecks()){
                if(t==null||t.stemFolder()==null){stemDecks.put(JSONObject.NULL);continue;}
                JSONArray g=new JSONArray();int packed=t.stemGains();for(int k=0;k<4;k++)g.put((packed>>>(k*8))&255);
                stemDecks.put(new JSONObject().put("token",t.stemToken).put("title",t.title).put("gains",g));
            }root.put("pcmStems",stemDecks);
            root.put("next",p.getString("dj_next",""));root.put("mode",p.getString("dj_mode","idle"));
            root.put("recordRequested",p.getBoolean("recordRequested",false));
            root.put("hasMaster",!p.getString("lastMaster","").isEmpty());
            root.put("lastCrash",p.getString("lastCrash",""));
            root.put("lastQuickError",p.getString("lastQuickError",""));
            root.put("nextReady",p.getBoolean("quick_next_ready",false));
            root.put("currentBpm",p.getFloat("quick_current_bpm",0));
            root.put("nextBpm",p.getFloat("quick_next_bpm",0));
            root.put("beatmatched",p.getBoolean("quick_beatmatch",false));
            root.put("mixDetail",p.getString("quick_mix_detail","Análise em andamento"));
            root.put("pitchPreserving",p.getBoolean("pcm_pitch_preserving",false));
            root.put("phaseEstimatedLocked",p.getBoolean("pcm_phase_locked_estimated",false));
            root.put("phaseErrorMs",p.getFloat("pcm_phase_error_ms",0));
            root.put("phraseHypothesis",p.getBoolean("pcm_phrase_hypothesis_used",false));
            root.put("autoDeferred",p.getLong("pcm_auto_deferred",0));
            root.put("autoPhaseFallbacks",p.getLong("pcm_auto_phase_fallbacks",0));
            root.put("autoLastReason",p.getString("pcm_auto_last_reason","nenhuma"));
            root.put("autoDigitalAlerts",p.getLong("pcm_auto_digital_alerts",0));
            root.put("androidOutputUnderruns",p.getInt("pcm_android_output_underruns",0));
            root.put("androidBufferFrames",p.getInt("pcm_android_buffer_frames",0));
            root.put("androidBufferCapacityFrames",p.getInt("pcm_android_buffer_capacity_frames",0));
            root.put("androidBufferGrowthRequests",p.getLong("pcm_android_buffer_growth_requests",0));
            root.put("autoCapture",p.getBoolean("pcm_incident_capture_enabled",false));
            root.put("lastIncident",p.getString("pcm_last_incident",""));
            root.put("masterPeakDbfs",p.getFloat("pcm_master_peak_dbfs",-120));
            root.put("masterRmsDbfs",p.getFloat("pcm_master_rms_dbfs",-120));
            root.put("masterPreLimitClips",p.getLong("pcm_master_pre_limit_clips",0));
            root.put("masterOutputClips",p.getLong("pcm_master_output_clips",0));
            root.put("masterLimiterGain",p.getFloat("pcm_master_limiter_gain",1));
            root.put("masterLimiterReducedFrames",p.getLong("pcm_master_limiter_reduced_frames",0));
        }catch(Exception e){Log.w(TAG,"Snapshot",e);}
        return root.toString();
    }
    public final class Bridge {
        @JavascriptInterface public String snapshot(){return MainActivity.this.snapshot();}
        @JavascriptInterface public void pick(){main.post(()->pickNative());}
        @JavascriptInterface public void clear(){main.post(()->clearNative());}
        @JavascriptInterface public void start(String style,String beats){main.post(()->startStudio(style,beats));}
        @JavascriptInterface public void quick(String style,String beats){main.post(()->startQuick(style,beats));}
        @JavascriptInterface public void studio(String style,String beats){main.post(()->startStudio(style,beats));}
        @JavascriptInterface public void stop(){main.post(()->stopNative());}
        @JavascriptInterface public void pause(){main.post(()->pauseNative());}
        @JavascriptInterface public void resume(){main.post(()->resumeNative());}
        @JavascriptInterface public void next(){main.post(()->nextNative());}
        @JavascriptInterface public void seek(double seconds,int token){
            if(!Double.isFinite(seconds)||seconds<0||!QuickMixService.isPlaying())return;
            long milliseconds=Math.round(seconds*1000.0);
            if(milliseconds<0||milliseconds>Integer.MAX_VALUE)return;
            main.post(()->{
                if(!QuickMixService.isPlaying())return;
                Intent cmd=new Intent(MainActivity.this,QuickMixService.class);
                cmd.setAction(QuickMixService.SEEK);
                cmd.putExtra("positionMs",(int)milliseconds);cmd.putExtra("trackToken",token);
                startService(cmd);
            });
        }

        @JavascriptInterface public void seekPcm(double seconds,long token){
            if(!Double.isFinite(seconds)||seconds<0||!AudioService.canSeek())return;
            main.post(()->{
                if(!AudioService.canSeek()||token!=AudioService.seekToken())return;
                Intent cmd=new Intent(MainActivity.this,AudioService.class);
                cmd.setAction(AudioService.SEEK);cmd.putExtra("seconds",seconds);cmd.putExtra("trackToken",token);
                startService(cmd);
            });
        }

        /** FX reaches ONLY the AudioTrack studio master. MediaPlayer cannot carry DSP inserts. */
        @JavascriptInterface public void pcmFx(String mode,double amount){pcmRhythm(mode,amount,4);}
        @JavascriptInterface public void pcmRhythm(String mode,double amount,int division){
            main.post(()->{
                if(!AudioService.isPlaying())return;
                Intent fx=new Intent(MainActivity.this,AudioService.class);
                fx.setAction(AudioService.FX);
                fx.putExtra("mode",mode==null?"off":mode);
                fx.putExtra("amount",Double.isFinite(amount)?Math.max(0,Math.min(1,amount)):.45);fx.putExtra("division",division);
                startService(fx);
            });
        }

        @JavascriptInterface public void stemGain(long token,int role,int value){AudioService.changeStem(token,role,value);}
        @JavascriptInterface public void stemPreset(long token,int mask){AudioService.changeStem(token,-1,mask);}
        @JavascriptInterface public void neuralStems(){main.post(()->{if(jingleBusy||NeuralStemActivity.isBusy())return;
            Runnable open=()->{String title=AudioService.seekTitle();Uri selected=musicUris.isEmpty()?null:musicUris.get(0);synchronized(ready){for(TrackData t:ready)if(t.title.equals(title)&&!t.sourceUri.isEmpty()){selected=Uri.parse(t.sourceUri);break;}}
                stopNative();Intent i=new Intent(MainActivity.this,NeuralStemActivity.class);if(selected!=null)i.setData(selected);ArrayList<String> library=new ArrayList<>();for(Uri u:musicUris)library.add(u.toString());i.putStringArrayListExtra("library",library);startActivityForResult(i,NEURAL_STEMS);};
            if(preparing||studioStarting||AudioService.isPlaying()||QuickMixService.isPlaying())new AlertDialog.Builder(MainActivity.this).setTitle("Preparar stems neurais").setMessage("A inferência usa muita memória. Parar a sessão e abrir a IA com a faixa atual? A biblioteca permanece salva.").setNegativeButton("Continuar tocando",null).setPositiveButton("Preparar IA",(d,w)->open.run()).show();else open.run();});}
        @JavascriptInterface public void pickJingle(){main.post(()->MainActivity.this.pickJingle());}
        @JavascriptInterface public void resetJingle(){main.post(()->MainActivity.this.changeJingle(null));}
        @JavascriptInterface public void sampler(String key,double volume){
            main.post(()->playSampler(key,volume));
        }
        @JavascriptInterface public void diagnostic(){diagnostics();}
        @JavascriptInterface public void autoCapture(boolean enabled){
            main.post(()->toggleIncidentCapture(enabled));
        }
        @JavascriptInterface public void exportIncident(){main.post(()->MainActivity.this.exportIncident());}
        @JavascriptInterface public void record(boolean enabled){main.post(()->toggleRecord(enabled));}
        @JavascriptInterface public void testAudio(){main.post(()->MainActivity.this.testAudio());}
        @JavascriptInterface public void saveMaster(){main.post(()->exportMaster());}
        @JavascriptInterface public String status(){return MainActivity.this.status();}
        @JavascriptInterface public int count(){return musicUris.size();}
        @JavascriptInterface public boolean busy(){return preparing;}
    }
    @Override public void onBackPressed(){if(web!=null&&web.canGoBack()){web.goBack();}else super.onBackPressed();}
    @Override protected void onDestroy(){
        cancelPreparation();selectionVersion.incrementAndGet();
        Thread resolver=selectionThread;if(resolver!=null)resolver.interrupt();
        if(quickSamplers!=null){quickSamplers.release();quickSamplers=null;quickSamplerIds.clear();quickSamplerReady.clear();}
        if(web!=null){web.removeJavascriptInterface("AURA_ANDROID");web.destroy();web=null;}super.onDestroy();}
}
