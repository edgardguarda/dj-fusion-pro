package br.com.edgard.aura.core;

import java.io.*;
import java.util.Arrays;

/** Integrated stereo loudness: K weighting, 400 ms blocks / 100 ms hop,
 * absolute -70 LUFS and relative -10 LU gating. PCM16 LE, no audio-thread I/O.
 * No true-peak measurement, multichannel weighting or compliance certification. */
public final class LoudnessAnalyzer {
    private LoudnessAnalyzer() {}
    public static final double UNAVAILABLE=-1000;
    private static final class Biquad {
        final double b0,b1,b2,a1,a2;
        double z1,z2;
        Biquad(double b0,double b1,double b2,double a1,double a2){this.b0=b0;this.b1=b1;this.b2=b2;this.a1=a1;this.a2=a2;}
        double tick(double x){double y=b0*x+z1;z1=b1*x-a1*y+z2;z2=b2*x-a2*y;return y;}
    }
    private static Biquad shelf(int rate){
        double k=Math.tan(Math.PI*1681.974450955533/rate),q=.7071752369554196;
        double vh=Math.pow(10,3.999843853973347/20),vb=Math.pow(vh,.4996667741545416),a=1+k/q+k*k;
        return new Biquad((vh+vb*k/q+k*k)/a,2*(k*k-vh)/a,(vh-vb*k/q+k*k)/a,2*(k*k-1)/a,(1-k/q+k*k)/a);
    }
    private static Biquad highpass(int rate){
        double k=Math.tan(Math.PI*38.13547087602444/rate),q=.5003270373238773,a=1+k/q+k*k;
        return new Biquad(1,-2,1,2*(k*k-1)/a,(1-k/q+k*k)/a);
    }
    private static double db(double power){return power>0?-.691+10*Math.log10(power):UNAVAILABLE;}
    public static double analyze(File pcm,int rate,long frames)throws IOException{
        if(rate<8000||rate>192000||frames<1||frames>Long.MAX_VALUE/4||pcm.length()!=frames*4)throw new IOException("PCM inválido para loudness");
        int hop=rate/10; if(frames<4L*hop)return UNAVAILABLE;
        Biquad sl=shelf(rate),sr=shelf(rate),hl=highpass(rate),hr=highpass(rate);
        double[] recent=new double[4],blocks=new double[1024];int count=0;long hops=frames/hop;
        byte[] buf=new byte[hop*4];double rolling=0;
        try(DataInputStream in=new DataInputStream(new BufferedInputStream(new FileInputStream(pcm),65536))){
            for(long h=0;h<hops;h++){
                if(Thread.currentThread().isInterrupted())throw new InterruptedIOException("Cancelado");
                in.readFully(buf);double sum=0;
                for(int j=0;j<buf.length;j+=4){double l=(short)((buf[j]&255)|(buf[j+1]<<8))/32768.0,r=(short)((buf[j+2]&255)|(buf[j+3]<<8))/32768.0;
                    l=hl.tick(sl.tick(l));r=hr.tick(sr.tick(r));sum+=l*l+r*r;}
                int slot=(int)(h&3);rolling+=sum-recent[slot];recent[slot]=sum;
                if(h>=3){double power=Math.max(0,rolling/(4.0*hop));if(db(power)>=-70){if(count==blocks.length)blocks=Arrays.copyOf(blocks,blocks.length*2);blocks[count++]=power;}}
            }
        }
        if(count==0)return UNAVAILABLE;
        double absoluteSum=0;for(int i=0;i<count;i++)absoluteSum+=blocks[i];double relative=absoluteSum/count*.1;
        double gatedSum=0;int gatedCount=0;for(int i=0;i<count;i++)if(blocks[i]>=relative){gatedSum+=blocks[i];gatedCount++;}
        return gatedCount==0?UNAVAILABLE:db(gatedSum/gatedCount);
    }
}
