#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")/.."
build=$(mktemp -d);trap 'rm -rf "$build"' EXIT
javac -d "$build" app/src/main/java/br/com/edgard/aura/core/{TrackData,StemStorage,LoudnessAnalyzer}.java tests/LoudnessAnalyzerTest.java
java -cp "$build" LoudnessAnalyzerTest
