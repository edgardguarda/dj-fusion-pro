import br.com.edgard.aura.core.*;
import java.io.*;
import java.nio.file.*;
public class LoudnessAnalyzerTest {
    static void check(boolean v,String label){if(!v)throw new AssertionError(label);}
    static File tone(int rate,double amplitude,int silence)throws Exception{
        File f=File.createTempFile("egmix-loudness-",".pcm");f.deleteOnExit();
        try(OutputStream out=new BufferedOutputStream(new FileOutputStream(f))){for(int i=0;i<rate*(4+silence);i++){int s=i<rate*silence?0:(int)Math.round(32767*amplitude*Math.sin(2*Math.PI*1000*i/rate));for(int c=0;c<2;c++){out.write(s&255);out.write(s>>8&255);}}}return f;
    }
    static double measure(File f,int rate)throws Exception{return LoudnessAnalyzer.analyze(f,rate,f.length()/4);}
    public static void main(String[] args)throws Exception{
        if(args.length==2){System.out.printf(java.util.Locale.ROOT,"%.5f%n",measure(new File(args[0]),Integer.parseInt(args[1])));return;}
        for(int rate:new int[]{44100,48000}){
            File a=tone(rate,.1,0),b=tone(rate,.2,0),s=tone(rate,.1,8),z=tone(rate,0,0);
            double l=measure(a,rate),h=measure(b,rate),p=measure(s,rate);
            check(Math.abs(l+20)<.15,"calibration "+l);check(Math.abs(h-l-6.0206)<.02,"6 dB");check(Math.abs(p-l)<.3,"silence gating "+p);check(measure(z,rate)==LoudnessAnalyzer.UNAVAILABLE,"silent");
            TrackData t=new TrackData("tone",a,rate,a.length()/4,120,1,0,.1);t.loudnessVersion=1;t.loudnessLufs=-16;check(t.playbackLevel()==1,"unity");t.loudnessLufs=-30;check(Math.abs(t.playbackLevel()-1.412538)<1e-5,"boost limit");t.loudnessLufs=-6;check(Math.abs(t.playbackLevel()-.501187)<1e-5,"cut limit");t.loudnessLufs=Double.NaN;check(Math.abs(t.playbackLevel()-1.412538)<1e-5,"fallback");
            Thread.currentThread().interrupt();try{measure(a,rate);throw new AssertionError("cancel ignored");}catch(InterruptedIOException expected){}finally{Thread.interrupted();}
            System.out.printf(java.util.Locale.ROOT,"PASS %d Hz: %.3f LUFS; +6dB %.3f; gated %.3f%n",rate,l,h,p);
        }
    }
}
