package br.com.edgard.aura;

import android.content.Context;
import br.com.edgard.aura.core.PcmSamplerBus;
import br.com.edgard.aura.core.CustomJingle;
import java.io.InputStream;
import java.io.ByteArrayOutputStream;
import java.io.IOException;

/** Offline sampler one-shots; no external files, services or network. */
final class PcmSamplerAssets {
    static final String[] KEYS={"vinheta","backspin","tapestop","scratch"};
    private PcmSamplerAssets(){}
    static void load(Context context,PcmSamplerBus bus) throws IOException {
        float[][] result=new float[KEYS.length][],right=new float[KEYS.length][];
        for(int i=0;i<KEYS.length;i++){
            byte[] bytes;
            if(i==0 && CustomJingle.available(context.getFilesDir())){
                try(InputStream in=new java.io.FileInputStream(CustomJingle.file(context.getFilesDir()))){bytes=CustomJingle.read(in);}
                catch(IOException e){bytes=readBundled(context,KEYS[i]);}
            }else{bytes=readBundled(context,KEYS[i]);}
            if(bytes.length<44 || bytes[0]!='R'||bytes[1]!='I'||bytes[2]!='F'||bytes[3]!='F'||
               bytes[8]!='W'||bytes[9]!='A'||bytes[10]!='V'||bytes[11]!='E')
                throw new IOException("Sampler WAV invalid: "+KEYS[i]);
            int ch=0,hz=0,bits=0,format=0,off=-1,length=-1;
            int p=12;
            while(p+8<=bytes.length){
                int size=(bytes[p+4]&255)|((bytes[p+5]&255)<<8)|((bytes[p+6]&255)<<16)|((bytes[p+7]&255)<<24);
                if(size<0||size>bytes.length-(p+8))throw new IOException("Bad RIFF block");
                if(bytes[p]=='f'&&bytes[p+1]=='m'&&bytes[p+2]=='t'&&bytes[p+3]==' '&&size>=16){
                    int start=p+8;
                    format=u16(bytes,start);ch=u16(bytes,start+2);hz=u32(bytes,start+4);bits=u16(bytes,start+14);
                }else if(bytes[p]=='d'&&bytes[p+1]=='a'&&bytes[p+2]=='t'&&bytes[p+3]=='a'){
                    off=p+8;length=size;
                }
                p+=8+size+(size&1);
            }
            if(format!=1||(ch!=1&&ch!=2)||bits!=16||hz<16000||hz>96000||off<0||length<ch*2||length%(ch*2)!=0)
                throw new IOException("Unsupported sampler WAV");
            int frames=length/(ch*2);
            int count=(int)Math.round(frames*(double)PcmSamplerBus.OUTPUT_RATE/hz);
            if(count<=0||count>PcmSamplerBus.OUTPUT_RATE*15)throw new IOException("Sampler length");
            float[] converted=new float[count];
            float[] stereo=ch==2?new float[count]:null;
            for(int j=0;j<count;j++){
                double pos=(double)j*hz/(double)PcmSamplerBus.OUTPUT_RATE;
                int a=Math.min(frames-1,(int)pos),b=Math.min(frames-1,a+1);
                double frac=pos-a;
                converted[j]=(float)((s16(bytes,off+a*ch*2)*(1-frac)+s16(bytes,off+b*ch*2)*frac)/32768.0);
                if(stereo!=null)stereo[j]=(float)((s16(bytes,off+a*4+2)*(1-frac)+s16(bytes,off+b*4+2)*frac)/32768.0);
            }
            result[i]=converted;right[i]=stereo;
        }
        bus.load(result,right);
    }
    private static byte[] readBundled(Context context,String key) throws IOException {
        try(InputStream in=context.getAssets().open("samplers/"+key+".wav")){
            ByteArrayOutputStream data=new ByteArrayOutputStream();byte[] chunk=new byte[8192];int n;
            while((n=in.read(chunk))!=-1){if(data.size()+n>PcmSamplerBus.OUTPUT_RATE*15*4)throw new IOException("Sampler too large");data.write(chunk,0,n);}
            return data.toByteArray();
        }
    }
    private static int u16(byte[] b,int p){return (b[p]&255)|((b[p+1]&255)<<8);}
    private static int u32(byte[] b,int p){return u16(b,p)|(u16(b,p+2)<<16);}
    private static short s16(byte[] b,int p){return (short)u16(b,p);}
}
