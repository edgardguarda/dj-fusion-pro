package br.com.edgard.aura;
import br.com.edgard.aura.core.PcmSamplerBus;
public class RealSamplerAssetsTest {
 public static void main(String[] args)throws Exception {
  java.io.File f=java.nio.file.Files.createTempDirectory("sampler").toFile();
  try {
   PcmSamplerBus bus=new PcmSamplerBus();
   PcmSamplerAssets.load(new android.content.Context(new java.io.File(args[0]),f),bus);
   if(!bus.ready())throw new AssertionError("samplers not ready");
   for(String key:PcmSamplerAssets.KEYS){
    if(!bus.trigger(key,.85))throw new AssertionError(key+" trigger");
    long nonzero=0; double peak=0;
    for(int j=0;j<48000*5;j++){double x=bus.next(),y=bus.right();if(!Double.isFinite(x)||!Double.isFinite(y))throw new AssertionError("bad sample");if(Math.abs(x)+Math.abs(y)>1e-5)nonzero++;peak=Math.max(peak,Math.max(Math.abs(x),Math.abs(y)));}
    if(nonzero<4800||peak<.001||peak>.381)throw new AssertionError(key+" nonzero="+nonzero+" peak="+peak);
    System.out.println("PASS real WAV "+key+" nonzero frames="+nonzero+" peak="+peak);
   }
  }finally{f.delete();}
 }
}
