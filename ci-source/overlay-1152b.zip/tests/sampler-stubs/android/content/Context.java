package android.content;
public class Context {
 private final java.io.File root,files;
 public Context(java.io.File root,java.io.File files){this.root=root;this.files=files;}
 public java.io.File getFilesDir(){return files;}
 public android.content.res.AssetManager getAssets(){return new android.content.res.AssetManager(root);}
}
