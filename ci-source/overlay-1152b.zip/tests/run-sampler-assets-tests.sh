#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")/.."
build=$(mktemp -d); trap 'rm -rf "$build"' EXIT
javac -encoding UTF-8 -d "$build" tests/sampler-stubs/android/content/{Context.java,res/AssetManager.java} app/src/main/java/br/com/edgard/aura/{PcmSamplerAssets.java,core/PcmSamplerBus.java,core/CustomJingle.java} tests/RealSamplerAssetsTest.java
java -cp "$build" br.com.edgard.aura.RealSamplerAssetsTest app/src/main/assets
