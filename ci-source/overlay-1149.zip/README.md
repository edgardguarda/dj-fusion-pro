# EG MIX 11.4.9 — Neural Workflow (beta)

Modelo HTDemucs integrado, quatro stems nativos por deck, preparação privada e exportação opcional. Consulte RELATORIO_11_4_9.md e COMPILAR_APK.md. O pacote completo inclui o modelo exato; a variante CI baixa e valida o modelo. Os relatórios anteriores são históricos. A assinatura de depuração pode variar entre builds.
