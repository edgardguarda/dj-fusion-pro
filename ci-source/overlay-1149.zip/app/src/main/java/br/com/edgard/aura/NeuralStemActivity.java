package br.com.edgard.aura;

import android.app.Activity;
import android.app.ActivityManager;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.provider.DocumentsContract;
import android.view.WindowManager;
import android.widget.*;
import br.com.edgard.aura.core.NeuralStemPipeline;
import br.com.edgard.aura.core.StemPreparationPolicy;
import br.com.edgard.aura.core.TrackData;
import java.io.*;
import java.security.MessageDigest;
import java.util.UUID;
import java.util.concurrent.atomic.AtomicBoolean;
import android.database.Cursor;
import android.provider.OpenableColumns;

/** Private, offline preparation screen. No network permission or audio upload. */
public final class NeuralStemActivity extends Activity {
    private static final int MODEL=901, SONG=902, DEST=903;
    private static final AtomicBoolean BUSY=new AtomicBoolean();
    public static boolean isBusy(){return BUSY.get();}
    private volatile Thread worker;
    private Uri song,destination,modelUri;
    private TextView status,selection;
    private Button start,chooseModel,chooseSong,chooseFolder,download,cancel,storage;
    private ProgressBar progress;
    private CheckBox exportWavs;
    private boolean backPending;
    private File modelFile;
    private boolean bundledModel;
    private static final String MODEL_ASSET="models/htdemucs_fp16weights.onnx";
    @Override public void onCreate(Bundle b){
        super.onCreate(b);
        // Keep the screen awake only while a neural job is active.
        modelFile=new File(getFilesDir(),"htdemucs-fp16weights.onnx");
        try(android.content.res.AssetFileDescriptor descriptor=getAssets().openFd(MODEL_ASSET)){bundledModel=descriptor.getLength()==165612636L;}catch(IOException ignored){bundledModel=false;}
        ScrollView scroll=new ScrollView(this);LinearLayout layout=new LinearLayout(this);layout.setOrientation(LinearLayout.VERTICAL);
        int pad=(int)(20*getResources().getDisplayMetrics().density);layout.setPadding(pad,pad,pad,pad);scroll.addView(layout);
        TextView title=new TextView(this);title.setText("EG MIX • Separação neural");title.setTextSize(24);layout.addView(title);
        TextView info=new TextView(this);info.setText("HTDemucs: vocais, bateria, baixo e outros instrumentos. Processamento local, sem enviar músicas. Prepare antes de tocar. O modelo de 166 MB está integrado. A preparação pode levar vários minutos. Para o Estúdio PCM, você não precisa exportar WAVs.");layout.addView(info);
        download=button(layout,"Obter cópia do modelo oficial (opcional)",()->{try{startActivity(new Intent(Intent.ACTION_VIEW,Uri.parse(OnnxStemModel.DOWNLOAD)));}catch(Exception e){status.setText("Navegador indisponível");}});
        chooseModel=button(layout,"Selecionar modelo ONNX (opcional)",()->pick(MODEL,"*/*"));
        chooseSong=button(layout,"1. Escolher música",()->pick(SONG,"audio/*"));
        exportWavs=new CheckBox(this);exportWavs.setText("Exportar também 5 WAVs para uma pasta");layout.addView(exportWavs);
        chooseFolder=button(layout,"2. Escolher pasta de destino (exportação)",()->{try{startActivityForResult(new Intent(Intent.ACTION_OPEN_DOCUMENT_TREE).addFlags(Intent.FLAG_GRANT_WRITE_URI_PERMISSION|Intent.FLAG_GRANT_READ_URI_PERMISSION),DEST);}catch(Exception e){status.setText("Seletor de pasta indisponível");}});
        storage=button(layout,"Gerenciar stems armazenados",this::manageStorage);
        selection=new TextView(this);layout.addView(selection);
        start=button(layout,"Separar 4 stems",this::begin);
        cancel=button(layout,"Cancelar processamento",()->{Thread w=worker;if(w!=null){w.interrupt();status.setText("Cancelando após o bloco atual…");}});
        progress=new ProgressBar(this,null,android.R.attr.progressBarStyleHorizontal);progress.setMax(100);layout.addView(progress);
        status=new TextView(this);status.setText("Escolha a música. Por padrão, os stems ficam no Estúdio PCM (44,1 kHz). Para outras taxas, marque a exportação WAV.");layout.addView(status);
        exportWavs.setOnCheckedChangeListener((v,checked)->refresh());
        if(b!=null){song=b.getParcelable("song");destination=b.getParcelable("destination");modelUri=b.getParcelable("model");exportWavs.setChecked(b.getBoolean("export",false));}
        setContentView(scroll);refresh();
    }
    private Button button(LinearLayout l,String text,Runnable action){Button b=new Button(this);b.setText(text);b.setMinHeight((int)(48*getResources().getDisplayMetrics().density));b.setOnClickListener(v->action.run());l.addView(b);return b;}
    private void pick(int request,String mime){try{Intent i=new Intent(Intent.ACTION_OPEN_DOCUMENT).addCategory(Intent.CATEGORY_OPENABLE).setType(mime).addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);startActivityForResult(i,request);}catch(Exception e){status.setText("Seletor indisponível");}}
    @Override protected void onActivityResult(int req,int res,Intent data){super.onActivityResult(req,res,data);if(res!=RESULT_OK||data==null||data.getData()==null)return;
        if(req==MODEL)modelUri=data.getData();else if(req==SONG)song=data.getData();else if(req==DEST)destination=data.getData();refresh();}
    private void refresh(){boolean idle=worker==null&&!BUSY.get();for(Button b:new Button[]{chooseModel,chooseSong,download,storage})b.setEnabled(idle);
        exportWavs.setEnabled(idle);chooseFolder.setEnabled(idle&&exportWavs.isChecked());
        start.setEnabled(StemPreparationPolicy.ready(modelUri!=null||modelFile.isFile()||bundledModel,song!=null,exportWavs.isChecked(),destination!=null,idle));cancel.setEnabled(worker!=null);
        if(worker!=null)getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);else getWindow().clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
        selection.setText("Modelo: "+(modelUri!=null?"selecionado, será verificado":modelFile.isFile()?"salvo, será verificado":bundledModel?"integrado no APK":"pendente")+"\nMúsica: "+(song==null?"pendente":displayName(song))+"\nDestino: "+(!exportWavs.isChecked()?"Estúdio PCM (privado)":destination==null?"escolha uma pasta":"Estúdio PCM + WAVs quando compatível")+"\nEspaço livre: "+formatBytes(getFilesDir().getUsableSpace()));}
    private void report(String s,int pct){runOnUiThread(()->{if(!isDestroyed()){status.setText(s);progress.setProgress(pct);}});}
    private void begin(){if(worker!=null)return;if(AudioService.isPlaying()||QuickMixService.isPlaying()){status.setText("Pare a reprodução antes de separar stems.");return;}if(!BUSY.compareAndSet(false,true)){status.setText("Outra separação está terminando. Tente novamente após o encerramento.");return;}final Uri input=song, dest=exportWavs.isChecked()?destination:null, newModel=modelUri;worker=new Thread(()->process(input,dest,newModel),"EG-MIX-neural-stems");worker.setPriority(Thread.MIN_PRIORITY);refresh();worker.start();}
    private void manageStorage(){
        if(BUSY.get())return;
        java.util.List<br.com.edgard.aura.core.StemStorage.Group> groups=br.com.edgard.aura.core.StemStorage.list(getFilesDir());
        if(groups.isEmpty()){new android.app.AlertDialog.Builder(this).setTitle("Stems armazenados").setMessage("Nenhum grupo gerenciável no cache privado.").setPositiveButton("OK",null).show();return;}
        String[] rows=new String[groups.size()];long total=0;for(int i=0;i<rows.length;i++){br.com.edgard.aura.core.StemStorage.Group g=groups.get(i);total+=g.bytes;rows[i]=g.title+" • "+formatBytes(g.bytes)+(g.scheduled?" • exclusão agendada":"");}
        new android.app.AlertDialog.Builder(this).setTitle("Stems privados • "+formatBytes(total)).setItems(rows,(d,i)->{
            br.com.edgard.aura.core.StemStorage.Group g=groups.get(i);
            new android.app.AlertDialog.Builder(this).setTitle(g.title).setMessage(g.scheduled?"Cancelar exclusão agendada?":"Excluir somente os quatro stems privados na próxima inicialização completa do aplicativo? A música original e os WAVs exportados permanecem. A faixa voltará ao master original.")
                .setNegativeButton("Voltar",null).setPositiveButton(g.scheduled?"Cancelar exclusão":"Agendar exclusão",(a,b)->{try{br.com.edgard.aura.core.StemStorage.schedule(getFilesDir(),g.key,!g.scheduled);status.setText(g.scheduled?"Exclusão cancelada.":"Exclusão agendada. Reinicie completamente o aplicativo para liberar espaço.");}catch(IOException e){status.setText("Falha: "+e.getMessage());}manageStorage();}).show();
        }).setNegativeButton("Fechar",null).show();
    }
    private String formatBytes(long n){return android.text.format.Formatter.formatFileSize(this,n);}
    private void verifyModel(File f)throws Exception{
        if(!f.isFile()||f.length()!=165612636L)throw new IOException("Modelo ausente ou tamanho incorreto");
        MessageDigest digest=MessageDigest.getInstance("SHA-256");try(InputStream in=new BufferedInputStream(new FileInputStream(f))){byte[] buf=new byte[65536];int n;while((n=in.read(buf))!=-1){NeuralStemPipeline.checkCancelled();digest.update(buf,0,n);}}
        StringBuilder hex=new StringBuilder();for(byte v:digest.digest())hex.append(String.format(java.util.Locale.ROOT,"%02x",v&255));
        if(!OnnxStemModel.SHA256.contentEquals(hex))throw new IOException("SHA-256 do modelo não corresponde à versão oficial selecionada");
    }
    private void importModel(Uri uri)throws Exception{
        if(uri==null){
            try{verifyModel(modelFile);return;}catch(IOException invalid){if(!bundledModel)throw invalid;}
            report("Preparando modelo integrado (166 MB)…",4);
        }
        if(getFilesDir().getUsableSpace()<165612636L+64L*1024*1024)throw new IOException("Espaço insuficiente para preparar o modelo neural");
        File part=new File(getFilesDir(),"htdemucs-import-"+UUID.randomUUID()+".tmp");
        try{try(InputStream in=uri==null?getAssets().open(MODEL_ASSET,android.content.res.AssetManager.ACCESS_STREAMING):getContentResolver().openInputStream(uri);OutputStream out=new BufferedOutputStream(new FileOutputStream(part))){if(in==null)throw new IOException("Modelo indisponível");byte[] buf=new byte[65536];long length=0;int n;while((n=in.read(buf))!=-1){NeuralStemPipeline.checkCancelled();if((length+=n)>165612636L)throw new IOException("Modelo grande demais");out.write(buf,0,n);}}
            verifyModel(part); // POSIX atomic replacement in the same private directory.
            android.system.Os.rename(part.getAbsolutePath(),modelFile.getAbsolutePath());
        }finally{part.delete();}
    }
    private void process(Uri input,Uri dest,Uri newModel){
        File work=new File(getCacheDir(),"neural-"+UUID.randomUUID());boolean made=false;
        Uri published=null;
        try{
            clearInterruptedJobs();made=work.mkdir();
            if(!made)throw new IOException("Não foi possível criar pasta temporária");
            report("Decodificando música…",3);AudioDecoder.Result pcm=AudioDecoder.decode(this,input,new File(work,"source.pcm"),frames->{if(Thread.currentThread().isInterrupted())throw new IllegalStateException("Cancelado");},1200);
            boolean nativeSupported=StemPreparationPolicy.nativeSupported(pcm.sampleRate);
            if(!nativeSupported&&dest==null)throw new IOException("Esta faixa não é 44,1 kHz. Marque a exportação WAV para usar no mixer clássico.");
            if(nativeSupported&&dest==null&&newModel==null){
                File existing=TrackData.locateStems(getFilesDir(),pcm.file,pcm.sampleRate,pcm.frames);
                if(existing!=null){br.com.edgard.aura.core.StemStorage.schedule(getFilesDir(),existing.getName(),false);runOnUiThread(()->{if(!isDestroyed())setResult(RESULT_OK);});report("Esta faixa já está preparada. Stems reaproveitados no Estúdio PCM.",100);return;}
            }
            report("Verificando modelo neural…",4);importModel(newModel);
            if(newModel!=null)runOnUiThread(()->{if(newModel.equals(modelUri)){modelUri=null;if(!isDestroyed())refresh();}});
            File raw=new File(work,"stems.float"), outputs=new File(work,"wav");
            NeuralStemPipeline.Staging staging;
            try(NeuralStemPipeline.PcmSource source=new NeuralStemPipeline.PcmSource(pcm.file,pcm.sampleRate,pcm.frames)){
                long total=source.outputFrames();if(total>1200L*44100)throw new IOException("Limite: 20 minutos por faixa");
                if(work.getUsableSpace()<StemPreparationPolicy.requiredBytes(total,dest!=null))throw new IOException("Espaço livre insuficiente para separar a faixa");
                ActivityManager manager=(ActivityManager)getSystemService(ACTIVITY_SERVICE);
                if(manager!=null){ActivityManager.MemoryInfo info=new ActivityManager.MemoryInfo();manager.getMemoryInfo(info);if(info.lowMemory)throw new IOException("Pouca memória disponível. Feche outros aplicativos e tente novamente.");}
                report("Carregando rede neural…",4);
                staging=new NeuralStemPipeline.Staging(raw);
                try(NeuralStemPipeline.Staging close=staging;OnnxStemModel net=new OnnxStemModel(modelFile)){NeuralStemPipeline.run(total,NeuralStemPipeline.SEGMENT,NeuralStemPipeline.OVERLAP,source,net,staging,(done,all)->report("Separando quatro canais • "+(done*100/all)+"%",5+(int)(done*85/all)));}
            }
            report("Preparando WAV estéreo 24 bits…",92);String base=outputBase(input);staging.export(outputs,base,dest!=null);
            raw.delete();
            if(dest!=null){
            NeuralStemPipeline.checkCancelled();String id=DocumentsContract.getTreeDocumentId(dest);Uri root=DocumentsContract.buildDocumentUriUsingTree(dest,id);
            published=DocumentsContract.createDocument(getContentResolver(),root,DocumentsContract.Document.MIME_TYPE_DIR,"EG MIX STEMS "+UUID.randomUUID().toString().substring(0,8));
            if(published==null)throw new IOException("Destino não permite criar pasta");
            File[] files=outputs.listFiles();if(files==null||files.length!=5)throw new IOException("Grupo incompleto");
            int saved=0;for(File f:files){report("Salvando arquivos • "+saved+"/5",94+saved);NeuralStemPipeline.checkCancelled();Uri u=DocumentsContract.createDocument(getContentResolver(),published,"audio/wav",f.getName());if(u==null)throw new IOException("Falha ao criar WAV");
                try(InputStream in=new BufferedInputStream(new FileInputStream(f));OutputStream out=getContentResolver().openOutputStream(u,"w")){if(out==null)throw new IOException("Falha ao salvar WAV");byte[] buf=new byte[65536];int n;while((n=in.read(buf))!=-1){NeuralStemPipeline.checkCancelled();out.write(buf,0,n);}}
                saved++;
            }
            NeuralStemPipeline.checkCancelled();published=null;
            }
            if(nativeSupported){try{
                br.com.edgard.aura.core.TrackData.publishStems(getFilesDir(),pcm.file,pcm.frames,outputs,base);
                br.com.edgard.aura.core.StemStorage.schedule(getFilesDir(),TrackData.pcmHash(pcm.file),false);
                runOnUiThread(()->{if(!isDestroyed())setResult(RESULT_OK);});
                report("Concluído: stems disponíveis no Estúdio PCM."+(dest!=null?" WAVs também exportados.":" Sem cópia externa.")+" Volte ao console e inicie o Estúdio PCM com a música original selecionada.",100);
            }catch(IOException cacheError){report((dest!=null?"WAVs exportados; cache nativo não salvo: ":"Falha ao salvar stems privados: ")+cacheError.getMessage(),dest!=null?100:0);}}
            else report("WAVs exportados. Para esta taxa de amostragem, use o mixer clássico.",100);
        }catch(OutOfMemoryError e){report("Memória insuficiente para o modelo neural. Nenhuma separação aprovada.",0);}
        catch(Exception e){report(Thread.currentThread().isInterrupted()?"Separação cancelada.":"Falha: "+e.getMessage(),0);}
        finally{if(published!=null)try{DocumentsContract.deleteDocument(getContentResolver(),published);}catch(Exception ignored){}if(made)clean(work);BUSY.set(false);runOnUiThread(()->{worker=null;if(!isDestroyed()){refresh();if(backPending)finish();}});}
    }
    /** Only the worker holding BUSY may touch these app-private UUID work folders. */
    private void clearInterruptedJobs(){
        File[] entries=getCacheDir().listFiles();if(entries==null)return;
        for(File f:entries)if(f.isDirectory()&&f.getName().matches("neural-[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}"))clean(f);
    }
    private String displayName(Uri uri){
        String name="Musica";
        try(Cursor c=getContentResolver().query(uri,new String[]{OpenableColumns.DISPLAY_NAME},null,null,null)){
            if(c!=null&&c.moveToFirst()&&c.getString(0)!=null)name=c.getString(0);
        }catch(Exception ignored){}
        return name;
    }
    private String outputBase(Uri uri){
        String name=displayName(uri);
        name=name.replaceFirst("\\.[^.]+$","").replaceAll("[^\\p{L}\\p{N} _-]","_").trim();
        if(name.isEmpty())name="Musica";
        if(name.length()>64)name=name.substring(0,64);
        return "EGMIX_"+name+"_"+UUID.randomUUID().toString().substring(0,8);
    }
    private static void clean(File f){File[] files=f.listFiles();if(files!=null)for(File child:files)clean(child);f.delete();}
    @Override protected void onSaveInstanceState(Bundle b){super.onSaveInstanceState(b);b.putParcelable("song",song);b.putParcelable("destination",destination);b.putParcelable("model",modelUri);b.putBoolean("export",exportWavs.isChecked());}
    @Override public void onBackPressed(){if(worker==null){super.onBackPressed();return;}new android.app.AlertDialog.Builder(this).setTitle("Separação em andamento").setMessage("Cancelar a separação e voltar ao console? Os arquivos temporários serão removidos.").setNegativeButton("Continuar",null).setPositiveButton("Cancelar e voltar",(d,w)->{backPending=true;Thread t=worker;if(t!=null)t.interrupt();else finish();status.setText("Cancelando após o bloco atual…");}).show();}
    @Override protected void onDestroy(){Thread w=worker;if(w!=null)w.interrupt();super.onDestroy();}
}
