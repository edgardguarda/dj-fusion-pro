package br.com.edgard.aura.core;

import java.io.*;
import java.nio.*;
import java.util.Arrays;

/** Streaming four-source waveform inference; no filter-based substitute. */
public final class NeuralStemPipeline {
    public static final int RATE=44100, SEGMENT=343980, OVERLAP=SEGMENT/4;
    public static final String[] ROLES={"drums","bass","other","vocals"};
    public interface Source { void read(long start,int count,float[] planar,int stride) throws Exception; }
    public interface Model { float[] predict(float[] planar) throws Exception; }
    public interface Sink { void write(float[] master,float[] stems,int frames,int stride) throws Exception; }
    public interface Progress { void update(long frames,long total) throws Exception; }
    private NeuralStemPipeline(){}
    public static void checkCancelled() throws InterruptedException {
        if(Thread.currentThread().isInterrupted())throw new InterruptedException("Separação cancelada");
    }
    public static void run(long total,int segment,int overlap,Source source,Model model,Sink sink,Progress progress) throws Exception {
        if(total<=0||segment<2||overlap<=0||2*overlap>=segment)throw new IllegalArgumentException("Segmentos inválidos");
        int step=segment-overlap;
        float[] fade=new float[overlap];
        for(int i=0;i<overlap;i++)fade[i]=(float)(.5-.5*Math.cos(Math.PI*(i+.5)/overlap));
        float[] input=new float[2*segment],tail=new float[8*overlap];
        double energy=0,error=0, dot[]=new double[4], stemEnergy[]=new double[4];
        for(long start=0;start<total;start+=step){
            checkCancelled(); Arrays.fill(input,0);
            int count=(int)Math.min(segment,total-start);
            source.read(start,count,input,segment);
            for(float x:input)if(!Float.isFinite(x))throw new IOException("Master inválido");
            float[] result=model.predict(input);
            checkCancelled();
            if(result==null||result.length!=8*segment)throw new IOException("Saída neural incompatível");
            for(float x:result)if(!Float.isFinite(x))throw new IOException("Inferência produziu amostras inválidas");
            if(start!=0){
                int n=Math.min(count,overlap);
                for(int c=0;c<8;c++)for(int i=0;i<n;i++){
                    float w=fade[i];
                    result[c*segment+i]=tail[c*overlap+i]*(1-w)+result[c*segment+i]*w;
                }
            }
            boolean last=start+count==total;
            int emit=last?count:step;
            for(int i=0;i<emit;i++)for(int c=0;c<2;c++){
                double x=input[c*segment+i],sum=0;
                energy+=x*x;
                for(int r=0;r<4;r++){
                    float v=result[(2*r+c)*segment+i]; sum+=v;
                    dot[r]+=x*v;stemEnergy[r]+=(double)v*v;
                }
                double residual=x-sum;error+=residual*residual;
                // Apply mixture consistency to the residual channel, without touching vocals/drums/bass.
                result[(4+c)*segment+i]+=(float)residual;
            }
            if(!last)for(int c=0;c<8;c++)System.arraycopy(result,c*segment+step,tail,c*overlap,overlap);
            sink.write(input,result,emit,segment);
            if(progress!=null)progress.update(start+emit,total);
            if(last)break;
        }
        if(!(energy>1e-9)||!Double.isFinite(error)||Math.sqrt(error/energy)>.35)
            throw new IOException("Master silencioso ou erro de reconstrução neural excessivo");
        int active=0, proportional=0;
        for(int r=0;r<4;r++)if(stemEnergy[r]>energy*.0001){active++;if(Math.abs(dot[r])/Math.sqrt(energy*stemEnergy[r])>.995)proportional++;}
        if(active==0||(active>1&&active==proportional))throw new IOException("Separação degenerada: nenhum canal independente detectado");
    }

    /** Stereo PCM16 on disk; windowed sinc resampling, with anti-alias cutoff for downsampling. */
    public static final class PcmSource implements Source,AutoCloseable {
        private final RandomAccessFile in; private final long frames; private final int rate;
        private static final int RADIUS=24;
        private final int phaseDivisor;
        private final double[][] phases;
        private static int gcd(int a,int b){while(b!=0){int r=a%b;a=b;b=r;}return a;}
        private static double[] weights(double frac,double cutoff){
            double[] w=new double[2*RADIUS];double sum=0;
            for(int k=0;k<w.length;k++){
                double d=frac-(k-RADIUS+1);
                if(Math.abs(d)<RADIUS)w[k]=(Math.abs(d)<1e-9?cutoff:Math.sin(Math.PI*cutoff*d)/(Math.PI*d))*(.5+.5*Math.cos(Math.PI*d/RADIUS));
                sum+=w[k];
            }
            for(int k=0;k<w.length;k++)w[k]/=sum;
            return w;
        }
        public PcmSource(File file,int rate,long frames)throws IOException{
            if(rate<8000||rate>192000||frames<=0||file.length()!=4*frames)throw new IOException("PCM inválido");
            this.rate=rate;this.frames=frames;
            phaseDivisor=gcd(rate,RATE);int phaseCount=RATE/phaseDivisor;
            // Exact rational phases for standard rates; bounded memory for unusual rates.
            phases=rate!=RATE&&phaseCount<=2048?new double[phaseCount][]:null;
            if(phases!=null)for(int i=0;i<phaseCount;i++)phases[i]=weights(i/(double)phaseCount,Math.min(1.,RATE/(double)rate)*.94);
            in=new RandomAccessFile(file,"r");
        }
        public long outputFrames(){return Math.round(frames*(double)RATE/rate);}
        public void read(long start,int count,float[] dst,int stride)throws IOException{
            if(start<0||count<=0||stride<count||dst.length<2L*stride||start>outputFrames()-count)throw new IOException("Intervalo PCM inválido");
            int radius=rate==RATE?0:RADIUS;
            long first=Math.max(0,start*rate/RATE-radius),last=Math.min(frames-1,(start+count-1)*rate/RATE+radius+1);
            byte[] bytes=new byte[Math.toIntExact((last-first+1)*4)];in.seek(first*4);in.readFully(bytes);
            ByteBuffer b=ByteBuffer.wrap(bytes).order(ByteOrder.LITTLE_ENDIAN);
            double cutoff=Math.min(1.,RATE/(double)rate)*.94;
            for(int i=0;i<count;i++){
                if((i&8191)==0&&Thread.currentThread().isInterrupted())throw new InterruptedIOException("Reamostragem cancelada");
                long pos=(start+i)*rate,center=pos/RATE;int rem=(int)(pos%RATE);
                if(radius==0){int off=(int)((center-first)*4);dst[i]=b.getShort(off)/32768f;dst[stride+i]=b.getShort(off+2)/32768f;continue;}
                double[] w=phases==null?weights(rem/(double)RATE,cutoff):phases[rem/phaseDivisor];
                double l=0,r=0;
                for(int k=0;k<w.length;k++){
                    long j=center-radius+1+k,ix=Math.max(0,Math.min(frames-1,j));int off=(int)((ix-first)*4);
                    l+=w[k]*b.getShort(off);r+=w[k]*b.getShort(off+2);
                }
                dst[i]=(float)(l/32768);dst[stride+i]=(float)(r/32768);
            }
        }
        public void close()throws IOException{in.close();}
    }

    /** One interleaved ten-channel staging file; global gain before writing aligned PCM24 WAVs. */
    public static final class Staging implements Sink,AutoCloseable {
        private static final int BLOCK=4096;
        private final File raw;private final DataOutputStream out;private long frames;private float peak;
        private final ByteBuffer block=ByteBuffer.allocate(BLOCK*40);
        private boolean closed;
        public Staging(File raw)throws IOException{this.raw=raw;out=new DataOutputStream(new BufferedOutputStream(new FileOutputStream(raw),1<<20));}
        public void write(float[] master,float[] stems,int n,int stride)throws IOException{
            if(closed||n<=0||stride<n||master.length<2L*stride||stems.length<8L*stride)throw new IOException("Bloco inválido");
            for(int start=0;start<n;start+=BLOCK){
                if(Thread.currentThread().isInterrupted())throw new InterruptedIOException("Gravação cancelada");
                int end=Math.min(n,start+BLOCK);block.clear();
                for(int i=start;i<end;i++)for(int c=0;c<10;c++){
                    float v=c<2?master[c*stride+i]:stems[(c-2)*stride+i];
                    if(!Float.isFinite(v))throw new IOException("Amostra inválida");peak=Math.max(peak,Math.abs(v));block.putFloat(v);
                }
                out.write(block.array(),0,block.position());frames+=end-start;
            }
        }
        public void close()throws IOException{if(!closed){closed=true;out.close();}}
        public void export(File folder,String base)throws Exception{export(folder,base,true);}
        public void export(File folder,String base,boolean includeMaster)throws Exception{
            if(!closed||frames<=0||raw.length()!=frames*40)throw new IOException("Separação incompleta");
            if(!folder.mkdir())throw new IOException("Pasta de saída indisponível");
            float gain=Math.min(1f,.98f/Math.max(peak,1e-12f));
            String[] suffix={"", ".drums", ".bass", ".other", ".vocals"};
            DataOutputStream[] wav=new DataOutputStream[5];
            try(DataInputStream src=new DataInputStream(new BufferedInputStream(new FileInputStream(raw),1<<20))){
                for(int i=includeMaster?0:1;i<5;i++){
                    wav[i]=new DataOutputStream(new BufferedOutputStream(new FileOutputStream(new File(folder,base+suffix[i]+".wav")),65536));
                    header(wav[i],frames);
                }
                byte[][] pcm24=new byte[5][BLOCK*6];
                for(long start=0;start<frames;start+=BLOCK){
                    checkCancelled();int n=(int)Math.min(BLOCK,frames-start);
                    src.readFully(block.array(),0,n*40);block.clear();
                    for(int i=0;i<n;i++)for(int c=0;c<10;c++){
                        int v=Math.round(block.getFloat()*gain*8388607);byte[] dst=pcm24[c/2];int off=i*6+(c%2)*3;
                        dst[off]=(byte)v;dst[off+1]=(byte)(v>>>8);dst[off+2]=(byte)(v>>>16);
                    }
                    for(int j=includeMaster?0:1;j<5;j++)wav[j].write(pcm24[j],0,n*6);
                }
            }finally{IOException failure=null;for(DataOutputStream w:wav)if(w!=null)try{w.close();}catch(IOException e){failure=e;}if(failure!=null)throw failure;}
        }
        private static void le(DataOutputStream o,long n,int bytes)throws IOException{for(int i=0;i<bytes;i++)o.write((int)(n>>>(8*i))&255);}
        private static void header(DataOutputStream o,long frames)throws IOException{
            long bytes=frames*6;if(bytes>0xffffffffL-36)throw new IOException("WAV grande demais");
            o.writeBytes("RIFF");le(o,bytes+36,4);o.writeBytes("WAVEfmt ");le(o,16,4);le(o,1,2);le(o,2,2);le(o,RATE,4);le(o,RATE*6L,4);le(o,6,2);le(o,24,2);o.writeBytes("data");le(o,bytes,4);
        }
    }
}
