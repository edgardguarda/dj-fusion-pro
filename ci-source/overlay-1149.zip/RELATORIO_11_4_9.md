# EG MIX 11.4.9 — Neural Workflow (beta)

Base: fonte 11.4.8 compilada no GitHub (run 45710304331). Mantém o HTDemucs ONNX fixado e as funcionalidades anteriores.

## Mudanças
- Preparação exclusiva para Estúdio PCM sem escolher pasta nem copiar cinco WAVs para fora do aplicativo (originais a 44,1 kHz). Exportação dos cinco WAVs continua disponível como opção; outras taxas exigem exportação para o mixer clássico.
- Reutilização de stems existentes pela identidade SHA-256 do PCM decodificado e validação dos cabeçalhos, sem repetir a inferência no modo privado. Reativação de grupo com exclusão agendada.
- Reserva de armazenamento por modo: 64 ou 84 bytes por quadro após decodificação, mais 256 MiB de margem; não inclui espaço já ocupado pelo PCM ou modelo. Pode variar com o provedor de documentos. Em caso de falha não publica grupo incompleto.
- Tela de separação: nome da música, espaço livre, destino explícito, botão de pasta condicionado à opção, seleção preservada em estado de Activity, confirmação de cancelamento ao voltar, tela ligada somente durante trabalho.
- Tamanho exato do modelo validado antes de SHA-256; não aceita modelo alternativo incompatível.
- VersionCode 1149; workflow usa SDK já instalado no runner, evitando o pacote obsoleto `tools`.

## Validação local
- 62 verificações novas (combinações de controles, taxas aceitas, limites de armazenamento, exportação opcional; quatro WAVs byte a byte iguais aos da exportação completa).
- Pipeline neural simulado, contrato tensorial 12, qualidade numérica 43, mixer PCM 106016, armazenamento 20, sampler 30514, segurança e recursos XML/JS/WAV aprovados. Logs em docs/testes-11.4.9.
- Não foi repetida inferência neural real nesta revisão; modelo e algoritmo de inferência não foram alterados. A UI nativa necessita teste no Android. Separação simultânea à reprodução não implementada. Vinheta paulistana pendente. APK de depuração pode ter certificado diferente da versão anterior; não desinstale sem exportar gravações e stems importantes.
