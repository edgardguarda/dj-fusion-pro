#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")/.."
build=$(mktemp -d); trap 'rm -rf "$build"' EXIT
javac -d "$build" app/src/main/java/br/com/edgard/aura/core/NeuralStemPipeline.java tests/NeuralStemPipelineTest.java app/src/main/java/br/com/edgard/aura/core/NeuralTensorContract.java tests/NeuralTensorContractTest.java tests/NeuralQualityTest.java app/src/main/java/br/com/edgard/aura/core/StemPreparationPolicy.java tests/StemPreparationPolicyTest.java
java -cp "$build" NeuralStemPipelineTest

java -cp "$build" NeuralTensorContractTest

java -cp "$build" NeuralQualityTest

java -cp "$build" StemPreparationPolicyTest
