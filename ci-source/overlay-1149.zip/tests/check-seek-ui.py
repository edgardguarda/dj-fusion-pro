from pathlib import Path
r=Path(__file__).resolve().parent.parent
q=(r/'app/src/main/java/br/com/edgard/aura/QuickMixService.java').read_text()
a=(r/'app/src/main/java/br/com/edgard/aura/MainActivity.java').read_text()
s=(r/'app/src/main/assets/native-ui.js').read_text()
b=(r/'app/build.gradle').read_text()
assert 'SEEK="br.com.edgard.aura.quick.SEEK"' in q
assert 'seekCurrent(positionMs)' in q and 'MediaPlayer.SEEK_CLOSEST' in q
assert 'if(mixing)' in q[q.find('private void seekCurrent'):q.find('private boolean validNextSpeed')]
assert '@JavascriptInterface public void seek(double seconds,int token)' in a
assert "api.seek(Number(seek.value),seekToken)" in s
assert 'seek.disabled=!seekCanPlay' in s
assert 'v.pcmCanSeek' in s and 'api.seekPcm' in s
assert "seek.title=seekCanPlay" in s
assert 'versionCode 1149' in b
print('PASS EG MIX native seek safety and UI regression: 9 checks')
