import br.com.edgard.aura.core.*;
import java.io.*;
import java.nio.file.*;
public class NativeStemDeckTest {
 static int checks; static void ok(boolean b,String m){checks++;if(!b)throw new AssertionError(m);}
 static void le(DataOutputStream o,long n,int bytes)throws IOException{for(int i=0;i<bytes;i++)o.write((int)(n>>>(i*8))&255);}
 static final int N=100000;
 static int sample(int i,int role,int ch){return (int)(Math.sin(i*(.017+role*.009)+ch*.37)*(600+role*400));}
 static void wav(File f,int role)throws IOException{try(DataOutputStream o=new DataOutputStream(new BufferedOutputStream(new FileOutputStream(f)))){o.writeBytes("RIFF");le(o,N*6+36,4);o.writeBytes("WAVEfmt ");le(o,16,4);le(o,1,2);le(o,2,2);le(o,44100,4);le(o,264600,4);le(o,6,2);le(o,24,2);o.writeBytes("data");le(o,N*6,4);for(int i=0;i<N;i++)for(int ch=0;ch<2;ch++)le(o,sample(i,role,ch)*256,3);}}
 static TrackData track(File f){return new TrackData("fixture",f,44100,N,120,.8,0,.2);}
 static void next(BufferedPcmDeck d,float[] out)throws Exception{long deadline=System.nanoTime()+2_000_000_000L;while(!d.next(out)){if(d.hasFailed()||System.nanoTime()>deadline)throw new IOException("deck stalled",d.error);Thread.sleep(1);}}
 static void eq(float a,float b,String m){ok(Math.abs(a-b)<.000003,m+" "+a+" "+b);}
 public static void main(String[] args)throws Exception{
  Path root=Files.createTempDirectory("native-stems-test");File dir=root.toFile(), pcm=new File(dir,"source.pcm"),export=new File(dir,"export");export.mkdir();
  try{try(DataOutputStream o=new DataOutputStream(new BufferedOutputStream(new FileOutputStream(pcm)))){for(int i=0;i<N;i++)for(int ch=0;ch<2;ch++){int v=0;for(int k=0;k<4;k++)v+=sample(i,k,ch);le(o,v,2);}}
   for(int k=0;k<4;k++)wav(new File(export,"track."+TrackData.STEM_NAMES[k]+".wav"),k);
   TrackData.publishStems(dir,pcm,N,export,"track");File pack=TrackData.locateStems(dir,pcm,44100,N);ok(pack!=null,"published group");ok(TrackData.locateStems(dir,pcm,48000,N)==null,"rate mismatch");
   TrackData a=track(pcm),b=track(pcm),original=track(pcm);a.attachStems(pack);b.attachStems(pack);ok(a.stemToken!=b.stemToken,"unique identity");
   // Linear and WSOLA must produce the same mix as the original for aligned unity stems.
   for(boolean stretch:new boolean[]{false,true}){a.setStemPreset(15);b.setStemPreset(15);try(BufferedPcmDeck da=new BufferedPcmDeck(a,48000,stretch?1.04:1,.17,stretch);BufferedPcmDeck ref=new BufferedPcmDeck(original,48000,stretch?1.04:1,.17,stretch);BufferedPcmDeck db=new BufferedPcmDeck(b,48000,1,.17,false)){
      ok(da.awaitPrimed(3000)&&ref.awaitPrimed(3000)&&db.awaitPrimed(3000),"prime");float[] x=new float[2],y=new float[2],z=new float[2];
      for(int i=0;i<25000;i++){next(da,x);next(ref,y);eq(x[0],y[0],"unity L");eq(x[1],y[1],"unity R");}
      a.setStemPreset(0);for(int i=0;i<1500;i++)next(da,x);eq(x[0],0,"mute L");eq(x[1],0,"mute R");ok(b.stemGains()==0x64646464,"other deck unaffected");next(db,z);ok(Math.abs(z[0])+Math.abs(z[1])>0,"other deck audible");
   }}
   a.setStemPreset(8);try(BufferedPcmDeck d=new BufferedPcmDeck(a,44100,1,0)){ok(d.awaitPrimed(3000),"seek replacement primed");float[] v=new float[2];for(int i=0;i<3000;i++){next(d,v);eq(v[0],sample(i,3,0)/32768f,"vocal L");eq(v[1],sample(i,3,1)/32768f,"vocal R");}}
   // Automatic vocal transition must not modify manual gains or mute other roles.
   a.setStemPreset(15);b.setStemPreset(15);
   try(BufferedPcmDeck da=new BufferedPcmDeck(a,44100,1,0);BufferedPcmDeck db=new BufferedPcmDeck(b,44100,1,0)){
      ok(da.awaitPrimed(3000)&&db.awaitPrimed(3000),"neural blend primed");
      float[] x=new float[2],y=new float[2];
      for(int i=0;i<5000;i++){
         ok(da.next(x,0),"outgoing available");ok(db.next(y,1),"incoming available");
         if(i>=1200)for(int ch=0;ch<2;ch++){int sum=0;for(int k=0;k<3;k++)sum+=sample(i,k,ch);eq(x[ch],sum/32768f,"vocals attenuated only");eq(y[ch],(sum+sample(i,3,ch))/32768f,"incoming unchanged");}
      }
      ok(a.stemGains()==0x64646464&&b.stemGains()==0x64646464,"manual gains preserved");
      for(int i=5000;i<7500;i++){ok(da.next(x),"restored audio");if(i>=6200)for(int ch=0;ch<2;ch++){int sum=0;for(int k=0;k<4;k++)sum+=sample(i,k,ch);eq(x[ch],sum/32768f,"automatic attenuation released");}}
   }
   ok(BufferedPcmDeck.levelForRms(.16)==1,"unity trim");ok(BufferedPcmDeck.levelForRms(.001)==1,"silence no boost");ok(BufferedPcmDeck.levelForRms(Double.NaN)==1,"invalid rms");
   ok(BufferedPcmDeck.levelForRms(.04)<=1.413&&BufferedPcmDeck.levelForRms(.8)>=.501,"bounded level");
   for(int i=0;i<=10000;i++){double t=i/10000.;float g1=BufferedPcmDeck.autoVocalGain(false,t),g2=BufferedPcmDeck.autoVocalGain(true,t);ok(g1>=0&&g1<=1&&g2>=0&&g2<=1&&g1*g2==0,"no competing vocal gains");}
   a.setStemPreset(8);
   a.setStemGain(-1,100);a.setStemGain(0,101);ok(a.stemGains()==0x64000000,"bad commands ignored");
   File bad=new File(pack,"drums.wav");try(RandomAccessFile f=new RandomAccessFile(bad,"rw")){f.setLength(f.length()-6);}try{TrackData.validateStems(pack,N);throw new AssertionError("truncated accepted");}catch(IOException expected){checks++;}
   System.out.println("PASS NativeStemDeckTest: "+checks+" checks (synthetic aligned PCM24, linear/WSOLA, independent deck, mute, seek, validation)");
  }finally{try(java.util.stream.Stream<Path> paths=Files.walk(root)){paths.sorted(java.util.Comparator.reverseOrder()).forEach(p->p.toFile().delete());}}
 }
}
