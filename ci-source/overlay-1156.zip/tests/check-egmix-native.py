from pathlib import Path
import re, wave, math, xml.etree.ElementTree as ET
root=Path(__file__).resolve().parent.parent
assets=root/'app/src/main/assets'
service=(root/'app/src/main/java/br/com/edgard/aura/AudioService.java').read_text()
activity=(root/'app/src/main/java/br/com/edgard/aura/MainActivity.java').read_text()
js=(assets/'native-ui.js').read_text()
manifest=ET.parse(root/'app/src/main/AndroidManifest.xml').getroot()
app=manifest.find('application')
ns='{http://schemas.android.com/apk/res/android}'
assert app.attrib[ns+'label']=='EG MIX'
assert app.attrib[ns+'icon']=='@mipmap/ic_launcher'
assert 'versionCode 1156' in (root/'app/build.gradle').read_text()
assert 'SAMPLER.equals(intent.getAction())' in service
assert 'samplerBus.next()' in service
assert service.index('samplerBus.next()') < service.index('masterLimiter.process(dc[0],dc[1],vm)')
assert 'public void sampler(String key,double volume)' in activity
assert "api.sampler(key," in js
assert 'body.aura10-native .sampler-pads{display:grid!important' in js
assert 'display:none!important' not in js[js.index('body.aura10-native .sampler-pads{display:grid!important'):][:130]
assert 'Separar com IA' in js and 'api.neuralStems()' in js and 'Sem stems' in js
for key in ['vinheta','backspin','tapestop','scratch']:
    wav=assets/'samplers'/f'{key}.wav'
    with wave.open(str(wav),'rb') as w:
        assert w.getnchannels()==1 and w.getsampwidth()==2 and w.getframerate()>=16000
        assert .3<w.getnframes()/w.getframerate()<15
print('PASS Native EG MIX static/asset regression: 18+ assertions')
