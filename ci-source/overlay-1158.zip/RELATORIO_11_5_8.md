# EG MIX 11.5.8 — Unified Live (beta)
- Um único transporte PCM na interface Android. A rota clássica serve o console nativo e o alias rápido chama PCM. O código legado é preservado, não migrado integralmente.
- Separação HTDemucs pode ocorrer com PCM ativo: worker de baixa prioridade, ORT intra-op 1, verificação de memória, temperatura e underruns entre blocos. A proteção é cooperativa e não garante que um bloco não cause atraso ou OOM. Cancelamento após o bloco atual.
- Voltar ao console sem cancelar enquanto PCM está ativo. Indicador de progresso e cancelamento. Stems publicados de forma atômica; novos decks podem receber stems verificados no worker. Decks já carregados continuam intactos. Cache recarregado em nova sessão.
- Console diferenciado por deck, IA explícita, atalhos duplicados removidos. Ferramentas clássicas de pré-escuta e edição manual ainda não migradas.
- Validação real da inferência concorrente em ARM64 e homologação física não realizadas. Testes Android de interface/PCM não equivalem à inferência neural durante reprodução.
