package br.com.edgard.aura.core;
/** Conservative cooperative guard. Checked between model invocations, not an OOM guarantee. */
public final class LiveNeuralGuard {
    public static final long MIN_LIVE_FREE=1024L*1024*1024;
    private boolean wasPlaying;
    private int baseline;
    public String check(boolean playing,boolean lowMemory,long available,int thermal,int underruns){
        if(lowMemory)return "Memória insuficiente";
        if(thermal>=3)return "Temperatura elevada";
        if(!playing){wasPlaying=false;return null;}
        if(available<MIN_LIVE_FREE)return "Memória livre insuficiente para IA simultânea";
        if(!wasPlaying||underruns<baseline){baseline=underruns;wasPlaying=true;}
        if((long)underruns-baseline>=3)return "Saída de áudio sob pressão";
        return null;
    }
}
