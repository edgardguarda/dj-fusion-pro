package br.com.edgard.aura;

import ai.onnxruntime.*;
import br.com.edgard.aura.core.NeuralStemPipeline;
import java.io.*;
import java.nio.FloatBuffer;
import java.util.*;

/** Pinned StemSplit HTDemucs export, CPU execution, fixed waveform contract. */
final class OnnxStemModel implements NeuralStemPipeline.Model,AutoCloseable {
    static final String SHA256="d05c269d0178d2a72ad484b10b11dd370193fc923201c3b27a99f848745db70a";
    static final String DOWNLOAD="https://huggingface.co/StemSplitio/htdemucs-onnx/resolve/d54ed9eb60e258ea82131c6ee14578628816456a/htdemucs_fp16weights.onnx";
    private final OrtEnvironment env=OrtEnvironment.getEnvironment();
    private final OrtSession session;
    private final OrtSession.SessionOptions options;
    private static final int N=NeuralStemPipeline.SEGMENT;
    OnnxStemModel(File model)throws Exception{
        options=new OrtSession.SessionOptions();
        OrtSession opened=null;
        try{
            // One worker also when playback starts after the model is loaded.
            options.setIntraOpNumThreads(1);
            options.setInterOpNumThreads(1);
            // Avoid expensive graph folding and large persistent allocation arenas on mobile.
            options.setOptimizationLevel(OrtSession.SessionOptions.OptLevel.NO_OPT);
            options.setMemoryPatternOptimization(false);
            options.setCPUArenaAllocator(false);
            opened=env.createSession(model.getAbsolutePath(),options);
            verify(opened.getInputInfo(),"mix",new long[]{1,2,N},false);
            verify(opened.getOutputInfo(),"stems",new long[]{1,4,2,N},true);
            session=opened;
        }catch(Exception|Error e){try{if(opened!=null)opened.close();}finally{options.close();}throw e;}
    }
    private static void verify(Map<String,NodeInfo> info,String name,long[] shape,boolean symbolic)throws IOException{
        NodeInfo node=info.get(name);
        if(node==null||!(node.getInfo() instanceof TensorInfo))throw new IOException("Tensor ausente: "+name);
        TensorInfo t=(TensorInfo)node.getInfo();long[] actual=t.getShape();
        if(t.type!=OnnxJavaType.FLOAT||actual.length!=shape.length)throw new IOException("Tipo neural incompatível");
        br.com.edgard.aura.core.NeuralTensorContract.verifyShape(actual,shape,symbolic);
    }
    public float[] predict(float[] input)throws Exception{
        try(OnnxTensor tensor=OnnxTensor.createTensor(env,FloatBuffer.wrap(input),new long[]{1,2,N});
            OrtSession.Result result=session.run(Collections.singletonMap("mix",tensor))){
            OnnxValue val=result.get("stems").orElseThrow(()->new IOException("Saída stems ausente"));
            if(!(val instanceof OnnxTensor))throw new IOException("Saída neural inválida");
            OnnxTensor output=(OnnxTensor)val;
            TensorInfo actual=output.getInfo();
            if(actual.type!=OnnxJavaType.FLOAT)throw new IOException("Tipo de saída neural inválido");
            br.com.edgard.aura.core.NeuralTensorContract.verifyShape(actual.getShape(),new long[]{1,4,2,N},false);
            FloatBuffer b=output.getFloatBuffer();
            if(b==null||b.remaining()!=8*N)throw new IOException("Tamanho de saída inválido");
            float[] out=new float[8*N];b.get(out);return out;
        }
    }
    public void close()throws OrtException{try{session.close();}finally{options.close();}}
}
