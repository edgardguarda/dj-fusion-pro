package br.com.edgard.aura.core;

import java.util.concurrent.ArrayBlockingQueue;
import java.util.concurrent.atomic.AtomicReference;
import java.util.concurrent.atomic.AtomicLong;

/**
 * Single-worker handoff planner. No large ring allocation, disk opening or
 * BufferedPcmDeck thread creation occurs on AudioTrack's render thread.
 *
 * Only the audio thread calls request/take/cancel. The worker publishes an
 * immutable result; superseded decks are closed before they can be consumed.
 */
public final class AsyncDeckPreparer implements AutoCloseable {
    public static final class Result {
        public final long generation;
        public final TrackData current, next;
        public final TrackPlanner.Handoff handoff;
        public final BufferedPcmDeck deck;
        public final Throwable error;
        private Result(long generation,TrackData current,TrackData next,
                       TrackPlanner.Handoff handoff,BufferedPcmDeck deck,Throwable error){
            this.generation=generation;this.current=current;this.next=next;
            this.handoff=handoff;this.deck=deck;this.error=error;
        }
        public void discard(){if(deck!=null)deck.close();}
    }
    private static final class Request {
        final long generation;
        final TrackData current,next;
        final double rate;
        final int beats;
        final double seekSeconds;
        Request(long gen,TrackData a,TrackData b,double speed,int beats,double seekSeconds){
            generation=gen;current=a;next=b;rate=speed;this.beats=beats;this.seekSeconds=seekSeconds;
        }
    }
    private final int outputRate;
    private final java.io.File stemRoot;
    private final ArrayBlockingQueue<Request> queue=new ArrayBlockingQueue<>(1);
    private final AtomicReference<Result> ready=new AtomicReference<>();
    private final Thread worker;
    private volatile long generation;
    private volatile boolean stopped;
    private final AtomicLong pendingGeneration = new AtomicLong(-1);
    public AsyncDeckPreparer(int outputRate){this(outputRate,null);}
    public AsyncDeckPreparer(int outputRate,java.io.File stemRoot){
        this.stemRoot=stemRoot;
        if(outputRate<=0)throw new IllegalArgumentException("output rate");
        this.outputRate=outputRate;
        worker=new Thread(this::work,"AURA-PCM-handoff-prepare");
        worker.setDaemon(true);worker.start();
    }
    /** Renderer-only: constant-time enqueue, no disk or new audio buffers. */
    public void request(TrackData current,TrackData next,double rate,int beats){
        if(stopped||current==null||next==null)throw new IllegalStateException("preparer inactive");
        enqueue(current,next,rate,beats,-1);
    }
    /** Use a separate preparer for manual seeks; preserve the old deck until ready. */
    public void requestSeek(TrackData track,double rate,double seconds){
        if(stopped||track==null||!Double.isFinite(seconds)||seconds<0)throw new IllegalArgumentException("seek");
        enqueue(track,track,rate,0,Math.min(seconds,Math.max(0,track.duration()-.65)));
    }
    private void enqueue(TrackData current,TrackData next,double rate,int beats,double seekSeconds){
        long gen=++generation;
        pendingGeneration.set(gen);
        Result old=ready.getAndSet(null);
        if(old!=null)old.discard();
        queue.clear();
        if(!queue.offer(new Request(gen,current,next,rate,beats,seekSeconds))){
            pendingGeneration.compareAndSet(gen,-1);
            throw new IllegalStateException("handoff preparation queue full");
        }
        worker.interrupt();
    }
    private void work(){
        while(!stopped){
            Request request;
            try{request=queue.take();}catch(InterruptedException e){continue;}
            BufferedPcmDeck deck=null;
            TrackPlanner.Handoff handoff=null;
            Throwable failure=null;
            try{
                if(request.seekSeconds>=0){
                    // Manual seek uses the existing tempo, including pitch preservation when needed.
                    deck=new BufferedPcmDeck(request.current,outputRate,request.rate,request.seekSeconds,
                            request.rate>=.94 && request.rate<=1.06 && Math.abs(request.rate-1)>.00001);
                }else{
                    try{request.next.attachNewlyPublishedStems(stemRoot);}catch(java.io.IOException|IllegalArgumentException ignored){}
                    handoff=TrackPlanner.plan(request.current,request.next,request.rate,request.beats);
                    deck=new BufferedPcmDeck(request.next,outputRate,handoff.rateNext,
                            handoff.cueBSeconds,handoff.beatmatch);
                }
            }catch(Throwable e){failure=e;}
            if(stopped||request.generation!=generation){
                if(deck!=null)deck.close();
                continue;
            }
            Result result=new Result(request.generation,request.current,request.next,handoff,deck,failure);
            Result previous=ready.getAndSet(result);
            if(previous!=null)previous.discard();
            // A newer request can arrive between the generation check and
            // publication. Never clear that newer request's pending state.
            if(stopped || request.generation!=generation){
                if(ready.compareAndSet(result,null))result.discard();
            }
            pendingGeneration.compareAndSet(request.generation,-1);
        }
    }
    /** Renderer-only; no wait and no filesystem access. */
    public Result take(){
        Result result=ready.getAndSet(null);
        if(result!=null && (stopped || result.generation!=generation)){
            result.discard();return null;
        }
        return result;
    }
    public boolean pending(){return pendingGeneration.get()==generation;}
    /** A published result is not a new request; don't discard it from a refresh tick. */
    public boolean hasReady(){
        Result result=ready.get();
        return result!=null && !stopped && result.generation==generation;
    }
    public void cancel(){
        ++generation;
        pendingGeneration.set(-1);
        queue.clear();
        Result previous=ready.getAndSet(null);
        if(previous!=null)previous.discard();
    }
    @Override public void close(){stopped=true;cancel();worker.interrupt();}
}
