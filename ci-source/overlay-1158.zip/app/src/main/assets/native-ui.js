/* AURA 11 Android host. The original UI stays in the APK;
 * native mode owns file selection, preparation and audio transport. */
(function () {
 'use strict';
 if (window.__AURA10_ATTACHED) return;
 window.__AURA10_ATTACHED = true;
 const api = window.AURA_ANDROID;
 if (!api || typeof api.snapshot !== 'function') return;
 const $ = (id) => document.getElementById(id);
 const escape = (s) => String(s ?? '').replace(/[&<>"']/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
 const fmt = (v) => {const n=Math.max(0,Math.floor(Number(v)||0));return `${Math.floor(n/60)}:${String(n%60).padStart(2,'0')}`;};
 const css = document.createElement('style');
 css.textContent = `
  #aura10-native-controller{background:#0c2519;border:1px solid #287f53;border-radius:12px;padding:8px;display:grid;gap:5px;font:12px/1.35 system-ui;color:#e1f7e9}
  #aura10-native-controller .head{display:flex;justify-content:space-between;align-items:center;gap:8px;min-height:34px}
  #aura10-native-controller .head button{min-height:30px;padding:4px 8px;font-size:11px}
  #aura10-native-controller .detail{display:none;gap:5px;grid-template-columns:repeat(3,minmax(0,1fr))}
  #aura10-native-controller.open .detail{display:grid}
  #aura10-native-controller .detail button{min-width:0;min-height:37px;padding:4px 5px;font-size:11px;white-space:normal}
  #aura10-state{color:#a7e7c2;overflow-wrap:anywhere;font-size:11px}
  #aura10-native-tracklist{overflow:auto;min-height:0;overscroll-behavior:contain}
  #aura10-native-tracklist .entry{padding:7px 6px;display:grid;grid-template-columns:22px minmax(0,1fr) auto;align-items:center;gap:7px;border-bottom:1px solid #31513f}
  #aura10-native-tracklist .entry.on{background:#174c30;border-radius:8px}
  #aura10-native-tracklist .entry b{overflow:hidden;text-overflow:ellipsis;white-space:nowrap;font-size:12px}
  #aura10-native-tracklist .entry small{color:#a6b9ae;white-space:nowrap}
  body.aura10-native #tracks,body.aura10-native #libraryPanel>.pager{display:none!important}
  body.aura10-native #libraryPanel #openLocalIA,body.aura10-native #libraryPanel #portableBanner{display:none!important}
  body.aura10-native #libraryPanel{grid-template-rows:auto minmax(0,1fr)!important}
  body.aura10-native #aura10-native-tracklist{display:block}
  body:not(.aura10-native) #aura10-native-tracklist{display:none}
  body.aura10-native #quickIAStatus{opacity:.7}
  body.aura10-native #aura10-native-controller{display:grid}
  body:not(.aura10-native) #aura10-native-controller{display:none}
  body.aura10-native #onSection,body.aura10-native #nextSection{opacity:.7}
  /* The compact Android library must not act as a tall, non-scrollable pane. */
  @media(max-width:819px),(pointer:coarse){
    body.aura10-native .wrap{scroll-behavior:smooth;touch-action:pan-y;overscroll-behavior-y:auto}
    body.aura10-native .workspace{height:auto!important;min-height:0!important;
      overflow:visible!important;display:flex;flex-direction:column}
    body.aura10-native #libraryPanel{overflow:visible!important;min-height:0!important;
      display:flex!important;flex-direction:column;gap:8px}
    body.aura10-native #aura10-native-tracklist{overflow:visible!important;min-height:0!important;
      max-height:none!important;touch-action:pan-y}
    body.aura10-native #aura10-native-tracklist .empty{height:auto;min-height:185px;
      padding:16px 12px;justify-content:center;gap:12px}
    body.aura10-native #aura10-native-tracklist .empty button{min-height:44px;
      border-color:#31aa6c;background:#194c32;color:#e9fff1}
    body.aura10-native .performance,body.aura10-native .workspace,body.aura10-native .library{touch-action:pan-y}
    body.aura10-native .statusbar{position:relative}
  }
  body.aura10-native .aura-native-audio-note{margin:5px 0;color:#b9cdbf;font-size:11px;line-height:1.4}
  /* Sampler pads run against the real native bridge; stems are explicit until separated. */
  body.aura10-native .stem-grid{display:none!important}
  body.aura10-native .sampler-panel{display:grid!important}
  body.aura10-native .sampler-pads{display:grid!important;grid-template-columns:repeat(2,minmax(0,1fr));gap:8px}
  body.aura10-native .sampler-pads button{min-height:56px;touch-action:manipulation}
  body.aura10-native .sampler-pads button[aria-pressed=true]{background:#2b8b5b!important;color:white;border-color:#90ffc4}
  body.aura10-native .workspace{overscroll-behavior-y:auto}
  body.aura10-native #aura10-native-tracklist .empty{min-height:150px}
  @media(max-width:420px){body.aura10-native .sampler-pads{grid-template-columns:repeat(2,minmax(0,1fr))}}
  body.aura10-native .djfx-panel::after{content:"Efeitos de timbre e de ritmo atuam no master PCM; ritmo exige BPM confiável.";
    display:block;color:#b9cdbf;font-size:11px;line-height:1.4;padding:7px 3px}
  body.aura10-native .stem-panel::after{content:"Prepare a música original com HTDemucs. O Estúdio PCM reconhece o cache de stems de faixas de 44,1 ou 48 kHz; o clássico aceita os WAVs exportados.";
    display:block;color:#a4c7b4;font-size:11px;line-height:1.45;padding:4px}
  body.aura10-native [data-fx-group="rhythm"]:disabled{opacity:.65}
  body.aura10-native [data-djfx]:not(:disabled)[aria-pressed=true]{
    background:#e5b57c!important;color:#1c1a13!important;border:2px solid #fff3d0!important}
  body.aura10-native .djfx-head input[type=range]{min-width:55px;width:clamp(55px,15vw,130px)}
  body.aura10-native :is(button,select,input):focus-visible{outline:2px solid #8effbc;outline-offset:2px}

  /* 11.3.9 · EG MIX console: accessible controls, honest native telemetry. */
  body.aura10-native{color:#eaf5ef;accent-color:#76e2a4}
  body.aura10-native .wrap{gap:12px;padding:10px;scroll-behavior:auto}
  body.aura10-native .top{background:#10251b;border:1px solid #355c47;padding:10px;border-radius:14px}
  body.aura10-native .brand{font-size:23px;letter-spacing:1px}
  body.aura10-native .subbrand{font-size:10px;color:#b5d7c2}
  body.aura10-native .performance,body.aura10-native .controls{gap:10px}
  body.aura10-native .deck-panels{gap:8px}
  body.aura10-native .deck{padding:12px 10px!important;border-radius:12px;border:1px solid #3b6550;background:#102219;min-width:0;box-shadow:none}
  body.aura10-native .deck-next{border-color:#786449;background:#24241b}
  body.aura10-native .deck-label{font-size:12px;letter-spacing:.5px}
  body.aura10-native .track-name{font-size:clamp(15px,3.9vw,22px);font-weight:750;line-height:1.25;min-height:2.5em;white-space:normal;overflow-wrap:anywhere;display:-webkit-box;-webkit-line-clamp:2;-webkit-box-orient:vertical;overflow:hidden}
  body.aura10-native .tempo-number{font-size:clamp(14px,3.6vw,20px);font-variant-numeric:tabular-nums;line-height:1.2}
  body.aura10-native .semantic-section,body.aura10-native .deck-foot{font-size:11px;color:#bdcfc4;line-height:1.35;white-space:normal;overflow-wrap:anywhere}
  body.aura10-native .info-line{font-size:12px;font-variant-numeric:tabular-nums}
  body.aura10-native .wave,body.aura10-native .mix-visual,body.aura10-native .plan-line,body.aura10-native #recover{display:none!important}
  body.aura10-native .control-row{gap:6px;grid-template-columns:repeat(4,minmax(0,1fr))}
  body.aura10-native .control-row button{min-height:48px!important;font-size:12px!important;border-radius:10px;white-space:normal}
  body.aura10-native button:disabled{opacity:1;cursor:not-allowed;background:#203029!important;color:#91a99a!important;border-color:#3b5346!important;box-shadow:none!important}
  body.aura10-native .seek-row{padding:6px 2px;gap:8px;min-height:48px;font-size:12px}
  body.aura10-native input[type=range]{min-height:36px;touch-action:pan-x!important}
  body.aura10-native .mix-row{grid-template-columns:repeat(2,minmax(0,1fr));gap:8px}
  body.aura10-native .mix-row select{min-height:44px!important;font-size:13px!important}
  body.aura10-native #aura10-native-controller{border-radius:12px;padding:12px;gap:9px;background:#102219;border-color:#3b6550}
  body.aura10-native #aura10-native-controller .head button,body.aura10-native #aura10-native-controller .detail button{min-height:44px;font-size:12px}
  body.aura10-native #aura10-state{font-size:13px;color:#d2e8db}
  body.aura10-native #eg-mode-row{display:flex;flex-wrap:wrap;gap:6px;align-items:center}
  body.aura10-native #eg-mode-label{font-size:11px;font-weight:700;letter-spacing:.4px;background:#254b35;color:#d9fce6;border-radius:6px;padding:6px 9px}
  body.aura10-native #eg-mode-info{font-size:12px;line-height:1.4;color:#c5d5ca;flex:1;min-width:140px}
  body.aura10-native #eg-studio-shortcut{min-height:44px;font-size:12px;width:100%;border-radius:8px}
  body.aura10-native #eg-transition{font-size:12px;line-height:1.4;color:#d6e8da;overflow-wrap:anywhere}
  body.aura10-native #eg-meter{display:grid;grid-template-columns:auto minmax(40px,1fr) auto;gap:8px;align-items:center;font-size:11px;color:#c8dbce}
  body.aura10-native #eg-meter progress{width:100%;height:9px;accent-color:#7ce6a6}
  body.aura10-native #eg-meter[hidden]{display:none}
  body.aura10-native #masterMeter{display:none!important}
  body.aura10-native .sampler-panel,body.aura10-native .djfx-panel,body.aura10-native .stem-panel{padding:10px;gap:8px;border-radius:12px;box-shadow:none}
  body.aura10-native .sampler-pads button{min-height:62px;font-size:13px;border-radius:10px;background:#1b3d2b}
  body.aura10-native .sampler-pads small,body.aura10-native .aura-native-audio-note{font-size:12px;line-height:1.35}
  body.aura10-native .djfx-pads button{min-height:48px;font-size:12px;border-radius:8px}
  body.aura10-native .stem-panel small,body.aura10-native .djfx-panel small{font-size:12px;line-height:1.4}
  body.aura10-native .stem-head button{min-height:44px;font-size:12px}
  body.aura10-native #eg-library-tools{display:flex;gap:8px;align-items:center;flex-wrap:wrap}
  body.aura10-native #eg-library-tools input{flex:1;min-width:140px;width:100%;height:44px;padding:8px 12px;border-radius:9px;background:#0d1e16;border:1px solid #557661;color:#eff9f1;font:14px system-ui}
  body.aura10-native #eg-library-count{font-size:12px;color:#c2d7c8}
  body.aura10-native #aura10-native-tracklist .entry{min-height:48px;padding:9px 8px;grid-template-columns:24px minmax(0,1fr);gap:2px 8px}
  body.aura10-native #aura10-native-tracklist .entry b{font-size:14px}
  body.aura10-native #aura10-native-tracklist .entry small:last-child{grid-column:2;font-size:12px;white-space:normal}
  body.aura10-native #aura10-native-tracklist .entry.on{border-left:3px solid #8eeeb3}
  body.aura10-native .tabs button,body.aura10-native .panel-head button,body.aura10-native #drop{min-height:44px;font-size:12px}
  body.aura10-native .eg-native-help{padding:14px;display:grid;gap:10px;font:14px/1.5 system-ui;color:#d8e8df}
  body.aura10-native .eg-native-help button{min-height:44px;white-space:normal}
  body.aura10-native .eg-native-help h2{font-size:16px;margin:0}
  body.aura10-native .eg-native-help p{margin:0}
  body.aura10-native #status{font-size:12px;white-space:normal}
  body.aura10-native [hidden],body.aura10-native #libraryPanel[hidden],body.aura10-native #previewPanel[hidden],body.aura10-native #diagnosticsPanel[hidden]{display:none!important}
  @media(max-width:819px),(pointer:coarse){
    body.aura10-native .wrap{scroll-padding-top:155px;padding:8px}
    body.aura10-native .workspace{min-height:240px!important}
    body.aura10-native #aura10-native-controller .detail{grid-template-columns:repeat(2,minmax(0,1fr))}
    body.aura10-native .deck-panels{grid-template-columns:repeat(2,minmax(0,1fr))}
    body.aura10-native .top .mobile-nav button{min-height:46px;font-size:13px}
  }
  @media(max-width:350px){body.aura10-native .deck{padding:9px 6px!important}body.aura10-native .control-row button{font-size:11px!important;gap:2px}body.aura10-native .control-row button svg{display:none}body.aura10-native .subbrand{letter-spacing:.5px;font-size:9px}}
  @media(prefers-reduced-motion:reduce){body.aura10-native *,body.aura10-native *::before,body.aura10-native *::after{animation:none!important;transition:none!important;scroll-behavior:auto!important}}
 `;
 css.textContent+=`
 body.aura10-native #eg-neural-job{display:grid;grid-template-columns:minmax(0,1fr) auto;gap:7px;align-items:center;background:#0b1519;border:1px solid #31505a;border-radius:12px;padding:10px;margin:8px 0;}
 body.aura10-native .eg-ai-head{display:flex;align-items:center;gap:12px;font-size:12px;color:#a5ecf4;grid-column:1/-1} #eg-neural-percent{margin-left:auto;font-variant-numeric:tabular-nums} #eg-neural-message{font-size:12px;line-height:1.35;overflow-wrap:anywhere;color:#b5cdd0} #eg-neural-progress{width:100%;grid-column:1/-1;accent-color:#2ed2d3} #eg-neural-action{min-height:44px!important;max-width:140px;font-size:12px!important;border-color:#3b8990;color:#aaf1ef} body.aura10-native #aura10-classic[hidden],body.aura10-native #aura10-studio[hidden],body.aura10-native #eg-studio-shortcut[hidden]{display:none!important}
 body.aura10-native .deck-on{--deck-ink:#33dca0;--deck-light:#abffdb} body.aura10-native .deck-next{--deck-ink:#63b4ff;--deck-light:#a6d9ff} body.aura10-native .deck-next .tempo-number,body.aura10-native .deck-next .deck-label{color:#a6d9ff} body.aura10-native .deck-next .wave span{background:#63b4ff} body.aura10-native .control-row button:focus-visible,body.aura10-native button:focus-visible{outline:2px solid #80e7ff;outline-offset:2px}
 `;
 document.head.appendChild(css);
 const panel = document.createElement('div');panel.id='aura10-native-controller';
 panel.innerHTML = `<div class="head"><strong>EG MIX • CONSOLE PCM</strong><button id="aura10-tools" type="button" aria-expanded="false">Opções ▾</button></div>
 <div id="eg-mode-row"><span id="eg-mode-label">PRONTO</span><span id="eg-mode-info">Selecione músicas para iniciar.</span></div><button id="eg-studio-shortcut" type="button" hidden>Estúdio PCM</button><div id="eg-neural-job"><div class="eg-ai-head"><strong>IA • HTDemucs</strong><span id="eg-neural-percent">—</span></div><progress id="eg-neural-progress" max="100" value="0" aria-label="Progresso de separação neural"></progress><div id="eg-neural-message" role="status">Modelo local</div><button id="eg-neural-action" type="button">Preparar stems</button></div><div id="eg-transition"></div><div id="eg-meter" hidden><span>Pico PCM</span><progress max="60" value="0" aria-label="Pico digital do master em dBFS"></progress><span id="eg-peak">—</span></div><div id="aura10-state" role="status" aria-live="polite">Motor único · análise, mixagem, stems e efeitos.</div>
 <div id="aura11-dsp-state" aria-live="off" style="font-size:10px;color:#b9d7c5;display:none"></div>
 <div class="detail" id="aura10-detail">
   <button id="aura10-pick" type="button">+ Músicas</button><button id="aura10-start" type="button">▶ Reproduzir</button><button id="aura10-mixnow" type="button">⇄ Mixar agora</button>
   <button id="aura10-record" type="button">● Gravar WAV</button>
   <button id="aura10-test" type="button">Testar som</button><button id="aura10-export" type="button">↓ Master WAV (PCM)</button><button id="aura10-diag" type="button">Diagnóstico</button>
   <button id="aura10-studio" type="button" hidden>Estúdio PCM</button>
   <button id="aura11-capture" type="button">Captura de incidentes: desativada</button>
   <button id="aura11-capture-export" type="button">Exportar incidente WAV</button>
   <button id="aura10-classic" type="button" hidden>Modo clássico</button>
 </div>`;
 const row = document.querySelector('.controls .control-row') || document.querySelector('.controls');
 if(row)row.insertAdjacentElement('afterend',panel);else document.body.appendChild(panel);
 const mixSettings=document.querySelector('.controls .mix-row');if(mixSettings)panel.after(mixSettings);
 const list = document.createElement('div');list.id='aura10-native-tracklist';
 const legacyTracks=$('tracks');
 if(legacyTracks)legacyTracks.insertAdjacentElement('afterend',list);
 let native=true,record=false,lastPlaylistKey='',latest=null,searchTerm='',commandUntil=0;
 const put=(id,value)=>{const el=$(id);if(el&&el.textContent!==String(value))el.textContent=String(value);};
 const setDisabled=(id,disabled)=>{const el=$(id);if(el)el.disabled=!!disabled;};
 const reduced=()=>window.matchMedia('(prefers-reduced-motion: reduce)').matches;
 const scrollToEl=el=>el?.scrollIntoView({behavior:reduced()?'auto':'smooth',block:'start'});
 const libraryTools=document.createElement('div');libraryTools.id='eg-library-tools';
 libraryTools.innerHTML='<input id="eg-library-search" type="search" aria-label="Buscar música na biblioteca" placeholder="Buscar música…"><span id="eg-library-count"></span>';
 list.before(libraryTools);list.setAttribute('role','list');list.setAttribute('aria-label','Músicas da biblioteca');
 $('eg-library-search').addEventListener('input',e=>{searchTerm=e.target.value.trim().toLocaleLowerCase('pt-BR');lastPlaylistKey='';update();});
 function openTab(id){
   for(const tab of document.querySelectorAll('.tabs [data-panel]')){
     const active=tab.dataset.panel===id;tab.setAttribute('aria-selected',String(active));tab.tabIndex=active?0:-1;
     const content=$(tab.dataset.panel);if(content)content.hidden=!active;
   }
 }
 for(const tab of document.querySelectorAll('.tabs [data-panel]')){
   tab.addEventListener('click',()=>openTab(tab.dataset.panel));
   tab.addEventListener('keydown',e=>{if(!['ArrowLeft','ArrowRight','Home','End'].includes(e.key))return;e.preventDefault();const tabs=[...document.querySelectorAll('.tabs [data-panel]')],i=tabs.indexOf(tab),j=e.key==='Home'?0:e.key==='End'?tabs.length-1:(i+(e.key==='ArrowRight'?1:-1)+tabs.length)%tabs.length;openTab(tabs[j].dataset.panel);tabs[j].focus();});
 }
 openTab('libraryPanel');
 $('quickLibrary')?.addEventListener('click',()=>{openTab('libraryPanel');scrollToEl(document.querySelector('.workspace'));});
 $('quickConsole')?.addEventListener('click',()=>scrollToEl(document.querySelector('.performance')));
 function openClassic(){openTab('diagnosticsPanel');scrollToEl(document.querySelector('.workspace'));}
 const unavailable=['editToggle','preview','importReference','harmonize','recordMix','saveMixRecord','report','extendedPCM'];
 for(const id of unavailable){const el=$(id);if(el){el.disabled=true;el.title='Ferramenta legada ainda não migrada ao PCM';}}
 const preview=$('previewPanel');if(preview){for(const el of [...preview.children])el.hidden=true;const help=document.createElement('div');help.className='eg-native-help';help.innerHTML='<h2>Planejamento de transição</h2><p>O AutoDJ usa BPM, Camelot, energia e estrutura. A pré-escuta offline ainda não foi migrada do modo clássico.</p><button type="button">Ver diagnóstico</button>';help.querySelector('button').onclick=openClassic;preview.appendChild(help);}
 const diagnostics=$('diagnosticsPanel');if(diagnostics){for(const el of [...diagnostics.children])el.hidden=true;const help=document.createElement('div');help.className='eg-native-help';help.innerHTML='<h2>Ajustes do EG MIX</h2><p>Um único motor PCM para AutoDJ, efeitos, gravação e stems. A IA pode preparar faixas enquanto o set toca, conforme os recursos do aparelho. Os decks carregados não são substituídos abruptamente.</p><button type="button" data-action="diag">Diagnóstico Android</button><button type="button" data-action="tools">Opções do motor</button><button type="button" data-action="classic" hidden>Ferramentas legadas</button>';help.querySelector('[data-action=diag]').onclick=()=>api.diagnostic();help.querySelector('[data-action=tools]').onclick=()=>{panel.classList.add('open');$('aura10-tools').setAttribute('aria-expanded','true');$('aura10-tools').textContent='Opções ▴';scrollToEl(panel);};help.querySelector('[data-action=classic]').onclick=openClassic;diagnostics.appendChild(help);}
 $('statusDetails')?.addEventListener('click',()=>{const dialog=$('messageDialog');put('messageText',$('aura10-state').textContent);if(dialog?.showModal)dialog.showModal();else alert($('aura10-state').textContent);});
 $('closeMessage')?.addEventListener('click',()=> $('messageDialog')?.close());
 $('fullscreen')?.addEventListener('click',async()=>{try{if(document.fullscreenElement)await document.exitFullscreen();else if(document.documentElement.requestFullscreen)await document.documentElement.requestFullscreen();else put('aura10-state','Tela cheia indisponível neste aparelho.');}catch(e){put('aura10-state','Tela cheia indisponível neste aparelho.');}});
 for(const id of ['energyWave','nextWave','mixStyleControl']){const el=$(id);if(el){el.removeAttribute('tabindex');el.removeAttribute('role');}}
 const jingle=document.querySelector('[data-sampler=vinheta]');if(jingle){jingle.setAttribute('aria-label','Disparar vinheta Edgard Guarda');const small=jingle.querySelector('small');if(small)small.textContent='Edgard Guarda · WAV';}

 // The only audio path supported by native FX is Studio PCM/AudioTrack.
 // MediaPlayer, Web stems and Web rhythm pads cannot be silently re-routed.
 let selectedFx='off',lastStudioActive=false;
 const nativeFxButtons=[...document.querySelectorAll('[data-djfx]')];
 const fxStatus=$('fxStatus'),fxReset=$('fxReset'),fxAmount=$('fxAmount');
 const safeAmount=()=>Math.max(0,Math.min(1,(Number(fxAmount?.value)||0)/100));
 const announceFx=(message)=>{if(fxStatus)fxStatus.textContent=message;};
 const sendFx=()=>{if(typeof api.pcmRhythm==='function')api.pcmRhythm(selectedFx,safeAmount(),Number($('fxDivision')?.value)||4);else if(typeof api.pcmFx==='function')api.pcmFx(selectedFx,safeAmount());};
 $('fxDivision')?.addEventListener('change',sendFx);
 function renderNativeFx(studio){
   if((!studio||(!latest?.rhythmReady&&['roll','beatgrid','slip','overloop'].includes(selectedFx)))&&selectedFx!=='off'){selectedFx='off';sendFx();}
   for(const pad of nativeFxButtons){
     const rhythmic=pad.dataset.fxGroup==='rhythm';
     pad.disabled=!studio||(rhythmic&&(!latest?.rhythmReady||typeof api.pcmRhythm!=='function'));
     pad.setAttribute('aria-pressed',String(!pad.disabled&&studio&&selectedFx===pad.dataset.djfx));
     pad.title=rhythmic?(pad.disabled?'Aguarde BPM confiável no Estúdio PCM':'Efeito rítmico no master PCM; fonte continua tocando'):
         studio?'Efeito aplicado ao master PCM antes do limiter':'Inicie o Estúdio PCM para usar este efeito';
   }
   if(fxReset){fxReset.disabled=!studio||selectedFx==='off';fxReset.textContent=selectedFx==='off'?'FX OFF':'Desligar FX';}
   if(fxAmount)fxAmount.disabled=!studio;
   if(studio!==lastStudioActive){
     lastStudioActive=studio;
     if(studio)announceFx('Efeitos reais do Estúdio PCM · desligados por padrão');
     else announceFx('Estúdio PCM necessário para efeitos nativos. Modo rápido mantém áudio original.');
   }
 }
 for(const pad of nativeFxButtons){
   pad.addEventListener('click',()=>{
     if(pad.disabled||typeof api.pcmFx!=='function')return;
     selectedFx=selectedFx===pad.dataset.djfx?'off':pad.dataset.djfx;
     sendFx();renderNativeFx(true);
     announceFx(selectedFx==='off'?'Master original · sem efeito':pad.textContent.trim()+' · solicitado no master PCM');
   });
 }
 fxReset?.addEventListener('click',()=>{
   selectedFx='off';sendFx();renderNativeFx(true);announceFx('Master original · efeitos desligados');
 });
 fxAmount?.addEventListener('input',()=>{
   const output=$('fxAmountValue');if(output)output.textContent=Math.round(safeAmount()*100)+'%';
   if(lastStudioActive&&selectedFx!=='off')sendFx();
 });
 // Four real offline native samplers. No imaginary master/stems processing.
 // Studio PCM mixes them before the limiter; quick playback uses a safe one-shot bus.
 // Native seek in both engines; PCM prepares the replacement deck asynchronously.
 const seek=$('seek'), seekTime=$('seekTime');
 let draggingSeek=false,seekCanPlay=false,seekQuick=true,seekToken=0,dragToken=0,dragQuick=true;
 if(seek){
   seek.disabled=true;seek.min='0';seek.step='0.1';
   seek.style.touchAction='pan-x';
   seek.setAttribute('aria-label','Posição da música atual');
   seek.addEventListener('pointerdown',()=>{if(!seek.disabled){draggingSeek=true;dragToken=seekToken;dragQuick=seekQuick;}},true);
   seek.addEventListener('input',e=>{
     if(!native||seek.disabled)return;
     if(!draggingSeek){dragToken=seekToken;dragQuick=seekQuick;}
     draggingSeek=true;
     if(seekTime)seekTime.textContent=fmt(seek.value);
     e.stopImmediatePropagation();
   },true);
   const seekEnd=e=>{
     if(!native||!draggingSeek)return;
     e.stopImmediatePropagation();
     draggingSeek=false;
     if(!seekCanPlay||dragQuick!==seekQuick||dragToken!==seekToken)return;
     if(seekQuick&&typeof api.seek==='function')api.seek(Number(seek.value),seekToken);
     else if(!seekQuick&&typeof api.seekPcm==='function')api.seekPcm(Number(seek.value),seekToken);
   };
   seek.addEventListener('change',seekEnd,true);
   seek.addEventListener('pointerup',seekEnd,true);
   seek.addEventListener('pointercancel',()=>{draggingSeek=false;update();},true);
   seek.addEventListener('blur',()=>{if(draggingSeek){draggingSeek=false;update();}},true);
   seek.title='Importe e reproduza uma faixa para mover a posição';
 }
 const samplerVolume=$('samplerVolume');
 const samplerOutput=$('samplerVolumeValue');
 const nativeSamplerPads=[...document.querySelectorAll('[data-sampler]')];
 function updateSamplerLevel(){
   const pct=Math.max(0,Math.min(100,Number(samplerVolume?.value)||0));
   if(samplerOutput)samplerOutput.textContent=Math.round(pct)+'%';
 }
 samplerVolume?.addEventListener('input',updateSamplerLevel);
 updateSamplerLevel();
 for(const pad of nativeSamplerPads){
   pad.disabled=typeof api.sampler!=='function';
   pad.setAttribute('aria-pressed','false');
   pad.title='One-shot offline: clique para disparar';
   pad.addEventListener('click',()=>{
     if(pad.disabled)return;
     const key=pad.dataset.sampler;
     api.sampler(key,Math.max(0,Math.min(1,(Number(samplerVolume?.value)||0)/100)));
     pad.setAttribute('aria-pressed','true');
     clearTimeout(pad._egFlash);pad._egFlash=setTimeout(()=>pad.setAttribute('aria-pressed','false'),450);
   });
 }
 const samplerPanel=document.querySelector('.sampler-panel');
 if(samplerPanel){const note=document.createElement('p');note.className='aura-native-audio-note';
   note.textContent='EG MIX: vinheta personalizável e efeitos club offline. No Estúdio PCM passam pelo limiter; no modo rápido, volume de segurança.';
   samplerPanel.appendChild(note);
   if(typeof api.pickJingle==='function'&&typeof api.resetJingle==='function'){
     const controls=document.createElement('div');controls.className='sampler-pads';
     for(const [label,fn] of [['Importar vinheta WAV',()=>api.pickJingle()],['Restaurar vinheta original',()=>{if(confirm('Restaurar a vinheta original e remover a personalizada?'))api.resetJingle();}]]){
       const button=document.createElement('button');button.type='button';button.textContent=label;button.addEventListener('click',fn);controls.appendChild(button);
     }
     samplerPanel.appendChild(controls);
   }
 }
 announceFx('Tocar ativa os efeitos do Estúdio PCM. Efeitos rítmicos exigem BPM confiável.');
 $('quickIAStatus')?.addEventListener('click',()=>{
   panel.classList.add('open');$('aura10-tools')?.setAttribute('aria-expanded','true');
   panel.scrollIntoView({behavior:'smooth',block:'center'});
 });
 // Native controls are separate from the legacy WebAudio mixer.
 // Classic mode can mix user-supplied, verified separate WAV channels.
 if($('stemPrepare')){
   $('stemPrepare').textContent='Separar com IA';
   $('stemPrepare').disabled=false;
   $('stemPrepare').addEventListener('click',()=>{
     if(typeof api.neuralStems==='function'){api.neuralStems();}else openClassic();
   });
 }
 if($('stemReset'))$('stemReset').hidden=true;
 if($('stemStatus'))$('stemStatus').textContent='Sem stems: toque em Separar com IA para preparar a faixa atual.';
 for(const input of document.querySelectorAll('[data-stem-role]')){input.disabled=true;input.title='Sem stems separados no motor Android';}

 const nativeStemPanel=document.querySelector('.stem-panel');
 const nativeStemControls=[];
 if(nativeStemPanel){
   for(const el of nativeStemPanel.querySelectorAll('.stem-target,.stem-presets,#stemTargetStatus'))el.style.display='none';
   const mix=document.createElement('div');mix.style.cssText='display:grid;gap:10px;min-width:0';
   for(const [idx,heading] of ['ON · atual','NEXT · próxima'].entries()){
     const section=document.createElement('section');section.style.cssText='display:grid;gap:6px;padding:9px;border:1px solid #375c48;border-radius:8px';
     section.innerHTML='<strong></strong><small></small>';section.querySelector('strong').textContent=heading;
     const controls={section,title:section.querySelector('small'),token:null,inputs:[],buttons:[]};
     section.style.display='none';
     for(const [role,label] of ['Bateria','Baixo','Instrumentos','Vocais'].entries()){
       const row=document.createElement('label');row.style.cssText='display:grid;grid-template-columns:minmax(85px,1fr) minmax(65px,2fr) 42px;align-items:center;gap:5px;min-height:44px';
       const name=document.createElement('span');name.textContent=label;
       const slider=document.createElement('input');slider.type='range';slider.min='0';slider.max='100';slider.value='100';slider.style.cssText='width:100%;min-width:0;accent-color:#91e9b4';slider.setAttribute('aria-label',heading+' '+label);slider.disabled=true;
       const value=document.createElement('output');value.textContent='100%';
       let pointerToken=null,dragging=false;
       slider.addEventListener('pointerdown',()=>{dragging=true;pointerToken=controls.token;});
       for(const event of ['pointerup','pointercancel','lostpointercapture','blur'])slider.addEventListener(event,()=>{dragging=false;pointerToken=null;});
       slider.addEventListener('input',()=>{const token=dragging?pointerToken:controls.token;if(token===null||token!==controls.token)return;value.textContent=slider.value+'%';if(typeof api.stemGain==='function')api.stemGain(token,role,Number(slider.value));});
       row.append(name,slider,value);section.append(row);controls.inputs.push({slider,value});
     }
     const presets=document.createElement('div');presets.style.cssText='display:grid;grid-template-columns:repeat(2,minmax(0,1fr));gap:5px';
     for(const [label,mask] of [['Original',15],['Instrumental',7],['Só voz',8],['Silenciar',0]]){
       const b=document.createElement('button');b.type='button';b.textContent=label;b.style.minHeight='44px';b.disabled=true;
       b.onclick=()=>{if(controls.token!==null&&typeof api.stemPreset==='function')api.stemPreset(controls.token,mask);};presets.append(b);controls.buttons.push(b);
     }
     section.append(presets);mix.append(section);nativeStemControls.push(controls);
   }
   nativeStemPanel.append(mix);
 }
 function renderNativeStems(v){
   nativeStemControls.forEach((control,i)=>{
     const d=v.playing&&!v.quick&&typeof api.stemGain==='function'?v.pcmStems?.[i]:null;
     const old=control.token;control.token=d?.token??null;
     control.section.style.display=d?'grid':'none';
     control.title.textContent=d?String(d.title||'Faixa preparada'):'Sem stems preparados';
     control.inputs.forEach(({slider,value},role)=>{slider.disabled=!d;if(!d||old!==control.token||document.activeElement!==slider){slider.value=String(d?.gains?.[role]??100);value.textContent=slider.value+'%';}});
     control.buttons.forEach(b=>b.disabled=!d);
   });
   const any=nativeStemControls.some(c=>c.token!==null);if($('stemStatus'))$('stemStatus').textContent=any?'Stems reais preparados · ajustes acompanham cada faixa.':'Sem stems: toque em Separar com IA para preparar a faixa atual.';
 }
 document.body.classList.add('aura10-native');
 const style = () => $('mixStyleSelect')?.value || 'auto-dj';
 const beats = () => $('mixBeats')?.value || '0';
 function pick(){if(!latest?.busy)api.pick();}
 function dispatch(fn){if(Date.now()<commandUntil)return;commandUntil=Date.now()+550;fn();}
 function start(){if(!latest?.playing&&!latest?.selected)return;dispatch(()=>{if(latest?.playing){if(latest.mode==='paused')api.resume();}else api.start(style(),beats());});}
 function stop(){api.stop();commandUntil=0;}
 function pause(){if(latest?.playing&&latest.mode!=='paused')dispatch(()=>api.pause());}
 function next(){if(latest?.playing&&latest.mode!=='mixing'&&latest.mode!=='paused')dispatch(()=>api.next());}
 $('aura10-tools').onclick=()=>{const open=panel.classList.toggle('open');$('aura10-tools').setAttribute('aria-expanded',String(open));$('aura10-tools').textContent=open?'Opções ▴':'Opções ▾';};
 $('aura10-pick').onclick=pick;
 $('aura10-start').onclick=start;
 $('aura10-mixnow').onclick=next;
 $('aura10-studio').onclick=()=>api.studio(style(),beats());

 $('eg-studio-shortcut').onclick=()=> $('aura10-studio').click();
 $('eg-neural-action').onclick=()=>{if(latest?.neuralBusy){if(typeof api.cancelNeural==='function')api.cancelNeural();}else if(typeof api.neuralStems==='function')api.neuralStems();};
 $('aura10-record').onclick=()=>{if(!latest?.quick)dispatch(()=>api.record(!record));};
 $('aura10-export').onclick=()=>api.saveMaster();
 $('aura10-test').onclick=()=>api.testAudio();
 $('aura10-diag').onclick=()=>api.diagnostic();
 $('aura11-capture').onclick=()=>{
   const current=JSON.parse(api.snapshot()).autoCapture;
   if(!current && !confirm('Autorizar captura local de alguns segundos do áudio digital quando houver falha? Os WAVs podem conter trechos das suas músicas e ficam armazenados apenas neste aparelho. Até 5 capturas serão mantidas.'))return;
   api.autoCapture(!current);
   setTimeout(update,250);
 };
 $('aura11-capture-export').onclick=()=>api.exportIncident();
 $('aura10-classic').onclick=openClassic;
 // A native selection must never reach the legacy HTML's input/FileList.
 // The original app may retain its Web features in explicit classic mode.
 document.addEventListener('click', e=>{
   if(!native)return;
   const target=e.target.closest?.('#quickAdd,#drop,#files,#aura10-pick,#clear,#play,#pause,#stop,#next');
   if(!target)return;
   if(target.id==='aura10-pick')return;
   e.preventDefault();e.stopImmediatePropagation();
   if(target.id==='quickAdd'||target.id==='drop'||target.id==='files')pick();
   else if(target.id==='clear'){if(latest?.selected&&confirm('Limpar a biblioteca e parar a reprodução? Os arquivos originais serão preservados.'))api.clear();}
   else ({play:start,pause,stop,next})[target.id]?.();
 },true);
 // Disable spurious legacy file-change events if the file chooser originated in WebView.
 $('files')?.addEventListener('change',e=>{if(native){e.stopImmediatePropagation();e.target.value='';}},true);
 function update(){
   if(!native)return;
   try{
     const v=JSON.parse(api.snapshot());latest=v;
     const status=String(v.status||'EG MIX Android pronto');
     const captureButton=$('aura11-capture');
     if(captureButton)captureButton.textContent=v.autoCapture?'Captura de incidentes: ativada':'Captura de incidentes: desativada';
     const selected=Math.max(0,v.selected||0),decoded=Math.max(0,v.decoded||0);
     const playing=!!v.playing,idx=Math.max(0,v.index||0);
     const activeSeconds=playing?(Number(v.quick?v.time:v.pcmPosition)||0):0;
     const quickDuration=Math.max(0,(Number(v.durationMs)||0)/1000);
     const studioDuration=Math.max(0,Number(v.pcmDuration)||0);
     const seekDuration=playing?(v.quick?quickDuration:studioDuration):0;
     seekQuick=!!v.quick;seekToken=v.quick?Number(v.quickSeekToken):Number(v.pcmSeekToken)||0;
     seekCanPlay=!!(playing && v.mode!=='mixing' && (v.quick?(quickDuration>1.5&&Number.isInteger(seekToken)&&seekToken>=0):(v.pcmCanSeek&&studioDuration>1.5)));
     if(draggingSeek&&(!seekCanPlay||dragQuick!==seekQuick||dragToken!==seekToken))draggingSeek=false;
     if(seek){
       seek.disabled=!seekCanPlay;
       seek.max=String(Math.max(0,seekDuration));
       if(!draggingSeek)seek.value=String(Math.min(seekDuration,Math.max(0,activeSeconds)));
       seek.title=seekCanPlay?'Arraste para avançar ou voltar na música atual':
         playing?'Aguarde o carregamento ou o final da transição':'Reproduza uma música para ativar a posição';
     }
     if(seekTime&&!draggingSeek)seekTime.textContent=fmt(activeSeconds);

     renderNativeFx(playing&&!v.quick&&v.mode!=='loading'&&v.mode!=='paused');
     if(playing&&!v.quick&&fxStatus&&selectedFx!=='off')announceFx(`${selectedFx} · ${Number(v.fxAppliedFrames||0)>0?'DSP aplicado':'aguardando sinal'} · ${Math.round(safeAmount()*100)}%`);
     if(samplerPanel){const note=samplerPanel.querySelector('.aura-native-audio-note');if(note)note.textContent=`Samplers: ${v.samplerReady?'prontos':'carregando'} · ${v.quick||!playing||v.mode==='paused'?'saída auxiliar':'barramento PCM'} · ${Number(v.samplerFrames||0)} quadros PCM`;}
     renderNativeStems(v);
     const prefix=v.quick?(v.mode==='paused'?'PAUSADO':v.mode==='loading'?'ABRINDO ÁUDIO':v.mode==='mixing'?(v.beatmatched?'TEMPO AJUSTADO (BETA)':'CROSSFADE'):'TOCANDO') :v.busy?`DSP ${decoded}/${selected}`:playing?(v.mode==='paused'?'PAUSADO':'REPRODUÇÃO'):selected?`MÚSICAS ${selected}`:'BIBLIOTECA VAZIA';
     put('aura10-state',prefix+' · '+status);
     const mode=v.busy&&!playing?'PREPARANDO PCM':playing?(v.quick?'MODO RÁPIDO':'PCM · AUTO DJ'):'PRONTO';
     put('eg-mode-label',mode);put('eg-mode-info',v.busy?`${decoded} de ${selected} faixas preparadas${playing?' · áudio ativo':''}`:playing?(v.quick?'Reprodução imediata · master original':'Efeitos PCM e gravação WAV disponíveis'):'Tocar inicia o motor único com fila inteligente.');
     put('eg-transition',playing?(v.mode==='mixing'?'Transição em andamento · aguarde para buscar ou avançar':v.mode==='paused'?'Pausado · toque em Retomar':v.next?'Próxima: '+v.next+' · mixes '+Number(v.mixedTransitions||0):'Sem próxima faixa confirmada'):'');
     const meter=$('eg-meter');meter.hidden=!playing||v.quick||v.mode==='paused';if(!meter.hidden){const db=Number(v.masterPeakDbfs);meter.querySelector('progress').value=Number.isFinite(db)?Math.max(0,Math.min(60,db+60)):0;put('eg-peak',Number.isFinite(db)?db.toFixed(1)+' dBFS':'—');}
     record=!!v.recordRequested;put('aura10-record',record?'■ Cancelar / encerrar WAV':'● Solicitar gravação WAV');
     setDisabled('aura10-record',v.quick);setDisabled('aura10-test',playing||v.busy);setDisabled('aura10-studio',!selected||v.autoPlayPending||playing);setDisabled('eg-studio-shortcut',!selected||v.autoPlayPending||playing);$('eg-studio-shortcut').hidden=true;put('eg-studio-shortcut',v.busy?'Preparando Estúdio PCM…':'Abrir Estúdio PCM · efeitos e WAV');setDisabled('aura10-export',!v.hasMaster);
     for(const id of ['quickAdd','aura10-pick'])setDisabled(id,v.busy);
     setDisabled('clear',!selected);setDisabled('stop',!playing&&!v.busy&&!v.autoPlayPending);
     put('quickIAStatus',v.neuralBusy?'IA · '+Number(v.neuralProgress||0)+'%':'IA · '+(v.modelState||'Modelo integrado'));
     put('eg-neural-message',v.neuralBusy?(v.neuralMessage||'Preparando…'):(v.neuralMessage||v.modelState||'Modelo integrado'));
     put('eg-neural-percent',v.neuralBusy?Number(v.neuralProgress||0)+'%':'LOCAL');
     $('eg-neural-progress').value=Number(v.neuralProgress||0);$('eg-neural-progress').hidden=!v.neuralBusy;
     put('eg-neural-action',v.neuralBusy?'Cancelar IA':'Preparar stems');setDisabled('eg-neural-action',!v.neuralBusy&&(v.busy||v.autoPlayPending||!selected));setDisabled('stemPrepare',!!v.neuralBusy||!!v.busy||!selected);

     const dsp=$('aura11-dsp-state');
     if(dsp){
       dsp.style.display=playing&&!v.quick?'block':'none';
       if(playing&&!v.quick){
         const db=n=>Number.isFinite(Number(n))?Number(n).toFixed(1):'—';
         dsp.textContent=`PCM · ${v.pitchPreserving?'WSOLA tonalidade':'tempo original'} · `+
           `fase ${v.phaseEstimatedLocked?'estimada ✓':'não validada'} (${db(v.phaseErrorMs)} ms) · `+
           `pico ${db(v.masterPeakDbfs)} dBFS · RMS ${db(v.masterRmsDbfs)} dBFS · `+
           `limiter ${db(v.masterLimiterGain)}×, atenuados ${Number(v.masterLimiterReducedFrames||0)} quadros · `+
           `picos pré-limiter ${Number(v.masterPreLimitClips||0)} · `+
           `autocorreções ${Number(v.autoDeferred||0)+Number(v.autoPhaseFallbacks||0)} · `+
           `alertas digitais ${Number(v.autoDigitalAlerts||0)}`;
       }
     }
     $('trackCount') && ($('trackCount').textContent=String(selected));
     
     $('transport') && ($('transport').textContent=playing?(v.mode==='paused'?'PAUSADO':v.mode==='loading'?'ABRINDO':v.mode==='mixing'?'MIXANDO':'TOCANDO'):v.busy?'ANALISANDO':selected?'PRONTO':'VAZIO');
     put('status',prefix+' · '+status);$('status')?.setAttribute('aria-live','off');
     const paused=playing&&v.mode==='paused';
     const canStart=paused||(!playing&&selected>0&&!v.autoPlayPending);
     setDisabled('play',!canStart);setDisabled('aura10-start',!canStart);
     const playLabel=$('play')?.querySelector('span');if(playLabel)playLabel.textContent=paused?'Retomar':'Tocar';
     put('aura10-start',paused?'▶ Retomar':v.autoPlayPending?'Preparando primeiras faixas…':'▶ Reproduzir');
     setDisabled('pause',!playing||paused);setDisabled('next',!playing||paused||v.mode==='mixing');setDisabled('aura10-mixnow',!playing||paused||v.mode==='mixing');
     const nextLabel=$('next')?.querySelector('span');if(nextLabel)nextLabel.textContent='Próxima';
     for(const id of ['mixStyleSelect','mixBeats'])setDisabled(id,playing||v.busy);

     const imported=Array.isArray(v.names)?v.names:[],tracks=Array.isArray(v.tracks)?v.tracks:[];
     const preparedNames=new Set(tracks.map(t=>t.name));
     const names=!v.quick&&tracks.length?(v.analysisComplete?tracks.map(t=>t.name):[...tracks.map(t=>t.name),...imported.filter(n=>!preparedNames.has(n))]):imported;
     const key=JSON.stringify({names,tracks,idx,playing,busy:v.busy,quick:v.quick,mode:v.mode,title:v.pcmTitle,next:v.next,searchTerm});
     if(key!==lastPlaylistKey){
       const frag=document.createDocumentFragment();
       let visible=0;const byName=new Map();for(const track of tracks){if(!byName.has(track.name))byName.set(track.name,track);else byName.set(track.name,null);}
       const nameCounts=new Map();for(const name of names)nameCounts.set(name,(nameCounts.get(name)||0)+1);
       names.forEach((name,i)=>{
         if(searchTerm&&!String(name).toLocaleLowerCase('pt-BR').includes(searchTerm))return;visible++;
         const active=playing&&(v.quick?i===idx:(nameCounts.get(name)===1&&name===v.pcmTitle));
         const div=document.createElement('div');div.className='entry'+(active?' on':'');div.setAttribute('role','listitem');if(active)div.setAttribute('aria-current','true');
         const t=byName.get(name);const meta=t?`${t.confidence>=.30?Number(t.bpm||0).toFixed(1)+' BPM':'BPM ?'} · ${t.camelot||'Tom ?'} · ${t.loudnessVersion===1&&Number.isFinite(t.loudnessLufs)&&t.loudnessLufs>=-70?Number(t.loudnessLufs).toFixed(1)+' LUFS · ':''}${fmt(t.seconds)}`:v.busy?'Preparando PCM…':'Na biblioteca';
         const state=(active?(v.mode==='paused'?'Pausada · ':'Tocando · '):playing&&v.next===name&&nameCounts.get(name)===1?'Próxima · ':'')+meta;
         div.innerHTML=`<small>${String(i+1).padStart(2,'0')}</small><b title="${escape(name)}">${escape(name)}</b><small>${escape(state)}</small>`;
         frag.appendChild(div);
       });
       // WebView 80–85 does not implement Element.replaceChildren.
       while(list.firstChild)list.removeChild(list.firstChild);list.appendChild(frag);
       lastPlaylistKey=key;put('eg-library-count',visible+' de '+names.length+' faixas');
       if(names.length&&!visible){const msg=document.createElement('p');msg.className='empty';msg.textContent='Nenhuma música corresponde à busca.';list.appendChild(msg);}
       if(!names.length){
         list.innerHTML='<div class="empty"><strong>Pronto para o seu primeiro set</strong><span>Importe músicas do aparelho para ativar o motor de mixagem.</span><button class="primary" type="button" id="aura-empty-add">＋ Selecionar músicas</button><button type="button" id="aura-empty-console">Ver console e efeitos</button></div>';
         $('aura-empty-add')?.addEventListener('click',pick);
         $('aura-empty-console')?.addEventListener('click',()=>document.querySelector('.wrap')?.scrollTo({top:0,behavior:'smooth'}));
       }
     }
     const uniqueTrack=name=>{const matches=tracks.filter(t=>t.name===name);return matches.length===1?matches[0]:null;};
     const current=playing&&!v.quick&&v.pcmTitle?uniqueTrack(v.pcmTitle):null;
     const following=!v.quick&&playing?uniqueTrack(v.next):null;
     if(playing&&!v.quick){
       $('currentName') && ($('currentName').textContent=v.pcmTitle||current?.name||'Abrindo faixa');
       $('onBpm') && ($('onBpm').textContent=Number(current?.bpm)>0?`${Number(current.bpm).toFixed(1)} BPM · DSP`:'BPM indisponível');
       $('onKey') && ($('onKey').textContent=current?.camelot||'Tom ?');
       $('onSection') && ($('onSection').textContent=Number(current?.phraseOutroConfidence||0)>=.65?'Hipótese de frase no final':'Seção não verificada');
       $('time') && ($('time').textContent=`${fmt(activeSeconds)} / ${fmt(studioDuration||current?.seconds||0)}`);
       $('remaining') && ($('remaining').textContent=`-${fmt(Math.max(0,(studioDuration||current?.seconds||0)-activeSeconds))}`);
     }else{
       $('currentName') && ($('currentName').textContent=playing?(names[idx]||'Abrindo faixa'):'Nenhuma faixa em reprodução');
       $('onBpm') && ($('onBpm').textContent=v.quick?(v.currentBpm>0?`${Number(v.currentBpm).toFixed(1)} BPM medido`:'BPM: analisando / indisponível'):selected?'Análise automática BPM + Camelot':'Adicione músicas');
       $('time') && ($('time').textContent=playing?`${fmt(activeSeconds)} / ${fmt(seekDuration)}`:'0:00 / --:--');
       $('remaining') && ($('remaining').textContent=playing?`-${fmt(Math.max(0,seekDuration-activeSeconds))}`:'--');
     }
     $('nextName') && ($('nextName').textContent=!playing?(names[0]||'Fila vazia'):v.quick?(v.next||'Fim da fila'):(v.next||following?.name||'Fim da fila'));
     $('nextBpm') && ($('nextBpm').textContent=v.quick?(v.nextBpm>0?`${Number(v.nextBpm).toFixed(1)} BPM medido`:'BPM: analisando / indisponível'):following?`${Number(following.bpm).toFixed(1)} BPM · DSP`:'BPM pendente');
     $('nextKey') && ($('nextKey').textContent=following?.camelot||'Tom ?');
     $('nextSection') && ($('nextSection').textContent=Number(following?.phraseIntroConfidence||0)>=.65?'Hipótese de entrada musical':'Seção não verificada');
     $('nextDuration') && ($('nextDuration').textContent=playing&&following?fmt(following.seconds):'--:--');
     if(!playing){put('onBpm','— BPM');put('nextBpm','— BPM');put('onSection','Sem reprodução');put('nextSection',selected?'Primeira da fila':'Adicione músicas');put('onKey','—');put('nextKey','—');}
     put('onLevel',playing?'Áudio nativo':'—');put('nextLevel','—');put('nextEngine',playing&&v.next?'Na fila':'Aguardando');
   }catch(e){console.error('EG MIX bridge/update:',e);latest=null;put('aura10-state','Falha de comunicação Android: '+e.message);for(const id of ['play','pause','next','aura10-start','aura10-mixnow','aura10-studio','eg-studio-shortcut','aura10-record'])setDisabled(id,true);if(seek)seek.disabled=true;}
 }
 update();setInterval(()=>{if(!document.hidden)update();},500);document.addEventListener('visibilitychange',()=>{if(!document.hidden)update();});
})();
