#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")/.."
build=$(mktemp -d);trap 'rm -rf "$build"' EXIT
javac -d "$build" app/src/main/java/br/com/edgard/aura/core/LiveNeuralGuard.java tests/LiveNeuralGuardTest.java
java -cp "$build" LiveNeuralGuardTest
python3 - <<'P'
from pathlib import Path
j=Path('app/src/main/java/br/com/edgard/aura/MainActivity.java').read_text();u=Path('app/src/main/assets/native-ui.js').read_text();n=Path('app/src/main/java/br/com/edgard/aura/NeuralStemActivity.java').read_text()
assert 'private void startQuick(String style,String beats){startStudio(style,beats);}' in j
assert 'getAssets().open("/native-ui.js".equals(path)?"native-ui.js":"aura-fast.html")' in j
assert "location.href='/classic.html'" not in u
assert 'eg-neural-action' in u and 'cancelNeural' in j
assert 'checkLiveResources(guard)' in n and 'detached=true;finish()' in n
print('PASS unified transport and live IA control static checks')
P
