import br.com.edgard.aura.core.LiveNeuralGuard;
public class LiveNeuralGuardTest {
 static void ok(boolean b){if(!b)throw new AssertionError();}
 public static void main(String[] args){LiveNeuralGuard g=new LiveNeuralGuard();long mem=2*LiveNeuralGuard.MIN_LIVE_FREE;
 ok(g.check(false,false,0,0,20)==null);ok(g.check(true,false,mem,0,20)==null);ok(g.check(true,false,mem,0,22)==null);ok(g.check(true,false,mem,0,23)!=null);
 ok(g.check(false,false,mem,0,23)==null);ok(g.check(true,false,mem,0,0)==null);ok(g.check(true,false,mem,0,1)==null);ok(g.check(true,false,mem,0,0)==null);
 ok(g.check(true,false,0,0,0)!=null);ok(g.check(false,true,mem,0,0)!=null);ok(g.check(true,false,mem,3,0)!=null);ok(g.check(true,false,mem,2,0)==null);
 System.out.println("PASS live neural guard: memory, thermal, underruns, playback state, counter reset");}
}
